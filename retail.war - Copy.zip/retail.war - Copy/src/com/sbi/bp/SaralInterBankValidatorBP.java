package com.sbi.bp;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.CorpTransaction;
import com.sbi.model.Transaction;
import com.sbi.rtgs.utils.CutoffTimeUtils;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;

public class SaralInterBankValidatorBP extends TransactionValidatorBP{
	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;
	
	private CutoffTimeUtils cutoffTimeUtils;//Added by Venkatesh
	private UserDAO userDAOImpl;
	private ReferenceDataCache referenceDataCache;

	/**
	 * Call validator.validateInterBank() method Call validator.validateLimit()
	 * method Call validator.validateTxnRights() method Call
	 * validator.validateAccountNature() method if both credit and debit
	 * branches are different { Call validator.validateTodaysTxnLimit() method
	 * Call validator.validateInterBranchLimit() method } if bankSystem is
	 * NonCore { Call validator.validateTransfer() method }
	 * 
	 * @param transaction
	 * @return boolean
	 */
	public boolean validate(Transaction txn)
			throws SBIApplicationException {
		this.transaction = txn;
		if (transaction != null) {
			
			 CorpTransaction transaction = (CorpTransaction)txn;
			 
			logger.info("validate(Transaction       transaction) "
					+ LoggingConstants.METHODBEGIN);
				logger.info("transaction :" + transaction.toString());
			double totalAmount=transaction.getDebit().getAmount().doubleValue()+transaction.getDebit().getRateOfInterest().doubleValue();
			
			validator.validateAmount(new Double(totalAmount));
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount() return true");
			}
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime());			
			

				if(!cutoffTimeUtils.isValidDateAndTime(transaction.getScheduledDate(),transaction.getDebit().getMerchantCode(),transaction.getBankCode()))
				{
					logger.info("scheduled date is not valid!!");				
					SBIApplicationException.throwException("IBFT009");//Verify the status of your transaction in the Status Enquiry link before you retry.
				}
			
			//Commented for SARAL LIMIT Changes
			/*validator.validateLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
					transaction.getName(),transaction.getBankCode(),scheduledDate);
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateLimit(String username,Double amount, String type,String bankCode) method - true");
			}*/

		
			String interBankIFSCCode=null;
			if (transaction.getDebit().getMerchantCode().equalsIgnoreCase("RTGS")) {
				
			Map data = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
            String limit = (String) data.get("CORP_RTGS_MIN_TRANSACTION_LIMIT");
            logger.info("limit****"+limit);
            
            double limitAmount = Double.parseDouble(limit);
           logger.info("limitAmount :" + limitAmount);
				if (transaction.getDebit().getAmount().doubleValue()<limitAmount)
					SBIApplicationException.throwException("IBFT004");
			}
		
			if (transaction.getDebit().getMerchantCode().equalsIgnoreCase("RTGS") || transaction.getDebit().getMerchantCode().equalsIgnoreCase("NEFT")
					|| transaction.getDebit().getMerchantCode().equalsIgnoreCase("GRPT")) {
				String narrative2=transaction.getCredit()[0].getNarrative2();
				logger.info("narrative 2:@@@@" +narrative2);
				if (narrative2!=null) {
					String interBankNarrative2[]=narrative2.split("\\|");
					interBankIFSCCode=interBankNarrative2[1];
				}
			}
			
			
			
			
			validator.validateInterBankAcctLimitForSaral(transaction.getCredit()[0].getNarrative1(),
					interBankIFSCCode,
			          transaction.getCredit()[BPConstants.ZERO_INT].getNarrative3(),
			          new Double(transaction.getDebit().getAmount().doubleValue()),transaction);
			

			
			validator.validateTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), new Integer(
							BPConstants.DEBIT_NO));
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
			}

		//Commented for SARAL LIMIT Changes
		/*	validator.validateTodaysTxnLimit(transaction.getDebit()
					.getAccountNo(), transaction.getDebit().getBranchCode(),
					new Double(transaction.getDebit().getAmount().doubleValue()),scheduledDate);
						if (logger.isDebugEnabled()) {
				logger
						.debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
			}*/

			//Commented for SARAL LIMIT Changes	
		/*	if (!(transaction.getDebit().getBranchCode()
					.equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode()))) {
             validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),new Double(transaction.getDebit().getAmount().doubleValue()),transaction.getName(),transaction.getBankCode(),scheduledDate);//bank code added for CR 1734
            if (logger.isDebugEnabled()){
            
                logger
                        .debug("validateTodaysInterBranchTxnLimit(String userName, Double amount, String txnName,String bankCode) method - true");
           
            
            }
			}*/
			//added for beneficiary process flow
			int newBeneficiaryCount=0;
			newBeneficiaryCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "INTERBANK", transaction.getCredit()[BPConstants.ZERO_INT].getNarrative1(), "SARAL",interBankIFSCCode);
						
			if(newBeneficiaryCount>0){
				transaction.getDebit().setIsNewlyAddedTp("YES");
				logger.info("Newly Added Beneficiary:::");
				logger.info("transaction.isScheduled()::::::::"+transaction.isScheduled());
				
				if(transaction.isScheduled()){
					SBIApplicationException.throwException("TPB004");
				}else{
					validator.newBeneficiaryAdditionLimitValidationForSaral(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getNarrative1(), "SARAL", "INTERBANK",transaction.getBankCode() , transaction.getDebit().getAmount(), interBankIFSCCode);
				}				
			}
			/*** 
			 * SARAL Limit Change Calling New Method to Validate the Based on the Category Wise overriding the existing all limit Validation
			 */
			
			/*** 
			 * Calling New Method to Validate the Based on the Category Wise overriding the existing all limit Validation
			 */
			
			String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
        Map data = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
		 String limit = (String) data.get("SARAL_SUBCAT_IB_CATEGORY_A_"+bankCode);
		 logger.info("limit >>>>>>>>"+limit);
		 logger.info("limit >>>>>>>>"+limit);
     	 double interBankTransferLimit = Double.parseDouble(limit);
     	 if (transaction.getDebit().getAmount().doubleValue()>interBankTransferLimit) {
			SBIApplicationException.throwException("LMT003");
     	 }
     	validator.validateSubCategoryGroupALimitForSaral(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, bankCode, "Interbank","SARAL");
     	
     	logger.info("validateSubCategoryGroupALimit method returns true");
     	
			logger.info("AMount:::::::"+transaction.getDebit().getAmount());
			validator.validateCategoryALimitForSaral(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount()), scheduledDate, transaction.getBankCode(),"SARAL");
			
			logger.info("validateCategoryALimit retruns true");
			
			
			//added for beneficiary process flow ends
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODEND);
			logger.info("Inside BP%%%% "+transaction.getDebit().toString());

		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		return true;
	}

	/**
	 * Validator injection
	 * 
	 * @param validator
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	//Added by Venkatesh
	public void setCutoffTimeUtils(CutoffTimeUtils cutoffTimeUtils) {
		this.cutoffTimeUtils = cutoffTimeUtils;
	}
	
	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	  public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
			this.referenceDataCache = referenceDataCache;
		}

}
