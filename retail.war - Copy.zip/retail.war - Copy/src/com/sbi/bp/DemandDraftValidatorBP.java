/*
 * DemandDraftValidatorBP.java
 * Created on Nov 5, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 5, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
//Changed on 30-June-2006 for Paladion by Saravanan N
package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.AccountDAOImpl;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.DDTransaction;
import com.sbi.model.Transaction;
import com.sbi.utils.Validator;

public class DemandDraftValidatorBP extends TransactionValidatorBP
{

    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;
    private AccountDAOImpl accountDAOImpl;

    /**
     * Call validator.validateInterBank method Call validator.validateLimit
     * method Call validator.validateTxnRights method if debit and credit branch
     * codes are different { call validator.validateTodaysTxnLimit method } if
     * any one of the method throws Exception then throw SBIApplicationException
     * else return true
     * 
     * @param transaction
     * @return boolean
     * @throws SBIApplicationException
     */
    public boolean validate(Transaction ddTransaction) throws SBIApplicationException
    {
        //this.transaction = transaction;
    	DDTransaction transaction = (DDTransaction)ddTransaction;
        if (transaction != null)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("validate(Transaction transaction) Begin :" + transaction.toString());
            }



            validator.validateAmount(transaction.getDebit().getAmount());
            if(logger.isDebugEnabled()){
            	logger.debug("validateAmount() return true");
            }
            //limit change uday
            //bank code added for CR 5023
           /* validator.validateLimit(transaction.getDebit().getAmount(), transaction.getName(),transaction.getBankCode());
            if (logger.isDebugEnabled())
            {
                logger.debug("validateLimit(Double amount, String type) method - true");
            }
            // CR 1523 -start
            validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getName(),transaction.getBankCode());//bank code added for CR 1734
            if (logger.isDebugEnabled()){
            
                logger
                        .debug("validateTodaysInterBranchTxnLimit(String userName, Double amount,String txnName) method - true");
            }*/
          //limit change uday
            // CR 1523 - end
            // added for paladion on 30-june-06
            validator.validateUserDDLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount());
            if (logger.isDebugEnabled())
            {
                logger.debug("validateUserDDLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount()) method - true");
            }
            //end
            validator.validateMinorMajorTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(),8,9);
            if (logger.isDebugEnabled())
            { 
                logger
                        .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
            }
         
         /*   validator.validateTodaysTxnLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                        .getBranchCode(), transaction.getDebit().getAmount());
                if (logger.isDebugEnabled())
                {
                    logger
                            .debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
                }*/
           validator.validateInterBank(transaction.getDebit().getBranchCode(),
                    transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
            if (logger.isDebugEnabled())
            {
                logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
            }
            
    //Added for DD IOI  
            Date scheduledDate = new Date(transaction.getScheduledDate().getTime());
			 String bankCode=transaction.getBankCode();
	            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
	            	bankCode="0";
	            }	
	            Account account=accountDAOImpl.findAccount(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
	            validator.validateSubCategoryGroupAMinorLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "DemandDraft",account.getProductCode());
	            validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "DemandDraft");
	           
			       logger.info("validateSubCategoryGroupBLimit method - true");
            //chang limit uday
            validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
                    transaction.getName(),transaction.getBankCode(),scheduledDate);
            if (logger.isDebugEnabled());
            if (logger.isDebugEnabled()) {
                logger.debug("validateCategoryBLimits(String username,Double amount, String type,String bankCode) method - true");
            }
          //chang limit uday
            
	       if("N".equalsIgnoreCase(transaction.getIoiEnabled()) && !"0|6|3|A".contains(transaction.getBankCode())){
	    	   validator.validateInterBranch(transaction.getDebit().getBranchCode(),
	                    transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
	    	   
           }
	       
	       validator.validateDDCreditBranch(transaction.getCredit()[0].getBranchCode(), transaction.getBankCode());
	       if (logger.isDebugEnabled())
           {
               logger.debug("validateDDCreditBranch(String creditBranchCode,String bankCode) method - true");
           }
            logger.debug("validate(Transaction transaction) Ends");

        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return true;

    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }

	public void setAccountDAOImpl(AccountDAOImpl accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}
	
}

