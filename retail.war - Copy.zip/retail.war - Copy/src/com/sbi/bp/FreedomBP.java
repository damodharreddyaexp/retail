package com.sbi.bp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.dao.FreedomRegDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.FreedomReqFormat;
import com.sbi.utils.UtilsConstant;



public class FreedomBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private FreedomRegDAO freedomRegDAOImpl; 
	private ReferenceDataCache referenceDataCache;	 
	 private  FreedomReqFormat freedomReqFormat;

	private CoreDAOImpl coreDAOImpl ;
	public Map getCIFMobileNoFromCore ( Map requestDataMap) {
		logger.info("getCIFMobileNoFromCore ( Map requestDataMap) -start");
		Map responseDataMap = new HashMap ();
		
		boolean flag=freedomRegDAOImpl.checkAccNoSelection((String)requestDataMap.get("loginUser"),
				(String)requestDataMap.get("account_no"));
		if(flag)
		{
			SBIApplicationException.throwException("MP027");
		}
		
		requestDataMap.put("txnno", "000400");
		List<Map> responseList = coreDAOImpl.getDataFromBankSystem(requestDataMap);
		@SuppressWarnings("unchecked")
		Map<String,String> resMap = responseList.get(0);
		logger.info("000400" +resMap);
		
		String primaryCIF=freedomRegDAOImpl.checkPrimaryCif(""+requestDataMap.get("loginUser"),""+resMap.get("cif_no"));
		if("CIFEmpty".equalsIgnoreCase(primaryCIF))  //checking primary account or not
		{
			SBIApplicationException.throwException("FRE04");
		}
		else if ("CIFMisMatched".equalsIgnoreCase(primaryCIF))
		{
			SBIApplicationException.throwException("FRE03");
		}
		else if ("MultipleCIF".equalsIgnoreCase(primaryCIF))
		{
			SBIApplicationException.throwException("FRE02");
		}
		// Retrieving mobile number from core server
		requestDataMap.put("txnno", "060459");
	    requestDataMap.put("Customer_Number",(String) resMap.get("cif_no"));
		responseList = coreDAOImpl.getDataFromBankSystem(requestDataMap);
		responseDataMap=responseList.get(0);
		logger.info("60459 "+responseDataMap);
    	requestDataMap.put("Postal Code",responseDataMap.get("Postal Code"));
        String coreMobileNo= (String)responseDataMap.get("Mobile Number");
        String address=responseDataMap.get("Address 1")+","+responseDataMap.get("Address 2")+","
 		+responseDataMap.get("Address 3")+","+responseDataMap.get("Address 4");//060459 response
        requestDataMap.put("fulladdress", address);
       
        String enteredMobileNo=(String)requestDataMap.get("mobileNo");
        if (coreMobileNo!= null && coreMobileNo.trim().length()>0) {
        	 if(!coreMobileNo.equals(enteredMobileNo) ) {
        		 SBIApplicationException.throwException("MOB001");       
        	 }        
        }
        else if (coreMobileNo == null || "".equals(coreMobileNo)) {
			logger.info("No mobile number from Core Server");
			SBIApplicationException.throwException("SE131");
		}
        
	
           //Retrieving mode of operation
			requestDataMap.put("account_no",(String)requestDataMap.get("account_no"));
		    requestDataMap.put("txnno", "069029");
			responseList = coreDAOImpl.getDataFromBankSystem(requestDataMap);
			responseDataMap=responseList.get(0);
			logger.info("069029 "+responseDataMap);
			responseDataMap.put("mode_of_operation",(String)responseDataMap.get("mode_of_operation"));
			String modeOfOperation=(String)responseDataMap.get("mode_of_operation");
			if(modeOfOperation == null || !(modeOfOperation.equalsIgnoreCase("SINGLE") || modeOfOperation.equalsIgnoreCase("EITHER OR SURVIVOR")
					||  modeOfOperation.equalsIgnoreCase("ANY A/C HOLD OR SURV")))
		    {
				SBIApplicationException.throwException("FRE01");
		    }
     
        Map requestMap = new HashMap();
       String userId=(String)requestDataMap.get("loginUser");
		String acctNo=(String)requestDataMap.get("account_no") ;
		String prodCode[]=new String[2];
		if(resMap.get("product_code")!=null && !"".equals(resMap.get("product_code")))
		    {
			String product_code=resMap.get("product_code");
			prodCode[0]=product_code.substring(0, 4);
			prodCode[1]=product_code.substring(4,8);
		    }
		requestDataMap.putAll(freedomRegDAOImpl.freedomReqForm(userId,acctNo,prodCode));    
        requestDataMap.put("branchCode",resMap.get("branch_code"));
    	requestDataMap.put("cif_no",resMap.get("cif_no"));
    	requestDataMap.put("name",resMap.get("name"));
    	requestDataMap.putAll(freedomReqFormat.formatSpecification(requestDataMap));

      String psgIpPort = fetchDataFromReferenceCache("sbifreedom");
		if(psgIpPort == null ){
			logger.info("Please check the PSG port and ip.");
			throw new SBIApplicationException("F001");
		}
		String psgInfo[] = psgIpPort.split("\\|");
		requestDataMap.put("psgPort",psgInfo[1]);
		requestDataMap.put("psgIp",psgInfo[0]);
		requestDataMap.put("protocolID", "");
		
		   return requestDataMap;
	
		
	}
	
	private String fetchDataFromReferenceCache(String cachRefKey){
		Map cacheData = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
		String cacheValue = (String) cacheData.get(cachRefKey);
		return cacheValue;
		}
	
	
	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	
	public void setFreedomRegDAOImpl(FreedomRegDAO freedomRegDAOImpl) {
		this.freedomRegDAOImpl = freedomRegDAOImpl;
	}

	
	public void setFreedomReqFormat(FreedomReqFormat freedomReqFormat) {
		this.freedomReqFormat = freedomReqFormat;
	}
	
}
