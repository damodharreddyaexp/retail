/*
 * NewAccountValidatorBP.java
 * Created on Dec 01, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 01, 2005 Sairam.T - Initial Creation
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.ApplyAccount;
import com.sbi.model.Request;
import com.sbi.utils.Constants;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

public class NewAccountValidatorBP extends RequestValidatorBP {

	private Validator validator;
	private RequestValidator requestValidator;
	protected final Logger logger = Logger.getLogger(getClass());

	ApplyAccount applyAccount;

	/**
	 * Call validator.getAccountSubType method Call to check the No Of
	 * ChequeLeaves for SA,CA,CC Accounts method Call
	 * validator.validateTransferTypes( method Call
	 * requestValidator.validateAmount method to check the numaric valid debit
	 * Amount method Call validator.validateTxnRights if debit and credit branch
	 * codes are different { call validator.validateTodaysTxnLimit method } if
	 * any one of the method throws Exception then throw SBIApplicationException
	 * else return true
	 * 
	 * @param request
	 * @return boolean
	 */

	public boolean validate(Request request) throws SBIApplicationException {

		logger.info("validate(Request request) "+ LoggingConstants.METHODBEGIN);

		ApplyAccount applyAccount = (ApplyAccount) request;
		boolean validateTransType = false;
		boolean validateAmount = false;
		boolean checkMultiplesOfHundreds = false;
		boolean validateDepositPeriod = false;
		
		if (applyAccount != null) {
		//	String debitAccount = validator.getAccountSubType(applyAccount.getDebitAcctNo());
            //  Changed for CR 1598
            //shanta
			String debitAccount = validator.getNewAccountSubType(applyAccount.getDebitAcctNo(),applyAccount.getBranchCode(),applyAccount.getUserName());
            logger.info("debitAccount :"+debitAccount);
            //  End of CR 1598
			if (debitAccount != null)
				validateTransType = validator.validateTransferTypes(debitAccount, applyAccount.getAccountCategory(),
																		Constants.PRINCIPLE);

			if (logger.isDebugEnabled()) {
				logger.debug("validateTransferTypes(String accountNo, String accountCategory ,String Principle ) method - true");
			}

			if (validateTransType == true) {
				validateAmount = requestValidator.validateAmount(applyAccount.getDebitAmount());
			}
          //sairam Added Here 07-02-2006
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount(Double debitAmount ) method - true");
			} 				
				
			if(validateAmount == true && applyAccount.getTypeAccount().equals("Recurring Deposit") ){
				checkMultiplesOfHundreds =requestValidator.checkMultiplesOfHundreds(applyAccount.getDebitAmount());
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("checkMultiplesOfHundreds(Float debitAmount ) method - true");
			} 
			if(checkMultiplesOfHundreds == true){
				//Added for CR 5140 by Devipriya
				//validateDepositPeriod = requestValidator.validateDepositPeriod(applyAccount.getMonths());
				validateDepositPeriod = requestValidator.validateDepositPeriod(applyAccount.getMonths(),applyAccount.getAccountCategory(),applyAccount.getTypeAccount());				
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("validateDepositPeriod(Float debitAmount ) method - true");
			} 
			
			//sairam Added Here 07-02-2006
			if (validateAmount == true) {
				//Modified by saravanan for bugs JAVA_MIG_12
				validator.validateTxnRights(applyAccount.getDebitAcctNo(),applyAccount.getDebitAcctBranchCode(), 
											applyAccount.getUserName(),8, new Integer(BPConstants.DEBIT_NO));
			}
			if (logger.isDebugEnabled()) { 
				logger.debug("validateTxnRights(String accountNo, String branchCode,String userName,Integer accessLevel) method - true");
			}

		} else {
			 SBIApplicationException.throwException(ErrorConstants.DATA_NULL_DESCRIPTION);
			 }
		logger.info("validate(Request request) " + LoggingConstants.METHODEND);
		return true;
	}

	/**
	 * Validator object injection done here
	 * 
	 * @param validator
	 * 
	 */
	public void setValidator(Validator validator) {

		this.validator = validator;
	}

	/**
	 * RequestValidator object injection done here
	 * 
	 * @param requestValidator
	 * 
	 */
	public void setRequestValidator(RequestValidator requestValidator) {
		this.requestValidator = requestValidator;
	}
	 

}
