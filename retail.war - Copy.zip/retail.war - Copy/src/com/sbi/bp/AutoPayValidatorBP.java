/*
 * AutoPayValidatorBP.java
 * Created on June 28, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//June 28, 2006 Saravanan N  - Initial Creation
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.ApplyAccount;
import com.sbi.model.Request;
import com.sbi.model.UserBillerMap;
import com.sbi.utils.Constants;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

public class AutoPayValidatorBP  {

	private Validator validator;
	protected final Logger logger = Logger.getLogger(getClass());
	
	/**
     * Call validator.validateTxnRights(accountNo,branchCode,userName,accessLevel) method and
     * get the Account Compare the input AccessLevel with Account Accesslevel If
     * the Account AccessLevel is greater than or equal to the input AccessLevel ,
     * return true Else throw Exception with message "Transaction rights is not
     * avilable for this Account"
     * 
     * @param accountNo
     * @param branchCode
     * @param userName
     * @param accessLevel
     * @return boolean
     */
	public boolean validate(UserBillerMap userBillerMap) throws SBIApplicationException {

		logger.info("validate(UserBillerMap userBillerMap)"+ LoggingConstants.METHODBEGIN);
		
		if (userBillerMap != null) {
				 validator.validateTxnRights(userBillerMap.getDebit_account_no(),userBillerMap.getDebit_branch_code(),
						 userBillerMap.getUserName(),new Integer(BPConstants.DEBIT_NO));
				 

			if (logger.isDebugEnabled()) {
				logger.debug("validateTxnRights(userBillerMap.getDebit_account_no(),userBillerMap.getDebit_branch_code(),"+
						" userBillerMap.getUserName(),new Integer(BPConstants.DEBIT_NO) method - true");
			}

		} else {
			 SBIApplicationException.throwException(ErrorConstants.DATA_NULL_DESCRIPTION);
			 }
		logger.info("validate(UserBillerMap userBillerMap)" + LoggingConstants.METHODEND);
		return true;
	}

	/**
	 * Validator object injection done here
	 * 
	 * @param validator
	 * 
	 */
	public void setValidator(Validator validator) {

		this.validator = validator;
	}

	
	 

}
