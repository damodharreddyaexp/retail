/* 
 * TransactionValidatorFactory.java
 * Created on Nov 8, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History 
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.UtilsConstant;
import com.sbi.powerjyothi.bp.PowerJyothiFundTransferValidatorBP;


public class TransactionValidatorFactory
{

    protected final Logger logger = Logger.getLogger(getClass());
    
    
    
    TransactionValidatorBP saralThirdPartyValidatorBP;
    TransactionValidatorBP saralFundsTransferValidatorBP;
    TransactionValidatorBP saralinterBankValidatorBP;

    TransactionValidatorBP fundsTransferValidatorBP;

    TransactionValidatorBP creditToPPFValidatorBP;

    TransactionValidatorBP demandDraftValidatorBP;

    TransactionValidatorBP thirdPartyValidatorBP;

    TransactionValidatorBP loanPartPaymentValidatorBP;
    
    TransactionValidatorBP indirectTaxesValidatorBP;//CR-1637
    
    TransactionValidatorBP relianceValidatorBP; // Rworld
    
    TransactionValidatorBP crisValidatorBP; // CRIS

    //Added by Aparna for VMT
    
    TransactionValidatorBP visaMoneyTransferValidatorBP;

	TransactionValidatorBP interBankValidator;// For RTGS/NEFT
	
	TransactionValidatorBP akshayaValidatorBP; // AKSHAYA
    
    TransactionValidatorBP makeDonationValidatorBP;//Make Donation Link
    
    TransactionValidatorBP ezTradeTransferValidatorBP;//Added for EZTrade
	
	TransactionValidatorBP suvidhaValidatorBP;//Added for e-Suvidha Link
	//added for e-TDR
    TransactionValidatorBP fixedDepositValidatorBP;
    
    TransactionValidatorBP recurringDepositValidatorBP;

	//added for Gift card
    TransactionValidatorBP giftCardFundTransferValidatorBP;
    
	//added for NPS
	TransactionValidatorBP debitUserAccountValidatorBP;
	
	// Added for Metro Topup
	TransactionValidatorBP  externalVendorRechargeValidatorBP;
    WuFundTransferValidatorBP wuFundTransferValidatorBP;//added by deva for western union
    

    //Added for SmartPayoutCard
    TransactionValidatorBP smartCardFundTransferValidatorBP;
    
    //Added for PrepaidPayoutCard
    TransactionValidatorBP prepaidCardFundTransferValidatorBP;
    
	PowerJyothiFundTransferValidatorBP pjFundTransferValidatorBP; // Added by Srinivas
	
	/*TransactionValidatorBP quickTransactionValidatorBP;  // Added by Anusha for Quick Transfer with starts
	
	public void setQuickTransactionValidatorBP(
			TransactionValidatorBP quickTransactionValidatorBP) {
		this.quickTransactionValidatorBP = quickTransactionValidatorBP;
	}*/
	
	TransactionValidatorBP quickTransactionValidatorCheckingBP;  
	



	public void setQuickTransactionValidatorCheckingBP(
			TransactionValidatorBP quickTransactionValidatorCheckingBP) {
		this.quickTransactionValidatorCheckingBP = quickTransactionValidatorCheckingBP;
	}
	// Added by Anusha for Quick Transfer with ends
	public static final String RWORLD = "MP";
    /**
     * Accept the txnName as input and according to that it will return
     * corresponding ValidatorBP instance
     * 
     * @param txnName
     * @return ValidatorBP
     */
    public TransactionValidatorBP getValidator(String txnName)
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("getValidator(String txnName) Begin -->txnName :" + txnName);
        }
       
            logger.info("getValidator(String txnName) Begin -->txnName :" + txnName);
        
        if (txnName != null && !txnName.trim().equalsIgnoreCase(BPConstants.EMPTY))
        {

            if (txnName.equalsIgnoreCase(BPConstants.FUND_TRANSFER))
                return fundsTransferValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.PPF))
                return creditToPPFValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.DEMAND_DRAFT))
                return demandDraftValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.THIRD_PARTY))
                return thirdPartyValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.LOAN_PART_PAYMENT)
                    || txnName.equalsIgnoreCase(BPConstants.LOAN_CLOSURE))
                return loanPartPaymentValidatorBP;
            else if (txnName.equalsIgnoreCase("IDP"))
                return indirectTaxesValidatorBP;
            else if (txnName.equalsIgnoreCase(TransactionValidatorFactory.RWORLD))
                return relianceValidatorBP;
            else if (txnName.equalsIgnoreCase("CRIS"))
                return crisValidatorBP;
            //Added by Aparna
            
            else if(txnName.equalsIgnoreCase("VMT"))
            	return visaMoneyTransferValidatorBP;
			//Added for RTGS/NEFT
            //IZ added for GRPT by Archana
			 else if (txnName.equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)||txnName.equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT))
                return interBankValidator;
			//Ended for RTGS/NEFT
			 else if (txnName.equalsIgnoreCase("AKSHAYA")) //Added for Akshaya payment
	               return akshayaValidatorBP;
             else if (txnName!=null && txnName.equalsIgnoreCase("MD")) //Added for Make Donation Link
                   return makeDonationValidatorBP;
             else if (txnName.equalsIgnoreCase("EZT")){
                 return ezTradeTransferValidatorBP;} //Added for EZTrade
             else if (txnName.equalsIgnoreCase("ETDR")){
                 return fixedDepositValidatorBP;} //Added for ETDR
              else if (txnName.equalsIgnoreCase(UtilsConstant.GIFT_CARD_TRANSACTION)){
                 return giftCardFundTransferValidatorBP;} //Added for Gift card
             else if (txnName!=null && txnName.equalsIgnoreCase("FEE")) //Added for e-Suvidha
                 return suvidhaValidatorBP;
             else if (txnName.equalsIgnoreCase("ERD")){
                 return recurringDepositValidatorBP;} //Added for eRD
			else if(txnName.equalsIgnoreCase("NPS") || txnName.equalsIgnoreCase("FOR")){
            	return debitUserAccountValidatorBP;} //Added for NPS changes
            else if (txnName.equalsIgnoreCase("EVCR")){ //Added for External Vendor card Recharge
                    return externalVendorRechargeValidatorBP;
              }else if (txnName!=null && "SBILIFE_INB".equalsIgnoreCase(txnName)){ //Added for SBI Life Insurance Premium
                    return debitUserAccountValidatorBP; }
		else if (txnName!=null && txnName.equalsIgnoreCase("WUT")){ // Added For Western Union Service
                 return wuFundTransferValidatorBP;
             }
		else if (txnName.equalsIgnoreCase(UtilsConstant.SMART_PAYOUT_CARD_TRANSACTION)){   //Added for Smart Payout card
            	 return smartCardFundTransferValidatorBP;} 
            
		else if (txnName.equalsIgnoreCase(UtilsConstant.PREPAID_PAYOUT_CARD_TRANSACTION)){   //Added for Prepaid Payout card
       	 return prepaidCardFundTransferValidatorBP;} 
  
            
		else if(txnName!=null && "POWER_JYOTHI".equalsIgnoreCase(txnName)) { // Added For Power Jyothi
            	 return pjFundTransferValidatorBP;
             }
            
            
            
		else  if (txnName.equalsIgnoreCase("CTsaral")){
			
			 return saralThirdPartyValidatorBP;
		}else  if (txnName.equalsIgnoreCase("CIsaral")){
			
			 return saralFundsTransferValidatorBP;
		}else if (txnName.equalsIgnoreCase("CNsaral")||txnName.equalsIgnoreCase("CRsaral")||txnName.equalsIgnoreCase("CZsaral"))
            return saralinterBankValidatorBP;
           //Added by Anusha for Quick Transfer with starts
		  else if (txnName.equalsIgnoreCase("QUCTXN")) 
             // return quickTransactionValidatorBP;
			  return quickTransactionValidatorCheckingBP;
            //Added by Anusha for Quick Transfer with ends

            else
            {
            	SBIApplicationException.throwException(ErrorConstants.TRANSACTION_NAME_NOT_VALID_ERROR_CODE);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
          }
        return null;
    }

    /**
     * FundsTransferValidatorBP injection
     * 
     * @param fundsTransferValidatorBP
     */
    public void setFundsTransferValidatorBP(TransactionValidatorBP fundsTransferValidatorBP)
    {
        this.fundsTransferValidatorBP = fundsTransferValidatorBP;
    }

    /**
     * CreditToPPFValidatorBP injection
     * 
     * @param creditToPPFValidatorBP
     */
    public void setCreditToPPFValidatorBP(TransactionValidatorBP creditToPPFValidatorBP)
    {
        this.creditToPPFValidatorBP = creditToPPFValidatorBP;
    }

    /**
     * DemandDraftValidatorBP injection
     * 
     * @param demandDraftValidatorBP
     */
    public void setDemandDraftValidatorBP(TransactionValidatorBP demandDraftValidatorBP)
    {
        this.demandDraftValidatorBP = demandDraftValidatorBP;
    }

    /**
     * ThirdPartyValidatorBP
     * 
     * @param thirdPartyValidatorBP
     */
    public void setThirdPartyValidatorBP(TransactionValidatorBP thirdPartyValidatorBP)
    {
        this.thirdPartyValidatorBP = thirdPartyValidatorBP;
    }

    /**
     * LoanPartPaymentValidatorBP injection
     * 
     * @param thirdPartyValidatorBP
     */
    public void setLoanPartPaymentValidatorBP(TransactionValidatorBP loanPartPaymentValidatorBP)
    {
        this.loanPartPaymentValidatorBP = loanPartPaymentValidatorBP;
    }

	public void setIndirectTaxesValidatorBP(
			TransactionValidatorBP indirectTaxesValidatorBP) {
		this.indirectTaxesValidatorBP = indirectTaxesValidatorBP;
	}

	public void setRelianceValidatorBP(TransactionValidatorBP relianceValidatorBP) {
		this.relianceValidatorBP = relianceValidatorBP;
	}

	public void setCrisValidatorBP(TransactionValidatorBP crisValidatorBP) { //CRIS
		this.crisValidatorBP = crisValidatorBP;
	}

	public void setVisaMoneyTransferValidatorBP(
			TransactionValidatorBP visaMoneyTransferValidatorBP) {
		this.visaMoneyTransferValidatorBP = visaMoneyTransferValidatorBP;
	}
    
	public void setInterBankValidator(TransactionValidatorBP interBankValidator) {
		this.interBankValidator = interBankValidator;

	}

	public void setAkshayaValidatorBP(TransactionValidatorBP akshayaValidatorBP) {
		this.akshayaValidatorBP = akshayaValidatorBP;
	}
	//Added for Make Donation Link

    public void setMakeDonationValidatorBP(TransactionValidatorBP makeDonationValidatorBP)
    {
        this.makeDonationValidatorBP = makeDonationValidatorBP;
    }

	public void setEzTradeTransferValidatorBP(
			TransactionValidatorBP ezTradeTransferValidatorBP) {
		this.ezTradeTransferValidatorBP = ezTradeTransferValidatorBP;
	}

	public void setFixedDepositValidatorBP(
			TransactionValidatorBP fixedDepositValidatorBP) {
		this.fixedDepositValidatorBP = fixedDepositValidatorBP;
	}
    
    
    //Make Donation Link - end
    
    public void setGiftCardFundTransferValidatorBP(
			TransactionValidatorBP giftCardFundTransferValidatorBP) {
		this.giftCardFundTransferValidatorBP = giftCardFundTransferValidatorBP;
	}
    //Suvidha link
	public void setSuvidhaValidatorBP(TransactionValidatorBP suvidhaValidatorBP) {
		this.suvidhaValidatorBP = suvidhaValidatorBP;
	}
    //Suvidha Link  -end

	public void setRecurringDepositValidatorBP(
			TransactionValidatorBP recurringDepositValidatorBP) {
		this.recurringDepositValidatorBP = recurringDepositValidatorBP;
	}

	public void setDebitUserAccountValidatorBP(
			TransactionValidatorBP debitUserAccountValidatorBP) {
		this.debitUserAccountValidatorBP = debitUserAccountValidatorBP;
	}
	//Added for Metro topup
	public void setExternalVendorRechargeValidatorBP(
			TransactionValidatorBP externalVendorRechargeValidatorBP) {
		this.externalVendorRechargeValidatorBP = externalVendorRechargeValidatorBP;
	}
	    public void setWuFundTransferValidatorBP(
			WuFundTransferValidatorBP wuFundTransferValidatorBP) {
		this.wuFundTransferValidatorBP = wuFundTransferValidatorBP;
	}

		public void setSmartCardFundTransferValidatorBP(
				TransactionValidatorBP smartCardFundTransferValidatorBP) {
			this.smartCardFundTransferValidatorBP = smartCardFundTransferValidatorBP;
		}
		
		public void setPrepaidCardFundTransferValidatorBP(
				TransactionValidatorBP prepaidCardFundTransferValidatorBP) {
			this.prepaidCardFundTransferValidatorBP = prepaidCardFundTransferValidatorBP;
		}

		public void setPjFundTransferValidatorBP(
				PowerJyothiFundTransferValidatorBP pjFundTransferValidatorBP) {
			this.pjFundTransferValidatorBP = pjFundTransferValidatorBP;
		}

		public void setSaralThirdPartyValidatorBP(
				TransactionValidatorBP saralThirdPartyValidatorBP) {
			this.saralThirdPartyValidatorBP = saralThirdPartyValidatorBP;
		}

		public void setSaralFundsTransferValidatorBP(
				TransactionValidatorBP saralFundsTransferValidatorBP) {
			this.saralFundsTransferValidatorBP = saralFundsTransferValidatorBP;
		}

		public void setSaralinterBankValidatorBP(
				TransactionValidatorBP saralinterBankValidatorBP) {
			this.saralinterBankValidatorBP = saralinterBankValidatorBP;
		}
		
		
}
