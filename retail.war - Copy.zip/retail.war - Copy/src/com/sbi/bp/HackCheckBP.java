package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;
import com.sbi.dao.BillDAO;
import com.sbi.dao.BillerMasterDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.PaymentScheduleDAO;
import com.sbi.dao.UserBillerMapDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.BillPaymentSchedule;
import com.sbi.model.UserBillerMap;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;
public class HackCheckBP {

	private UserBillerMapDAO userBillerMapDAOImpl;
	private BillerMasterDAO billerMasterDAOImpl;
    private PaymentScheduleDAO paymentScheduleDAOImpl;
    private BillDAO billDAOImpl;
	private Validator validator;
	protected final Logger logger = Logger.getLogger(getClass());
    
    
	public void validateAddBiller(String billerId,String userName)
	{
		logger.info("validateAddBiller(String billerId,String userName) "+LoggingConstants.METHODBEGIN);
		if(!userBillerMapDAOImpl.checkUserBillerMap(billerId,userName))
		{
			 SBIApplicationException.throwException(ErrorConstants.VALIDATE_CHECK_USER_BILLERMAP_ERROR_CODE);
		}
		logger.info("validateAddBiller(String billerId,String userName) "+LoggingConstants.METHODEND);
	}
	
	
	public void validateEditBiller(UserBillerMap userBillerMap,Integer accessLevel)
	{
		if(!billerMasterDAOImpl.checkBillerMasterDetails(userBillerMap.getBiller().getBillerID(),userBillerMap.getUserName()))
		{
		    SBIApplicationException.throwException(ErrorConstants.VALIDATE_CHECK_BILLER_MASTER_DETAILS_ERROR_CODE);
		}
	}
	
	
	public void validatePaySchBills(BillPaymentSchedule billPaymentSchedule, Integer accessLevel,String debitProductCode){
	//String billerId,String billNo,String userName,Double amount,String accountNo,String branchCode,Integer accessLevel)
		Date scheduledDate = new Date(); 
		if(validator.validateLimit(billPaymentSchedule.getAmount(),UtilsConstant.THIRD_PARTY,billPaymentSchedule.getDebitBranchCode().substring(0,1)))//CR-5023
		    if(paymentScheduleDAOImpl.checkPaymentSchedule(billPaymentSchedule.getBill().getBillerID(),billPaymentSchedule.getBill().getBillNo(),billPaymentSchedule.getUserName(),billPaymentSchedule.getAmount()))
			   if(validator.validateMinorMajorTxnRights(billPaymentSchedule.getDebitAccountNo(),billPaymentSchedule.getDebitBranchCode(),billPaymentSchedule.getUserName(),8,9))
				   validator.validateSubCategoryGroupAMinorLimit(billPaymentSchedule.getUserName(), billPaymentSchedule.getAmount(),scheduledDate,billPaymentSchedule.getDebitBranchCode().substring(0,1), "BillPayment", debitProductCode);
			   else
					SBIApplicationException.throwException("SE067");
		    else
                SBIApplicationException.throwException(ErrorConstants.VALIDATE_CHECK_PAYMENT_SCHEDULE_ERROR_CODE);
	}
	
	public void validatePayWithBills(BillPaymentSchedule billPaymentSchedule,Integer accessLevel,String debitProductCode)
	{
		Date scheduledDate = new Date(); 
		if(billPaymentSchedule != null){
			if(validator.validateLimit(billPaymentSchedule.getAmount(),UtilsConstant.THIRD_PARTY,billPaymentSchedule.getDebitBranchCode().substring(0,1)))//CR-5023
				if(billDAOImpl.checkBillExists(billPaymentSchedule.getUserName(),billPaymentSchedule.getBill().getBillerID(),billPaymentSchedule.getBill().getBillNo(),billPaymentSchedule.getAmount()))
					if(validator.validateMinorMajorTxnRights(billPaymentSchedule.getDebitAccountNo(),billPaymentSchedule.getDebitBranchCode(),billPaymentSchedule.getUserName(),8,9))
						validator.validateSubCategoryGroupAMinorLimit(billPaymentSchedule.getUserName(), billPaymentSchedule.getAmount(),scheduledDate,billPaymentSchedule.getDebitBranchCode().substring(0,1), "BillPayment", debitProductCode);
					else
						SBIApplicationException.throwException("SE067");
				else
					SBIApplicationException.throwException(ErrorConstants.VALIDATE_CHECK_BILL_EXISTS_ERROR_CODE);
		}else{
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
	}
	
	public void validatePayWithOutBills(BillPaymentSchedule billPaymentSchedule, Integer accessLevel,String debitProductCode)
	//String userName,String billerId,String accountNo,String branchCode,Integer accessLevel,Double amount)
	{
		Date scheduledDate = new Date(); 
	    if(validator.validateLimit(billPaymentSchedule.getAmount(),UtilsConstant.THIRD_PARTY,billPaymentSchedule.getDebitBranchCode().substring(0,1)))//CR-5023
			if(userBillerMapDAOImpl.checkUserBillerMapForWithoutBill(billPaymentSchedule.getUserName(),billPaymentSchedule.getBill().getBillerID()))
                if(validator.validateMinorMajorTxnRights(billPaymentSchedule.getDebitAccountNo(),billPaymentSchedule.getDebitBranchCode(),billPaymentSchedule.getUserName(),8,9))
                		validator.validateSubCategoryGroupAMinorLimit(billPaymentSchedule.getUserName(), billPaymentSchedule.getAmount(),scheduledDate,billPaymentSchedule.getDebitBranchCode().substring(0,1), "BillPayment", debitProductCode);
                else
					SBIApplicationException.throwException("SE067");
			else
				SBIApplicationException.throwException(ErrorConstants.VALIDATE_CHECKUSER_BILLERMAP_WITHOUR_BILL_ERROR_CODE);
    }


	public void setUserBillerMapDAOImpl(UserBillerMapDAO userBillerMapDAOImpl) {
		this.userBillerMapDAOImpl = userBillerMapDAOImpl;
	}

	public void setBillerMasterDAOImpl(BillerMasterDAO billerMasterDAOImpl) {
		this.billerMasterDAOImpl = billerMasterDAOImpl;
	}
	
	 public void setValidator(Validator validator)
	    {
	        this.validator = validator;
	    }


    /**
     * @param billDAOImpl The billDAOImpl to set.
     */
    public void setBillDAOImpl(BillDAO billDAOImpl)
    {
        this.billDAOImpl = billDAOImpl;
    }


    /**
     * @param paymentScheduleDAOImpl The paymentScheduleDAOImpl to set.
     */
    public void setPaymentScheduleDAOImpl(PaymentScheduleDAO paymentScheduleDAOImpl)
    {
        this.paymentScheduleDAOImpl = paymentScheduleDAOImpl;
    }

	 

	
}
