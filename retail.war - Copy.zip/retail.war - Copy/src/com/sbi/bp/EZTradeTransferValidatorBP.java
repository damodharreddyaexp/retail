
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class EZTradeTransferValidatorBP extends TransactionValidatorBP{



    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;   
   

    public boolean validate(Transaction transaction)
            throws SBIApplicationException {
        this.transaction = transaction;
        if (transaction != null) {
            logger.info("validate(Transaction transaction) "
                    + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled()) {
                logger.debug("transaction :" + transaction.toString());
            }
           
            validator.validateAmount(transaction.getDebit().getAmount());
            if (logger.isDebugEnabled()) {
                logger.debug("validateAmount() return true");
            }
      
           
            validator.validateEZTradeTransaction(transaction.getDebit().getUserName(), transaction.getDebit().getAccountNo(), transaction.getDebit().getProductType(),transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo());
           
            if (logger.isDebugEnabled()) {
                logger.debug("validateEZTradeTransaction(String userName, String debitAccountNo,String creditAccountNo) method - true");
            }
            //method added to validate user define limit CR 5076
          validator.validateEZTradeUserTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getBankCode());
            if (logger.isDebugEnabled()) {
                logger
                        .debug("validateEZTradeUserTxnLimit(String userName, Double amount) method - true");
            }          
                  
                       
            validator.validateEZTradeTodaysTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getBranchCode(),transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),transaction.getBankCode(),transaction.getDebit().getAmount());
            if (logger.isDebugEnabled()) {
                logger.debug("validateEZTradeTodaysTxnLimit(String userName,String bankCode,Double amount) method - true");
            }       
            
            

        } else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return true;
    }

    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }  
    


}
