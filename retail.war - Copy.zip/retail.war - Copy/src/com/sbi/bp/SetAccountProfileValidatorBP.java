/*
 * SetAccountProfileValidatorBP.java
 * Created on Sep 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Sep 18, 2006 MAHESH  - Initial Creation   Created for CR 1201
package com.sbi.bp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.AccountDAO;
import com.sbi.dao.DAOConstants;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.ApplyAccount;
import com.sbi.model.Request;
import com.sbi.model.UserBillerMap;
import com.sbi.utils.Constants;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

public class SetAccountProfileValidatorBP  {

	private Validator validator;
    private AccountDAO accountDAOImpl;
	protected final Logger logger = Logger.getLogger(getClass());
	
	public boolean validate(List accountList,String strSetAccProfileType) throws SBIApplicationException {

		logger.info("validate(List accountList)"+ LoggingConstants.METHODBEGIN);
         if (accountList.size()>0){
             for (int i = 0; i < accountList.size(); i++) {
                 Account account = (Account) accountList.get(i);
                 if (logger.isDebugEnabled()) {
                     logger.debug("account :" + account);
                 }
                 validator.validateAccOwnership(account.getAccountNo(),account.getBranchCode(),account.getUserName(),
                         new Integer("0"),strSetAccProfileType);               
                
             }
         }		
		
		logger.info("validate(List accountList)" + LoggingConstants.METHODEND);
		return true;
	}
    
    public Map getAccountsSetForAutopay(String userName,List accountList){
        
        logger.info("getAccountsSetForAutopay(String userName)"+LoggingConstants.METHODBEGIN);
        List accountSetForAutopay = null;
        List returnAccountList = new ArrayList();
        Map accountMap = new HashMap();
        accountSetForAutopay = accountDAOImpl.findAccountSetForAutopay(userName,accountList);
        
        
        if(accountSetForAutopay==null){
            logger.info("getAccountsSetForAutopay(String userName)"+LoggingConstants.METHODEND);
            return null;
        }else{
            for(int i=0;i<accountSetForAutopay.size();i++){                
                Account autopayAcc = (Account)accountSetForAutopay.get(i);
                
                for(int count=0;count<accountList.size();count++){                    
                    Account acc = (Account)accountList.get(count);
                    
                    if (acc.getAccountNo().equalsIgnoreCase(autopayAcc.getAccountNo()) && acc.getBranchCode().equalsIgnoreCase(autopayAcc.getBranchCode())){
                        returnAccountList.add(acc);
                        accountList.remove(count);
                        accountSetForAutopay.remove(i);                    
                        count--;                     
                        i--;                        
                    
                    }                  
                    
                }
                accountMap.put("newAccountList",accountList);
                accountMap.put("accountSetForAutopay",returnAccountList);
                
            }
            logger.info("getAccountsSetForAutopay(String userName)"+LoggingConstants.METHODEND);
            return accountMap;
        }
    }

	
	public void setValidator(Validator validator) {

		this.validator = validator;
	}

    public void setAccountDAOImpl(AccountDAO accountDAOImpl)
    {
        this.accountDAOImpl = accountDAOImpl;
    }

}
