/*
 * IndirectTaxesValidatorBP.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2006 SARAVANAN - Initial Creation

package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class IndirectTaxesValidatorBP extends TransactionValidatorBP
{

    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;

    /**
     * Call validator.validateAmount() method Call for validating amount
     * validator.validateCBECTodaysTxnLimit method for validating today txn amount
     * 
     * @param transaction
     * @return boolean
     */
    public boolean validate(Transaction transaction) throws SBIApplicationException
    {

        this.transaction = transaction;
        if (transaction != null)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN +"transaction :" + transaction.toString());
            }
            validator.validateAmount(transaction.getDebit().getAmount());
            
            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
//          changed for CR2655 CBEC Cutoff by Archana
            validator.validateCBECTodaysTxnLimit(transaction.getDebit().getUserName(), transaction.getDebit().getAmount(),transaction.getScheduledDate());
            if (logger.isDebugEnabled())
            {
            	logger.debug("validate(Transaction transaction) " + LoggingConstants.METHODEND);
            }

          
            //logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
          

        }
        else
        { 
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return true;
    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }


}
