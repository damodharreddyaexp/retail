package com.sbi.bp;

import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Name;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.axis.message.MessageElement;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.sbi.service.ServiceConstant;
import com.sbi.utils.AESEncrypt;
import com.sbi.utils.ChecksumMD5;

import com.sbi.SBIL_Registration_pkg.SBIL_RegistrationSoapStub;
import com.sbi.dao.AccountDAO;
import com.sbi.dao.CoreDAO;
import com.sbi.dao.SBIGroupServicesDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.SBIGroupServiceModel;
import com.sbi.utils.StringUtils;
import com.sbi.wsclient.mf.RegistrationMFResponseRegistrationMFResult;
import com.sbi.wsclient.mf.ServiceSoap;
import com.sbi.wsclient.mf.ServiceSoapProxy;


public class SBIGroupServicesBP {
	
	protected final static Logger logger = Logger.getLogger(SBIGroupServicesBP.class);
	private CoreDAO coreDAOImpl;	
	private SBIGroupServicesDAO sbiGroupServicesDAOImpl;
	private AccountDAO accountDAOImpl;

	public Map getCustomerDetails(Map inParam) {
		logger.info("getCustomerDetails(Map inParam) begins Here");
		Map responseMap = null;
		try {
			List CIFNumbersList = new ArrayList();
			CIFNumbersList = sbiGroupServicesDAOImpl.findUserDetails(inParam);
			if(CIFNumbersList!=null && CIFNumbersList.size()>0) {
				responseMap=(Map)CIFNumbersList.get(0);
			}
		}
		catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("getCustomerDetails(Map inParam) ends");
		return responseMap;
	}	
	public List construct60459Request(Map inParams) throws SBIApplicationException {
		logger.info("construct60459Request(Map inParams) begins");
		Map enquiryMap = new HashMap();
		enquiryMap.put("txnno", "060459");
		enquiryMap.put("bankCode", ((String)inParams.get("bankCode")));
		enquiryMap.put("Customer_Number",((String)inParams.get("cifNumber")));
		/*Changes for new PAN response 060459*/
		String bankCodes = "0|A|6|3";
		String bankCode=(String)inParams.get("bankCode");
		if(null!=bankCode && bankCodes.contains(bankCode)){
			enquiryMap.put("fetch_indicator","S");
			logger.info("FETCH_INDICATOR S is added");
		}
		List requestToCore = postToCore(enquiryMap);		
		logger.info("construct60459Request(Map inParams) ends");
		return requestToCore;
	}
	
	public List getAccounts(Map inParam) {
		logger.info("getAccounts(Map inParam) begins Here");
		List accounts = new ArrayList();
		try {
			String userName = (String) inParam.get(ServiceConstant.USER_NAME);
			String[] productType = (String[]) inParam
					.get(ServiceConstant.PRODUCT_TYPE);
			Integer accessLevel = new Integer(
					(String) inParam.get(ServiceConstant.ACCESS_LEVEL));
			accounts = accountDAOImpl.findAccounts(userName, productType,
					accessLevel);
		} catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(),
					daoExc);
		}
		logger.info("accountDAOImpl.findAccounts " + accounts);
		logger.info("getAccounts(Map inParam) ends");
		return accounts;
	}

	public SBIGroupServiceModel populate60459Response(SBIGroupServiceModel model, Map inParams) {
		

		logger.info("populate60459Response(SBIGroupServiceModel model, Map inParams) begins");
		if((String)inParams.get("Customer Name")!=null && ((String)inParams.get("Customer Name")).length()>0) {
			model.setCustomerName((String)inParams.get("Customer Name"));
		}else {
			model.setCustomerName(" ");
		}
		if((String)inParams.get("Customer Number")!=null && ((String)inParams.get("Customer Number")).length()>0) {
			model.setCustomerNumber((String)inParams.get("Customer Number"));
		}else {
			model.setCustomerNumber(" ");
		}		
		if((String)inParams.get("Pan_No_S")!=null && ((String)inParams.get("Pan_No_S")).length()>0) {
			model.setPanNumber((String)inParams.get("Pan_No_S"));
		}else {
			//SBIApplicationException.throwException("SGS002");
			model.setPanNumber("");
		}
		
		if((String)inParams.get("DOB_S")!=null && ((String)inParams.get("DOB_S")).length()>0 && !"00000000".equals((String)inParams.get("DOB_S"))) {
			String convert2DateString = StringUtils.convertDateStringFormat((String)inParams.get("DOB_S"));
			model.setDob(convert2DateString);			
		}else {
			//SBIApplicationException.throwException("SGS001");
			model.setDob("");
		}
		
		logger.info("populate60459Response(SBIGroupServiceModel model, Map inParams) ends");
		return model;
	}	
	public List postToCore(Map requestMap){
		logger.info("postToCore(Map requestMap) method begins");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			if(status!=null && ("F1".equals(status)) || ("F2".equals(status))) {
				SBIApplicationException.throwException("F1");
			}else if(status!=null && "ERR.".equals(status)) {                	 
				SBIApplicationException.throwException("PJ009");
			}
		}
		logger.info("postToCore(Map requestMap) ends");
		return responseList;
	}
	public String constructServiceRequest(Map inParams, String aesKey) {
		logger.info("constructServiceRequest(Map inParams) method begins");
		String policyNumber = (String)inParams.get("policyNumber");
		String pan = (String)inParams.get("pan");
		String dob = (String)inParams.get("dob");
		String inbRegno = (String)inParams.get("refNo");
		//String finalString = "policyNumber="+policyNumber+"|pan_no="+pan+"|dob="+dob;
		String xmlString = covertToXMLString(policyNumber, pan, dob, inbRegno); 
		//String finalString="<?xml version=\"1.0\" encoding=\"utf-8\"?><REGISTRATIONDETAILS><POLICYNUMBER>55001944108</POLICYNUMBER><PANNO>BNIPK4565Y</PANNO><DOB>03-MAY-63</DOB><INBREGNO>123456789</INBREGNO></REGISTRATIONDETAILS>";
		String checksum=getMD5Hash(xmlString);
		logger.info("checksum :::: "+checksum);
		String finalString = xmlString+"|checksum="+checksum;
		System.out.println("finalString : "+finalString);
		String encString = encrypt(finalString, aesKey);
		encString = encString.replaceAll("\n", "");
		encString = encString.replaceAll("\r", "");
		logger.info("constructServiceRequest(Map inParams) method ends");
		return encString;
	}

	public String constructServiceRequestForMF(Map inParams, String mfaesKey) {
		logger.info("constructServiceRequestMF(Map inParams) method begins");
		String folioNumber = (String) inParams.get("folioNumber");
		String pan = (String) inParams.get("pan");
		String dob = (String) inParams.get("dob");
		String bankAcNo = (String) inParams.get("accountNumber");
		//String bankAcNo="00000020099633870";
		String inbRegno = (String) inParams.get("refNo");
		String pipeString = covertToPIPEString(folioNumber, pan, bankAcNo,
				inbRegno);
		//pipeString = "FolioNo=6024519|PanNo=ADQPV6142B|BankAccNo=33928|INBRegNo=123456789";
		String checksum = getMD5Hash(pipeString);
		logger.info("checksum :::: " + checksum);
		String finalString = pipeString + "|checkSum= " + checksum;
		logger.info("pipeString : " + finalString);
		
		String encString = encrypt(finalString, mfaesKey);
		encString = encString.replaceAll("\n", "");
		encString = encString.replaceAll("\r", "");
		logger.info("constructServiceRequestMF(Map inParams) method ends");
		return encString;
	}

	public Map postWebServiceRequest(String requestString,  Map inParam,String aesKey) {
		logger.info(" SBI Life Web Service : postWebServiceRequest(String requestString) method begins");
		Map responseMap = null;
		try {
         /* SBIL_RegistrationSoapStub stub=new SBIL_RegistrationSoapStub(new URL("http://10.1.102.34/SBIL_Registration.asmx"),null);
			logger.info("stub :: "+stub.toString());
			//add SOAP header for authentication
			SOAPHeaderElement authentication = new SOAPHeaderElement("http://10.1.102.34/SBIL_Registration.asmx","AuthenticationHeader");
			SOAPHeaderElement user = new SOAPHeaderElement("http://10.1.102.34/SBIL_Registration.asmx","serviceId", "ONLINESBI");
			SOAPHeaderElement password = new SOAPHeaderElement("http://10.1.102.34/SBIL_Registration.asmx","ServicePassword", "onlinesbi@123");
			authentication.addChild(user);
			authentication.addChild(password);
			
			
            HashMap requestHeaders=new HashMap();			
			requestHeaders.put(new QName("http://SBIL_Registration/","AuthenticationHeader","s"),"<AuthenticationHeader><serviceId>ONLINESBI</serviceId><ServicePassword>onlinesbi@123</ServicePassword></AuthenticationHeader>");
			QName qname = new QName("SBILRegister");
			logger.info("localpart : "+qname.getLocalPart());
			logger.info("prefix : "+qname.getPrefix());
			logger.info("namespace : "+qname.getNamespaceURI());
			requestHeaders.put(new QName("com.rotbank.security", "AtmUuid2"),
					((IBMSOAPFactory)SOAPFactory.newInstance()).createElementFromXMLString("x:AtmUuid2 xmlns:x=\"com.rotbank.security\"><x:uuid>ROTB-0A01254385FCA09</x:uuid><x:AtmUuid2>"));
			
			requestHeaders.put(new QName("http://SBIL_Registration", "AuthenticationHeader"),
					((IBMSOAPFactory)SOAPFactory.newInstance()).createElementFromXMLString("s:AuthenticationHeader xmlns:s=\"http://www.w3.org/2001/XMLSchema\"><s:serviceId>ONLINESBI</s:serviceId><s:ServicePassword>onlinesbi@123</s:ServicePassword></s:AuthenticationHeader>"));
			
			
			logger.info("requestHeaders :: "+requestHeaders);
		 	stub._setProperty(Constants.REQUEST_SOAP_HEADERS,requestHeaders);
			
			
			
			SBILRegister obj =new SBILRegister();			
			obj.setStrInputXML(requestString);
			logger.info("requestString :: "+requestString);
			//"brJ+xXT8o5LvkcYrC3kWDjE/z24K9tHR1MrfcSxk7jv4UpLuw5prcBA2MI7/EcFugp/dt1Ewi4LRhvxnQyvsIdvrtp/pLuptrGTa4dLQ6FWEvbfMlmBlsOntQvkS8GSLYpPLwcuU2sZtFS0wC1k64EFaWbCLK8Aa5g05F5ssIrMdVUn8vWmmTX8I6fxxMmVlUoV1p/+0HnQp0FNV3ozGLjjyJR1sm9IGu/rFard3/qHFFeR1rD670ReqW+DpFvcexsLUuKxJV8RsPocRd0oflwzdozN9RoUAjE00MGIsR0MBHXPYMw6XN3hsRT4OOo3N"
			SBILRegisterResponse responseString =stub.SBILRegister(obj);
		    System.out.println("responseString :: "+responseString.getSBILRegisterResult());*/
			
			//SBIL_RegistrationSoapStub stub = new SBIL_RegistrationSoapStub(new URL("http://10.1.102.34/SBIL_Registration.asmx"),null);  //dev
			/*SBIL_RegistrationSoapStub stub = new SBIL_RegistrationSoapStub(new URL("http://10.1.102.43/SBIL_Registration.asmx"),null);    // production 
			//add SOAP header for authentication
			SOAPHeaderElement authentication = new SOAPHeaderElement("http://SBIL_Registration/","AuthenticationHeader");
			SOAPHeaderElement user = new SOAPHeaderElement("http://SBIL_Registration/","serviceId", "ONLINESBI");
			SOAPHeaderElement password = new SOAPHeaderElement("http://SBIL_Registration/","ServicePassword", "onlinesbi@123");*/
			
			logger.info("---------------SBI Life Url---------:"+inParam.get("sbiLifeWSURL").toString());
			logger.info("---------------SBI Life Service---------:"+inParam.get("sbiLifeService").toString());
			logger.info("---------------SBI Life Password---------:"+inParam.get("sbiLifePwd").toString());
			
			SBIL_RegistrationSoapStub stub = new SBIL_RegistrationSoapStub(new URL(inParam.get("sbiLifeWSURL").toString()),null);    // production 
			//add SOAP header for authentication
			SOAPHeaderElement authentication = new SOAPHeaderElement("http://SBIL_Registration/","AuthenticationHeader");
			SOAPHeaderElement user = new SOAPHeaderElement(inParam.get("sbiLifeService").toString(),null);
			SOAPHeaderElement password = new SOAPHeaderElement(inParam.get("sbiLifePwd").toString(),null);
			
			
			authentication.addChild(user);
			authentication.addChild(password);		
			stub.setHeader(authentication);
			String responseString = stub.SBILRegister(requestString);			
			logger.info(" SBI Life Web Service : ResponseString :: "+responseString);			
			String decString = decrypt(responseString, aesKey);
			logger.info(" SBI Life Web Service : After decryption :: "+decString);
			String[] splitChecksum = decString.split("\\|");	
			logger.info("SBI Life Web Service : splitChecksum :: "+splitChecksum);
			responseMap = parseXmlString2Map(splitChecksum[0]);		
		} catch (Exception e) {
			logger.info("Exception occured while posting the request... SBI Life Web Service : ",e);
			e.printStackTrace();
			responseMap = null;
		}
		logger.info(" SBI Life Web Service : postWebServiceRequest(String requestString) method ends");
		return responseMap;
	}
	
	/*public Map postWebServiceRequestForLIFE(String requestString, Map inParam) {
		logger.info("===========SBI LIFE WEBSERVICE Before Connecting=====postWebServiceRequestForLIFE(String requestString) method begins");
		Map responseMap = null;
		try {
		 	//mfAESKey,sbiMFWStargetEndpoint,sbiMFWSServiceID,sbiMFWSPwd
			//String endPoingURL="http://10.0.251.83/SBIOneViewMF/service.asmx";
			String endPoingURL=inParam.get("sbiLifeWSURL").toString();
			logger.info("==================End point URL=================:"+endPoingURL);
			ServiceSoap stub=new ServiceSoapProxy(endPoingURL).getServiceSoap();
			RegistrationMFResponseRegistrationMFResult obj =stub.registrationMF(requestString, inParam.get("sbiLifeService").toString(), inParam.get("sbiLifePwd").toString());
			MessageElement [] resss=obj.get_any();
			String response=resss[0].toString();
			String responseName=resss[0].getName();
			logger.info("==========SBI LIFE WS Response Type===========:"+responseName);
			if("Encdata".equalsIgnoreCase(responseName)){
			logger.info("=====SBI LIFE WS Encrypted Response String ==============:"+response);
			int length=response.length();
			String finalString=(response.substring(18, (length-10)));
			logger.info("=========SBI MF WS Final String========::"+finalString);
			String decString = SBIGroupServicesBP.decrypt(finalString, inParam.get("mfAESKey").toString());
			//String decString="FolioNo = 13627577|PanNo = BUQPS3847C|BankAccNo = 0511123656|INBRegno = 123456789|Status = Registration successful|checkSum = c3f095b90ff8760bf83e831e3f6d4260";
			logger.info("After SBI MF WS Decrypted Response String :"+decString);
			//String finalString = decrypt(om.getText(), inParam.get("mfAESKey").toString());
			responseMap = decriptionToString(decString);
			responseMap.put("errorcode", "00000");
			return responseMap;
			}else if("Return_msg".equalsIgnoreCase(responseName)){
			responseMap.put("errorcode", "MFWS002");
			}
		} catch (Exception e) {
			logger.info(
					"Exception occured while posting the request.to SBI MF fund.. "+e.getMessage());
			responseMap.put("errorcode", "MFWS002");
			logger.info("postWebServiceRequestForMF(String requestString) ERROR While connecting SBI MF WS");	
			return responseMap;
		}
		logger.info("postWebServiceRequestForMF(String requestString) method ends");
		return responseMap;
	}*/
	
	
	
	

	public Map postWebServiceRequestForMF(String requestString, Map inParam) {
		logger.info("===========SBI MF WEBSERVICE Before Connecting=====postWebServiceRequestForMF(String requestString) method begins");
		Map responseMap = null;
		try {
		 	//mfAESKey,sbiMFWStargetEndpoint,sbiMFWSServiceID,sbiMFWSPwd
			//String endPoingURL="http://10.0.251.83/SBIOneViewMF/service.asmx";
			String endPoingURL=inParam.get("sbiMFWStargetEndpoint").toString();
			logger.info("==================End point URL=================:"+endPoingURL);
			ServiceSoap stub=new ServiceSoapProxy(endPoingURL).getServiceSoap();
			RegistrationMFResponseRegistrationMFResult obj =stub.registrationMF(requestString, inParam.get("sbiMFWSServiceID").toString(), inParam.get("sbiMFWSPwd").toString());
			MessageElement [] resss=obj.get_any();
			String response=resss[0].toString();
			String responseName=resss[0].getName();
			logger.info("==========SBI MF WS Response Type===========:"+responseName);
			if("Encdata".equalsIgnoreCase(responseName)){
			logger.info("=====SBI MF WS Encrypted Response String ==============:"+response);
			int length=response.length();
			String finalString=(response.substring(18, (length-10)));
			logger.info("=========SBI MF WS Final String========::"+finalString);
			String decString = SBIGroupServicesBP.decrypt(finalString, inParam.get("mfAESKey").toString());
			//String decString="FolioNo = 13627577|PanNo = BUQPS3847C|BankAccNo = 0511123656|INBRegno = 123456789|Status = Registration successful|checkSum = c3f095b90ff8760bf83e831e3f6d4260";
			logger.info("After SBI MF WS Decrypted Response String :"+decString);
			//String finalString = decrypt(om.getText(), inParam.get("mfAESKey").toString());
			responseMap = decriptionToString(decString);
			responseMap.put("errorcode", "00000");
			return responseMap;
			}else if("Return_msg".equalsIgnoreCase(responseName)){
			responseMap.put("errorcode", "MFWS002");
			}
		} catch (Exception e) {
			logger.info(
					"Exception occured while posting the request.to SBI MF fund.. "+e.getMessage());
			responseMap.put("errorcode", "MFWS002");
			logger.info("postWebServiceRequestForMF(String requestString) ERROR While connecting SBI MF WS");	
			return responseMap;
		}
		logger.info("postWebServiceRequestForMF(String requestString) method ends");
		return responseMap;
	}
	private Map parseXmlString2Map(String decString) {
		logger.info("parseXmlString2Map(String decString) method begins"+decString);
		Map responseMap = null;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;		
		try {
			responseMap = new HashMap();
		    db = dbf.newDocumentBuilder();
		    InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(decString));		    
	        Document doc = db.parse(is);
	        Element rootElement = doc.getDocumentElement();
	        NodeList childNodes = rootElement.getChildNodes();
	        for(int i=0;i<childNodes.getLength();i++){
	        	Node tmp = childNodes.item(i);
	        	NodeList nodeList = tmp.getChildNodes();	        	
	        	for(int j = 0; j<nodeList.getLength();j++){
	        		Node tmp1 = nodeList.item(j);
	        		responseMap.put(tmp.getNodeName(), tmp1.getNodeValue());
	        	}	        	
	        }
	        //System.out.println("responseMap.. "+responseMap);
	        logger.info("responseMap ::: "+responseMap);
		} catch (Exception e) {
			logger.error("Exception occured while parsing XML... ", e);
			responseMap=null;
		}
		logger.info("parseXmlString2Map(String decString) method ends");
		return responseMap;
	}
private Map decriptionToString(String decString) {
		logger.info("decriptionToString(String decString) method begins"
				+ decString);
		StringTokenizer finalString = null;
		Map responseMap = null;
		if ((!(decString == null)) || "".equals(decString))
			finalString = new StringTokenizer(decString, "|");
		String key = null;
		String value = null;
		responseMap = new HashMap();
		while (finalString.hasMoreElements()) {
			String keyValueString = finalString.nextElement().toString();
			int i = 0;
			for (String retval : keyValueString.split("=")) {
				i++;
				if (i == 1)
					key = retval.trim();
				if (i == 2)
					value = retval.trim();
			}

			responseMap.put(key, value);

		}
		logger.info("response key Status::" + responseMap.get("INBRegNo"));
		logger.info("=============response key Status===================::" + responseMap.get("Status"));
		logger.info("decriptionToString(String decString) method ends");
		return responseMap;
	}
	public void insertUserDetails(Map inParams) {
		logger.info("insertUserDetails(Map inParams) method begins");
		try {
			int count = sbiGroupServicesDAOImpl.insertUserDetails(inParams);			
		} catch (DAOException daoe) {
			throw new SBIApplicationException("SE002");
		}
		logger.info("insertUserDetails(Map inParams) method ends");		
	}
	public String getReference(){
		String reference=null;
		try{
			reference = sbiGroupServicesDAOImpl.getReferenceNo();
		}catch (DAOException daoException){
            	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
        }
		return reference;
	}
	public List getServicesForUser(Map inParams) {
		logger.info("getServicesForUser(Map inParams) method begins");
		String userName = (String) inParams.get("userName");
		//String bankCode = (String) inParams.get("bankCode");
		List groupServicesList = sbiGroupServicesDAOImpl.getGroupServices(userName);
		logger.info("getServicesForUser(Map inParams) method ends");
		return groupServicesList;
	}
	public static String encrypt(String data, String filePath) {
		logger.info("encrypt(String data, String filePath) method begins");
        AESEncrypt enc = new AESEncrypt(); 
        enc.setSecretKey(filePath);        
        String encData = null;
        try {
              data = URLDecoder.decode(data, "utf-8");
              encData = enc.encryptFile(data);
        } catch (Exception ex) {
              logger.error("Exception occured :" +ex);
        }
        //System.out.println("encData ::: "+encData);   
        encData = encData.replaceAll("\n", "");
        encData = encData.replaceAll("\r", "");
        logger.info("encData ::: "+encData);
		logger.info("encrypt(String data, String filePath) method ends");
        return encData;		
	}
	public static String decrypt(String encData, String filePath) {
		logger.info("decrypt(String encData, String filePath) method begins");
		AESEncrypt enc = new AESEncrypt();
		enc.setSecretKey(filePath);
        String decData = null;
        try {
              //encData = URLDecoder.decode(encData, "UTF-8");
        } catch (Exception ex) {
              logger.error("Exception occured :" + ex);
        }
        decData = enc.decryptFile(encData);
        logger.info("decData :: "+decData);
       // System.out.println("decData :: "+decData);
		logger.info("decrypt(String encData, String filePath) method ends");
        return decData;
		
	}
	//For test
	/*public String constructServiceRequest() {
		logger.info("constructServiceRequest(Map inParams) method begins");
		String policyNumber = (String)inParams.get("policyNumber");
		String pan = (String)inParams.get("pan");
		String dob = (String)inParams.get("dob");
		//String finalString = "policyNumber="+policyNumber+"|pan_no="+pan+"|dob="+dob;
		
		String finalString="<?xml version=\"1.0\" encoding=\"utf-8\"?><REGISTRATIONDETAILS><POLICYNUMBER>55001944108</POLICYNUMBER><PANNO>BNIPK4565Y</PANNO><DOB>03-MAY-63</DOB><INBREGNO>123456789</INBREGNO></REGISTRATIONDETAILS>";
//		||checksum=48cc66cdd4787bfc1a30efdc6c6502c6
//		||checksum=7a781e7ac7434dce4e466ed3a6aee805
		String checksum=getMD5Hash(finalString);
		System.out.println("checksum :: "+checksum);
		checksum="7a781e7ac7434dce4e466ed3a6aee805";
		String encString = encrypt(finalString, "/opt/bv1to1/CLASSES/RET_SBILIFE.key");
		encString="brJ+xXT8o5LvkcYrC3kWDjE/z24K9tHR1MrfcSxk7jveiMqpNJyzvwETHGO19jYOg0zjaFj7+DOtm9fmvl6M1XeN5n46MoFifz7d2+Wjz4Qt+hHJD/DDS64dv8Ci6qlp4A3QQZCJpNxCm5bBn6vRc6gN9j9KuCQod4VeFXLcxh/4uMkTh+L/RJmaM5pNC66BcpNWtcPf/ZHEdpMx4UIgL1u7FhNs/FoPLg/JQik11TjLvpLP8IX0nnh2vCox4LkCrAbBEE10VEeAL/KizeF/dw==";
		String decString = decrypt(encString, "/opt/bv1to1/CLASSES/RET_SBILIFE.key");
		
		logger.info("checksum :::: "+checksum);
		logger.info("SBI Group Service encString::: "+encString+"\ndecString :: "+decString);
		logger.info("constructServiceRequest(Map inParams) method ends");
		return encString;
	}*/
	public String getMD5Hash(String name) {
		logger.info("getMD5Hash(String name) method begins");
		ChecksumMD5 cmd5 = new ChecksumMD5();
		String checksum = null;
		try {
			checksum = cmd5.getValue(name);
		} catch (Exception e) {
			logger.error("Exception occured... ",e);
		}
		logger.info("getMD5Hash(String name) method ends");
		return checksum;				 
	} 

	private String covertToXMLString(String policyNumber, String pan, String dob, String inbRegno) {
		logger.info("covertToXMLString(String policyNumber, String pan, String dob, String inbRegno) method begins");
		String xmlString = null;
		try {
			
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	 
			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("REGISTRATIONDETAILS");
			doc.appendChild(rootElement);	 			 
	 
			// POLICYNUMBER elements
			Element policyNo = doc.createElement("POLICYNUMBER");
			policyNo.appendChild(doc.createTextNode(policyNumber));
			rootElement.appendChild(policyNo);
	 
			// panno elements
			Element panNo = doc.createElement("PANNO");
			panNo.appendChild(doc.createTextNode(pan));
			rootElement.appendChild(panNo);
	 
			// DOB elements
			Element dobElement = doc.createElement("DOB");
			dobElement.appendChild(doc.createTextNode(dob));
			rootElement.appendChild(dobElement);
	 
			// inbRegno elements
			Element inbRegnoElement = doc.createElement("INBREGNO");
			inbRegnoElement.appendChild(doc.createTextNode(inbRegno));
			rootElement.appendChild(inbRegnoElement);
	 
			// write the content into string
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			
			// create string from xml tree
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);			  
			transformer.transform(source, result);
			xmlString = sw.toString();
			xmlString = xmlString.replace("UTF-8", "utf-8");
			logger.info("xmlString : "+xmlString);
	 
		  } catch (ParserConfigurationException pce) {
			  throw new SBIApplicationException("SE002");
		  } catch (TransformerException tfe) {
			  throw new SBIApplicationException("SE002");
		  }
		  logger.info("covertToXMLString(String policyNumber, String pan, String dob, String inbRegno) method ends");
		  return xmlString;
	} 
//Added for CR-577 SBI Mutual Fund
	public List getMfServicesForUser(Map inParams) {
		logger.info("getServicesForUser(Map inParams) method begins");
		String userName = (String) inParams.get("userName");
		// String bankCode = (String) inParams.get("bankCode");
		String folioNumber = (String) inParams.get("folioNumber");

		List groupServicesList = sbiGroupServicesDAOImpl
				.getUserMutualFundServices(userName, folioNumber);
		logger.info("getServicesForUser(Map inParams) method ends");
		return groupServicesList;
	}
	//Added for CR-577 SBI Mutual Fund
	
	public void insertMFRegisterationDetails(Map inParams) {
		logger.info("insertMFRegisterationDetails(Map inParams) method begins");
		try {
			int count = sbiGroupServicesDAOImpl
					.insertMFRegisterDetails(inParams);
		} catch (DAOException daoe) {
			throw new SBIApplicationException("SE002");
		}
		logger.info("insertMFRegisterationDetails(Map inParams) method ends");
	}

	//Added for CR-577 SBI Mutual Fund
	private String covertToPIPEString(String folioNumber, String pan,
			String bankAcNo, String inbRegno) {
		logger.info("covertToPIPEString(String folioNumber, String pan, String dob, String inbRegno) method begins");
		String pipeString = null;

		pipeString = "FolioNo=" + folioNumber + "|" + "PanNo=" + pan + "|"
				+ "BankAccNo=" + bankAcNo + "|" + "INBRegNo=" + inbRegno;

		logger.info("pipeString : " + pipeString);

		logger.info("overtToPIPEString(String folioNumber, String pan, String dob, String inbRegno) method ends");
		return pipeString;
	}
	
	//Added for CR-577 SBI Mutual Fund
	public List getFolioNumber(Map inParams) {
		logger.info("getFolioNumber(Map inParams) method begins");
		String userName = (String) inParams.get("userName");
		List groupServicesList = sbiGroupServicesDAOImpl
				.getFolioNumber(userName);
		logger.info("getFolioNumber(Map inParams) method ends");
		return groupServicesList;
	}

	//Added for CR-577 SBI Mutual Fund
	public void insertMFRegisterDetails(Map inParams) {
		logger.info("insertMFRegisterDetails(Map inParams) method begins");
		try {
			int count = sbiGroupServicesDAOImpl
					.insertMFRegisterDetails(inParams);
		} catch (DAOException daoe) {
			throw new SBIApplicationException("SE002");
		}
		logger.info("insertUserDetails(Map inParams) method ends");
	  }
	

	public void setSbiGroupServicesDAOImpl(SBIGroupServicesDAO sbiGroupServicesDAOImpl) {
		this.sbiGroupServicesDAOImpl = sbiGroupServicesDAOImpl;
	}
	public void setCoreDAOImpl(CoreDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	
	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}
	//For test
	public static void main(String[] args) {
		SBIGroupServicesBP sgbBP = new SBIGroupServicesBP();
		//sgbBP.constructServiceRequest();
		String zz = sgbBP.covertToXMLString("45787878879","ARJPK1239A","02/10/1985","GS0000067");
		zz = zz.replace(" standalone=\"no\"", "");
		System.out.println(zz);
		System.out.println(sgbBP.getMD5Hash("pan_no=BNIPK4565Y"));		
		//sgbBP.postWebServiceRequest("", "/opt/bv1to1/CLASSES/RET_SBILIFE.key");
		sgbBP.encrypt("<?xml version=\"1.0\" encoding=\"utf-8\"?><REGISTRATIONDETAILS><POLICYNUMBER>45787878879</POLICYNUMBER><PANNO>ARJPK1239A</PANNO><DOB>02/10/1985</DOB><INBREGNO>GS0000067</INBREGNO></REGISTRATIONDETAILS>", "/opt/bv1to1/CLASSES/RET_SBILIFE.key");
		sgbBP.decrypt("+LdeajgD82sZmAFZ1q2YjnOZjiaZ3Mgzvk6XcHQP+FXinUoCiaSIppiNYlvMhIbLjauatg+sIJ+MQVBG6faRVdUOnK+pcdL/e2XUCg/IQBqX3ZWsMlY4EfcCYxHM5i4qNjPjqcXibIoFk0K8FyTZQKMh4mENssQ7WbV70rTh6uBahNDzMKHVVLDLb9elJVINo1icO25Af25GcswCse7IyBkzu49gMs7Y/PMpW1Zh5yyDAcVWIQ074D6VKdOliPEB", "/opt/bv1to1/CLASSES/RET_SBILIFE.key");
		//sgbBP.parseXmlString2Map("<?xml version=\"1.0\" encoding=\"utf-8\"?><ServiceOutput><StatusCode>008</StatusCode><StatusDescription>Policy already registered</StatusDescription></ServiceOutput>");	
		System.out.println("date : "+StringUtils.convertDateStringFormat("01010001"));
		String[] arr = {"AGBPK3042P","AGBPK3042Q","AGBPK3042R","AGBPK3042S"};
		System.out.println("PAN\tEncrypted Data");
		for(int i=0;i<arr.length;i++){
			String checkSum = sgbBP.getMD5Hash("pan_no="+arr[i]);
			System.out.println("pan_no="+arr[i]+"\t"+checkSum);
			if(checkSum != null && checkSum.length()>0){
				String encryptedString = sgbBP.encrypt("pan_no="+arr[i]+"|checkSum="+checkSum, "/opt/bv1to1/CLASSES/RET_SBILIFE.key");				
				System.out.println(arr[i]+"\t"+encryptedString);
			}
		}
		
		
	}
}
