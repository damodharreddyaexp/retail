/*
 * LogonBP.java
 * Created on Jun 12, 2006
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jun 12, 2006 MV32627 - Initial Creation
package com.sbi.bp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.authentication.algorithm.Sha512Hashing;
import com.sbi.cache.UserSessionCache;
import com.sbi.dao.BVUserDAO;
import com.sbi.dao.UserDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.User;
import com.sbi.model.UserProfile;
import com.sbi.model.UserProfileDetails;
import com.sbi.service.ServiceConstant;
import com.sbi.utils.EncryptMD5;
import com.sbi.utils.StringUtils;
import com.sbi.utils.SMSGateWayRequestSender;
import com.sbi.utils.LoggingConstants;

public class LogonBP {
	private Logger logger=Logger.getLogger(getClass());
	private static final long MILLIS_PER_DAY = 1000 * 60 * 60 * 24;
	private UserDAO userDAOImpl;
	private BVUserDAO broadVisionDAOImpl;
	private Sha512Hashing sha512Hashing;
	private UserSessionCache userSessionCache;
	
	private SMSGateWayRequestSender smsGateWayRequestSender;
	//modified for cr 5034
	public boolean validateLogin(Map lock,String keyId, String userName,String password,String ipAddress,String userTypeConf)throws SBIApplicationException{//modified for CR 5034 - keyid has to be passed in order to encrypt the db password with key and compare.
		boolean lockStatus=false;
		Integer lockCount = null;
		Integer role = null;
		int userType = 0;
		logger.debug("lock & type details:"+lock);
		String passwordType=(String)lock.get("PASSWORD_MODE");
		// Checking User Role
		role= new Integer (lock.get("USER_ROLE").toString());
		if(lock.get("USER_ROLE") != null){
			if(role.intValue() != 1){				
				Object[] errorParams={userName};
				if(userTypeConf.equals("1"))
				SBIApplicationException.throwException("LOG027",errorParams);// for corporate user in khata context
				SBIApplicationException.throwException("LOG022",errorParams);// Other than retil user
	          }
		}else {
            Object[] errorParams={userName};
            SBIApplicationException.throwException("LOG005",errorParams); // user role null
        }
		
		// Checking Khata user
		if(lock.get("USER_TYPE") != null)
			userType = Integer.parseInt(lock.get("USER_TYPE").toString());
		
		if( (userType != Integer.parseInt(userTypeConf))){       	
			Object[] errorParams={userName};
			SBIApplicationException.throwException("USRTYP" + userType,errorParams);   // Only Khata user     	
        }
		
				
		if (lock.get("LAYOUT_PREF") == null )
			lock.put("LAYOUT_PREF","0");			
		lockCount = new Integer (lock.get("LAYOUT_PREF").toString());
		if (lockCount.intValue() > 2)
			lockStatus=true;
		
		if(!lockStatus){			
			Integer loginCount = null;
			String errorCode =null;
			if (lock.get("LOGIN_COUNT") == null )
				 lock.put("LOGIN_COUNT","0");
			 loginCount= new Integer(lock.get("LOGIN_COUNT").toString());			 
			 if(loginCount.intValue() >0)
				 errorCode = "LOG001";				 
			 else
				 errorCode = "LOG024";		
			
			boolean loginStatus=userDAOImpl.validateLogin(keyId,userName,password);//modified for CR 5034
			logger.info("loginStatus::"+loginStatus);
			if(!loginStatus){
				 if(passwordType != null && passwordType.equalsIgnoreCase("J")){
					Object[] errorParams={userName};
					SBIApplicationException.throwException(errorCode,errorParams); // Invalid username / password
				}
				else{
					//CR 1808 - Reset login password using PPKIT - starts(if-else loop brought in for this CR) 
					if(passwordType != null && passwordType.equalsIgnoreCase("K")){
						boolean kModeLoginStatus = false;
						
						String kModeUsername = (String)lock.get("K_MODE_USERNAME");//changed for CR 5034
						logger.info("kModeLoginStatus - BV :" + kModeLoginStatus);
						
						String md5Key = (String)lock.get("md5salt");
						String decpassword= (String)lock.get("bv_password");
						if(!kModeLoginStatus && kModeUsername!=null && kModeUsername!=""){//if password is java encrypted
							String newPassword =  EncryptMD5.hashMessage(EncryptMD5.hashMessage(kModeUsername+"#"+decpassword)+"#"+md5Key);
							kModeLoginStatus=userDAOImpl.kModeValidateLogin(keyId,userName,newPassword,kModeUsername);//modified for CR 5034
							logger.info("kModeLoginStatus - java :" + kModeLoginStatus);
						}
						
						/*if(!kModeLoginStatus)
							kModeLoginStatus=broadVisionDAOImpl.validateLogin(userName,password);
						
						logger.info("kModeLoginStatus:::"+kModeLoginStatus);*/
						if (!kModeLoginStatus){
							Object[] errorParams={userName};
							if(kModeUsername==null || kModeUsername.trim().equalsIgnoreCase("")){//for kmode password reset users. CR 5034
								errorCode="LOG001";
							}else{//for password redespatch kit users.							
								errorCode="K001";
							}
							SBIApplicationException.throwException(errorCode,errorParams); // Invalid username / password. CR 5034
						}
						else{
							try{
								User user=new User();
								user.setUserAlias(userName);
								user.setUserIPaddress(ipAddress);                            
							}catch(DAOException daoEx){
								logger.error("Exception occured : " , daoEx);
							}
							return true;
						}
					}
					else{
						Object[] errorParams={userName};
						SBIApplicationException.throwException("LOG028",errorParams);//Contact branch for new login credentials
					} 					
				}				
			}
			else
				return true;
			}
		else{
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG002",errorParams);// user locked.
		}
		return false;
	}
	
	public Map getUserDetails(Map inputParams)throws SBIApplicationException{
		Map outParams = new HashMap();
		String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
		String password = (String) inputParams.get(ServiceConstant.PASSWORD);
		String bankCode = (String) inputParams.get(ServiceConstant.BANK_CODE);
        int dateDifference=0;
        Integer userRole = null;
        UserProfile profile = null;
        UserProfileDetails profileDetails = null; //New Special Category(SBCollect&Merchant) Limit Setting 
        String kioskID=   (String) inputParams.get("kioskID");  // Added for KiosK - CR 2914 
        logger.info("kioskID::::"+inputParams.get("kioskID"));
		User user = userDAOImpl.findUser(userName, password);
		if ( user != null ) {
			if(user.getUserState().equalsIgnoreCase("0")) // CR 1595
			{ 
			if ( user.getRoles() != null && user.getRoles().size() > 0 ) {
				userRole = (Integer) user.getRoles().get(0);            
				if ( userRole != null) {                   
					profile = userDAOImpl.findUserProfile(user.getUserAlias());
					logger.info("User Profile : " + profile);
					
					profileDetails = userDAOImpl.findUserProfileDetails(user.getUserAlias()); //New Special Category(SBCollect&Merchant) Limit Setting
					logger.info("User ProfileDetails : " + profileDetails);
					
					if ( profile != null ) {
						if( profile.getBankCode().equalsIgnoreCase( bankCode.trim() ) ){
							if(kioskID==null)
							{
								kioskID="";
							}
							userSessionCache.setData(userName+"_kioskID", kioskID); // Added for KiosK - CR 2914 
	                        user.setBankCode(profile.getBankCode());
							user.setPPFlimit(profile.getTransactioLimit()); 
	                        user.setUserType(profile.getUserType());
							user.setThirdPartyLimit(profile.getThirdPartyLimit());
	                        user.setCorporateId(profile.getCorporateId());
	                        user.setUserIPaddress((String) inputParams.get(ServiceConstant.IP_ADDRESS));
	                        user.setNriSurvey(profile.getNriSurvey());// added for NRI survey
	                        user.setName(profile.getName());// added for NRI survey
	                        user.setBranchCode(profile.getBranchCode());// added for NRI survey  
	                        user.setPasswordMode(profile.getPasswordMode());    //  Added for CR 1893
	                        user.setOverAllTxnLimit(profile.getOverAllTxnLimit());//CR-2187 Saravanan N
							user.setUser_id(profile.getUserID());
							user.setAddressStatus(profile.getAddressStatus());    //  Added for CR 5026
	                       	outParams.put(ServiceConstant.USER, user);							
							if(profile.getChangePasswordDate()!=null)
								dateDifference=(int)((new Date().getTime() /MILLIS_PER_DAY) - (profile.getChangePasswordDate().getTime()/MILLIS_PER_DAY));
							outParams.put("profile",profile);
							outParams.put("dateDifference",new Integer(dateDifference));
							//CR-5405 start													
							//userDAOImpl.insertActiveUserLogin(inputParams);  //CR-5405 //multiple logins reverted
							//CR-5405 end
							return outParams;
						}else{
							Object[] errorParams={userName,bankCode};
                            SBIApplicationException.throwException("LOG003",errorParams); // bankCode not matching
						}
					}else {
						Object[] errorParams={userName};
						SBIApplicationException.throwException("LOG004",errorParams);// profile null
					}
                   
				
			} else {
                Object[] errorParams={userName};
                SBIApplicationException.throwException("LOG005",errorParams);// role null
                  }
            }else {
				Object[] errorParams={userName};
				SBIApplicationException.throwException("LOG006",errorParams);// role list null
			}
			}else{
				// Added for CR 1956 by Nageshwararao
				if(user.getUserState().equalsIgnoreCase("1")){
					Object[] errorParams={userName};
					SBIApplicationException.throwException("LOG025",errorParams);// user state is 1
				}
				// Added for IR 72331 by Martin Markus
				if(user.getUserState().equalsIgnoreCase("-2")){
					Object[] errorParams={userName};
					SBIApplicationException.throwException("LOG029",errorParams);// user state is -2
				}
			}
		} else {
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG007",errorParams);// user null
		}
		return null;
	} 

	//	CR-2723 start
	public void validatePhishingIP(String keyId, String userloginIP,String userName,String password){//Modified on 060109 //modified for CR 5034
		logger.debug("validatePhishingIP(String userloginIP,String userName,String password) - start");		
		try
		{
			if(userDAOImpl.isValidPhishingIP(userloginIP) || userDAOImpl.isUserFromPHIDummy(keyId, userName, password)){		//modified for CR 5034			
				logger.info("User has come either from suspected Phishing IP or this username is present in sbi_phi_dummy table");			
				Object[] errorParams={userloginIP,userName};
				SBIApplicationException.throwException("PHI001",errorParams);
			}
		}
		catch(DAOException daoExc)
		{
			logger.error("Error while checking phishing ip",daoExc);
			Object[] errorParams={userloginIP,userName};
			SBIApplicationException.throwException("PHI001",errorParams);
		}
		logger.debug("validatePhishingIP(String userloginIP,String userName,String password) - end");
	}
	
//	CR-2723 end
	
	public boolean validateLogin(Map lock,String keyId, String userName,String password,String ipAddress,String userTypeConf, String loginMode, String bankCode)throws SBIApplicationException{//modified for CR 5034 - keyid has to be passed in order to encrypt the db password with key and compare.
		boolean lockStatus=false;
		Integer lockCount = null;
		Integer role = null;
		int userType = 0;
		logger.debug("lock & type details:"+lock);
		String passwordType=(String)lock.get("PASSWORD_MODE");
		// Checking User Role
		role= new Integer (lock.get("USER_ROLE").toString());
		if(lock.get("USER_ROLE") != null){
			if(role.intValue() != 1){				
				Object[] errorParams={userName};
				if(userTypeConf.equals("1"))
				SBIApplicationException.throwException("LOG027",errorParams);// for corporate user in khata context
				SBIApplicationException.throwException("LOG022",errorParams);// Other than retil user
	          }
		}else {
            Object[] errorParams={userName};
            SBIApplicationException.throwException("LOG005",errorParams); // user role null
        }
		
		// Checking Khata user
		if(lock.get("USER_TYPE") != null)
			userType = Integer.parseInt(lock.get("USER_TYPE").toString());
		
		if( (userType != Integer.parseInt(userTypeConf))){       	
			Object[] errorParams={userName};
			SBIApplicationException.throwException("USRTYP" + userType,errorParams);   // Only Khata user     	
        }
		
				
		if (lock.get("LAYOUT_PREF") == null )
			lock.put("LAYOUT_PREF","0");			
		lockCount = new Integer (lock.get("LAYOUT_PREF").toString());
		if (lockCount.intValue() > 2)
			lockStatus=true;
		
		if(!lockStatus){			
			Integer loginCount = null;
			String errorCode =null;
			if (lock.get("LOGIN_COUNT") == null )
				 lock.put("LOGIN_COUNT","0");
			 loginCount= new Integer(lock.get("LOGIN_COUNT").toString());			 
			 if(loginCount.intValue() >0)
				 errorCode = "LOG001";				 
			 else
				 errorCode = "LOG024";		
			
			boolean loginStatus=userDAOImpl.validateLogin(keyId,userName,password,loginMode);//modified for CR 5034
			logger.info("loginStatus::"+loginStatus);
			if(!loginStatus){
				 if(passwordType != null && passwordType.equalsIgnoreCase("J")){
					Object[] errorParams={userName};
					SBIApplicationException.throwException(errorCode,errorParams); // Invalid username / password
				}
				else{
					//CR 1808 - Reset login password using PPKIT - starts(if-else loop brought in for this CR) 
					if(passwordType != null && passwordType.equalsIgnoreCase("K")){
						boolean kModeLoginStatus = false;
						String kModeUsername = (String)lock.get("K_MODE_USERNAME");//changed for CR 5034
						logger.info("kModeLoginStatus - BV :" + kModeLoginStatus);
						//String kModeUserPwdMode = userDAOImpl.getKModeUserPwdMode(kModeUsername);
						//logger.info("KMode user pwd mode"+kModeUserPwdMode);
						String md5Key = (String)lock.get("md5salt");
						String decpassword= (String)lock.get("bv_password");
						if(!kModeLoginStatus && kModeUsername!=null && kModeUsername!=""){//if password is java encrypted
							String newPassword = "";
							if(!"SHA-512".equalsIgnoreCase(loginMode)){
								newPassword = EncryptMD5.hashMessage(EncryptMD5.hashMessage(kModeUsername+"#"+decpassword)+"#"+md5Key);
								kModeLoginStatus=userDAOImpl.kModeValidateLogin(keyId,userName,newPassword,kModeUsername);
							}
							else{
								decpassword = (String)lock.get("shapassword");
								String newShaPassword = sha512Hashing.hashingSHA2(kModeUsername+"#"+decpassword);
								newPassword = sha512Hashing.hashingSHA2(newShaPassword+"#"+md5Key);
								kModeLoginStatus=userDAOImpl.kModeValidateLogin(keyId,userName,newPassword,kModeUsername,loginMode);
							}
							logger.info("kModeLoginStatus - java :" + kModeLoginStatus);
						}
						
						/*if(!kModeLoginStatus)
							kModeLoginStatus=broadVisionDAOImpl.validateLogin(userName,password);
						
						logger.info("kModeLoginStatus:::"+kModeLoginStatus);*/
						if (!kModeLoginStatus){
							Object[] errorParams={userName};
							if(kModeUsername==null || kModeUsername.trim().equalsIgnoreCase("")){//for kmode password reset users. CR 5034
								errorCode="LOG001";
							}else{//for password redespatch kit users.							
								errorCode="K001";
							}
							SBIApplicationException.throwException(errorCode,errorParams); // Invalid username / password. CR 5034
						}
						else{
							try{
								User user=new User();
								user.setUserAlias(userName);
								user.setUserIPaddress(ipAddress);                            
							}catch(DAOException daoEx){
								logger.error("Exception occured : " , daoEx);
							}
							return true;
						}
					}
					else{
						//Commented on 231109 to avoid BV validation - after 10g migration
					/*//CR 1808 - Reset login password using PPKIT - ends
						password = (String)lock.get("bv_password");
						boolean bvLoginStatus=broadVisionDAOImpl.validateLogin(userName,password);
						logger.info("bvstatus :" + bvLoginStatus);
						if(bvLoginStatus){
							try{
								password = (String)lock.get("encPassword");
								User user=new User();
								user.setUserAlias(userName);
								user.setUserIPaddress(ipAddress);
								userDAOImpl.changeLoginPassword(user,password,password);
							}catch(DAOException daoEx){
								logger.error("EXception occured : " , daoEx);
							}
							return true;
						}
						else{
							Object[] errorParams={userName};
							SBIApplicationException.throwException(errorCode,errorParams);// Invalid username / password failed in BV 
					    }	*/					
						Object[] errorParams={userName};
						SBIApplicationException.throwException("LOG028",errorParams);//Contact branch for new login credentials
					} 					
				}				
			}
			else
				return true;
			}
		else{
			// Added for  Locking SMS
			 UserProfile userProfile =(UserProfile) userDAOImpl.findUserProfile(userName);
			 String mobileNo =userProfile.getMobileNumber();
			 String countryCode = userProfile.getCountryCode();
			 String userNameFull = userName;
			 userName = getPadUserName(userName);
			 logger.info("Username has been locked for three times wrong attempt " + userName);	
			 logger.info("Username has been locked for three times wrong attempt with bankcode " + bankCode);				 
			 if(userProfile.getMobileNumber()!=null) {
				 try 
	         	{
	                 SimpleDateFormat sdf =new SimpleDateFormat("dd/MM/yyyy HH:mm");
	                 Calendar c1 = Calendar.getInstance(); // today          
	                 String smsParamValues[] ={userName,sdf.format(c1.getTime())};
	                 String msgTypeId ="MT000127"; 
	                 if(lockCount.intValue() == 3) //Added for User Lock CR

	                 {

	                 userDAOImpl.updateLayoutPref(userNameFull); 

	                 smsGateWayRequestSender.sendLoginLockSMS(msgTypeId,smsParamValues,bankCode,ServiceConstant.SMS_SEND_ORDER_ZERO, userName, mobileNo, countryCode);
					 logger.info("Username has been locked for three times wrong attempt - sms triggered " + userName);			

	                 }
	                 		
	         	}
				catch (Exception exp)
				{
					logger.error(LoggingConstants.EXCEPTION, exp);	
				}
			 }
			
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG002",errorParams);// user locked.
		}
		return false;
	}
	
	public String getPadUserName(String userName) {
		int userCount = userName.length();

		String replaceWord = "XXXXX";
		int startIndexVal = 0;
		int endIndexVal = 0;

		switch(userCount) {
		case 3 :
			startIndexVal = 1;endIndexVal= 2;
			userName = userName.substring(0, startIndexVal) + "X"
			+ userName.substring(endIndexVal);
			break;
		case 4 :
			startIndexVal = 1;endIndexVal= 3;
			userName = userName.substring(0, startIndexVal) + "XX"
			+ userName.substring(endIndexVal);
			break;
		case 5 :
			startIndexVal = 1;endIndexVal= 4;
			userName = userName.substring(0, startIndexVal) + "XXX"
			+ userName.substring(endIndexVal);
			break;
		case 6 :
			startIndexVal = 1;endIndexVal= 5;
			userName = userName.substring(0, startIndexVal) + "XXXX"
			+ userName.substring(endIndexVal);
			break;
		default :
			startIndexVal = 2;endIndexVal= 6;
			userName = userName.substring(0, startIndexVal) + replaceWord
			+ userName.substring(endIndexVal);
			break;
		}
		return userName;
	}
	
	public String getPAssword(String keyId, String password){
		return StringUtils.decryptString(password,keyId);
	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	public void setBroadVisionDAOImpl(BVUserDAO broadVisionDAOImpl) {
		this.broadVisionDAOImpl = broadVisionDAOImpl;
	}

	/**
	 * @param userSessionCache the userSessionCache to set
	 */
	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}

	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}
	
	//Added by three times lock out
    public void setSmsGateWayRequestSender(
    		SMSGateWayRequestSender smsGateWayRequestSender) {
    	this.smsGateWayRequestSender = smsGateWayRequestSender;
    }

	/**
	 * @param roleMapping The roleMapping to set.
	 */
	
	
	
}
