/* 
 * TransactionBP.java 
 * Created on Oct 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 28, 2005 BOOPATHI - Initial Creation
//Nov 09,2005  MURUGAN K - modification in setter methods and change behaviour  the instance variable default to private 
//Nov 23, 2005 BOOPATHI - Constants Added
//Nov 26, 2005 BOOPATHI - i have changed the implementation of postTransactionToBankSystem method
//Oct 24, 2010 Marimuthu - Changed for I-collect Module.	
package com.sbi.bp;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.UserSessionCache;
import com.sbi.dao.BankSystemDAO;
import com.sbi.dao.BankSystemTransactionDAOFactory;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.IBTransactionDAO;
import com.sbi.dao.UserDAO;
import com.sbi.dao.UserDAOImpl;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionResponse;
import com.sbi.rtgs.dao.InterBankBeneficiaryDAO;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.TxnFormatter;
import com.sbi.utils.TxnFormatterFactory;
import com.sbi.utils.UtilsConstant;

public class TransactionBP
{

    protected final Logger logger = Logger.getLogger(getClass());

    private TxnFormatterFactory txnFormatterFactory;

    private IBTransactionDAO ibTransactionDAOImpl;

    private BankSystemTransactionDAOFactory bankSystemTransactionDAOFactory;

	 private InterBankBeneficiaryDAO interBankBeneficiaryDAOImpl;
	 private UserSessionCache userSessionCache;
	 
	 private String billerName="";//added for CR 5553
	 
	 private UserDAO userDAOImpl;

    public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	/**
     * Call postTransactionToDB with Transaction Object as a input and get
     * ReferenceNo and update that Reference No in Transaction Object. Call
     * postTransactionToBankSystem with Transaction Object as a input and get
     * TransactionResponse Object and update the Transation object. Call
     * updateTransactionStatus with ReferenceNo,TransactionResponse and get
     * boolean result. return the Transaction Object
     * 
     * @param transaction
     *            Transaction
     * @return Transaction
     */
    public Transaction postTransaction(Transaction transaction) throws SBIApplicationException{
        if (transaction != null){
            if (logger.isDebugEnabled())
            {
                logger.debug("postTransaction(Transaction transaction) Begin transaction : " + transaction.toString());
            }
            String userName=transaction.getDebit().getUserName();
            logger.info("userName::"+userName);
            String branchCode=transaction.getDebit().getBranchCode();
            String bankCode="";
            if(branchCode!=null){
            	bankCode=branchCode.substring(0,1);
            }
            String kioskID =  (String) userSessionCache.getData(userName+"_kioskID");// Added for KiosK - CR 2914
            //added for CR 5553 - begin
            if (transaction.getName().equals("BP")){
            	billerName=(String)transaction.getCredit()[0].getNarrative1();
            	logger.info("biller name is ::::"+billerName);
            	transaction.getCredit()[0].setNarrative1("");
            	logger.info("biller name in transaction getCredit leg ::::"+billerName);
            }
            //added for CR 5553 - end
            String referenceNo =  postTransactionToDB(transaction);
            if(referenceNo != null && referenceNo.length() > 0 && 
            		(referenceNo.substring(0,2).equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)||
            		 referenceNo.substring(0,2).equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT)||
            		 referenceNo.substring(0,2).equalsIgnoreCase(UtilsConstant.DD_CONSTANT)||
            		 referenceNo.substring(0,2).equalsIgnoreCase("IU")))
            {
            	logger.debug("Commission update::");
            	//Added to add commission recovery details for I-Collect
            	String creditStatusCode = "process_now";
                if(referenceNo.substring(0,2).equalsIgnoreCase("IU")){
                	creditStatusCode = (String) transaction.getDebit().getNarrative1();
                }
                int res = interBankBeneficiaryDAOImpl.updCommissionAmount(referenceNo,transaction.getDebit().getRateOfInterest(),creditStatusCode);
                if(res > 0)
                    logger.info("Commission Amount set fot reference no:" + referenceNo);
              
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("referenceNo : " + referenceNo);
            }
            transaction.getDebit().setReferenceNo(referenceNo);
			if (!transaction.isScheduled()) {
				TransactionResponse transactionResponse = postTransactionToBankSystem(transaction);
	            if (logger.isDebugEnabled()){
	                logger.debug("transactionResponse : " + transactionResponse);
	            }
	            transaction.getDebit().setStatusCode(transactionResponse.getStatusCode());
	            transaction.getDebit().setStatusDescription(transactionResponse.getStatusDescription());
	            transaction.getDebit().setTransactionTime(transactionResponse.getResponseDate());
	            //GRPT const added for GRPT added by Archana 
	            if(transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)|| 
            	   transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT)
	            		)
	            	transaction.getDebit().setThirdPartyRef(transactionResponse.getResponseReference());
	            if (logger.isDebugEnabled())
	                logger.debug("transactionResponse :"+transactionResponse);
	            
	            updateTransactionStatus(referenceNo, transactionResponse);
	            //Added for Updation of amount for the newly added beneficiary in Temp table
	            if(("IT|IV|IR|IZ|IF").contains(transaction.getDebit().getReferenceNo().substring(0,2)) && transaction.getDebit().getIsNewlyAddedTp()!=null  && "YES".equalsIgnoreCase(transaction.getDebit().getIsNewlyAddedTp())){
	            	updateNewBeneficairyTransactions(transaction);
	            }
	            if (logger.isDebugEnabled()){
	                logger.debug("postTransaction(Transaction transaction) Ends transaction : " + transaction);
	            }
			}
			// Added for KiosK - CR 2914 - Start 
            logger.info("kioskID is :"+kioskID);
            if(kioskID!=null && kioskID.trim().length()>0)
            {
            	int recordCount=0;
            	recordCount=ibTransactionDAOImpl.insertKioskDetails(referenceNo,kioskID,userName,bankCode);
            }
            // Added for KiosK - CR 2914 - End 
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return transaction;

    }

    /**
     * Call IBTransactionDAO.createTransaction method with Transaction Object as
     * a input and get ReferenceNo back.
     * 
     * @param transaction
     *            Transaction
     * @return String
     */
    private String postTransactionToDB(Transaction transaction)
    {
        String refNo=null;
    	try
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("postTransactionToDB(Transaction transaction) Begin transaction : " + transaction);
            }
            refNo = ibTransactionDAOImpl.createTransaction(transaction);
            logger.info("refNo :"+refNo);
            if (logger.isDebugEnabled())
            {
                logger.debug("postTransactionToDB(Transaction transaction) Ends -> refNo : " + refNo);
            } 
            
        }
        catch (DAOException daoException)
        {
        	SBIApplicationException.throwException(daoException.getMessage(),daoException);
        }
        return refNo;
    }

    /**
     * Check the path . If it is core{ - call CoreFormatter.getTransactionFormat
     * with Transaction Object as a input and get Map back. - Call
     * CoreDaoImpl.getDataFromBankSystem with Map as a input and get List back. -
     * Get the data from List at first position. - Update the
     * TransactionResponse Object and return it }else{ - call
     * SwitchFormatter.getTransactionFormat with Transaction Object as a input
     * and get Map back. - Call SwitchDaoImpl.getDataFromBankSystem with Map as
     * a input and get List back. - Get the data from List at first position. -
     * Update the TransactionResponse Object and return it }
     * 
     * @param transaction
     *            Transaction
     * @return TransactionResponse
     */
    private TransactionResponse postTransactionToBankSystem(Transaction transaction)
    {
    	TransactionResponse transactionResponse=null;
        if (transaction != null)
        {
            
            if (logger.isDebugEnabled())
            {
                logger.debug("postTransactionToBankSystem(Transaction transaction) Begin -->transaction : " + transaction);
            }

            try
            {
                String txnPath = transaction.getPath();
                if (logger.isDebugEnabled())
                {
                    logger.debug("txnPath : " + txnPath);
                }
                TxnFormatter txnFormatter = txnFormatterFactory.getTransactionFormatter(txnPath);
                if (logger.isDebugEnabled())
                {
                    logger.debug("txnFormatter is :" + txnFormatter);
                }
                Map requestData = txnFormatter.getTransactionRequestFormat(transaction);
                // CR-5553 changed on 28/7/2010 - Start 
                String txnno = (String) requestData.get("txnno");
                String bankcode=(String)requestData.get("bankCode");
                String bankCodes="0|A|6";
                String txnName = transaction.getName();
                String txnNames = "001045|011045";
                String refNo = (String)requestData.get("reference_no");
                String narrative = (String)requestData.get("narrative");
                String debitBranchCode = (String)requestData.get("debitBranchCode");
                String creditBranchCode = (String)requestData.get("creditBranchCode");
                String remitt_type = (String)requestData.get("remitt_type");
            	if(txnNames.contains(txnno)){
                	if(refNo != null && "IB".equals(refNo.substring(0,2))){
                		if (billerName != null && billerName.length() <25){
                			billerName =String.format("%-25s", billerName);
                		}else{
                			billerName =billerName.substring(0,25);
                		}
                		narrative =  billerName+" "+narrative;
                	}
                /*	if(narrative!=null && narrative.length()>46){
                		narrative =narrative.substring(0,46);
                	}*/
                	requestData.put("narrative",narrative);
            		}
                //  // CR-5553 changed on 28/7/2010 - End
            	// CR - 5578 Changes Start - 29/09/2010 - Start
            	if(refNo != null && "ID".equals(refNo.substring(0,2)) &&( bankcode !=null) && ("0|A|3|6".contains(bankcode))){
            		if((debitBranchCode !=null && creditBranchCode !=null)&&(debitBranchCode.equalsIgnoreCase(creditBranchCode))){
            			requestData.put("remitt_type","1");
            		}
            		
            	}
            	// CR - 5578 Changes Start - 29/09/2010 - End
                BankSystemDAO bankSystemDAO = bankSystemTransactionDAOFactory.getBankSystemDAO(txnPath);
                List responseList = bankSystemDAO.getDataFromBankSystem(requestData);
                logger.info("responseList :"+responseList);
                if (logger.isDebugEnabled())
                {
                    logger.debug("List from bank system is :" + responseList);
                }
                HashMap bankSystemDataHash = (HashMap) responseList.get(BPConstants.ZERO_INT);
                logger.info("bankSystemDataHash :"+bankSystemDataHash);
                if (logger.isDebugEnabled())
                {
                    logger.debug("bankSystemDataHash is :" + bankSystemDataHash);
                }
                Map transactionResponseData = txnFormatter.getTransactionResponseFormat(bankSystemDataHash);
                //logger.info("*****transactionResponseData :"+transactionResponseData);

                //logger.info("transactionResponseData :"+transactionResponseData);
                transactionResponse = new TransactionResponse();
                transactionResponse.setResponseDate((Timestamp) transactionResponseData.get(BPConstants.RESPONSE_DATE));
                transactionResponse.setResponseReference((String) transactionResponseData
                        .get(BPConstants.RESPONSE_REFERENCE));
                transactionResponse.setStatusCode((String) transactionResponseData.get(BPConstants.STATUS));
                transactionResponse.setStatusDescription((String) transactionResponseData
                        .get(BPConstants.RESPONSE_DESCRIPTION));
				//Added for RTGS/NEFT
                
                String transactionType="";
                if(transaction.getDebit().getReferenceNo() != null && transaction.getDebit().getReferenceNo().length() >0){
                	transactionType = transaction.getDebit().getReferenceNo().substring(0,2);
                }
                if(transactionType.equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)
						||transactionType.equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT) 
						||transactionType.equalsIgnoreCase(UtilsConstant.DD_CONSTANT)
						||transactionType.equalsIgnoreCase("IU")) 
				{
                	double commissionAmount=transaction.getDebit().getRateOfInterest().doubleValue();
                	String utrNo="";
                	String tempUTRNo="";
                	if (transactionResponseData.get("utr_no")!=null && transactionResponseData.get("utr_no").toString().trim().length()>0 ) {
                		utrNo=transactionResponseData.get("utr_no").toString().trim();
                		tempUTRNo = utrNo;
                	}
                	
                	//Added this if condition by megavannan for DD commission
                	/*if(transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.DD_CONSTANT)){
                		utrNo = (String) transaction.getDebit().getAdditionalParams().get("outref1");
                		tempUTRNo = ((String) transactionResponseData.get(BPConstants.RESPONSE_REFERENCE));
                	}
                	*///DD commission end - by megavannan

                	interBankBeneficiaryDAOImpl.updateEchequeMasterForInterBankOnline(transaction.getDebit().getReferenceNo(),new Double(commissionAmount),utrNo,transactionResponse.getStatusCode());
                	transactionResponse.setResponseReference(tempUTRNo);
                }	
				//Ended for RTGS/NEFT
                if (logger.isDebugEnabled())
                {
                    logger.debug("transactionResponse is :" + transactionResponse);
                }
                //logger.info("transactionResponse :"+transactionResponse);
                logger.debug("postTransactionToBankSystem(Transaction transaction) End" );
            }
            catch (DAOException daoException)
            {
            	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
        }
        return transactionResponse;

    }

    /**
     * Call IBTransactionDAO.updateStatus with referenceNo and
     * TransactionResponse Object as a input and return boolean result.
     * 
     * @param referenceNo
     *            String
     * @param transactionResponse
     *            TransactionResponse
     * @return boolean
     */
    private boolean updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse)
    {
        logger.debug("updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse) Begin");

        if (transactionResponse != null && referenceNo != null && referenceNo.trim() != BPConstants.EMPTY)
        {
            try
            {
                return ibTransactionDAOImpl.updateStatus(transactionResponse, referenceNo);
            }
            catch (DAOException daoException)
            {
            	SBIApplicationException.throwException(daoException.getMessage(),daoException);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
        return true;

    }

    //Added to update the Transcation details of Newly Added beneficiary
    private void updateNewBeneficairyTransactions (Transaction transaction){
    	try
        {
        	if(!"ERR.".equalsIgnoreCase(transaction.getDebit().getStatusCode())){		            		
        		int insertTpTxnCount=0;
        		
        		String accountNo="";
        		String branchCode="";
        		String userName="";
        		
        		if( "IT|IF".contains(transaction.getDebit().getReferenceNo().substring(0,2))){
        			
        			accountNo=transaction.getCredit()[0].getAccountNo();
        			branchCode=transaction.getCredit()[0].getBranchCode();
        			userName=transaction.getDebit().getUserName();
            		
            			
        		}else if("IR|IZ".contains(transaction.getDebit().getReferenceNo().substring(0,2))){
        			String narrative2=transaction.getCredit()[0].getNarrative2();
        			
    				logger.info("narrative 2 in BP" +narrative2);
    				if (narrative2!=null) {
    					String interBankNarrative2[]=narrative2.split("\\|");
    					branchCode=interBankNarrative2[1];
    				}
    				accountNo=transaction.getCredit()[0].getNarrative1();
    				userName=transaction.getDebit().getUserName();
           		}else if("IV".equalsIgnoreCase(transaction.getDebit().getReferenceNo().substring(0,2))){
        			Map additionalParamsMap = new HashMap();
        			additionalParamsMap = transaction.getDebit().getAdditionalParams();
        			
        			accountNo = (String)additionalParamsMap.get("outref3");
        			branchCode="00000";
        			userName=transaction.getDebit().getUserName();
        			
        		}
        		
        		logger.info("acct no::::"+accountNo);
        		logger.info("branch Code::::"+branchCode);
        		logger.info("userName::::"+userName);
        		//String username, String creditAccountNo,String echequeNo,String branchCode,double amount,String transactionStatus,String module
        		insertTpTxnCount = userDAOImpl.updateNewTPTransactions(userName,accountNo , transaction.getDebit().getReferenceNo(),branchCode ,transaction.getDebit().getAmount() , transaction.getDebit().getStatusCode(), "RETAIL");
        		logger.info("Transaction details for Third party category no of rows::::"+insertTpTxnCount);
        	}
        }catch(Exception e){
        	logger.error("Exception in insertion of New TP Transactions",e);
        }
    
    	
    }
    
    
    
    
    /**
     * IBTransactionDAOImpl injection
     * 
     * @param ibTransactionDAOImpl
     *            IBTransactionDAO
     */
    public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl)
    {
        this.ibTransactionDAOImpl = ibTransactionDAOImpl;
    }

    /**
     * TxnFormatterFactory injection
     * 
     * @param txnFormatterFactory
     *            void
     */
    public void setTxnFormatterFactory(TxnFormatterFactory txnFormatterFactory)
    {
        this.txnFormatterFactory = txnFormatterFactory;
    }

	public void setBankSystemTransactionDAOFactory(
			BankSystemTransactionDAOFactory bankSystemTransactionDAOFactory) {
		this.bankSystemTransactionDAOFactory = bankSystemTransactionDAOFactory;
	}
	//Added for RTGS/NEFT
	public void setInterBankBeneficiaryDAOImpl(
			InterBankBeneficiaryDAO interBankBeneficiaryDAOImpl) {
		this.interBankBeneficiaryDAOImpl = interBankBeneficiaryDAOImpl;
	}
	//Ended for RTGS/NEFT

	/**
	 * @param userSessionCache the userSessionCache to set
	 */
	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}
}
