/*
 *  History:
 * Created by Lenin on Mar 20 2013
 * 
 */
package com.sbi.bp;

import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import Encryption.Encrypt;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.SmartPayoutCardDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.SmartCardHistoryModel;
import com.sbi.utils.UtilsConstant;

public class SmartPayoutCardBP {
	
	private Logger logger = Logger.getLogger(getClass());
	
	private SmartPayoutCardDAO smartCardDaoImpl;
	
	private ReferenceDataCache referenceDataCache;
	
	public boolean validateCardDetails(String userName,String cardNumber) throws SBIApplicationException {
		boolean valFlag = false;
		Map smartCardDetails = new HashMap();
		List smartCardList = smartCardDaoImpl.fetchActiveSmartCardList(userName);
		if(smartCardList.size() > 0)
			for(int i=0; i < smartCardList.size(); i++){
				smartCardDetails = (Map)smartCardList.get(i);
				if(smartCardDetails.get("CARD_NUMBER").equals(cardNumber)){
					return true;
				}
			}
		SBIApplicationException.throwException("SMC001");
		return valFlag;
	}

	public String fetchDataFromReferenceCache(String cachRefKey){
		Map cacheData = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
		String cacheValue = (String) cacheData.get(cachRefKey);
		return cacheValue;
		}
	
	public Map constructTopUpPSGRequestString(String topupRefNo,String selectedCardNum,double debitAmount,String inbRefNo,String narration,String ip,String port){
		
			Map requestMap = new HashMap();
			requestMap.put("protocolID", "0134");
			requestMap.put("transaction_type", "S2");
			requestMap.put("txnName", "smartcard_topup");
			requestMap.put("reference_no", topupRefNo);
			requestMap.put("card_no",selectedCardNum );
			Double amount = debitAmount;
			if(amount == null)
				amount = new Double(0.0);
			DecimalFormat f = new DecimalFormat("00000000.00");
			String strAmount = f.format(amount);
			strAmount = strAmount.replace(".", "");
			requestMap.put("load_amt", strAmount );
			requestMap.put("narration", narration);
			requestMap.put("ib_ref_no", inbRefNo);
			requestMap.put("psgIp" ,ip);
			requestMap.put("psgPort", port);
			return requestMap;
	}
	public Map constructCardEnqRequestString(String topupRefNo,String selectedCardNum,String ip,String port){
		
		Map requestMap = new HashMap();
		requestMap.put("protocolID", "0064");
		requestMap.put("transaction_type", "S1");
		requestMap.put("txnName", "smartpayoutcard_reg");
		requestMap.put("reference_no", topupRefNo);
		requestMap.put("card_no",selectedCardNum );
		requestMap.put("psgIp" ,ip);
		requestMap.put("psgPort", port);
		return requestMap;
	}
	
	
	

	public boolean checkCardRegStaus(String username,String cardnumber) {
		int recordCount = 0;

		recordCount=smartCardDaoImpl.fetchCardRegStatus(username,cardnumber);
		if(recordCount>0){
			return false;
		}else{	
			return true;
		}	
	}
	public boolean checkOnePerDay(String username) {
		int recordCount = 0;
		recordCount=smartCardDaoImpl.fetchRegisterCards(username);
		if(recordCount>0){
			return false;
		}else{
			return true;
		}
	}
	public boolean checkThreeCardsPerUserName(String username) {
		int recordCount = 0;
		recordCount=smartCardDaoImpl.fetchNoOfRegisterCards(username);
		if(recordCount>=3){
			return false;
		}else{
			return true;
		}
	}
	public String getReference(String fromFlag){
		String reference=null;
		try{
			reference = smartCardDaoImpl.getReferenceNo(fromFlag);
		}catch (DAOException daoException){
            	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
        }
		return reference;
	}
	public void insertSmartPayoutCardDetails(String refNo, String cardnumber,
			String username, String cardStatus) {
		try{
			smartCardDaoImpl.insertSmartPayoutCardDetails(refNo,cardnumber,username,cardStatus);
		}catch (DAOException daoException){
        	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
	}
	public Map constructSmartPayoutCardPSGRequestString(SmartCardHistoryModel smartCardModel) {
		Map requestMap = new HashMap();
		requestMap.put("protocolID", "0064");
		requestMap.put("transaction_type", "S1");
		requestMap.put("txnName", "smartpayoutcard_reg");
		String refNo=smartCardModel.getRefNo();
		refNo=refNo.replaceAll("\\n", "");
		refNo=refNo.replaceAll("\\r", "");
		requestMap.put("reference_no", refNo.trim());
		String cardNumber=smartCardModel.getCardNumber();
		cardNumber=cardNumber.replaceAll("\\n", "");
		cardNumber=cardNumber.replaceAll("\\r", "");
		requestMap.put("card_no", cardNumber.trim());		
		requestMap.put("psgIp",smartCardModel.getIp());
		requestMap.put("psgPort",smartCardModel.getPort());
		return requestMap;
	}
	public List fetchListofPayoutCards(String username, String status) {
		List smartPayoutCards=smartCardDaoImpl.getSmartPayoutDetails(username,status);
		return smartPayoutCards;
	}
	public boolean verifyCardNoUserName(String username, String cardNumber) {
		int recordCount = 0;
		recordCount=smartCardDaoImpl.verifyCardNoUserName(username,cardNumber);
		if(recordCount==0){
			return false;
		}else{	
			return true;
		}
	}
	
	public String encrypt(String data, String filePath) {
		logger.info("encrypt(String data, String filePath) method begins");
        Encrypt enc = new Encrypt(); 
        enc.setSecretkey(filePath);       
        String encData = null;
        try {
              data = URLDecoder.decode(data, "utf-8");
              encData = enc.encryptFile(data);
              if(encData == null){
            	  throw new SBIApplicationException("SE002");
              }
        } catch (Exception ex) {
        	logger.error("Exception occured while encrypting .. ",ex);
        	throw new SBIApplicationException("SE002");
        }           
        encData = encData.replaceAll("\n", "");
        encData = encData.replaceAll("\r", "");        
        logger.info("encrypt(String data, String filePath) method ends");
        return encData;		
	}
	public String decrypt(String encData, String filePath) {
		logger.info("decrypt(String encData, String filePath) method begins");
		Encrypt enc = new Encrypt();
		enc.setSecretkey(filePath);
        String decData = null;        
        decData = enc.decryptFile(encData);
        if(decData==null){
        	throw new SBIApplicationException("SE002");
        }
        logger.info("decrypt(String encData, String filePath) method ends");
        return decData;		
	}
	public String maskCardNumber(String smartCardNumber) {
	    final String s = smartCardNumber.replaceAll("\\D", "");
	    final int start = 4;
	    final int end = s.length() - 4;
	    final String overlay = StringUtils.repeat("X", end - start);
	    return StringUtils.overlay(s, overlay, start, end);
	}
	
	public void deleteSmartPayoutCardDetails(String username, String cardnumber) {
		try{
			smartCardDaoImpl.deregisterSmartCard(username,cardnumber);
		}catch (DAOException daoException){
        	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
	}
	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}

	public void setSmartCardDaoImpl(SmartPayoutCardDAO smartCardDaoImpl) {
		this.smartCardDaoImpl = smartCardDaoImpl;
	}	
}