package com.sbi.bp;

import java.util.ArrayList;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.AccessLevelDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;

public class AccessLevelBp 
{
	private AccessLevelDAO accessLevelDAOImpl;
	protected final Logger logger = Logger.getLogger(getClass());
	
	SBIApplicationException applicationException = new SBIApplicationException("Exception in BP");

	public List getUserAccounts(String userName) 
	{
		List accountList = new ArrayList();
		try {
			if (userName != null && !(userName.trim().equals(""))) 
			{
				accountList = accessLevelDAOImpl.findAccounts(userName);
			}
		}
		catch (DAOException daoException) {            
			SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
		}
		logger.info("Account List :" + accountList);        
		return accountList;
	}

	public Map getPdfDetails(Map inputParams)
	{
		logger.info("getPdfDetails(...) Starts Here");
		Map printDetails = new HashMap();
		try {
			printDetails = accessLevelDAOImpl.findPdfDetails(inputParams);
		}catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("getPdfDetails(...) Ends Here");
		return printDetails;
	}
	
	public void setAccessLevelDAOImpl(AccessLevelDAO accessLevelDAOImpl) {
		this.accessLevelDAOImpl = accessLevelDAOImpl;
	}


}
