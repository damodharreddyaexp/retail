package com.sbi.bp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.util.FileCopyUtils;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.FORBeneficiaryDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.model.Account;
import com.sbi.model.FORBeneficiaryDetails;
import com.sbi.model.FORPaymentDetails;
import com.sbi.service.ServiceConstant;
import com.sbi.service.ServiceErrorConstants;
import com.sbi.utils.CutoffTimeUtils;
import com.sbi.utils.FORUtil;
import com.sbi.utils.HttpsConnection;
import com.sbi.utils.StringUtils;

public class FORPaymentBP {
	
	private static Logger logger = Logger.getLogger(com.sbi.bp.FORPaymentBP.class);
	
	private AccountInformationBP accountInformationBP;
	private FORBeneficiaryDAO forBeneficiaryDAOImpl;
	private ReferenceDataCache referenceDataCache;
	private FORUtil forUtil;
	private CutoffTimeUtils cutOffTimeUtils;

	

	private static final double FOR_USD_REMIT_PER_TRANSACTION_LIMIT = 2000;//2000000;
	private static final double FOR_USD_REMIT_MEDICAL_FEES_PERMIT_LIMIT = 25000;//25000000;
	private static final double FOR_USD_ALL_REMIT_PERMIT_LIMIT = 96000;//96000000;
	private static final int FOR_PER_MONTH_TRANSACTION_LIMIT = 4;//4;//4000000;
	private static final double FOR_TOTAL_USD_REMIT_PERMIT_LIMIT = 125000;//(Online + Other channel) limit
	
	private static final double FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_ALL_REMIT_PERMIT_LIMIT = 3000;
	private static final double FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_REMIT_MEDICAL_FEES_PERMIT_LIMIT = 50000;
	
	private static final double FOR_TOTAL_INR_INITIAL_BEN_TRANSACTION_LIMIT = 50000;//(Online + Other channel) limit
	
	private HttpsConnection httpsConnection;
	
	/**
	 * This method will get the transaction accounts, beneficiary details and exchange rate values
	 * and set it in the Map. This Map values will be displayed in the payment initial page.
	 * 
	 * @param userName
	 * @param bankCode 
	 * @return
	 */
	public Map getFORTransferInitValues(String userName, String bankCode){
		logger.info("getFORTransferInitValues(String) - starts");
		Map outputParams = new HashMap();
		Map xchangeMap = null;
		
		try {
			xchangeMap = getAllExchangeRates();
		}catch(SBIApplicationException ex) {
			logger.error("Exception while getting Excahange rate", ex);
			SBIApplicationException.throwException(ex.getErrorCode());
		}		
		catch(Exception ex) {
			logger.error("Exception while getting Excahange rate", ex);
			SBIApplicationException.throwException("FOR010");
		}
		//Checking for the beneficiary details
		List forBeneficiaryDetailsList = forBeneficiaryDAOImpl.getFORBeneficiaryDetails(userName, bankCode,
				FOR_BEN_STATUS_ACTIVE);
		if(forBeneficiaryDetailsList != null && forBeneficiaryDetailsList.size()>0){
			logger.info("Total no of beneficiaries - "+forBeneficiaryDetailsList.size());
			outputParams.put("forBeneficiaryDetailsList", forBeneficiaryDetailsList);
		}
		else {
			logger.error("No FOR beneficiaries are added/active for this user.");
			SBIApplicationException.throwException("FOR003");
		}
		//Retrieving debit accounts for that particular user
		List debitAccountList = accountInformationBP.getTransactionAccounts(userName, 
				ServiceConstant.DEBIT_ACCOUNT);
		
		//Retrieving positive product list 
		//List<String> positiveProductCodeList = forBeneficiaryDAOImpl.getPositiveEnableBranchDetails("Y");
		//logger.info("FOR PAYMENT BP -- Positive ProductCode List Outside :: "  + positiveProductCodeList);
		
		if(debitAccountList != null && debitAccountList.size()>0){
			logger.info("Total accounts mapped for this user in FORPaymentBP - "+debitAccountList.size());
			logger.info("Total accounts mapped for this user in FORPaymentBP - "+debitAccountList);
			Iterator accIterator = debitAccountList.iterator();
			List<String> positiveProductCodeList = forBeneficiaryDAOImpl.getPositiveEnableBranchDetails("Y");
			logger.info("FOR PAYMENT BP -- Positive ProductCode List Outside :: "  + positiveProductCodeList);
			/*List<String> positiveProductCodeList = Arrays.asList(productList);
			logger.info("FOR PAYMENT BP -- Positive ProductCode List Inside :: "  + positiveProductCodeList);*/
			while(accIterator.hasNext()){
				Account account = (Account) accIterator.next();			
				if(account.getBankSystem().equalsIgnoreCase("Core")){
					//boolean productTypeFlag = false;
					String tmpString = account.getProductCode()+"|"+account.getProductType();
					logger.info("Inside Account Condition Postive Product List-- " + tmpString);
					if(!((positiveProductCodeList).toString()).contains(tmpString)){
						logger.info("tmpString : "+tmpString);
						logger.info("account being removed : "+account.getProductCode()+"|"+account.getProductType());
						accIterator.remove();
					}
					/*for(int i=0;i<productList.length;i++){
						if(tmpString.equalsIgnoreCase(productList[i])){
							productTypeFlag = true;
							break;
						}
					}
					if(!productTypeFlag){
						accIterator.remove();
					}*/
				}
				else{
					accIterator.remove();
				}
			}
			if(debitAccountList.size() <= 0){
				logger.error("No transaction accounts eligible for Internation Fund transfer");
				SBIApplicationException.throwException("FOR023");
			}
			logger.info("Total accounts mapped after filtering - "+debitAccountList.size());
			outputParams.put("debitAccountList", debitAccountList);
			outputParams.put("xchangeMap", xchangeMap); // Exchange Rate displaying in Front
		}
		else {
			logger.error("No transaction accounts mapped for this user");
			SBIApplicationException.throwException(ServiceErrorConstants.SE067);
        }
		logger.info("getFORTransferInitValues(String) - ends");
		return outputParams; 
	}
	
	/**
	 * This method is to get the Exchange rates for all three currencies
	 * 
	 * @return xchangeMap 
	 */
	public Map getAllExchangeRates()throws Exception{
		logger.info("getAllExchangeRates() - starts");
	//	String currencyCodes[] = new String[]{"USD", "EUR", "GBP"};
	/*	String inputXml = forUtil.generateXchangeRateRequestString(currencyCodes);
		LOGGER.info("Input Exchange XML String - "+inputXml);*/
		String responseString = postXML(FOR_GLS_EXRATE_URL, new String[0][]);
		logger.info("Response "+responseString);
		if(responseString == null || responseString.indexOf("<inb_for_exchange_rate_details>") == -1){
			logger.error("Invalid exchange rate response.");
			SBIApplicationException.throwException("FOR018");
		}		
		Map xchangeMap = forUtil.parseXchangeXMLStringToMap(responseString);
		logger.info("Response Map values - "+xchangeMap);		
		return xchangeMap;
	}
	
	public Map getAllExchangeRates1()throws Exception{
		logger.info("getAllExchangeRates() - starts");
		String responseString = postXML(FOR_GLS_EXRATE_URL, new String[0][]);
		logger.info("Response "+responseString);
		if(responseString != null){
			 
			responseString = responseString.substring(responseString.indexOf("<inb_for_exchange_rate_details>"));
			responseString = responseString.replaceAll(" ", "");
			Map xchangeMap = forUtil.parseXchangeXMLStringToMap(responseString);
			logger.info("Xchange Map - "+xchangeMap);
		//	<inb_for_exchange_rate_details><currency><code>USD</code><rate>45.50</rate></currency><currency><code>GBP</code><rate>60.03</rate></currency><currency><code>EUR</code><rate>75.76</rate></currency></inb_for_exchange_rate_details>
			logger.info("Response Map values - "+xchangeMap);	
			String currCode = (String) xchangeMap.get("code");
			if(currCode != null && ("USD".equalsIgnoreCase(currCode)||"EUR".equalsIgnoreCase(currCode)||"GBP".equalsIgnoreCase(currCode))){
				return xchangeMap;
			} 
			else{
				logger.info("Unable to post XML to get eXchange Rate from External System.");
				//response.setErrorCode("FOR010");
				
			}
		}
			return new HashMap();
		
	}
	
	public Map getAllExchangeRates111()throws Exception{
		logger.info("getAllExchangeRates() - starts");
	
		Map xchangeMap = new HashMap();
		
		xchangeMap.put("USD", "56.43");
		xchangeMap.put("EUR", "68.7");
		xchangeMap.put("GBP", "87.61"); 
		
		logger.info("Response Map values - "+xchangeMap);		
		return xchangeMap;
	}

	/**
	 * To retrieve the transaction count done by the user on current month
	 * 
	 * @param userName
	 * @param bankCode
	 * @return
	 */
	public int getTransactionCount(String userName, String bankCode){
		logger.info("getTransactionCount(String, String) - starts");
		int count = forBeneficiaryDAOImpl.getTransactionCount(userName, bankCode);		
		logger.info("getTransactionCount(String, String) - ends");
		return count;
	}
	
	/** 
	 * This method is for accept side validation of input parameters given in forpaymentinitial.jsp
	 * This method will also set other values required in the initial page
	 */
	public FORBeneficiaryDetails getBeneficaryDetails(String benId, String userName, String Status){
		logger.info("getActiveBeneficaryDetails(String benId, String userName, String Status) - starts");
		FORBeneficiaryDetails forBeneficiaryDetails = 
			forBeneficiaryDAOImpl.retrieveActiveFORBeneficiaryDetail(benId, userName, Status);
		logger.info("getActiveBeneficaryDetails(String benId, String userName, String Status) - ends");
		return forBeneficiaryDetails;
	}
	
	/**
	 * This method is for server side validation of input parameters given in forpaymentinitial.jsp.
	 * This method will also set other values required in the interim page.
	 * 
	 * @param inputMap
	 * @return
	 */
	public void setFORInterimPageValues(Map inputMap){
		logger.info("setFORInterimPageValues(Map) - starts");
		String userName = (String)inputMap.get("userName");
		String currCode = inputMap.get("currCode").toString().toUpperCase();
		String remitPurpose = inputMap.get("remitPurpose").toString().toUpperCase();
		String bankCode = inputMap.get("bankCode").toString();
		String forINRAmount = inputMap.get("forINRAmount").toString();
		logger.info("INR Amount Value Interim Payment BP ---" + forINRAmount);
		String forDestAmount = inputMap.get("forDestAmount").toString();
		logger.info("Destination Amount Value Interim Payment BP ---" + forDestAmount);
		boolean isCommissionRequired = (Boolean)inputMap.get("isCommissionRequired");
		logger.info("FOR Interim Page Commision :: " + isCommissionRequired);
		
		
		// check For Currency code for selected countries (US/GB/AUS) 
		if("USD|GBP|EUR".indexOf(currCode)==-1){
			logger.error("Invalid currency code selected.");
			SBIApplicationException.throwException("FOR028");
		}
		
		// Check For Monthly Limit Transaction 
		int count = getTransactionCount(userName, bankCode);
		logger.info("Transactions count - "+count);
		if(count >= FOR_PER_MONTH_TRANSACTION_LIMIT){
			logger.info("Transaction count limit exceeds for the current month.");
			SBIApplicationException.throwException("FOR019");
		}
	
		// Check For Amount Tampered
		double forAmount = Double.parseDouble(inputMap.get("forAmount").toString());
		if(forAmount < 0){
			logger.info("There are serious irregularities in your amount information.");
			SBIApplicationException.throwException("FOR027");
		}
		Map xratevalues = (Map)inputMap.get("xchangeMap");
		double xRate = Double.parseDouble(xratevalues.get(currCode).toString());
		double xrateUSD = Double.parseDouble(xratevalues.get("USD").toString());
		logger.info("USD Rate -- " + xrateUSD);
		
		double inrDebitAmount = forAmount * xRate;//Double.parseDouble(forINRAmount) * ;
		double USD_Rate_Convert_Amount = 0;
		// Check For Yearly Conversion for purpose of remit.
		// Step 1 : Convert the value relevant for USD 
		if (currCode.equalsIgnoreCase("USD")) {
			USD_Rate_Convert_Amount = forAmount;
		}
		else {
			// Other than USD Dollar (i.e EUR / GBP), converting EUR/GBP to USD dollar 
			USD_Rate_Convert_Amount = inrDebitAmount / xrateUSD; 
		}
		USD_Rate_Convert_Amount = Double.parseDouble(getUSDAmountFormat(USD_Rate_Convert_Amount)); // value rounded
	 
		// Step 2 : Check For Dollar Conversion per transaction limit == 2000
		if (USD_Rate_Convert_Amount > FOR_USD_REMIT_PER_TRANSACTION_LIMIT) {
			logger.info("Amount Exceeds the per transaction limit");
			SBIApplicationException.throwException("FOR020");
		}
		// finished
		
		checkRemitTxnLimit(userName, bankCode, currCode, remitPurpose, USD_Rate_Convert_Amount,"");
		
		// Step 3b :
		// Main Change are added for service rate 
		inrDebitAmount = Math.ceil(inrDebitAmount);
		double forServiceAmount = Math.ceil(getServiceTaxAmount(inrDebitAmount));
		double forCommissionAmount = 0; // Staff - Zero
		
		if (isCommissionRequired == true) {
			forCommissionAmount = getCommissionAmount(bankCode);
			forCommissionAmount = Math.ceil(xrateUSD * forCommissionAmount) ;
		}
		logger.info(" FOR Commission Amount -- " + forCommissionAmount);
		
		double forTentativeAmount = inrDebitAmount + forServiceAmount + forCommissionAmount;
		
		// Rounding to rupee - 1 
		forTentativeAmount = Math.ceil(forTentativeAmount);
		logger.info("Final Tentative Amount --- > " + forTentativeAmount);
		
		inputMap.put("inrDebitAmount", String.valueOf(inrDebitAmount)); // Whether we have to change to USD_Rate_Convert_Amount
		// Main Change are added for showing commission, service , total amount in display interim  page
		inputMap.put("forServiceAmount", String.valueOf(forServiceAmount));
		inputMap.put("forCommissionAmount", String.valueOf(forCommissionAmount));
		inputMap.put("forTentativeAmount", String.valueOf(forTentativeAmount));
	
		// Main change are added for showing USD_eqiuv_amount
		inputMap.put("USD_Rate_Convert_Amount", String.valueOf(USD_Rate_Convert_Amount));
		inputMap.put("xRate", xratevalues.get(currCode).toString());
		
		logger.info("setFORInterimPageValues(Map) - ends");
	}
	
	/**
	 * To Check whether particular remitter, transaction amount exceeds allowable yearly limit  
	 * made on both otherchannel /online and checking individual limit of , 
	 */
	
	/*public boolean checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt, String txnMode){
		logger.info("checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt) - starts");
		
		String remitPurpose = remitPurposes.toString().toUpperCase();//remitPurpose
		
		// Step3a : Study Abroad / Fees 
		double total_previous_USD_Debit_Amount_online_Purpose = 0;
		double total_USD_permit_limit = 0;// online Transaction Amount
		double total_previous_USD_Debit_Amount_branch = 0;
		double total_previous_USD_Debit_Amount_online_Overall = 0;
		
		String flag = "";
		
		// Cumulative both values for Permit Online Transaction Values = 96000USD 
		total_USD_permit_limit = FOR_USD_ALL_REMIT_PERMIT_LIMIT;//
		
		// New Change 
		
		if ((remitPurpose.equalsIgnoreCase("STUDY ABROAD|S0305"))
		   ||(remitPurpose.equalsIgnoreCase("MEDICAL TREATMENT|S0304")) 
		   ||(remitPurpose.equalsIgnoreCase("FAMILY MAINTENANCE|S1301"))){
			
			total_previous_USD_Debit_Amount_online_Purpose = forBeneficiaryDAOImpl.getRemitLimit(userName,bankCode,"",remitPurpose,"online");
		}
		else if ((remitPurpose.equalsIgnoreCase("REMITTANCE FOR EXAMINATION FEES|S0305"))
				||(remitPurpose.equalsIgnoreCase("FEE FOR PARTICIPATION IN GLOBAL CONFERENCES / SPECIALISED TRAINING|S0301"))
				||(remitPurpose.equalsIgnoreCase("MEDICAL TREATMENT (BOARDING/LODGING EXP.)|S0304"))
				||(remitPurpose.equalsIgnoreCase("GIFTS|S1302"))
				||(remitPurpose.equalsIgnoreCase("DONATIONS(PERSONAL)|S1302"))
				||(remitPurpose.equalsIgnoreCase("OTHERS|S1303"))
				) {
			total_previous_USD_Debit_Amount_online_Purpose = 0;
		}
		else {
			logger.info("Invalid purpose of remit.");
			SBIApplicationException.throwException("FOR016");
		} 
		
		// Summation Values made through Other Channel for all Purpose of Remit
		total_previous_USD_Debit_Amount_branch = forBeneficiaryDAOImpl.getRemitLimit(userName,bankCode,flag,"","branch");
		logger.info("Total Remittance through other channel in USD - "+total_previous_USD_Debit_Amount_branch);
		
		// Summation Values made through Online for all Purpose of Remit
		total_previous_USD_Debit_Amount_online_Overall = forBeneficiaryDAOImpl.getRemitLimit(userName, bankCode, "allOnline", "", "online");
		logger.info("Total Remittance through INB in USD - "+total_previous_USD_Debit_Amount_online_Overall);
		logger.info("Current Transaction Amount in USD - "+USD_Rate_Convert_Amt);
		
		if (!txnMode.equalsIgnoreCase("transacBranch")) {
			if((total_previous_USD_Debit_Amount_online_Overall+USD_Rate_Convert_Amt)>FOR_USD_ALL_REMIT_PERMIT_LIMIT){
				logger.info("The transaction amount exceeded the overall yearly limit of International Funds Transfer.");
				SBIApplicationException.throwException("FOR024");
			}
		}
		// Checking both overall transaction made through online and branch
		double total_previous_USD_Debit_Amount = USD_Rate_Convert_Amt + 
			total_previous_USD_Debit_Amount_online_Overall	+ total_previous_USD_Debit_Amount_branch;
		
		if (total_previous_USD_Debit_Amount	> FOR_TOTAL_USD_REMIT_PERMIT_LIMIT) {
			logger.info("The transaction amount exceeded the overall yearly limit of International Funds Transfer.");
			SBIApplicationException.throwException("FOR024");
		} 
		
		// Total sum
		logger.info("total_USD_Debit_Amount with current txn amount --" + total_previous_USD_Debit_Amount);
		// Online Amount
		logger.info("total_previous_USD_Debit_Amount_online for the selected purpose --" + total_previous_USD_Debit_Amount_online_Purpose);
		
		// Before Checking
		logger.info("Previous Allowable Remit Permit Limit is --" + total_USD_permit_limit);
		
		// New change added by abdul
		if (total_previous_USD_Debit_Amount_online_Purpose <= total_USD_permit_limit) {
			logger.info("Summed Value (online + current Txn Amount) is less than 96000 USD");
			if (total_previous_USD_Debit_Amount_branch >= FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_ALL_REMIT_PERMIT_LIMIT) {
				logger.info("Sum Value (other channel Amt )is greater than 1 lakh 4 thousand USD");
				total_USD_permit_limit = FOR_TOTAL_USD_REMIT_PERMIT_LIMIT - total_previous_USD_Debit_Amount_branch;
			}
		}
		
		// After Checking
		logger.info("After second level checking Allowable Remit Permit Limit is --" + total_USD_permit_limit);
		
		// Now We are checking with individual purpose of remit exceeds the allowable individual permit limit
		// Checking done due to if overall transaction limit is less than 2 lakhs it allowing but individual remit permit value not allowed
		// so that again condition is checking for individual remit purpose also
		
		
		// Summation Previous Online Transaction Amount With current Transaction Amount for checking allowable permit limit
		total_previous_USD_Debit_Amount_online_Purpose = total_previous_USD_Debit_Amount_online_Purpose + USD_Rate_Convert_Amt;
		
		if (!txnMode.equalsIgnoreCase("transacBranch")) {
			if (total_previous_USD_Debit_Amount_online_Purpose > total_USD_permit_limit) {
				logger.info("The requested transaction amount is exceeding your yearly limit of International Funds Transfer.");
				SBIApplicationException.throwException("FOR022");
			}
		}
		logger.info("checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt) - ends");
		return true;			
	}*/
	
	
	public boolean checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt, String txnMode){
		logger.info("checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt) - starts");
		
		String remitPurpose = remitPurposes.toString().toUpperCase();//remitPurpose
		
		//private static final double FOR_USD_REMIT_PER_TRANSACTION_LIMIT = 2000;//2000;
		//private static final double FOR_USD_REMIT_MEDICAL_FEES_PERMIT_LIMIT = 25000;//25000;
		//private static final double FOR_USD_ALL_REMIT_PERMIT_LIMIT = 72000;//96000;
		//private static final int FOR_PER_MONTH_TRANSACTION_LIMIT = 3;//4;//4000000;
		//private static final double FOR_TOTAL_USD_REMIT_PERMIT_LIMIT = 75000;//(Online + Other channel) limit
		
		//private static final double FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_ALL_REMIT_PERMIT_LIMIT = 3000;
		//private static final double FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_REMIT_MEDICAL_FEES_PERMIT_LIMIT = 50000;
		
		//private static final double FOR_TOTAL_INR_INITIAL_BEN_TRANSACTION_LIMIT = 50000;//(Online + Other channel) limit
		
		// Step3a : Study Abroad / Fees 
		double total_previous_USD_Debit_Amount_online_Purpose = 0;
		double total_USD_permit_limit = 0;// online Transaction Amount
		double total_previous_USD_Debit_Amount_branch = 0;
		double total_previous_USD_Debit_Amount_online_Overall = 0;
		
		String flag = "";
		
		// Cumulative both values for Permit Online Transaction Values = 72000USD 
		total_USD_permit_limit = FOR_USD_ALL_REMIT_PERMIT_LIMIT;// 
		
		// New Change 
		
		if ((remitPurpose.equalsIgnoreCase("STUDY ABROAD|S0305"))
		   ||(remitPurpose.equalsIgnoreCase("MEDICAL TREATMENT|S0304")) 
		   ||(remitPurpose.equalsIgnoreCase("FAMILY MAINTENANCE|S1301"))){
			
			total_previous_USD_Debit_Amount_online_Purpose = forBeneficiaryDAOImpl.getRemitLimit(userName,bankCode,"",remitPurpose,"online");
		}
		else if ((remitPurpose.equalsIgnoreCase("REMITTANCE FOR EXAMINATION FEES|S0305"))
				||(remitPurpose.equalsIgnoreCase("FEE FOR PARTICIPATION IN GLOBAL CONFERENCES / SPECIALISED TRAINING|S0301"))
				||(remitPurpose.equalsIgnoreCase("MEDICAL TREATMENT (BOARDING/LODGING EXP.)|S0304"))
				||(remitPurpose.equalsIgnoreCase("GIFTS|S1302"))
				||(remitPurpose.equalsIgnoreCase("DONATIONS(PERSONAL)|S1302"))
				||(remitPurpose.equalsIgnoreCase("OTHERS|S1303"))
				) {
			total_previous_USD_Debit_Amount_online_Purpose = 0;
		}
		else {
			logger.info("Invalid purpose of remit.");
			SBIApplicationException.throwException("FOR016");
		} 
		
		// Summation Values made through Other Channel for all Purpose of Remit
		total_previous_USD_Debit_Amount_branch = forBeneficiaryDAOImpl.getRemitLimit(userName,bankCode,flag,"","branch");
		logger.info("Total Remittance through other channel in USD - "+total_previous_USD_Debit_Amount_branch);
		
		// Summation Values made through Online for all Purpose of Remit
		total_previous_USD_Debit_Amount_online_Overall = forBeneficiaryDAOImpl.getRemitLimit(userName, bankCode, "allOnline", "", "online");
		logger.info("Total Remittance through INB in USD - "+total_previous_USD_Debit_Amount_online_Overall);
		logger.info("Current Transaction Amount in USD - "+USD_Rate_Convert_Amt);
		
		if (!txnMode.equalsIgnoreCase("transacBranch")) {
			if((total_previous_USD_Debit_Amount_online_Overall+USD_Rate_Convert_Amt)>FOR_USD_ALL_REMIT_PERMIT_LIMIT){
				logger.info("The transaction amount exceeded the overall yearly limit of International Funds Transfer.");
				SBIApplicationException.throwException("FOR024");
			}
		}
		// Checking both overall transaction made through online and branch
		double total_previous_USD_Debit_Amount = USD_Rate_Convert_Amt + 
			total_previous_USD_Debit_Amount_online_Overall	+ total_previous_USD_Debit_Amount_branch;
		
		if (total_previous_USD_Debit_Amount	> FOR_TOTAL_USD_REMIT_PERMIT_LIMIT) {
			logger.info("The transaction amount exceeded the overall yearly limit of International Funds Transfer.");
			SBIApplicationException.throwException("FOR024");
		} 
		
		// Total sum
		logger.info("total_USD_Debit_Amount with current txn amount --" + total_previous_USD_Debit_Amount);
		
		// Online Amount
		logger.info("total_previous_USD_Debit_Amount_online for the selected purpose --" + total_previous_USD_Debit_Amount_online_Purpose);
		
		// Before Checking
		logger.info("Previous Allowable Remit Permit Limit is --" + total_USD_permit_limit);
		
		// New change added by abdul
		if (total_previous_USD_Debit_Amount_online_Purpose <= total_USD_permit_limit) {
			logger.info("Summed Value (online + current Txn Amount) is less than 72000 USD");
			if (total_previous_USD_Debit_Amount_branch >= FOR_USD_SECOND_LEVEL_OTHER_CHANNEL_ALL_REMIT_PERMIT_LIMIT) {
				logger.info("Sum Value (other channel Amt )is greater than 3 thousand USD");
				total_USD_permit_limit = FOR_TOTAL_USD_REMIT_PERMIT_LIMIT - total_previous_USD_Debit_Amount_branch;
			}
		}
		
		// After Checking
		logger.info("After second level checking Allowable Remit Permit Limit is --" + total_USD_permit_limit);
		
		// Now We are checking with individual purpose of remit exceeds the allowable individual permit limit
		// Checking done due to if overall transaction limit is less than 75000 USD it allowing but individual remit permit value not allowed
		// so that again condition is checking for individual remit purpose also
		
		
		// Summation Previous Online Transaction Amount With current Transaction Amount for checking allowable permit limit
		total_previous_USD_Debit_Amount_online_Purpose = total_previous_USD_Debit_Amount_online_Purpose + USD_Rate_Convert_Amt;
		
		if (!txnMode.equalsIgnoreCase("transacBranch")) {
			if (total_previous_USD_Debit_Amount_online_Purpose > total_USD_permit_limit) {
				logger.info("The requested transaction amount is exceeding your yearly limit of International Funds Transfer.");
				SBIApplicationException.throwException("FOR022");
			}
		}
		logger.info("checkRemitTxnLimit(String userName, String bankCode, String currencyCode, String remitPurposes, double USD_Rate_Convert_Amt) - ends");
		return true;			
	}
	
	
	/**
	 * This method is to construct all the initial parameters that are required for FOR transaction
	 * initial page.
	 * 
	 * @param inputMap
	 * @return
	 */
	public String initFORTransfer(Map inputMap)throws Exception{
		logger.info("initFORTransfer(Map) - starts");
		
		String userName = inputMap.get("userName").toString();
		String benId = inputMap.get("benId").toString();		
		
		//FORBeneficiaryDetails forBeneficiaryDetails = 
		//	forBeneficiaryDAOImpl.retrieveActiveFORBeneficiaryDetail(benId, userName, FOR_BEN_STATUS_ACTIVE);
		
		FORBeneficiaryDetails forBeneficiaryDetails = (FORBeneficiaryDetails)inputMap.get("forBeneficiaryDetails");
		
		String forRemitInstruct = "";
		if(inputMap.get("forRemitInstruct") != null && inputMap.get("forRemitInstruct").toString().length()>0)
			forRemitInstruct = inputMap.get("forRemitInstruct").toString();
		
		//Creating transaction id for this transaction
		String forRefNo = forBeneficiaryDAOImpl.getFORPaymentSequenceNo();
		
		FORPaymentDetails forPaymentDetails = new FORPaymentDetails();
		forPaymentDetails.setTransactionId(forRefNo);
		forPaymentDetails.setUserName(userName);
		forPaymentDetails.setBeneficiaryId(benId);
		forPaymentDetails.setAmount(Double.valueOf(inputMap.get("forAmount").toString()));
		
		// Main Change For Debit and Service Rate
		//forPaymentDetails.setAmount(Double.valueOf(inputMap.get("").toString()));
		forPaymentDetails.setServiceTax(Double.valueOf(inputMap.get("forServiceAmount").toString()));
		forPaymentDetails.setCommissionAmount(Double.valueOf(inputMap.get("forCommissionAmount").toString()));
		
		forPaymentDetails.setCurrencyCode(inputMap.get("currCode").toString());
		forPaymentDetails.setBicCode(forBeneficiaryDetails.getBicNum()); // Need to change this
		forPaymentDetails.setDebitAccountNo(inputMap.get("debitAccountNo").toString());
		forPaymentDetails.setDebitBranchCode(inputMap.get("debitBranchCode").toString());		
		forPaymentDetails.setStatus(FOR_TRANSFER_STATUS_OP);
		forPaymentDetails.setRemitInstruct(forRemitInstruct);
		forPaymentDetails.setSourceOfFund(inputMap.get("sourceOfFund").toString());
		forPaymentDetails.setPurposeOfRemit(inputMap.get("remitPurpose").toString());
		
		logger.info("FOR Payment details - "+forPaymentDetails);
		
		// Main change addedd for remit return code)
		String tmp = inputMap.get("remitPurpose").toString();
		logger.info("Remit Purpose -" + tmp);
	
		if(tmp!=null && tmp.length()>0){
			String temp[] = tmp.split("\\|"); 
			//forTransacDetails.setPurposeOfRemit(temp[0]);
			forPaymentDetails.setRemitReturnCode(temp[1].toString());
		}
		else {
			//forTransacDetails.setPurposeOfRemit("");
			forPaymentDetails.setRemitReturnCode("");
		}
		
		
		// Main change are added for REM Pan Number and USD Equivalent Number
		forPaymentDetails.setRemitterPAN(inputMap.get("remPanNum").toString());
		forPaymentDetails.setUsdEquivAmount(Double.valueOf(inputMap.get("USD_Rate_Convert_Amount").toString()));
		forPaymentDetails.setTxnMode(inputMap.get("transacMode").toString());
		forPaymentDetails.setExchangeRate(Double.valueOf(inputMap.get("xRate").toString()));
		 
		inputMap.put("forPaymentDetails", forPaymentDetails);
		//inputMap.put("forBeneficiaryDetails", forBeneficiaryDetails);
		
		String bankCode = inputMap.get("bankCode").toString();
		List forTransactionHistory = getALLOtherChannelTransactionDetails(userName, bankCode);
		//forBeneficiaryDAOImpl.getAllTransactionDetails(userName, bankCode);
		
		inputMap.put("forTransactionHistory", forTransactionHistory);
		inputMap.put("FTFlag", "ft_init");
		
		logger.info("Final Map - "+inputMap);
		
		String xmlString = forUtil.generateFTRequestXMLMessage(inputMap);
		logger.info("OFAC XML String - "+xmlString); 
		String encXmlString = forUtil.encrptAESString(xmlString);//xmlString
		//String encXmlString = xmlString;//xmlString
		//forXMLFileWriting(xmlString,forRefNo); 
		logger.info("Encrypted OFAC XML String - "+encXmlString);
		String[][] data = new String[][]{{"transinitresStr", encXmlString}};//xmlString}};
		if(xmlString != null){
			String responseString = postXML(FOR_GLS_FT_INIT_URL, data);
			logger.info("Response String - "+responseString);
			
			if(responseString == null || responseString.indexOf("<inb_for_transaction_init_res_details>") == -1){
				updateFTStatusDetails(forRefNo, FORBeneficiaryDAO.FOR_FAILURE, 
						"Unable to post XML to initiate OFAC / AML check.", "", "");
				logger.info("Unable to post XML to initiate OFAC / AML check.");
				SBIApplicationException.throwException("FOR018");
			}
			
			responseString = responseString.substring(responseString.indexOf("<inb_for_transaction_init_res_details>"));
			responseString = responseString.replaceAll(" ", "");
			
			Map responseMap = forUtil.parseFORXMLStringToMap(responseString);
			logger.info("Response Map - "+responseMap);
			
			String status = (String) responseMap.get("tran_init_status");
			if(status != null && ("processing".equalsIgnoreCase(status)
					|| "success".equalsIgnoreCase(status))){
				int result = forBeneficiaryDAOImpl.initFORTransfer(forPaymentDetails);
				if(result <= 0){
					logger.error("Error while creating transaction");
					SBIApplicationException.throwException(ServiceErrorConstants.SE067);
				}
				logger.info("Transaction initiated successfully.");
			}
			else{
				updateFTStatusDetails(forRefNo, FORBeneficiaryDAO.FOR_FAILURE, 
						"Unable to post XML to initiate OFAC / AML check.", "", "");
				logger.info("Unable to post XML to initiate OFAC / AML check.");
				SBIApplicationException.throwException("FOR018");
			}
		}
		
		logger.info("initFORTransfer(Map) - ends");
		return forRefNo;
	}
	
	/**
	 * This method will write xml String in a xml file
	 * 
	 */
	
	public void forXMLFileWriting(String xmlString, String forRefNo) {
		logger.info("forXMLFileWriting(String xmlString, String forRefNo - Starts");
		try {
			String tempPath="D:/temp/";
			String newPath="D:/abdul/";
			
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("ddMMyyyy");
			String txn_date_fmt=simpleDateFormat.format(new Date());
			simpleDateFormat=new SimpleDateFormat("HHmmss");
			String txn_time_fmt=simpleDateFormat.format(new Date());
			
			File tmpFile = null;
			File backupFile = null;
			File moveFile = null;
			
			//String fileName="INB_"+branchCode+"_"+txn_date_fmt+"_"+txn_time_fmt+"_"+txn_date_fmt+"_"+counterService.getPaddedNextCounter()+".txt";
			
		//	String fileName="INB_"+txn_date_fmt+"_"+txn_time_fmt+"_"+txn_date_fmt+"_"+forRefNo+".txt";
			String fileName="INB_"+txn_date_fmt+"_"+txn_time_fmt+"_"+txn_date_fmt+"_"+forRefNo+".pdf";
			
			tmpFile = new File( tempPath+fileName );
			BufferedWriter writer = new BufferedWriter(new FileWriter(tmpFile, true));
			
			writer.newLine();
			writer.write(xmlString); 
			
			writer.close();
			logger.info("writing file ends");
			backupFile =  new File(tempPath,fileName+"_backup");
			
			FileCopyUtils.copy(tmpFile,backupFile );
			
			moveFile = new File(newPath+fileName);
			tmpFile.renameTo(moveFile);
			logger.info("forXMLFileWriting(String xmlString, String forRefNo - ends");
			
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	
	/**
	 * This Method create a new remit id for new remitter and also examine wheteher it is 
	 * available for already existing remitter.
	 */
	
	public String getRemitId(String userName, String bankCode) {
		String remitSeqId = forBeneficiaryDAOImpl.getRemitId(userName, bankCode);
		return remitSeqId;
	}
	
	/**
	 * This method is used to for passing other channel information to GLS system in separate XML string
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	public String initFOROCCredit(Map inParams)throws Exception { 
		logger.info("initFOROCCredit(String) - starts");
		String responseStr = null;
		if(inParams != null){
			//inParams.put("FTFlag", "");
			String xmlString = forUtil.generateOtherChannelRequestXMLMessage(inParams);
			responseStr = xmlString;
			logger.info("XML String - "+xmlString);
			//String encXmlString = xmlString;//forUtil.encrptAESString(xmlString);
			String encXmlString = forUtil.encrptAESString(xmlString);
			String[][] data = new String[][]{{"otherChannel", encXmlString}};
			responseStr = postXML(FOR_GLS_OC_URL, data);
			logger.info("Response string - "+responseStr);
		}
		logger.info("initFOROCCredit(String) - ends");
		return responseStr;
	}
	
	/**
	 * This method will fire the <transaction> XML message to GLS to initiate FOR credit to customer
	 * @param inParams
	 * @return
	 */
	public String initFORGLSCredit(Map inParams) throws Exception{
		logger.info("initFORGLSCredit(String) - starts");
		String responseStr = null;
		if(inParams != null){
			inParams.put("FTFlag", "");
			String xmlString = forUtil.generateFTRequestXMLMessage(inParams);
			logger.info("XML String - "+xmlString);
			//String encXmlString = xmlString;//forUtil.encrptAESString(xmlString);
			String encXmlString = forUtil.encrptAESString(xmlString);
			String[][] data = new String[][]{{"transresponseStr", encXmlString}};
			responseStr = postXML(FOR_GLS_FT_ADVICE_URL, data);
			logger.info("Response string - "+responseStr);
		}
		logger.info("initFORGLSCredit(String) - ends");
		return responseStr;
	}

	/**
	 * This method is to retrieve all the FOR transaction details of a particular user.
	 * 
	 * @param userName
	 * @param bankCode
	 * @return
	 */
	public List getAllTransactionDetails(String userName, String bankCode, String status){
		logger.info("getAllTransactionDetails(String, String) - starts");
		List forTransactionList = forBeneficiaryDAOImpl.getAllTransactionDetails(userName, bankCode, status);
		/*if(forTransactionList == null || forTransactionList.size() == 0){
			LOGGER.error("No FOR transactions found.");
			SBIApplicationException.throwException("FOR011");
		}*/
		logger.info("getAllTransactionDetails(String, String) - ends");
		return forTransactionList;
	}
	
	public List getALLOtherChannelTransactionDetails(String userName, String bankCode){
		logger.info("getALLOtherChannelTransactionDetails(String, String) - starts");
		List forTransactionList = forBeneficiaryDAOImpl.getALLOtherChannelTransactionDetails(userName, bankCode);
		/*if(forTransactionList == null || forTransactionList.size() == 0){
			LOGGER.error("No FOR transactions found.");
			SBIApplicationException.throwException("FOR011");
		}*/
		logger.info("getALLOtherChannelTransactionDetails(String, String) - ends");
		return forTransactionList;
	}
	
	/**
	 * This method is to retrieve the transaction details of the given transaction id.
	 * 
	 * @param transactionId
	 * @param userName
	 * @return
	 */
	
	public FORPaymentDetails getTransactionOtherChannelDetails(String transactionId, String userName){
		logger.info("getTransactionOtherChannelDetails(String, String) - starts");
		FORPaymentDetails forPaymentDetails = null;
		forPaymentDetails = forBeneficiaryDAOImpl.getTransactionOtherChannelDetails(transactionId, userName);
		logger.info("getTransactionOtherChannelDetails(String, String) - ends");
		return forPaymentDetails;
	}
	
	public FORPaymentDetails getTransactionDetails(String transactionId, String userName){
		logger.info("getTransactionDetails(String, String) - starts");
		FORPaymentDetails forPaymentDetails = null;
		try{
			forPaymentDetails = forBeneficiaryDAOImpl.getTransactionDetails(transactionId, userName);
		}
		catch(IncorrectResultSizeDataAccessException excep){
			logger.error("No FOR transactions found.");
			SBIApplicationException.throwException("FOR011");
		}
		logger.info("getTransactionDetails(String, String) - ends");
		return forPaymentDetails;
	}

	/**
	 * This method is to cancel a FOR transaction.
	 * 
	 * @param transactionId
	 * @param remarks
	 * @param userName
	 * @return
	 */
	
	public int cancelTransaction(String transactionId, String statusDesc, String userName){
		logger.info("cancelTransaction(String, String, String) - starts");
		int result = forBeneficiaryDAOImpl.updateTransactionStatus(transactionId, 
				FOR_TRANSFER_STATUS_CANCELLED, statusDesc, "Transaction cancelled by user.", userName);
		if(result != 1){
			logger.error("No FOR transactions found.");
			SBIApplicationException.throwException("FOR011");
		}		
		logger.info("cancelTransaction(String, String, String) - ends");
		return result;
	}
	
	/**
	 * This method will update the status of FOR beneficiary on the basis of status provided by URL
	 * hit from GLS.
	 * 
	 * @param inputMap
	 * @return
	 */
	public String updateOFACStatusDetails(Map inputMap){
		logger.info("updateOFACStatusDetails(Map) - starts");
		String benId = inputMap.get("ben_id").toString();
		String status = inputMap.get("ofac_status").toString();
		String statusDesc = inputMap.get("ofac_status_desc").toString();
		FORBeneficiaryDetails forBenDetals = forBeneficiaryDAOImpl.
			retrieveActiveFORBeneficiaryDetail(benId, "", "");
		String currentStatus = forBenDetals.getStatus();
		logger.info("Current status - "+currentStatus);
		//LOGGER.info("is valid state change - "+isValidBenStatusChange(currentStatus, status));
		String responseString = "";
		if(FORBeneficiaryDAO.FOR_OFAC_PENDING.equalsIgnoreCase(currentStatus)){
			//Two possible status to update through URL posting - success and failure
			//On success the beneficiary will be moved to active state after Cooling period verification
			if(FORBeneficiaryDAO.FOR_SUCCESS.equalsIgnoreCase(status)){
				status = FORBeneficiaryDAO.FOR_VERIFY_PENDING;
				if(statusDesc == null || !(statusDesc.trim().length() > 0)){
					statusDesc = "OFAC check completed successfully.";
				}
			}
			//On OFAC check failure the status is moved to rejected state 
			if(FORBeneficiaryDAO.FOR_FAILURE.equalsIgnoreCase(status)){
				status = FORBeneficiaryDAO.FOR_REJECT;
				if(statusDesc == null || !(statusDesc.trim().length() > 0)){
					statusDesc = "OFAC check failed.";
				}
			}
			int result = forBeneficiaryDAOImpl.updateOFACStatus(benId, status, statusDesc);
			if(result == 1){
				responseString = "success|OFAC status updated successfully";
				logger.info("OFAC status updated successfully.");
			}else{
				responseString = "failure|Invalid Transaction ID or Transaction ID not found";
				logger.error("Invalid Transaction ID or Transaction ID not found.");
			}
		}
		else{
			responseString = "failure|Invalid status change";
			logger.error("Invalid status change.");
		} 
		// Change - Inclusion of response time in xml String
		
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.S");
		
		String remId = forBenDetals.getRemitId();
		String[] tmp = responseString.split("\\|");
		String GLS_OFAC_ACK_MSG = new StringBuffer()
	    .append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><gls_ofac_res_details>")
	    .append("<ben_id>").append(benId).append("</ben_id>")
		.append("<rem_id>").append(remId).append("</rem_id>")
		.append("<ofac_status>").append(tmp[0]).append("</ofac_status>")
		.append("<ofac_status_desc>").append(tmp[1]).append("</ofac_status_desc>")
		.append("<res_time>"+dateFormat.format(currentDate.getTime()).toString()+"</res_time>")
		.append("</gls_ofac_res_details>").toString();
		
		logger.info("Response String - "+GLS_OFAC_ACK_MSG);
		
		logger.info("updateOFACStatusDetails(Map) - ends");
		//return responseString;
		return GLS_OFAC_ACK_MSG;
	}
	
	/**
	 * This method is to check whether the FOR beneficiary status change is valid or not
	 * 
	 * @param currentStatus
	 * @param newStatus
	 * @return
	 */
	public boolean isValidBenStatusChange(String currentStatus, String newStatus){
		/*
		 Valid status changes 
		 auth_pending -> ofac_pending -> verification_pending -> active
		 any state (other than verification_pending, inactive and rejected) -> inactive / rejected
		 
		 Status in INB in beneficiary flow - auth_pending, ofac_pending, verification_pending, active, rejected
		 Status from GLS for OFAC check in beneficiary flow - success, failure
		 */
		logger.info("isValidBenStatusChange(String, String) - starts");
		logger.info("Current status - "+currentStatus+" New Status - "+newStatus);
		boolean isValidCurrStatus = false;
		boolean isValidNewStatus = false;
		boolean isValid = false;
		if(currentStatus == null || currentStatus.trim().length() == 0 || 
				newStatus == null || newStatus.trim().length() == 0){
			isValidCurrStatus = isValidNewStatus = isValid = false;
		}
		else{
			if(FORBeneficiaryDAO.FOR_OFAC_PENDING.equalsIgnoreCase(currentStatus)){
				isValidCurrStatus = true;
			}
			else if(FORBeneficiaryDAO.FOR_INACTIVE.equalsIgnoreCase(currentStatus) || 
					FORBeneficiaryDAO.FOR_REJECT.equalsIgnoreCase(currentStatus) ||
					FORBeneficiaryDAO.FOR_VERIFY_PENDING.equalsIgnoreCase(currentStatus)){
				isValidCurrStatus = false;
			}
			
			if((FORBeneficiaryDAO.FOR_SUCCESS.equalsIgnoreCase(newStatus) ||
					FORBeneficiaryDAO.FOR_FAILURE.equalsIgnoreCase(newStatus))){
				isValidNewStatus = true;			
			}
		}
		if(isValidCurrStatus && isValidNewStatus){
			logger.info("Valid beneficiary status change.");
			isValid = true;
		}
		logger.info("isValidBenStatusChange(String, String) - ends");
		return isValid;
	}
	
	/**
	 * This method will validate whether the status fund transfer status change is valid or not
	 *  
	 * @param currentStatus
	 * @param newStatus
	 * @return
	 */
	public boolean isValidFTStatusChange(String currentStatus, String newStatus){
		logger.info("isValidFTStatusChange(String, String) - ends");
		boolean isValid = false;
		logger.info("Current status - "+currentStatus+" New Status - "+newStatus);
		if(currentStatus == null || currentStatus.trim().length() == 0 || 
				newStatus == null || newStatus.trim().length() == 0){
			isValid = false;
		}
		else{
			if(FORBeneficiaryDAO.FOR_OFAC_PENDING.equalsIgnoreCase(currentStatus)){
				if(FORBeneficiaryDAO.FOR_OFAC_SUCCESS.equalsIgnoreCase(newStatus) ||
						FORBeneficiaryDAO.FOR_OFAC_FAILURE.equalsIgnoreCase(newStatus)){
					isValid = true;
				}
				else{
					isValid = false;
				}
			}
			else if(FORBeneficiaryDAO.FOR_OFAC_SUCCESS.equalsIgnoreCase(currentStatus)){
				if(FORBeneficiaryDAO.FOR_GLS_CREDIT_SUCCESS.equalsIgnoreCase(newStatus) ||
						FORBeneficiaryDAO.FOR_GLS_CREDIT_FAILURE.equalsIgnoreCase(newStatus)){
					isValid = true;
				}
				else{
					isValid = false;
				}
			}
			else if(FORBeneficiaryDAO.FOR_GLS_CREDIT_SUCCESS.equalsIgnoreCase(currentStatus)){
				if(FORBeneficiaryDAO.FOR_SUCCESS.equalsIgnoreCase(newStatus) ||
						FORBeneficiaryDAO.FOR_FAILURE.equalsIgnoreCase(newStatus)){
					isValid = true;
				}
				else{
					isValid = false;
				}
			}
			else if(FORBeneficiaryDAO.FOR_GLS_CREDIT_FAILURE.equalsIgnoreCase(currentStatus)){
				//GLS credit failure will come only during F1 or F2 or ERR. cases 
				//At that scenario to re try the fund transfer try with ofac_success
				if(FORBeneficiaryDAO.FOR_OFAC_SUCCESS.equalsIgnoreCase(newStatus)){
					isValid = true;
				}
				else{
					isValid = false;
				}
			}
			else if(FORBeneficiaryDAO.FOR_CANCELLED.equalsIgnoreCase(currentStatus)){
				isValid = false;
			}
			else if(FORBeneficiaryDAO.FOR_FAILURE.equalsIgnoreCase(currentStatus)){
				isValid = false;
			}
		}
		logger.info("isValidFTStatusChange(String, String) - ends");
		return isValid;
	}
	
	/**
	 * This method will calculate the service tax based on the given debit amount.  
	 * 
	 * @param debitAmount
	 * @return
	 */
	
	
	public double getServiceTaxAmount(double amount){
		logger.info("getServiceTaxAmount(String) - starts");
		double tax = 0;
		
		
		
		if(amount >= 0 && amount <= 100000){
			tax = (amount * .12)/100;
			tax = (tax<30)? 30 : tax;
		} 
		else if(amount > 100000 && amount <= 1000000){
			tax = (100000 * .12)/100;
			tax = (tax<30)? 30 : tax;
			//tax = tax + 120 + (((amount - 100000) * .06)/100);
			tax = tax + (((amount - 100000) * .06)/100);
		}
		else if(amount > 1000000){	 
			tax = (100000 * .12)/100;
			tax = (tax<30)? 30 : tax;
			//tax = tax + 120 + (((900000) * .06)/100);
			tax = tax + (((900000) * .06)/100);
			tax = tax + 660 + (((amount - 1000000) * .012)/100);
			tax = (tax>6000)? 6000 : tax;
		}
		//tax + 3% of tax for education cess 
		tax = Math.round(tax + ((tax * 3)/100));
		logger.info("debit Amount - "+amount+" calculated tax - "+tax);
		logger.info("getServiceTaxAmount(String) - ends");
		return tax;
	}

	
	
	public String getUSDAmountFormat(Double amount) {
		logger.info("getUSDAmountFormat(..) Starts here");
		if (amount == null){
			amount = new Double(0.0);
		}
		DecimalFormat f = new DecimalFormat("################.##");
		String formattedAmount = f.format(amount);
		logger.info("Formatter amount - "+formattedAmount);
		logger.info("getUSDAmountFormat(..) Ends here");
		return formattedAmount;
	}
	
	/**
	 * This Method will obtain the commission amount 
	 * @param forPaymentDetails
	 * @return
	 */
	
	public double getCommissionAmount(String bankCode){
		logger.info("getCommissionAmount - starts");
		
		double commissionamount = 0;
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		
		try{
			Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
			if(data != null){
				String CommissionAmt = (String) data.get(FORBeneficiaryDAO.FOR_GLS_COMMISSION_RATE + bankCode );
				commissionamount = Double.parseDouble(CommissionAmt);
			}
		}
		catch(Exception excep){
			logger.error("Exception while getting Commission Rate", excep);
			response.setErrorCode("FOR010");
		}

		logger.info("getCommissionAmount - ends");
		return commissionamount;
	}
	
	/**
	 *  This Method get check debit Account is for SBI staff 
	 *  
	 * @param forPaymentDetails
	 * @return
	 */
	
	public boolean checkStaffAccount(String debitAccNo) {
		try {
			
			
		} catch (Exception  e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	
	public String updateTransactionAmountDetails(FORPaymentDetails forPaymentDetails){
		logger.info("updateTransactionAmountDetails(FORPaymentDetails) - starts");
		int result = forBeneficiaryDAOImpl.updateTransactionAmountDetails(forPaymentDetails);
		String responseString = "";
		if(result == 1){
			responseString = "success|FT status updated successfully.";
			logger.info("FT status updated successfully.");
		}else{
			responseString = "failure|Invalid Transaction ID or Transaction ID not found.";
			logger.error("Invalid Transaction ID or Transaction ID not found.");
		}
		logger.info("updateTransactionAmountDetails(FORPaymentDetails) - ends");
		return responseString;
	}
	
	public String updateFTStatusDetails(String transactionId, String status, String statusDesc, 
			String remarks, String userName){
		logger.info("updateFTStatusDetails(String, String, String, String, String) - starts");
		int result = forBeneficiaryDAOImpl.updateTransactionStatus(transactionId, status, statusDesc, remarks, userName);
		String responseString = "";
		if(result == 1){
			responseString = "success|FT status updated successfully.";
			logger.info("FT status updated successfully.");
		}else{
			responseString = "failure|Invalid Transaction ID or Transaction ID not found.";
			logger.error("Invalid Transaction ID or Transaction ID not found.");
		}
		logger.info("updateFTStatusDetails(String, String, String, String, String) - ends");
		return responseString;
	}
	
	
	
	/**
	 * This method will construct all the parameters that are required for FOR Fund Transfer.
	 * These parameters are used in FORRequestMapper.
	 * 
	 * @param transactionId
	 * @return
	 */
	public Map constructFORFundTransferParameters(String transactionId){
		logger.info("constructFORFundTransferParameters(String) - starts");
		
		//FORPaymentDetails forPaymentDetails = getTransactionDetails(transactionId, "", ""); //change by Other Channel
		FORPaymentDetails forPaymentDetails = getTransactionDetails(transactionId, ""); //change by Other Channel
		
		
		Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
		/*
		String forAccountNumber = "00003197776003006";//(String) data.get("FOR_GLS_CREDIT_ACCOUNT_NUMBER_"+forPaymentDetails.getDebitBankCode());
		String forBranchCode = "00300";//(String) data.get("FOR_GLS_CREDIT_BRANCH_CODE_"+forPaymentDetails.getDebitBankCode());
		
		String commAccountNumber = "00003197776003006";//(String) data.get("FOR_GLS_COMMISSION_ACCOUNT_NUMBER_"+forPaymentDetails.getDebitBankCode());
		String commBranchCode = "00300";//(String) data.get("FOR_GLS_COMMISSION_BRANCH_CODE_"+forPaymentDetails.getDebitBankCode());
		
		String staxAccountNumber = "00003197776003006";//(String) data.get("FOR_GLS_STAX_ACCOUNT_NUMBER_"+forPaymentDetails.getDebitBankCode());
		String staxBranchCode = "00300";//(String) data.get("FOR_GLS_STAX_BRANCH_CODE_"+forPaymentDetails.getDebitBankCode());
		*/
		
		String forAccountNumber = data.get("FOR_GLS_CREDIT_ACCOUNT_NUMBER_"+forPaymentDetails.getDebitBankCode()).toString();
		String forBranchCode = data.get("FOR_GLS_CREDIT_BRANCH_CODE_"+forPaymentDetails.getDebitBankCode()).toString();
		
		double forTransferAmount = Math.ceil(forPaymentDetails.getExchangeRate().doubleValue() * 
				forPaymentDetails.getAmount().doubleValue());
		
		double totalDebitAmount = forTransferAmount + forPaymentDetails.getCommissionAmount().doubleValue()
				+ forPaymentDetails.getServiceTax().doubleValue();
		
		// Setting for 2 decimal places
		totalDebitAmount = Double.parseDouble(getUSDAmountFormat(totalDebitAmount));
		logger.info("totalDebitAmount in FORPaymentBp --- >" + totalDebitAmount);
		
		Map forFTParams = new HashMap();
		forFTParams.put("transactionId", forPaymentDetails.getTransactionId());
		forFTParams.put("debitAccountNo", forPaymentDetails.getDebitAccountNo());
		forFTParams.put("debitBranchCode", forPaymentDetails.getDebitBranchCode());
		forFTParams.put("bankCode", forPaymentDetails.getDebitBankCode());
		forFTParams.put("transactionId", forPaymentDetails.getTransactionId());
		forFTParams.put("debitAmount", ""+totalDebitAmount);//"100");
		forFTParams.put(ServiceConstant.AMOUNT_TRANSFER, ""+totalDebitAmount);
		forFTParams.put(ServiceConstant.CREDIT_AMOUNT_TRANSFER, ""+totalDebitAmount);
		forFTParams.put("merchantCode", "FOR");
		forFTParams.put("userName", forPaymentDetails.getUserName());
		forFTParams.put("transactionRemarks", forPaymentDetails.getPurposeOfRemit());
		forFTParams.put(ServiceConstant.TRANSACTION_NAME, "FOR");
		
		/*
		forFTParams.put("creditAccountNo", forAccountNumber);
		forFTParams.put("creditBranchCode", forBranchCode);
		forFTParams.put(ServiceConstant.CREDIT_TXN_COUNT, "1");
		*/
		
		if(forTransferAmount <= 0){
			logger.error("Fund transfer amount - "+forTransferAmount);
			logger.info("constructFORFundTransferParameters(String) - ends");
			return null;
		}
		//forFTParams.put("forTransferAmount", ""+forTransferAmount);
		forFTParams.put("forTransferAmount", ""+totalDebitAmount);
		forFTParams.put("creditAccountNo", forAccountNumber);
		forFTParams.put("creditBranchCode", forBranchCode);
		
		/*forFTParams.put("commissionAmount", forPaymentDetails.getCommissionAmount().toString());
		forFTParams.put("commissionAccountNo", commAccountNumber);
		forFTParams.put("commissionBranchCode", commBranchCode);
		
		forFTParams.put("staxAmount", forPaymentDetails.getServiceTax().toString());
		forFTParams.put("staxAccountNo", staxAccountNumber);
		forFTParams.put("staxBranchCode", staxBranchCode);		
		
		forFTParams.put(ServiceConstant.CREDIT_TXN_COUNT, "3");
		*/
		forFTParams.put(ServiceConstant.CREDIT_TXN_COUNT, "1");
		
		logger.info("constructFORFundTransferParameters(String) - ends");
		return forFTParams;
	}
	
	public Map constructFORReverseFundTransferParameters(String transactionId){
		logger.info("constructFORFundTransferParameters(String) - starts");
		//FORPaymentDetails forPaymentDetails = getTransactionDetails(transactionId, "", "");
		FORPaymentDetails forPaymentDetails = getTransactionDetails(transactionId, "");
		
		Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
		
		//Need to change this account number 
		String forAccountNumber = "00003197776003006";//(String) data.get("FOR_GLS_CREDIT_ACCOUNT_NUMBER");
		String forBranchCode = "00300";//(String) data.get("FOR_GLS_CREDIT_BRANCH_CODE");
		
		Map forFTParams = new HashMap();
		forFTParams.put("transactionId", forPaymentDetails.getTransactionId());
		forFTParams.put("debitAccountNo", forAccountNumber);
		forFTParams.put("debitBranchCode", forBranchCode);
		forFTParams.put("bankCode", forPaymentDetails.getDebitBankCode());
		forFTParams.put("transactionId", forPaymentDetails.getTransactionId());
		forFTParams.put("debitAmount", "100");
		forFTParams.put(ServiceConstant.AMOUNT_TRANSFER, "100");
		forFTParams.put(ServiceConstant.CREDIT_AMOUNT_TRANSFER, "100");
		// Main change added for Service Account
		forFTParams.put(ServiceConstant.CREDIT_AMOUNT_TRANSFER, ""+forPaymentDetails.getServiceTax());
		
		forFTParams.put("merchantCode", "FOR");
		forFTParams.put("userName", forPaymentDetails.getUserName());
		forFTParams.put("transactionRemarks", "FOR Reversal for Transaction ID - "+forPaymentDetails.getTransactionId());
		forFTParams.put(ServiceConstant.TRANSACTION_NAME, "FOR");
		
		forFTParams.put("creditAccountNo", forPaymentDetails.getDebitAccountNo());
		forFTParams.put("creditBranchCode", forPaymentDetails.getDebitBranchCode());
		forFTParams.put(ServiceConstant.CREDIT_TXN_COUNT, "1");
		
		logger.info("constructFORFundTransferParameters(String) - ends");
		return forFTParams;
	}
	
	/**
	 * This method is to post XML data to URL
	 * @param urlString
	 * @param data
	 * @return
	 */
	public String postXML(String urlString, String[][] data) throws Exception{
		logger.info("postXML(String, String) - starts");
		String responseString = httpsConnection.postData(null, urlString, data, "POST"); ;
		
		//String responseString = httpMessage.sendMessage(data, urlString); ;
		logger.info("response String - "+responseString);
		logger.info("postXML(String, String) - ends");
		return responseString;
	}

	//Code to perform server side validations
	/**
	 * Method to validate the Debit account number selected from the screen against the 
	 * list of debit accounts mapped for that user.
	 * 
	 */
	public boolean validateDebitAccount(Map inputValues){
		logger.info("validateDebitAccount(Map inputValues, List availableAccountInfo) - begins");
    	boolean result = false;
    	logger.info("Input values --- " +inputValues);
		List availableAccountInfo = (List) inputValues.get("debitAccountList");;
    	String debitAccNo = (String)inputValues.get("debitAccountNo");
    	String debitBranchCode = (String)inputValues.get("debitBranchCode");
    	String debitAccType = (String)inputValues.get("debitAccountType");
    	//LOGGER.info("debitAccNo:::"+debitAccNo+"  debitBranchCode:::"+debitBranchCode+"  debitAccType:::"+debitAccType);
    	if(debitAccNo == null || debitAccNo.trim().length() <= 0 ||
     			debitBranchCode == null || debitBranchCode.trim().length() <= 0 || 
    			debitAccType == null || debitAccType.trim().length() <= 0){
    		logger.error("Debit Account Information is not valid.");
    		return result;
    	}
    	Iterator iterator = availableAccountInfo.listIterator();
    	while(iterator.hasNext()){
    		Account acc = (Account)iterator.next();
    		if(debitAccNo.equals(acc.getAccountNo()) && debitBranchCode.equals(acc.getBranchCode())
    				&& debitAccType.equals(acc.getProductType())){
    			result = true;
    		}
    	}
    	logger.info("Is Valid Debit Acc - "+result);
    	logger.info("validateDebitAccount(Map inputValues, List availableAccountInfo) - ends");
    	return result;
    }
	
	/**
	 * 
	 * @param inputValues
	 * Method check whether the new added beneficiary transacting amount exceeds above Rs.50000/-
	 * @return
	 */
	
	public boolean validateBenTransacAmount(Map inputValues) {
		logger.info("validateBenTransacAmount(inputValues) - starts");
		int result = forBeneficiaryDAOImpl.getBenActivatedDays(inputValues.get("userName").toString(),inputValues.get("benId").toString());
		logger.info("Beneficary Activated days ::" +result);
		boolean  isValidAmount = false;
		if(result <= 5){
			double transcINRAmount = forBeneficiaryDAOImpl.getBenINRTransacAmount(inputValues.get("userName").toString(),inputValues.get("benId").toString());
			logger.info("Transaction Amount for first five days ::" +transcINRAmount);
			transcINRAmount = transcINRAmount + Double.parseDouble(inputValues.get("forINRAmount").toString());
			logger.info("Transaction Amount for first five days + current Transaction Amount ::" +transcINRAmount);
			if (transcINRAmount > FOR_TOTAL_INR_INITIAL_BEN_TRANSACTION_LIMIT) {
				isValidAmount = false;
			} else {
				isValidAmount = true;
			}
		}else{
			isValidAmount = true;
		}
		logger.info("Validate ben Transaction ::" + isValidAmount);
		logger.info("validateBenTransacAmount(inputValues) - ends");

		return isValidAmount;
	}
	
	
	public int insertRequestResponseDetails(Map inputValues){
		logger.info("insertRequestResponseDetails(Map inputValues) - begins");
		int result = -1;
		if(inputValues != null){
			logger.info("Input values - "+inputValues);
			String requestId = inputValues.get("requestId").toString();
			String serverName = inputValues.get("serverName").toString();
			String clientIP = inputValues.get("clientIP").toString();
			
			String responseString = inputValues.get("responseString").toString();
			String requestString = inputValues.get("requestString").toString();

			String requestTime = "";
			String responseTime = "";
			if(inputValues.get("startTime") != null && inputValues.get("startTime") instanceof Long){
				Long startTime = (Long)inputValues.get("startTime");
				Date inputDate = new Date(startTime.longValue());
				Format formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.S");
				requestTime = formatter.format(inputDate);
				responseTime = formatter.format(new Date(System.currentTimeMillis()));
			}
			result = forBeneficiaryDAOImpl.insertRequestResponseDetails(requestId, requestString, 
					responseString,	clientIP, serverName, requestTime, responseTime);
		}
		logger.info("insertRequestResponseDetails(Map inputValues) - ends");
		return result;
	}
	
	public  boolean dateBtw(String dateStr){
		Calendar inputDate = Calendar.getInstance();
		try{
			logger.info(" Input Transaction date - "+dateStr);
			inputDate.setTime(new SimpleDateFormat("dd/MM/yyyy").parse(dateStr));
		}
		catch(Exception excep){
			excep.printStackTrace();
			return false;
		}
		
		GregorianCalendar fyStartDate = null;
		Calendar today = Calendar.getInstance();
		if(today.get(Calendar.MONTH) <= 2){
			fyStartDate = new GregorianCalendar(today.get(Calendar.YEAR)-1, 3, 1);//1st April of previous year
		}
		else{
			fyStartDate = new GregorianCalendar(today.get(Calendar.YEAR), 3, 1);//1st April of current year
		}
			logger.info("Start date - "+new SimpleDateFormat("dd-MMM-yyyy").format(fyStartDate.getTime()));
			logger.info("End date - "+new SimpleDateFormat("dd-MMM-yyyy").format(System.currentTimeMillis()));

		if(inputDate.before(fyStartDate) || inputDate.after(today)){
			return false;
		}
		logger.info("valid");
		return true;  
	}
	
	public boolean validTransactionDay() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("E/MM/yyyy/HH/mm");
		Calendar calendar = Calendar.getInstance();
        String strTxnDate = simpleDateFormat.format(calendar.getTime());
        String[] dateArray = strTxnDate.split("/");
        String strDay = dateArray[0];
        logger.info(" Transaction Day -- " + strDay);
		//strDay = "Sat";
        if ("Sat".equalsIgnoreCase(strDay) || "Sun".equalsIgnoreCase(strDay) ) {
        	logger.info(" No transaction allowed on saturdays and sunday ");
        	return false;
        }
		return true;
	}
	
	public boolean validCutOffTime(Map inputParams) {
		Timestamp payDate = StringUtils.currentTimeStamp();
		boolean validCutOffTime = cutOffTimeUtils.isValidDateAndTime(payDate, "FOR",(String)inputParams.get("bankCode"));
		logger.info("FOR Payment BP validCuttoff time -- " + validCutOffTime);
		return validCutOffTime;
	}
	
	public boolean validOneYearAccount(String accOpenDate) {	
		boolean isValidOneYearAcc = false;
		String getOneYearAccount = forBeneficiaryDAOImpl.getAccountOpenDate(accOpenDate);
		if (getOneYearAccount.equalsIgnoreCase("TRUE")) {
			isValidOneYearAcc = true;
		} else {
			isValidOneYearAcc = false;
		}
		return isValidOneYearAcc;
	}
	
	public boolean validINBTransactionLimit(String benId, double limit, String userName, String bankCode){
		return false;
	}
	
	public AccountInformationBP getAccountInformationBP() {
		return accountInformationBP;
	}

	public void setAccountInformationBP(AccountInformationBP accountInformationBP) {
		this.accountInformationBP = accountInformationBP;
	}

	public FORBeneficiaryDAO getForBeneficiaryDAOImpl() {
		return forBeneficiaryDAOImpl;
	}

	public void setForBeneficiaryDAOImpl(FORBeneficiaryDAO forBeneficiaryDAOImpl) {
		this.forBeneficiaryDAOImpl = forBeneficiaryDAOImpl;
	}
	
	public ReferenceDataCache getReferenceDataCache() {
		return referenceDataCache;
	}

	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	
	public FORUtil getForUtil() {
		return forUtil;
	}

	public void setForUtil(FORUtil forUtil) {
		this.forUtil = forUtil;
	}
	
	public HttpsConnection getHttpsConnection() {
		return httpsConnection;
	}

	public void setHttpsConnection(HttpsConnection httpsConnection) {
		this.httpsConnection = httpsConnection;
	}
	
	public void setCutOffTimeUtils(CutoffTimeUtils cutOffTimeUtils) {
		this.cutOffTimeUtils = cutOffTimeUtils;
	}

	private static final String FOR_BEN_STATUS_APPROVED = "approved";
	private static final String FOR_BEN_STATUS_ACTIVE = "active";
	
	private static final String FOR_TRANSFER_STATUS_OP = "ofac_pending";
	private static final String FOR_TRANSFER_STATUS_CANCELLED = "cancelled";

	public static final String FOR_GLS_EXRATE_URL = "https://remit.onlinesbi.com/remx/remxexrate.htm";
	public static final String FOR_GLS_FT_INIT_URL = "https://remit.onlinesbi.com/remx/remxtransinitreceiver.htm";
	public static final String FOR_GLS_FT_ADVICE_URL = "https://remit.onlinesbi.com/remx/remxtransreceiver.htm";
	public static final String FOR_GLS_OFAC_URL = "https://remit.onlinesbi.com/remx/remxofacreceiver.htm";
	public static final String FOR_GLS_OC_URL = "https://remit.onlinesbi.com/remx/remxocreceiver.htm";    
	

	
	String[] productList={"10291401|A1","10291481|A1","10111401|A1","10291431|A1","10921431|A1","10941431|A1",
			  "10951431|A1","10961431|A1","10971431|A1","10291441|A1","10921441|A1","10941441|A1",
			  "10951441|A1","10961441|A1","10971441|A1","10291451|A1","10921451|A1","10941451|A1",
			  "10951451|A1","10961451|A1","10971451|A1","10291461|A2","10921461|A1","10941461|A1",
			  "10951461|A1","10961461|A1","10971461|A1","60591001|A4","60507001|A4","10111101|A1",
			  "10203401|A1","50113401|A4","50113401|A2","10113401|A1"};
	
			 //60507001	A4	OD Banks Deposits (PER)
			 //anupsen A1 10111101 SBCHQ-GEN-PUB-IND-NONRURAL-INR / 10203401|A1
			 //probhat neogy  00000011303566834 60591001	A4	OD PERSONAL LOAN STAFF
			 //10113401|A1 SBCHQ-GEN-STF IND-ALL-INR.  Deepak
			 //60507001|A4 OD Banks Deposits (PER)
			 //10203401|A1 SBCHQ-PEN-STF-IND-ALL-INR
			 //50113401|A4 CA-GEN-STF-IND-ALL-INR
			 //50113401|A2 CA-GEN-STF-IND-ALL-INR	 
}

