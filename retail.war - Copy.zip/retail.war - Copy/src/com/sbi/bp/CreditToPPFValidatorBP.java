/*
 * CreditToPPFValidatorBP.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants added
package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class CreditToPPFValidatorBP extends TransactionValidatorBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;
	
	private UserDAO userDAOImpl;

	

	/**
	 * Call validator.validateInterBank method Call validator.validateLimit
	 * method Call validator.validateTxnRights method
	 * validator.validateAccountNature method if debitbranchCode and
	 * creditBranchCode are different { Call validator.validateTodaysTxnLimit
	 * method } if debitbranchCode and creditBranchCode are equal {
	 * validator.validateInterBranchLimit method } if bankSystem is NonCore {
	 * validator.validateTransfer method }
	 * 
	 * if any one of the method throws Exception then throws
	 * SBIApplicationException exception else return true
	 * 
	 * @param transaction
	 * @return boolean
	 */
	public boolean validate(Transaction transaction)
			throws SBIApplicationException {
		this.transaction = transaction;
		if (transaction != null) {
			logger.info("validate(Transaction transaction)"
					+ LoggingConstants.METHODBEGIN);
			if (logger.isDebugEnabled()) {
				logger.debug("transaction :" + transaction.toString());
			}
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime()); 
			validator.validateInterBank(transaction.getDebit().getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode());
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
			}

			validator.validateAmount(transaction.getDebit().getAmount());
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount() return true");
			}
			//Added New validation Method to override all validation pertaining to the Limit
			validator.validateCategoryJLimit(transaction.getDebit().getUserName(), transaction.getDebit().getAmount(), scheduledDate, transaction.getBankCode());
			logger.info("validateCategoryJLimit Independent PPF Txn limit Method returns true");
			TransactionLeg[] creditLeg = transaction.getCredit();
	    	String accountNature = creditLeg[0].getAccountNature();
	    	
			logger.info("account nature  "+ accountNature);
//			added by viswalakshmy for PPF CR2633 starts

			if((accountNature!=null) && (accountNature.equals("1")))
			{
				validator.validateAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getUserName(),
			          transaction.getDebit().getAmount());
			
				if (logger.isDebugEnabled()) {
				logger
						.debug("validateAcctLimit method - true");
				}
				
				//Added newly to check the Newly added Third party transfer limit
				//Added to set the Indicator for Third party Differentiation
				
				int newBeneficairyCount=0;
				newBeneficairyCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "THIRDPARTY",transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo() , "RETAIL",transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
				if(newBeneficairyCount>0){
					transaction.getDebit().setIsNewlyAddedTp("YES");
					
					if(transaction.isScheduled()||transaction.isSiTxn()){
						SBIApplicationException.throwException("TPB006");
					}
					else{
						validator.newBeneficiaryAdditionLimitValidation(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "RETAIL", "THIRDPARTY", transaction.getBankCode(),transaction.getDebit().getAmount(),transaction.getCredit()[0].getBranchCode());
					}
				}
			}

        validator.validateMinimumAmount(transaction.getDebit().getAmount(),transaction.getName());
            
            validator.validateMinimumAmount(transaction.getCredit()[0].getAmount(),transaction.getName());
                    if (logger.isDebugEnabled()) 
                        logger.debug("validateMinimumAmount () method - true");
            logger.info("validateMinimumAmount(transaction.getDebit().getAmount()) method - true");            
            //End of CR 3081
            
            	validator.validateMulitplesOfHundred(transaction.getDebit().getAmount());
				validator.validateMulitplesOfHundred(transaction.getCredit()[0].getAmount());
				
				if (logger.isDebugEnabled()) 
				logger.debug("validateMulitplesOfHundred(transaction.getDebit().getAmount()) method - true");
				

			validator.validateTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), new Integer(
							BPConstants.DEBIT_NO));
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
			}
			
			
			
			if((accountNature!=null)&&(!accountNature.equals("1"))) //added by viswalakshmy for PPF CR2633 
			{
				 validator.validateTxnRights(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),transaction.getCredit()[BPConstants.ZERO_INT].getUserName(), new Integer(BPConstants.CREDIT_NO));
					if (logger.isDebugEnabled()) {
						logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
					}	
			}
			
			
			String txnPath = transaction.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
            
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);

			logger.info("validate(Transaction transaction)"
					+ LoggingConstants.METHODEND);
			//Changed by Lenin for Kony Apps
			/*if(transaction.getMobileFlag()!=null && "yes".equalsIgnoreCase(transaction.getMobileFlag())){
				logger.info("Mobile category wise validation");
						validator.validateMobileCategoryJLimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode());
			}*/	
			//Added by Lenin for Kony
			if(transaction.getMobileFlag()!=null){
				String channel = null;
				if( "yes".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "MINB";
				}else if("map_inb".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "map_inb";
				}
				validator.validateMobileCategoryJLimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode(), channel);
			}

		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return true;
	}

	/**
	 * Validator injection
	 * 
	 * @param validator
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

}

