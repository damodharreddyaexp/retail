package com.sbi.bp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.AutoSweepDAO;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.AutoSweepModel;
import com.sbi.model.AutoSweepUserDetailsModel;

@SuppressWarnings(value = "unchecked")
public class AutoSweepBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private CoreDAOImpl coreDAOImpl;

	private AutoSweepDAO autoSweepDAOImpl;

	public List postEnquriyToCore(Map requestMap) throws DAOException,
			SBIApplicationException {

		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno=" + requestMap.get("txnno") + " ::"
				+ responseList);

		return responseList;
	}

	public List postToCore(Map requestMap) throws DAOException,
			SBIApplicationException {
		logger.info("postToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		if (responseList != null && responseList.size() > 0) {
			Map resMap = (Map) responseList.get(0);
			String status = (String) resMap.get("status");
			String statement = (String) resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			if (status != null && ("F1".equals(status))
					|| ("F2".equals(status))) {
				SBIApplicationException.throwException("F1");
			} else if (status != null && "ERR.".equals(status)) {
				if (errorCode != null && "2860".equals(errorCode.trim())) {
					SBIApplicationException.throwException("PTC018");
				} else {
					SBIApplicationException.throwException("PTC002");
				}
			}
		}
		logger.info("postToCore(...) Ends Here");
		return responseList;
	}

	public List postToCore400(Map requestMap) throws DAOException,
			SBIApplicationException {
		logger.info("postToCore400(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		if (responseList != null && responseList.size() > 0) {
			Map resMap = (Map) responseList.get(0);
		}
		logger.info("postToCore(...) Ends Here");
		return responseList;
	}

	public List construct400Request(Map inputParams) {
		logger.info("construct400Request(...) Starts Here");
		Map enquiryMap = new HashMap();
		enquiryMap.put("txnno", "000400");
		enquiryMap.put("bankCode", ((String) inputParams.get("bankCode")));
		enquiryMap.put("account_no", inputParams.get("account_no"));
		List requestToCore = postToCore400(enquiryMap);
		logger.info("construct400Request(...) Ends Here");
		return requestToCore;
	}

	public List construct007050Request(Map inParams) {
		logger.info("construct007050Request(...) Starts Here");

		String debitAccountNumber = (String) inParams.get("account_no");
		String bankCode = (String) inParams.get("bankCode");
		String userName = (String) inParams.get("userName");
		logger.info("debitAccountNumber1111111:::" + debitAccountNumber);
		logger.info("bankCode1111111:::" + bankCode);
		logger.info("userName1111111:::" + userName);

		Map outParam = new HashMap();
		outParam.put("txnno", "007050");
		outParam.put("bankCode", bankCode);
		String autoSweepReferenceNo = getBankRefNo();
		logger.info("autoSweepReferenceNo1111111:::" + autoSweepReferenceNo);
		outParam.put("reference_number", autoSweepReferenceNo);
		outParam.put("account_no", debitAccountNumber);
		outParam.put("enquiry_type", "9");
		outParam.put("userName", userName);
		List requestToCore = postToCore(outParam);
		logger.info("construct007050Request(...) Ends Here");
		return requestToCore;
	}

	public AutoSweepModel populate007050Response(AutoSweepModel asModel,
			Map inParams) {
		logger.info("populate007050Response(...) Starts Here");

		logger.info("populate007050Response(...) account_no:"
				+ (String) inParams.get("account_no"));
		asModel.setAccount_no((String) inParams.get("account_no"));
		asModel.setName(((String) inParams.get("Name")));
		asModel.setOld_Home_Branch(((String) inParams.get("Old_Home_Branch")));
		asModel.setCurrency(((String) inParams.get("Currency")));
		asModel.setOld_acc_type(((String) inParams.get("Old_acc_type")));
		asModel
				.setOld_Int_category(((String) inParams.get("Old_Int_category")));
		asModel.setOld_seg_code(((String) inParams.get("Old_seg_code")));
		asModel.setOld_desc(((String) inParams.get("Old_desc")));
		asModel.setNew_Home_Branch(((String) inParams.get("New_Home_Branch")));
		asModel.setNew_Acc_type(((String) inParams.get("New_Acc_type")));
		asModel
				.setNew_Int_Category(((String) inParams.get("New_Int_Category")));
		asModel
				.setNew_segment_code(((String) inParams.get("New_segment_code")));

		logger.info("populate007050Response(...) Ends Here " + asModel);
		return asModel;
	}

	public List construct007046Request(AutoSweepModel asModel, Map inParams) {
		logger.info("construct007046Request(...) Starts Here");
		Map outParam = new HashMap();
		String bankCode = (String) inParams.get("bankCode");
		outParam.put("txnno", "007046");
		outParam.put("bankCode", bankCode);
		logger.info("construct007046Request(...) account_no:"
				+ asModel.getAccount_no());
		outParam.put("Account_no", asModel.getAccount_no());
		outParam.put("Name", asModel.getName());
		outParam.put("Old_Home_Branch", asModel.getOld_Home_Branch());
		outParam.put("Currency", asModel.getCurrency());
		outParam.put("Old_Account_Type", asModel.getOld_acc_type());
		outParam.put("Old_Int_Category", asModel.getOld_Int_category());
		outParam.put("Old_Segment_Code", asModel.getOld_seg_code());
		outParam.put("Old_Description", asModel.getOld_desc());
		outParam.put("New_Home_Branch", asModel.getNew_Home_Branch());
		outParam.put("New_Account_type", asModel.getToProductType());
		outParam.put("New_Int_category", asModel.getToSubCat());
		outParam.put("New_segment_Code", asModel.getNew_segment_code());

		List requestToCore = postToCore(outParam);
		logger.info("construct007046Request(...) Ends Here");
		return requestToCore;
	}

	public List construct060422Request(Map inParams) {
		logger.info("construct060422Request(...) Starts Here");
		
		String thresholdAmount=(String)inParams.get("thresholdAmount")+"000+";
		String resultantBalance=(String)inParams.get("resultantBalance")+"000+";
		logger.info("thresholdAmount::"+thresholdAmount+"resultantBalance:::"+resultantBalance);

		Map outParam = new HashMap();
		outParam.put("txnno", "060422");
		outParam.put("bankCode", ((String) inParams.get("bankCode")));
		outParam.put("MODULE_NAME","ETDR");//to point sbi_core_interface
		String autoSweepReferenceNo = getBankRefNo();

		outParam.put("reference_no", autoSweepReferenceNo);
		outParam.put("account_no",
				((String) inParams.get("debitAccountNumber")));
		outParam.put("cr_acctno", "00000000000000000");
		outParam.put("sweep_type", "2");// hard coded
		outParam.put("frequency_code", ((String) inParams.get("sweepCycle")));// user
																		// input
		outParam.put("start_date", ((String) inParams.get("startDate")));// user
																			// input
		outParam.put("end_date", "31129999");
		outParam.put("second_acct_system", "DEP");
		outParam.put("Threshold_Amount", thresholdAmount);// user input
		outParam.put("Resultant_balance", resultantBalance);// user input
		outParam.put("Sweep_multiple", "1000000+");// hard coded
		outParam.put("Sav_Plus_indicator", "Y");// hard coded

		List requestToCore = postToCore(outParam);

		logger.info("construct060422Request(...) Ends Here");
		return requestToCore;
	}

	public String getBankRefNo() {
		logger.info("getBankRefNo(...) Starts Here");
		String autoSweepReferenceNo = null;
		try {
			autoSweepReferenceNo = autoSweepDAOImpl.createSequenceID();
			logger.info("autoSweepReferenceNo:::" + autoSweepReferenceNo);
		} catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(),
					daoExc);
		}
		logger.info("getBankRefNo(...) Ends Here");
		return autoSweepReferenceNo;
	}

	public Map getNewProductCode(String productCode) {
		logger.info("getNewProductCode(...) Starts Here");
		String autoSweepReferenceNo = null;
		Map newProductCodemap = new HashMap();
		try {
			newProductCodemap = autoSweepDAOImpl.getNewProductCode(productCode);
			logger.info("autoSweepReferenceNo:::" + newProductCodemap);
		} catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(),
					daoExc);
		}
		logger.info("getNewProductCode(...) Ends Here");
		return newProductCodemap;
	}

	public Map getCustomerDetails(Map inParam) {
		logger.info("getCustomerDetails(...) Starts Here");
		Map CustomerMap = null;
		try {

			CustomerMap = autoSweepDAOImpl.findUserDetails(inParam);

		} catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(),
					daoExc);
		}
		logger.info("getCustomerDetails(...) Ends Here");
		return CustomerMap;
	}

	public AutoSweepUserDetailsModel populate60459Response1(
			AutoSweepUserDetailsModel autoSweepUserDetailsModel, Map inParams) {
		logger.info("populate60459Response(...) Starts Here");
		if ((String) inParams.get("customerName") != null
				&& ((String) inParams.get("customerName")).length() > 0) {
			autoSweepUserDetailsModel.setCustomerName((String) inParams
					.get("customerName"));
		} else {
			autoSweepUserDetailsModel.setCustomerName(" ");
		}
		if ((String) inParams.get("customerAddress") != null
				&& ((String) inParams.get("customerAddress")).length() > 0) {
			autoSweepUserDetailsModel.setAddress1((String) inParams
					.get("customerAddress"));
		} else {
			autoSweepUserDetailsModel.setAddress1(" ");
		}

		if ((String) inParams.get("branchName") != null
				&& ((String) inParams.get("branchName")).length() > 0) {
			autoSweepUserDetailsModel.setBranchName((String) inParams
					.get("branchName"));
		} else {
			autoSweepUserDetailsModel.setBranchName(" ");
		}

		if ((String) inParams.get("branchAddress") != null
				&& ((String) inParams.get("branchAddress")).length() > 0) {
			autoSweepUserDetailsModel.setBranchAddress((String) inParams
					.get("branchAddress"));
		} else {
			autoSweepUserDetailsModel.setBranchAddress(" ");
		}

		logger.info("populate60459Response(...) Ends Here");
		return autoSweepUserDetailsModel;
	}

	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}

	public void setAutoSweepDAOImpl(AutoSweepDAO autoSweepDAOImpl) {
		this.autoSweepDAOImpl = autoSweepDAOImpl;
	}

}
