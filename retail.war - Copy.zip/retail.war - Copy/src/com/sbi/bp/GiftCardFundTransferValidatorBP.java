/*
 * GiftCardFundTransferValidatorBP.java
 * Created on June 24, 2010
 *
 * Copyright (c) 2007 by SBI All Rights Reserved.
 * $Header: $
 */
//History


package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class GiftCardFundTransferValidatorBP extends TransactionValidatorBP
{
   protected final Logger logger = Logger.getLogger(getClass());
   private Validator validator;
   
  
public boolean validate(Transaction transaction) throws SBIApplicationException
   {

       this.transaction = transaction;
       if (transaction != null)
       {
           logger.info("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);
           
           if (logger.isDebugEnabled())
           {
               logger.debug("transaction array:" + transaction.getCredit()[0]);
           }
           
           logger.info("transaction :"+transaction.toString());
         
           TransactionLeg credit = (TransactionLeg)transaction.getCredit()[0];
           TransactionLeg debit = (TransactionLeg)transaction.getDebit();
           
           Double amount = credit.getAmount();
           logger.info("amount:"+amount);
           logger.info("credit:"+credit);
           String userName = credit.getUserName();
           logger.info("userName:"+userName);
           String strCardDetails = credit.getThirdPartyRef();
           logger.info("strCardDetails:"+strCardDetails);
           String payeeName = debit.getNarrative2();
           String nickName = debit.getNarrative3();
           
           String debitProductCode=debit.getDebitProductCode();
           logger.info("debitProductCode::::"+debitProductCode);
           debit.setDebitProductCode("");
           logger.info("in validatorbp:"+debitProductCode+":"+payeeName+":"+nickName);
            if (logger.isDebugEnabled())
           {
               logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
           }

           validator.validateAmount(transaction.getDebit().getAmount());
           if(logger.isDebugEnabled()){
           	logger.debug("validateAmount() return true");
           }
           
           validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
           if (logger.isDebugEnabled())
           {
               logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
           }
           Date scheduledDate = null; 
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				scheduledDate = new Date();     
           //chang limit uday
			 String bankCode=transaction.getBankCode();
	            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
	            	bankCode="0";
	            }	
				validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "GiftCard");
			       logger.info("validateSubCategoryGroupBLimit method - true");
			    validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
                   transaction.getName(),transaction.getBankCode(),new Date());
         logger.info("validateCategoryBLimit method returns true");
           logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
       }
       else{ 
    	   SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
       }
       return true;
   }
   public void setValidator(Validator validator)
   {
       this.validator = validator;
   }
}

