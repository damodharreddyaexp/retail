package com.sbi.bp;

import java.io.IOException;
import java.io.StringReader;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;
import com.sbi.dao.ATMHotListingDAO;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.ATMHotListingDetails;
import com.sbi.model.UserProfile;

public class BlATMHotListingBP {
	private static Logger logger = Logger.getLogger(com.sbi.bp.ATMHotListingBP.class);
	private ATMHotListingDAO atmHotListingDAOImpl;
	//potireddy for Hotlisting ATM start
	private CoreDAOImpl coreDAOImpl;
	private SMSGatewayClient smsGatewayClient;
	
	
	
 


	static int ssize =8; 
    static char[] chars = new char[] {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
          'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
          'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
          'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
          'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
        };
	//potireddy for Hotlisting ATM end

	/**
	 * This method is used to Insert ATM XML request and response string 
	 * 
	 * @param xmlMessage
	 * @return
	 */

	public int insertRequestResponseDetails(Map inputValues){
		logger.info("insertRequestResponseDetails(inputValues - begins");
		ATMHotListingDetails atmHotListingDetails = new ATMHotListingDetails();
		int result = 0;
		if(inputValues != null){
			//logger.info("inputValues - "+ inputValues);
			String requestTime = "";
			String responseTime = "";
			if(inputValues.get("startTime") != null && inputValues.get("startTime") instanceof Long){
				Long startTime = (Long)inputValues.get("startTime");
				Date inputDate = new Date(startTime.longValue());
				Format formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.S");
				requestTime = formatter.format(inputDate);
				responseTime = formatter.format(new Date(System.currentTimeMillis()));
			}
			//Assiging To Model
			//atmHotListingDetails.setServerName(inputValues.get("serverName").toString());
			//atmHotListingDetails.setIpAddress(inputValues.get("clientIP").toString());
			//atmHotListingDetails.setServerName("devretail");
			//atmHotListingDetails.setIpAddress("172.168.27.56");
			//atmHotListingDetails.setUserName(inputValues.get("userName").toString());
			atmHotListingDetails.setRequestString(inputValues.get("requestString").toString());
			atmHotListingDetails.setResponseString(inputValues.get("responseString").toString());
			atmHotListingDetails.setRequestTime(requestTime);
			atmHotListingDetails.setResponseTime(responseTime);
			atmHotListingDetails.setRequestType(inputValues.get("flag").toString());
			atmHotListingDetails.setRequestType(inputValues.get("flag").toString());
			result = atmHotListingDAOImpl.insertATMReqResDetails(atmHotListingDetails,inputValues.get("flag").toString(),inputValues.get("inbRefNum").toString());
		}
		logger.info("insertRequestResponseDetails(Map inputValues) - ends");
		return result;
	}

	/**
	 * This method is used to parse the ATM XML response string and generate into Map  
	 * Iterate ::: CardInquiryResp
	 * @param xmlMessage
	 * @return
	 */

	public Map parseATMXMLStringToMap(String xmlMessage){
		logger.info("parseFORXMLStringToMap(String) - begins");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Map responseMap = new LinkedHashMap();
		try{
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new StringReader(xmlMessage)));
			Element rootElement = doc.getDocumentElement();
			NodeList childNodes = rootElement.getChildNodes();
			int nodesLen = childNodes.getLength();
			int childCardInquiryOccurence=1;
			int childFSSCardDetailsOccurence=1;
			int childOPUSCardDetailsOccurence = 1;
			String vendorId="-";

			for(int i=0;i<nodesLen;i++){
				Node tmp = childNodes.item(i);
				if("CardInquiryResp".equalsIgnoreCase(tmp.getNodeName())){
					Map xchangeMap = convertCardEnquiryToMap(tmp);
					vendorId = (String)xchangeMap.get("vendorId");
					responseMap.put(tmp.getNodeName().concat(Integer.toString(childCardInquiryOccurence)), xchangeMap);
					if ("FSS".equalsIgnoreCase(vendorId)) {
						childFSSCardDetailsOccurence= Integer.parseInt(xchangeMap.get("childOccurence").toString());
					} else if ("OPUS".equalsIgnoreCase(vendorId)) {
						childOPUSCardDetailsOccurence= Integer.parseInt(xchangeMap.get("childOccurence").toString());
					}
					//logger.info("Card Inquiry Resp ::" + responseMap);
					childCardInquiryOccurence = childCardInquiryOccurence + 1;
				}
				else{
					responseMap.put(tmp.getNodeName(), tmp.getTextContent());
				}
			}
			childCardInquiryOccurence = childCardInquiryOccurence - 1;
			responseMap.put("childFSSCardDetailsOccurence", childFSSCardDetailsOccurence);
			responseMap.put("childOPUSCardDetailsOccurence", childOPUSCardDetailsOccurence);
			responseMap.put("childCardInquiryOccurence", childCardInquiryOccurence);
		}
		catch(Exception excep){
			logger.error("Exception while parsing FOR XML", excep);
			responseMap = null;
		}
		logger.info("parseFORXMLStringToMap(String) - ends");
		return responseMap;
	}

	/**
	 * This method will iteratively parse the <CardDetails> XML string
	 * and convert into Map 
	 * 
	 * @param xChangeNode
	 * @return
	 */
	private Map convertCardEnquiryToMap(Node xChangeNode){
		logger.info("convertCardEnquiryToMap(Node) - begins");
		int tmpLen = xChangeNode.getChildNodes().getLength();
		NodeList excList = xChangeNode.getChildNodes();
		Map cardEnquiryMap = new HashMap();
		int childOccurence = 1;
		String vendorId ="-";

		for(int j=0;j<tmpLen;j++){
			Node tmp = excList.item(j);
			if("CardDetails".equalsIgnoreCase(tmp.getNodeName())){
				Map cardDetailsMap = convertCardDetailsToMap(tmp, vendorId);
				cardEnquiryMap.put(tmp.getNodeName().concat(Integer.toString(childOccurence)), cardDetailsMap);
				childOccurence = childOccurence + 1;
			} else {
				if ("FSS".equalsIgnoreCase(tmp.getTextContent().toString())) {
					vendorId = tmp.getTextContent().toString();
				} else if ("OPUS".equalsIgnoreCase(tmp.getTextContent().toString()))  {
					vendorId = tmp.getTextContent().toString();
				}
				cardEnquiryMap.put(tmp.getNodeName(), tmp.getTextContent());
				cardEnquiryMap.put("vendorId",vendorId);
			}
		}
		childOccurence = childOccurence - 1;
		cardEnquiryMap.put("childOccurence", childOccurence);
		logger.info("convertCardEnquiryToMap(Node) - ends");
		return cardEnquiryMap;
	}

	/**
	 * This method will iteratively parse the <cardDetails> XML string
	 * and convert into Map 
	 * 
	 * @param xChangeNode, vendorId
	 * @return
	 */

	private Map convertCardDetailsToMap(Node xChangeNode, String vendorId){
		logger.info("convertCardDetailsToMap(Node, String) - begins");
		int tmpLen = xChangeNode.getChildNodes().getLength();
		NodeList excList = xChangeNode.getChildNodes();
		Map excMap = new HashMap();
		Timestamp timestamp = null;
		String dateString ="";
		for(int j=0;j<tmpLen;j++){
			Node tmp = excList.item(j);
			if ((tmp.getNodeName().toString().equalsIgnoreCase("IssueDate")) 
					|| (tmp.getNodeName().toString().equalsIgnoreCase("ExpiryDate"))){
				dateString = dateStringFormat(tmp.getTextContent().toString());
				excMap.put(tmp.getNodeName(), dateString);
			} else { 
				excMap.put(tmp.getNodeName(), tmp.getTextContent());
			}
		}
		excMap.put("vendorId", vendorId);	
		//logger.info("Inner Map Card Details  -- " + excMap);
		logger.info("convertCardDetailsToMap(Node, String) - ends");
		return excMap; 
	}

	
	public static String dateStringFormat(String dateString){
    	SimpleDateFormat sd1=new SimpleDateFormat("yyyy-mm-dd");
    	Date date;
    	String dateReturnString=null;
		try {
			date = sd1.parse(dateString);
	    	sd1.applyPattern("dd-mm-yyyy");
	    	dateReturnString = sd1.format(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return dateReturnString;
    }
	
	// HotList Response String
	/**
	 * This method is used to parse the ATM HotList XML response string and generate into Map  
	 * 
	 * @param xmlMessage
	 * @return
	 */

	public Map parseATMHotListingXMLStringToMap(String xmlMessage){
		logger.info("parseFORXMLStringToMap(String) - begins");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Map responseMap = new LinkedHashMap();
		try{
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new StringReader(xmlMessage)));
			Element rootElement = doc.getDocumentElement();
			NodeList childNodes = rootElement.getChildNodes();
			int nodesLen = childNodes.getLength();
			int childOccurence = 1;

			for(int i=0;i<nodesLen;i++){
				Node tmp = childNodes.item(i);
				if("HotlistResp".equalsIgnoreCase(tmp.getNodeName())){
					Map xchangeMap = convertHotListingCardToMap(tmp);
					responseMap.put(tmp.getNodeName().concat(Integer.toString(childOccurence)), xchangeMap);
					childOccurence = childOccurence + 1;
				}
				else{
					responseMap.put(tmp.getNodeName(), tmp.getTextContent());
				}
			}
			responseMap.put("childOccurence", childOccurence);
		}
		catch(Exception excep){
			logger.error("Exception while parsing FOR XML", excep);
			responseMap = null;
		}
		//logger.info("XML String -> Map - "+responseMap);
		logger.info("parseFORXMLStringToMap(String) - ends");
		return responseMap;
	}

	/**
	 * This method will iteratively parse the <HotListResp> XML string
	 * and convert into Map 
	 * 
	 * @param xChangeNode
	 * @return
	 */

	private Map convertHotListingCardToMap(Node xChangeNode){
		logger.info("convertHotListingCardToMap(Node) - begins");
		int tmpLen = xChangeNode.getChildNodes().getLength();
		NodeList excList = xChangeNode.getChildNodes();
		Map excMap = new HashMap();
		for(int j=0;j<tmpLen;j++){
			Node tmp = excList.item(j);
			excMap.put(tmp.getNodeName(), tmp.getTextContent());
		}
		//logger.info("Inner Map Card Details  --" + excMap);
		logger.info("convertHotListingCardToMap(Node) - ends");
		return excMap; 
	}
	
	//potireddy for Hotlisting ATM start
	// Connecting the Core ::
	public List postEnquriyToCore(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postEnquriyToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

			if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
				SBIApplicationException.throwException("F1");
			}   
			logger.info("txn:::"+requestMap.get("txnno"));
			if(status!=null && status.equalsIgnoreCase("ERR.")){
				SBIApplicationException.throwException("TL10");
			}
		}
		logger.info("postEnquriyToCore(...) Ends Here");
		return responseList;
	}
	
	// Connecting Core To Get AccountInfo for the customer 
	public boolean validateMobileNo(String userMobileNo, String coreMobileNo) {
		boolean validateflag = true;
		if (coreMobileNo != null && coreMobileNo.trim().length()>0 && userMobileNo != null && userMobileNo.trim().length() > 0 && userMobileNo.equalsIgnoreCase(coreMobileNo)) {
			logger.info("Mobile Number remains same with CBS");
			validateflag = false;
		}
		return validateflag;
	}
	
	public void sendSmsRequest(String bankCode,String userName,String messageTypeId,String mobileNo,String countryCode,String smsParamValues[])throws UnknownHostException, IOException{
		logger.info("sendSmsRequest method Starts hrere");
		//String mobileNo=userProfile.getMobileNumber();
		//String countryCode=userProfile.getCountryCode();
		//logger.info("smsParamValues::::::"+smsParamValues[0]);
		SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"0",userName,mobileNo,countryCode);
		String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
		logger.info("smsRequestString"+smsRequestString);
		smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
		logger.info("sendSmsRequest method Ends hrere");	
	}
	
	private SMSRequestParams populateSMSRequestParams(String messageTypeId,String smsParamValues[],String bankCode,String sendOrder, String userName,String mobileNumber,String countryCode)
	{
		logger.info("SMSGateWayRequestSender populateSMSRequestParams  for Beneficiary Starts. userName" + userName );
		SMSRequestParams smsRequestParams = new SMSRequestParams();
		smsRequestParams.setMessageId(StringUtils.uniqueNumberUsingDateAndRandom("RU"));
		smsRequestParams.setMessageTypeId(messageTypeId);
		smsRequestParams.setModuleName("retail");
		smsRequestParams.setUserName(userName);
		smsRequestParams.setBankCode(bankCode);
		smsRequestParams.setMobileNo(mobileNumber);
		smsRequestParams.setCountryCode(countryCode);
		smsRequestParams.setSendOrder(sendOrder);
		List<String> listParam = new ArrayList<String>();
		if( smsParamValues != null){
			for( int i=0; i<smsParamValues.length; i++){
				listParam.add(smsParamValues[i]);
			}
		}
		smsRequestParams.setParam(listParam);
		return smsRequestParams;
		
	}
	
	public String getRandomString(){
		Random ran = new java.util.Random();
		String randomString = "";
		for (int j = 0; j < ssize; j++){
			int r = ran.nextInt(chars.length);
			randomString += chars[r];
		}
		return randomString;
	}

	
	//potireddy for Hotlisting ATM end

	public ATMHotListingDAO getAtmHotListingDAOImpl() {
		return atmHotListingDAOImpl;
	}

	public void setAtmHotListingDAOImpl(ATMHotListingDAO atmHotListingDAOImpl) {
		this.atmHotListingDAOImpl = atmHotListingDAOImpl;
	}

	//potireddy for Hotlisting ATM start
	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
		this.smsGatewayClient = smsGatewayClient;
	}
	//potireddy for Hotlisting ATM end
}
