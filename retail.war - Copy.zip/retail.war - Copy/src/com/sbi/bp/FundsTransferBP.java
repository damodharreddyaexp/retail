/*
 * FundsTransferBP.java
 * Created on Dec 6, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 6, 2005 BOOPATHI - Initial Creation

package com.sbi.bp;

import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.model.Transaction;
import com.sbi.utils.RequestMapperFactory;
import com.sbi.utils.TransactionRequestMapper;
import com.sbi.utils.Validator;


public class FundsTransferBP
{
    protected final Logger logger = Logger.getLogger(getClass());
    private RequestMapperFactory requestMapperFactory;
    private TransactionBP transactionBP;
    private Validator validator;

    
    

	public Transaction transferFunds(Map inputParams)

    {
        
        TransactionRequestMapper transactionRequestMapper = requestMapperFactory.getRequestMapper((String) inputParams.get("transactionName"));
        logger.debug(transactionRequestMapper + "Mapper  created");
        Transaction transaction = transactionRequestMapper.getTransactionObject(inputParams);
        
        logger.info(transaction.getDebit().getBranchCode());
        logger.info(transaction.getCredit()[0].getBranchCode());
        
        validator.validateInterBank(transaction.getDebit().getBranchCode(), transaction.getCredit()[0].getBranchCode());
        
        Transaction transactionResult = transactionBP.postTransaction(transaction);
        logger.info("transactionResult :"+transactionResult);
        return transactionResult; 
        
    } 
    
    /**
     * TODO TransactionBP object injection done here
     * 
     * @param transactionBP
     *            void
     */
    public void setTransactionBP(TransactionBP transactionBP) {
        this.transactionBP = transactionBP;
    }

    /**
     * TODO RequestMapperFactory object injection done here
     * 
     * @param requestMapperFactory
     *            void
     */
    public void setRequestMapperFactory(RequestMapperFactory requestMapperFactory) {
        this.requestMapperFactory = requestMapperFactory;
    }
    
    public void setValidator(Validator validator) {
		this.validator = validator;
	}
 
    
    
}
