/**
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * @author		: Mahindra Satyam Computer Services Ltd
 * @authorID	: SM55551
 * @date		: 21-May-2013
 * @version		: 1.0
 */ 
package com.sbi.bp;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.QuickTransferInitiateDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.Validator;

/**
 * IMPSFundsTransferBP.java
 * Initial Version. Added for  IMPSQuickTransferBPbusiness validation and MQ message posting.
 */
public class IMPSQuickTransferBP{

	protected final Logger logger = Logger.getLogger(getClass());
	
	private QuickTransferInitiateDAO quickTransferInitiateDAOImpl; 
	private Validator validator;

	
	
	public void setValidator(Validator validator) {
		this.validator = validator;
	}


	public boolean validate(Map inputParams) throws SBIApplicationException{
		logger.info("validate method begin");
		String userName = (String) inputParams.get("userName");
		String bankCode = (String) inputParams.get("bankCode");		
		String debitAccountNo = (String) inputParams.get("debitAccountNo");		
		String branchCode = (String) inputParams.get("debitBranchCode");		
		//String benName = (String) inputParams.get("benName");		
		String transacType = (String) inputParams.get("transacType");		
		String benMmid = (String) inputParams.get("mmId");		
		String creditAccountNo = (String) inputParams.get("creditAccountNo");	
		String ifscCode= (String)inputParams.get("creditIFSCCode");
		String curruptionFlag= (String)inputParams.get("curruptionFlag");
		String debitProductCode =(String)inputParams.get("debitProductCode");
		String merchantcode = (String) inputParams.get("transactionMode");	
		double totalAmount=Double.parseDouble(((String) inputParams.get("amountTransfer")));
	//	Date scheduledDate = null; 
		Date scheduledDate=new Date();

	//	double totalAmountForNEFT=transaction.getDebit().getAmount().doubleValue()+transaction.getDebit().getRateOfInterest().doubleValue();
		validator.validateAmount(new Double(totalAmount));
	//	validator.validateQuickTransferLimitPerDay (totalAmount,userName, bankCode);
		validator.quickTransferValidateCategoryALimit(userName,  totalAmount, scheduledDate, bankCode,merchantcode);
	//	validator.validateNreNroNriAccounts(userName,debitAccountNo);		
		validator.validateIMPSMinTxnLimit(totalAmount);
//		validator.validatePtoAAcctLimitIMPS(inputParams);
		validator.validateMinorMajorTxnRights(debitAccountNo, branchCode, userName,8,9);
		validator.validateSubCategoryGroupAMinorLimit(userName, totalAmount, scheduledDate, bankCode, "IMPS", debitProductCode);
//		validator.validatePerTransaction(userName, new Double(totalAmount), bankCode);
		validator.validateCategoryALimit(userName, totalAmount,new Date(), bankCode);
		logger.info("validate method end");
		return true;
	}
	

	public Map constructImpsQuickTransferRequestString(Map inputParams){
		logger.info("constructImpsQuickTransferRequestString method begin");
		String transacType = (String)inputParams.get("transacType");
		String remAccNo = null;
		String benMMID = (String)inputParams.get("mmId");
		String benMobNo = ((String) inputParams.get("benMobNo"));
		remAccNo = (String)inputParams.get("creditAccountNo");
		logger.info("remAccNo"+remAccNo);
		String transferAmount=(String)inputParams.get("amountTransfer");
		double amount = Double.parseDouble(transferAmount);
		int amtInPaisa=(int)(amount*100);
		logger.info("amtInPaisa"+amtInPaisa);
		Map requestMap = new HashMap();
		requestMap.put("transacType", transacType);
		requestMap.put("REM_ACCNO", remAccNo);
		requestMap.put("AMOUNT",amtInPaisa);
		requestMap.put("BEN_MMID", benMMID);
		if(benMobNo!=null){
			String[] benMobNoStr = benMobNo.split("\\|");
			requestMap.put("BEN_MOBNO",benMobNoStr[1]);
		}
		requestMap.put("REM_MOBNO", (String)inputParams.get("remMobNo"));
		requestMap.put("REM_NAME", (String)inputParams.get("remName"));
		requestMap.put("SENDER_ID","INB");
		requestMap.put("SOURCE_TID", (String)inputParams.get("impsRefNo"));
		requestMap.put("BEN_ACCNO", (String)inputParams.get("creditAccountNo"));
		requestMap.put("BEN_IFSC", (String)inputParams.get("ifscCode"));
		requestMap.put("BEN_ACC_TYPE","10");
		requestMap.put("COM_AMT","0");
		logger.info("constructImpsFundsTransferRequestString method end");
		return requestMap;
	}	
	
	public boolean processImpsQuickTransferRequest(Map request,String refNo) throws Exception
    {
	 logger.info("processImpsQuickTransferRequest method begin");
	 int count = 0;
	 boolean msgStatus=false;
	  String requestString = null;
	  logger.info("flag"+(String)request.get("transacType"));
/*	 if("PtoP".equalsIgnoreCase((String)request.get("transacType"))){
		 requestString= constructIMPSRequestForP2P(request);
	 }*/
	// else{
		 requestString= constructIMPSQuickTxnRequestForP2A(request); 
	// }
   
     logger.info("IMPS requestString :"+requestString);    
    
     if(requestString!=null){
       	count = quickTransferInitiateDAOImpl.insertImpsQuickTransferRequest(refNo,requestString,"retail");
       	if(count>0){
      // 	String encReqMsg=mqSendReceiver.encrypt(requestString,"IMPS.key");	
      //	String decReqMsg=mqSendReceiver.decrypt(encReqMsg,"IMPS.key");
      //	logger.info("encrypted Req Msg"+encReqMsg);
      //	logger.info("decrypted Req Msg"+decReqMsg);
     //  mqSendReceiver.selectQMgr();
      	//msgStatus=mqSendReceiver.putMessages(encReqMsg);
    //    mqSendReceiver.getDisConnectedMQ();
         }
       	else{
			SBIApplicationException.throwException("IMPS016");
       		}
       	}
     
     
        logger.info("processImpsQuickTransferRequest method end");
        return msgStatus; 
    }
           
	
	public String constructIMPSRequestForP2P(Map inputData)
    {
		logger.info("constructPSGRequestString method begin");
		StringBuffer impsReqStringBuffer = new StringBuffer();
		impsReqStringBuffer.append("PROD=SBIINBIMPS&TYPE=P2P&")
		.append("REM_ACCNO=")
		.append((String)inputData.get("REM_ACCNO")).append("&")
		.append("AMOUNT=")
		.append(inputData.get("AMOUNT")).append("&")
		.append("REM_MOBNO=")
		.append((String)inputData.get("REM_MOBNO")).append("&")
		.append("REM_NAME=")
		.append((String)inputData.get("REM_NAME")).append("&")
		.append("SENDER_ID=")
		.append((String)inputData.get("SENDER_ID")).append("&");
		if(inputData.get("remarks")!=null){
			impsReqStringBuffer.append("REMARKS=").append((String)inputData.get("remarks")).append("&");
		}
		impsReqStringBuffer.append("SOURCE_TID=")
		.append((String)inputData.get("SOURCE_TID")).append("&")
		.append("BEN_MMID=")
		.append((String)inputData.get("BEN_MMID")).append("&")
		.append("BEN_MOBNO=")
		.append((String)inputData.get("BEN_MOBNO")).append("&")
		.append("COM_AMT=")
		.append(0);
		logger.info("constructPSGRequestString method end");
		return impsReqStringBuffer.toString();
    } 
	public String constructIMPSQuickTxnRequestForP2A(Map inputData)
    {
		logger.info("constructIMPSRequestForP2A method begin");
		StringBuffer impsReqStringBuffer = new StringBuffer();
		impsReqStringBuffer.append("PROD=SBIINBIMPS&TYPE=P2A&")
		.append("REM_ACCNO=")
		.append((String)inputData.get("REM_ACCNO")).append("&")
		.append("AMOUNT=")
		.append(inputData.get("AMOUNT")).append("&")
		.append("REM_MOBNO=")
		.append((String)inputData.get("REM_MOBNO")).append("&")
		.append("REM_NAME=")
		.append((String)inputData.get("REM_NAME")).append("&")
		.append("SENDER_ID=")
		.append((String)inputData.get("SENDER_ID")).append("&");
		if(inputData.get("remarks")!=null){
			impsReqStringBuffer.append("REMARKS=").append((String)inputData.get("remarks")).append("&");
		}
		impsReqStringBuffer.append("SOURCE_TID=")
		.append((String)inputData.get("SOURCE_TID")).append("&")
		.append("BEN_ACCNO=")
		.append((String)inputData.get("BEN_ACCNO")).append("&")
		.append("BEN_IFSC=")
		.append((String)inputData.get("BEN_IFSC")).append("&")
		.append("BEN_ACC_TYPE=")
		.append((String)inputData.get("BEN_ACC_TYPE")).append("&")
		.append("COM_AMT=")
		.append(0);
		logger.info("constructIMPSRequestForP2A method end");
		return impsReqStringBuffer.toString();
    } 
	
//	private Validator validator;
	
//	private UserDAO userDAOImpl;
	
//	private IMPSTransferDAO impsTransferDaoImpl;
	

	


	/**
	 * This method is used to perform all the business validations pertaining to P2A/P2P fund transfer.
	 * @param inputParams
	 * @return boolean validation status
	 * @throws SBIApplicationException
	 */
/*	public boolean validate(Map inputParams) throws SBIApplicationException{
		logger.info("validate method begin");
		String userName = (String) inputParams.get("userName");
		String bankCode = (String) inputParams.get("bankCode");		
		String debitAccountNo = (String) inputParams.get("debitAccountNo");		
		String branchCode = (String) inputParams.get("debitBranchCode");		
		//String benName = (String) inputParams.get("benName");		
		String transacType = (String) inputParams.get("transacType");		
		String benMmid = (String) inputParams.get("mmId");		
		String creditAccountNo = (String) inputParams.get("creditAccountNo");	
		String ifscCode= (String)inputParams.get("creditIFSCCode");
		String curruptionFlag= (String)inputParams.get("curruptionFlag");
		String debitProductCode =(String)inputParams.get("debitProductCode");
		double totalAmount=Double.parseDouble(((String) inputParams.get("amountTransfer")));
		Date scheduledDate = null; 
		validator.validateBeneficiaryForUser(userName, bankCode, transacType, benMmid,creditAccountNo);
        
		validator.validateNreNroNriAccounts(userName,debitAccountNo);
		
		validator.validateAmount(new Double(totalAmount));
		validator.validateIMPSMinTxnLimit(totalAmount);
		
		if (transacType != null && "PtoP".equalsIgnoreCase(transacType)) {
			validator.validateIMPSFundsTransferAcctLimit(inputParams);
		} else {
			validator.validatePtoAAcctLimitIMPS(inputParams);
		}
		
		validator.validateMinorMajorTxnRights(debitAccountNo, branchCode, userName,8,9);
		
		if (transacType != null && "PtoP".equalsIgnoreCase(transacType)) {
			int newBeneficiaryCount = 0;
			newBeneficiaryCount = userDAOImpl.isNewBeneficiaryExists(userName,
					"IMPS", benMmid, "RETAIL", "00000");

			if (newBeneficiaryCount > 0) {
				logger.info("Newly Added Beneficiary:::");
				validator.validateFirstDayTxnLtForIMPS(userName, benMmid,"RETAIL","IMPS",bankCode,totalAmount,"00000");
			//	SBIApplicationException.throwException("TPB004");
				validator.impsNewBeneficiaryAdditionLimitValidation(userName,
						benMmid, "RETAIL", "IMPS", bankCode, totalAmount,
						"00000");
			}
		}
		else{
			int newBeneficiaryCount = 0;
			newBeneficiaryCount = userDAOImpl.isNewBeneficiaryExists(userName,
					"INTERBANK", creditAccountNo, "RETAIL", ifscCode);

			if (newBeneficiaryCount > 0) {
				logger.info("Newly Added Beneficiary:::");
				validator.validateFirstDayTxnLtForIMPS(userName,creditAccountNo,"RETAIL","INTERBANK",bankCode,totalAmount,ifscCode);
			//	SBIApplicationException.throwException("TPB004");
				validator.impsNewBeneficiaryAdditionLimitValidation(userName,
						creditAccountNo, "RETAIL", "INTERBANK", bankCode, totalAmount,
						ifscCode);
			}
		}
		scheduledDate=new Date();
		validator.validateSubCategoryGroupAMinorLimit(userName, totalAmount, scheduledDate, bankCode, "IMPS", debitProductCode);
		validator.validatePerTransaction(userName, new Double(totalAmount), bankCode);
		validator.validateCategoryALimit(userName, totalAmount,new Date(), bankCode);
		if (curruptionFlag != null && "MINB".equalsIgnoreCase(curruptionFlag)) {
			//Added for Kony
			String channel= "mapp_inb";
			logger.info("Mobile category wise validation");
			//Added for Kony	
			validator.validateMobileCategoryALimit(userName, totalAmount,new Date(), bankCode, channel);
}
		logger.info("validate method end");
		return true;
	}*/

	/**
	 * 
	 * @param inputParams
	 * @return
	 */
	
	
	/*private String checkNullString(Object obj){
		if(obj != null){
			return obj.toString();
		}
		return null;
	}*/ 
	/*public int insertNewTPTxnForIMPS(Map inputParams){
		logger.info("insertNewTPTxnForIMPS method end");
		int newBeneficiaryCount = 0;
		int insertCount=0;
		String transacType=(String)inputParams.get("transacType");
		String userName = (String) inputParams.get("userName");
		String acctNoOrMMID=null;
		String impsRefNo=(String) inputParams.get("impsRefNo");
		String ifscCode=null;
		double amount=Double.parseDouble(((String) inputParams.get("amountTransfer")));
		if (transacType != null && "PtoP".equalsIgnoreCase(transacType)) {
			acctNoOrMMID = (String) inputParams.get("mmId");	
			ifscCode="00000";
			newBeneficiaryCount = userDAOImpl.isNewBeneficiaryExists(userName,
					"IMPS", acctNoOrMMID, "RETAIL", "00000");
			
			}
		else{
			acctNoOrMMID = (String) inputParams.get("creditAccountNo");	
			ifscCode= (String)inputParams.get("ifscCode");
			newBeneficiaryCount = userDAOImpl.isNewBeneficiaryExists(userName,
					"INTERBANK", acctNoOrMMID, "RETAIL", ifscCode);
					}
		if(newBeneficiaryCount>0){
			insertCount=userDAOImpl.updateNewTPTransactions(userName, acctNoOrMMID, impsRefNo, ifscCode, amount,"", "RETAIL");
		}
		logger.info("insertNewTPTxnForIMPS method end");
		return insertCount;
	}
	*/
	
/*	public void setValidator(Validator validator) {
		this.validator = validator;
	}


	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}*/ 

	
	/*public void setImpsTransferDaoImpl(IMPSTransferDAO impsTransferDaoImpl) {
		this.impsTransferDaoImpl = impsTransferDaoImpl;
	}
*/
	
	public void setQuickTransferInitiateDAOImpl(
			QuickTransferInitiateDAO quickTransferInitiateDAOImpl) {
		this.quickTransferInitiateDAOImpl = quickTransferInitiateDAOImpl;
	}

}
