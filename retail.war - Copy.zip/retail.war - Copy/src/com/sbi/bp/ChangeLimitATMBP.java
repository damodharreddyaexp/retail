/*
 * ChangeLimitATMBP.java 
 * Created on Aug 11, 2014
 * Copyright (c) 2014 by SBI All Rights Reserved.
 */

//History
//Aug 11, 2014 Rajanand - Initial Creation

package com.sbi.bp;

import java.io.StringReader;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.sbi.dao.ChangeLimitATMDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.service.ServiceErrorConstants;
import com.sbi.utils.MQSendReceiver;

public class ChangeLimitATMBP {
	private static Logger logger = Logger.getLogger(com.sbi.bp.ChangeLimitATMBP.class);
	private ChangeLimitATMDAO changeLimitATMDAOImpl;
	private MQSendReceiver mqSendReceiver;
	private final static String ATM_200_REQUEST_ID_CAF_ATM_Limit_Inquiry = "ATM_LIMIT_INQUIRY_200_";
	private final static String ATM_200_REQUEST_ID_CAF_POS_Limit_Inquiry = "POS_LIMIT_INQUIRY_200_";
	private final static String ATM_200_REQUEST_ID_CAF_ATM_Limit_UPDATE = "ATM_LIMIT_UPDATE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_POS_Limit_UPDATE = "POS_LIMIT_UPDATE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_DOMESTIC_USAGE_ENABLE = "DOMESTIC_USAGE_ENABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_DOMESTIC_USAGE_DISABLE = "DOMESTIC_USAGE_DISABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_INTERNATIONAL_USAGE_ENABLE = "INTERNATIONAL_USAGE_ENABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_INTERNATIONAL_USAGE_DISABLE = "INTERNATIONAL_USAGE_DISABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_ATM_CHANNEL_ENABLE = "ATM_CHANNEL_ENABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_ATM_CHANNEL_DISABLE = "ATM_CHANNEL_DISABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_POS_CHANNEL_ENABLE = "POS_CHANNEL_ENABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_POS_CHANNEL_DISABLE = "POS_CHANNEL_DISABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_CNP_CHANNEL_ENABLE = "CNP_CHANNEL_ENABLE_200_";
	private final static String ATM_200_REQUEST_ID_CAF_CNP_CHANNEL_DISABLE = "CNP_CHANNEL_DISABLE_200_";
	private final static String SUCCESS = "success";
	private final static String FAILURE = "failure";
	private final static String REQ_LIMIT="DailyLimit";
	private final static String REQ_CHANNEL="Channel";
	private final static String REQ_USAGE="Usage";
	private final static String ATM_TXN= "ATM Limit";
	private final static String POS_TXN= "POS Limit";
	private final static String CHANNEL_TXN= "Channel";
	private final static String USAGE_TXN= "Usage";
	private final static String ENQUIRY_TXN= "Enquiry";
	private final static String UPDATE_TXN= "Update";
	private final static String REQUEST_FROM = "RINB";
	private final static String REQ_ATM_ENQUIRY= "atmLimitEnquiry";
	private final static String REQ_POS_ENQUIRY= "posLimitEnquiry";
	private final static String REQ_ATM_UPDATE= "atmLimitChange";
	private final static String REQ_POS_UPDATE= "posLimitChange";
	private final static String REQ_ENABLE_ATM= "enableATM";
	private final static String REQ_DISABLE_ATM= "disableATM";
	private final static String REQ_ENABLE_POS= "enablePOS";
	private final static String REQ_DISABLE_POS= "disablePOS";
	private final static String REQ_ENABLE_CNP= "enableCNP";
	private final static String REQ_DISABLE_CNP= "disableCNP";
	private final static String REQ_ENABLE_DOMESTIC= "enableDomestic";
	private final static String REQ_DISABLE_DOMESTIC= "disableDomestic";
	private final static String REQ_ENABLE_INTERNATIONAL= "enableInternational";
	private final static String REQ_DISABLE_INTERNATIONAL= "disableInternational";
	private final static String FN_ATMONLY="atmOnly";
	private final static String FN_DOMESTIC="domesticOnly";
	private final static String ZERO_NULL="0";

	//To parse the ATM XML response string and generate into Map 
	public Map parseATMXMLStringToMap(String xmlMessage){
		logger.info("parseATMXMLStringToMap(String) - begins");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Map responseMap = new LinkedHashMap();
		try{
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new StringReader(xmlMessage)));
			Element rootElement = doc.getDocumentElement();
			NodeList childNodes = rootElement.getChildNodes();
			int nodesLen = childNodes.getLength();
			int childCardInquiryOccurence=1;
			int childFSSCardDetailsOccurence=1;
			int childOPUSCardDetailsOccurence = 1;
			String vendorId="-";

			for(int i=0;i<nodesLen;i++){
				Node tmp = childNodes.item(i);
				if("CardInquiryResp".equalsIgnoreCase(tmp.getNodeName())){
					Map xchangeMap = convertCardEnquiryToMap(tmp);
					vendorId = (String)xchangeMap.get("vendorId");
					responseMap.put(tmp.getNodeName().concat(Integer.toString(childCardInquiryOccurence)), xchangeMap);
					if ("FSS".equalsIgnoreCase(vendorId)) {
						childFSSCardDetailsOccurence= Integer.parseInt(xchangeMap.get("childOccurence").toString());
					} else if ("OPUS".equalsIgnoreCase(vendorId)) {
						childOPUSCardDetailsOccurence= Integer.parseInt(xchangeMap.get("childOccurence").toString());
					}
					logger.info("Card Inquiry Resp :: " + responseMap);
					childCardInquiryOccurence = childCardInquiryOccurence + 1;
				}
				else{
					responseMap.put(tmp.getNodeName(), tmp.getTextContent());
				}
			}
			childCardInquiryOccurence = childCardInquiryOccurence - 1;
			responseMap.put("childFSSCardDetailsOccurence", childFSSCardDetailsOccurence);
			responseMap.put("childOPUSCardDetailsOccurence", childOPUSCardDetailsOccurence);
			responseMap.put("childCardInquiryOccurence", childCardInquiryOccurence);
		}
		catch(Exception excep){
			logger.error("Exception while parsing FOR XML", excep);
			responseMap = null;
		}
		logger.info("parseATMXMLStringToMap(String) - ends");
		return responseMap;
	}

	//To iteratively parse the <CardDetails> XML string and convert into Map
	private Map convertCardEnquiryToMap(Node xChangeNode){
		logger.info("convertCardEnquiryToMap(Node) - begins");
		int tmpLen = xChangeNode.getChildNodes().getLength();
		NodeList excList = xChangeNode.getChildNodes();
		Map cardEnquiryMap = new HashMap();
		int childOccurence = 1;
		String vendorId ="-";

		for(int j=0;j<tmpLen;j++){
			Node tmp = excList.item(j);
			if("CardDetails".equalsIgnoreCase(tmp.getNodeName())){
				Map cardDetailsMap = convertCardDetailsToMap(tmp, vendorId);
				cardEnquiryMap.put(tmp.getNodeName().concat(Integer.toString(childOccurence)), cardDetailsMap);
				childOccurence = childOccurence + 1;
			} else {
				if ("FSS".equalsIgnoreCase(tmp.getTextContent().toString())) {
					vendorId = tmp.getTextContent().toString();
					//logger.info("FSS Card Presence::: "+vendorId);
				} else if ("OPUS".equalsIgnoreCase(tmp.getTextContent().toString()))  {
					vendorId = tmp.getTextContent().toString();
					//logger.info("OPU Card Presence::: "+vendorId);
				}
				cardEnquiryMap.put(tmp.getNodeName(), tmp.getTextContent());
				cardEnquiryMap.put("vendorId",vendorId);
			}
		}
		childOccurence = childOccurence - 1;
		cardEnquiryMap.put("childOccurence", childOccurence);
		logger.info("convertCardEnquiryToMap(Node) - ends");
		return cardEnquiryMap;
	}

	//To iteratively parse the <cardDetails> XML string and convert into Map
	private Map convertCardDetailsToMap(Node xChangeNode, String vendorId){
		logger.info("convertCardDetailsToMap(Node, String) - begins");
		int tmpLen = xChangeNode.getChildNodes().getLength();
		NodeList excList = xChangeNode.getChildNodes();
		Map excMap = new HashMap();
		String dateString ="";
		for(int j=0;j<tmpLen;j++){
			Node tmp = excList.item(j);
			if ((tmp.getNodeName().toString().equalsIgnoreCase("IssueDate")) 
					|| (tmp.getNodeName().toString().equalsIgnoreCase("ExpiryDate"))){
				dateString = dateStringFormat(tmp.getTextContent().toString());
				excMap.put(tmp.getNodeName(), dateString);
			} else { 
				excMap.put(tmp.getNodeName(), tmp.getTextContent());
			}
		} 
		excMap.put("vendorId", vendorId);	
		logger.info("Inner Map Card Details  -- " + excMap);
		logger.info("convertCardDetailsToMap(Node, String) - ends");
		return excMap; 
	}

	//To get formatted date
	public String dateStringFormat(String dateString){
		logger.info("dateStringFormat(String) - begins - " + dateString);
		int dateLength = dateString.length();
		String dateReturnString=null;
		if(dateLength>=10)
		{			 
			dateString=dateString.substring(0, 10).toString();
			SimpleDateFormat sd1=new SimpleDateFormat("yyyy-mm-dd");
			Date date;

			try {
				date = sd1.parse(dateString);
				sd1.applyPattern("dd-mm-yyyy");
				dateReturnString = sd1.format(date);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			dateReturnString = "NA";
		}

		logger.info("dateStringFormat(String) - ends");
		return dateReturnString;
	}

	//To Format CardBin from Card Number	
	public  String formatCardBin(String card12Bin) {
		logger.info("formatCardBin(String) - begins");
		String cardBin = card12Bin.substring(0,6).trim();
		if(cardBin.equalsIgnoreCase("600206")|| cardBin.equalsIgnoreCase("504435") || cardBin.equalsIgnoreCase("504645") || 
				cardBin.equalsIgnoreCase("603845") || cardBin.equalsIgnoreCase("504993") || cardBin.equalsIgnoreCase("504774") || 
				cardBin.equalsIgnoreCase("622018")|| cardBin.equalsIgnoreCase("504775")|| cardBin.equalsIgnoreCase("504809"))
		{
			String binDigit12 = card12Bin.substring(11,12).trim();
			if(binDigit12.equalsIgnoreCase("7"))
			{
				cardBin=cardBin+"*****"+"7";
			}
			else if(binDigit12.equalsIgnoreCase("8"))
			{
				cardBin=cardBin+"*****"+"8";
			}
		}
		logger.info("CardBin in formatCardBin(String) ::: "+cardBin);
		logger.info("formatCardBin(String) - ends");
		return cardBin;
	}

	//To check the presence of CardBin in reference table
	public boolean checkCardBin(String cardBin) throws DAOException,SBIApplicationException{
		logger.info("checkCardBin(String) - begins");
		boolean status= false;
		int count=0;
		try {
			count=changeLimitATMDAOImpl.cardBinCheck(cardBin);
			status = (count>0) ? true : false;
			logger.info("checkCardBin(String) - ends");
			return status;
		} catch(DataAccessException dataAccessException) {
			logger.error("Exception occured ::: " + dataAccessException);
			DAOException.throwException("CHALT029");
		} catch(Exception exce) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exce);
		}
		logger.info("checkCardBin(String) - ends");
		return status;
	}

	//To obtain Maximum ATM / POS Limit and Allowed Updates for the card
	public Map preRequestCheck(String cardBin, Map inputParams) throws DAOException,SBIApplicationException{
		logger.info("preRequestCheck(String) - begins");
		Map respMap = new HashMap();
		String upgradeStatus = FAILURE;
		try {
			String atmMaxLimit=changeLimitATMDAOImpl.maximumATMLimit(cardBin);
			String posMaxLimit=changeLimitATMDAOImpl.maximumPOSLimit(cardBin);
			String allowedFn=changeLimitATMDAOImpl.cardFnValidation(cardBin);
			respMap.put("atmMaxLimit",atmMaxLimit);
			respMap.put("posMaxLimit",posMaxLimit);
			respMap.put("allowedFn",allowedFn);

			/*upgradeStatus = ((REQ_LIMIT.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
					REQ_POS_UPDATE.equalsIgnoreCase((String) inputParams.get("limitChange")) &&
					FN_ATMONLY.equalsIgnoreCase(allowedFn))||(REQ_USAGE.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
							FN_ATMONLY.equalsIgnoreCase(allowedFn))||(REQ_CHANNEL.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
									FN_ATMONLY.equalsIgnoreCase(allowedFn)) || (REQ_USAGE.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
											FN_DOMESTIC.equalsIgnoreCase(allowedFn)) ) ? FAILURE : SUCCESS;*/
			upgradeStatus = ((REQ_LIMIT.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
					REQ_POS_UPDATE.equalsIgnoreCase((String) inputParams.get("limitChange")) &&
					FN_ATMONLY.equalsIgnoreCase(allowedFn))||(REQ_USAGE.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
							FN_ATMONLY.equalsIgnoreCase(allowedFn))||(REQ_CHANNEL.equalsIgnoreCase((String) inputParams.get("selectedService"))&& 
									FN_ATMONLY.equalsIgnoreCase(allowedFn))) ? FAILURE : SUCCESS;
			

			respMap.put("upgradeStatus", upgradeStatus);
			logger.info("preRequestCheck(String) - ends");
			return respMap;
		} catch(DataAccessException dataAccessException) {
			logger.error("Exception occured ::: " + dataAccessException);
			DAOException.throwException("CHALT029");
		} catch(Exception exce) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exce);
		}
		logger.info("preRequestCheck(String) - ends");
		return null;
	}

	//To validate the entered new limit (5000X and < Max Limit)
	public boolean validateNewLimit(String newLimit, String maxLimit){
		logger.info("validateNewLimit(String) - begins");
		int limit = Integer.parseInt(newLimit);
		int maxilimit = Integer.parseInt(maxLimit);
		if(limit % 5000 != 0) {
			logger.info("validateNewLimit(String) - ends");
			return false;}
		else if(limit>maxilimit) {
			logger.info("validateNewLimit(String) - ends");
			return false;}
		else
		{
			logger.info("validateNewLimit(String) - ends");
			return true;
		}
	}

	//To validate the presence of Special Characters in entered new limit 
	public boolean validateSpecialChar(String newLimit) {
		logger.info("validateSpecialChar(String) - begins");
		boolean blnSpecialChar = true;
		if (newLimit == null) {
			newLimit = "";
		}              
		Pattern p = Pattern.compile("[\\\\&<>\"'%@\\=;\\*~`!$%^{}\\;?\\-]+");
		Matcher m = p.matcher(newLimit);
		boolean inValid = m.find();
		if (inValid || (newLimit != null && !newLimit.equalsIgnoreCase("") && newLimit.trim().length() == 0)) {
			blnSpecialChar = false;
		}
		logger.info("validateSpecialChar(String) - ends");
		return blnSpecialChar;
	}

	//To format the Request string
	public Map formatReqString(Map requestMap){
		logger.info("formatReqString(Map) - begins");	
		// Variable Declaration::
		Map reqStringMap = new HashMap();
		String reqString=null;
		String inbReference=null;
		String inbRefNo = null;

		// Obtaining Through request Map 
		String selectedService =(String)requestMap.get("selectedService");
		String limitChange =(String)requestMap.get("limitChange");
		String channelFlag =(String) requestMap.get("channelFlag");
		String usageFlag =(String) requestMap.get("usageFlag");
		String enquiryService =(String) requestMap.get("enquiryService");
		String allowedFn =(String) requestMap.get("allowedFn");

		// Formatting The Limit values
		String newATMLimit=formatNewLimit((String) requestMap.get("newATMLimit"));
		String newPOSLimit =formatNewLimit((String) requestMap.get("newPOSLimit"));


		try {
			//As of now
			inbRefNo = changeLimitATMDAOImpl.getATMLimitSequenceNo();
			//inbRefNo="121212121212";
			requestMap.put("inbRefNo", inbRefNo);

			if (REQ_LIMIT.equalsIgnoreCase(selectedService) && allowedFn != null)
			{
				if (REQ_ATM_ENQUIRY.equalsIgnoreCase(enquiryService) && allowedFn != null)
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_ATM_Limit_Inquiry+inbRefNo);
					requestMap.put("txn",ATM_TXN);
					requestMap.put("txntype", ENQUIRY_TXN);
					requestMap.put("requestType", REQ_ATM_ENQUIRY);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_POS_ENQUIRY.equalsIgnoreCase(enquiryService) && !FN_ATMONLY.equalsIgnoreCase(allowedFn))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_POS_Limit_Inquiry+inbRefNo);
					requestMap.put("txn",POS_TXN);
					requestMap.put("txntype", ENQUIRY_TXN);
					requestMap.put("requestType", REQ_POS_ENQUIRY);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_ATM_UPDATE.equalsIgnoreCase(limitChange) && allowedFn!=null)
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_ATM_Limit_UPDATE+inbRefNo);
					requestMap.put("txn",ATM_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ATM_UPDATE);
					requestMap.put("limitUpdate", newATMLimit);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_POS_UPDATE.equalsIgnoreCase(limitChange) &&  !FN_ATMONLY.equalsIgnoreCase(allowedFn))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_POS_Limit_UPDATE+inbRefNo);
					requestMap.put("txn",POS_TXN );
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_POS_UPDATE);
					requestMap.put("limitUpdate", newPOSLimit);
					reqString = requestFormat(requestMap);
				}
			}
			//else if (REQ_USAGE.equalsIgnoreCase(selectedService) && !FN_DOMESTIC.equalsIgnoreCase(allowedFn) &&  !FN_ATMONLY.equalsIgnoreCase(allowedFn))
			else if (REQ_USAGE.equalsIgnoreCase(selectedService) &&  !FN_ATMONLY.equalsIgnoreCase(allowedFn))
			{
				if (REQ_ENABLE_DOMESTIC.equalsIgnoreCase(usageFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_DOMESTIC_USAGE_ENABLE+inbRefNo);
					requestMap.put("txn", USAGE_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ENABLE_DOMESTIC);
					reqString = requestFormat(requestMap);
				} 
				else if (REQ_DISABLE_DOMESTIC.equalsIgnoreCase(usageFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_DOMESTIC_USAGE_DISABLE+inbRefNo);
					requestMap.put("txn", USAGE_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_DISABLE_DOMESTIC);
					reqString = requestFormat(requestMap);
				} 
				else if (!FN_DOMESTIC.equalsIgnoreCase(allowedFn))
				{
				if (REQ_ENABLE_INTERNATIONAL.equalsIgnoreCase(usageFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_INTERNATIONAL_USAGE_ENABLE+inbRefNo);
					requestMap.put("txn", USAGE_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ENABLE_INTERNATIONAL);
					reqString = requestFormat(requestMap);
				} 
				else if (REQ_DISABLE_INTERNATIONAL.equalsIgnoreCase(usageFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_INTERNATIONAL_USAGE_DISABLE+inbRefNo);
					requestMap.put("txn", USAGE_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_DISABLE_INTERNATIONAL);
					reqString = requestFormat(requestMap);
				} 
			}
			}
			else if (REQ_CHANNEL.equalsIgnoreCase(selectedService) && !FN_ATMONLY.equalsIgnoreCase(allowedFn))
			{
				if (REQ_ENABLE_ATM.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_ATM_CHANNEL_ENABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ENABLE_ATM);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_DISABLE_ATM.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_ATM_CHANNEL_DISABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_DISABLE_ATM);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_ENABLE_POS.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_POS_CHANNEL_ENABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ENABLE_POS);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_DISABLE_POS.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_POS_CHANNEL_DISABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_DISABLE_POS);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_ENABLE_CNP.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_CNP_CHANNEL_ENABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_ENABLE_CNP);
					reqString = requestFormat(requestMap);
				}
				else if (REQ_DISABLE_CNP.equalsIgnoreCase(channelFlag))
				{
					requestMap.put("requestId" ,ATM_200_REQUEST_ID_CAF_CNP_CHANNEL_DISABLE+inbRefNo);
					requestMap.put("txn", CHANNEL_TXN);
					requestMap.put("txntype", UPDATE_TXN);
					requestMap.put("requestType", REQ_DISABLE_CNP);
					reqString = requestFormat(requestMap);
				}
			}

			// Storing the request details in DB:::
			if(reqString!=null)
			{
				inbReference = changeLimitATMDAOImpl.insertATMLimitTxnDetails(reqString,requestMap);
			}
			// Assigining in the outparam
			reqStringMap.put("reqString", reqString);
			reqStringMap.put("inbRefNo", inbRefNo);
			reqStringMap.put("inbReference", inbReference);
			logger.info("Formatted Request String ::: "+reqString);   
			logger.info("formatReqString(Map) - ends");	
			return reqStringMap;
		} catch(DataAccessException dataAccessException) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
		} catch(Exception exce) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exce);
		}
		logger.info("formatReqString(Map) - ends");	
		return reqStringMap;
	}

	//To Frame the Request XML
	public  String requestFormat(Map requestMap) {
		logger.info("atmInquiryRequest200Format(Map, String, String) - begins");
		StringBuffer  strAtmCafLimitEnquiry = new StringBuffer();
		String limit = (String) requestMap.get("limitUpdate");
		limit = (limit!=null) ? limit : "";

		strAtmCafLimitEnquiry.append("<atmServiceRequest>") 
		.append("<cardNumber>" + (String) requestMap.get("cardNumber") + "</cardNumber>")
		.append("<cardExpiry>" + (String)requestMap.get("expiryDate") + "</cardExpiry>")
		.append("<vendorName>" + (String) requestMap.get("serverType") + "</vendorName>")
		.append("<channelReference>" + (String) requestMap.get("inbRefNo") + "</channelReference>")
		.append("<requestType>" + (String) requestMap.get("requestType") + "</requestType>")
		.append("<limit>" + limit + "</limit>")
		.append("<channelID>" + REQUEST_FROM + "</channelID>")
		.append("</atmServiceRequest>");

		logger.info("XML Parsed Request String :: " +strAtmCafLimitEnquiry.toString());
		logger.info("atmInquiryRequest200Format Method(Map, String, String  - ends");
		return strAtmCafLimitEnquiry.toString();
	}

	//To post request to the FSS server through Client
	public Map postEnquriyToSocket(Map requestMap) throws DAOException,SBIApplicationException{
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);      
		logger.info("postEnquriyToSocket(Map) - begins");
		Map responseMap = new HashMap();
		String responseString = null;
		boolean msgStatus=false;
		if (requestMap != null)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("request :" + requestMap);
			}
			String requestString = (String)requestMap.get("reqmsg");
			String serverType = (String)requestMap.get("serverType");
			logger.info("serverType in postEnquriyToSocket ::: "+serverType);   
			if(requestString!=null){
				try {
					responseString = mqSendReceiver.postMQ(requestString,serverType);
					//responseString = "<atmServiceResponse><txn>ATM Limit</txn><txnType>ResponseEnquiry</txnType><channelReference>121212121212</channelReference><mwReference>MQ0000345678</mwReference><status>00</status><statusDesc>success</statusDesc><limit>0</limit></atmServiceResponse>";
				}  
				catch (Exception e) {
					SBIApplicationException.throwException("CHALT031");
				}
			}
			responseMap.put("responseString", responseString);		
			logger.info("Response String :::"+responseString);   
			logger.info("postEnquriyToSocket(Map) - ends");
			return responseMap;
		}
		else
		{
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("postEnquriyToSocket(Map) - ends");
		return null;
	}

	//To parse the response Xml into Map
	public Map parseRespStringToMap(String xmlMessage){
		logger.info("parseRespStringToMap(String) - begins");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Map responseMap = new LinkedHashMap();
		try{
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new StringReader(xmlMessage)));
			Element rootElement = doc.getDocumentElement();
			NodeList childNodes = rootElement.getChildNodes();
			int nodesLen = childNodes.getLength();

			for(int i=0;i<nodesLen;i++){
				Node tmp = childNodes.item(i);
				responseMap.put(tmp.getNodeName(), tmp.getTextContent());
			}
		}
		catch(Exception excep){
			logger.error("Exception while parsing Response XML", excep);
			responseMap = null;
		}
		logger.info("Response Map ::: " + responseMap);
		logger.info("parseRespStringToMap(String) - ends");
		return responseMap;
	}

	//To format and store the 200 Response string
	public Map formatResponse(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("formatResponse(Map) - begins");
		Map respMap = new HashMap();
		String respFormat="";
		String responseCode=null;
		int count =0;
		try
		{
			respMap = parseRespStringToMap((String) requestMap.get("responseString"));
			respMap.put("responseString",(String) requestMap.get("responseString"));
			respFormat = ((String) respMap.get("channelReference")==null||(String) respMap.get("mwReference")==null||
					(String) respMap.get("status")==null||(String) respMap.get("statusDesc")==null) ? FAILURE : SUCCESS;
			logger.info("atmServiceResponse ::: " +(String) respMap.get("atmServiceResponse"));

			if(FAILURE.equalsIgnoreCase(respFormat))
			{
				logger.info("Response format from MQ is Invalid");
				respMap.put("respFormat",respFormat);
				return respMap;
			}

			respFormat = (((String) requestMap.get("inbRefNo")).equalsIgnoreCase((String) respMap.get("channelReference"))) ? SUCCESS : FAILURE;
			if(FAILURE.equalsIgnoreCase(respFormat))
			{
				logger.info("Response format from MQ is Invalid inbReference(channelReference) doesnot match");
				respMap.put("respFormat",respFormat);
				return respMap;
			}
			else{
				respMap.put("respFormat",respFormat);
				responseCode = (String) respMap.get("status");
				respMap.put("responseCode",(String) respMap.get("status"));
				String avlLimit =(String) respMap.get("limit");
				if (avlLimit==null || avlLimit.trim().length()<=0 || ZERO_NULL.equalsIgnoreCase(avlLimit))
				{
					respMap.put("avlLimit",ZERO_NULL);
				}
				else
				{
					respMap.put("avlLimit",avlLimit.replaceAll("^0+",""));
				}
				count = changeLimitATMDAOImpl.updateATMLimitTxnDetails(respMap,(String)requestMap.get("inbReference"));
				logger.info("formatResponse(Map) ends");
				return respMap;
			}
		} catch (Exception excep) {
			SBIApplicationException.throwException("CHALT031");
		}
		logger.info("formatResponse(Map) ends");
		return respMap;
	}

	//To Pad the new limit with zeros
	public String formatNewLimit(String newLimit){
		logger.info("formatNewLimit(String) - begins");
		if(newLimit!=null && newLimit.length() != 17)
		{
			int paddLength = 12 - newLimit.length();
			char paddArray[] = new char[paddLength];
			for(int loop=0; loop<paddLength; loop++)
			{
				paddArray[loop] = '0';
			}
			StringBuffer newLimitBuf = new StringBuffer("").append(paddArray).append(newLimit);
			newLimit = newLimitBuf.toString();
			logger.info("formatNewLimit(String) - ends");
			return newLimit;
		}
		else
		{
			logger.info("formatNewLimit(String) - ends");
			return null;
		}
	}

	public ChangeLimitATMDAO getChangeLimitATMDAOImpl() {
		return changeLimitATMDAOImpl;
	}

	public void setChangeLimitATMDAOImpl(ChangeLimitATMDAO changeLimitATMDAOImpl) {
		this.changeLimitATMDAOImpl = changeLimitATMDAOImpl;
	}

	public MQSendReceiver getMqSendReceiver() {
		return mqSendReceiver;
	}

	public void setMqSendReceiver(MQSendReceiver mqSendReceiver) {
		this.mqSendReceiver = mqSendReceiver;
	}


}
