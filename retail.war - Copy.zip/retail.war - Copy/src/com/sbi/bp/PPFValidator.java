/**
 * @(#) PPFValidator.java
 */ 

package com.sbi.bp;

import com.sbi.model.Account;
import com.sbi.utils.Constants;
import com.sbi.utils.ProfileValidator;
import com.sbi.cache.UserSessionCache;


import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.utils.LoggingConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.dao.ErrorConstants;

public class PPFValidator extends ProfileValidatorBP
{
    private ProfileValidator profileValidator;
    
    private UserSessionCache userSessionCache;        
    
    private Logger logger = Logger.getLogger(getClass());
    
    private final static String TP_VALIDATION_KEY = "validationType";
    
    private final static String TP_VALIDATION_ADD_TYPE = "Add";
    
    private final static String TP_VALIDATION_EDIT_TYPE = "Edit";
    
    private final static String ACCOUNT_KEY = "account";
    /**
     * Will call the following methods 
     * 1.verifybranchcode of ProfileValidator
     * 2.verifyAccountIdentifierof the Profilevalidator
     * 3.validateaccount of the Profilevalidator
     */
    public void validate( Object input )
    {
        if(input != null)
        {
            logger.info("PPFValidator : validate method "+LoggingConstants.METHODBEGIN);
            
            logger.info("PPFValidator : validate method "+LoggingConstants.METHODBEGIN);
            Map validateMap = (Map) input;
            String type = (String)  validateMap.get(TP_VALIDATION_KEY);
            Account acc = (Account) validateMap.get(ACCOUNT_KEY);
            
            Map branchlist = (Map) userSessionCache.getData(acc.getUserName()+BPConstants.BRANCH_LIST_REFERENCE);
            logger.info("PPFValidator : Branch code obtained"+acc.getBranchCode());
            logger.info("PPFValidator : branchlist size"+branchlist.size());
            
            logger.info("PPFValidator : calling verifybranchcode");
            profileValidator.verifyBranchCode(acc.getBranchCode(),branchlist);                       
            
            acc.setBankSystem(Constants.NONCORE_SYSTEM);
            logger.info("PPFValidator : calling verifyAccountIdentifier");
            profileValidator.verifyAccountIdentifier(acc);
            
            logger.info("PPFValidator : calling validateAccount");
            profileValidator.validateAddAccount(acc);

        }
        else
        {
            logger.error("PPFValidator : Error in data received");
            SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
          }
    }
    public void setProfileValidator(ProfileValidator profileValidator) {
        this.profileValidator = profileValidator;
    }
    public void setUserSessionCache(UserSessionCache userSessionCache) {
        this.userSessionCache = userSessionCache;
    }


}
