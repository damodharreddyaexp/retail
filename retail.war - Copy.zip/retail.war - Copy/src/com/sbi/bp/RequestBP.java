/*
 * RequestBP.java
 * Created on Nov 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 28, 2005 Sairam.T - Initial Creation
package com.sbi.bp;
 

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.dao.IBTransactionDAO;
import com.sbi.dao.RequestDAO;
import com.sbi.dao.RequestDAOFactory;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Request;
import com.sbi.model.TransactionResponse;
import com.sbi.utils.LoggingConstants;

public class RequestBP {
	protected final Logger logger = Logger.getLogger(getClass());

	private IBTransactionDAO ibTransactionDAOImpl;

	private RequestDAOFactory requestDAOFactory;

	/**
	 * Call the insertRequest with ChequeDetails Object as a input and get the ReferenceNumber and ChequeDetails Object.
	 * Call updateStatus with ReferenceNo,TransactionResponse and get boolean result.
	 * return the Request Object 
	 * @param Request request
	 * @return request 
	 */

	public Request createRequest(Request request)throws SBIApplicationException {
		logger.info("createRequest(Request request) " + LoggingConstants.METHODBEGIN);
		try {
			if (request != null) {
				RequestDAO requestDAOImpl = requestDAOFactory.getRequestDAO(request.getRequestType());
				TransactionResponse response = (TransactionResponse) requestDAOImpl.insertRequest(request); //Changed generically CR5535
				if (response != null) {
					String referenceNo = response.getTransactionReferenceNo();
					logger.info("referenceNoBefore>>>>>>>"+referenceNo);
                    //sairam Added here
                    String reffNo=referenceNo;
                    if(referenceNo.length()>10)
                        reffNo = referenceNo.substring(0,referenceNo.length()-2); //sairam Added this line only Here 17-05-06 CR-1253
					logger.info("reffNoAfter>>>>>>>"+reffNo);
					logger.info("StatusCode"+response.getStatusCode());
                    logger.info("StatusDescription"+response.getStatusDescription());
                    //Modified by saravanan for CR-1486 on July 17th 2006 - start
					boolean status = ibTransactionDAOImpl.updateStatus(response, reffNo);
                    //Modified by saravanan for CR-1486 on July 17th 2006 - end
					request.setRefrenceNo(reffNo); //sairam modified this line only here 17-05-06 CR-1253
                    request.setStatus(response.getStatusCode());
                    request.setStatusDescription(response.getStatusDescription());
					return request;
				}
			}else{
				SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		} catch (DAOException daoException) {

			 logger.info("TransactionBP.postTransactionToDB method throws Exception :" + daoException.toString());
			 SBIApplicationException.throwException(daoException.getMessage(),daoException);
			 }
		 logger.info("validate(Request request) " + LoggingConstants.METHODEND);
		return request;
	}

	/**
	 * IbTransactionDAOImpl injection
	 * @param ibTransactionDAOImpl IBTransactionDAO 
	 */
	public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl) {
		this.ibTransactionDAOImpl = ibTransactionDAOImpl;
	}

	/** 
	 * RequestDAOFactory injection
	 * @param RequestDAOFactory requestDAOFactory 
	 */
	public void setRequestDAOFactory(RequestDAOFactory requestDAOFactory) {
		this.requestDAOFactory = requestDAOFactory;
	}
	

}
