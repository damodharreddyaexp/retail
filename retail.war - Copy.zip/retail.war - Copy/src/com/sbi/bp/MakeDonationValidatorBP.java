
package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class MakeDonationValidatorBP extends TransactionValidatorBP {

    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;   

    public boolean validate(Transaction transaction)
            throws SBIApplicationException {
        this.transaction = transaction;
        if (transaction != null) {
            logger.info("validate(Transaction transaction) "
                    + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled()) {
                logger.debug("transaction :" + transaction.toString());
            }
            
            validator.validateDonationCreditAccount(transaction.getDebit().getMerchantCode(),
            		transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
            
            if(transaction.getDebit().getAdditionalParams() != null && transaction.getDebit().getAdditionalParams().get("outref1") != null){
            	validator.validateDonorName(transaction.getDebit().getAdditionalParams().get("outref1").toString(),
                		transaction.getDebit().getUserName(),transaction.getDebit().getMerchantCode());
            }
            
            //To check whether both a/c are of same bank
          validator.validateInterBank(transaction.getDebit().getBranchCode(),
                    transaction.getCredit()[BPConstants.ZERO_INT]
                            .getBranchCode());
            if (logger.isDebugEnabled()) {
                logger
                        .debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
            }

            validator.validateAmount(transaction.getDebit().getAmount());
            if (logger.isDebugEnabled()) {
                logger.debug("validateAmount() return true");
            }
      
            Date scheduledDate = new Date(transaction.getScheduledDate().getTime()); 
          //limit change uday    
                  
            validator.validateTxnRights(transaction.getDebit().getAccountNo(),
                    transaction.getDebit().getBranchCode(), transaction
                            .getDebit().getUserName(), new Integer(
                            BPConstants.DEBIT_NO));
            if (logger.isDebugEnabled()) {
                logger
                        .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
            }
     
            //limit change uday
            
            validator.validateCharityLimits(transaction.getDebit().getMerchantCode(),
                    transaction.getDebit().getAmount());
            if (logger.isDebugEnabled()) {
                logger.debug("validateCharityLimits(String charityID,Double amount) method - true");
            }
            
            String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
            	
			validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "Donation");
		       logger.info("validateSubCategoryGroupBLimit method - true");
            
          //chang limit uday
            validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
                    transaction.getName(),transaction.getBankCode(),scheduledDate);
            if (logger.isDebugEnabled());
            if (logger.isDebugEnabled()) {
                logger.debug("validateCategoryBLimits(String username,Double amount, String type,String bankCode) method - true");
            }
          //chang limit uday
            logger.info("validate(Transaction transaction) "
                    + LoggingConstants.METHODEND);
            

        } else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return true;
    }

    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }  
    
	

}
