package com.sbi.bp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.CoreDAOImpl;
import com.sbi.dao.Form15GHinitiateDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.model.CustomerForm15GHModel;
import com.sbi.model.CustomerForm15GHSchedule3Model;
import com.sbi.service.ServiceConstant;

public class Form15HinitiateBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private CoreDAOImpl coreDAOImpl;
	/*private SMSGatewayClient smsGatewayClient;
    private LogonValidator logonValidator;
    private RequestResponseService requestResponseService;
    private UserDAO userDAOImpl;
    UserProfile userProfile;
    private ForgotLoginPwdDAO forgotLoginPwdDAOImpl;*/
    
    private Form15GHinitiateDAO form15GHinitiateDAOImpl;
	
    public void setForm15GHinitiateDAOImpl(
			Form15GHinitiateDAO form15gHinitiateDAOImpl) {
		form15GHinitiateDAOImpl = form15gHinitiateDAOImpl;
	}


	static int ssize =8; 
    static char[] chars = new char[] {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
          'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
          'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
          'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
          'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
        };
	
    public Map verifyCIFNumberDetails(String userName, String branchCode,String bankCode,String fromPage) {
		logger.info("verifyCIFNumberDetails(...) Starts Here");
		Map userResponseMap = null;
		Map scheduleResponseMap = null;
		Map finalResponseMap = new HashMap();
		List CIFNumbersUserList = new ArrayList();
		List CIFNumberUserScheduleList = new ArrayList();
		SBIApplicationResponse applicationresponse=new SBIApplicationResponse();	
	//	applicationresponse.setErrorStatus(ServiceConstant.FAILURE);
		if(userName!=null && userName.length()>0){
			CIFNumbersUserList = form15GHinitiateDAOImpl.verifyCIFNumberUserDetails(userName,branchCode); 
			if(CIFNumbersUserList!=null && CIFNumbersUserList.size()>0) {
				userResponseMap=(Map)CIFNumbersUserList.get(0);
				String CIFNUmber = (String)userResponseMap.get("CIF_NO");
				logger.info("CIFNUmber ::: " + CIFNUmber);
				
				Map customerEnquiryMap = new HashMap();
				// CIFNo=(String)rescifMap.get("CIF_NO");
				 logger.info(" CIFNo in customerEnquiryMap  15 GService::: " + CIFNUmber);
			//	customerEnquiryMap.put("Customer_Number", CIFNo); 							r 
				 customerEnquiryMap.put("Customer_Number", CIFNUmber);  					
				customerEnquiryMap.put("txnno", "060459");
				customerEnquiryMap.put("bankCode", bankCode); 							
			   List customerResponseList=postEnquriyToCoreFor060459(customerEnquiryMap);  
			   if(customerResponseList!=null && customerResponseList.size()>0){
			   Map responseMap = (Map)customerResponseList.get(0);
			   
			   if(responseMap!=null && responseMap.size()>0){  // Newly Added by Damodhar for blocking 
				   String status=(String)responseMap.get("status");
			   if(status!=null){
			   Map coreConnectionMap=(Map)customerResponseList.get(1);
			      applicationresponse=(SBIApplicationResponse)coreConnectionMap.get("applicationresponse");
			   if(applicationresponse.getErrorStatus()!=null &&applicationresponse.getErrorStatus().equals(ServiceConstant.FAILURE) ){
				   finalResponseMap.put("applicationresponse",applicationresponse);
					return finalResponseMap;
			   }
			   
			   }
			   }
			//   responseMap.put("assessmentYear", assessmentYear); 
			 //  responseMap.put("status", status); 
				String dob=(String)responseMap.get("Date of Birth");
			    logger.info("Date of Birth  ::"+  dob);
			    if(dob!=null){
				   Integer ageInYear=customerAgeDetails(dob); 
				if(fromPage.equals("form15G") && ageInYear>=65){
					applicationresponse.setErrorCode("FORM15GH001");
					applicationresponse.setErrorStatus(ServiceConstant.FAILURE);
					finalResponseMap.put("applicationresponse",applicationresponse);
					return finalResponseMap;
				}
				else{
				if(fromPage.equals("form15H") && ageInYear<65){     						// Enable this code for Stagging
			//		if(fromPage.equals("form15H") && ageInYear>=65){					// Enable this code for Local Testing
						applicationresponse.setErrorCode("FORM15GH001");
						applicationresponse.setErrorStatus(ServiceConstant.FAILURE);
						finalResponseMap.put("applicationresponse",applicationresponse);
						return finalResponseMap;
					}
					else{
						applicationresponse.setErrorStatus(ServiceConstant.SUCCESS);
					}
				}
				CIFNumberUserScheduleList = form15GHinitiateDAOImpl.verifyCIFNumberUserScheduleDetails(userName,branchCode,CIFNUmber); 
				if(CIFNumberUserScheduleList!=null && CIFNumberUserScheduleList.size()>0)
					finalResponseMap.put("CIFNumberUserScheduleList",CIFNumberUserScheduleList);
					finalResponseMap.put("applicationresponse",applicationresponse);
			}
		}
			}
		}
		logger.info("verifyCIFNumberDetails(...) Ends Here");
	//	return scheduleResponseMap;
		return finalResponseMap;
	}
    
	public Map getCustomerCIFDetails(String userName) {
		logger.info("getCustomerCIFDetails(...) Starts Here");
		Map responseMap = null;
		List CIFNumbersList = new ArrayList();
		if(userName!=null && userName.length()>0){
			CIFNumbersList = form15GHinitiateDAOImpl.findUserDetails(userName.trim());
			if(CIFNumbersList!=null && CIFNumbersList.size()>0) {
				responseMap=(Map)CIFNumbersList.get(0);
			}
		}

		logger.info("getCustomerCIFDetails(...) Ends Here");
		return responseMap;
	}
	
	public List postEnquriyToCoreFor060459(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postEnquriyToCoreFor060459(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
		SBIApplicationResponse applicationresponse=new SBIApplicationResponse();
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

			if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
				//SBIApplicationException.throwException("F1");
				applicationresponse.setErrorCode("FORM15GH004");
				applicationresponse.setErrorStatus(ServiceConstant.FAILURE);
				Map finalResponseMap=new HashMap();
				finalResponseMap.put("applicationresponse",applicationresponse);
				responseList.add(finalResponseMap);
			}   
			logger.info("txn:::"+requestMap.get("txnno"));
			if(status!=null && status.equalsIgnoreCase("ERR.")){
				SBIApplicationException.throwException("TL10");
			}
		}
		logger.info("postEnquriyToCoreFor060459(...) Ends Here");
		return responseList;
	}  
    
	  public CustomerForm15GHModel form15GH60459Response(CustomerForm15GHModel form15GHModel, Map inParams) {
	    	logger.info("form15GH60459Response(...) Starts Here");
	    	if((String)inParams.get("branchName")!=null && ((String)inParams.get("branchName")).length()>0) {
	    		form15GHModel.setBranchName((String)inParams.get("branchName"));
	    	}else {
	    		form15GHModel.setBranchName(" ");
	    	}
	    	if((String)inParams.get("Customer Name")!=null && ((String)inParams.get("Customer Name")).length()>0) {
	    		form15GHModel.setCustomerName((String)inParams.get("Customer Name"));
	    	}else {
	    		form15GHModel.setCustomerName(" ");
	    	}
	    	if((String)inParams.get("Customer Number")!=null && ((String)inParams.get("Customer Number")).length()>0) {
	    		form15GHModel.setCustomerNumber((String)inParams.get("Customer Number"));
	    	}else {
	    		form15GHModel.setCustomerNumber(" ");
	    	}
	    	if((String)inParams.get("Address 1")!=null && ((String)inParams.get("Address 1")).length()>0) {
	    		form15GHModel.setAddress1((String)inParams.get("Address 1"));
	    	}else {
	    		form15GHModel.setAddress1(" ");
	    	}
	    	if((String)inParams.get("Address 2")!=null && ((String)inParams.get("Address 2")).length()>0) {
	    	//	form15GHModel.setAddress2((String)inParams.get("Address 2"));
	    		form15GHModel.setPremisesName((String)inParams.get("Address 2")) ;
	    	}else {
	    //		form15GHModel.setAddress2(" ");
	    		form15GHModel.setPremisesName(" "); 
	    	}
	    	if((String)inParams.get("Address 3")!=null && ((String)inParams.get("Address 3")).length()>0) {
	    		form15GHModel.setAddress3((String)inParams.get("Address 3"));
	    	}else {
	    		form15GHModel.setAddress3(" ");
	    	}
	    	if((String)inParams.get("Address 4")!=null && ((String)inParams.get("Address 4")).length()>0) {
	    		form15GHModel.setAddress4((String)inParams.get("Address 4"));
	    	}else {
	    		form15GHModel.setAddress4(" ");
	    	}
	    	if((String)inParams.get("Pan Number")!=null && ((String)inParams.get("Pan Number")).length()>0) {
	    		form15GHModel.setPanNumber((String)inParams.get("Pan Number"));
	    		//New CR begins
	    		form15GHModel.setMaskedPan(form15GHModel.getPanNumber().substring(0,2)+"XXXXXX"+form15GHModel.getPanNumber().substring(8,10));
	    		//New CR ends
	    	}else {
	    		form15GHModel.setPanNumber(" ");
	    		//New CR begins
	    		form15GHModel.setMaskedPan(" ");
	    		//New CR ends
	    	}
	    	if((String)inParams.get("Mobile Number")!=null && ((String)inParams.get("Mobile Number")).length()>0) {
	    		form15GHModel.setMobileNumber((String)inParams.get("Mobile Number")); 
	    	}else {
	    		form15GHModel.setMobileNumber(" ");
	    	}
	    	if((String)inParams.get("Postal Code")!=null && ((String)inParams.get("Postal Code")).length()>0) {
	    		form15GHModel.setPostalCode((String)inParams.get("Postal Code"));  
	    	}else {
	    		form15GHModel.setPostalCode(" "); 
	    	}
	    	if((String)inParams.get("Country Code")!=null && ((String)inParams.get("Country Code")).length()>0) {
	    		form15GHModel.setCountryCode((String)inParams.get("Country Code")); 
	    	}else {
	    		form15GHModel.setCountryCode(" ");
	    	}
	    	if((String)inParams.get("assessmentYear")!=null && ((String)inParams.get("assessmentYear")).length()>0) {
	    		form15GHModel.setAssessmentYear((String)inParams.get("assessmentYear"));
	    	}else {
	    		form15GHModel.setAssessmentYear(" ");
	    	}
	    	if((String)inParams.get("status")!=null && ((String)inParams.get("status")).length()>0) {
	    		form15GHModel.setStatus((String)inParams.get("status"));
	    	}else {
	    		form15GHModel.setStatus(" "); 
	    	}
	    	if((String)inParams.get("age")!=null && ((String)inParams.get("age")).length()>0) {
	    		form15GHModel.setAge((String)inParams.get("age"));
	    	}else {
	    		form15GHModel.setAge(" "); 
	    	}
	    	logger.info("form15GH60459Response(...) Ends Here");
	    	return form15GHModel;
	    }

		public List postEnquriyToCoreFor61447(Map requestMap) throws DAOException,SBIApplicationException{
			logger.info("postEnquriyToCoreFor61447(...) Starts Here");
			List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
			logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
			SBIApplicationResponse response=new SBIApplicationResponse();
			Map appResponse=new HashMap();
			
			if(responseList!=null && responseList.size()>0) {
				Map resMap = (Map)responseList.get(0);
				String status = (String)resMap.get("status");
				String statement = (String)resMap.get("statement");
				String errorCode = (String) resMap.get("error_code");
				logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);
				
			//	if((status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2") )) ||statement.trim().equals("NO CUSTOMER RECORDS FOUND")){
				if((status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2") )) ||(statement!=null && statement.trim().equals("NO CUSTOMER RECORDS FOUND"))){
					response.setErrorStatus(ServiceConstant.FAILURE);
					response.setErrorCode("FORM15GH003");
				}   
				else{
					if(status!=null && status.equalsIgnoreCase("ERR.")){
						SBIApplicationException.throwException("TL10");
					}
					else{
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}
				}
			}
			appResponse.put(ServiceConstant.APPLICATION_RESPONSE, response);
			responseList.add(appResponse);
			logger.info("postEnquriyToCoreFor61447(...) Ends Here");
			return responseList;
		}
	
		
		public List postEnquriyToCoreFor61448(Map requestMap) throws DAOException,SBIApplicationException{
			logger.info("postEnquriyToCoreFor61448(...) Starts Here");
			List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
			logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
			if(responseList!=null && responseList.size()>0) {
				Map resMap = (Map)responseList.get(0);
				String status = (String)resMap.get("status");
				String statement = (String)resMap.get("statement");
				String errorCode = (String) resMap.get("error_code");
				logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

				if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
					SBIApplicationException.throwException("F1");
				}   
				logger.info("txn:::"+requestMap.get("txnno"));
				if(status!=null && status.equalsIgnoreCase("ERR.") && !"0344".equalsIgnoreCase(errorCode)){
					SBIApplicationException.throwException("TL10");
				}
			}
			logger.info("postEnquriyToCoreFor61448(...) Ends Here");
			return responseList;
		}		
public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
	this.coreDAOImpl = coreDAOImpl;
}

public int customerAgeDetails(String date){
	//java.util.Date dob=new java.util.Date();
	 int age =0;
	try{
		if(date.length()==8 ){
			int yr=Integer.parseInt(date.substring(4,8));
			int mn=Integer.parseInt(date.substring(2,4));
			int day=Integer.parseInt(date.substring(0, 2));
		    Calendar cal = new GregorianCalendar(yr, mn, day); 
		    Calendar now = new GregorianCalendar();
		     age = now.get(Calendar.YEAR) - cal.get(Calendar.YEAR);
		    if ((cal.get(Calendar.MONTH) > now.get(Calendar.MONTH))
		        || (cal.get(Calendar.MONTH) == now.get(Calendar.MONTH) && cal.get(Calendar.DAY_OF_MONTH) > now
		            .get(Calendar.DAY_OF_MONTH))) {
		      age--;
		    }

			System.out.println("Age in year::"+ age);
		}
	}
	catch(Exception ex){
		logger.info(ex.getMessage());
	}
	return age;
}

public CustomerForm15GHModel getAllForm15GCustDetails(CustomerForm15GHModel form15GHModel, Map inParams) {
	logger.info("getAllCustDetails(...) Starts Here");
	CustomerForm15GHSchedule3Model customerForm15GHSchedule3Model=new CustomerForm15GHSchedule3Model();
	SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
	if((String)inParams.get("custName")!=null && ((String)inParams.get("custName")).length()>0) {
		form15GHModel.setCustomerName((String)inParams.get("custName"));
	}else {
		form15GHModel.setCustomerName(" ");
	}
	if((String)inParams.get("custAssessYear")!=null && ((String)inParams.get("custAssessYear")).length()>0) {
		form15GHModel.setCustAssessYear((String)inParams.get("custAssessYear"));
	}else {
		form15GHModel.setCustAssessYear(" ");
	}
	if((String)inParams.get("custFlatNo")!=null && ((String)inParams.get("custFlatNo")).length()>0) {
		form15GHModel.setAddress1((String)inParams.get("custFlatNo"));
	}else {
		form15GHModel.setAddress1(" ");
	}
		
	if((String)inParams.get("status")!=null && ((String)inParams.get("status")).length()>0) {
		form15GHModel.setStatus((String)inParams.get("status"));
	}else {
		form15GHModel.setStatus(" ");
	}
	if((String)inParams.get("age")!=null && ((String)inParams.get("age")).length()>0) {
		form15GHModel.setAge((String)inParams.get("age"));
	}else {
		form15GHModel.setAge(" ");
	}
	if((String)inParams.get("wardDetails")!=null && ((String)inParams.get("wardDetails")).length()>0) {
		form15GHModel.setAddress2((String)inParams.get("wardDetails"));
	}else {
		form15GHModel.setAddress2(" ");
	}
	if((String)inParams.get("street")!=null && ((String)inParams.get("street")).length()>0) {
		form15GHModel.setAddress3((String)inParams.get("street"));
	}else {
		form15GHModel.setAddress3(" ");
	}
	if((String)inParams.get("area")!=null && ((String)inParams.get("area")).length()>0) {
		form15GHModel.setAddress4((String)inParams.get("area"));
	}else {
		form15GHModel.setAddress4(" ");
	}
	if((String)inParams.get("custPan")!=null && ((String)inParams.get("custPan")).length()>0) {
		form15GHModel.setPanNumber((String)inParams.get("custPan"));
		form15GHModel.setMaskedPan(form15GHModel.getPanNumber().substring(0,2)+"XXXXXX"+form15GHModel.getPanNumber().substring(8,10));
	}else {
		form15GHModel.setPanNumber(" ");
		form15GHModel.setMaskedPan(" ");
	}
	if((String)inParams.get("premisesName")!=null && ((String)inParams.get("premisesName")).length()>0) {
		form15GHModel.setPremisesName((String)inParams.get("premisesName"));
	}else {
		form15GHModel.setPremisesName(" ");
	}
	if((String)inParams.get("areaCode")!=null && ((String)inParams.get("areaCode")).length()>0) {
		form15GHModel.setAreaCode((String)inParams.get("areaCode"));
	}else {
		form15GHModel.setAreaCode(" ");
	}
	
	if((String)inParams.get("aoType")!=null && ((String)inParams.get("aoType")).length()>0) {
		form15GHModel.setAoType((String)inParams.get("aoType"));
	}else {
		form15GHModel.setAoType(" ");
	}
	if((String)inParams.get("rangeCode")!=null && ((String)inParams.get("rangeCode")).length()>0) {
		form15GHModel.setRangeCode((String)inParams.get("rangeCode"));
	}else {
		form15GHModel.setRangeCode(" ");
	}
	if((String)inParams.get("state")!=null && ((String)inParams.get("state")).length()>0) {
		form15GHModel.setStateName((String)inParams.get("state"));
	}else {
		form15GHModel.setStateName(" ");
	}
	if((String)inParams.get("district")!=null && ((String)inParams.get("district")).length()>0) {
		form15GHModel.setDistrictName((String)inParams.get("district"));
	}else {
		form15GHModel.setDistrictName(" ");
	}
	if((String)inParams.get("town")!=null && ((String)inParams.get("town")).length()>0) {
		form15GHModel.setTown((String)inParams.get("town"));
	}else {
		form15GHModel.setTown(" ");
		
	}
	if((String)inParams.get("pin")!=null && ((String)inParams.get("pin")).length()>0) {
		form15GHModel.setPin((String)inParams.get("pin"));
	}else {
		form15GHModel.setPin(" ");
	}
	
	
	if((String)inParams.get("aoNo")!=null && ((String)inParams.get("aoNo")).length()>0) {
		form15GHModel.setAoNo((String)inParams.get("aoNo"));
	}else {
		form15GHModel.setAoNo(" ");
	}
	if((String)inParams.get("custMobile")!=null && ((String)inParams.get("custMobile")).length()>0) {
		form15GHModel.setMobileNumber((String)inParams.get("custMobile")); 
	}else {
		form15GHModel.setMobileNumber(" ");
	}
	if((String)inParams.get("lastAssesssYear")!=null && ((String)inParams.get("lastAssesssYear")).length()>0) {
		form15GHModel.setLastAssesssYear((String)inParams.get("lastAssesssYear"));  
	}else {
		form15GHModel.setLastAssesssYear(" "); 
	}
	if((String)inParams.get("email")!=null && ((String)inParams.get("email")).length()>0) {
		form15GHModel.setEmail((String)inParams.get("email")); 
	}else {
		form15GHModel.setEmail(" ");
	}
	if((String)inParams.get("custTel")!=null && ((String)inParams.get("custTel")).length()>0) {
		form15GHModel.setCustTel((String)inParams.get("custTel")); 
	}else {
		form15GHModel.setCustTel(" ");
	}
	
	if((String)inParams.get("presentWard")!=null && ((String)inParams.get("presentWard")).length()>0) {
		form15GHModel.setPresentWard((String)inParams.get("presentWard")); 
	}else {
		form15GHModel.setPresentWard(" ");
	}
	
	if((String)inParams.get("residentialStatus")!=null && ((String)inParams.get("residentialStatus")).length()>0) {
		form15GHModel.setResidentialStatus((String)inParams.get("residentialStatus")); 
	}else {
		form15GHModel.setResidentialStatus(" ");
	}
	
	if((String)inParams.get("occupation")!=null && ((String)inParams.get("occupation")).length()>0) {
		form15GHModel.setOccupation((String)inParams.get("occupation")); 
	}else {
		form15GHModel.setOccupation(" ");
	}
	
	
	if((String)inParams.get("presentAreaCode")!=null && ((String)inParams.get("presentAreaCode")).length()>0) {
		form15GHModel.setPresentAreaCode((String)inParams.get("presentAreaCode")); 
	}else {
		form15GHModel.setPresentAreaCode(" ");
	}
	
	if((String)inParams.get("presentRangeCode")!=null && ((String)inParams.get("presentRangeCode")).length()>0) {
		form15GHModel.setPresentRangeCode((String)inParams.get("presentRangeCode")); 
	}else {
		form15GHModel.setPresentRangeCode(" ");
	}
	
	if((String)inParams.get("presentAoType")!=null && ((String)inParams.get("presentAoType")).length()>0) {
		form15GHModel.setPresentAoType((String)inParams.get("presentAoType")); 
	}else {
		form15GHModel.setPresentAoType(" ");
	}
	
	if((String)inParams.get("presentAoNo")!=null && ((String)inParams.get("presentAoNo")).length()>0) {
		form15GHModel.setPresentAoNo((String)inParams.get("presentAoNo")); 
	}else {
		form15GHModel.setPresentAoNo(" ");
	}
	
	if((String[])inParams.get("estimatedTotalIncome")!=null ) {
		String[] estimatedTotalIncome=(String[])inParams.get("estimatedTotalIncome");
		List<String> estimatedTotalIncomeList =new ArrayList<String>();
		for(int i=0;i<estimatedTotalIncome.length;i++){
			estimatedTotalIncomeList.add(estimatedTotalIncome[i]);
		}
		//estimatedTotalIncomeList.add(arg0)
		//List<String> estimatedTotalIncome = Arrays.asList((String[])inParams.get("estimatedTotalIncome"));
		//String[] estimatedTotalIncome=(String[])inParams.get("estimatedTotalIncome");
		estimatedTotalIncomeList.add("ETI3");
		form15GHModel.setEstimatedTotalIncome(estimatedTotalIncomeList); 
		
	}
	else {
        List<String> estimatedTotalIncomeList = new ArrayList<String>();
        estimatedTotalIncomeList.add("ETI3");
                      //Arrays.asList(estimatedTotalIncomeByDefault);
        form15GHModel.setEstimatedTotalIncome(estimatedTotalIncomeList);
  }

	
	if((String)inParams.get("noOfShare")!=null && ((String)inParams.get("noOfShare")).length()>0) {
		form15GHModel.setNoOfShare((String)inParams.get("noOfShare")); 
	}else {
		form15GHModel.setNoOfShare(" ");
	}
	
	if((String)inParams.get("shareRate")!=null && ((String)inParams.get("shareRate")).length()>0) {
		form15GHModel.setShareRate((String)inParams.get("shareRate")); 
	}else {
		form15GHModel.setShareRate(" ");
	}
	
	if((String)inParams.get("totalValueOfShare")!=null && ((String)inParams.get("totalValueOfShare")).length()>0) {
		form15GHModel.setTotalValueOfShare((String)inParams.get("totalValueOfShare")); 
	}else {
		form15GHModel.setTotalValueOfShare(" ");
	}
	
	if((String)inParams.get("distinctiveNoOfShare")!=null && ((String)inParams.get("distinctiveNoOfShare")).length()>0) {
		form15GHModel.setDistinctiveNoOfShare((String)inParams.get("distinctiveNoOfShare")); 
	}else {
		form15GHModel.setDistinctiveNoOfShare(" ");
	}
	
	if((String)inParams.get("dateOfAcquired")!=null && ((String)inParams.get("dateOfAcquired")).length()>0) {
		form15GHModel.setDateOfAcquired((String)inParams.get("dateOfAcquired")); 
	}else {
		form15GHModel.setDateOfAcquired(" ");
	}
	
	
	if((String)inParams.get("securitiesDesc")!=null && ((String)inParams.get("securitiesDesc")).length()>0) {
		form15GHModel.setSecuritiesDesc((String)inParams.get("securitiesDesc")); 
	}else {
		form15GHModel.setSecuritiesDesc(" ");
	}
	if((String)inParams.get("noOfSchecurities")!=null && ((String)inParams.get("noOfSchecurities")).length()>0) {
		form15GHModel.setNoOfSchecurities((String)inParams.get("noOfSchecurities")); 
	}else {
		form15GHModel.setNoOfSchecurities(" ");
	}
	if((String)inParams.get("amountOfSecurities")!=null && ((String)inParams.get("amountOfSecurities")).length()>0) {
		form15GHModel.setAmountOfSecurities((String)inParams.get("amountOfSecurities")); 
	}else {
		form15GHModel.setAmountOfSecurities(" ");
	}
	if((String)inParams.get("dateOfSecurities")!=null && ((String)inParams.get("dateOfSecurities")).length()>0) {
		form15GHModel.setDateOfSecurities((String)inParams.get("dateOfSecurities")); 
	}else {
		form15GHModel.setDateOfSecurities(" ");
	}
	if((String)inParams.get("dateOfSecuritiesAcquired")!=null && ((String)inParams.get("dateOfSecuritiesAcquired")).length()>0) {
		form15GHModel.setDateOfSecuritiesAcquired((String)inParams.get("dateOfSecuritiesAcquired")); 
	}else {
		form15GHModel.setDateOfSecuritiesAcquired(" ");
	}
	
	
	if((String[])inParams.get("accountNo")!=null) {
		String[] accountNo=(String[])inParams.get("accountNo");
		List<CustomerForm15GHSchedule3Model> customerForm15GHSchedule3ModelList=new ArrayList<CustomerForm15GHSchedule3Model>();
		for(int i=0;i<accountNo.length;i++){
		customerForm15GHSchedule3Model=new CustomerForm15GHSchedule3Model();
		String[] nameOfPersonInt=(String[])inParams.get("nameOfPersonInt");
		String[] amountOfInt=(String[])inParams.get("amountOfInt");
		String[] dateOfIntGiven=(String[])inParams.get("dateOfIntGiven");
		String[] periodOfIntGiven=(String[])inParams.get("periodOfIntGiven");
		String[] rateOfInt=(String[])inParams.get("rateOfInt");
		customerForm15GHSchedule3Model.setAccountNo(accountNo[i]);
		customerForm15GHSchedule3Model.setNameOfPersonInt(nameOfPersonInt[i]);
		customerForm15GHSchedule3Model.setAmountOfInt(amountOfInt[i]);
		customerForm15GHSchedule3Model.setDateOfIntGiven(dateOfIntGiven[i]);
		customerForm15GHSchedule3Model.setPeriodOfIntGiven(periodOfIntGiven[i]);
		customerForm15GHSchedule3Model.setRateOfInt(rateOfInt[i]);
		customerForm15GHSchedule3ModelList.add(customerForm15GHSchedule3Model);
		}
		form15GHModel.setCustomerForm15GHSchedule3ModelList(customerForm15GHSchedule3ModelList);
	}
	
	
	if((String)inParams.get("nameOfMF")!=null && ((String)inParams.get("nameOfMF")).length()>0) {
		form15GHModel.setNameOfMF((String)inParams.get("nameOfMF")); 
	}else {
		form15GHModel.setNameOfMF(" ");
	}
	if((String)inParams.get("noOfUnitOfMF")!=null && ((String)inParams.get("noOfUnitOfMF")).length()>0) {
		form15GHModel.setNoOfUnitOfMF((String)inParams.get("noOfUnitOfMF")); 
	}else {
		form15GHModel.setNoOfUnitOfMF(" ");
	}
	if((String)inParams.get("classOfUnit")!=null && ((String)inParams.get("classOfUnit")).length()>0) {
		form15GHModel.setClassOfUnit((String)inParams.get("classOfUnit")); 
	}else {
		form15GHModel.setClassOfUnit(" ");
	}
	if((String)inParams.get("distinctiveNoOfUnit")!=null && ((String)inParams.get("distinctiveNoOfUnit")).length()>0) {
		form15GHModel.setDistinctiveNoOfUnit((String)inParams.get("distinctiveNoOfUnit")); 
	}else {
		form15GHModel.setDistinctiveNoOfUnit(" ");
	}
	if((String)inParams.get("incomeOfUnit")!=null && ((String)inParams.get("incomeOfUnit")).length()>0) {
		form15GHModel.setIncomeOfUnit((String)inParams.get("incomeOfUnit")); 
	}else {
		form15GHModel.setIncomeOfUnit(" ");
	}
	
	
	if((String)inParams.get("poDetails")!=null && ((String)inParams.get("poDetails")).length()>0) {
		form15GHModel.setPoDetails((String)inParams.get("poDetails")); 
	}else {
		form15GHModel.setPoDetails(" ");
	}
	
	if((String)inParams.get("accountOpenDate")!=null && ((String)inParams.get("accountOpenDate")).length()>0) {
		form15GHModel.setAccountOpenDate((String)inParams.get("accountOpenDate")); 
	}else {
		form15GHModel.setAccountOpenDate(" ");
	}
	
	if((String)inParams.get("totalAmountWithrawl")!=null && ((String)inParams.get("totalAmountWithrawl")).length()>0) {
		form15GHModel.setTotalAmountWithrawl((String)inParams.get("totalAmountWithrawl")); 
	}else {
		form15GHModel.setTotalAmountWithrawl(" ");
	}
	
	if((String)inParams.get("place")!=null && ((String)inParams.get("place")).length()>0) {
		form15GHModel.setPlace((String)inParams.get("place")); 
	}else {
		form15GHModel.setPlace(" ");
	}
	
	if((String)inParams.get("dateOfSubmission")!=null && ((String)inParams.get("dateOfSubmission")).length()>0) {
	//	form15GHModel.setDateOfSubmit((String)inParams.get("dateOfSubmission")); 
	
		
		form15GHModel.setDateOfSubmit((String)inParams.get("dateOfSubmission")); 
		logger.info("date::"+form15GHModel.getDateOfSubmission());
		
	}else {
		form15GHModel.setDateOfSubmit(" ");
	}
	logger.info("getAllCustDetails(...) Ends Here");
	return form15GHModel;
}


public Map submitAllForm15GCustDetails(Map inputParams) { 
	logger.info("submitAllForm15GCustDetails(...) Starts Here");
	Map outParam=new HashMap();
	try {
		outParam=form15GHinitiateDAOImpl.insertForm15GCustDetails(inputParams); 
	}catch (DAOException daoExc) {
		SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
	}
	logger.info("insertCustomerDetails(...) Ends Here");
	return outParam;
}

public Map submitAllForm15HCustDetails(Map inputParams) { 
	logger.info("submitAllForm15HCustDetails(...) Starts Here");
	Map outParam=new HashMap();
	try {
		outParam=form15GHinitiateDAOImpl.insertForm15HCustDetails(inputParams); 
	}catch (DAOException daoExc) {
		SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
	}
	logger.info("insertCustomerDetails(...) Ends Here");
	return outParam;
}
public Map getPrintCustomerDetails(Map inParam) {
	logger.info("getPrintCustomerDetails(...) Starts Here");
	Map printDetails = new HashMap();
	try {
		printDetails = form15GHinitiateDAOImpl.findPrintUserDetails(inParam);
	}catch (DAOException daoExc) {
		SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
	}
	logger.info("getPrintCustomerDetails(...) Ends Here");
	return printDetails;
}

}
