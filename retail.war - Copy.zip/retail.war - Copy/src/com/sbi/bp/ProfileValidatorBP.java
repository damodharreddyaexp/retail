/**
 * @(#) ProfileValidatorBP.java
 */

package com.sbi.bp;

public abstract class ProfileValidatorBP
{
	public abstract void validate( Object input );
	
	
}
