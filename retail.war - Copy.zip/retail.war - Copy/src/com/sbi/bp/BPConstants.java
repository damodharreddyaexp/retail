/*   
 * BPConstants.java
 * Created on Nov 23, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 23, 2005 BOOPATHI - Initial Creation
//Changed on 30-June-2006 for Paladion by Saravanan N
 
package com.sbi.bp;

import com.sbi.utils.Constants;

public interface BPConstants extends Constants
{

    
    public static final String CREDIT_TRANSACTION_LEG = "BP001";
   
    public static final String INPUT_IRREGULARITY_CODE="F002";// Added by saravanan for paladion on 28/06/2006
   
    public static final String RESPONSE_DATE = "responseDate";
	public static final String STATUS = "STATUS";
	//public static final String  RESPONSE_DESCRIPTION = "responseReference";
    
     public static final String PPVALIDATOR = "PPVALIDATOR";
     
     
    
     public static final String COUNTRY_CODE="countryCode";
  
     public static final String BUS_PHONE="bus_phone";
   
     public static final String ISSUE_CODE_3 = "3";
     
     public static final String ISSUE_CODE_4 = "4";
     
     public static final String ISSUE_CODE_5 = "5";
     
     public static final String ISSUE_CODE_6 = "6";
     
     public static final String ISSUE_CODE_7 = "7";
     
     public static final String ISSUE_CODE_8 = "8";
     
     public static final String ISSUE_CODE_9 = "9";
     
     public static final String ISSUE_CODE_11 = "11";
     
     public static final String ISSUE_CODE_18 = "18";

     public static final String LOGIN_COUNT = "loginCount";

    public static final String LOGIN_DATE = "loginDate";

    public static final String SQL_LOGIN_COUNT = "login_count";

    public static final String SQL_LOGIN_DATE = "last_login_date";
    // demat services start
    
    public static final String DEMAT_REQUST="dematRequest";    
    
    public static final String DP_ID="dpId";
// end demat services
//  Added for CR 1256
    public static final String PRINCIPAL = "PRI";

	public static final String ISSUE_CODE_1 = "1";

	public static final String ISSUE_CODE_2 = "2";
}
