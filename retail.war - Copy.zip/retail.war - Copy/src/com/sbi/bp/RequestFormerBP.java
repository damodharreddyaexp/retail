/*
 * RequestFormerBP.java
 * Created on Jun 24, 2008
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jun 24, 2008 MS67276 � Initial Creation

package com.sbi.bp;

import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.utils.EzConstants;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestFormer;
import com.sbi.utils.RequestFormerFactory;

/**
 * This class is used to frame xml request to send it to external system.
 */

public class RequestFormerBP {
	private RequestFormerFactory requestFormerFactory;

	/**
	 * @param input
	 * @return Steps: 1. Get 'typeOfRequest' variable from input map. 2. call getRequestFormer()
	 *         method of requestFormerFactory to get appropriate request former by passing this
	 *         variable. 3. return the framed xml output.
	 */
	private final Logger logger = Logger.getLogger(getClass());

	public String formRequest(Map input) throws Exception {
		logger.info("RequestFormerBP - " + LoggingConstants.METHODBEGIN);

		logger.info("Requst type :" + (String) input.get(EzConstants.EZ_REQUEST_TYPE));

        RequestFormer requestFomer = requestFormerFactory.getRequestFormer((String)input.get(EzConstants.EZ_REQUEST_TYPE));

		String reqXML = requestFomer.formRequest(input);

		logger.info("RequestFormerBP - " + LoggingConstants.METHODEND);
		return reqXML;
	}

	/**
	 * RequestFormerFactory object injection
	 * @param RequestFormerFactory void
	 */
	public void setRequestFormerFactory(RequestFormerFactory requestFormerFactory) {
		this.requestFormerFactory = requestFormerFactory;
	}

}
