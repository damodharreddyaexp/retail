
package com.sbi.bp;

import com.sbi.exception.SBIApplicationException;
import com.sbi.model.RetailTransaction;
import com.sbi.model.Transaction;
import com.sbi.utils.NitrFeeTransactionRequestMapper;
import java.util.Map;
import org.apache.log4j.Logger;

// Referenced classes of package com.sbi.bp:
//            NitrValidatorBP, TransactionBP 

public class NitrBP
{

    public NitrBP()
    {
    }

    public Transaction payFee(Map inputParams)
        throws SBIApplicationException
    {
        Transaction nitrTransaction = new RetailTransaction();
        Transaction transactionResult = null;
        logger.info(">>>>>>>>>>>>>>>>" + inputParams.toString());
        boolean hackCheckvalid = nitrValidatorBP.validate(inputParams);
        logger.info("hackcheck value" + hackCheckvalid);
        if(hackCheckvalid)
        {
            inputParams.put("feeType", "FEES");
            nitrTransaction = nitrFeeTransactionRequestMapper.getTransactionObject(inputParams);
            transactionResult = transactionBP.postTransaction(nitrTransaction);
            logger.info("transactionResult........" + transactionResult);
        } else
        {
            logger.info("hackCheck....." + hackCheckvalid);
        }
        return transactionResult;
    }

    public void setNitrValidatorBP(NitrValidatorBP nitrValidatorBP)
    {
        this.nitrValidatorBP = nitrValidatorBP;
    }

    public void setNitrFeeTransactionRequestMapper(NitrFeeTransactionRequestMapper nitrFeeTransactionRequestMapper)
    {
        this.nitrFeeTransactionRequestMapper = nitrFeeTransactionRequestMapper;
    }

    public void setTransactionBP(TransactionBP transactionBP)
    {
        this.transactionBP = transactionBP;
    }

    private NitrValidatorBP nitrValidatorBP;
    private NitrFeeTransactionRequestMapper nitrFeeTransactionRequestMapper;
    protected final Logger logger = Logger.getLogger(getClass());
    private TransactionBP transactionBP;
}
