/* 
 * ThirdPartyValidatorBP.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
//Changed on 30-June-2006 for Paladion by Saravanan N
package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class ThirdPartyValidatorBP extends TransactionValidatorBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;
	
	private BranchMasterDAO branchMasterDAOImpl;
	
	 private UserDAO userDAOImpl;

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	/**
	 * Call validator.validateInterBank() method Call validator.validateLimit()
	 * method Call validator.validateTxnRights() method Call
	 * validator.validateAccountNature() method if both credit and debit
	 * branches are different { Call validator.validateTodaysTxnLimit() method
	 * Call validator.validateInterBranchLimit() method } if bankSystem is
	 * NonCore { Call validator.validateTransfer() method }
	 * 
	 * @param transaction
	 * @return boolean
	 */
	public boolean validate(Transaction transaction)
			throws SBIApplicationException {
		this.transaction = transaction;
		if (transaction != null) {
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODBEGIN);
			if (logger.isDebugEnabled()) {
				logger.debug("transaction :" + transaction.toString());
			}
			validator.validateTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), new Integer(
							BPConstants.DEBIT_NO));
			validator.validateInterBank(transaction.getDebit().getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode());
			validator.validateAccountNature(
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getAccountNo(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getUserName(), transaction.getName());

			validator.validateAmount(transaction.getDebit().getAmount());
			if(!(transaction.getDebit().getAmount().doubleValue()==transaction.getCredit()[0].getAmount().doubleValue())){
				logger.info("Debi and credit amount is not same");
				SBIApplicationException.throwException("TAM001");
			}
			validator.validateAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getUserName(),
			          transaction.getDebit().getAmount());
			validator.validateLVTLimitPerDay (transaction.getDebit().getAmount(),transaction.getDebit().getUserName(), transaction.getBankCode());
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime()); 
			
			int newBeneficairyCount=0;
			
			newBeneficairyCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "THIRDPARTY", transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "RETAIL",transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
			
			if(newBeneficairyCount>0){
				transaction.getDebit().setIsNewlyAddedTp("YES");
				if(transaction.isScheduled()||transaction.isSiTxn()){
					SBIApplicationException.throwException("TPB006");
				}else{
					validator.newBeneficiaryAdditionLimitValidation(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "RETAIL", "THIRDPARTY", transaction.getBankCode(),transaction.getDebit().getAmount(),transaction.getCredit()[0].getBranchCode());
				}
			}
			
			
			String txnPath = transaction.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
            
            if(transaction.getBankCode().equalsIgnoreCase("0")){
            	logger.info("NRE accounts validations for SBI bank -part");
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
            	
            }
            
            else if(txnPath.equals("CMC")){
        		
        		  String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
        		  logger.info("TP Transaction path is CMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
  	      		  }
  	      		  else {
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	      		  }
        		  
              }
              
              else if(txnPath.equals("NCMC")){
              	
              	 String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
              	 logger.info("TP Transaction path is NCMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
  	            	
  	      		  }
  	      		 else{
  	             	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	             	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	             } 
              	
              }
            
            else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of SBI loop 
            else{ // for associate banks
            	logger.info("NRE accounts validations for Associate banks -part");
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of else part-Associate banks
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);

			/*** 
			 * Calling New Method to Validate the Based on the Category Wise overriding the existing all limit Validation
			 */
			
            String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
            validator.validateSubCategoryGroupALimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, bankCode, "Thirdparty");
            
            logger.info("Validation returns true");
            
			validator.validateCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,bankCode);			
		
			//changed by Lenin for Kony
			/*if(transaction.getMobileFlag()!=null && "yes".equalsIgnoreCase(transaction.getMobileFlag())){
				logger.info("Mobile category wise validation");
						validator.validateMobileCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode());
			}*/	
			//Added By Lenin for Kony
			
			if(transaction.getMobileFlag()!=null){
				String channel = null ;
				if("yes".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "MINB";
				}else if("mapp_inb".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "mapp_inb";
				}
				validator.validateMobileCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode(),channel);
			}
		 
		
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		return true;
	}

	/**
	 * Validator injection
	 * 
	 * @param validator
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	}

	public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}
	

}
