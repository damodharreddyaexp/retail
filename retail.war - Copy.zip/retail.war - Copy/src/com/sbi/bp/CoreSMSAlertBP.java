/*
 * CR 5572
 */
package com.sbi.bp;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.cache.UserSessionCache;
import com.sbi.common.model.User;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.dao.DAOConstants;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.model.UserProfile;
import com.sbi.service.ServiceErrorConstants;
import com.sbi.utils.LoggingConstants;

public class CoreSMSAlertBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private CoreDAOImpl coreDAOImpl ;
	public Map getCIFMobileNoFromCore ( Map requestDataMap){
		logger.info("getCIFMobileNoFromCore ( Map requestDataMap) -start");
		Map responseDataMap = new HashMap ();
		List responseDataList = new ArrayList();
		requestDataMap.put("txnno" ,"000400");
		responseDataList = coreDAOImpl.getDataFromBankSystem(requestDataMap); // get responselist  for 400
		validateCoreResponse(responseDataList);
		responseDataMap = (Map)responseDataList.get(0);    	
    	//if 400 is a valid response then fire 67050 with cif for mobile no enquiry
    	if (responseDataMap !=null && responseDataMap.get("cif_no")!= null && !responseDataMap.get("cif_no").equals(""))	{
			requestDataMap.put("txnno", "067050");
			requestDataMap.put("customer_number", responseDataMap.get("cif_no"));
			responseDataList = coreDAOImpl.getDataFromBankSystem(requestDataMap); // get response list for  67050
			validateCoreResponse(responseDataList);
			responseDataMap = (Map)responseDataList.get(0);
			//outParam.put("mobile_no","");
		}
		logger.info("outParam" + responseDataMap);
		logger.info("getCIFMobileNoFromCore ( Map requestDataMap) -start");
					return responseDataMap;
	}
	
	public void updateMobileNoWithCBS (Map requestDataMap){
		List responseDataList = new ArrayList();
		requestDataMap.put("txnno", "067000");
		responseDataList = coreDAOImpl.getDataFromBankSystem(requestDataMap); // get responselist  for 067000
		validateCoreResponse(responseDataList);
		
	}
	
	private boolean  validateCoreResponse(List  responseDataList)  {
		logger.info("validateCoreResponse(List  responseDataList) - begin");
		Map coreResponse = new HashMap();
		if(responseDataList !=null && responseDataList.size() > 0)
    	{
			coreResponse = (HashMap) responseDataList.get(0);
            if(coreResponse != null)
            {
            	String status = null;
                String errorCode = null;
                if(coreResponse.get("status") != null)
                	status = (String)coreResponse.get("status");
                if(coreResponse.get("error_code") != null){
                	errorCode = (String)coreResponse.get("error_code");
                	status = errorCode; 
                }
             
                if(status == null  && (errorCode == null  || errorCode.equalsIgnoreCase(""))){
                
                	return true; 
                }
                else if (coreResponse.get("status")!=null && "O.K.".equalsIgnoreCase((String)coreResponse.get("status")))
                {
                	return true; 
                }
                else
                {
                    SBIApplicationException.throwException(status);
                }
            }
            else
            {  
                SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
    	}
		
		else {
			SBIApplicationException.throwException(ServiceErrorConstants.SE002);
	                     
		}
		logger.info("validateCoreResponse(List  responseDataList) - end");
		return false;
	}
	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	
}
