/*      
 * IBTransactionInformationBP.java
 * Created on Nov 29, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 29, 2005 MURUGAN K - Initial Creation and Implemetations
//April 29, 2006 PONNUSAMY - One method added -CR 897&972
//May 25, 2006 PONNUSAMY  CR 1267 added
//Changed on 26-June-2006 for Paladion by Saravanan N
package com.sbi.bp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.context.NoSuchMessageException;

import com.sbi.common.utils.CommissionUtils;
import com.sbi.dao.BankSystemDAO;
import com.sbi.dao.ChequeStopPaymentDAO;
import com.sbi.dao.IBTransactionDAO;
import com.sbi.dao.SwitchDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.RetailTransaction;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.model.TransactionResponse;
import com.sbi.utils.DisplayEcheques;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.TxnFormatter;
import com.sbi.utils.UtilsConstant;



/**
 * TODO This class is used to  get the Transaction information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class IBTransactionInformationBP {

    protected final Logger logger = Logger.getLogger(getClass());

    private IBTransactionDAO ibTransactionDAOImpl;

    private ChequeStopPaymentDAO chequeStopPaymentDAOImpl;

    private TxnFormatter switchTxnFormatter;

    private SwitchDAO switchDAOImpl;
    
    private BankSystemDAO coreTransactionDAOImpl;     //Added by mega for DD Commission 
        
    private CommissionUtils commissionUtils;//Added for CR-5178
    
    private ResourceBundleMessageSource commissionProperties; //Added by Anil for DD commission waiver for Defence

    //Added by mega for DD Commission
    //To validate the Staff Account for DDCommission
    //Commented for CR-5178 STARTS
   /* public boolean findStaffAccount(String userName, String debitAccountNo) {
    	
		logger.debug("findStaffAccount() - "+ LoggingConstants.METHODBEGIN);
		boolean staffAcc = false;
		try {
			staffAcc = ibTransactionDAOImpl.validateStaffAccount(userName, debitAccountNo);
			logger.info("Validate Staff Account Result : "+staffAcc);
		} catch (DAOException daoException) {
			logger.error(LoggingConstants.EXCEPTION, daoException);
			SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
		}
		logger.debug("findStaffAccount() - "+ LoggingConstants.METHODEND);
		return staffAcc;
	}    
    */
  //Commented for CR-5178 ENDS
    //Added by mega for DD Commission
    //To get the reference no for DDCommssion
   /* public String getDDSequenceID() {
		logger.debug("getDDSequenceID() - "+ LoggingConstants.METHODBEGIN);
		String ddSequenceID = null;
		try {
			ddSequenceID = ibTransactionDAOImpl.createDDSequenceID();
		} catch (DAOException daoException) {
			logger.error(LoggingConstants.EXCEPTION, daoException);
			SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
		}
		logger.debug("getDDSequenceID() - "+ LoggingConstants.METHODEND);
		return ddSequenceID;
	}
      
    //Added by mega for DD Commission
    //To get the commission from the core for DDCommssion
	public Map getDDCommissionFromCore(Map inputParams) {
		logger.debug("getDDCommissionFromCore - "+ LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		List responseList = null;
		String debitAccountNo = (String) inputParams.get("debitAccountNo");
		String debitAmount = (String) inputParams.get("amountTransfer");
		String bankCode = (String) inputParams.get(UtilsConstant.BANK_CODE);
		try {
			logger.debug("inputParams:" + inputParams);
			if (debitAccountNo != null && debitAmount != null && bankCode != null) {
				Map requestParam = new HashMap();
				//Setting the parameters to be passed to the core for DDCommission
				requestParam.put("transAmount", StringUtils.emptyStringCheckForDouble(debitAmount));
				requestParam.put("debt_acc_no", debitAccountNo);
				requestParam.put(UtilsConstant.TXN_NO, (String) inputParams.get(UtilsConstant.TXN_NO));
				requestParam.put("reference_no", (String) inputParams.get(UtilsConstant.DD_SEQUENCEID));
				requestParam.put(UtilsConstant.BANK_CODE, bankCode);
				requestParam.put(UtilsConstant.DEBIT_BRANCH_CODE, (String) inputParams.get(UtilsConstant.DEBIT_BRANCH_CODE));
				requestParam.put(UtilsConstant.CREDIT_BRANCH_CODE, (String) inputParams.get(UtilsConstant.DD_CREDIT_BRANCH));
				requestParam.put("account_no", debitAccountNo);
				requestParam.put("amount", StringUtils.getCoreAmount(StringUtils.emptyStringCheckForDouble(debitAmount)));// its for req string
				requestParam.put(UtilsConstant.SEGMENT, (String) inputParams.get(UtilsConstant.SEGMENT));

				responseList = coreTransactionDAOImpl.getDataFromBankSystem(requestParam);
				outParams.put("ddCommisionList", responseList);
			} 
		} catch (DAOException daoException) {
			logger.error(LoggingConstants.EXCEPTION, daoException);
			SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
		}
		logger.debug("getDDCommissionFromCore - "+ LoggingConstants.METHODEND);
		return outParams;
	}*/        

	
	//Megavannan added this method for DD commission
	 /**
	 * Call the [interBankBeneficiaryDAOImpl.getDDCommissionAmount()] return the commision List
	 * @param inputParams
	 * @return List
	 */	
  
	public double getDDCaluculatedCommission(Map inputParams) {
		logger.debug("getDDCommission - " + LoggingConstants.METHODBEGIN);
		double commision = 0.0;
		String debitAccountNo = (String) inputParams.get("debitAccountNo");
		String debitAmount = (String) inputParams.get("amountTransfer");
		String bankCode = (String) inputParams.get(UtilsConstant.BANK_CODE);
		String productDesc=(String) inputParams.get(UtilsConstant.DEBIT_PRODUCT_DESC);
		//////Anil DD Commission waiver for defence prodcut code
		String debitProductCode = (String)inputParams.get(UtilsConstant.DEBIT_PRODUCT_CODE);
		logger.debug("$$$$$$ debitProductCode ##### debitProductCode$$$$$$" + debitProductCode);
		//String ddCommission=UtilsConstant.DD_COMMISSION;

		
		try {
			logger.debug("inputParams:" + inputParams);
			if (debitAccountNo != null && debitAmount != null && bankCode != null) {
				if ("0|A|6".indexOf(bankCode)!=-1) {
					bankCode = "0";
				}
				//Commented and Modified for CR-5178
				//commision = getCommissionAmount(bankCode,new Double(debitAmount),"DD");
				//////Anil DD Commission waiver for defence product code
							Map DDCommission=getDDProductCode(bankCode);
							
							logger.info("productCode"+debitProductCode+"Defence Code!!!!!"+DDCommission.containsValue(debitProductCode));
							if(debitProductCode!=null && DDCommission!=null && DDCommission.size()>0 && DDCommission.containsValue(debitProductCode)){
								commision = 0.0;	
							}else{								
								commision = commissionUtils.getCommissionAmountForRetail(bankCode,new Double(debitAmount),"DD",productDesc," ");
							}
				logger.debug("getDDCommission - " + commision);
			}
		} catch (DAOException daoException) {
			logger.error(LoggingConstants.EXCEPTION, daoException);
			SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
		}
		logger.debug("getDDCommission - " + LoggingConstants.METHODEND);
		return commision;
	}   
	//////Anil DD Commission waiver for defence product code for SBI
		private Map getDDProductCode(String bankCode) {
			logger.error("getDDProductCode(String type) getDDProductCode"+bankCode);
			Map prodCode=new HashMap();
			if( bankCode != null &&bankCode != "" && ("0").equals(bankCode)){
				
				try{
					String ddCommission="ddCommission_"+bankCode;
					String getProdCode=commissionProperties.getMessage(ddCommission,null,null) ;
					logger.error("getDDProductCode(String type) getProdCode"+getProdCode);
					if(getProdCode!=null){
						StringTokenizer st=new StringTokenizer(getProdCode,"|");
						int i=0;
						while( st.hasMoreTokens() ) {
							prodCode.put("prodCode"+i, st.nextToken());
							i++;
		
						}
					}
				}catch(NoSuchMessageException e){
					logger.error("No SuchMessage Exception in getDDProductCode");
				}
				catch (Exception e) {
					logger.error("getDDProductCode catch");
				}
			}	
			return prodCode;
		}	
    
    /**
	 * TODO Call the [iBTransactionDAOImpl.findDebits(userName)] return the Debit Account List
	 * @param userName
	 * @return List
	 */
    //Added for CR 2975
    public List getTransactions(String userName,String transactionType,String fromDate,String toDate) {

        logger.debug("getTransactions(String userName,String fromDate,String toDate) method begin");
        List transactionList = null;
        List resultList = null;
        try {
            if (userName != null) {

                transactionList = ibTransactionDAOImpl.findDebits(userName,transactionType,fromDate,toDate);

            }
            if(transactionList != null && transactionList.size() > 0)
            {
            	resultList = new ArrayList();
            	
            	   for (Iterator<TransactionLeg> it = transactionList.iterator(); it.hasNext(); ) {
                   	TransactionLeg debitLeg = it.next();
                   	if( debitLeg.getMerchantCode() != null)
                   	{
                   	if(debitLeg.getMerchantCode().equals("ERD"))
                   	{
                   		debitLeg.setType("Recurring Deposit");
                   	}
                   	if(debitLeg.getMerchantCode().equals("SBILIFE_INB"))
                   	{
                   		debitLeg.setType("SBI Life Insurance Payment");
                   	}
                   	if(debitLeg.getMerchantCode().equals("NPS"))
                   	{
                   		debitLeg.setType("NPS Contribution");
                   	}
                   	if("POWER_JYOTHI".equalsIgnoreCase(debitLeg.getMerchantCode().trim())) {
                   		debitLeg.setType("Power Jyoti Fee Collection");
                   	}

                   	}
                   	// Dev-445 e-Annuity Deposit Starts Here
                   	if(debitLeg.getType()!=null && "Fixed Deposit".equalsIgnoreCase(debitLeg.getType())){
                   		String fdType=ibTransactionDAOImpl.getFixedDepositType(debitLeg.getReferenceNo());
                   		if(fdType!=null && fdType.trim().length()>0 && "e-Annuity".equalsIgnoreCase(fdType)){
                   			debitLeg.setType("e-Annuity Deposit");
                   		}
                   		if(fdType!=null && fdType.trim().length()>0 && "e-TDR/e-STDR Tax Saving Scheme".equalsIgnoreCase(fdType)){
                   			debitLeg.setType("Fixed Deposit Tax Saving Scheme");
                   		}
                   		if(fdType!=null && fdType.trim().length()>0 && "e-MOD".equalsIgnoreCase(fdType)){
                   			debitLeg.setType("e-MOD Deposit");
                   		}
                   	}
                   	// Dev-445 e-Annuity Deposit ends Here
                   	resultList.add(debitLeg);
                   }
            }
            
         

        }
        catch (DAOException daoException) {
            logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("getTransactions(String userName,String fromDate,String toDate) method end");
        return resultList;
    }
    
    //End of CR 2975
    public List getTransactions(String userName) {

        logger.debug("getTransactions(String userName) method begin");
        List transactionList = null;
        try {
            if (userName != null) {

                transactionList = ibTransactionDAOImpl.findDebits(userName);

            }

        }
        catch (DAOException daoException) {
            logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("getTransactions(String userName) method end");
        return transactionList;
    }

    /**
     * TODO Call the i[BTransactionDAOImpl.findDebits(userName,enquiryStatus)] return the debit account list
     * @param userName
     * @param enquiryStatus
     * @return List
     */
    //code added by Manikanta & Srinivas(required for JSP)
    public int getChallanrequired(String merchantCode){
    	  logger.debug("getChallanrequired(String merchantCode) method begin");
    	  int chalanReq=ibTransactionDAOImpl.getChallanReq(merchantCode);
    	  return chalanReq;
    }
    public List getTransactions(String userName, String enquiryStatus) {
        // logger.info("getTransactions(String userName, String enquiryStatus) method begin");
    	  logger.debug("getTransactions(String userName, String enquiryStatus) method begin");
        List transactionLegList = null;
        try {
            if (userName != null && enquiryStatus != null) {

                transactionLegList = ibTransactionDAOImpl.findDebits(userName, enquiryStatus);

            }

        }
        catch (DAOException daoException) {
             //   logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

         // logger.info("getTransactions(String userName,String enquiryStatus) method end");
        logger.debug("getTransactions(String userName,String enquiryStatus) method end");
        return transactionLegList;
    }

    /**    CR 897&972 added by ponnusamy
     * TODO Call the i[BTransactionDAOImpl.findDebits(userName,transactionType,limit)] return the debit account list
     * @param userName
     * @param transactionType
     * @param limit
     * @return List
     */
    public List getTransactions(String userName, String transactionType,Integer limit) {
        logger.debug("getTransactions(String userName, String transactionType, int limit) method begin");
        List transactionTypeList = null;
        try {
            if (userName != null && transactionType != null && limit != null ) {

           	transactionTypeList = ibTransactionDAOImpl.findDebits(userName,transactionType,limit);
           
            }

        }
        catch (DAOException daoException) {
            //logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("getTransactions(String userName, String transactionType, int limit) method end");
        return transactionTypeList;
    }


    /**
     * TODO Call the [IBTransactionDAOImpl.findDebit(referenceNo)] return the Debit TransactionLeg 
     * Call the [IBTransactionDAOImpl.findCredits(referenceNo))] return the list of Credi TransactionnLeg
     * Build the Transaction object using Debit and Credit TransactionLeg which are returned by above methods 
     * @param userName
     * @param referenceNo
     * @return Transaction
     */
    public Transaction getTransactionDetails(String userName, String referenceNo) {

        Transaction transaction = new RetailTransaction();
        TransactionLeg transactionLeg=new TransactionLeg();
        HashMap addParamsMap;
        logger.debug("getTransactionDetails(String userName, String referenceNo) method begin");
        try {
            //logger.info("Ref. No  " + referenceNo);
            if (userName != null && referenceNo != null && !referenceNo.trim().equalsIgnoreCase("")) {
                String txnType=referenceNo.substring(0,2);
                logger.debug(" Ref.No Substring.... " + txnType);
                // added username as parameter for paladion on 28-06-06 by Saravanan N
              
                TransactionLeg debitLeg = (TransactionLeg) ibTransactionDAOImpl.findDebit(referenceNo,userName);
                
                //CR 1267 -start- added by Ponnusamy
                
                if(txnType!=null&&txnType.equalsIgnoreCase("IK")||txnType!=null&&txnType.equalsIgnoreCase("IG") ||
                		txnType!=null&&txnType.equalsIgnoreCase("IJ")|| txnType!=null&&txnType.equalsIgnoreCase("IU")){
                	addParamsMap= (HashMap)ibTransactionDAOImpl.findAddParams(referenceNo);
	                transactionLeg.setAdditionalParams(addParamsMap);
	                transaction.setAddParams(transactionLeg);
	                if(logger.isDebugEnabled())
	                logger.debug("adparams value from transactionleg........"+transactionLeg.getAdditionalParams());
	                logger.info("adparams value from transaction........"+transaction.getAddParams());
                
                
                if(txnType!=null&&txnType.equalsIgnoreCase("IK")||txnType!=null&&txnType.equalsIgnoreCase("IG"))
                {
	              
                	/*addParamsMap= (HashMap)ibTransactionDAOImpl.findAddParams(referenceNo);
	                transactionLeg.setAdditionalParams(addParamsMap);
	                transaction.setAddParams(transactionLeg);
	                if(logger.isDebugEnabled())
	                	logger.debug("adparams value from transactionleg........"+transactionLeg.getAdditionalParams());
	                logger.info("adparams value from transaction........"+transaction.getAddParams());
	                */
                	
                
	                if(debitLeg != null){
	                	
	                String strRefNo=debitLeg.getThirdPartyRef();
	                String userNameDebitLeg=debitLeg.getUserName();
	                if(logger.isDebugEnabled()){
	                	logger.debug("userNameDebitLeg........."+userNameDebitLeg);
	                	logger.debug("thirdparty referenceno........."+strRefNo);
	                	logger.debug(" Debit Leg " + debitLeg);
	                }
	                Double amount=debitLeg.getAmount();
	                double Amountdouble = amount.doubleValue();
	                if(Amountdouble>0.0){
	                	DisplayEcheques dispEcheques=new DisplayEcheques();
	                	String amountInWords=dispEcheques.currencyInWords(amount+"");
	                	logger.debug("Amount in words....."+amountInWords);
	                	transaction.setAmountInWords(amountInWords);
	                }
	                logger.debug("amount from transactionLeg..........."+amount);
	                
	                if(strRefNo!=null && strRefNo.length()>=18){
	                	 String BSRCode="";
						  String tenderDate="";
						  String challanNo="";						  
						  if(strRefNo.length()>=7){
						   BSRCode=strRefNo.substring(0,7);
						   logger.info("BSRCode"+BSRCode);
						  }
						  if(strRefNo.length()>=12 && strRefNo.length()<=18){
						   tenderDate=strRefNo.substring(12,18);
						   logger.info("tenderDate"+tenderDate);
						  }
						  if( strRefNo.length()>=7 && strRefNo.length()<=18){
						   challanNo=strRefNo.substring(7,12);
						   logger.info("challanNo"+challanNo);
						  }
						  transaction.setBsrCode(BSRCode);
						  transaction.setTenderDate(tenderDate);
						  transaction.setChallanNo(challanNo);
						    	
	                 }
		                // added by saravanan for paladion on 26/06/06
	               }else{
	            	   SBIApplicationException.throwException(BPConstants.INPUT_IRREGULARITY_CODE);
	               }//end of paladion
	                List OLTASMerCodelst=new ArrayList() ;
            	   	DisplayEcheques displayEcheques = new DisplayEcheques();
			  		OLTASMerCodelst=displayEcheques.displayOLTAS(addParamsMap);
			  		logger.info("the oltas list size is..."+OLTASMerCodelst);
			  		addParamsMap.put("OLTASMerCodelst",OLTASMerCodelst);
			  		
                }
                }
                //CR 1267 -end - added by Ponnusamy
                
                List creditLegList = (List) ibTransactionDAOImpl.findCredits(referenceNo);
                TransactionLeg creditLeg[] = null;
                if (creditLegList != null && creditLegList.size() > 0) {
                    creditLeg = new TransactionLeg[creditLegList.size()];

                    for (int i = 0; i < creditLegList.size(); i++) {
                        creditLeg[i] = (TransactionLeg) creditLegList.get(i);
						//Added for RTGS/NEFT
						 if ((referenceNo.substring(0,2).equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)||referenceNo.substring(0,2).equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT) ) 
								 && creditLeg[i].getNarrative2()!=null ) {
                          String[] arrNarrative2 =  creditLeg[i].getNarrative2().split("\\|");
	                      creditLeg[i].setNarrative2(arrNarrative2[2]);
	                      creditLeg[i].setNarrative3(arrNarrative2[3]);
						  //Ended for RTGS/NEFT
                        }
                    }
                }
                else {
                    SBIApplicationException.throwException(BPConstants.CREDIT_TRANSACTION_LEG);
                    
                }
                transaction.setDebit(debitLeg);
                transaction.setCredit(creditLeg);
                logger.info("Transction's Debit   Leg: " + debitLeg.toString());
                    logger.debug("Transaction's Credit Leg: " + creditLeg.toString());
                }
            }
        catch (DAOException doaException) {
            logger.error("Exception occured : " + doaException);
            SBIApplicationException.throwException(doaException.getErrorCode());
        }

        logger.debug("getTransactionDetails(String userName, String referenceNo) method end");
        return transaction;
    }

    //CR 2061 - Start
    
    public Map getMPGOVTDetails(String referenceNo) {
        
        logger.debug("getMPGOVTDetails(String referenceNo) method begin");
        logger.info("Reference No :"+referenceNo);
        
        Map displayData = new HashMap();
        
        Map supplierParams = null;
       
        try
        {
                if (referenceNo != null && !referenceNo.trim().equalsIgnoreCase("")) {

                    supplierParams = ibTransactionDAOImpl.getSupplierParams(referenceNo);
                    logger.info("Supplier Params :"+supplierParams);
                    
                }

        }
        catch (DAOException daoException)
        {
            logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
              
        if (supplierParams != null && supplierParams.size() > 0) {
            
            String period=(String)supplierParams.get("outref18");
            String periodname = "";
            if(period.equals("1"))
                periodname = "April";
            else if(period.equals("2"))
                periodname = "May";
            else if(period.equals("3"))
                periodname = "June";
            else if(period.equals("4"))
                periodname = "July";
            else if(period.equals("5"))
                periodname = "August";
            else if(period.equals("6"))
                periodname = "September";
            else if(period.equals("7"))
                periodname = "October";
            else if(period.equals("8"))
                periodname = "November";
            else if(period.equals("9"))
                periodname = "December";
            else if(period.equals("10"))
                periodname = "January";
            else if(period.equals("11"))
                periodname = "February";
            else if(period.equals("12"))
                periodname = "March";
            else if(period.equals("41"))
                periodname = "First Quarter";
            else if(period.equals("42"))
                periodname = "Second Quarter";
            else if(period.equals("43"))
                periodname = "Third Quarter";
            else if(period.equals("44"))
                periodname = "Fourth Quarter";
            else if(period.equals("99"))
                periodname = "Yearly";
            else if(period.equals("98"))
                periodname = "Others";
            
            displayData.put("periodname",periodname);
            displayData.put("supplierParams", supplierParams);
            logger.info("Display Data :"+displayData);
                
            }
        
        else {
           
             SBIApplicationException.throwException(BPConstants.CREDIT_TRANSACTION_LEG);
        }
        logger.debug("getMPGOVTDetails(String referenceNo) method end");
        return displayData;

}

    
public Map getICEGATEDetails( String referenceNo ) {
    
    logger.debug("getICEGATEDetails(String referenceNo) method begin");
    logger.info("Reference No :"+referenceNo);
        
        Map icegateMap = new HashMap();
        Map resultMap = new HashMap();
    
        try
        {
                if (referenceNo != null && !referenceNo.trim().equalsIgnoreCase("")) {

                    icegateMap = ibTransactionDAOImpl.findICEGATEDetails(referenceNo);
                    logger.info("ICEGATE Details :"+icegateMap);
                }

        }
        catch (DAOException daoException)
        {
            logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        
        
        
        if (icegateMap!=null && icegateMap.size()>0)
        {
            resultMap.put("corpRefNo",(String)icegateMap.get("corpRefNo"));
            resultMap.put("echequeNo",(String)icegateMap.get("echequeNo"));
            resultMap.put("amt",(String)icegateMap.get("amt"));
            resultMap.put("outref2",(String)icegateMap.get("outref2"));
            resultMap.put("amount",(String)icegateMap.get("amount"));
            resultMap.put("outref3",(String)icegateMap.get("outref3"));
            resultMap.put("referenceNo",(String)icegateMap.get("referenceNo"));
            resultMap.put("strDate",(String)icegateMap.get("strDate"));
            resultMap.put("outref4",(String)icegateMap.get("outref4"));
            resultMap.put("outref6",(String)icegateMap.get("outref6"));
            resultMap.put("branch_code",(String)icegateMap.get("branch_code"));
            resultMap.put("branch_name",(String)icegateMap.get("branch_name"));
            resultMap.put("custom_desc",(String)icegateMap.get("custom_desc"));
            
        }
        else
        {
           
            SBIApplicationException.throwException(BPConstants.CREDIT_TRANSACTION_LEG);
        }
        logger.debug("getICEGATEDetails(String referenceNo) method end");
        return resultMap;
        
    }
   
    //CR 2061 - End
   
    public List getChequeStatus(String accountNo, String branchCode, Integer[] chequeNo) {

        logger.info("getChequeStatus(String accountNo, String branchCode, Integer[] chequeNo) method begin");
        List chequeStatusList = null;
        try {
            if (accountNo != null && branchCode != null && chequeNo != null) {

                chequeStatusList = chequeStopPaymentDAOImpl.findChequeStatus(accountNo, branchCode, chequeNo);
            }

        }
        catch (DAOException doaException) {
            logger.error("Exception occured : ", doaException);
            SBIApplicationException.throwException(doaException.getErrorCode());
        }

        logger.info("getChequeStatus(String accountNo, String branchCode, Integer[] chequeNo) method end");
        return chequeStatusList;
    }

    public TransactionResponse cancelTransaction(String referenceNo) {

        Map requestData = new HashMap();
        requestData.put(BPConstants.REFERENCE_NO, referenceNo);
        requestData.put(BPConstants.TXNNO, BPConstants.SWITCH_CANCEL_TXN_TXNNO);
        List switchData = switchDAOImpl.getDataFromBankSystem(requestData);
        logger.info("switchData " + switchData.get(BPConstants.ZERO_INT));
        HashMap bankSystemDataHash = (HashMap) switchData.get(BPConstants.ZERO_INT);
        if (logger.isDebugEnabled()) {
            logger.debug("bankSystemDataHash is :" + bankSystemDataHash);
        }
        logger.info("BankSystemDataHash " + bankSystemDataHash);

        Map transactionResponseData = switchTxnFormatter.getTransactionResponseFormat(bankSystemDataHash);

        TransactionResponse transactionResponse = new TransactionResponse();
        transactionResponse.setResponseDate((Timestamp) transactionResponseData.get(BPConstants.RESPONSE_DATE));
        transactionResponse.setResponseReference((String) transactionResponseData.get(BPConstants.RESPONSE_REFERENCE));
        transactionResponse.setStatusCode((String) transactionResponseData.get(BPConstants.STATUS));
        transactionResponse
                .setStatusDescription((String) transactionResponseData.get(BPConstants.RESPONSE_DESCRIPTION));
        ibTransactionDAOImpl.updateStatus(transactionResponse, referenceNo);

        return transactionResponse;
    }
    //Added for CR 5615

    public Map getIBTransactionCreditDetails (String utrNo){
    	logger.info("getTransactionCreditDetails (String referenceNo) begins") ;
    	Map outParam = new HashMap();
        try
        {
                if (utrNo != null && !utrNo.trim().equalsIgnoreCase("")) {
                	outParam = ibTransactionDAOImpl.getIBTransactionCreditDetails(utrNo);
                	logger.info("creditDetails :"+outParam);
                }

        }
        catch (DAOException daoException)
        {
            logger.error("Exception occured : ", daoException);
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
    	logger.info("getTransactionCreditDetails (String referenceNo) ends") ;
    	return  outParam;
    }
    //Added for DD Commission.
    //Commented for CR-5178 STARTS
    /*private double getCommissionAmount(String bankCode,Double debitAmount,String merchantCode) throws DAOException{
		List commList=interBankBeneficiaryDAOImpl.getCommissionAmount(bankCode,merchantCode,debitAmount);
		double commAmount=0;
		if(commList!=null && commList.size()>0) {
			Map commissionMap=(Map)commList.get(0);
			double minAmount=0;
			double maxAmount=0;
			BigDecimal percentageValue=(BigDecimal)commissionMap.get("PERCENTAGE_VALUE");
			BigDecimal minAmountVal=(BigDecimal)commissionMap.get("MIN_AMOUNT");
			BigDecimal maxAmountVal=(BigDecimal)commissionMap.get("MAX_AMOUNT");
			BigDecimal baseValue=(BigDecimal) commissionMap.get("BASE_VALUE");
			logger.info("baseValue:::"+baseValue);
			
			if (percentageValue==null )
				percentageValue=new BigDecimal(0);
			if(baseValue!=null&& baseValue.intValue()!=0)
			{
				logger.info("into the bae calculation");
				commAmount=(Math.ceil(debitAmount.doubleValue()/baseValue.doubleValue())*(percentageValue.doubleValue()));
				logger.info("calculated com"+commAmount);
			}else
				commAmount=(debitAmount.doubleValue())*(percentageValue.doubleValue()/100);
			if (minAmountVal==null )
				minAmountVal=new BigDecimal(0);
			if (maxAmountVal==null )
				maxAmountVal=new BigDecimal(0);
			
			minAmount=minAmountVal.doubleValue();
			maxAmount=maxAmountVal.doubleValue();
			
				if (commAmount<minAmount)
					commAmount=minAmount;
				else if (commAmount>maxAmount && maxAmount != 0)
					commAmount=maxAmount;
			BigDecimal comAmount=new BigDecimal(commAmount);	
			//comAmount=comAmount.setScale(2,BigDecimal.ROUND_HALF_EVEN);
			//commAmount=comAmount.doubleValue();
			
			//Added for round off to the next 25 paise.
			
			if(comAmount != null && comAmount.toString().indexOf(".") != -1){
				BigDecimal roundedComAmount=comAmount.setScale(0 ,BigDecimal.ROUND_FLOOR);	
				double paise = new Double(comAmount.toString().substring(comAmount.toString().indexOf("."),comAmount.toString().length())).doubleValue();
				double roundoff= 0.25; 
				commAmount=roundedComAmount.doubleValue() + (Math.ceil(paise /roundoff) * roundoff) ;
				logger.info("Commission Amount"+commAmount);
			}
		}
		return commAmount;
	}*/
    //Commented for CR-5178 ENDS
    //End
    /**
     * TODO IBTransactionDAOImpl object injection done here
     * @param transactionDAOImpl void
     */

    public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl) {
        this.ibTransactionDAOImpl = ibTransactionDAOImpl;
    }

    public void setChequeStopPaymentDAOImpl(ChequeStopPaymentDAO chequeStopPaymentDAOImpl) {
        this.chequeStopPaymentDAOImpl = chequeStopPaymentDAOImpl;
    }

    public void setSwitchDAOImpl(SwitchDAO switchDAOImpl) {
        this.switchDAOImpl = switchDAOImpl;
    }

    public void setSwitchTxnFormatter(TxnFormatter switchTxnFormatter) {
        this.switchTxnFormatter = switchTxnFormatter;
    }


	public void setCoreTransactionDAOImpl(BankSystemDAO coreTransactionDAOImpl) {
		this.coreTransactionDAOImpl = coreTransactionDAOImpl;
	}

	public void setCommissionUtils(CommissionUtils commissionUtils) {
		this.commissionUtils = commissionUtils;
	}
	///Added by Anil for DD Commission waiver
	public void setCommissionProperties(
			ResourceBundleMessageSource commissionProperties) {
		this.commissionProperties = commissionProperties;
	}

}
