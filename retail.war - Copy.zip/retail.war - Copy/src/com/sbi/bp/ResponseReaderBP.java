
/*
 * ResponseReaderBP.java
 * Created on Jun 24, 2008
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jun 24, 2008 MS67276 � Initial Creation

package com.sbi.bp;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.utils.EzConstants;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.ResponseReader;
import com.sbi.utils.ResponseReaderFactory;

/**
 * 
 * This class is used to read the response xml from external system.
 *
 */


public class ResponseReaderBP
{
	private ResponseReaderFactory responseReaderFactory;
	
	/**
	 * 
	 * @param xmlDocument
	 * @return
	 * Steps:
	 * 1. Get 'typeOfResponse' variable from input map.
	 * 2. Call readResponse() method of responseReaderFactory to get
	 *    appropriate reader by passing this variable.
	 */   
	
    private final Logger logger=Logger.getLogger(getClass());

	public Map readResponse(Map input ) throws Exception
	{
        logger.info("ResponseReaderBP - "+ LoggingConstants.METHODBEGIN);        

        logger.info("Response Type :"+(String)input.get(EzConstants.EZ_RESPONSE_TYPE));

        ResponseReader responseReader = responseReaderFactory.readResponse((String)input.get(EzConstants.EZ_RESPONSE_TYPE));
        
        Map responseXml= new HashMap();
        responseXml= responseReader.readResponse(input);
        
        logger.info("ResponseReaderBP - "+ LoggingConstants.METHODEND);            
        
        return responseXml;
	}

    public void setResponseReaderFactory(ResponseReaderFactory responseReaderFactory)
    {
        this.responseReaderFactory = responseReaderFactory;
    }

}
