/*     
 *AccountInformationBP.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 MURUGAN K - Initial Creation
// Nov 24, boopathi - changed accountType to productType
// Feb 09, PONNUSAMY G - CHANGES ADDED FOR NRI PIS ACCOUNT -CR 2957
package com.sbi.bp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.commons.lang.StringUtils;

import com.sbi.dao.AccountDAO;
import com.sbi.dao.AccountMasterDAO;
import com.sbi.dao.AccountMasterDAOFactory;
import com.sbi.dao.DAOConstants;
import com.sbi.dao.LoanAccountMasterDAO;
import com.sbi.dao.TransactionHistoryDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.AccountDetails;
import com.sbi.model.LoanAccountDetails;
import com.sbi.model.TransactionAccountDetails;
import com.sbi.service.ServiceConstant;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;
import com.sbi.dao.CoreDAO;


/**
 * TODO we get the Account related informations from this class
 *  
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class AccountInformationBP {

    private AccountDAO accountDAOImpl;

    private AccountMasterDAOFactory accountMasterDAOFactory;

    private TransactionHistoryDAO transactionHistoryDAOImpl;
    
    private Validator validator; // added for NRI-Survey;
    
    protected final Logger logger = Logger.getLogger(getClass());

    SBIApplicationException applicationException = new SBIApplicationException("Exception in BP");
//Account statement address change ---start

    /* CR -147 START */
	private LoanAccountMasterDAO loanaccountDetails;
	/* CR -147 END */
    
    private CoreDAO coreDAOImpl;

	/**
	 * TODO 1. Invokes coreDAOImpl.getDataFromBankSystem to get account address.
	 * Return the list
	 * 
	 * @param Map
	 *            containing txnno,fetch_indicator,Account number,bankCode
	 * @return Map
	 */
	public Map getAddressFromCore(Map requestParams) {
		logger.info("getAddressFromCore(Map requestParams) - begin");
		Map addressMap = new HashMap();
		List responseList = new ArrayList();
		logger.info("requestParams :" + requestParams);
		logger.info("bankCode :" + requestParams.get("bankCode"));
		responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
		logger.info("responseList:" + responseList);
		if (responseList != null && responseList.size() > 0) {
			addressMap = (Map) responseList.get(0);
			String status = (String) addressMap.get("status");
			String statement = (String) addressMap.get("statement");
			String errorCode = (String) addressMap.get("error_code");
			logger.info("status :" + status);
			logger.info("statement :" + statement);
			// checking for null returned by core --- start
			addressMap.put("address1",(StringUtils.defaultIfEmpty((String) addressMap.get("address1"), "")));
			logger.info("address1 :" + StringUtils.defaultIfEmpty((String) addressMap.get("address1"), ""));
			addressMap.put("address2",(StringUtils.defaultIfEmpty((String) addressMap.get("address2"), "")));
			logger.info("address2 :" + StringUtils.defaultIfEmpty((String) addressMap.get("address2"), ""));
			addressMap.put("address3",(StringUtils.defaultIfEmpty((String) addressMap.get("address3"), "")));
			logger.info("address3 :" + StringUtils.defaultIfEmpty((String) addressMap.get("address3"), ""));
			addressMap.put("address4",(StringUtils.defaultIfEmpty((String) addressMap.get("address4"), "")));
			logger.info("address4 :" + StringUtils.defaultIfEmpty((String) addressMap.get("address4"), ""));
			addressMap.put("postal_code",(StringUtils.defaultIfEmpty((String) addressMap.get("postal_code"), "")));
			logger.info("postal_code :" + StringUtils.defaultIfEmpty((String) addressMap.get("postal_code"), ""));
			// checking for null returned by core --- end
			if (status != null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2"))) {
				SBIApplicationException.throwException("F1");
				
			}
			if (status != null && status.equalsIgnoreCase("ERR.")) {
				SBIApplicationException.throwException("SE002");
			}
		}
		logger.info("getAddressFromCore(Map requestParams) - end");
			return addressMap;
	}

//Account statement address change ---end
    /**
     * TODO 1. Invokes AccountDAO.findAccounts to get account list object 2.
     * Return the list
     * 
     * @param userName
     * @return List
     */

    public List getUserAccounts(String userName) {

        
        List accountList = new ArrayList();
        try {
            if (userName != null && !(userName.trim().equals(""))) {

                accountList = accountDAOImpl.findAccounts(userName);
                if (accountList != null) {
                     return accountList;
                }
 
            }
        }
        catch (DAOException daoException) {            
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("Account List :" + accountList);        
        return accountList;
    }
 
    /**
     * TODO get the Account List based on Account Type, call
     * AccountDAOImpl.findAccounts(username,productType)
     * 
     * @param username
     * @param productType
     * @return List
     */
    public List getUserAccounts(String username, String productType) {
        List accountList = null;
        logger.debug("User name: " + username + " Account Type: " + productType);
        try {
            if (username != null && productType != null) {
                accountList = accountDAOImpl.findAccounts(username, productType);
            }
            else {
                logger.debug("User name and Account Type are NULL");
            }
        }
        catch (DAOException daoException) {            
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List " + accountList);
        return accountList;

    }

    public List getUserAccounts(String userName, String productType, String accessLevel) {
        return null;
    }
    
    
    public List getUserAccountsNroTds(String username, String productType,String productDescription) {
        List accountList = null;
        logger.debug("User name: " + username + " Account Type: " + productType +" productDescription: " + productDescription);
        try {
            if (username != null && productType != null && productDescription!=null) {
                accountList = accountDAOImpl.findAccountsNroTds(username, productType,productDescription);
            }
            else {
                logger.debug("User name and Account Type are NULL");
            }
        }
        catch (DAOException daoException) {            
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List " + accountList);
        return accountList;

    }
    /**
     * 1. Invokes AccountDAO.findAccounts(username,productType) to get account
     * list object 2. Return the list
     */
    public List getLoanAccounts(String userName, String[] productType, Integer accessLevel ) {
        
        
        
        return null;
    }

    /**
     * 1. Set accountNature to 2. 2. Invokes
     * AccountDAO.findAccountsByNature(username,accountNature) to get account
     * list object. 3. Return the list
     */ 
    public List getPPFAccounts(String userName, String[] productType, Integer accessLevel) {
        
        List ppfAccountList = null;
        if(userName != null && productType != null && accessLevel != null  ) 
        {
        try{
           
            ppfAccountList = accountDAOImpl.findAccounts(userName, productType,accessLevel );
        }  
        catch(DAOException doaExp)
        {
            SBIApplicationException.throwException(doaExp.getErrorCode(), doaExp); 
        }
        
        }
        return ppfAccountList;
    }

    /**
     * TODO 1. Call accountDAOImpl.findAccountsWithBalance(username) 2. Return
     * Accounts List object
     * 
     * @param username
     * @return List
     */

    public List getUserAccountsWithBalance(String userName,Boolean accountLimit) {
        
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {

            try {            	
                accountList = accountDAOImpl.findAccountsWithBalance(userName,accountLimit);
 
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name:" + userName);
        }
        logger.debug("Account List: " + accountList);
        
        return accountList;
    }

    public List getUserAccountsWithoutBalance(String userName,Boolean accountLimit) {
        logger.debug("getUserAccountsWithoutBalance(String username) method begin");
        logger.debug("User name: " + userName);
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {

            try {  
            		accountList = accountDAOImpl.findAccountsWithoutBalance(userName,accountLimit);
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name:" + userName);
        }
        logger.debug("Account List: " + accountList);
        logger.debug("getUserAccountsWithoutBalance(String username) method end");
        return accountList;
    }

    //Added for EZTrade
    public List getUserTradingAccountsWithBalance(String userName) {
        logger.debug("getUserTradingAccountsWithBalance(String userName) method begin");       
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {

            try {  
            	
            		accountList = accountDAOImpl.findTradeAccountsWithBalance(userName);
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name input is null or empty:" + userName);
        }
        logger.debug("Account List: " + accountList);
        logger.debug("getUserTradingAccountsWithBalance(String userName) method end");
        return accountList;
    }
    public List getUserTradingAccountsWithoutBalance(String userName) {
        logger.debug("getUserTradingAccountsWithoutBalance(String userName) method begin");       
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {

            try {  
            	
            		accountList = accountDAOImpl.findTradeAccountsWithoutBalance(userName);
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name input is null or empty:" + userName);
        }
        logger.debug("Account List: " + accountList);
        logger.debug("getUserTradingAccountsWithoutBalance(String userName) method end");
        return accountList;
    }
    
    public List findNRIPISAccountDetails(List accountList, String userName){
    	List clubbedAccountList=new ArrayList();
    	Account account = null;
    	List tradingPISAccountList=accountDAOImpl.findTradeAccountsWithoutBalance(userName);
    	 if(accountList!=null && accountList.size()>0)
 		{
     		for(int i=0;i<accountList.size();i++)
     		{
     			clubbedAccountList.add(accountList.get(i));
     		}
 		}
 		if(tradingPISAccountList!=null && tradingPISAccountList.size()>0)
 		{
 			for (int i = 0; i < tradingPISAccountList.size(); i++) {        				
                 account = (Account) tradingPISAccountList.get(i);
                 clubbedAccountList.add(account);
 			}
 		}
    	return clubbedAccountList;
    }
    //End - EZTrade
    /**
     * 1. Set accountNature to 1. 2. Invokes
     * AccountDAO.findAccountsByNature(username,accountNature) to get account
     * list object. 3. Return the list
     */
    public List getThirdPartyAccounts(String username) {
        return null;
    }

    public List getUserAccountsWithBalance(String userName, String accessLevel, String productType) {

        return null;

    }

    // Change to getTransactionAccounts
    /**
     * TODO Invoce the
     * AccountDAOImpl.findTransactionAccount(userName,productType) to get the
     * filtered account list
     * 
     * @param userName
     * @param productType
     * @return List
     */
    public List getTransactionAccounts(String userName, String productType) {
        List transactionAccountList = null;
        try {
            transactionAccountList = accountDAOImpl.findTransactionAccount(userName, productType);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Transaction acccount list : " + transactionAccountList);
        return transactionAccountList;
    }
    
    public List getTransactionMajorMinorAccounts(String userName, String productType) {
        List transactionAccountList = null;
        try {
            transactionAccountList = accountDAOImpl.findAccountsWtBalanceByAccessLevel(userName, ServiceConstant.DEBIT_ACCOUNT, 8,9);//(userName, productType,8,9);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Transaction acccount list : " + transactionAccountList);
        return transactionAccountList;
    }

    public List getAccounts(String username) {
        return null;
    }
    
    //Added by Madhanfor Balance CR
    public AccountDetails getUserAccountDetailsNew(String accountNo, String branchCode, String userName) {
        AccountDetails accountDetails = null;
        logger.info("getUserAccountDetails(String accountNo, String branchCode,String userName) method begin");
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if(account == null){
                	account = accountDAOImpl.findBMAccount(accountNo, branchCode, userName);
                }
                // added for NRI PIS accounts -start
                if(account == null){
                	account = accountDAOImpl.findNRIPISAccount(accountNo, branchCode, userName);
                }
                // added for NRI PIS accounts -end
                
                //Added for CR 5039
                if(account == null){
                    account = accountDAOImpl.findClosedAccountsDetails(accountNo, branchCode, userName);
                }
                //End of CR 5039
                if (account != null) {
                    logger.info("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                    
                    	accountDetails = accountMasterDAO.findLoanAccountDetails(account); //loan Enq 10400
                    	if(accountDetails!=null && "A6".equals(account.getProductType()))  {
                        	LoanAccountDetails loanDetails = (LoanAccountDetails)accountDetails;
                        	if(loanDetails.getAccountStatus()!=null && "DISC".equalsIgnoreCase(loanDetails.getAccountStatus()))
                        		account.setAccountStatus(loanDetails.getAccountStatus());                    		
                    	} 
                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    logger.info("Product Type: "+account.getProductType());
                    if("A1".equals(account.getProductType()) || "B1".equals(account.getProductType()))
                    {
                    	TransactionAccountDetails transactionAccountDetails = (TransactionAccountDetails)accountDetails;
                    	account.setBalance(transactionAccountDetails.getAvailableBalance());
                    	 }

                    if (accountDetails != null) {
                        accountDetails.setAccount(account);
                        logger.info("account from account details:  --> getBalance(): "+account.getBalance());
                        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");
                    }
                    // return accountDetails;
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
        }
        logger.debug("Account Details: " + accountDetails);
        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");

        return accountDetails;
    }

    /**
     * TODO Get user account [AccountDAO.findAccount(username, accountno,
     * branchcode)] AccountMasterDAOFactory.getAccoutType(account.productType)
     * return AccountMasterDAO AccountMasterDAO.findAccountDetails(accountno,
     * branchcode) return AccountDetails return AccountDetails *
     * 
     * @param accountNo
     * @param branchCode
     * @param userName
     * @return AccountDetails
     */

    public AccountDetails getUserAccountDetails(String accountNo, String branchCode, String userName) {
       
        AccountDetails accountDetails = null;        
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if(account == null){
                	account = accountDAOImpl.findBMAccount(accountNo, branchCode, userName);
                }
              //Added for CR 5039
                if(account == null){
                    account = accountDAOImpl.findClosedAccountsDetails(accountNo, branchCode, userName);
                }
                //End of CR 5039
                // added for NRI PIS accounts -start
                if(account == null){
                	account = accountDAOImpl.findNRIPISAccount(accountNo, branchCode, userName);
                }
                // added for NRI PIS accounts -end
                if (account != null) {
                	if(logger.isDebugEnabled())
                    logger.debug("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                	if(logger.isDebugEnabled())
                    logger.debug("AccountMasterDAO type: " + accountMasterDAO);

                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    if (accountDetails != null) {
                        accountDetails.setAccount(account);
                    	if(logger.isDebugEnabled()){
                        logger.debug("AccountDetails  return by" + accountMasterDAO + " is+" + accountDetails);
                        logger.debug("AccountDetails.AccountDescription " + accountDetails.getAccountDescription());
                        logger.debug("AccountDetails.productType " + accountDetails.getAccount().getProductType());
                    	}
                    }                  
                }
            }
            catch (DAOException daoException) {                
            	//logger.error("Exception Occured: "+daoException);
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
			if(logger.isDebugEnabled()){
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
			}
        }
    	if(logger.isDebugEnabled())
        logger.debug("Account Details: " + accountDetails);
      return accountDetails;
    }

    /**
     * TODO Get the Account [AccountDAOImpl.findAccount(String accountNo, String
     * branchCode, String userName)] and get the List TransactionHistory from
     * [TransactionHistoryDAOImpl.findTransactionHistory(Account account, int
     * limit)] return List of TransactionHistory
     * 
     * @param userName
     * @param accountNo
     * @param branchCode
     * @param limit
     * @return List
     */

    public List getAccountStatement(String userName, String accountNo, String branchCode, int limit) {
        List transactionHistorylist = null;
        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if(account==null)// added to get NRI PIS account
                account=accountDAOImpl.findNRIPISAccount(accountNo, branchCode, userName);//added to get NRI PIS account
                //Added for CR 5039
                if(account == null){
                    account = accountDAOImpl.findClosedAccountsDetails(accountNo, branchCode, userName); 
                }
                
                logger.info("Account return by AccountDAOImpl is" + account);
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, limit);

            }
            catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
            return transactionHistorylist;

        }
        else {
            logger.debug("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        logger.debug("TransactionHistorylist" + transactionHistorylist);
        return transactionHistorylist;

    }

    /**
     * TODO Get Accounts By Nature
     * [accountDAOImpl.findAccountsByNature(userName, accountNature)] return
     * List of Accounts
     * 
     * @param userName
     * @param accountNature
     * @return List of Accounts
     */
    public List getAccountsByNature(String userName, Integer accountNature) {
        
        List accountList = new ArrayList();
        if (userName != null && accountNature != null) {
            if ((accountNature.equals(new Integer("0"))) || (accountNature.equals(new Integer("1")))
                    || (accountNature.equals(new Integer("2")))) {
                logger.debug("inside if condition getAccountsByNature : accountNature " + accountNature + "UserName : "
                        + userName);
                try {
                    accountList = accountDAOImpl.findAccountsByNature(userName, accountNature);
                    if (accountList != null) {
                        return accountList;
                    }
                }
                catch (DAOException daoException) {
                    SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                }
            }
        }
        else {
            logger.debug("User Name is " + userName);
            logger.debug("Account Nature is " + userName);
        }
        return null;
    }

    /**
     * TODO Get the Account [AccountDAOImpl.findAccount(String accountNo, String
     * branchCode, String userName)] and get the List of TransactionHistory from
     * [TransactionHistoryDAOImpl.findTransactionHistory(Account
     * account,Timestamp fromDate, Timestamp toDate, int order) using Account
     * 
     * @param userName
     * @param accountNo
     * @param branchCode
     * @param fromDate
     * @param toDate
     * @param order
     * @return List
     */

    public List getAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate,
            Timestamp toDate, int order) {
        
        List transactionHistorylist = null;

        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if(account == null){
                	account = accountDAOImpl.findBMAccount(accountNo, branchCode, userName);
                }
                if(account == null){// added to get NRI PIS account
                	account = accountDAOImpl.findNRIPISAccount(accountNo, branchCode, userName);
                }
                //Added for CR 5039
                if(account == null){
                    account = accountDAOImpl.findClosedAccountsDetails(accountNo, branchCode, userName);
                }
                //End of CR 5039
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, fromDate, toDate,
                        order);
                logger.debug("TransactionList is " + transactionHistorylist);
                }
            catch (DAOException daoException) {
            	SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.info("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        return transactionHistorylist;
    }

    /**
     * TODO Get the Transaction Accounts [accountDAOImpl.findAccounts(userName)]
     * return list of Accounts
     * 
     * @param userName
     * @return List
     */

    public List getTransactionAccounts(String userName) {
        
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {
            try {
                accountList = accountDAOImpl.findAccounts(userName);                
                if (accountList != null) {
                	return accountList;
                }
                else {
                    logger.info("List of Account is" + accountList);
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.debug("input parameter userName " + userName);
        }

        return null;

    }

    /**
     * TODO Get the Accounts with Balance
     * [AccountDAOImpl.findAccountsWithBalance(userName,productType)] retunrn
     * List of Accounts
     * 
     * @param userName
     * @param productType
     * @return List
     */
    public List getUserAccountsWithBalance(String userName, String productType[]) {
        
        logger.debug("User name: " + userName + "Account Type: " + productType);
        List accountList = null;
        try {
            if (userName != null && userName.trim() != "" && productType != null) {
                accountList = accountDAOImpl.findAccountsWithBalance(userName, productType);

            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List With Balace " + accountList);
        
        return accountList;
    } 
    //Added for CR 295 - Start
    public Map getBMAccountDetails(String accountNo, String branchCode, Timestamp fromDate, String userName)
    {
    	Map accountDetails = new HashMap();
    	Account accountObj = (Account) accountDAOImpl.findAccount(accountNo,branchCode,userName);
    	if(accountObj != null){
    		if(logger.isDebugEnabled())
    			logger.debug("bank system is " + accountObj.getBankSystem());       
	    	if (accountObj.getBankSystem().equalsIgnoreCase(DAOConstants.CORE))
	    	{
	    		List bmacclist = accountDAOImpl.getBMAccounts(accountNo,branchCode,fromDate,userName);
	    		accountDetails.put("getBMaccList",bmacclist);
	    		
	    		
	    	}
        }
    	return accountDetails;
    	
    }
//  Added for CR 295 - End

    /**
     * TODO Enter the description of the method here
     * @param userName
     * @return boolean
     */
    public boolean upateCoreMessageStatus(String userName, String [] branchCodes)
    { 
        boolean status = false;
        try{
        status =  accountDAOImpl.upateCoreMessageStatus(userName,branchCodes);  
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        return status;
     }
    
    
    // NRI - Survey Start
    /**
     * TODO Enter the description of the method here
     * @param userName
     * @return boolean
     */
    public boolean checkUserNRIAccounts(List accountList){
    	
    	boolean nriStatus = false ;
    	//List accountList = accountDAOImpl.findAccounts(userName);
    	for(int counter=0;counter<accountList.size();counter++)
        {
		   Account curraccount = (Account)accountList.get(counter);
           if(curraccount.getBankSystem().equalsIgnoreCase("Core")){
        		   int indexNRE = curraccount.getProductDescription().indexOf("NRE");
        		   int indexNRNR = curraccount.getProductDescription().indexOf("NRNR");
        		   int indexNRO = curraccount.getProductDescription().indexOf("NRO");
        		   int indexFCNB= curraccount.getProductDescription().indexOf("FCNB");        		   
        		   
        		   if(indexNRE >= 0 || indexNRNR >= 0 || indexNRO >= 0 || indexFCNB >= 0){
        			   logger.info("User has NRI CORE Account");
        			   nriStatus = true;
        			   break;
        		   }
           }else{
        	   if(curraccount.getBankSystem().equalsIgnoreCase("NonCore")){
        		   String type =validator.getAccountSubType(curraccount.getAccountNo());        		   
	        	   if(type.equalsIgnoreCase("NRE") || type.equalsIgnoreCase("NRNR") || type.equalsIgnoreCase("NRO") || type.equalsIgnoreCase("FCNB")  ){
	        		   logger.info("User Has Non Core NRE Accounts");
	        		   nriStatus = true;
	        		   break;
	        	   }
	           }
           }
            
         }
    	
    	return nriStatus;
    }
    
    // NRI - Survey End
    
    //Added for Make Donation Link    
   
    public List getDonationAccounts(String bankCode) {
        List donationAccountsList = null;       
        try {
            donationAccountsList = accountDAOImpl.getDonationAccounts(bankCode);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
       
        return donationAccountsList;
    }
    
    //Make Donation Link - end
    public List getEZTradeAccounts(String userName,String prodDesType){
    	List eZAccountList=null;
    	 try {
    		 eZAccountList = accountDAOImpl.getEZTradeAccounts(userName,prodDesType);
    		 if(eZAccountList!=null && eZAccountList.size()>0){
    		 for (int i = 0; i < eZAccountList.size(); i++) {
                 Account acc = (Account) eZAccountList.get(i);
                 if (acc.getAccountNo().equalsIgnoreCase(acc.getParentAccountNo())) {
                	 int childAccountCount=0;
                	 childAccountCount=findChildAccount(eZAccountList,acc.getAccountNo());
                	 if(childAccountCount==0){
                		 eZAccountList.remove(acc);
                	 }
                 }
                
             }
    	 }

         }
         catch (DAOException daoException) {
             SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
         }
    	return eZAccountList;
    }
    private int findChildAccount(List eZAccountList,String accountNo){
    	logger.info("eZAccountList size inside method :"+eZAccountList.size());
    	int childAccountCount=0;
    	 for (int i = 0; i < eZAccountList.size(); i++) {
             Account acc = (Account) eZAccountList.get(i);
             if (accountNo.equalsIgnoreCase(acc.getParentAccountNo())&& acc.getAccountNature().equals("3")) {
            	 childAccountCount+=1;
             }
         }
    	 logger.info("childAccountCount :"+childAccountCount);
    	return childAccountCount;
    }
    
    //Added by Devipriya - CR 5039
    public List getUserClosedAccountsDetails(String userName) {
        logger.debug("getUserAccountsWithoutBalance(String username) method begin");
        List closedAccountList = new ArrayList();
        if (userName != null) {
            try {  
                closedAccountList = accountDAOImpl.getClosedAccountsDetails(userName);
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        if(closedAccountList != null && closedAccountList.size()>0){
        logger.info("Size of closedAccountList: " + closedAccountList.size());
        }
        logger.debug("getUserAccountsWithoutBalance(String username) method end");
        return closedAccountList;
    }
    
   //End of CR 5039 
    
    //Added for CR 5195
    public List getUserAccountsWithBalance(String userName){
    	logger.debug("getUserAccountsWithBalance(String username) method begin");
        List consolidatedAccountList = new ArrayList();
        try {
	        if (userName != null && userName.trim() != "") {    	
	            consolidatedAccountList = accountDAOImpl.findAccountsWithBalance(userName);	            
	        }
        }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }            
        if(consolidatedAccountList != null && consolidatedAccountList.size()>0){
        logger.info("Size of consolidatedAccountList: " + consolidatedAccountList.size());
        }
        logger.debug("getUserAccountsWithoutBalance(String username) method end");
        return consolidatedAccountList;
    }
    
    public List getUserDepositAccountDetails(String userName, String productType[]) {
        
        logger.debug("User name: " + userName + "Account Type: " + productType);
        List accountList = null;
        try {
            if (userName != null && userName.trim() != "" && productType != null) {
                accountList = accountDAOImpl.findDepositAccountsWithBalance(userName, productType);
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List With Balace " + accountList);
        
        return accountList;
    } 
 
    //End of CR 5195

    /*Added for Core SMS Alert Module*/
    
    public List getCoreSMSAccounts(String userName, String productType) {
        List accountList = null;
        try {
            accountList = accountDAOImpl.getAccountsForCoreSMSAlerts(userName, productType);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.info("acccount list for Core SMS Alert Mdoule: " + accountList);
        return accountList;
    }
    /*Added for Core SMS Alert Module*/

    
public List findTPAccountsBYLimitStatus(String userName, Integer accountNature) {
        List accountList ;            
        accountList = accountDAOImpl.findTPAccountsWithStatus(userName, accountNature);
        return accountList;
    }
    

public List getPendingTpLimitApprovals(String userName) {
    List accountList ; 
    logger.info("getPendingTpLimitApprovals(String userName) -begin");
    accountList = accountDAOImpl.pendingTpLimitApprovals(userName);
    logger.info("getPendingTpLimitApprovals(String userName) -end");
    return accountList;
}
    /**
     * TODO AccountDAO object injection done here
     * 
     * @param accountDAOImpl
     *            void
     */
/**
 * Added for 24-48 hrs 3p ben verification   for SR 62013
 */
    public List getAccountsByNature(String userName, Integer accountNature ,String view) {
    	logger.info("List getAccountsByNature(String userName, Integer accountNature ,String view) method begins ");
    	logger.info("view"+view);        
        List accountList = new ArrayList();
            if (userName != null && accountNature != null &&(accountNature.equals(new Integer("0"))) || (accountNature.equals(new Integer("1")))
                    || (accountNature.equals(new Integer("2")))) {
                    accountList = accountDAOImpl.findAccountsByNature(userName, accountNature ,view);
                    logger.info("List getAccountsByNature(String userName, Integer accountNature ,String view) method ends ");            }
        return accountList;
    }
    
    // To get the third party account details for PostItPad CR-5735
    public List getRecentTPAccounts(String userName,String timePeriod,String historyType){
    	List tpList = new ArrayList();
        if(userName!=null){
        	tpList=accountDAOImpl.findRecentTPAccounts(userName,timePeriod,historyType);
        }
        	
        return tpList;
    }
    //CR-5735 end
    
 // CR 147 start

	public AccountDetails getLoanCurrAndPrevYearInterest(
			AccountDetails accountDetails)

	{

		String accountNo = accountDetails.getAccount().getAccountNo();
		String branchCode = accountDetails.getAccount().getBranchCode();

		String userName = accountDetails.getAccount().getUserName();

		logger.debug("getLoanCurrAndPrevInterest(AccountDetails accountDetails) method begin");
		if (accountNo != null && branchCode != null && userName != null) {
			try {
				Account account = accountDAOImpl.findAccount(accountNo,
						branchCode, userName);

				if (account != null) {
					logger.debug("Account from AccountDAOImp is" + account);

					AccountDetails loanaccountDetail = loanaccountDetails
							.findLoanAccountDetails(account);
					logger.info("Product Type: " + account.getProductType());

					if (loanaccountDetail != null) {
						LoanAccountDetails intRateLoanAccDetailNew = (LoanAccountDetails) loanaccountDetail;
						LoanAccountDetails intRateLoanAccDetail = (LoanAccountDetails) accountDetails;
						intRateLoanAccDetail
								.setCurrentYearInterest(intRateLoanAccDetailNew
										.getCurrentYearInterest());
						intRateLoanAccDetail
								.setPreviousYearInterest(intRateLoanAccDetailNew
										.getPreviousYearInterest());
						logger.debug("getLoanCurrAndPrevInterest(AccountDetails accountDetails) method end");
						return intRateLoanAccDetail;
					}

				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(
						daoException.getErrorCode(), daoException);
			}
		}
		logger.debug("Account Details: " + accountDetails);
		logger.debug("getLoanCurrAndPrevInterest(String accountNo, String branchCode,String userName) method end");

		return accountDetails;
	}
	
	public List getUserAccountsWithOutBalance(String userName, String productType[]) {
        
        logger.debug("User name: " + userName + "Account Type: " + productType);
        List accountList = null;
        try {
            if (userName != null && userName.trim() != "" && productType != null) {
                accountList = accountDAOImpl.findAccountsWithOutBalance(userName, productType);

            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List With Balace " + accountList);
        
        return accountList;
    }
	
	//MIT Inward Outward
		public List getUserAccountsNreSB(String username, String productType,
				String productDescription) {
			List accountList = null;
			try {
				if (username != null) {
					accountList = accountDAOImpl.findAccountsNreSB(username,
							productType, productDescription);
				} else {
					logger.debug("User name and Account Type are NULL");
				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}
			logger.debug("Account List " + accountList);
			return accountList;

		}

		public List getUserBenAccounts(String username) {
			List accountList = null;
			try {
				if (username != null) {
					accountList = accountDAOImpl.fetchNreBEN(username);
				} else {
					logger.debug("User name NULL");
				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}
			logger.debug("Account List " + accountList);
			return accountList;
		}

		public List getUserAccountsNreNroSB(String username, String productType,
				String productDescription1, String productDescription2) {
			List accountList = null;
			try {
				if (username != null) {
					accountList = accountDAOImpl.findAccountsNreNroSB(username,
							productType, productDescription1, productDescription2);
				} else {
					logger.debug("User name and Account Type are NULL");
				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}
			logger.debug("Account List " + accountList);
			return accountList;

		}

		public String getBranchMailid(String branchCode) {
			String branchMailid = null;
			try {
				if (branchCode != null) {
					branchMailid = accountDAOImpl.getBranchMailid(branchCode);
				} else {
					logger.debug("branch code is NULL");
				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}

			return branchMailid;

		}

		public String getCifNo(String UserName) {
			String cifNo = null;
			try {
				if (UserName != null) {
					cifNo = accountDAOImpl.getCifNo(UserName);
				} else {
					logger.debug("CIF No is NULL");
				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}

			return cifNo;

		}

		public String getRefNo() {
			String cifNo = null;
			try {
				cifNo = accountDAOImpl.getRefNo();
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException.getErrorCode(),
						daoException);
			}

			return cifNo;

		}

		public boolean insertOutwardDetails(String Ref_No, String cifNo,
				String userName, String address, String debitAccount,
				String amount, String currency, String purpose, String charges,
				String benAccount, String mailId, String branchMailid,
				String status, String branchCode, String homeBranchCode) throws DAOException {
			logger.info("insertOutwardDetails() " + LoggingConstants.METHODBEGIN);
			boolean result = false;
			
			
			validator.validateAccount(debitAccount, branchCode, userName);
			validator.validateNreAccounts(userName,debitAccount);
			validator.validateBenAccounts(userName, benAccount);
			validator.validateBeniAmount(amount,benAccount,userName);
			

			
			result = accountDAOImpl.insertOutwardDetails(Ref_No, cifNo, userName,
					address, debitAccount, amount, currency, purpose, charges,
					benAccount, mailId, branchMailid, status, homeBranchCode);

			return result;
		}

		public boolean insertInwardDetails(String userName, String rrno1,
				String ramount1, String rcurrency1, String rbankname1,
				String mailId, String branchMailid, String status,
				String deposite1, String tdeposite1, String damount1,
				String dcurrency1, String paymenttype, String accNo,
				String icheque, String day, String month, String year,
				String cifNo, String Ref_No, String address,
				String debitAccountNo1, String renewalType, String userComment,
				String branchCode, String homeBranchCode) throws DAOException {
			logger.info("insertInwardDetails() " + LoggingConstants.METHODBEGIN);
			boolean result = false;

			validator.validateAccount(debitAccountNo1, branchCode, userName);
			validator.validateNreNroAccounts(userName,debitAccountNo1);
			
			result = accountDAOImpl.insertInwardDetails(userName, rrno1, ramount1,
					rcurrency1, rbankname1, mailId, branchMailid, status,
					deposite1, tdeposite1, damount1, dcurrency1, paymenttype,
					accNo, icheque, day, month, year, cifNo, Ref_No, address,
					debitAccountNo1, renewalType, userComment, homeBranchCode);

			return result;
		}
	//MIT Inward Outward
	public List getAccountsForProductTypeA1A2(String userName, String accountListType) {
	        
			logger.info("getAccountsForProductTypeA1A2() - Method Begin");
	        List accountList = null;
	        try {
	            if (userName != null && userName.trim() != "") {
	                accountList = accountDAOImpl.findAccountsByNatureAndProductType(userName, accountListType);
	            }
	        }
	        catch (DAOException daoException) {
	            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
	        }
			logger.info("getAccountsForProductTypeA1A2() - Method Begin");
	        return accountList;
	    }
	
	public String getTdsReferenceNo(){
		logger.info("getTdsReferenceNo() - Method Begin");
        String referenceNo = null;
        try {
            	referenceNo = accountDAOImpl.getTdsSeqNo();
            	logger.info("Tds Sequence No:"+referenceNo);
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
		logger.info("getAccountsForProductTypeA1A2() - Method Begin");
        return referenceNo;
	}
	
	public void setLoanaccountDetails(LoanAccountMasterDAO loanaccountDetails) {
		this.loanaccountDetails = loanaccountDetails;
	}
	// CR -147 END
    
    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

    /**
     * TODO AccountMasterFactory object injection done here
     * 
     * @param accountMasterDAOFactory
     *            void
     */

    public void setAccountMasterDAOFactory(AccountMasterDAOFactory accountMasterDAOFactory) {
        this.accountMasterDAOFactory = accountMasterDAOFactory;
    }

   
    
    /**
     * TODO TransactionHistoryDAOImpl object injection done here
     * 
     * @param transactionHistoryDAOImpl
     *            void
     */
     

    public void setTransactionHistoryDAOImpl(TransactionHistoryDAO transactionHistoryDAOImpl) {
        this.transactionHistoryDAOImpl = transactionHistoryDAOImpl;

    } 

	/**
	 * @param validator The validator to set.
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	} 
	//Account statement address change ---start

	public void setCoreDAOImpl(CoreDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	//Account statement address change ---end

	
}
