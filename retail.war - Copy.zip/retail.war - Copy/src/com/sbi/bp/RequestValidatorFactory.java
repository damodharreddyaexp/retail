/*
 * RequestValidatorFactory.java
 * Created on Nov 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 28, 2005 Sairam.T - Initial Creation
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;

public class RequestValidatorFactory {
	 protected final Logger logger = Logger.getLogger(getClass());

	private RequestValidatorBP chequeBookValidatorBP;

	private RequestValidatorBP newAccountValidatorBP;

	private RequestValidatorBP standingIncValidatorBP;

	private RequestValidatorBP depositRenewalValidatorBP;

	/**
	 * Accept the requestType as input and according to that it will return
	 * corresponding ValidatorBP instance
	 * 
	 * @param requestType
	 * @return RequestValidatorBP
	 */

	public RequestValidatorBP getValidator(String requestType) {

		logger.info("getValidator(String requestType) ");
		if (logger.isDebugEnabled()) {

			logger.debug("requestType :" + requestType);
		}

		if (requestType != null	&& !requestType.trim().equalsIgnoreCase(BPConstants.EMPTY)) {
			
			if (requestType.equalsIgnoreCase(BPConstants.CHEQUE_REQUEST)) {
				logger.info("getValidator return chequeBookValidatorBP :"+ chequeBookValidatorBP);
				return chequeBookValidatorBP;
			} else if (requestType.equalsIgnoreCase(BPConstants.DEPOSIT_RENEW_DETAILS)) {
				logger.info("getValidator return depositRenewalValidatorBP :"+ depositRenewalValidatorBP);
				return depositRenewalValidatorBP;
			} else if (requestType.equalsIgnoreCase(BPConstants.STANDING_INSTRUCTIONS)) {
				logger.info("getValidator return standingIncValidatorBP :"+ standingIncValidatorBP);
				return standingIncValidatorBP;
			} else if (requestType.equalsIgnoreCase(BPConstants.APPLY_NEW_ACCOUNT)) {
				logger.info("getValidator return newAppalyAccountValidatorBP :"+ newAccountValidatorBP);
				
			} else {
				 SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		} else {
			 SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			 }
		return newAccountValidatorBP;
	}

	/**
	 * ChequeBookValidatorBP injection
	 * 
	 * @param ChequeBookValidatorBP
	 */

	public void setChequeBookValidatorBP(RequestValidatorBP chequeBookValidatorBP) {

		this.chequeBookValidatorBP = chequeBookValidatorBP;
	}

	/**
	 * DepositRenewalValidatorBP injection
	 * 
	 * @param depositRenewalValidatorBP
	 */
	public void setDepositRenewalValidatorBP(RequestValidatorBP depositRenewalValidatorBP) {

		this.depositRenewalValidatorBP = depositRenewalValidatorBP;
	}

	/**
	 * NewAccountValidatorBP injection
	 * 
	 * @param newAccountValidatorBP
	 */
	public void setNewAccountValidatorBP(RequestValidatorBP newAccountValidatorBP) {

		this.newAccountValidatorBP = newAccountValidatorBP;
	}

	/**
	 * StandingIncValidatorBP injection
	 * 
	 * @param standingIncValidatorBP
	 */
	public void setStandingIncValidatorBP(RequestValidatorBP standingIncValidatorBP) {

		this.standingIncValidatorBP = standingIncValidatorBP;
	}
	
	

}
