package com.sbi.bp;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

/**
 * This class is for validating the Debit Account Mapped to a User. It can be used to perform basic  
 * validation on user's debit account for intra bank fund transfers. 
 * This class was created for NPS module.
 * 
 * @author Manoj Kumar Mariappan
 */
public class DebitUserAccountValidatorBP extends TransactionValidatorBP
{
    protected final Logger logger = Logger.getLogger(getClass());
    private Validator validator;
    
    /**
     * @param transaction
     * @return boolean
     */
    public boolean validate(Transaction transaction) throws SBIApplicationException{

    	this.transaction = transaction;
    	if(transaction != null){
            if(logger.isDebugEnabled()){
                logger.debug("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);
                logger.debug("transaction :" + transaction.toString());
            }
            
            validator.validateInterBank(transaction.getDebit().getBranchCode(),
                    transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
            if (logger.isDebugEnabled()){
                logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
            }
            
            validator.validateAmount(transaction.getDebit().getAmount());
            if(logger.isDebugEnabled()){
            	logger.debug("validateAmount() return true");
            }
            
            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(), 8, 9);
            if (logger.isDebugEnabled()){
                logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
            }
            
            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
            if (logger.isDebugEnabled()){
                logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
            }
            //limit change uday
            Date scheduledDate = new Date(transaction.getScheduledDate().getTime());
             
         	if(StringUtils.isNotBlank(transaction.getName()) && "NPS".equalsIgnoreCase(transaction.getName())) {
         		String bankCode=transaction.getDebit().getBranchCode().substring(0,1);
        		 if(bankCode!=null && "0|3|A|6".contains(bankCode)){
                	bankCode="0";
                }
    			validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "NPS");
    		       logger.info("validateSubCategoryGroupBLimit method - true");
                
            }else if(StringUtils.isNotBlank(transaction.getName()) && "SBILIFE_INB".equalsIgnoreCase(transaction.getName())){
            	String bankCode =transaction.getBankCode();
            	if(bankCode==null ||bankCode.trim().length()==0){
            		bankCode=transaction.getDebit().getBranchCode().substring(0,1);
           		 	if(bankCode!=null && "0|3|A|6".contains(bankCode)){
           		 		bankCode="0";
           		 	}
            	}	
    			validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "Sbilife");
    		       logger.info("validateSubCategoryGroupBLimit method - true");
                
            }
           
                validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
                transaction.getName(),transaction.getDebit().getBranchCode().substring(0,1),scheduledDate);
               
                    logger.info("validateCategoryBLimits(String username,Double amount, String type,String bankCode) method - true");
            //limit change uday
            
    				logger.info("Mobile category flag for NPS validation----"+transaction.getMobileFlag());
                    if(transaction.getMobileFlag()!=null && "yes".equalsIgnoreCase(transaction.getMobileFlag())){
    				logger.info("Mobile category NPS validation");
    				validator.validateMobileCategoryBLimitForNPS(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode());
    	}	
        }
        else{ 
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return true;
    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator){
        this.validator = validator;
    }
    
}
