/* 
 * TransactionValidatorFactory.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;

public class ValidatorFactory
{

    protected final Logger logger = Logger.getLogger(getClass());

    ValidatorBP fundsTransferValidatorBP;

    ValidatorBP creditToPPFValidatorBP;

    ValidatorBP demandDraftValidatorBP;

    ValidatorBP thirdPartyValidatorBP;

    ValidatorBP loanPartPaymentValidatorBP;

    /**
     * Accept the txnName as input and according to that it will return
     * corresponding ValidatorBP instance
     * 
     * @param txnName
     * @return ValidatorBP
     */
    public ValidatorBP getValidator(String txnName)
    {
        logger.info("getValidator(String txnName) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("txnName :" + txnName);
        }
        if (txnName != null && !txnName.trim().equalsIgnoreCase(BPConstants.EMPTY))
        {

            if (txnName.equalsIgnoreCase(BPConstants.FUND_TRANSFER))
                return fundsTransferValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.PPF))
                return creditToPPFValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.DEMAND_DRAFT))
                return demandDraftValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.THIRD_PARTY))
                return thirdPartyValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.LOAN_PART_PAYMENT)
                    || txnName.equalsIgnoreCase(BPConstants.LOAN_CLOSURE))
                return loanPartPaymentValidatorBP;
            else
            {
            	SBIApplicationException.throwException(ErrorConstants.TRANSACTION_NAME_NOT_VALID_ERROR_CODE);
             }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
         }
        return null;
    }

    /**
     * FundsTransferValidatorBP injection
     * 
     * @param fundsTransferValidatorBP
     */
    public void setFundsTransferValidatorBP(ValidatorBP fundsTransferValidatorBP)
    {
        this.fundsTransferValidatorBP = fundsTransferValidatorBP;
    }

    /**
     * CreditToPPFValidatorBP injection
     * 
     * @param creditToPPFValidatorBP
     */
    public void setCreditToPPFValidatorBP(ValidatorBP creditToPPFValidatorBP)
    {
        this.creditToPPFValidatorBP = creditToPPFValidatorBP;
    }

    /**
     * DemandDraftValidatorBP injection
     * 
     * @param demandDraftValidatorBP
     */
    public void setDemandDraftValidatorBP(ValidatorBP demandDraftValidatorBP)
    {
        this.demandDraftValidatorBP = demandDraftValidatorBP;
    }

    /**
     * ThirdPartyValidatorBP
     * 
     * @param thirdPartyValidatorBP
     */
    public void setThirdPartyValidatorBP(ValidatorBP thirdPartyValidatorBP)
    {
        this.thirdPartyValidatorBP = thirdPartyValidatorBP;
    }

    /**
     * LoanPartPaymentValidatorBP injection
     * 
     * @param thirdPartyValidatorBP
     */
    public void setLoanPartPaymentValidatorBP(ValidatorBP loanPartPaymentValidatorBP)
    {
        this.loanPartPaymentValidatorBP = loanPartPaymentValidatorBP;
    }
    
    

}
