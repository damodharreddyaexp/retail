/*
 * ProfileValidtorFactory.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 MURUGAN K - Initial Creation
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;

public class ProfileValidatorFactory {

    private Logger logger = Logger.getLogger(getClass());

    private ProfileValidatorBP thirdPartyValidator;

    private ProfileValidatorBP ppFValidator;

    /**
     * Accepts type as input. Values for type and appropriate return objects for the same are
     * 1. TP - TPValidator
     * 2. PPF - PPFValidator
     */

    public ProfileValidatorBP getvalidator(String type) {
        logger.info("getvalidator : " + LoggingConstants.METHODBEGIN);
        if (type != null) {
            logger.info("getvalidator : type" + type);
            if (type.equalsIgnoreCase(BPConstants.PPF)) {
                logger.info("getvalidator : Creating a PPFvalidator instance");
                return ppFValidator;
            }
            else if (type.equalsIgnoreCase(BPConstants.THIRD_PARTY)) {
                logger.info("getvalidator : Creating a THIRD_PARTY  instance");
                return thirdPartyValidator;
            }
        }
        else {
            logger.error("getvalidator : invalid type passed");
            SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
        }
        return null;
    }

   

    public void setThirdPartyValidator(ProfileValidatorBP thirdPartyValidator) {
        this.thirdPartyValidator = thirdPartyValidator;
    }



    public void setPpFValidator(ProfileValidatorBP ppFValidator) {
        this.ppFValidator = ppFValidator;
    }




   
}
