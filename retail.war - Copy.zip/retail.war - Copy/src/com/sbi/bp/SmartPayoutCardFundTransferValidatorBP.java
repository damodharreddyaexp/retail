/*
 * SmartPayoutCardFundTransferValidatorBP.java
 * Created on June 24, 2010
 *
 * Copyright (c) 2007 by SBI All Rights Reserved.
 * $Header: $
 */
//History


package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class SmartPayoutCardFundTransferValidatorBP extends TransactionValidatorBP {
   protected final Logger logger = Logger.getLogger(getClass());
   private Validator validator;  
  
   public boolean validate(Transaction transaction) throws SBIApplicationException {
       this.transaction = transaction;
       if (transaction != null) {
           logger.info("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);           
           if (logger.isDebugEnabled()){
               logger.debug("transaction array:" + transaction.getCredit()[0]);
           }           
           logger.info("transaction :"+transaction.toString());         
           TransactionLeg credit = (TransactionLeg)transaction.getCredit()[0];
           TransactionLeg debit = (TransactionLeg)transaction.getDebit();           
           debit.setDebitProductCode("");
           validator.validateAmount(transaction.getDebit().getAmount());          
           validator.validateMinMaxSmartCardLimit(transaction.getDebit().getAmount());
           validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
           validator.isSmartCardExist(transaction.getDebit().getUserName(), transaction.getDebit().getThirdPartyRef());
           validator.validateCreAccSmartCard(transaction.getCredit()[0].getAccountNo(),transaction.getCredit()[0].getBranchCode());
           Date scheduledDate = null; 
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				scheduledDate = new Date();     
			 String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }	
			validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode, "SmartPayoutCard");
			logger.info("validateSubCategoryGroupBLimit method - true");
			validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
            transaction.getName(),transaction.getBankCode(),new Date());
			logger.info("validateCategoryBLimit method returns true");
			logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
       	}else{ 
    	   SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
       }
       return true;
   }
   public void setValidator(Validator validator)
   {
       this.validator = validator;
   }
}