/*
 * ProfileBP.java
 * Created on Dec 16, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History
//Dec 16, 2005 MURUGAN K - Initial Creation
//Dec 18,2005 NAVEEN KUMAR - Methods implementation.
package com.sbi.bp;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.authentication.user.RequestResponseService;
import com.sbi.common.model.ProfileEncPsdModel;
import com.sbi.dao.AccountDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.Field;
import com.sbi.model.User;
import com.sbi.model.UserProfile;
import com.sbi.model.UserProfileDetails;
import com.sbi.rtgs.model.RTGSBeneficiaryDetails;
import com.sbi.service.ServiceConstant;
import com.sbi.si.dao.StandingInstructionsDAO;
import com.sbi.utils.CommonUtils;
import com.sbi.utils.Constants;
import com.sbi.utils.EncryptMD5;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.LogonValidator;
import com.sbi.utils.SMSGateWayRequestSender;
import com.sbi.utils.StringUtils;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;

import com.sbi.model.UserProfileDetails;

public class ProfileBP {
    protected final Logger logger = Logger.getLogger(getClass());

    private UserDAO userDAOImpl;

    UserProfile userProfile;

    private CommonUtils commonUtils;

    private AccountDAO accountDAOImpl;

    private Account updatedAccountObj;

    private Validator validator;

    private ProfileValidatorFactory profileValidatorFactory;
    
    private ProfileValidatorBP profileValidatorBP; 
    
    private LogonValidator logonValidator;
    
    private final static String TP_VALIDATION_KEY = "validationType";
    
    private final static String TP_VALIDATION_ADD_TYPE = "Add";
    
    private final static String TP_VALIDATION_EDIT_TYPE = "Edit";
    
    private final static String ACCOUNT_KEY = "account";
    
    //Added for SI Module
    private StandingInstructionsDAO standingInstructionsDAOImpl;
    //End SI Module
    
    //Added by Sivagnanavelu
    private SMSGateWayRequestSender smsGateWayRequestSender; 
    
    private RequestResponseService requestResponseService;
    
    UserProfileDetails userProfileDetails;
       
    public UserProfile changeProfilePassword(String enteredpassword, String oldpassword, User user, ProfileEncPsdModel model,String mvkbLang) {


        logger.debug("changeprofilepwd(String enteredpassword, String oldpassword, String userName) method begin");
        try {
            userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
            String currentPwd = userProfile.getProfilepassword();
            String profileHashing = userProfile.getProfileHashing();
            String loginHashing = userProfile.getLoginHashing();
            String userName = user.getUserAlias();
            logger.info("Username "+userName);
            
            
            if(model == null){
            	if(!logonValidator.profilePassword(enteredpassword))
            		SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
            }
            else {
            	if(!logonValidator.profilePassword(model))
            	SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
            }
             //aruna
            StringBuilder credential = new StringBuilder().append(userName).append("|").append(oldpassword);
            boolean pwdVerify = ("SHA-512".equalsIgnoreCase(profileHashing))?
            		requestResponseService.validateHashSHA2(currentPwd,credential.toString()):
            			commonUtils.verifyEncryption(credential.toString(), currentPwd); 
            
            if (pwdVerify) {
                //if(oldpassword.equalsIgnoreCase(enteredpassword)){
                    if(oldpassword.equals(enteredpassword)){
                    SBIApplicationException.throwException(ErrorConstants.OLDPASSWORD_NEWPASSWORD_MATCH);
                }
                    //CR 1774 Start
                credential = new StringBuilder().append(userName).append("#").append(enteredpassword);
                boolean status = ("SHA-512".equalsIgnoreCase(loginHashing))?
                		requestResponseService.validateHashSHA2( user.getPassword(),credential.toString()):
                			EncryptMD5.verifyHash(credential.toString() , user.getPassword());
            	if(status)
            		SBIApplicationException.throwException("SE148");
            	//CR 1774 End
            	String arrayString[] = { userName + "|" + enteredpassword };
                String returnStringArray[] = null;
                returnStringArray = commonUtils.encryptParam(arrayString);   
                List arrayList = new ArrayList();
                Field field1 = new Field();
                field1.setFieldName(BPConstants.PROFILE_PASSWORD);
                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                //field1.setValue(returnStringArray[0]);
                field1.setValue(requestResponseService.getSHA2Hashing(userName,enteredpassword,"|"));
                arrayList.add(field1);  
                // Added this code to capture profile pwd changed date start
                Timestamp sysdate = null;
                sysdate = StringUtils.currentTimeStamp();
                
                if(!"SHA-512".equalsIgnoreCase(profileHashing)){
                	 Field updateShaFlag = new Field();
                	 updateShaFlag.setFieldName("PROFILE_PASSWORD_HASHING");
                	 updateShaFlag.setType(BPConstants.SQL_VARCHAR_VALUE);
                	 updateShaFlag.setValue("SHA-512");
                	 arrayList.add(updateShaFlag);
                }
                
                Field profilePwdChangedDate = new Field();
                profilePwdChangedDate.setFieldName("PROFILE_PWD_CHANGED_DATE");
                profilePwdChangedDate.setType(BPConstants.SQL_TIMESTAMP_VALUE);
                profilePwdChangedDate.setValue(sysdate);
                arrayList.add(profilePwdChangedDate);
             // Added this code to capture profile pwd changed date end
                
                //Added by Aruna for CR_196
                Field updateMvkbLang = new Field();
                updateMvkbLang.setFieldName("PROFILE_MVKB_LANG");
                updateMvkbLang.setType(BPConstants.SQL_VARCHAR_VALUE);
                updateMvkbLang.setValue(mvkbLang);
           	    arrayList.add(updateMvkbLang);
                //Added by Aruna for CR_196 end
                userProfile = userDAOImpl.updateProfile(arrayList, user);
            }
            else{
                SBIApplicationException.throwException(ErrorConstants.INVALID_PROFILE_PASSWORD_ERROR_CODE);
            }

        }

        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("changeprofilepwd(String enteredpassword, String oldpassword, String userName) method end");
        return userProfile;

    }

    /**
     * TODO Call [Common
     * 
     * @param profilePassword
     * @param enteredPassword
     * @return boolean
     */
    public boolean verifyProfilePassword(String enteredPassword, String profilePassword, String userName) {

        logger.debug("verifyProfilePassword(String enteredPassword,String profilePassword) "
                + LoggingConstants.METHODBEGIN);
        boolean status = commonUtils.verifyEncryption(userName + "|" + enteredPassword, profilePassword);

        if (status) {


            return status;
        }else{
        	SBIApplicationException.throwException(ErrorConstants.INVALID_PROFILE_PASSWORD_ERROR_CODE);
        }

        logger.debug("verifyProfilePassword(String enteredPassword,String profilePassword) "
                + LoggingConstants.METHODEND);
        return false;

    }

    public UserProfile updatePersonalProfile(Map inputParam) {
        logger.debug("updatepersonalprofile(Map inputParam)" + LoggingConstants.METHODBEGIN);

        User user = (User) inputParam.get(Constants.USER);
        UserProfile userProfile = (UserProfile) userDAOImpl.findUserProfile(user.getUserAlias());
       

        try {
            if(logger.isDebugEnabled()){
            logger.debug("Input from  Service : " + inputParam);
            logger.debug("Input from update Personal Profile : " + userProfile);
            }
            if (inputParam != null && user != null) {

                String friendlyName = (String) inputParam.get(BPConstants.DISPLAY_NAME);
                String emailID = (String) inputParam.get(BPConstants.EMAIL);
                String phoneNo = (String) inputParam.get(BPConstants.HOME_PHONE);

                List inparamList = new ArrayList();

                if(!friendlyName.equals(userProfile.getFriendlyName()))
                {
                    Field field1 = new Field();
                    field1.setFieldName(BPConstants.FRIENDLY_NAME);
                    field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field1.setValue(friendlyName);
                	
                    inparamList.add(field1);
                }

             /*   if(!emailID.equals(userProfile.getEmail()))
                {
                    Field field2 = new Field();
                    field2.setFieldName(BPConstants.EMAIL);
                    field2.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field2.setValue(emailID);
                	
                    inparamList.add(field2);
                }*/

                //Commented by Madhan for CR-2187
/*                if(!phoneNo.equals(userProfile.getHomePhone()))
                {
                    Field field3 = new Field();
                    field3.setFieldName(BPConstants.HOME_PHONE);
                    field3.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field3.setValue(phoneNo);
                	
                    inparamList.add(field3);
                }*/
                //End CR
                logger.info("inparamList "+inparamList.size());
                logger.info("Profile "+userProfile);
                
                if(inparamList.size() > 0)
                	userProfile = userDAOImpl.updateProfile(inparamList, user);



            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);       
        }

        logger.info("updatepersonalprofile User Profile " + userProfile);
        logger.debug("updatepersonalprofile(Map inputParam)" + LoggingConstants.METHODEND);
        return userProfile;
    }

    public UserProfile setPassword(Map profileDetails, User user) {
        logger.debug("setpassword(String userName,String hindQuesition,String hindAnswer) method begin");
        String password = (String)profileDetails.get("password");
        String hintQuesition = (String)profileDetails.get("hintQuestion");
        String hintAnswer = (String)profileDetails.get("hintAnswer");
        String dateOfBirth = (String)profileDetails.get("dateOfBirth");
		String placeOfBirth = (String)profileDetails.get("placeOfBirth");
    	String userName = user.getUserAlias();
        //Added by Madhan for Enable High Security CR
		String dbMobileNumberCheck = (String)profileDetails.get("dbMobileNumberCheck");
		String mobile_No = (String)profileDetails.get("mobile_No");
		String mvkbLang = (String)profileDetails.get("mvkbLang"); //Added by Aruna for CR_196
		logger.debug("dbMobileNumberCheck and mobile_No in ProfileBP: "+dbMobileNumberCheck+" - "+mobile_No);
		//End CR
		
		userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
		String loginHashing = userProfile.getLoginHashing();
		String profileHashing = userProfile.getProfileHashing();
		
		ProfileEncPsdModel model = (ProfileEncPsdModel)profileDetails.get("model");
		if(model == null){

			if(!logonValidator.profilePassword(password))
	        	SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
		}else{
			if(!logonValidator.profilePassword(model))
	        	SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
		}
		
		
    	 
    	//aruna
         boolean status = ("SHA-512".equalsIgnoreCase(loginHashing))?
         		requestResponseService.validateHashSHA2(user.getPassword(), userName + "#" + password ):
         			EncryptMD5.verifyHash(userName + "#" + password  , user.getPassword());
		
    	//CR 1774 Start
    	//boolean status = EncryptMD5.verifyHash(userName + "#" + password  , user.getPassword());
    	if(status)
    		SBIApplicationException.throwException("SE148");
    	//CR 1774 End
        String arrayString[] =
        { userName + "|" + password, userName + "|" + hintQuesition, userName + "|" + hintAnswer };
        String returnStringArray[] = commonUtils.encryptParam(arrayString);

        List inparamList = new ArrayList();

        Field field1 = new Field();
        field1.setFieldName(BPConstants.PROFILE_PASSWORD);
        field1.setType(BPConstants.SQL_VARCHAR_VALUE);
        field1.setValue(requestResponseService.getSHA2Hashing(userName,password,"|"));
        inparamList.add(field1);
        
        Field uiPreference = new Field();
        uiPreference.setFieldName("UI_PREFERENCE");
        uiPreference.setType(BPConstants.SQL_VARCHAR_VALUE);
        uiPreference.setValue("");
        inparamList.add(uiPreference);
        
        // Added this code to capture profile pwd changed date start
        Timestamp sysdate = null;
        sysdate = StringUtils.currentTimeStamp();
        
        
        Field profilePwdChangedDate = new Field();
        profilePwdChangedDate.setFieldName("PROFILE_PWD_CHANGED_DATE");
        profilePwdChangedDate.setType(BPConstants.SQL_TIMESTAMP_VALUE);
        profilePwdChangedDate.setValue(sysdate);
        inparamList.add(profilePwdChangedDate);
        
     // Added this code to capture profile pwd changed date start
        
        if(!"SHA-512".equalsIgnoreCase(profileHashing)){
       	 Field shaHashing = new Field();
       	 shaHashing.setFieldName("PROFILE_PASSWORD_HASHING");
       	 shaHashing.setType(BPConstants.SQL_VARCHAR_VALUE);
       	 shaHashing.setValue("SHA-512");
            inparamList.add(shaHashing);
       }
        
        

        if(hintQuesition  != null && hintQuesition.trim().length()>0){ 
            Field field2 = new Field();
            field2.setFieldName(BPConstants.HINT_QUESTION);
            field2.setType(BPConstants.SQL_VARCHAR_VALUE);
            field2.setValue(returnStringArray[1]);
            inparamList.add(field2);
        }
        
        if(hintAnswer != null && hintAnswer.trim().length()>0){
            Field field3 = new Field();
            field3.setFieldName(BPConstants.HINT_ANSWER);
            field3.setType(BPConstants.SQL_VARCHAR_VALUE);
            field3.setValue(returnStringArray[2]);
            inparamList.add(field3);
        }
        
        Timestamp dobObj = null;
		if(dateOfBirth !=null && dateOfBirth.trim().length()>0)
			dobObj = StringUtils.coreDateToTimestamp(dateOfBirth);
		if(dobObj !=null){
			Field dob = new Field();
			dob.setFieldName("DATE_OF_BIRTH");
			dob.setType(BPConstants.SQL_TIMESTAMP_VALUE);
			dob.setValue(dobObj);
			inparamList.add(dob);
		}
		
		if(placeOfBirth != null && placeOfBirth.trim().length()>0){
			if(!StringUtils.isValidPlaceofBirth(placeOfBirth))
				SBIApplicationException.throwException("SE150",new Object[]{placeOfBirth}); 
			Field pob = new Field();
			pob.setFieldName("PLACE_OF_BIRTH");
			pob.setType(BPConstants.SQL_VARCHAR_VALUE);
			pob.setValue(placeOfBirth);
			inparamList.add(pob);
		}
		
		//Added by Aruna for CR_196
		//if(mvkbLang != null && mvkbLang.trim().length()>0){
            Field mvkbLangVal = new Field();
            mvkbLangVal.setFieldName("PROFILE_MVKB_LANG");
            mvkbLangVal.setType(BPConstants.SQL_VARCHAR_VALUE);
            mvkbLangVal.setValue(mvkbLang);
            inparamList.add(mvkbLangVal);
       // }
		//Added by Aruna for CR_196 end
		
        //Added by Madhan for Enable High Security CR
		logger.info("dbMobileNumberCheck.trim().length(): "+dbMobileNumberCheck.trim().length());
        if("".equals(dbMobileNumberCheck)){
        	if(mobile_No != null && mobile_No.trim().length()>0){

        		Field mobile = new Field();
        		mobile.setFieldName("MOBILE_NO");
        		mobile.setType(BPConstants.SQL_VARCHAR_VALUE);
        		mobile.setValue(mobile_No);
        		inparamList.add(mobile);
        	}
        	else
        	{
        		logger.info("user have not entered the mobile number, even though it is not avliable in db");
	        	//Needed only when mobile number insertion becomes mandatory
        		//	SBIApplicationException.throwException("SE141", new Object[]{placeOfBirth});
        	}
        }
		//End CR

		userProfile = userDAOImpl.updateProfile(inparamList, user);

        logger.debug("setpassword(String userName,String hindQuesition,String hindAnswer) method end");
        return userProfile;
    }

/*
 * Method Name : updateUserProfiledetailsLimit
 *  New Special Category Limit Setting
 *  Param :input param with profile details like SBCollect and Merchant Limit
*/   
    public UserProfileDetails updateUserProfiledetailsLimit(Map inputParam){
    	
    	try
    	{
    		
        	User user = (User) inputParam.get(Constants.USER);
        	List <Map>approvalDetailsList = new ArrayList<Map>();
        	Map<Object, Object> approvalDetailsMap = null;
        	List detailInParams = new ArrayList();
        	
        	String userName = user.getUserAlias();
        	String bankCode = user.getBankCode();
            String branchCode=user.getBranchCode();
            
            String userMobileNo = (String) inputParam.get("userMobileNo");
            String sfAuthProvider = (String)inputParam.get("sfAuthProvider");
            String mobileNoAvail=(String)inputParam.get("userHasMobileNo");
            String tokenStatus = (String)inputParam.get("tokenStatus");
            
            
            Double sbcLimit= Double.valueOf((String)inputParam.get("sbcLimit"));
            Double merchantLimit = Double.valueOf((String)inputParam.get("merchantLimit"));
            
            Double currentSBCLimit = Double.valueOf((String)inputParam.get("currentSbcLimit"));
            Double currentMerchantLimit = Double.valueOf((String)inputParam.get("currentMerchantLimit"));

            Double sbcMinLimit = Double.valueOf((String)inputParam.get("sbcMinLimit"));
            Double merchantMinLimit = Double.valueOf((String)inputParam.get("merchantMinLimit"));
            
          if(sbcLimit.compareTo(currentSBCLimit) != 0){
        	  
              //insert into temp table and send sms only if user entered limit exceeds min. approval limit
        	  try{
                   if(sbcLimit.compareTo(sbcMinLimit) > 0)
                   {
                    	String highSecPwd = StringUtils.randomNumber().toString();
                    	approvalDetailsMap = new HashMap<Object, Object>();
                    	
                    	approvalDetailsMap.put("userName",userName);
                    	approvalDetailsMap.put("branchCode",branchCode);
                    	approvalDetailsMap.put("mobileNo",userMobileNo);
                    	approvalDetailsMap.put("type","SBC_LIMIT");
                    	approvalDetailsMap.put("smsPassword",highSecPwd);
                    	approvalDetailsMap.put("messageTypeId","MT000031");
                    	approvalDetailsMap.put("smsParam1","SBC");

                    	approvalDetailsMap.put("oldValue",currentSBCLimit);
                    	approvalDetailsMap.put("newValue",sbcLimit);
                    	approvalDetailsList.add(approvalDetailsMap);
                    }
                    else
                    {
                    	Field field = new Field();
                        field.setFieldName("SB_COLLECT_LIMIT");
                        field.setType(BPConstants.SQL_DOUBLE_VALUE);                    
                        field.setValue(sbcLimit);
                        detailInParams.add(field);
                    }
                	
                }catch (SBIApplicationException exception)
                {
                    SBIApplicationException.throwException(exception.getErrorCode());                        
                }catch (DAOException daoException) {
                    SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                }                   
            }
            
            if(merchantLimit.compareTo(currentMerchantLimit) != 0){
            	
                //insert into temp table and send sms only if user entered limit exceeds min. approval limit
            	try{
                    if(merchantLimit.compareTo(merchantMinLimit) > 0)
                    {
                    	String highSecPwd =  StringUtils.randomNumber().toString();
                    	approvalDetailsMap = new HashMap<Object, Object>();
                    	
                    	approvalDetailsMap.put("userName",userName);
                    	approvalDetailsMap.put("branchCode",branchCode);
                    	approvalDetailsMap.put("mobileNo",userMobileNo);
                    	approvalDetailsMap.put("type","MERCHANT_LIMIT");
                    	approvalDetailsMap.put("smsPassword",highSecPwd);
                    	approvalDetailsMap.put("messageTypeId","MT000031");
                    	approvalDetailsMap.put("smsParam1","MERCHANT");

                    	approvalDetailsMap.put("oldValue",currentMerchantLimit);
                    	approvalDetailsMap.put("newValue",merchantLimit);
                    	approvalDetailsList.add(approvalDetailsMap);
                    }
                    else
                    {
                    	Field field = new Field();
                        field.setFieldName("MERCHANT_LIMIT");
                        field.setType(BPConstants.SQL_DOUBLE_VALUE);                    
                        field.setValue(merchantLimit);
                        detailInParams.add(field);
                    }
                }catch (SBIApplicationException exception)
                {
                    SBIApplicationException.throwException(exception.getErrorCode());                        
                }catch (DAOException daoException) {
                    SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                }catch (Exception e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}                   
            }
            
            if(approvalDetailsList!=null && approvalDetailsList.size()>0){
            	
            	boolean insertStatus = insertDefineLimitDetails(approvalDetailsList,mobileNoAvail);
            	 logger.info("insertStatus value" + insertStatus);
            	if(insertStatus && mobileNoAvail!=null && mobileNoAvail.equalsIgnoreCase("yes")){
            		 if(sfAuthProvider!=null && "SoftwareToken".equalsIgnoreCase(sfAuthProvider)){
            			 logger.info("sfAuthProvider" + sfAuthProvider);
            			 if(tokenStatus!=null && "".equalsIgnoreCase(tokenStatus)){
			 				SBIApplicationException.throwException("ST015");
			 			 }
            		 }else{
            		String mobileNo="";
            		String message="";
            		String messageTypeId="";
            		Map messageDetail=new HashMap();
            		for(int i=0;i<approvalDetailsList.size();i++){
            			messageDetail=(Map)approvalDetailsList.get(i);
            			mobileNo=(String)messageDetail.get("mobileNo");
            			//message=(String)messageDetail.get("userMessage"); // Updated By Sivagnanavelu for SMSgateway 
            			messageTypeId=(String)messageDetail.get("messageTypeId");
            			
            			 if(logger.isDebugEnabled()){       
            				 logger.debug("message :"+message);
            			 }
            			 
            			 String smsParamValues[]={(String)messageDetail.get("smsParam1"), (String)messageDetail.get("smsPassword")};
            			 smsGateWayRequestSender.sendSMSRequest(messageTypeId, smsParamValues,user.getBankCode(),ServiceConstant.SMS_SEND_ORDER_ZERO,userName);                      
            		}
            	
            		}
            	}
            }
            
             if(detailInParams.size() > 0 )
               userProfileDetails = userDAOImpl.updateProfileDetails(detailInParams, user);
             else
               userProfileDetails = userDAOImpl.findUserProfileDetails(user.getUserAlias());
    		
    	}catch(DAOException daoException)
    	{
    		daoException.printStackTrace();
    	}catch(Exception exception)
    	{
    		exception.printStackTrace();
    	}
    	
    	return userProfileDetails;
    }
    
    /**
     * This Method Will form the following objects
     * field=internet_bank_trans_limit;value=<from input User object>;type=number;key=n
     * field=thirdparty_limit;value=<from input User object>;type=number;key=n
     * call the updateProfile method of the UserDAO
     * method modified to handle Tax,Demat and eZtrade define limit for CR 5076 by Pons
     * @param userobj
     * @return UserProfile
     */
    public UserProfile updateLimits(Map inputParam) {
        logger.info("updatelimits(Map inputParam)" + LoggingConstants.METHODBEGIN);

        try {
        	User user = (User) inputParam.get(Constants.USER);
        	
        	String userName = user.getUserAlias();
            String bankCode = user.getBankCode();
            String branchCode=user.getBranchCode();
            String sfAuthProvider = (String)inputParam.get("sfAuthProvider");
        	String tokenStatus = (String)inputParam.get("tokenStatus");
             String minTaxApprLimit = (String)inputParam.get("minTaxApprLimit");
             String minDematApprLimit = (String)inputParam.get("minDematApprLimit");
             String minEztradeApprLimit = (String)inputParam.get("minEztradeApprLimit");
            
             Double minimumTaxApprLimit = Double.valueOf(minTaxApprLimit);
             Double minimumDematApprLimit = Double.valueOf(minDematApprLimit);
             Double minimimEztradeApprLimit = Double.valueOf(minEztradeApprLimit);
        
             Double currentTPLimit = user.getThirdPartyLimit();
             Double currentDDLimit = user.getPPFlimit();
            
            Double currentTaxTxnLimit = (Double)inputParam.get("currentTaxTxnLimit");
            //Double currentDematTxnLimit = user.getOverAllTxnLimit(); //CR-2187 Saravanan N
			//Added by Aruna.V
			Double currentDematTxnLimit =(Double)inputParam.get("currentDematTxnLimit");
            logger.info("currentDematTxnLimit::"+currentDematTxnLimit); 
            Double currentEztradeUserLimit=(Double)inputParam.get("currentEztradeUserLimit");
          //Added for CR 2899
            Double newTaxTxnLimit = new Double((String)inputParam.get("newTaxTxnLimit"));
            Double newDematTxnLimit= new Double((String)inputParam.get("otxnlimit"));
            Double ezTradeUserTxnLimit = new Double((String)inputParam.get("ezTradeUserTxnLimit"));
            String mobileNoAvail=(String)inputParam.get("userHasMobileNo");
            String userMobileNo = (String) inputParam.get("userMobileNo");
            String userCountryCode = (String) inputParam.get("userCountryCode");
            
            
            List inparamList = new ArrayList();
            List <Map>approvalDetailsList = new ArrayList<Map>();           
            
          
            Map<Object, Object> approvalDetailsMap = new HashMap<Object, Object>();
            if(userCountryCode == null || userCountryCode == " ")
            	userCountryCode="";
            else
            	userCountryCode = userCountryCode.trim();
            //End - CR 2899

            if (inputParam != null && userName != null && !userName.trim().equalsIgnoreCase(BPConstants.EMPTY)) {

                Double internetBankTransactionLimit = new Double((String) inputParam
                        .get(BPConstants.INTERNET_BANK_TRANSACTION_LIMIT));
                //Double thirdPartyLimit = new Double((String) inputParam.get(BPConstants.THIRDPARTY_LIMIT));//Commented for CR 5067
              
                /*if(thirdPartyLimit.compareTo(currentTPLimit) != 0 )
                {
                    try 
                    {
                    	//validator.validateLimit(thirdPartyLimit, Constants.THIRD_PARTY); commented for cr-5023
                    	validator.validateLimit(thirdPartyLimit, Constants.THIRD_PARTY,bankCode);//added for cr-5023
                        validator.validateMaxThirdParyLimit(thirdPartyLimit,userName);
                     }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(exception.getErrorCode());
                                                
                    }
                	
                    Field field1 = new Field();
                    field1.setFieldName(BPConstants.THIRDPARTY_LIMIT);
                    field1.setType(BPConstants.SQL_DOUBLE_VALUE);
                    field1.setValue(thirdPartyLimit);

                    inparamList.add(field1);
                }*///Commented for CR 5067
                
                if(currentDDLimit.compareTo(internetBankTransactionLimit) != 0)
                {
                    try 
                    {
                    	//validator.validateLimit(internetBankTransactionLimit, Constants.DEMAND_DRAFT);// commented for cr-5023
                    	validator.validateLimit(internetBankTransactionLimit, Constants.DEMAND_DRAFT,bankCode);//added for cr-5023
                    }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(ErrorConstants.INVALID_DD_LIMIT);                        
                    }

                    Field field2 = new Field();
                    field2.setFieldName(BPConstants.INTERNET_BANK_TRANSACTION_LIMIT);
                    field2.setType(BPConstants.SQL_DOUBLE_VALUE);
                    field2.setValue(internetBankTransactionLimit);

                    inparamList.add(field2);
                	
                }

               /* //Added for SI Module
                //Check for any TP SI. 
                int defineLimitCount = standingInstructionsDAOImpl.findSIExceedingDefineLimit(userName,thirdPartyLimit);
                if(defineLimitCount > 0)
                	SBIApplicationException.throwException("SI013"); 
                //End SI Module*///Commented for CR 5067
                
//              Added for CR 2899
                if(newTaxTxnLimit.compareTo(currentTaxTxnLimit) != 0)
                {
                	logger.info("currentTaxLimit is not equal to newTaxLimit");
                    try 
                    {
                        validator.validateLimit(newTaxTxnLimit,"TAX_TXN_MAX_LIMIT_"+user.getBankCode());
                        
                        //insert into temp table and send sms only if user entered limit exceeds min. approval limit
                        if(newTaxTxnLimit.compareTo(minimumTaxApprLimit) > 0)
                        {
                        	String highSecPwd=StringUtils.randomNumber().toString();
                        	approvalDetailsMap.put("userName",userName);
                        	approvalDetailsMap.put("branchCode",branchCode);
                        	approvalDetailsMap.put("mobileNo",userMobileNo);
                        	approvalDetailsMap.put("type","TAXLIMIT");
                        	approvalDetailsMap.put("smsPassword",highSecPwd);
                        	//Start:Updated for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("messageTypeId","MT000031");
                        	approvalDetailsMap.put("smsParam1","Tax");
                        	
                        	//approvalDetailsMap.put("userMessage","Your High Security Password to approve the Tax Transaction Limit is: "+highSecPwd);
                        	//approvalDetailsMap.put("userMessage","This Password is to approve the Tax Transaction Limit. Do not give it to anyone. " +
                        		//	"Bank will never call you to ask for it. Password : "+highSecPwd);
							//approvalDetailsMap.put("userMessage","Bank will NEVER telephone you to verify this password.Password to approve the Tax Transaction Limit is:"+highSecPwd+".Do not give it to anyone.");
                        	//End:Added for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("oldValue",currentTaxTxnLimit);
                        	approvalDetailsMap.put("newValue",newTaxTxnLimit);
                        	approvalDetailsList.add(approvalDetailsMap);
                        	                        	
                        }
                        else
                        {
                        	Field field4 = new Field();
	                        field4.setFieldName("NEWS_PREFERENCE2");
	                        field4.setType(BPConstants.SQL_DOUBLE_VALUE);                    
	                        field4.setValue(newTaxTxnLimit);
	                        inparamList.add(field4);
                        }
                    	
                    }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(exception.getErrorCode());                        
                    }    
                    catch (DAOException daoException) {
                        SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                    }                   
                    
                }
                //End - CR 2899
                
                if(currentEztradeUserLimit.compareTo(ezTradeUserTxnLimit) != 0)
                {
                    try 
                    {
                        validator.validateLimit(ezTradeUserTxnLimit,"EZ_TRADE_INTER_BR_LIMIT_"+user.getBankCode());
                        
                        if(ezTradeUserTxnLimit.compareTo(minimimEztradeApprLimit) > 0){
                        	approvalDetailsMap = new HashMap<Object, Object>();
                        	String highSecPwd=StringUtils.randomNumber().toString();
                        	approvalDetailsMap.put("userName",userName);
                        	approvalDetailsMap.put("branchCode",branchCode);
                        	approvalDetailsMap.put("mobileNo",userMobileNo);
                        	approvalDetailsMap.put("type","EZTRADE_LIMIT");
                        	approvalDetailsMap.put("smsPassword",highSecPwd);
                        	//Start:Updated for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("messageTypeId","MT000031");
                        	approvalDetailsMap.put("smsParam1","NRI eZ Trade");
                        	//approvalDetailsMap.put("userMessage","Your High Security Password to approve the NRI eZ Trade Transaction Limit is: "+highSecPwd);
                        	//approvalDetailsMap.put("userMessage","This Password is to approve the NRI eZ Trade Transaction Limit. Do not give it to anyone. " +
                        	//		"Bank will never call you to ask for it. Password :"+highSecPwd);
							//approvalDetailsMap.put("userMessage","Bank will NEVER telephone you to verify this password.Password to approve the NRI eZ Trade Transaction Limit is:"+highSecPwd+".Do not give it to anyone.");
                        	//End:Added for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("oldValue",currentEztradeUserLimit);
                        	approvalDetailsMap.put("newValue",ezTradeUserTxnLimit);
                        	approvalDetailsList.add(approvalDetailsMap);
                        }
                        else{
                        Field field3 = new Field();
                        field3.setFieldName("NEWS_PREFERENCE3");
                        field3.setType(BPConstants.SQL_DOUBLE_VALUE);                    
                        field3.setValue(ezTradeUserTxnLimit);
                        inparamList.add(field3);
                        }
                    }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(exception.getErrorCode());                        
                    }
                   
                }
                
//              Cr-2187 start Saravanan N
                if(currentDematTxnLimit.compareTo(newDematTxnLimit) != 0)
                {
                    try 
                    {
                        validator.validateLimit(newDematTxnLimit,"OVERALL_TXN_LIMIT_"+user.getBankCode());
                        if(newDematTxnLimit.compareTo(minimumDematApprLimit) > 0){
                        	approvalDetailsMap = new HashMap<Object, Object>();
                        	String highSecPwd=StringUtils.randomNumber().toString();
                        	approvalDetailsMap.put("userName",userName);
                        	approvalDetailsMap.put("branchCode",branchCode);
                        	approvalDetailsMap.put("mobileNo",userMobileNo);
                        	approvalDetailsMap.put("type","DEMAT_LIMIT");
                        	approvalDetailsMap.put("smsPassword",highSecPwd);
                        	//Start:Updated for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("messageTypeId","MT000031");
                        	approvalDetailsMap.put("smsParam1","Demat");
                        	//approvalDetailsMap.put("userMessage","Your High Security Password to approve the Demat Transaction Limit is: "+highSecPwd);
                        	//approvalDetailsMap.put("userMessage","This Password is to approve the Demat Transaction Limit. Do not give it to anyone. " +
                        	//		"Bank will never call you to ask for it. Password :"+highSecPwd);
							//approvalDetailsMap.put("userMessage","Bank will NEVER telephone you to verify this password.Password to approve the Demat Transaction Limit is:"+highSecPwd+".Do not give it to anyone.");
                        	//End:Added for Sivagnanavelu for smsgateway
                        	approvalDetailsMap.put("oldValue",currentDematTxnLimit);
                        	approvalDetailsMap.put("newValue",newDematTxnLimit);
                        	approvalDetailsList.add(approvalDetailsMap);
                        }
                        else{
                        Field field2 = new Field();
                        field2.setFieldName("OVERALL_TXN_LIMIT");
                        field2.setType(BPConstants.SQL_VARCHAR_VALUE);                    
                        field2.setValue((String) inputParam.get("otxnlimit"));
                        inparamList.add(field2);
                        }
                    }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(exception.getErrorCode());                        
                    }
                   
                    
                }
                //CR-2187 end
              
                if(approvalDetailsList!=null && approvalDetailsList.size()>0){
                	
                	boolean insertStatus = insertDefineLimitDetails(approvalDetailsList,mobileNoAvail);
                	 logger.info("insertStatus value" + insertStatus);
                	if(insertStatus && mobileNoAvail!=null && mobileNoAvail.equalsIgnoreCase("yes")){
                		 if(sfAuthProvider!=null && "SoftwareToken".equalsIgnoreCase(sfAuthProvider)){
                			 logger.info("sfAuthProvider" + sfAuthProvider);
                			 if(tokenStatus!=null && "".equalsIgnoreCase(tokenStatus)){
				 				SBIApplicationException.throwException("ST015");
				 			 }
                		 }else{
                		String mobileNo="";
                		String message="";
                		String messageTypeId="";
                		Map messageDetail=new HashMap();
                		for(int i=0;i<approvalDetailsList.size();i++){
                			messageDetail=(Map)approvalDetailsList.get(i);
                			mobileNo=(String)messageDetail.get("mobileNo");
                			//message=(String)messageDetail.get("userMessage"); // Updated By Sivagnanavelu for SMSgateway 
                			messageTypeId=(String)messageDetail.get("messageTypeId");
                			 if(logger.isDebugEnabled()){       
                			logger.debug("message :"+message);
                			 }
                			 String smsParamValues[]={(String)messageDetail.get("smsParam1"), (String)messageDetail.get("smsPassword")};
                			 smsGateWayRequestSender.sendSMSRequest(messageTypeId, smsParamValues,user.getBankCode(),ServiceConstant.SMS_SEND_ORDER_ZERO,userName);                      
                		}
                	
                		}
                	}
                }
				
                if(inparamList.size() > 0 )
                	userProfile = userDAOImpl.updateProfile(inparamList, user);
                else
                	userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        catch (Exception exception) {
            SBIApplicationException.throwException(exception.getMessage());
        }
        logger.info("UserProfile object contains value" + userProfile);
        logger.debug("updatelimits(Map inputParam)" + LoggingConstants.METHODEND);
        

        return userProfile;
    }

    /**
     * This method form the following objects
     * field=mobile_no;value=<from input User object>;type=number;key=n
     * field=sms_security;value=<from input User object>;type=number;key=n
     * will call the updateProfile method of the UserDAO
     * @param inputParam
     * @return UserProfile
     */
    public Map updateHighSecurityOption(Map inputParam) {
        logger.debug("updatehighsecurityoption(Map inputParam) Begin");

        Map outParams = new HashMap();
        try {
        	User user = (User) inputParam.get(Constants.USER);
            String userName = user.getUserAlias();
            
            if(logger.isDebugEnabled())
            logger.debug("input fron  Service : " + inputParam);

            if (inputParam != null && userName != null && !userName.trim().equalsIgnoreCase(BPConstants.EMPTY)) {

                String mobileNumber = (String) inputParam.get(BPConstants.MOBILE_NO);
               // Integer smsSecurity = (Integer) inputParam.get(BPConstants.SMS_SECURITY);
                String dbChange = (String) inputParam.get( "dbChange");
                logger.info("In updateHighSecurityOption in ProfileBP:: mobileNumber: "+mobileNumber+" dbChange: "+dbChange+" old mobile no: "+(String) inputParam.get("oldMobileNo")+" new mobile no: "+(String) inputParam.get("newMobileNo"));
 /*               List inparamList = new ArrayList();
           	    //Added by Madhan for CR-1894               
               // if(smsSecurity.equals(new Integer(0))){
	                Field field1 = new Field();
	                field1.setFieldName(BPConstants.MOBILE_NO);
	                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
	                field1.setValue(mobileNumber);
	                inparamList.add(field1);
                //}
                //End CR-1894
                Field field2 = new Field();
                field2.setFieldName(BPConstants.SMS_SECURITY);
                field2.setType(BPConstants.SQL_INTEGER_VALUE);
                field2.setValue(smsSecurity);

                
                inparamList.add(field2);
*/
                 outParams= userDAOImpl.updateProfileMobileNo(inputParam, user);
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("updatelimits(Map inputParam) End" );

        return outParams;
    }

    /**
     * This method will call the getValidator method of ProfileValidatorFactory with type as
     * TP if the account nature of in accounts object passed is 1
     * PPF if the account nature of in accounts object passed is 2
     * 2. With the object obtained in Step1 calls  the validate method of ProfileValidatorBP.
     * 3. If the validate method returns true calls the insertaccount method of AccountDAO
     * @param account
     * @return Account
     */
    public Account addUserAccounts(Account account) {
        logger.debug("addUseraccounts( Account account )" + LoggingConstants.METHODBEGIN);


        try {
            
            if (account != null) {
                
                String validatortype = "";
                logger.debug("Setting the account nature for Validator factory ");
                if(account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString()))
                {
                    validatortype = BPConstants.THIRD_PARTY;
                }
                else
                {
                    validatortype = BPConstants.PPF;
                    account.setAccessLevel(new Integer(1));
                }
                
                logger.debug("Calling the getValidator of profileValidatorFactory");
                profileValidatorBP = profileValidatorFactory.getvalidator(validatortype);
                
                Map validateMap = new HashMap();
                validateMap.put(TP_VALIDATION_KEY,TP_VALIDATION_ADD_TYPE);
                validateMap.put(ACCOUNT_KEY,account);
                logger.debug("Calling the validate of profileValidatorBP");
                profileValidatorBP.validate(validateMap);
                
                updatedAccountObj = accountDAOImpl.insertAccount(account);
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.info("Account object contains value" + updatedAccountObj);
        logger.debug("addUseraccounts( Account account )" + LoggingConstants.METHODEND);


        return updatedAccountObj;
    }

    /**
     * 1.This method will call the getValidator method of ProfileValidatorFactory with type as TP
     * 2. With the object obtained in Step1 calls  the validate method of ProfileValidatorBP.
     * 3. If the validate method returns true calls the updateaccount method of AccountDAO
     * @param account
     * @return Account
     */
    public Map editUserAccount(Account account) {
        logger.debug("edituseraccount( Account account )" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Account Object is" + account);
        Account updatedAccountObj = new Account();
        String oldBranchCode =account.getBranchCode();
        String sfAuthProvider = account.getSfAuthProvider();
        String tokenStatus = account.getTokenStatus();
        Map accountMap = new HashMap();
        try {

            if (account != null) {

                String validatortype = "";
                logger.debug("Setting the account nature for Validator factory ");
                if(account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString()))
                {
                    validatortype = BPConstants.THIRD_PARTY;
                }
                else
                {
                    validatortype = BPConstants.PPF;
                }
                
                logger.debug("Calling the getValidator of profileValidatorFactory");
                profileValidatorBP = profileValidatorFactory.getvalidator(validatortype);
                
                logger.debug("Calling the validate of profileValidatorBP");
                Map validateMap = new HashMap();
                validateMap.put(TP_VALIDATION_KEY,TP_VALIDATION_EDIT_TYPE);
                validateMap.put(ACCOUNT_KEY,account);
                profileValidatorBP.validate(validateMap);
                // updatedAccountObj = accountDAOImpl.updateThirdParty(account,oldBranchCode);
                //Approve limit start
                Map thirdParty = new HashMap();
                thirdParty = accountDAOImpl.getCurrentTpTxnLimit(account.getUserName(), account.getAccountNo(), oldBranchCode);
                if (thirdParty != null){
	                logger.info("thirdParty"+thirdParty);
	                logger.info("oldTxnLimit::"+thirdParty.get("TRANSACTION_LIMIT"));
	                String oldTxnLimit= thirdParty.get("TRANSACTION_LIMIT").toString();
	                logger.info("oldTxnLimit:"+oldTxnLimit);
	                double oldTPLimit = Double.parseDouble(oldTxnLimit);
	                double newTransferLimit = account.getBalance().doubleValue();
	                String currentTpName = (String)thirdParty.get("NAME_THIRD_PARTY");
	                //String msg="";
	                String highSecPwd= StringUtils.randomNumber().toString();
	                logger.info("oldTPLimit.doubleValue() :"+oldTPLimit);
	                accountMap.put("oldTxnLimit", oldTxnLimit);
	                thirdParty.put("oldbranchcode", oldBranchCode);
	                logger.info(" account.getBalance().doubleValue() :"+ account.getBalance().doubleValue());
	                if ( account.getBalance().doubleValue() == oldTPLimit){
	                	accountMap.put("limitModified", "No");
	                }
	                if ( account.getBalance().doubleValue()< oldTPLimit ){
	                	accountMap.put("limitModified", "yes");
	                }
	                if ( account.getBalance().doubleValue()> oldTPLimit ){
	                	
	                	if(sfAuthProvider !=null && "SoftwareToken".equalsIgnoreCase(sfAuthProvider)){
		 		 			if(tokenStatus!=null && "Blocked".equalsIgnoreCase(tokenStatus)){
		 						logger.info("user have token in blocked state");
		 						SBIApplicationException.throwException("ST015");
		 					}
		 		 			logger.info("user have token in active state");
		        		 }
	                	
	                	userProfile = userDAOImpl.findUserProfile(account.getUserName());
	                	//msg ="Bank will NEVER telephone you to verify this password.Password to approve third party transfer limit is:"+highSecPwd+".Do not give it to anyone.";
	                	thirdParty.put("mobileOption", "No");
	                	if (userProfile.getMobileNumber() != null){
	                		thirdParty.put("mobileOption", "Yes");
	                	}
	                	if(sfAuthProvider!=null && "SoftwareToken".equalsIgnoreCase(sfAuthProvider)){
	                		thirdParty.put("mobileOption", "Yes");
                		}
	                	thirdParty.put("userAccount", account);
	                	thirdParty.put("smsPassword", highSecPwd);
	                	updatedAccountObj = userDAOImpl.insertApprovalBeneficiaryLimit(thirdParty);
	                	if (userProfile.getMobileNumber() != null ){
	                		if(sfAuthProvider!=null && "SoftwareToken".equalsIgnoreCase(sfAuthProvider)){
	                			accountMap.put("limitModified", "yes");
	                		}
	                		else{
		                		String smsParamValues[] ={highSecPwd};
		                        String msgTypeId = "MT000024";
		                        smsGateWayRequestSender.sendSMSRequest(msgTypeId, smsParamValues,userProfile.getBankCode(),ServiceConstant.SMS_SEND_ORDER_ZERO,account.getUserName());
	                		}
	                	}
	                	accountMap.put("limitModified", "yes");
	                	account.setBalance(oldTPLimit); // set old value as the limit value while updating in the table 
	                }//else 
	           	                
	                if ((currentTpName != null && account.getAccountNickName()!= null && 
	                		! currentTpName.equals(account.getAccountNickName()))
	                	||  account.getBalance().doubleValue()< oldTPLimit ){
	                	updatedAccountObj = accountDAOImpl.updateThirdParty(account,oldBranchCode);
	                	
	                	accountMap.put("BenDetails", "yes");
	                }
	                account.setBalance(newTransferLimit); // reset the new transfer limit in the account object .
                }else {
            	 SBIApplicationException.throwException("SE002");
                }
                //Approvel limit end
                
                accountMap.put("updatedAccount", updatedAccountObj);
                
            }
       
            }catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
            catch (SBIApplicationException sbiExc) {//added for PPF Limit change
            	 SBIApplicationException.throwException(sbiExc.getErrorCode(), sbiExc);
            }

           catch (Exception exception) {
                SBIApplicationException.throwException(exception.getMessage());
            }
        logger.info("Account object contains value" + updatedAccountObj);
        logger.debug("editUseraccounts( Account account )" + LoggingConstants.METHODEND);


         return accountMap;
       
        }

    /**
     * 1.Calls the encrpytParameter method of CommonUtils by passing  the hint question and hintanswer in a string array.
     * 2. The encrypted hint details obtained in the step 1 is validated against the hint details in the UserProfile object obtained as input. If it does not match throw an SBIApplicationException
     */
    public boolean verifyHintDetails(String hintquestion, String hintanswer, String username) {
        if (hintquestion != null && hintanswer != null && username != null) { 
        	boolean boolhintvalid = false;

            logger.debug("verifyhintdetails : obtaining userprofile object for user");
            UserProfile userprofile = userDAOImpl.findUserProfile(username);

            logger.debug("verifyhintdetails : obtaining hint details for the user");
            String actualhintq = userprofile.getHintQuestion();
            String actualhintans = userprofile.getHintAnswer();
            if (actualhintq != null && actualhintans != null) {
                logger.debug("verifyhintdetails : validating hint question against user profile object " + actualhintq);
                boolhintvalid = commonUtils.verifyEncryption(username + "|" + hintquestion, actualhintq);
                if (boolhintvalid) {
                    logger.debug("verifyhintdetails : validating hint answer against user profile object "
                            + actualhintans);
                      boolhintvalid = commonUtils.verifyEncryption(username + "|" + hintanswer, actualhintans);
                    if (boolhintvalid) {
                    	//Changed for CR 5145 by Devipriya
                       // SBIApplicationException.throwException(ErrorConstants.INVALID_HINT_ANSWER_ERROR_CODE);  
                    	boolhintvalid=true; 
                    }
                    
                }
                

            }
           
            return boolhintvalid;
        }
        else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);            
        }
        return false;
    }
    
    public UserProfile updateMobileNo(Map inputParams){
        
        UserProfile userProfile = null;
        String mobileNumber = (String) inputParams.get(BPConstants.MOBILE_NO);
        String countryCode =(String) inputParams.get(BPConstants.COUNTRY_CODE);
        if(mobileNumber!=null && countryCode!=null )
        {
            String busPhone = countryCode+"|"+mobileNumber;
            User user = (User) inputParams.get(BPConstants.USER);
            List inparamList = new ArrayList();
            Field field1 = new Field();
            try{
                field1.setFieldName(BPConstants.BUS_PHONE);
                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                field1.setValue(busPhone);
                inparamList.add(field1);                
                userProfile = userDAOImpl.updateProfile(inparamList,user);    
            }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    public UserProfile updateLoginCountAndNumber(Map inputParams){        
        UserProfile userProfile = null;
        Integer loginCount = (Integer) inputParams.get(BPConstants.LOGIN_COUNT);
        Date date = new Date();  
        java.sql.Date   sqlDate =  new java.sql.Date(date.getTime());
        Timestamp loginDate = new Timestamp(sqlDate.getTime());
        
        if(loginCount!=null )
        {
            User user = (User) inputParams.get(BPConstants.USER);
            List inparamList = new ArrayList();
            Field field1 = new Field();
            Field field2 = new Field();
            try{
                field1.setFieldName(BPConstants.SQL_LOGIN_COUNT);
                field1.setType(BPConstants.SQL_INTEGER_VALUE);
                field1.setValue(loginCount);
                inparamList.add(field1);
                
                field2.setFieldName(BPConstants.SQL_LOGIN_DATE);
                field2.setType(BPConstants.SQL_TIMESTAMP_VALUE);
                field2.setValue(loginDate);
                inparamList.add(field2);
                userProfile = userDAOImpl.updateProfile(inparamList,user); 
            }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    public void changeLoginPassword(User user, String oldPassword, String newPassword){    	
    	if(user != null ){
    		String newMD5Password = "";
    		String newSHAPassword = "";
    		if(!logonValidator.firstTimeLoginPassword(newPassword))//changed for CR 5034 - reusing first time login validation.
            	SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
    		userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
    		boolean status= false;
    		String profileMode = userProfile.getProfileHashing() !=null && userProfile.getProfileHashing().trim().length()>0?"SHA-512":"MD5";
    		if("MD5".equals(profileMode)){
    			status = EncryptMD5.verifyHash(user.getUserAlias() + "|" + newPassword, userProfile.getProfilepassword());
    		}else{
    			status = requestResponseService.validateHashSHA2(userProfile.getProfilepassword(),user.getUserAlias() + "|" + newPassword);
    		}
    	
         	if(status)
         		SBIApplicationException.throwException("SE149");
	        try{
	    		String userName = user.getUserAlias();
	    		 boolean loginStatus = false;
	    		 String loginMode = userProfile.getLoginHashing() !=null && userProfile.getLoginHashing().trim().length()>0?"SHA-512":"MD5";
	    			 loginStatus = userDAOImpl.validateLogin(null, userName, oldPassword,loginMode);
	    		 
	    		if(loginStatus){
	    			
	    			newMD5Password=EncryptMD5.hashMessage(user.getUserAlias() + "#" + newPassword); //added for CR 5034
	    			newSHAPassword= requestResponseService.getSHA2Hashing(user.getUserAlias(),newPassword,"#");
	    			//sha512Hashing.hashingSHA2(user.getUserAlias() + "#" + newPassword); //added for SHA Implementation
	    			//added for CR 5450 - begin
	    			int passHistCount = userDAOImpl.getPrevPassHistory(user.getUserAlias(), newMD5Password,newSHAPassword);
	    			if (passHistCount>0){
	    				SBIApplicationException.throwException("SE151");
	    			}
	    			//added for CR 5450 - end
	    			userDAOImpl.changeLoginPassword(user, oldPassword, newSHAPassword);
	    			userDAOImpl.insertMD5PasswordTemp(userName, newMD5Password);
	    		}else{
	    			SBIApplicationException.throwException(ErrorConstants.INVALID_LOGIN_PASSWORD_ERROR_CODE);
	    		}
	    	}catch(DAOException daoExp){
	    		SBIApplicationException.throwException(daoExp.getErrorCode());
	    	}	    	
        }
    
        }
    //Added by Madhan for CR-2086
    /**
     * This method will call the getValidator method of ProfileValidatorFactory with type as
     * TP if the account nature of in accounts object passed is 1
     * PPF if the account nature of in accounts object passed is 2
     * 2. With the object obtained in Step1 calls  the validate method of ProfileValidatorBP.
     * 3. If the validate method returns true calls the insertaccount method of AccountDAO
     * @param account
     * @return Account
     */
    public Account validateTPAccount(Account account) {
        logger.debug("validateTPAccount( Account account )" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Account Object is" + account);

        try {
            
            if (account != null) {
                
                String validatortype = "";
                logger.debug("Setting the account nature for Validator factory ");
                if(account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString()))
                {
                    validatortype = BPConstants.THIRD_PARTY;
                }
                else
                {
                    validatortype = BPConstants.PPF;
                    account.setAccessLevel(new Integer(1));
                }
                
                logger.debug("Calling the getValidator of profileValidatorFactory");
                profileValidatorBP = profileValidatorFactory.getvalidator(validatortype);
                
                Map validateMap = new HashMap();
                validateMap.put(TP_VALIDATION_KEY,TP_VALIDATION_ADD_TYPE);
                validateMap.put(ACCOUNT_KEY,account);
                logger.debug("Calling the validate of profileValidatorBP");
                profileValidatorBP.validate(validateMap);
               
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.info("Account object contains value" + updatedAccountObj);
        logger.debug("validateTPAccount( Account account )" + LoggingConstants.METHODEND);


        return account;
    }

    //End CR-2086
    //Added for SI Module
    //If validateBenName returns true then name is modified and SI is avaliable, false otherwise 
    public boolean validateBenName(Account account) {
    	 if(logger.isDebugEnabled())
    		 logger.debug("validateBenName begins");
        String oldThirdPartyName="";
        boolean status = false;
        try {
            if (account != null) {
            	Map result = standingInstructionsDAOImpl.findTPNameLimit(account);
            	 if (result != null) {
            		 if(logger.isDebugEnabled())
            		 	logger.debug("Values in Map " + result);
            		 String thirdPartyName = account.getAccountNickName();
            		 oldThirdPartyName = (String) result.get("NAME_THIRD_PARTY");
 	                 if(!oldThirdPartyName.equalsIgnoreCase(thirdPartyName)){//Name is modified, check whether you have any SI in table
 	                	logger.info("Name is modified, check whether you have any SI in table");
	            		int benNameCount = standingInstructionsDAOImpl.findSIBeneficiary(account.getUserName(),account.getAccountNo(),account.getBranchCode(),oldThirdPartyName);
	            		if(benNameCount >0)
	            			status = true;
	            		else
	            			status = false;
	            	}else{
	            		logger.info("Name is not modified, no check is needed whether you have any SI in table");
	            		status = false;
	            	}
            	}
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        if(logger.isDebugEnabled())
        	logger.debug("validateBenName ends");
        return status;
    }
    
    public boolean validateSILimit(Account account) {
    	if(logger.isDebugEnabled())
    		logger.debug("validateSILimit begins");
        double oldLimit;
        boolean status=false;
        try {
            if (account != null) {
            	Map result  = standingInstructionsDAOImpl.findTPNameLimit(account);
            	 if (result != null) {
            		 if(logger.isDebugEnabled())
            		 	logger.debug("Values in Map " + result);
            		 double newLimit = account.getBalance().doubleValue();
            		 oldLimit =  ((BigDecimal)result.get("TRANSACTION_LIMIT")).doubleValue();
            		 String oldThirdPartyName = (String) result.get("NAME_THIRD_PARTY");
  	                logger.info(" oldLimit: "+oldLimit);
	            	if(newLimit<oldLimit){
	            		//Name is modified, check whether you have any SI in table
	            		logger.info("newLimit is less than oldLimit, check whether you have any SI in table");
	            		int benLimitCount = standingInstructionsDAOImpl.findSIBeneficiaryExceedingLimit(account.getUserName(),account.getBalance(),account.getAccountNo(),account.getBranchCode(),oldThirdPartyName);
	            		if(benLimitCount >0)
	            			status=true;
	            		else
	            			status=false;
	            	}else{
	            		logger.info("newLimit is greater than oldLimit or they might be equal also, no check is needed whether you have any SI in table");
	            		status=false;
	            	}
            	}
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        if(logger.isDebugEnabled())
        	logger.debug("validateSILimit ends");
        return status;
    }
    
    
    public boolean validateIBBenName(RTGSBeneficiaryDetails beneficiaryDetails,String oldTPName) {
    	if(logger.isDebugEnabled())
    		logger.debug("validateBenName begins");
    	boolean status=false;
        try {
            if (beneficiaryDetails != null) {
            	String thirdPartyName = beneficiaryDetails.getThirdPartyName();
            	if(!oldTPName.equalsIgnoreCase(thirdPartyName)){
            		//Name is modified, check whether you have any SI in table
            		logger.info("Name is modified, check whether you have any SI in table");
            		int benNameCount = standingInstructionsDAOImpl.findSIBeneficiary(beneficiaryDetails.getUserName(),beneficiaryDetails.getAccountNo(),beneficiaryDetails.getIFSCReceiver(),oldTPName);
            		if(benNameCount >0)
            			status=true;
            		else
            			status=false;
            	}else{
            		logger.info("Name is not modified, no check is needed whether you have any SI in table");
            		status=false;
            	}
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        if(logger.isDebugEnabled())
        	logger.debug("validateBenName ends");
        return status;
    }
    
    public boolean validateIBSILimit(RTGSBeneficiaryDetails beneficiaryDetails,double oldLmt,String oldTPName) {
    	 if(logger.isDebugEnabled())
        logger.debug("validateSILimit begins");
    	 boolean status=false;
       try {
            if (beneficiaryDetails != null) {
            	double newLimit = beneficiaryDetails.getTransferLimit().doubleValue();
            	if(newLimit<oldLmt){
            		//Name is modified, check whether you have any SI in table
            		logger.info("newLimit is less than oldLimit, check whether you have any SI in table");
            		int benLimitCount = standingInstructionsDAOImpl.findSIBeneficiaryExceedingLimit(beneficiaryDetails.getUserName(),beneficiaryDetails.getTransferLimit(),beneficiaryDetails.getAccountNo(),beneficiaryDetails.getIFSCReceiver(),oldTPName);
            		if(benLimitCount >0)
            			status=true;
            		else
            			status=false;
            	}else{
            		logger.info("newLimit is greater than oldLimit or they might be equal also, no check is needed whether you have any SI in table");
            		status=false;
            	}
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        if(logger.isDebugEnabled())
        logger.debug("validateSILimit ends");
        return status;
    }

    //End SI Module
    //Added for CR 2899
    public boolean insertDefineLimitDetails(List approvalList,String mobileNoAvail) throws DAOException
    {
    	logger.debug("insertDefineLimitDetails - method begin");
    	logger.info("approvalList :"+approvalList.size());
    	int noOfRowsUpdated  = userDAOImpl.insertApprovalDefineLimitDetails(approvalList,mobileNoAvail);
    	logger.debug("insertDefineLimitDetails - method end");
    	if(noOfRowsUpdated>0)
    		return true;
    	else
    		return false; 
     }
    //End - CR 2899 
    
    
    //Added for CR 5355
    public String checkPhisingIP(String ipAddress, String userName) {
		logger.info("checkPhisingIP method begins");
		String validateIP= null;
		try{
			validateIP = validator.checkPhisingIP(ipAddress, userName);
		}catch(DAOException daoException){
			SBIApplicationException.throwException(daoException.getErrorCode());			
		}	
		logger.info("checkPhisingIP method ends");
		return validateIP;		
	}
    //End of CR 5355

    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

    public void setCommonUtils(CommonUtils commonUtils) {
        this.commonUtils = commonUtils;
    }

    public void setProfileValidatorBP(ProfileValidatorBP profileValidatorBP) {
        this.profileValidatorBP = profileValidatorBP;
    }

    public void setProfileValidatorFactory(ProfileValidatorFactory profileValidatorFactory) {
        this.profileValidatorFactory = profileValidatorFactory;
    }

    public void setValidator(Validator validator) {
        this.validator = validator;
    }

    public void setUserDAOImpl(UserDAO userDAOImpl) {
        this.userDAOImpl = userDAOImpl;
    }

	public void setLogonValidator(LogonValidator logonValidator) {
		this.logonValidator = logonValidator;
	}

	public void setStandingInstructionsDAOImpl(
			StandingInstructionsDAO standingInstructionsDAOImpl) {
		this.standingInstructionsDAOImpl = standingInstructionsDAOImpl;
	}  

	//Added for SMSgateway by Sivagnanavelu
	public void setSmsGateWayRequestSender(SMSGateWayRequestSender smsGateWayRequestSender) {
		this.smsGateWayRequestSender = smsGateWayRequestSender;
	}

	public RequestResponseService getRequestResponseService() {
		return requestResponseService;
	}

	public void setRequestResponseService(
			RequestResponseService requestResponseService) {
		this.requestResponseService = requestResponseService;
	}
	
}






