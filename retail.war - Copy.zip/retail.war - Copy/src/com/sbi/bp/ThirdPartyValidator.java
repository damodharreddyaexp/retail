/**
 * @(#) TPValidator.java
 */
 
package com.sbi.bp;


import java.util.HashMap;
import java.util.Map;

import com.sbi.model.Account;
import com.sbi.utils.Constants;
import com.sbi.utils.ProfileValidator;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;
import org.apache.log4j.Logger;
import com.sbi.utils.LoggingConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.ProfileDAO;
 
public class ThirdPartyValidator extends ProfileValidatorBP
{
    private ProfileValidator profileValidator;
    private ProfileDAO profileDAOImpl;
    
    private BranchMasterDAO branchMasterDAOImpl;
    
    private Validator validator;
    
    private Logger logger = Logger.getLogger(getClass());
    
    private final static String TP_VALIDATION_KEY = "validationType";
    
    private final static String TP_VALIDATION_ADD_TYPE = "Add";
    
    private final static String TP_VALIDATION_EDIT_TYPE = "Edit";
    
    private final static String ACCOUNT_KEY = "account";
	/**
	 * Will call the following methods 
	 * 1.findBankSystem of BranchmasterDAO
	 * 2.verifyaccountidentifier of the Profilevalidator
	 * 3.validateaccount of the Profilevalidator
	 * 4.verifylimit of validator class
	 */ 
	public void validate( Object input )
	{
        if(input != null)
        {        	
            logger.info("TPValidator : validate method "+LoggingConstants.METHODBEGIN);
            Map validateMap = (HashMap) input;
            
            String type = (String)  validateMap.get(TP_VALIDATION_KEY);
            Account acc = (Account) validateMap.get(ACCOUNT_KEY);

            logger.info("TPValidator : calling findBankSystem");
            String banksystem = branchMasterDAOImpl.findBankSystem(acc.getBranchCode());
            
            logger.info("TPValidator : banksystem "+banksystem);
            if(banksystem == null)
            	banksystem = Constants.NONCORE_SYSTEM;
            acc.setBankSystem(banksystem);
 
            logger.info("TPValidator : calling verifyaccountidentifier");
            //added for CR 2854
            profileValidator.validateOwnAccount(acc);
            profileValidator.verifyAccountIdentifier(acc);



//          added by viswalakshmy for  PPF  cr2633 starts
            
            String productCode = acc.getProductCode();            
            logger.info("ProductCode:"+productCode);
            if ("13111401".equals(productCode))
    		{            	
    	 /*Map branchlist =profileDAOImpl.findUserBranches(acc.getUserName(), "ALL"); 
    		 //(Map) userSessionCache.getData(acc.getUserName()+BPConstants.BRANCH_LIST_REFERENCE);
    	 	logger.info("branchlist: "+branchlist);
    	 	logger.info("PPFValidator : Branch code obtained"+acc.getBranchCode());
         	logger.info("PPFValidator : branchlist size"+branchlist.size());
         
         logger.info("PPFValidator : calling verifybranchcode");
         profileValidator.verifyBranchCode(acc.getBranchCode(),branchlist);*/
            validator.validateLimit(acc.getBalance(),"PPF",acc.getBranchCode().substring(0,1));//CR-5023
            //limit change -uday
            //validator.validateLimit(acc.getBalance(),"TP",acc.getBranchCode().substring(0,1));//CR-5023
            validator.validateCategoryAdditionLimit(acc.getBalance(),acc.getBranchCode().substring(0,1),"Thirdparty");//CR-5023
            //Added for CR 3081
            validator.validateMinimumAmount(acc.getBalance(), "PPF");
            validator.validateMulitplesOfHundred(acc.getBalance());
            //End of CR 3081
         
    		}
            
//          added by viswalakshmy for  PPF  cr2633 ends
            
       

            
            logger.info("TPValidator : calling validateAccount");
            if(type.equalsIgnoreCase(TP_VALIDATION_ADD_TYPE))
            {
            	profileValidator.validateAddAccount(acc);
            }
//          modified for cr-2854
            else if(type.equalsIgnoreCase(TP_VALIDATION_EDIT_TYPE)){
            	//profileValidator.validateEditAccount(acc);
            }
            else{
            	SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
            }
            logger.info("TPValidator : calling verifylimit");
            //limit change -uday
           // validator.validateLimit(acc.getBalance(),UtilsConstant.THIRD_PARTY);
            validator.validateCategoryAdditionLimit(acc.getBalance(),acc.getBranchCode().substring(0,1),"Thirdparty");//CR-5023
        }
        else
        {
            logger.error("TPValidator : Error in data received");
            SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
        }
		 
	}
    public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
        this.branchMasterDAOImpl = branchMasterDAOImpl;
    }
    public void setProfileValidator(ProfileValidator profileValidator) {
        this.profileValidator = profileValidator;
    }
    public void setValidator(Validator validator) {
        this.validator = validator;
    }
	public void setProfileDAOImpl(ProfileDAO profileDAOImpl) {
		this.profileDAOImpl = profileDAOImpl;
	}


}
