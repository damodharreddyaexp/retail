/*
 * ConvertToMiniBillerBP.java
 * Created on Dec 24, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 24, 2005 BOOPATHI - Initial Creation

package com.sbi.bp;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.MiniBiller;
import com.sbi.model.UserBillerMap;
import com.sbi.utils.LoggingConstants;

public class ConvertToMiniBillerBP
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    public List getMiniBiller(List userBillerMapList){
        
       logger.info("getMiniBiller(List userBillerMapList) "+LoggingConstants.METHODBEGIN);
       if(logger.isDebugEnabled()){
           logger.info("userBillerMapList "+userBillerMapList);
       }
       List miniBillerData = new ArrayList();
       if(userBillerMapList != null && userBillerMapList.size() > 0 ){
            
         
           for (int i = 0; i < userBillerMapList.size(); i++)
           {

               UserBillerMap userBillerMap = (UserBillerMap) userBillerMapList.get(i);

               MiniBiller miniBiller = new MiniBiller();
               miniBiller.setBillerName((String) userBillerMap.getBiller().getFriendlyName());
               miniBiller.setBillerID((String) userBillerMap.getBiller().getBillerID());
               miniBiller.setNickName((String) userBillerMap.getBillerShortname());
               miniBiller.setReason((String) userBillerMap.getReason());
               miniBiller.setRegnStatus((String) userBillerMap.getCustRegnStatus());
               miniBiller.setSerialNo(userBillerMap.getSerialNo());               
               miniBiller.setAutoPay(userBillerMap.getAutoPay());
           
               miniBillerData.add(miniBiller);
           }
           
           
           if(logger.isDebugEnabled()){
               logger.info("miniBillerData "+miniBillerData);
           }
           logger.info("getMiniBiller(List userBillerMapList) "+LoggingConstants.METHODEND);
           }else
           {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
              
            }
       return miniBillerData;
    }
    
    
}

