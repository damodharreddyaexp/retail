package com.sbi.bp;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.sbi.dao.CoreDAO;
import com.sbi.dao.CoreInterfaceDAO;
import com.sbi.dao.TdsEnquiryDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.CoreClient;
import com.sbi.utils.CoreMessageProcessor;
import com.sbi.utils.MapToXMLConvertor;
import com.sbi.utils.NroMapToXMLConvertor;
import com.sbi.utils.PdfReportWriter;

public class TdsEnquiryBP {

	private CoreDAO coreDAOImpl;

	private MapToXMLConvertor mapToXMLConvertor;
	private NroMapToXMLConvertor nromapToXMLConvertor;

	private PdfReportWriter pdfReportWriter;

	private CoreMessageProcessor coreMessageProcessor;

	private CoreClient coreClient;

	private CoreInterfaceDAO coreInterfaceDAOImpl;

	private TdsEnquiryDAO tdsEnquiryDAOImpl;

	protected final Logger logger = Logger.getLogger(getClass());
	
	/*public static String convertCoreAmtFormatToAmount(String value) {
		String signtrail = null;
		if(value.contains("+") && value != null){
		signtrail=value.replace("+","");
		}else{
		signtrail=value;
		}
		return signtrail;
	}*/

	public Map getCIFNumberMethod(String referenceNo, String accountNo,
			String branchCode, String taxYear, String userName) {
		logger.info("getCIFNumberMethod(String referenceNo,String accountNo,String branchCode,String taxYear,String userName) -STARTS");
		String bankCode = "";
		String cifNo = "";
		Map tdsEnqMap =new HashMap();
		Map returnMap = null;
		if(accountNo !=null && accountNo.length()>0){
			bankCode=branchCode.substring(0,1);
			tdsEnqMap.put("reference_no",referenceNo);
			tdsEnqMap.put("account_no", accountNo);
			tdsEnqMap.put("bank_code", bankCode);
			tdsEnqMap.put("userName", userName);
			tdsEnqMap.put("bankCode", bankCode);
			tdsEnqMap.put("txnno", "000400");
			tdsEnqMap.put("branchCode", branchCode);
			tdsEnqMap.put("taxYear",taxYear);

			try {
				
				List<Map> responseList = coreDAOImpl.getDataFromBankSystem(tdsEnqMap);
				Map<String,String> resMap = responseList.get(0);
				tdsEnqMap.put("cif_no",resMap.get("cif_no"));
				tdsEnqMap.put("name",resMap.get("name"));
				cifNo = resMap.get("cif_no");

				logger.info("Response map is : " + resMap);
				if (cifNo != null && cifNo.length() > 0)
					returnMap = getTdsDetails(tdsEnqMap);
				else{
					returnMap = new HashMap();
					returnMap.put("updateFlag",false);
				}
			} catch (Exception e) {
				logger.error("Exception in getCIFNumberMethod",e);
				returnMap.put("updateFlag",false);
				return returnMap;
			}
		}
		logger.info("getCIFNumberMethod(String referenceNo,String accountNo,String branchCode,String taxYear,String userName) -ENDS");
		return returnMap;
	}

	
		public Map getCIFNumberMethodNroTds(String referenceNo, String accountNo,String Nro_Flag,String tdsEnqOption,String branchCode,String userName) {
		logger.info("getCIFNumberMethod(String referenceNo,String accountNo,String branchCode,String userName) -STARTS");
		String bankCode = "";
		String cifNo = "";
		Map tdsEnqMap =new HashMap();
		Map returnMap = null;
		if(accountNo !=null && accountNo.length()>0){
			bankCode=branchCode.substring(0,1);
			tdsEnqMap.put("reference_no",referenceNo);
			tdsEnqMap.put("account_no", accountNo);
			tdsEnqMap.put("tds_EnqOption", tdsEnqOption);
			tdsEnqMap.put("Nro_Flag", Nro_Flag);
			tdsEnqMap.put("bank_code", bankCode);
			tdsEnqMap.put("userName", userName);
			tdsEnqMap.put("bankCode", bankCode);
			tdsEnqMap.put("txnno", "000400");
			tdsEnqMap.put("branchCode", branchCode);
			try {
				List<Map> responseList = coreDAOImpl.getDataFromBankSystem(tdsEnqMap);
				logger.info("After responseList :::: " + responseList);
				Map<String,String> resMap = responseList.get(0);
				tdsEnqMap.put("cif_no",resMap.get("cif_no"));
				tdsEnqMap.put("name",resMap.get("name"));
				cifNo = resMap.get("cif_no");

				logger.info("Response map is : " + resMap);
				if (cifNo != null && cifNo.length() > 0){
					returnMap = getNroTdsDetails(tdsEnqMap);
					returnMap.put("updateFlagNro",true);
				}
				else{
					returnMap = new HashMap();
					returnMap.put("updateFlag",false);
					returnMap.put("updateFlagNro",false);
				}
			}catch (SBIApplicationException SBIApplicationException) {
				logger.error("inside SBIApplicationException TDSEnquiryBP :::::",SBIApplicationException);
				returnMap.put("updateFlag",false);
				returnMap.put("updateFlagNro",false);
				return returnMap;
			} 
			catch (Exception e) {
				logger.error("Exception in getCIFNumberMethod",e);
				returnMap.put("updateFlag",false);
				returnMap.put("updateFlagNro",false);
				return returnMap;
			}
		}
		logger.info("getCIFNumberMethod(String referenceNo,String accountNo,String branchCode,String taxYear,String userName) -ENDS");
		return returnMap;
	}
	
	/**
	 * 
	 * @param tdsEnMap
	 * @return
	 * @throws Exception
	 */
	private Map getTdsDetails(Map tdsEnMap) throws Exception {

		logger.info("getTdsDetails(Map tdsEnMap) -STARTS");
		Map<String, String> cifMap = new HashMap<String, String>();
		String recordsRemaining = "";
		int recordsRemainingInt = 0;
		String bankCode = "";
		Vector response = null;
		String status = "pending";
		boolean responseConversionFlag = true;
		boolean displayFlag = false;
		String xmlString = "";
		StringBuffer xmlStringBuffer = new StringBuffer();
		String taxYear = (String) tdsEnMap.get("taxYear");
		String refNo = (String) tdsEnMap.get("reference_no");
		String branchCode = (String) tdsEnMap.get("branchCode");
		String corebranchCode = (String) tdsEnMap.get("branchCode");// Fix for
																	// handling
																	// 'A'
																	// branch
																	// code.
																	// While
																	// sending
																	// to core
																	// alone 'A'
																	// is
																	// replaced
																	// with '1'
		String cif_no = (String) tdsEnMap.get("cif_no");
		String custName = (String) tdsEnMap.get("name");
		bankCode = branchCode.substring(0, 1);
		Map<String, String> responseMap = null;
		Map returnMap = new HashMap();
		cifMap.put("reference_no", refNo);
		cifMap.put("txnno", "000510");
		String finYear = taxYear.replaceAll("-", "");
		cifMap.put("tax_year", finYear);
		if (branchCode.substring(0, 1).equalsIgnoreCase("A")) {
			corebranchCode = branchCode.replaceAll("A", "1").replaceAll("a",
					"1");
		}
		// DEV - 292
		
		cifMap.put("enquiry_option", "4");
		logger.info("corebranchCode"+ corebranchCode);
		cifMap.put("bankCode", bankCode);
		cifMap.put("branch_code",corebranchCode);
		cifMap.put("account_no",cif_no);
		cifMap.put("entity_type","C");
		cifMap.put("customer_no", cif_no);
		String reqString = coreMessageProcessor.convertRequest(cifMap);
		cifMap.put("req_string", reqString);
		List prop = coreInterfaceDAOImpl.findCoreResponseData("000512");
		response = coreClient.processMsg(reqString, bankCode);
		String responseStr = (String)response.get(0);
		cifMap.put("branch_code",(String)tdsEnMap.get("branchCode")); //Again mapping to 'A' Branch Code;
		if (responseStr.indexOf("ERR.")>=0 || responseStr.charAt(12) == '1'){
			status="processed";
			responseConversionFlag=false;
			displayFlag=true;
		}
		else if (responseStr.equals("F1")||responseStr.equals("F2"))
			responseConversionFlag=false;
	

		if  (responseConversionFlag){
			logger.info("Response string from core inside getTdsDetails method :/n"+responseStr);
			responseMap=(Map)coreMessageProcessor.convertResponse(responseStr,"000512",prop);
			recordsRemaining =responseMap.get("records_remaining");
			if(recordsRemaining !=null && recordsRemaining.trim().length()>0  )
				recordsRemainingInt = new Integer(recordsRemaining);
			logger.info("records remaining column from the core String :"+recordsRemainingInt);
			if(recordsRemainingInt>0){
				status="pending";
				displayFlag=false;
			}
			else{
				status="processed";
				displayFlag=true;
			}
		}
		tdsEnMap.put("response",responseStr);
		tdsEnMap.put("request",reqString);
		tdsEnMap.put("status", status);
		tdsEnMap.put("customer_name",custName);
		tdsEnMap.put("displayFlag",displayFlag);
		String referenceNumber=  tdsEnquiryDAOImpl.raiseTdsRequest(tdsEnMap);
		returnMap.put("referenceNumber", referenceNumber);
	//Commented and modified for fixing issue on 26-04-2010 starts 
		//if  (responseConversionFlag){
		if  (responseConversionFlag && displayFlag){
	//Commented and modified for fixing issue on 26-04-2010 ends 
			xmlStringBuffer.append("<TDSENQUIRY>");
			xmlString=mapToXMLConvertor.constructXmlString(responseMap,cifMap);
			xmlStringBuffer.append(xmlString);
			xmlStringBuffer.append("</TDSENQUIRY>");
			logger.info("XML string formed ::");
			writeXmlfile(taxYear, xmlStringBuffer.toString(),referenceNumber,"");
		}

		returnMap.put("updateFlag", displayFlag);
		logger.info("getTdsDetails(Map tdsEnMap) -ENDS");
		return returnMap;
	}

	private Map getNroTdsDetails(Map tdsEnMap) throws Exception {

		logger.info("getTdsDetails(Map tdsEnMap) -STARTS");
		Map<String, String> cifMap = new HashMap<String, String>();
		String recordsRemaining = "";
		int recordsRemainingInt = 0;
		String bankCode = "";
		Vector response = null;
		Vector response000614 = null;
		String status = "pending";
		boolean responseConversionFlag = true;
		boolean corenotconflag = true;
		boolean displayFlag = false;
		String xmlString = "";
		StringBuffer xmlStringBuffer = new StringBuffer();
		String taxYear = "-";
		String tdsenquiryOption = (String) tdsEnMap.get("tds_EnqOption");
		String Nro_Flag = (String) tdsEnMap.get("Nro_Flag");
		String refNo = (String) tdsEnMap.get("reference_no");
		String branchCode = (String) tdsEnMap.get("branchCode");
		String corebranchCode = (String) tdsEnMap.get("branchCode");
		String cif_no="";
		cif_no = (String) tdsEnMap.get("cif_no");
		String custName = (String) tdsEnMap.get("name");
		bankCode = branchCode.substring(0, 1);
		Map<String, String> responseMap = null;
		
		Map returnMap = new HashMap();
		cifMap.put("reference_no", refNo);
		cifMap.put("txnno", "000507");
		if (branchCode.substring(0, 1).equalsIgnoreCase("A")) {
			corebranchCode = branchCode.replaceAll("A", "1").replaceAll("a",
					"1");
		}
		cifMap.put("enquiry_option",tdsenquiryOption);
		logger.info("corebranchCode"+ corebranchCode);
		cifMap.put("bankCode", bankCode);
		cifMap.put("branch_code",corebranchCode);
		cifMap.put("account_no",cif_no);
		cifMap.put("entity_type","C");
		cifMap.put("customer_no", cif_no);
		String reqString = coreMessageProcessor.convertRequest(cifMap);
		System.out.println("reqString Value :::::: "+reqString);
		cifMap.put("req_string", reqString);
		String tds_option_value = reqString.substring(40,41);
		logger.info("TDS Option Value :"+tds_option_value);
		
			List prop000614 = coreInterfaceDAOImpl.findCoreResponseData("000614");
			List prop000509 = coreInterfaceDAOImpl.findCoreResponseData("000509");
		
			
			cifMap.put("branch_code",(String)tdsEnMap.get("branchCode")); 
			
			if((tds_option_value!=null) && (("1".equalsIgnoreCase(tds_option_value)) || ("2".equalsIgnoreCase(tds_option_value))))
			{
				response = coreClient.processMsg(reqString, bankCode);
				System.out.println("000614 response string Value :::::: "+response);
				String responseStr000614 = (String)response.get(0);
				if (responseStr000614.indexOf("ERR.")>=0 || responseStr000614.charAt(12) == '1'){
					status="processed";
					responseConversionFlag=false;
					displayFlag=true;
				}
				else if (responseStr000614.equals("F1")||responseStr000614.equals("F2"))
					corenotconflag=false;

				if  (responseConversionFlag){
					logger.info("Response string from core inside getTdsDetails method :/n"+responseStr000614);
					responseMap=(Map)coreMessageProcessor.convertResponse(responseStr000614,"000614",prop000614);
					
					String CNCS_rate=responseMap.get("CNCS_rate");
					String CNCS_rate_614=getFormattedAmount(CNCS_rate,4);
					responseMap.put("CNCS_rate", CNCS_rate_614);
					String CNCS_surcharge=responseMap.get("CNCS_surcharge");
					String CNCS_surcharge_614=getFormattedAmount(CNCS_surcharge,4);
					responseMap.put("CNCS_surcharge", CNCS_surcharge_614);
					
					Date now=new Date();
					String submit_date=responseMap.get("submit_date");
					String day=submit_date.substring(0, 2);
					String month=submit_date.substring(2, 4);
					String year=submit_date.substring(4, 8);
					String DATE_FORMAT = day+"/"+month+"/"+year;
					responseMap.put("submit_date", DATE_FORMAT);
					String certificate_type=responseMap.get("certificate_type").trim();
					responseMap.put("certificate_type", certificate_type);
				}
				tdsEnMap.put("response",responseStr000614);
				tdsEnMap.put("request",reqString);
				tdsEnMap.put("status", status);
				tdsEnMap.put("customer_name",custName);
				tdsEnMap.put("displayFlag",displayFlag);
				tdsEnMap.put("Nro_Flag",Nro_Flag);
				if((tdsenquiryOption.equalsIgnoreCase("1")) && (tdsenquiryOption!=null))
				{
					tdsEnMap.put("Enquiry_Flag","1");
				}else if((tdsenquiryOption.equalsIgnoreCase("2")) && (tdsenquiryOption!=null)) {
					tdsEnMap.put("Enquiry_Flag","2");
				}
				returnMap.put("responseMap", responseMap);
				returnMap.put("updateFlag", displayFlag);
				returnMap.put("responseConversionFlag", responseConversionFlag);
				returnMap.put("corenotconflag", corenotconflag);
			}
			else if((tds_option_value!=null) && ("3".equalsIgnoreCase(tds_option_value)))
			{
				/*Map<String, String> responseMap_Convert = null;
				responseMap_Convert=new HashMap<String, String>();*/
				response = coreClient.processMsg(reqString, bankCode);
				System.out.println("000509 response string Value :::::: "+response);
				String responseStr = (String)response.get(0);
				if (responseStr.indexOf("ERR.")>=0 || responseStr.charAt(12) == '1'){
					status="processed";
					responseConversionFlag=false;
					displayFlag=true;
				}
				else if (responseStr.equals("F1")||responseStr.equals("F2"))
				    corenotconflag=false;

				if  (responseConversionFlag){
					logger.info("Response string from core inside getTdsDetails method :/n"+responseStr);
					responseMap=(Map)coreMessageProcessor.convertResponse(responseStr,"000509",prop000509);
					/*String customerno=responseMap.get("customer_no");
					String customer_no=convertCoreAmtFormatToAmount(customerno);
					responseMap_Convert.put("customer_no", customer_no);
					
					String actionval=responseMap.get("action");
					String action=convertCoreAmtFormatToAmount(actionval);
					responseMap_Convert.put("action", action);
					
					String customername=responseMap.get("customer_name");
					String customer_name=convertCoreAmtFormatToAmount(customername);
					responseMap_Convert.put("customer_name", customer_name);
					
					String TDSexemption=responseMap.get("TDS_exemption");
					String TDS_exemption=convertCoreAmtFormatToAmount(TDSexemption);
					responseMap_Convert.put("TDS_exemption", TDS_exemption);
					
					String CNCSratecert=responseMap.get("CNCS_rate_cert");
					String CNCS_rate_cert=convertCoreAmtFormatToAmount(CNCSratecert);
					responseMap_Convert.put("CNCS_rate_cert", CNCS_rate_cert);
					
					String totaltaxpaid=responseMap.get("total_tax_paid");
					String total_tax_paid=convertCoreAmtFormatToAmount(totaltaxpaid);
					responseMap_Convert.put("total_tax_paid", total_tax_paid);
					
					String CNCSrate=responseMap.get("CNCS_rate");
					String CNCS_rate=convertCoreAmtFormatToAmount(CNCSrate);
					responseMap_Convert.put("CNCS_rate", CNCS_rate);
					
					String CNCSsurcharge=responseMap.get("CNCS_surcharge");
					String CNCS_surcharge=convertCoreAmtFormatToAmount(CNCSsurcharge);
					responseMap_Convert.put("CNCS_surcharge", CNCS_surcharge);
					
					String displayedtdnv=responseMap.get("displayed_tdnv");
					String displayed_tdnv=convertCoreAmtFormatToAmount(displayedtdnv);
					responseMap_Convert.put("displayed_tdnv", displayed_tdnv);
					
					String displayedtdrh=responseMap.get("displayed_tdrh");
					String displayed_tdrh=convertCoreAmtFormatToAmount(displayedtdrh);
					responseMap_Convert.put("displayed_tdrh", displayed_tdrh);
					
					String todisplaytdnv=responseMap.get("to_display_tdnv");
					String to_display_tdnv=convertCoreAmtFormatToAmount(todisplaytdnv);
					responseMap_Convert.put("to_display_tdnv", to_display_tdnv);
					
					String todisplaytdrh=responseMap.get("to_display_tdrh");
					String to_display_tdrh=convertCoreAmtFormatToAmount(todisplaytdrh);
					responseMap_Convert.put("to_display_tdrh", to_display_tdrh);
					
					String branchspecific=responseMap.get("branch_specific");
					String branch_specific=convertCoreAmtFormatToAmount(branchspecific);
					responseMap_Convert.put("branch_specific", branch_specific);
					
					String recordsremaining=responseMap.get("records_remaining");
					String records_remaining=convertCoreAmtFormatToAmount(recordsremaining);
					responseMap_Convert.put("records_remaining", records_remaining);
					
					String accountnumber1=responseMap.get("account_number_1");
					String account_number_1=convertCoreAmtFormatToAmount(accountnumber1);
					responseMap_Convert.put("account_number_1", account_number_1);
					
					String accountbranch1=responseMap.get("account_branch_1");
					String account_branch_1=convertCoreAmtFormatToAmount(accountbranch1);
					responseMap_Convert.put("account_branch_1", account_branch_1);
					
					String accountstatus1=responseMap.get("account_status_1");
					String account_status_1=convertCoreAmtFormatToAmount(accountstatus1);
					responseMap_Convert.put("account_status_1", account_status_1);
					
					String incometaxpaid1=responseMap.get("income_tax_paid_1");
					String income_tax_paid_1=convertCoreAmtFormatToAmount(incometaxpaid1);
					responseMap_Convert.put("income_tax_paid_1", income_tax_paid_1);
					
					String surchargepaid1=responseMap.get("surcharge_paid_1");
					String surcharge_paid_1=convertCoreAmtFormatToAmount(surchargepaid1);
					responseMap_Convert.put("surcharge_paid_1", surcharge_paid_1);
					
					String cesspaid1=responseMap.get("cess_paid_1");
					String cess_paid_1=convertCoreAmtFormatToAmount(cesspaid1);
					responseMap_Convert.put("cess_paid_1", cess_paid_1);
					
					String interestpaid1=responseMap.get("interest_paid_1");
					String interest_paid_1=convertCoreAmtFormatToAmount(interestpaid1);
					responseMap_Convert.put("interest_paid_1", interest_paid_1);
					
					String rolloverdate1=responseMap.get("rollover_date_1");
					String rollover_date_1=convertCoreAmtFormatToAmount(rolloverdate1);
					responseMap_Convert.put("rollover_date_1", rollover_date_1);
					
					String accountnumber2=responseMap.get("account_number_2");
					String account_number_2=convertCoreAmtFormatToAmount(accountnumber2);
					responseMap_Convert.put("account_number_2", account_number_2);
					
					String accountbranch2=responseMap.get("account_branch_2");
					String account_branch_2=convertCoreAmtFormatToAmount(accountbranch2);
					responseMap_Convert.put("account_branch_2", account_branch_2);
					
					String accountstatus2=responseMap.get("account_status_2");
					String account_status_2=convertCoreAmtFormatToAmount(accountstatus2);
					responseMap_Convert.put("account_status_2", account_status_2);
					
					String incometaxpaid2=responseMap.get("income_tax_paid_2");
					String income_tax_paid_2=convertCoreAmtFormatToAmount(incometaxpaid2);
					responseMap_Convert.put("income_tax_paid_2", income_tax_paid_2);
					
					String surchargepaid2=responseMap.get("surcharge_paid_2");
					String surcharge_paid_2=convertCoreAmtFormatToAmount(surchargepaid2);
					responseMap_Convert.put("surcharge_paid_2", surcharge_paid_2);
					
					String cesspaid2=responseMap.get("cess_paid_2");
					String cess_paid_2=convertCoreAmtFormatToAmount(cesspaid2);
					responseMap_Convert.put("cess_paid_2", cess_paid_2);
					
					String interestpaid2=responseMap.get("interest_paid_2");
					String interest_paid_2=convertCoreAmtFormatToAmount(interestpaid2);
					responseMap_Convert.put("interest_paid_2", interest_paid_2);
					
					String rolloverdate2=responseMap.get("rollover_date_2");
					String rollover_date_2=convertCoreAmtFormatToAmount(rolloverdate2);
					responseMap_Convert.put("rollover_date_2", rollover_date_2);
					
					String accountnumber3=responseMap.get("account_number_3");
					String account_number_3=convertCoreAmtFormatToAmount(accountnumber3);
					responseMap_Convert.put("account_number_3", account_number_3);
					
					String accountbranch3=responseMap.get("account_branch_3");
					String account_branch_3=convertCoreAmtFormatToAmount(accountbranch3);
					responseMap_Convert.put("account_branch_3", account_branch_3);
					
					String accountstatus3=responseMap.get("account_status_3");
					String account_status_3=convertCoreAmtFormatToAmount(accountstatus3);
					responseMap_Convert.put("account_status_3", account_status_3);
					
					String incometaxpaid3=responseMap.get("income_tax_paid_3");
					String income_tax_paid_3=convertCoreAmtFormatToAmount(incometaxpaid3);
					responseMap_Convert.put("income_tax_paid_3", income_tax_paid_3);
					
					String surchargepaid3=responseMap.get("surcharge_paid_3");
					String surcharge_paid_3=convertCoreAmtFormatToAmount(surchargepaid3);
					responseMap_Convert.put("surcharge_paid_3", surcharge_paid_3);
					
					String cesspaid3=responseMap.get("cess_paid_3");
					String cess_paid_3=convertCoreAmtFormatToAmount(cesspaid3);
					responseMap_Convert.put("cess_paid_3", cess_paid_3);
					
					String interestpaid3=responseMap.get("interest_paid_3");
					String interest_paid_3=convertCoreAmtFormatToAmount(interestpaid3);
					responseMap_Convert.put("interest_paid_3", interest_paid_3);
					
					String rolloverdate3=responseMap.get("rollover_date_3");
					String rollover_date_3=convertCoreAmtFormatToAmount(rolloverdate3);
					responseMap_Convert.put("rollover_date_3", rollover_date_3);
					
					String accountnumber4=responseMap.get("account_number_4");
					String account_number_4=convertCoreAmtFormatToAmount(accountnumber4);
					responseMap_Convert.put("account_number_4", account_number_4);
					
					String accountbranch4=responseMap.get("account_branch_4");
					String account_branch_4=convertCoreAmtFormatToAmount(accountbranch4);
					responseMap_Convert.put("account_branch_4", account_branch_4);
					
					String accountstatus4=responseMap.get("account_status_4");
					String account_status_4=convertCoreAmtFormatToAmount(accountstatus4);
					responseMap_Convert.put("account_status_4", account_status_4);
					
					String incometaxpaid4=responseMap.get("income_tax_paid_4");
					String income_tax_paid_4=convertCoreAmtFormatToAmount(incometaxpaid4);
					responseMap_Convert.put("income_tax_paid_4", income_tax_paid_4);
					
					String surchargepaid4=responseMap.get("surcharge_paid_4");
					String surcharge_paid_4=convertCoreAmtFormatToAmount(surchargepaid4);
					responseMap_Convert.put("surcharge_paid_4", surcharge_paid_4);
					
					String cesspaid4=responseMap.get("cess_paid_4");
					String cess_paid_4=convertCoreAmtFormatToAmount(cesspaid4);
					responseMap_Convert.put("cess_paid_4", cess_paid_4);
				    
					String interestpaid4=responseMap.get("interest_paid_4");
					String interest_paid_4=convertCoreAmtFormatToAmount(interestpaid4);
					responseMap_Convert.put("interest_paid_4", interest_paid_4);
					
					String rolloverdate4=responseMap.get("rollover_date_4");
					String rollover_date_4=convertCoreAmtFormatToAmount(rolloverdate4);
					responseMap_Convert.put("rollover_date_4", rollover_date_4);
					
					String accountnumber5=responseMap.get("account_number_5");
					String account_number_5=convertCoreAmtFormatToAmount(accountnumber5);
					responseMap_Convert.put("account_number_5", account_number_5);
					
					String accountbranch5=responseMap.get("account_branch_5");
					String account_branch_5=convertCoreAmtFormatToAmount(accountbranch5);
					responseMap_Convert.put("account_branch_5", account_branch_5);
					
					String accountstatus5=responseMap.get("account_status_5");
					String account_status_5=convertCoreAmtFormatToAmount(accountstatus5);
					responseMap_Convert.put("account_status_5", account_status_5);
					
					String incometaxpaid5=responseMap.get("income_tax_paid_5");
					String income_tax_paid_5=convertCoreAmtFormatToAmount(incometaxpaid5);
					responseMap_Convert.put("income_tax_paid_5", income_tax_paid_5);
					
					String surchargepaid5=responseMap.get("surcharge_paid_5");
					String surcharge_paid_5=convertCoreAmtFormatToAmount(surchargepaid5);
					responseMap_Convert.put("surcharge_paid_5", surcharge_paid_5);
					
					String cesspaid5=responseMap.get("cess_paid_5");
					String cess_paid_5=convertCoreAmtFormatToAmount(cesspaid5);
					responseMap_Convert.put("cess_paid_5", cess_paid_5);
					
					String interestpaid5=responseMap.get("interest_paid_5");
					String interest_paid_5=convertCoreAmtFormatToAmount(interestpaid5);
					responseMap_Convert.put("interest_paid_5", interest_paid_5);
					
					String rolloverdate5=responseMap.get("rollover_date_5");
					String rollover_date_5=convertCoreAmtFormatToAmount(rolloverdate5);
					responseMap_Convert.put("rollover_date_5", rollover_date_5);
					
					String totalinterestpaid=responseMap.get("total_interest_paid");
					String total_interest_paid=convertCoreAmtFormatToAmount(totalinterestpaid);
					responseMap_Convert.put("total_interest_paid", total_interest_paid);*/
					
					recordsRemaining =responseMap.get("records_remaining");
					if(recordsRemaining !=null && recordsRemaining.trim().length()>0  )
						recordsRemainingInt = new Integer(recordsRemaining);
					logger.info("records remaining column from the core String :"+recordsRemainingInt);
					if(recordsRemainingInt>0){
						status="pending";
						displayFlag=false;
					}
					else{
						status="processed";
						displayFlag=true;
					}
				}
				tdsEnMap.put("response",responseStr);
				tdsEnMap.put("request",reqString);
				tdsEnMap.put("status", status);
				tdsEnMap.put("customer_name",custName);
				tdsEnMap.put("displayFlag",displayFlag);
				tdsEnMap.put("Nro_Flag",Nro_Flag);
				tdsEnMap.put("Enquiry_Flag","3");
				String referenceNumber=  tdsEnquiryDAOImpl.raiseNroTdsRequest(tdsEnMap);
				returnMap.put("referenceNumber", referenceNumber);
				returnMap.put("responseConversionFlag", responseConversionFlag);
				returnMap.put("corenotconflag", corenotconflag);
				if  (responseConversionFlag && displayFlag){
					xmlStringBuffer.append("<TDSENQUIRY>");
					xmlString=nromapToXMLConvertor.constructXmlString(responseMap,cifMap);
					xmlStringBuffer.append(xmlString);
					xmlStringBuffer.append("</TDSENQUIRY>");
					logger.info("XML string formed ::");
					writeXmlfile(taxYear, xmlStringBuffer.toString(),referenceNumber,tds_option_value);
				}

				returnMap.put("updateFlag", displayFlag);//check line
				logger.info("getTdsDetails(Map tdsEnMap) -ENDS");

			}
			
			
			return returnMap;
		}

	public static String getFormattedAmount(String amount,int length) {
		String xmlString=null;
		amount=amount.trim();
		if (length==5 ){
			if (amount.length()>2)
				xmlString=amount.substring(0,amount.length()-3)+"."+amount.substring(amount.length()-2);
			else if (amount.length()==2)
				xmlString="0.0"+amount;
			else
				xmlString="0.00";
		}else if (length==11)
		{
			if (amount.length()>1)
				xmlString=amount.substring(0,amount.length()-1)+".00";
			else
				xmlString="0.00";
		}
		else{
			amount=amount.substring(0,amount.length()-1);
			if(amount.length()>3)
				xmlString=amount.substring(0, amount.length()-3)+"."+amount.substring( amount.length()-3, amount.length()-1);
			else
			{
				if (amount.length()==3)
					xmlString="0."+amount.substring(0,2);
				else if (amount.length()==2)
					xmlString="0.0"+amount.substring(0,1);
				else
					xmlString="0.00";

			}	
		}
		String formatAmt=formatAmount(xmlString);
		return formatAmt;
		
	}
	
	public static String formatAmount(String absoluteAmount){
    	String sign="";
        String formattedAmount=" ";
    	if (absoluteAmount != null && absoluteAmount.length()>0) {
            if(absoluteAmount.substring(0,1).equals("-")){
                sign="-";
                absoluteAmount=absoluteAmount.substring(1,absoluteAmount.length());
            }
        	double doubleAmount=Double.valueOf(absoluteAmount).doubleValue();
            DecimalFormat decimalFormat = new DecimalFormat("#############0.00");
            String amount=decimalFormat.format(doubleAmount);
            int index = amount.indexOf(".");
            String decimalValue="";
            if (index != -1)
                decimalValue = amount.substring(index + 1);
            else
                decimalValue = "00";
            
            amount = amount.substring(0, index);
            int length = amount.length();
            if (length >= 1 && length <= 3)
                formattedAmount = amount;
            else {
                formattedAmount=amount.substring(length-3,length);
                for(int i=length-5;i>=0;i-=2)
                    formattedAmount=amount.substring(i,i+2)+","+formattedAmount;
                if(length%2==0)
                    formattedAmount=amount.substring(0,1)+","+formattedAmount;
            }
            formattedAmount = sign + formattedAmount + "." + decimalValue;
            
        } 
        return formattedAmount;
    }
	
	// DEV-292 - Form15G/15H BP start
	public Map getForm15ghMethod(String accountNo, String branchCode,
			String taxYear, String userName,String form15gORh) {
		logger.info("getForm15ghMethod(String referenceNo,String accountNo,String branchCode,String taxYear,String userName) -STARTS");
		String bankCode = "";
		String cifNo = "";
		Map tdsEnqMap = new HashMap();
		Map returnMap = null;
		try {
			bankCode = branchCode.substring(0, 1);
			if (("A|3|6").contains(bankCode)) {
				bankCode = "0";
			}
			// tdsEnqMap.put("reference_no", referenceNo);
			tdsEnqMap.put("account_no", accountNo);
			tdsEnqMap.put("bank_code", bankCode);
			tdsEnqMap.put("userName", userName);
			tdsEnqMap.put("bankCode", bankCode);
			tdsEnqMap.put("txnno", "000400");
			tdsEnqMap.put("branchCode", branchCode);
			tdsEnqMap.put("taxYear", taxYear);
            tdsEnqMap.put("form15gORh", form15gORh);
			List<Map> responseList = coreDAOImpl
					.getDataFromBankSystem(tdsEnqMap);
			Map<String, String> resMap = responseList.get(0);
			validateCoreResponse(resMap);
			tdsEnqMap.put("cif_no", resMap.get("cif_no"));
			cifNo = resMap.get("cif_no");
			returnMap = form15ghDetails(tdsEnqMap);

		} catch (SBIApplicationException e) {
			logger.error("SBIApplicationException occured", e);
			SBIApplicationException.throwException(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception occured", e);
			SBIApplicationException.throwException("SE002");
		}

		logger.info("getForm15ghMethod(String referenceNo,String accountNo,String branchCode,String taxYear,String userName) -ENDS");
		return returnMap;
	}

	/**
	 * 
	 * @param tdsEnMap
	 * @return
	 * @throws Exception
	 */
	private Map form15ghDetails(Map tdsEnMap) throws Exception {

		logger.info("form15ghDetails(Map tdsEnMap) -STARTS");
		Map<String, String> cifMap = new HashMap<String, String>();

		String bankCode = null;

		String taxYear = (String) tdsEnMap.get("taxYear");
		// String refNo = (String) tdsEnMap.get("reference_no");
		String branchCode = (String) tdsEnMap.get("branchCode");
		String corebranchCode = (String) tdsEnMap.get("branchCode");
		String cif_no = (String) tdsEnMap.get("cif_no");

		bankCode = branchCode.substring(0, 1);
		Map<String, String> responseMap = null;
		// cifMap.put("reference_no", refNo);
		cifMap.put("txnno", "000510");
		String finYear = taxYear.replaceAll("-", "");
		cifMap.put("tax_year", finYear);
		if (branchCode.substring(0, 1).equalsIgnoreCase("A")) {
			corebranchCode = branchCode.replaceAll("A", "1").replaceAll("a",
					"1");
		}
        String form15gORh=(String) tdsEnMap.get("form15gORh");
        if ("form15G".equals(form15gORh))
        {
        	cifMap.put("enquiry_option", "5");  //form15g
        }
        else
        {
        	cifMap.put("enquiry_option", "1"); // form15h

        }
		
		logger.info("corebranchCode" + corebranchCode);
		cifMap.put("bankCode", bankCode);
		cifMap.put("branch_code", corebranchCode);
		cifMap.put("account_no", cif_no);
		cifMap.put("entity_type", "C");
		cifMap.put("customer_no", cif_no);
		cifMap.put("responsetxnno", "000513");
		List responseList = coreDAOImpl.getDataFromBankSystem(cifMap);
		HashMap coreDataHash = (HashMap) responseList.get(0);
		coreDataHash.put("customer_no", cif_no);

		// validateCoreResponse(coreDataHash);

		logger.info("form15ghDetails(Map tdsEnMap) -ENDS");
		return coreDataHash;
	}

	private void validateCoreResponse(Map coreDataHash) {
		String status = null;
		String errorCode = null;
		String statement = null;
		Object errorObj[] = new Object[1];
		if (coreDataHash.get("status") != null) {
			status = (String) coreDataHash.get("status");
		}
		if (coreDataHash.get("error_code") != null) {
			errorCode = (String) coreDataHash.get("error_code");
			status = errorCode;
		}
		if (status != null || errorCode != null) {
			SBIApplicationException.throwException(status);
		}
	}

	// DEV-292 - Form15G/15H BP END

	/**
	 * 
	 * @param taxYear
	 * @param xmlString
	 * @param referenceNo
	 * @throws Exception
	 */
	private boolean writeXmlfile(String taxYear, String xmlString,
			String referenceNo,String tds_option_value) throws Exception {
		logger.info("writeXmlfile(String taxYear,String xmlString,String referenceNo) throws Exception::");
		boolean writeFlag = false;
		writeFlag = pdfReportWriter.write(taxYear, xmlString, referenceNo,tds_option_value);

		return writeFlag;

	}



	public CoreDAO getCoreDAOImpl() {
		return coreDAOImpl;
	}

	public void setCoreDAOImpl(CoreDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}

	public MapToXMLConvertor getMapToXMLConvertor() {
		return mapToXMLConvertor;
	}
	public void setMapToXMLConvertor(MapToXMLConvertor mapToXMLConvertor) {
		this.mapToXMLConvertor = mapToXMLConvertor;
	}
	public PdfReportWriter getPdfReportWriter() {
		return pdfReportWriter;
	}
	public void setPdfReportWriter(PdfReportWriter pdfReportWriter) {
		this.pdfReportWriter = pdfReportWriter;
	}
	public CoreMessageProcessor getCoreMessageProcessor() {
		return coreMessageProcessor;
	}
	public void setCoreMessageProcessor(CoreMessageProcessor coreMessageProcessor) {
		this.coreMessageProcessor = coreMessageProcessor;
	}
	public CoreClient getCoreClient() {
		return coreClient;
	}
	public void setCoreClient(CoreClient coreClient) {
		this.coreClient = coreClient;
	}
	public CoreInterfaceDAO getCoreInterfaceDAOImpl() {
		return coreInterfaceDAOImpl;
	}
	public void setCoreInterfaceDAOImpl(CoreInterfaceDAO coreInterfaceDAOImpl) {
		this.coreInterfaceDAOImpl = coreInterfaceDAOImpl;
	}
	public TdsEnquiryDAO getTdsEnquiryDAOImpl() {
		return tdsEnquiryDAOImpl;
	}

	public void setTdsEnquiryDAOImpl(TdsEnquiryDAO tdsEnquiryDAOImpl) {
		this.tdsEnquiryDAOImpl = tdsEnquiryDAOImpl;
	}
	public NroMapToXMLConvertor getNromapToXMLConvertor() {
		return nromapToXMLConvertor;
	}


	public void setNromapToXMLConvertor(NroMapToXMLConvertor nromapToXMLConvertor) {
		this.nromapToXMLConvertor = nromapToXMLConvertor;
	}

}
