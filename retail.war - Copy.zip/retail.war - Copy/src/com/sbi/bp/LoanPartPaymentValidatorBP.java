/* 
 * LoanPartPaymentValidatorBP.java
 * Created on Nov 15, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 15, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class LoanPartPaymentValidatorBP extends TransactionValidatorBP
{

    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;

    public boolean validate(Transaction transaction) throws SBIApplicationException
    {
        this.transaction = transaction;
        if (transaction != null)
        {
            logger.info("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled())
            {
                logger.debug("transaction :" + transaction.toString());
            }

            
            validator.validateAmount(transaction.getDebit().getAmount());
            if(logger.isDebugEnabled()){
            	logger.debug("validateAmount() return true");
            }
            
            validator.validateInterBank(transaction.getDebit().getBranchCode(),
                    transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
            if (logger.isDebugEnabled())
            { 
                logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
            }

            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
            if (logger.isDebugEnabled())
            {
                logger
                        .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
            }

            validator.validateTxnRights(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), transaction
                    .getCredit()[BPConstants.ZERO_INT].getBranchCode(), transaction.getCredit()[BPConstants.ZERO_INT]
                    .getUserName(), new Integer(BPConstants.CREDIT_NO));
            if (logger.isDebugEnabled())
            {
                logger
                        .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for credit- true");
            }
            
            validator.validateTodaysTxnLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                    .getBranchCode(), transaction.getDebit().getAmount());
            if (logger.isDebugEnabled())
            {
                logger
                        .debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
            }

            if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                    .getBranchCode())))
            {
                validator.validateInterBranchLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                        .getBranchCode(), transaction.getDebit().getAmount(), transaction.getName(),transaction.getBankCode());//bank code added for CR 1734
                if (logger.isDebugEnabled())
                {
                    logger
                            .debug("validateInterBranchLimit(String accountNo, String branchCode, Double amount, String name) method - true");
                }

            }
            
          /*  if (transaction.getPath().equalsIgnoreCase(BPConstants.NONCORE_TO_NONCORE))
            {
                validator.validateTransfer(transaction.getDebit().getAccountNo(),
                        transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), BPConstants.INTEREST);
                if (logger.isDebugEnabled())
                {
                    logger
                            .debug("validateTransfer(String debitAccountNo, String creditAccountNo, String transferType) method - true");
                }

            }*/
            
            
            String txnPath = transaction.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
            
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.INTEREST);

            logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
         

        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
        return true;
    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }

}

