/*
 * IPOValidatorBP.java
 * Created on Aug 25, 2008
 *  
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 25, 2008 Ponnusamy - Initial Creation
package com.sbi.bp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.DebtIPORequestDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.IPORequestDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.IPOBidDetails;
import com.sbi.model.IPODetails;
import com.sbi.utils.DebtIPOValidator;
import com.sbi.utils.IPOValidator;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class DebtIPOValidatorBP
{
	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;

	private DebtIPOValidator debtIpoValidator;

	private DebtIPORequestDAO debtIpoRequestDAOImpl;
	
	private ReferenceDataCache referenceDataCache;

	public boolean validate(IPODetails ipodetails, ArrayList arrCutOff) throws SBIApplicationException {
		logger.info("validate(IPODetails ipodetails) " + LoggingConstants.METHODBEGIN);
		if (ipodetails != null) {
			if (logger.isInfoEnabled()) {
				logger.info("ipodetails :" + ipodetails.toString());
			}
			boolean validPAN = debtIpoValidator.validatePANNumber(ipodetails.getPANNumber());
			if (!validPAN) {
				SBIApplicationException.throwException("IPO008");
			}
			boolean validDmatAcc = debtIpoValidator.validateDmatAccount(ipodetails.getDmatAccType(), ipodetails.getDPId(), ipodetails.getClientId());
			if (!validDmatAcc) {
				SBIApplicationException.throwException("IPO009");
			}
			Integer minQuantity = ipodetails.getMinQuantity();

			boolean validBidDetails = debtIpoValidator.validateQtyAndBidDetails(ipodetails.getBankCode(), ipodetails.getCompanyId(), minQuantity, arrCutOff);
			if (!validBidDetails) {
				SBIApplicationException.throwException("IPO012");
			}
			for (int i = 0; i < arrCutOff.size(); i++) {
				IPOBidDetails ipoBidDetails = (IPOBidDetails) arrCutOff.get(i); 				
				Double bidValue = new Double(ipoBidDetails.getBidValue());
				validator.validateAmount(bidValue);
				validator.validateLimit(bidValue, "RETAILIPO_TXN_MAX_LIMIT_"+ipodetails.getBankCode(), ipodetails.getBankCode());
			}
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount- bidValue() return true");
			}
			logger.info("getDebitAccountNo: "+ipodetails.getDebitAccountNo());
			logger.info("getDebitBranchCode: "+ipodetails.getDebitBranchCode());
			logger.info("getUserName: "+ipodetails.getUserName());
			logger.info("BPConstants.DEBIT_NO: "+BPConstants.DEBIT_NO);
			
			validator.validateTxnRights(ipodetails.getDebitAccountNo(), ipodetails.getDebitBranchCode(), ipodetails.getUserName(), new Integer(
					BPConstants.DEBIT_NO));
			if (logger.isInfoEnabled()) {
				logger.info("validateTxnRights method for debit - true");
			}
			//Validation for one company one Pannumber
			/*boolean ipoRequestStatus = debtIpoRequestDAOImpl.isIPORequested(ipodetails.getCompanyId(), ipodetails.getPANNumber());
			if (ipoRequestStatus) {
				SBIApplicationException.throwException("IPO006");
			}*/
			//isIPORequestMaxStatus 5 for that company with same account Number
			boolean isIPORequestMaxStatus = debtIpoRequestDAOImpl.isIPORequestMaxStatus(ipodetails);
			if (isIPORequestMaxStatus) {
				SBIApplicationException.throwException("IPO015");
			}
			
			//ashok added for Category Validation.
			boolean validCategoryValue = debtIpoValidator.validateCategoryAmount(ipodetails.getCompanyId(),ipodetails.getSumBidValue(),ipodetails.getUserType());

			if (!validCategoryValue) {
				SBIApplicationException.throwException("IPO019");
			}
			
			
			
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("validate(IPODetails ipodetails) " + LoggingConstants.METHODEND);
		return true;
	}
	
	// start of validation for validateOneCroreLimitforAccNoperDay 28/03/2013 --Anil
	public boolean validateOneCroreLimitforAccNoperDay(IPODetails ipodetails, Map outParams) throws SBIApplicationException {
		logger.info("validateOneCroreLimitforAccNoperDay " + LoggingConstants.METHODBEGIN);
		boolean isIPOLimitforAcc=false;
		if (ipodetails != null) {
			Double sumBidValue=(Double)outParams.get("sumBidValue");
			logger.info("validateOneCroreLimitforAccNoperDay sumBidValue:::: "+sumBidValue);
			String ipoReqReachedOneCrLimitPerDay = debtIpoRequestDAOImpl.ipoReqReachedOneCrLimitforAccNoPerDay(ipodetails,outParams);
			if(ipoReqReachedOneCrLimitPerDay!=null && !("").equalsIgnoreCase(ipoReqReachedOneCrLimitPerDay)){
				logger.info("validateOneCroreLimitforAccNoperDay   ipoReqReachedOneCrLimitPerDay::"+ipoReqReachedOneCrLimitPerDay);
				double chkTotal = Double.parseDouble(ipoReqReachedOneCrLimitPerDay);
				double chkLimitPerDay=chkTotal+sumBidValue;
				if (chkLimitPerDay>10000000) {
					isIPOLimitforAcc=true;
				}
			}

		} 
		logger.info("validateOneCroreLimitforAccNoperDay " + LoggingConstants.METHODEND);
		return isIPOLimitforAcc;
	}
	//end of validation for validateOneCroreLimitforAccNoperDay 28/03/2013 
	public boolean validateIPOEdit(IPODetails ipodetails, ArrayList arrCutOff, Map inParams) throws SBIApplicationException {

		logger.info("validate(IPODetails ipodetails) " + LoggingConstants.METHODBEGIN);
		if (ipodetails != null) {
			if (logger.isInfoEnabled()) {
				logger.info("ipodetails :" + ipodetails.toString());
			}
			boolean validPAN = debtIpoValidator.validatePANNumber(ipodetails.getPANNumber());
			if (!validPAN) {
				SBIApplicationException.throwException("IPO008");
			} 
			boolean validDmatAcc = debtIpoValidator.validateDmatAccount(ipodetails.getDmatAccType(), ipodetails.getDPId(), ipodetails.getClientId());
			if (!validDmatAcc) {
				SBIApplicationException.throwException("IPO009");
			}
			Integer minQuantity = ipodetails.getMinQuantity();

			boolean validBidDetails = debtIpoValidator.validateQtyAndBidDetails(ipodetails.getBankCode(), ipodetails.getCompanyId(), minQuantity, arrCutOff);
			if (!validBidDetails) {
				SBIApplicationException.throwException("IPO012");
			}
			for (int i = 0; i < arrCutOff.size(); i++) {
				IPOBidDetails ipoBidDetails = (IPOBidDetails) arrCutOff.get(i);
				Double bidValue = new Double(ipoBidDetails.getBidValue());
				validator.validateAmount(bidValue);
				validator.validateLimit(bidValue, "RETAILIPO_TXN_MAX_LIMIT_"+ipodetails.getBankCode(), ipodetails.getBankCode());
			}
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount- bidValue() return true");
			}
			logger.info("getDebitAccountNo: "+ipodetails.getDebitAccountNo());
			logger.info("getDebitBranchCode: "+ipodetails.getDebitBranchCode());
			logger.info("getUserName: "+ipodetails.getUserName());
			logger.info("BPConstants.DEBIT_NO: "+BPConstants.DEBIT_NO);
			
			validator.validateTxnRights(ipodetails.getDebitAccountNo(), ipodetails.getDebitBranchCode(), ipodetails.getUserName(), new Integer(
					BPConstants.DEBIT_NO));
			if (logger.isInfoEnabled()) {
				logger.info("validateTxnRights method for debit - true");
			}

			boolean validUserExistDetails = debtIpoRequestDAOImpl.validateUserExistDetails(inParams);
			if (!validUserExistDetails) {
				SBIApplicationException.throwException("IPO012");
			}
			
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("validate(IPODetails ipodetails) " + LoggingConstants.METHODEND);
		return true;
	
	}
	
	/**
	 * Added this for get the Max Bid value in the 3 Bid details
	 * @param bidValue
	 * @return
	 */
	public Double getMaxBidValue(String[] bidValue,String[] bidAction) {
		logger.info("getMaxBidValue method begin");
		Double maxValue = new Double(0);
		for (int i = 0; i < bidValue.length; i++) {
			if (bidAction[i]!=null && !bidAction[i].equals("D")) {
				if (bidValue[i] != null && bidValue[i].length() > 0) {
					if (maxValue < Double.parseDouble(bidValue[i])) {
						maxValue = Double.parseDouble(bidValue[i]);
					}
				}
			}
		}
		logger.info("Max Value Return : " + maxValue);
		logger.info("getMaxBidValue method end");
		return maxValue;
	}

	/**
	 * Added for IPO DEBT for sum of Bid values
	 */
	public Double getSumBidValue(String[] bidValue,String[] bidAction) {
		logger.info("getSumBidValue method begin");
		Double sumValue = new Double(0);
		for (int i = 0; i < bidValue.length; i++) {
			if (bidValue[i] != null && bidValue[i].length() > 0) {
				sumValue += Double.parseDouble(bidValue[i]);
			}
		}
		logger.info("getSumBidValue Return : " + sumValue);
		logger.info("getSumBidValue method end");
		return sumValue;
	}
	
	
	/**
	 * 
	 * @param companyId
	 * @param bidValue
	 * @return
	 */
	public String[] getBidValueWithDiscount(String bankCode, String companyId, 
			String[] bidValue,	String[] bidQuantity){
		logger.info("getBidValueWithDiscount(String, String[]) - begins");
		String discBidValue[] = new String[bidValue.length];
		List compList = debtIpoRequestDAOImpl.getDebtIPOdetails(companyId);
		IPODetails ipoDetails = (IPODetails) compList.get(0);
		double flatDiscount = ipoDetails.getDiscountFlatAmount();
		double percentDiscount = ipoDetails.getDiscountPercentage();
		double discountLimit = 0d;
		
		Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
		if(data != null){
			String tmpdiscountLimit = (String) data.get("RETAILIPO_DISC_LIMIT_"+bankCode);
			discountLimit = Double.parseDouble(tmpdiscountLimit);
			logger.info("Bank Code : "+bankCode);
			logger.info("Discount Limit : "+discountLimit);
		}
		
		if(flatDiscount == 0 && percentDiscount==0){
			logger.info("No Discount for this bid.");
			discBidValue = bidValue;
		}
		else{
			if(flatDiscount != 0){
				logger.info("Flat discount - "+flatDiscount);
				
				for(int i=0;i<bidValue.length;i++){
					if(bidValue[i] != null && !bidValue[i].equalsIgnoreCase("") && bidValue[i].trim().length()>0
							&& bidQuantity[i] != null && !bidQuantity[i].equalsIgnoreCase("") && bidQuantity[i].trim().length()>0){
						double tmpBidValue = Double.parseDouble(bidValue[i]);
						double totalFlatDiscount =  Double.parseDouble(bidQuantity[i]) * flatDiscount;
						logger.info("Flat discount for bid "+i+" is  - "+totalFlatDiscount);
						if(tmpBidValue > totalFlatDiscount && 
								(tmpBidValue - totalFlatDiscount) <= discountLimit)
							discBidValue[i] = ""+(long)Math.round(tmpBidValue - totalFlatDiscount);
						else
							discBidValue[i] = bidValue[i];
						logger.info("Disc Bid value :::"+discBidValue[i]);
					}
					else
						discBidValue[i] = bidValue[i];
				}
			}
			else if(percentDiscount != 0){
				logger.info("Discount % - "+percentDiscount);
				for(int i=0;i<bidValue.length;i++){
					if(bidValue[i] != null && !bidValue[i].equalsIgnoreCase("") && bidValue[i].trim().length()>0){
						double tmpBidValue = Double.parseDouble(bidValue[i]);
						double tmpDiscValue = (tmpBidValue * (percentDiscount / 100)); 
						if(tmpBidValue > tmpDiscValue && 
								(tmpBidValue - tmpDiscValue) <= discountLimit){
							discBidValue[i] = ""+(long)Math.round(tmpBidValue - tmpDiscValue);
						}
						else
							discBidValue[i] = bidValue[i];
						
						logger.info("Disc Bid value :::"+discBidValue[i]);
					}
					else
						discBidValue[i] = bidValue[i];
				}
			}
		}
		logger.info("getBidValueWithDiscount(String, String[]) - ends");
		return discBidValue;
	}
	public void setValidator(final Validator validator) {
		this.validator = validator;
	}
	public void setDebtIpoRequestDAOImpl(final DebtIPORequestDAO debtIpoRequestDAOImpl) {
		this.debtIpoRequestDAOImpl = debtIpoRequestDAOImpl;
	}
	public void setDebtIpoValidator(DebtIPOValidator debtIpoValidator) {
		this.debtIpoValidator = debtIpoValidator;
	}
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
}
