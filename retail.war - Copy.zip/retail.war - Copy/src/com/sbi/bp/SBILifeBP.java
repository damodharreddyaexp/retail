package com.sbi.bp;

import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.SBILifePolicyDetails;
import com.sbi.utils.SBILifeParser;
import com.sbi.wsclient.SBILifeWebServiceClient;

@SuppressWarnings(value="unchecked")
public class SBILifeBP {
	private static final Logger logger = Logger.getLogger(SBILifeBP.class);

	private SBILifeWebServiceClient webserviceCall;
	private AccountInformationBP accountInformationBp;
	private SBILifeParser sbiLifeParser;


	public SBILifePolicyDetails getPolicyDetails(String policyNo, String dateOfBirth) { 
		logger.info("SBILifePolicyDetails(..) Starts here");

		String xmlResponseString=null;
		SBILifePolicyDetails policyDetails=null;
		String parsedDOB=null;

		dateOfBirth=sbiLifeParser.convertDDMMYYYYFormat(dateOfBirth);

		
		Pattern p=Pattern.compile("\\/");
		String[] tok=p.split(dateOfBirth);
		String day=tok[0];
		String mon=tok[1];
		String ye=tok[2];

		StringBuilder appendFields=new StringBuilder();
		appendFields.append(day).append(mon).append(ye);
		
		parsedDOB=String.valueOf(appendFields);
	
		logger.info("Policy No: " + policyNo);		
		logger.info("Date Of Birth: " + dateOfBirth);
		logger.info("parsedDOB : " + parsedDOB);

		if(policyNo!=null && dateOfBirth!=null){

			xmlResponseString = webserviceCall.doWebServiceCall(policyNo, parsedDOB);
			if(StringUtils.isNotBlank(xmlResponseString)){

				Document dom = sbiLifeParser.getDocumentObj(xmlResponseString);
				List<SBILifePolicyDetails> parseDocumentList = sbiLifeParser.parseDocument(dom);
				policyDetails = sbiLifeParser.printData(parseDocumentList);
				
			}else {
				logger.info("No Response From SBI Life Premium, We are experiencing network delay, Please try later.");
				SBIApplicationException.throwException("SBLIFE003");
			}
		}else {			 
			logger.info("Policy Number / DOB is Empty ....");
			SBIApplicationException.throwException("SE002");
		}

		logger.info("SBILifePolicyDetails(..) Ends here");
		return policyDetails;

	}

	public List getTransactionAccounts(String userName)
	{
		logger.info("getTransactionAccounts(String userName) Starts");

		List debitAccountList = accountInformationBp.getTransactionAccounts(userName,"debitAccount");

		if (debitAccountList != null && debitAccountList.size() > 0 ){
			logger.info("Debit Account list -->"+debitAccountList);	
			Iterator debitIterator = debitAccountList.iterator();
			while(debitIterator.hasNext()) {  
				Account account = (Account) debitIterator.next();
				if (!"Core".equalsIgnoreCase(account.getBankSystem())) {
					debitIterator.remove();
				}
			}
		}
		else {
			SBIApplicationException.throwException("SE067");
		}

		logger.info("getTransactionAccounts(String userName) Ends");
		return debitAccountList;
	}

	public void setWebserviceCall(SBILifeWebServiceClient webserviceCall) {
		this.webserviceCall = webserviceCall;
	}
	public void setAccountInformationBp(AccountInformationBP accountInformationBp) {
		this.accountInformationBp = accountInformationBp;
	}
	public void setSbiLifeParser(SBILifeParser sbiLifeParser) {
		this.sbiLifeParser = sbiLifeParser;
	}
}
