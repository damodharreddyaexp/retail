package com.sbi.bp;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import com.sbi.bp.BPConstants;
import com.sbi.dao.AccountDAO;
import com.sbi.dao.DAOConstants;
import com.sbi.dao.SQLConstants;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.model.Account;
import com.sbi.model.CbecTransactionLeg;
import com.sbi.model.Transaction;
import com.sbi.service.ServiceConstant;
import com.sbi.service.ServiceErrorConstants;
import com.sbi.utils.StringUtils;
import com.sbi.utils.TransactionRequestMapper;
import com.sbi.dao.UserDAO;
import com.sbi.dao.EchequeMasterDAO;

import com.sbi.model.EchequeMaster;

public class TransactionManageBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private EchequeMasterDAO echequeMasterDAOImpl;

	private UserDAO userDAOImpl ;

	private ResourceBundleMessageSource transactionProperties;
	
    public static final String NC_DEBIT_ACCOUNT_DATA = "010|011|016|017";
	

	public CbecTransactionLeg getEcheque(String userName, String echequeNo,
			String functionType) {
		
	logger.debug("CorpTransactionLeg getEcheque(String userName, String echequeNo,String functionType) method begin");
	
	CbecTransactionLeg corptranleg = null;
		if (userName != null && echequeNo != null && functionType != null) {
			try{
			corptranleg = echequeMasterDAOImpl.findEcheque(userName, echequeNo,
					functionType);
			if (corptranleg != null) {

				corptranleg = setEchequePropeties(corptranleg);
				if (corptranleg.getEchequeNo().substring(0,2).equalsIgnoreCase("CS"))
					corptranleg.setBeneficiary(corptranleg.getName());

			} 
			}catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
				
			}
		} 
		logger.debug("CorpTransactionLeg getEcheque(String userName, String echequeNo,String functionType) method ends");
		return corptranleg;
	}



	private String getCorpTransactionStatus(String key) {
		String transactionValue = DAOConstants.TXN_STATUS_UNKNOWN;
		try {
			transactionValue = transactionProperties.getMessage(key, null,
					null);
		} catch (NoSuchMessageException ex) {
			//logger.error("Exception occured" ,ex );
		}

		return transactionValue;
	}
	
	
	
	
	
	public CbecTransactionLeg setEchequePropeties(CbecTransactionLeg corpTransactionLeg)
	{
		logger.debug("setEchequePropeties : begin");
		int curAuthLevel = Integer.parseInt(corpTransactionLeg
				.getCurrentAuthLevel());

		Date currentDate;
		currentDate = new Date(System.currentTimeMillis());

		String debitstatusmessage = null;
		debitstatusmessage = getCorpTransactionStatus("debitStatus"
				+ curAuthLevel);
		if (curAuthLevel == 50
				&& (Integer.parseInt(corpTransactionLeg.getScheduled()) == 0)
				&& (currentDate.before(corpTransactionLeg.getScheduledDate()))
				&& (Integer.parseInt(corpTransactionLeg.getProcessed()) == 1)) {

			debitstatusmessage = getCorpTransactionStatus("debitStatus"
					+ curAuthLevel);

		} else if ((curAuthLevel != 50) && (curAuthLevel > 0)
				&& (Integer.parseInt(corpTransactionLeg.getScheduled()) == 0)
				&& (Integer.parseInt(corpTransactionLeg.getProcessed()) == 1)
				&& (currentDate.before(corpTransactionLeg.getScheduledDate()))) {
			debitstatusmessage = getCorpTransactionStatus("debitStatusSPA");
		} else if ((curAuthLevel != 50) && (curAuthLevel > 0)) {
			debitstatusmessage = getCorpTransactionStatus("debitStatus"
					+ curAuthLevel);
		}
		else if (curAuthLevel==-1 || curAuthLevel==-2 || curAuthLevel==-3 || curAuthLevel==-5 || curAuthLevel==-6)
			debitstatusmessage=getCorpTransactionStatus("debitStatus"+curAuthLevel);
		else {
			String statusCode = null;
			logger.debug("getting status code ");
			statusCode = corpTransactionLeg.getStatusCode();
			if (statusCode != null) {
				if (statusCode != "00" && statusCode != "f1"
						&& statusCode != "08" && statusCode != "57")
					debitstatusmessage = getCorpTransactionStatus("statusCodeElse");
				else
					debitstatusmessage = getCorpTransactionStatus("statusCode"
							+ statusCode);

				if (debitstatusmessage.equalsIgnoreCase("pending")) {
					debitstatusmessage = getCorpTransactionStatus("debitStatusAPD");
				}

			}

		}//end of else

		if (debitstatusmessage.equalsIgnoreCase("unknown"))
			debitstatusmessage = getCorpTransactionStatus("debitStatusUnknown");

		corpTransactionLeg.setStatus(debitstatusmessage);
		
		if (corpTransactionLeg.getStatus().equalsIgnoreCase("failure"))
			corpTransactionLeg.setCreditStatusCode("Rejected");

		String transactiontypemessage = null;
		transactiontypemessage = getCorpTransactionStatus("transactionType"
				+ corpTransactionLeg.getEchequeNo().charAt(1));
		if (transactiontypemessage.equalsIgnoreCase("unknown"))
			transactiontypemessage = getCorpTransactionStatus("transactionTypeFT");
		corpTransactionLeg.setTransactionType(transactiontypemessage);

		String auth1Name = userDAOImpl
				.getAuthorizerName(corpTransactionLeg.getAuth1Name());
		corpTransactionLeg.setAuth1Name(auth1Name);
		logger.info("corpTransactionLeg.getAuth1Name()=="
				+ corpTransactionLeg.getAuth1Name());
		if (curAuthLevel==-1)
		{
			corpTransactionLeg.setAuth1Name("CANCELLED");
		}
		String auth2Name = userDAOImpl
				.getAuthorizerName(corpTransactionLeg.getAuth2Name());
		corpTransactionLeg.setAuth2Name(auth2Name);
		
		String makerName=userDAOImpl.getAuthorizerName(corpTransactionLeg.getMaker());
		corpTransactionLeg.setMaker(makerName);
		
		logger.debug("setEchequePropeties : end");
	return corpTransactionLeg;
	}

    
   private List modifyDisplayFlag( List echequeslist,String userName)
   {
    
       logger.info("ModifyDisplayFlag( List echequeslist,String userName) method begin" );
       for(int i=0;i<echequeslist.size();i++)
     {
       EchequeMaster   echequeMaster=(EchequeMaster) echequeslist.get(i);
         Integer systemEdited =  echequeMaster.getSystemEdited();
         Integer readValue = echequeMaster.getRead();
         
         if( systemEdited != null && readValue != null )
         {
             if ( systemEdited.intValue()==0  && readValue.intValue()==1 && echequeMaster.getMaker().equals(userName))
             echequeMaster.setDisplayFlag(new Integer("0"));
             else if (systemEdited.intValue()==0 && readValue.intValue()==0 && echequeMaster.getMaker().equals(userName))
                 echequeMaster.setDisplayFlag(new Integer("1"));
             else
                 echequeMaster.setDisplayFlag(new Integer("2"));   
                 
                 
             
         }
      logger.info("Display flag of Echeque number: " + echequeMaster.getEchequeNo() + " - "  + echequeMaster.getDisplayFlag());
     }
     
   return echequeslist;
   }
     
     
     public Transaction postTransaction(Transaction transaction){
		
    	 return transaction;
    	 
     }
     
     


   
	
	
	public void setEchequeMasterDAOImpl(EchequeMasterDAO echequeMasterDAOImpl) {
		this.echequeMasterDAOImpl = echequeMasterDAOImpl;
	}




	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}



	public void setTransactionProperties(
			ResourceBundleMessageSource transactionProperties) {
		this.transactionProperties = transactionProperties;
	}

	

	



}

