/*
 * CustomerCareBP.java
 * Created on Dec 31, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 31, 2005 MANIKANDAN - Initial Creation
// change 106 instead of 114,change 114 instead of 106  Murugan K 


package com.sbi.bp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.UserSessionCache;
import com.sbi.dao.AccountDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.IBTransactionDAO;
import com.sbi.dao.TicketMasterDAO;
import com.sbi.dao.TicketThreadsDAO;
import com.sbi.dao.TroubleLoginDAO;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Field;
import com.sbi.model.Ticket;
import com.sbi.model.TicketThread;
import com.sbi.model.TransactionLeg;
import com.sbi.model.User;
import com.sbi.model.UserProfile;
import com.sbi.service.ServiceConstant;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.MailSender;
import com.sbi.common.utils.StringUtils;

public class CustomerCareBP {
	
	private AccountDAO accountDAOImpl;
	private UserDAO userDAOImpl;
	private TroubleLoginDAO troubleLoginDAOImpl;
	private TicketMasterDAO ticketMasterDAOImpl;
	private TicketThreadsDAO ticketThreadsDAOImpl;
	private IBTransactionDAO ibTransactionDAOImpl; 
	private UserSessionCache userSessionCache;
	//private SendEmail sendEmail;
	private MailSender mailSender;
	private String fromAddress;
	private String subject;
	private String message;
	private String host;
	protected final Logger logger=Logger.getLogger(getClass());
	
	public Ticket addTicket( Ticket ticket,String emailId )
	{
		logger.info("addTicket( Ticket ticket,String emailId )" + LoggingConstants.METHODBEGIN);
		Ticket ticketObj=null;
		logger.info("addTicket( Ticket ticket,String emailId ) inparam :" + ticket + "," + emailId);
		
		if(ticket!=null){
			UserProfile userProfile = (UserProfile) userSessionCache.getData(ticket.getUserName() + ServiceConstant.USER_PROFILE);
			if(userProfile!=null)
				ticket.setName(userProfile.getName());
			String issueCode=ticket.getIssueCode();
			//Integer bankCode=(Integer)ticket.getBankCode();
			String userEmailId="";
			if(issueCode.equals(BPConstants.ISSUE_CODE_1)){
				ticket.setWorkFlowState(new Double(112));
				ticket.setAssignedTo(new Double(5308));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_2)){
				ticket.setWorkFlowState(new Double(111));
				ticket.setAssignedTo(new Double(-103));
			}else{
				ticket.setWorkFlowState(new Double(106));
				ticket.setAssignedTo(new Double(-103));
			}
			/*int accountCount=0;
			 * String issue="356";
			 * if(issue.indexOf(issueCode)!=-1)
				accountCount=accountDAOImpl.findAllAccountsCount(ticket.getUserName());
				
			if(Integer.parseInt(issueCode)>=12 && Integer.parseInt(issueCode)<=17){
				if(Integer.parseInt(issueCode) == 14)
						ticket.setWorkFlowState(new Double(106));
				else 
						ticket.setWorkFlowState(new Double(111));
				ticket.setAssignedTo(new Double(-103));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_4) || issueCode.equals(BPConstants.ISSUE_CODE_7) || issueCode.equals(BPConstants.ISSUE_CODE_11)){
				ticket.setWorkFlowState(new Double(106));
				ticket.setAssignedTo(new Double(-103));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_18)){
				ticket.setWorkFlowState(new Double(114));
				ticket.setAssignedTo(new Double(-105));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_5) || issueCode.equals(BPConstants.ISSUE_CODE_6) || issueCode.equals(BPConstants.ISSUE_CODE_8) || issueCode.equals(BPConstants.ISSUE_CODE_9)){
				ticket.setWorkFlowState(new Double(101));
				ticket.setAssignedTo(new Double(-104));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_3)){
				ticket.setParam1(ticket.getUserName());
				if(accountCount > 0){
					ticket.setWorkFlowState(new Double(106)); // change 106 instead of 114
					ticket.setAssignedTo(new Double(-103));
				}
				else{
					ticket.setWorkFlowState(new Double(114)); // change 114 instead of 106
					ticket.setAssignedTo(new Double(-105));
				}
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_1)){
				ticket.setWorkFlowState(new Double(112));
				ticket.setAssignedTo(new Double(5308));
			}
			else if(issueCode.equals(BPConstants.ISSUE_CODE_2)){
				ticket.setWorkFlowState(new Double(111));
				ticket.setAssignedTo(new Double(-103));
			}*/
				
			/*if(Integer.parseInt(issueCode)>=12 && Integer.parseInt(issueCode)<=17)
					ticket.setAssignedTo(new Double(-103));
			else if(issueCode.equals(BPConstants.ISSUE_CODE_4) || issueCode.equals(BPConstants.ISSUE_CODE_7) || issueCode.equals(BPConstants.ISSUE_CODE_11))
				ticket.setAssignedTo(new Double(-103));
			else if(issueCode.equals(BPConstants.ISSUE_CODE_18))
				ticket.setAssignedTo(new Double(-105));
			else if(issueCode.equals(BPConstants.ISSUE_CODE_5) || issueCode.equals(BPConstants.ISSUE_CODE_6) || issueCode.equals(BPConstants.ISSUE_CODE_8) || issueCode.equals(BPConstants.ISSUE_CODE_9))
				ticket.setAssignedTo(new Double(-104));
			else if(issueCode.equals(BPConstants.ISSUE_CODE_3)){
				ticket.setParam1(ticket.getUserName());
				if(accountCount>0)
					ticket.setAssignedTo(new Double(-103));
				else
					ticket.setAssignedTo(new Double(-105));
			}*/
			
			
			if(issueCode.equals(BPConstants.ISSUE_CODE_1) || issueCode.equals(BPConstants.ISSUE_CODE_2)){
				logger.info("Trouble login tickets. ");
			}else{
				
				//Added for Retail Paladion	- modified again to fix impact in TroubleLogin
				logger.info("Customer Care Ticket  - paladion validation start...");
				int validIssueCodeCount = ticketMasterDAOImpl.isValidIssueCode(ticket.getIssueCode(),ticket.getIssueNature());
				if(validIssueCodeCount<=0)
				{
					logger.info("selected issue code and issue description doesn't match");
					SBIApplicationException.throwException("EC019");//There are serious irregularities.
				}
				
				if(!StringUtils.checkMatchForRegularExpression("^[a-zA-Z0-9@\\.,_=\\-\\[\\]/\\\\?#\\s]{1,2000}$",ticket.getDescription()))
				{
					logger.info("Description entered by the user contained suspicious characters");
					SBIApplicationException.throwException("EC019");
				}
				
				if(!StringUtils.checkMatchForRegularExpression("^[a-zA-Z0-9@\\._]{5,150}$",emailId))
				{
					logger.info("Invalid Email Id - presence of unmatched characters");
					SBIApplicationException.throwException("EC019");
				}
				
				//End - Retail Paladion
				
				
				if(emailId!=null && emailId.length()>0){
					if(userProfile!=null){
						userEmailId = userProfile.getEmail();
						if(userEmailId == null || userEmailId.trim().length() == 0){
							Field fieldEmail=new Field();
							fieldEmail.setFieldName(BPConstants.EMAIL);
							fieldEmail.setType(BPConstants.SQL_VARCHAR_VALUE);
							fieldEmail.setKey(BPConstants.N);
							fieldEmail.setValue(emailId);
						
							List email=new ArrayList();
							email.add(fieldEmail);
							User user=new User();
							user.setUserAlias(ticket.getUserName());
						
							UserProfile profile=userDAOImpl.updateProfile(email,user);
							if(profile==null){
								SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
								
							}
						}
					}
				}else{
					logger.info("Hack check for email");
					SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
				}
			}
			logger.info("addTicket( Ticket ticket,String emailId ) imparam :" + ticket);
			ticketObj = ticketMasterDAOImpl.insertTicket(ticket);
				
			if(ticketObj.getTicketNo()==null){
				SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
				}
			try{
				if(emailId!=null && emailId.length()>0)
					mailSender.sendMail(fromAddress,emailId,subject,message,host);
			}catch(Exception exception){
				logger.info("Mail Not Send");
			}
			logger.info("addTicket( Ticket ticket,String emailId ) outparam :" + ticketObj);
			
		}
		logger.info("addTicket( Ticket ticket,String emailId )" + LoggingConstants.METHODEND);
		return ticketObj;
	}

	public Ticket updateTicket( Ticket ticket){
		logger.info("updateTicket( Ticket ticket )" + LoggingConstants.METHODBEGIN);
		logger.info("updateTicket( Ticket ticket ) inparam ;" + ticket);
		if(ticket!=null){
			Double workFlowState=ticket.getWorkFlowState();
			if(workFlowState.intValue()==108)
				ticket.setWorkFlowState(new Double(109));
				/*else if(workFlowState.intValue()==103)
					ticket.setWorkFlowState(new Double(104));
				else if(workFlowState.intValue()==116)
					ticket.setWorkFlowState(new Double(117));*/
				if(workFlowState.intValue()==108){ //|| workFlowState.intValue()==103 || workFlowState.intValue()==116 ){
					if(ticket.getDescription().length()<=2000){
						boolean status=ticketMasterDAOImpl.updateTicket(ticket.getTicketNo(),ticket.getWorkFlowState(),ticket.getUserName());
						if(status==false){
							SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
						}	
					}
					else{
						SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
					}
				}
				else{
					boolean status=ticketMasterDAOImpl.updateFlag(new Integer(1),ticket.getTicketNo(),ticket.getUserName());
					if(status==false){
						SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
					}
				}
				TicketThread ticketThread=createTicketThread(ticket);
				TicketThread ticketThreadObj=ticketThreadsDAOImpl.insertTicketThread(ticketThread);
				if(ticketThreadObj==null){
					SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                }
				logger.info("updateTicket( Ticket ticket) outparam :" +ticket);
		}
		logger.info("updateTicket( Ticket ticket)" + LoggingConstants.METHODEND);
		return ticket;
	}
	
	
	public Ticket closeTicket( Ticket ticket ){
		logger.info("closeTicket( Ticket ticket )" + LoggingConstants.METHODBEGIN);
		if(ticket !=null)
		{
			Double workFlowState=ticket.getWorkFlowState();
			
			if(workFlowState.intValue()==106 || workFlowState.intValue()==108 || workFlowState.intValue()==109)
				ticket.setWorkFlowState(new Double(110));
			else if(workFlowState.intValue()==101 || workFlowState.intValue()==103 || workFlowState.intValue()==104)
				ticket.setWorkFlowState(new Double(105));
			else if(workFlowState.intValue()==114 || workFlowState.intValue()==116 || workFlowState.intValue()==117)
				ticket.setWorkFlowState(new Double(118));
			
			boolean result=ticketMasterDAOImpl.updateTicket(ticket.getTicketNo(),ticket.getWorkFlowState(),ticket.getUserName());
			
			if(result==false){
				SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		else{
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return ticket;
	}
	
	public String findStatusByReferenceNumber( String referenceNumber, String userName ){
		String statusCode=null;
		TransactionLeg transactionLeg=null;
		if(referenceNumber!=null && referenceNumber.trim().length()>0 && userName!=null && userName.trim().length()>0){
			transactionLeg=ibTransactionDAOImpl.findDebit(referenceNumber,userName); // Added the username argument for paladion impact
			if(transactionLeg==null){
				SBIApplicationException.throwException(ErrorConstants.INVALID_REFRENCE_NUMBER);
			}
			
			else if(userName.equalsIgnoreCase(transactionLeg.getUserName())){
				statusCode=transactionLeg.getStatusCode();
				logger.info("Status Code :" + statusCode);
			}
			else{
				SBIApplicationException.throwException(ErrorConstants.INVALID_REFRENCE_NUMBER);
			}
		}
		else{
			SBIApplicationException.throwException(ErrorConstants.INVALID_REFRENCE_NUMBER);
		}
		return statusCode;
	}
	
	public String validateAccount(String accountNo,String branchCode,String userName,String bankCode,String emailId,String issueCode){
		logger.info("Inparams accountNo: " + accountNo + " : branch Code :" + branchCode + " : user name :" + userName + " : banck code : " + bankCode + " : issue code :" + issueCode );
		Map accountMap=troubleLoginDAOImpl.getAccountDetails(accountNo,branchCode);
		String oldUserName="";
		String dbUserName="";
		String status="";
		String accountStatus = "";
		if(accountMap == null || accountMap.size()==0)
			SBIApplicationException.throwException("TL05");//Please enter valid Account No and Branch
		if(accountMap.size()==1){
			Iterator iterator =  accountMap.values().iterator();
			String value = (String)iterator.next();
			logger.info("Account Details : " + value);
			String[] userValues = value.split("\\|\\|");
			oldUserName = userValues[0];
			dbUserName = userValues[1];
			accountStatus = userValues[2];
			if(accountStatus == null || Integer.parseInt(accountStatus)!=1)
				SBIApplicationException.throwException("TL02");//User ID does not match with the Account Number and the Branch Code supplied by you.
			if(dbUserName!=null && dbUserName.equals(userName))
				status = "Valid";
			else if (oldUserName == null || !oldUserName.equals(userName))
				SBIApplicationException.throwException("TL02");//User ID does not match with the Account Number and the Branch Code supplied by you.
				
			Map userDetails=troubleLoginDAOImpl.getUserDetails(dbUserName);
			logger.info("UserDetails : " + userDetails);
			if(userDetails!=null && userDetails.size()>0){
				Integer userStatus= new Integer(1);
				if(userDetails.get("USER_STATE")!=null)
					userStatus=new Integer(userDetails.get("USER_STATE").toString());
				int loginCount=0;
				if(userDetails.get("LOGIN_COUNT")!=null)
					loginCount=new Integer(userDetails.get("LOGIN_COUNT").toString()).intValue();
				if(userStatus.intValue() != 0)
					SBIApplicationException.throwException("TL03");//Invalid User ID
				else{
					if(loginCount > 0){
						if(status.trim().length()==0)
							status = dbUserName;
					}
				}
			}else
				SBIApplicationException.throwException("TL05");//Please enter valid Account No and Branch
		}
			
		return status;
	}
	
	/**
	 * @param accountDAOImpl The accountDAOImpl to set.
	 */
	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}

	/**
	 * @param userDAOImpl The userDAOImpl to set.
	 */
	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	/**
	 * @param ticketThreadsDAOImpl The ticketThreadsDAOImpl to set.
	 */
	public void setTicketThreadsDAOImpl(TicketThreadsDAO ticketThreadsDAOImpl) {
		this.ticketThreadsDAOImpl = ticketThreadsDAOImpl;
	}

	/**
	 * @param ibTransactionDAOImpl The ibTransactionDAOImpl to set.
	 */
	public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl) {
		this.ibTransactionDAOImpl = ibTransactionDAOImpl;
	}

	/**
	 * @param userSessionCache The userSessionCache to set.
	 */
	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}
	
	/**
	 * @param fromAddress The fromAddress to set.
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	/**
	 * @param toAddress The toAddress to set.
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @param message The message to set.
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	private TicketThread createTicketThread(Ticket ticket){
		TicketThread ticketThread=new TicketThread();
		ticketThread.setOid(ticket.getOid());
		ticketThread.setThread(ticket.getDescription());
		ticketThread.setThread_originator(ticket.getUserName());
		return ticketThread;
	}

	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public void setTroubleLoginDAOImpl(TroubleLoginDAO troubleLoginDAOImpl) {
		this.troubleLoginDAOImpl = troubleLoginDAOImpl;
	}

	public void setTicketMasterDAOImpl(TicketMasterDAO ticketMasterDAOImpl) {
		this.ticketMasterDAOImpl = ticketMasterDAOImpl;
	}
}
