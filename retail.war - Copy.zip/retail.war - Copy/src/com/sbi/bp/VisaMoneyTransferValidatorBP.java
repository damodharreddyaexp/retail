/*
 * VisaMoneyTransferValidatorBP.java
 * Created on May 14, 2007
 *
 * Copyright (c) 2007 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//May 14, 2007 Aparna Srikantan(AS26003) - Initial Creation and implementation.

package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class VisaMoneyTransferValidatorBP extends TransactionValidatorBP
{
	 private BranchMasterDAO branchMasterDAOImpl;
   protected final Logger logger = Logger.getLogger(getClass());

   private Validator validator;

   private UserDAO userDAOImpl;
   
   public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

/**
    * Call validator.validateInterBank() method Call
    * validator.validateTxnRights() method Call validator.validateTxnRights()
    * method Call validator.validateTodaysTxnLimit() method if debit and credit
    * branch codes are different { Call validator.validateTodaysTxnLimit()
    * method } if the bankSystem is NonCore { Call validator.validateTransfer()
    * method } if any one of the method throw Exception, then throw
    * SBIApplicationException else return true
    * 
    * @param transaction
    * @return boolean
    */
   public boolean validate(Transaction transaction) throws SBIApplicationException
   {

       this.transaction = transaction;
       if (transaction != null)
       {
           logger.info("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);
           
           if (logger.isDebugEnabled())
           {
               logger.debug("transaction array:" + transaction.getCredit()[0]);
           }
           
           logger.info("transaction :"+transaction.toString());
         
           TransactionLeg credit = (TransactionLeg)transaction.getCredit()[0];
           TransactionLeg debit = (TransactionLeg)transaction.getDebit();
           
           Double amount = credit.getAmount();
           logger.info("amount:"+amount);
           logger.info("credit:"+credit);
           String userName = credit.getUserName();
           logger.info("userName:"+userName);
           String strCardDetails = credit.getThirdPartyRef();
           logger.info("strCardDetails:"+strCardDetails);
           /*String[] cardDetails = strCardDetails.split("|");
           logger.info("cardDetails.length:"+cardDetails.length);*/
           String cardNumber = debit.getNarrative1();
           String payeeName = debit.getNarrative2();
           String nickName = debit.getNarrative3();
           
           String encCardNumber=debit.getDebitProductCode();
           logger.info("encCardNumber::::"+encCardNumber);
           debit.setDebitProductCode("");
           logger.info("debit.getDebitProductCode():::"+debit.getDebitProductCode());
           /*StringTokenizer st = new StringTokenizer(strCardDetails,"|");
           logger.info("token count:"+st.countTokens());
           while(st.hasMoreTokens()){
        	   
        	   cardNumber = st.nextToken();
        	   payeeName = st.nextToken();
        	   nickName = st.nextToken();
        	   
        	   
           }*/
           logger.info("in validatorbp:"+encCardNumber+":"+payeeName+":"+nickName);
           
           validator.validateUserLimit(userName,encCardNumber,payeeName,amount);
           
           //validator.validateTotalTransaction(transaction.getDebit().getAccountNo());
           
           //Changed by Devipriya
           Date visaScheduledDate = null; 
			if(transaction.isScheduled())
				visaScheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				visaScheduledDate = new Date();
			//SR72725
			validator.validateLVTLimitPerDay (transaction.getDebit().getAmount(),transaction.getDebit().getUserName(), transaction.getBankCode());
			String bankCode=transaction.getBankCode();
			if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
			
            validator.validateTodaysUserLimit(amount,transaction.getDebit().getAccountNo(),userName,visaScheduledDate);
           //End by Devipriya
           //MT007
            validator.validateInterBank(transaction.getDebit().getBranchCode(),
                   transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
           if (logger.isDebugEnabled())
           {
               logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
           }
           
           
           validator.validateAmount(transaction.getDebit().getAmount());
           if(logger.isDebugEnabled()){
           	logger.debug("validateAmount() return true");
           }
           
           if(!(transaction.getDebit().getAmount().doubleValue()==transaction.getCredit()[0].getAmount().doubleValue())){
				logger.info("Debi and credit amount is not same");
				SBIApplicationException.throwException("TAM001");
			}

           validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                   transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
           if (logger.isDebugEnabled())
           {
               logger
                       .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
           }

           /*validator.validateTxnRights(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), transaction
                   .getCredit()[BPConstants.ZERO_INT].getBranchCode(), transaction.getCredit()[BPConstants.ZERO_INT]
                   .getUserName(), new Integer(BPConstants.CREDIT_NO));
           if (logger.isDebugEnabled())
           {
               logger
                       .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for credit - true");
           }*/
           //added for retail FT/TP/VMT scheduling for CR2379 By Archana
           Date scheduledDate = null; 
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				scheduledDate = new Date();     
                     //changed for retail  FT/TP/VMT scheduling for CR2379 By Archana
      //     validator.validateTodaysTxnLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                 //  .getBranchCode(), transaction.getDebit().getAmount(),scheduledDate);
           if (logger.isDebugEnabled())
           {
               logger
                       .debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
           }
          //cr 1523 start
           if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                                                                                                 .getBranchCode())))
           {
           	
           	logger.info("username :"+transaction.getDebit().getUserName());
           	logger.info("amount :"+transaction.getDebit().getAmount());
           	logger.info("name :"+transaction.getName());
           	
           	logger.info("bankCode...FT :"+transaction.getBankCode());
           	
           	
           	if(transaction.getBankCode().trim().equalsIgnoreCase("0")){
           		logger.info("SBI part-validateTodaysInterBranchTxnLimit");
           	  //changed for retail  FT/TP/VMT scheduling for CR2379 By Archana
       //    validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getName(),transaction.getBankCode(),scheduledDate);//bank code added for CR 1734
           	
           if (logger.isDebugEnabled()){
           
               logger
                       .debug("validateTodaysInterBranchTxnLimit(String userName, Double amount,String txnName) method - true");
           }
           
           }
           	else
           	{
           		logger.info("associate part-validateInterBranchLimit");
           		  if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                   .getBranchCode())))
           		  {
           		//  validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getName(),transaction.getBankCode());//bank code added for CR 1734
                     	
           	            if (logger.isDebugEnabled()){
           	            
           	                logger
           	                        .debug("validateTodaysInterBranchTxnLimit(String userName, Double amount,String txnName) method - true");
           	            }

                   }
           
           	}
           //cr 1523 end

           }

           //above lines commented for my my use
           
         /*  if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                   .getBranchCode())))
           {
               validator.validateInterBranchLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                       .getBranchCode(), transaction.getDebit().getAmount(), transaction.getName());
               if (logger.isDebugEnabled())
               {
                   logger
                           .debug("validateInterBranchLimit(String accountNo, String branchCode, Double amount, String name) method - true");
               }

           }*/
           
           
          /* String txnPath = transaction.getPath();
           
           logger.info("txnPath :"+txnPath);
           
           String debitSubType = "";
           String creditSubType = "";
//         Passing two additional arguments (productcode and flag) for getAccountSubType() for core for CR 1256
           if(transaction.getBankCode().equalsIgnoreCase("0")){
           
           if(txnPath.equals("CC")){
           	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
           	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
           	
           }else if(txnPath.equals("CNC")){
           	
           	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
           	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
           	
           }else if(txnPath.equals("NCC")){
           	
           	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
           	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
           	
           }
           
           else if(txnPath.equals("CMC")){
       		
     		  String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
     		  logger.info("Transaction path is CMC and creditBranchType is:"+creditBranchType);
	      		  if(creditBranchType.equals("C")){
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
	      		  }
	      		  else {
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
	      		  }
     		  
           }
           
           else if(txnPath.equals("NCMC")){
           	
           	 String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
           	 logger.info("Transaction path is NCMC and creditBranchType is:"+creditBranchType);
	      		  if(creditBranchType.equals("C")){
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
	            	
	      		  }
	      		 else{
	             	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
	             	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
	             } 
           	
           }
           
           else{
           	
           	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
           	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
           	
           }
           
       }*///above lines commented for my use end of SBI loop
        
          //below lines commented for my use
           /*else // for Associate banks
           {
           	 if(txnPath.equals("CC")){
                	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
                	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
                	
                }else if(txnPath.equals("CNC")){
                	
                	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
                	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
                	
                }else if(txnPath.equals("NCC")){
                	
                	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
                	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
                	
                }else{
                	
                	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
                	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
                	
                }
           }
           
           
           
           
           logger.info("debitSubType :"+debitSubType);
           logger.info("creditSubType :"+creditSubType);
           
           validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);above lines commented for my use*/

         /*  if (transaction.getPath().equalsIgnoreCase(BPConstants.NONCORE_TO_NONCORE))
           {
               validator.validateTransfer(transaction.getDebit().getAccountNo(),
                       transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), BPConstants.PRINCIPLE);
               if (logger.isDebugEnabled())
               {
                   logger
                           .debug("validateTransfer(String debitAccountNo, String creditAccountNo, String transferType) method - true");
               }

           }*/
           
           
           //Added for New third party transfer limit validation
           
           
           
           
           
			
			
			//Added to set the Indicator for Third party Differentiation
			
			int newBeneficairyCount=0;
			newBeneficairyCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "VMT", encCardNumber, "RETAIL","00000");
			
			if(newBeneficairyCount>0){
				transaction.getDebit().setIsNewlyAddedTp("YES");
				if(transaction.isScheduled()){
					SBIApplicationException.throwException("TPB003");
				}
				else{
					validator.newBeneficiaryAdditionLimitValidation(transaction.getDebit().getUserName(), encCardNumber, "RETAIL", "VMT", transaction.getBankCode(),transaction.getDebit().getAmount(),"00000");
				}
			}
           
           //Added Newly to override all the existing validation pertaining to the Limit
           
			validator.validateCategoryALimit(userName, amount, visaScheduledDate, transaction.getBankCode());
			//Changed by Lenin for Kony
			/*if(transaction.getMobileFlag()!=null && "yes".equalsIgnoreCase(transaction.getMobileFlag())){
				logger.info("Mobile category wise validation");
						validator.validateMobileCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode());
			}*/
			//Added by Lenin for Kony
			if(transaction.getMobileFlag()!=null){
				String channel = null ;
				if("yes".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "MINB";
				}else if("mapp_inb".equalsIgnoreCase(transaction.getMobileFlag())){
					channel= "mapp_inb";
				}
				validator.validateMobileCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode(),channel);
			}
			
		//added for validating card number
			validator.validateCardNumber(transaction.getDebit().getUserName(), encCardNumber , cardNumber);
			
           logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
         

       }
       else
       { 
       	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
           }
       return true;
   }

   /**
    * Validator injection
    * 
    * @param validator
    */
   public void setValidator(Validator validator)
   {
       this.validator = validator;
   }

   public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}

}

