package com.sbi.bp;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.sbi.authentication.user.RequestResponseService;
import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.ForgotLoginPwdDAO;
import com.sbi.dao.UserDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.User;
import com.sbi.model.UserProfile;
import com.sbi.utils.EncryptMD5;
import com.sbi.utils.LogonValidator;

public class ForgotLoginPwdBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private CoreDAOImpl coreDAOImpl;
	private SMSGatewayClient smsGatewayClient;
    private LogonValidator logonValidator;
    private RequestResponseService requestResponseService;
    private UserDAO userDAOImpl;
    UserProfile userProfile;
    private ForgotLoginPwdDAO forgotLoginPwdDAOImpl;
	
    static int ssize =8; 
    static char[] chars = new char[] {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
          'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
          'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
          'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
          'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
        };
	
	public Map getCustomerDetails(Map inParam) {
		logger.info("getCustomerDetails(...) Starts Here");
		Map responseMap=null;
		List response400List = postEnquriyToCore(inParam);
		if(response400List!=null && response400List.size()>0) {
			responseMap=(Map)response400List.get(0);
		}
		return responseMap;
	}


	public List postEnquriyToCore(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postEnquriyToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

			if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
				SBIApplicationException.throwException("F1");
			}   
			logger.info("txn:::"+requestMap.get("txnno"));
			if(status!=null && status.equalsIgnoreCase("ERR.")){
				SBIApplicationException.throwException("TL10");
			}
		}
		logger.info("postEnquriyToCore(...) Ends Here");
		return responseList;
	}
	
	public String constructDDMMYYYYFormat(String date)throws Exception{
		String parseDate="";
		SimpleDateFormat sdf1=new SimpleDateFormat("ddMMyyyy");
		SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy");
		parseDate=sdf1.format(sdf2.parse(date));
		return parseDate;
	}
	
	public void sendSmsRequest(UserProfile userProfile,String bankCode,String userName,String messageTypeId,String smsParamValues[])throws UnknownHostException, IOException{
		logger.info("sendSmsRequest method Starts hrere");
		String mobileNo=userProfile.getMobileNumber();
		String countryCode=userProfile.getCountryCode();
		//logger.info("smsParamValues::::::"+smsParamValues[0]);
		SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"0",userName,mobileNo,countryCode);
		String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
		logger.info("smsRequestString"+smsRequestString);
		smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
		logger.info("sendSmsRequest method Ends hrere");	
	}
	// forgotuser name
		public void resendSmsRequest(UserProfile userProfile,String bankCode,String userName,String messageTypeId,String smsParamValues[])throws UnknownHostException, IOException{
			logger.info("resendSmsRequest method Starts hrere");
			String mobileNo=userProfile.getMobileNumber();
			String countryCode=userProfile.getCountryCode();
			SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"1",userName,mobileNo,countryCode);
			String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
			logger.info("resendsmsRequestString"+smsRequestString);
			smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
			logger.info("resendSmsRequest method Ends hrere");	
		}
		// forgotuser name
	private SMSRequestParams populateSMSRequestParams(String messageTypeId,String smsParamValues[],String bankCode,String sendOrder, String userName,String mobileNumber,String countryCode)
	{
		logger.info("SMSGateWayRequestSender populateSMSRequestParams  for Beneficiary Starts. userName" + userName );
		SMSRequestParams smsRequestParams = new SMSRequestParams();
		smsRequestParams.setMessageId(StringUtils.uniqueNumberUsingDateAndRandom("RU"));
		smsRequestParams.setMessageTypeId(messageTypeId);
		smsRequestParams.setModuleName("retail");
		smsRequestParams.setUserName(userName);
		smsRequestParams.setBankCode(bankCode);
		smsRequestParams.setMobileNo(mobileNumber);
		smsRequestParams.setCountryCode(countryCode);
		smsRequestParams.setSendOrder(sendOrder);
		List<String> listParam = new ArrayList<String>();
		if( smsParamValues != null){
			for( int i=0; i<smsParamValues.length; i++){
				listParam.add(smsParamValues[i]);
			}
		}
		smsRequestParams.setParam(listParam);
		return smsRequestParams;
		
	}
	
	public void changeLoginPassword(User user, String newPassword){    	
		if(user != null ){
			String newMD5Password = "";
			String newSHAPassword = "";
			if(!logonValidator.firstTimeLoginPassword(newPassword)){
				SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
			}
			userProfile = forgotLoginPwdDAOImpl.findUserProfile(user.getUserAlias());
			try{
				String userName = user.getUserAlias();
				newMD5Password=EncryptMD5.hashMessage(user.getUserAlias() + "#" + newPassword); //added for CR 5034
				newSHAPassword= requestResponseService.getSHA2Hashing(user.getUserAlias(),newPassword,"#");
				int passHistCount = userDAOImpl.getPrevPassHistory(user.getUserAlias(), newMD5Password,newSHAPassword);
				if (passHistCount>0){
					SBIApplicationException.throwException("SE151");
				}
				userDAOImpl.changeLoginPassword(user, "", newSHAPassword);
				userDAOImpl.insertMD5PasswordTemp(userName, newMD5Password);

			}catch(DAOException daoExp){
				SBIApplicationException.throwException(daoExp.getErrorCode());
			}	    	
		}
	}
	
	public Map getCustomerCIFDetails(String userName) {
		logger.info("getCustomerCIFDetails(...) Starts Here");
		Map responseMap = null;
		List CIFNumbersList = new ArrayList();
		if(userName!=null && userName.length()>0){
			CIFNumbersList = forgotLoginPwdDAOImpl.findUserDetails(userName.trim());
			if(CIFNumbersList!=null && CIFNumbersList.size()>0) {
				responseMap=(Map)CIFNumbersList.get(0);
			}
		}

		logger.info("getCustomerCIFDetails(...) Ends Here");
		return responseMap;
	}
	
	
	public String getRandomString(){
		Random ran = new java.util.Random();
		String randomString = "";
		for (int j = 0; j < ssize; j++){
			int r = ran.nextInt(chars.length);
			randomString += chars[r];
		}
		return randomString;
	}
public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
	this.coreDAOImpl = coreDAOImpl;
}

public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
	this.smsGatewayClient = smsGatewayClient;
}


public void setLogonValidator(LogonValidator logonValidator) {
	this.logonValidator = logonValidator;
}


public void setRequestResponseService(
		RequestResponseService requestResponseService) {
	this.requestResponseService = requestResponseService;
}


public void setUserDAOImpl(UserDAO userDAOImpl) {
	this.userDAOImpl = userDAOImpl;
}


public void setForgotLoginPwdDAOImpl(ForgotLoginPwdDAO forgotLoginPwdDAOImpl) {
	this.forgotLoginPwdDAOImpl = forgotLoginPwdDAOImpl;
}


}
