package com.sbi.bp;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;

public class QuickTransactionValidatorCheckingBP extends TransactionValidatorBP{
	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;
		
	private ReferenceDataCache referenceDataCache; 
	

	

	/**
	 * Call validator.validateInterBank() method Call validator.validateLimit()
	 * method Call validator.validateTxnRights() method Call
	 * validator.validateAccountNature() method if both credit and debit
	 * branches are different { Call validator.validateTodaysTxnLimit() method
	 * Call validator.validateInterBranchLimit() method } if bankSystem is
	 * NonCore { Call validator.validateTransfer() method }
	 * 
	 * @param transaction
	 * @return boolean
	 */
	public boolean validate(Transaction transaction)
			throws SBIApplicationException {
		this.transaction = transaction;
		if (transaction != null) {
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODBEGIN);
				logger.info("transaction :" + transaction.toString());
				   String merchantcode = transaction.getDebit().getMerchantCode();
				if("QCKNEFT".equalsIgnoreCase(merchantcode)) 
				{
					double totalAmountForNEFT=transaction.getDebit().getAmount().doubleValue()+transaction.getDebit().getRateOfInterest().doubleValue();
					validator.validateQuickTransferLimitPerDay (transaction.getDebit().getAmount(),transaction.getDebit().getUserName(), transaction.getBankCode());
					validator.validateAmount(new Double(totalAmountForNEFT));
				}
				
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount() return true");
			}
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime());			

			//Validating limit for RTGS
			String interBankIFSCCode=null;
			if (transaction.getDebit().getMerchantCode().equalsIgnoreCase("QCKNEFT") ||transaction.getDebit().getMerchantCode().equalsIgnoreCase("IMPS")) {
				
              	transaction.getDebit().setNreProductCode(validator.isNREProductCode(transaction.getDebit().getDebitProductCode()));
				
              	Map data = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
              	// String minRTGSLimit = (String) data.get("SBI_QUICK_TRANSFER_LIMIT");
 	        	double  minRTGSAmount = Double.parseDouble(((String)referenceDataCache.getReferenceData("TRANSACTION_LIMIT").get("SBI_QUICK_TRANSFER_LIMIT_"+ transaction.getBankCode())));

         //     	 double minRTGSAmount = Double.parseDouble(minRTGSLimit);
				if (transaction.getDebit().getAmount().doubleValue()>minRTGSAmount) 
					SBIApplicationException.throwException("IBFT004");
			}
			if (transaction.getDebit().getMerchantCode().equalsIgnoreCase("QCKNEFT") || transaction.getDebit().getMerchantCode().equalsIgnoreCase("IMPS")) {
				String narrative2=transaction.getCredit()[0].getNarrative2();
				logger.info("narrative 2:@@@@" +narrative2);
				if (narrative2!=null) {
					String interBankNarrative2[]=narrative2.split("\\|");
					interBankIFSCCode=interBankNarrative2[1];
				}
			}
			//Validating credit account limit
			if(!(transaction.getDebit().getAmount().doubleValue()==transaction.getCredit()[0].getAmount().doubleValue())){ 
				logger.info("Debi and credit amount is not same");
				SBIApplicationException.throwException("TAM001");
			}
			//validating the credit and debit amount same 
			String branchCode = transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(); 
			String benificiaryName = transaction.getCredit()[BPConstants.ZERO_INT].getNarrative3();
			validator.validateQuickTransferAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getNarrative1(), 
					branchCode,benificiaryName,
			          new Double(transaction.getDebit().getAmount().doubleValue()),transaction);   
			
			//Validating transactions rights for the user
			validator.validateMinorMajorTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), 8,9);
	
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
			}
	
			logger.info("interBankIFSCCode::::"+interBankIFSCCode);
			logger.info("credit Acc No::::"+ transaction.getCredit()[BPConstants.ZERO_INT].getNarrative1());
			logger.info("username::::"+transaction.getDebit().getUserName());
			
		//    validator.QuickTransferAdditionLimitValidation(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getNarrative1(), "RETAIL", "QuickTransfer",transaction.getBankCode() , transaction.getDebit().getAmount(), interBankIFSCCode);	
						
			validator.validateSubCategoryGroupALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, transaction.getBankCode(), "QuickTransfer");	
			logger.info("validateSubCategoryGroupALimit returns true");		
			
			validator.quickTransferValidateCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, transaction.getBankCode(),merchantcode);
			
			logger.info("validateCategoryALimit retruns true");
			
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODEND);
			logger.info("Inside BP%%%% "+transaction.getDebit().toString());
						
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		return true;
	}
	
	
	
	/**
	 * Validator injection
	 * 
	 * @param validator
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	
}
