/* 
 * TransactionValidatorBP.java
 * Created on Oct 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 26, 2005 Sairam.T - Initial Creation
//Nov 09,2005  Changed set methods and declare instance are private  which is realated to setter methods.
package com.sbi.bp;


import org.apache.log4j.Logger;
import com.sbi.model.Request;


public abstract class RequestValidatorBP {
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	/**
	 * Call validate method that return boolean
	 * 
	 * @param request
	 * @return boolean
	 */
	public abstract boolean validate(Request request);

}
