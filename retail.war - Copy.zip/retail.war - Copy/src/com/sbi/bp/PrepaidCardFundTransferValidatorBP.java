/*
 * PrepaidCardFundTransferValidatorBP.java
 * Created on SEP 17 2014
 *
 * Copyright (c) 2010 by SBI All Rights Reserved.
 * $Header: $
 */
//History
// SEP 17, 2014 Rajasekar S(RS00352820)- Initial Creation and implementation.

package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.bp.BPConstants;
import com.sbi.bp.TransactionValidatorBP;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class PrepaidCardFundTransferValidatorBP extends TransactionValidatorBP{
	
	protected Logger logger=Logger.getLogger(getClass());
	
	private Validator validator;

	@Override
	public boolean validate(Transaction transaction) throws SBIApplicationException
	{
		this.transaction=transaction;
		if(transaction!=null)
		{
			logger.info("Transaction validate(Transaction transaction) Method Begin ");
			logger.info("Transaction validate(Transaction transaction)"+LoggingConstants.METHODBEGIN);
			if(logger.isDebugEnabled())
			{
				logger.debug("Transaction Array"+transaction.getCredit()[0]);
			}
			logger.info("Transaction :"+transaction.toString());
			TransactionLeg credit=(TransactionLeg)transaction.getCredit()[0];
			TransactionLeg debit=(TransactionLeg)transaction.getDebit();
			debit.setDebitProductCode("");
		 	String cardType=transaction.getDebit().getCartType();
		    logger.info("Card Type--->"+cardType);
		   // String prepaidCardMinTopup=cardType+"_Card_Min_Topup";
		   // String prepaidCardMaxTopup=cardType+"_Card_Max_Topup";
		    String prepaidCardMinTopup=cardType+"_CARD_MIN_TOPUP";
		    String prepaidCardMaxTopup=cardType+"_CARD_MAX_TOPUP";
		    
		   // logger.info("Prepaid Card Type Minimum Topup Amount "+prepaidCardMinTopup);
		   // logger.info("Prepaid Card Type Maximum Topup Amount "+prepaidCardMaxTopup);
		  	validator.validateAmount(transaction.getDebit().getAmount());
		   // validator.validateMinMaxPrepaidCardLimit(transaction.getDebit().getAmount(),prepaidCardMinTopup,prepaidCardMaxTopup);
		    validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
		    validator.isPrepaidCardExist(transaction.getDebit().getUserName(), transaction.getDebit().getThirdPartyRef());
		    validator.validateCreAccPrepaidCard(transaction.getCredit()[0].getAccountNo(),transaction.getCredit()[0].getBranchCode());
		
		    Date scheduledDate = null; 
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
			 scheduledDate = new Date();     
			 String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
           	validator.validateSubCategoryGroupBLimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount()), scheduledDate, bankCode,"SmartPayoutCard");
			logger.info("validateSubCategoryGroupBLimit method - true");
			validator.validateCategoryBLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
            transaction.getName(),transaction.getBankCode(),new Date());
			logger.info("validateCategoryBLimit method returns true");
			logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
            
		}
		
		else
		{
			  SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		// TODO Auto-generated method stub
		return false;
	}

	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	
	

}
