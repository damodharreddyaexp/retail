package com.sbi.bp;

import java.util.Date;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.model.QuickTransferCustomerModel;
import com.sbi.service.ServiceConstant;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;
public class QuickTransactionValidatorBP  {  

    protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator; 
		
	protected QuickTransferCustomerModel quickTransferDetails; 

	public boolean validate(QuickTransferCustomerModel quickTransferDetails)
			throws SBIApplicationException {
	//	final  Pattern pattern; 
	//	final  Matcher matcher;
		 SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		 
		 String alphaPattern="[0-9a-zA-Z]+";
		String numericPattern = "[0-9]+";
		this.quickTransferDetails = quickTransferDetails; 
		boolean debitAccountValidateFlag =false;
		if (quickTransferDetails != null) {
			//logger.info("validate(QuickTransferCustomerModel quickTransferDetails) "+ LoggingConstants.METHODBEGIN);
			String debitAccountNo = quickTransferDetails.getDebitAccountNo(); 
			String debitBranchCode = quickTransferDetails.getDebitBranchCode();
		//	String debitBranchCode = "00036";
			String beneficiaryName = quickTransferDetails.getBeneficiaryName();
			String beneficiaryAccountNo = quickTransferDetails.getBeneficiaryAccountNo();
			String beneficiaryIfscCode = quickTransferDetails.getIfscCode(); 

			String beneficiaryCreditAmount =quickTransferDetails.getAmount();
			double amount = Double.parseDouble(beneficiaryCreditAmount);
			String beneficiaryBankName = quickTransferDetails.getBankName();

			String beneficiaryRemarks = quickTransferDetails.getRemarks(); 
			String beneficiaryTxnMode = quickTransferDetails.getTransactionMode(); 
			String userName = quickTransferDetails.getUserName();
			String bankCode = quickTransferDetails.getBankCode();
			logger.info("userName:::"+userName + "bankCode ::" + bankCode); 
			String txnName = quickTransferDetails.getTxnName();			
			Date scheduledDate = null; 
			 logger.info("EpfoTransaction.isScheduled() ::"+quickTransferDetails.isScheduled());
	         logger.info("EpfoTransaction.getScheduledDate() ::"+quickTransferDetails.getScheduledDate());
			if(quickTransferDetails.isScheduled())
				scheduledDate = new Date(quickTransferDetails.getScheduledDate().getTime());
			else
				scheduledDate = new Date();
			
			//String quickTransferLimitKey = quickTransferDetails.getQuickTransferLimitKey();
			
		//	double quickTransferAmount = Double.parseDouble(quickTransferLimitKey);

			 
			// validation for userDebitAccount start here
			debitAccountValidateFlag =  validateAccountDetails(debitAccountNo);
			logger.info("debitAccountValidateFlag::::" + debitAccountValidateFlag);	
			// validation for userDebitAccount end here
			
			// validation for BeneficiaryAccountNo start here
			if("".equals(beneficiaryAccountNo) || beneficiaryAccountNo == null)   
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAccountValidateFlag empty debitAccountValidateFlag :::" + debitAccountValidateFlag);
			}
			Pattern pattern2 = Pattern.compile(numericPattern);
			Matcher matcher2 = pattern2.matcher(beneficiaryAccountNo); 		
			if (!matcher2.matches()) { 
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
			}
			// validation for BeneficiaryAccountNo ends here
			
			// validation for Amount start here
			if("".equals(beneficiaryCreditAmount) || beneficiaryCreditAmount == null)   
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAmount debitAccountValidateFlag :::" + debitAccountValidateFlag);
			}
			if(amount>5000) 
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAmount debitAccountValidateFlag :::" + debitAccountValidateFlag);
			}
			Pattern pattern3 = Pattern.compile(numericPattern);
			Matcher matcher3 = pattern3.matcher(beneficiaryCreditAmount); 
			if (!matcher3.matches()) { 
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAmount matcher debitAccountValidateFlag :::" + debitAccountValidateFlag);
			}
			// validation for Amount ends here
			
			if("".equals(beneficiaryBankName) || beneficiaryBankName == null)  
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitBankName debitAccountValidateFlag :::" + debitAccountValidateFlag);

			}
			// validation for BeneficiaryName starts here
			if("".equals(beneficiaryName) || beneficiaryName == null)  
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAccountValidateFlag empty debitAccountValidateFlag :::" + debitAccountValidateFlag);


			}
			Pattern pattern4 = Pattern.compile(alphaPattern);
			Matcher matcher4 = pattern4.matcher(beneficiaryName); 
			if (!matcher4.matches()) { 
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitAccountValidateFlag empty debitAccountValidateFlag :::" + debitAccountValidateFlag);

			}
		// validation for BeneficiaryName ends here
			
			if("".equals(beneficiaryIfscCode) || beneficiaryIfscCode == null)  
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitIfscCode debitAccountValidateFlag :::" + debitAccountValidateFlag);


			}
			/*if("".equals(beneficiaryRemarks) )  
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitRemarks debitAccountValidateFlag :::" + debitAccountValidateFlag);


			}*/
			if("".equals(beneficiaryTxnMode) || beneficiaryTxnMode == null) 
			{
				applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				applicationResponse.setErrorCode("QUKTXN001");
				debitAccountValidateFlag =false;
				logger.info("debitTxnMode debitAccountValidateFlag :::" + debitAccountValidateFlag);


			}
		 	validator.validateAmount(amount);
			logger.info("validateAmount :::" + amount);
        	validator.validateQuickTransferLimit(userName,amount,txnName,bankCode);
			logger.info("validateQuickTransferLimit  end here" );
			
			logger.info("validateTxnRights method start here in bp class:::" );
			validator.validateTxnRights(debitAccountNo,debitBranchCode,userName, new Integer(9)); 
			logger.info("validateTxnRights method ends here in bp class:::" );

			String txnPath = quickTransferDetails.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            	String debitSubType = "";
            	String creditSubType = "";
              	//debitSubType = validator.getAccountSubType(quickTransferDetails.getDebitAccountNo());
            	//creditSubType = validator.getAccountSubType(quickTransferDetails.getBeneficiaryAccountNo()); 
            	
            
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            //validator.validateTransferTypes(debitSubType, creditSubType, "principle"); 

            logger.info("validate(Transaction transaction) "+ LoggingConstants.METHODEND);
         
         if(bankCode!=null && "0|3|A|6".contains(bankCode)){
         	bankCode="0";
         }
  //   	double debitAmount = Double.parseDouble(quickTransferDetails.getAmount());
     //	logger.info("debitAmount:::"+ amount); 
     //    validator.validateSubCategoryQuickTransfer(quickTransferDetails.getUserName(), amount, scheduledDate, bankCode, "QuickTransfer"); 
         
      //   logger.info("Validation returns true");
         
		//	validator.validateCategoryALimit(quickTransferDetails.getUserName(),  amount, scheduledDate,bankCode);			 
		
          

		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		
	
		return debitAccountValidateFlag;
	}
	   
	public boolean validateAccountDetails(String userDebitAccount) {
		boolean validateFlag =true;
		 SBIApplicationResponse applicationResponse = null;
			String numericPattern = "[0-9]+";
			Pattern pattern1 = Pattern.compile(numericPattern);
			Matcher matcher1 = pattern1.matcher(userDebitAccount); 
		
		if("".equals(userDebitAccount) || userDebitAccount == null)  
		{
			applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
			applicationResponse.setErrorCode("QUKTXN001");
			validateFlag =false;
		}
		if (!matcher1.matches()) { 
			applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
			applicationResponse.setErrorCode("QUKTXN001");
			validateFlag =false;
		}
		if((userDebitAccount.length()<11|| userDebitAccount.length()>17 ))
		{
			validateFlag= false;
			applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
			applicationResponse.setErrorCode("QUKTXN001");
		}
		return validateFlag;
	}
	
	public void setValidator(Validator validator) {
		this.validator = validator;
	}
	

}
