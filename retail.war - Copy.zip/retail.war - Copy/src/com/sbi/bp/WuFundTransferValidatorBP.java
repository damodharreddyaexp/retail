package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.dao.WuMoneyTransferDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Transaction;
import com.sbi.model.TransactionLeg;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class WuFundTransferValidatorBP extends TransactionValidatorBP {   
	private static final Logger logger = Logger.getLogger(WuFundTransferValidatorBP.class);

	private Validator validator;
	private WuMoneyTransferDAO wuMoneyTransferDAOImpl;

	public boolean validate(Transaction transaction) throws SBIApplicationException {
		logger.info("wuFundTransferValidatorBP validate " + LoggingConstants.METHODBEGIN);

		if (transaction != null){

			if (logger.isInfoEnabled()){
				logger.info("transaction Credit array:" + transaction.getCredit()[0]);
				logger.info("transaction Debit array:" + transaction.getDebit());
			}

			logger.info("transaction :"+transaction.toString());

			TransactionLeg credit = (TransactionLeg)transaction.getCredit()[0];
			TransactionLeg debit = (TransactionLeg)transaction.getDebit();

			Double amount = credit.getAmount();    
			String userName = credit.getUserName();
			String debitProductCode=debit.getDebitProductCode();

			logger.info("Credit userName ->"+userName);
			logger.info("Credit Amount ->"+amount);
			logger.info("debitProductCode ->"+debitProductCode);

			validator.validateAmount(amount);
			wuMoneyTransferDAOImpl.validateCreditAccountNo(credit.getAccountNo(), userName);


			//  validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));

			/*           Date scheduledDate = null; 
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				scheduledDate = new Date();     

			validator.validateTodaysTxnLimit(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getAmount(),scheduledDate);
			 */

			logger.info("validate(Transaction transaction) " + LoggingConstants.METHODEND);
		}
		else{ 
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return true;
	}  


	public void setValidator(Validator validator)	{
		this.validator = validator;
	}
	public void setWuMoneyTransferDAOImpl(WuMoneyTransferDAO wuMoneyTransferDAOImpl) {
		this.wuMoneyTransferDAOImpl = wuMoneyTransferDAOImpl;
	}
}