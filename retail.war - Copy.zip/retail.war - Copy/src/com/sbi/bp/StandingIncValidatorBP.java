/*
 * StandingIncValidatorBP.java
 * Created on Dec 01, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec  4 ,2005 Naveen Kumar - Initial Creation
//Changed on 28-June-2006 for Paladion by Saravanan N


package com.sbi.bp;


import org.apache.log4j.Logger;
import com.sbi.bp.BPConstants;
import com.sbi.bp.RequestValidatorBP;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Request;
import com.sbi.model.StandingInstructions;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

    
    
public class StandingIncValidatorBP extends RequestValidatorBP

{
    protected final Logger logger = Logger.getLogger(getClass());
    private RequestValidator requestValidator;
    private Validator validator;
    StandingInstructions standingInstructions;
        
       
    public boolean validate(Request request) throws SBIApplicationException 
    {
        if (request != null)
        {
            logger.info("validate(Request request) " + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled())
            {
                logger.debug("request :" + request.toString());
            }
        StandingInstructions standingInstructions = (StandingInstructions) request; 
        logger.info("standingInstructions"+standingInstructions);
         
        // Added for paladion on 28-06-06 by Saravanan N
       
        validator.validateTxnRights(standingInstructions.getAccountNo(),standingInstructions.getBranchCode(),
    	standingInstructions.getUserName(),new Integer(BPConstants.DEBIT_NO));	
        if(standingInstructions.getTransOption().equals("1") || standingInstructions.getTransOption().equals("2")){
        	if(standingInstructions.getDdTransfer().intValue() == 1){
        		try{
        			validator.validateTxnRights(standingInstructions.getCreditAccountNo(),standingInstructions.getCreditBranchCode(),
            	        	standingInstructions.getUserName(),new Integer(BPConstants.CREDIT_NO));
        		}catch(SBIApplicationException sbiexce){
        			try{
        				//BPconstant added for ThirdParty - start
						validator.validateAccountNature(standingInstructions.getCreditAccountNo(),standingInstructions.getCreditBranchCode(),
            	        	standingInstructions.getUserName(),BPConstants.THIRD_PARTY);
						// end
        			}catch(SBIApplicationException sbiexce1){
        				SBIApplicationException.throwException(ErrorConstants.INPUT_VALUE_NULL_ERROR_CODE);
        			}
        		}
        	}
        }
        
        if(standingInstructions.getTransOption().equals("3") || standingInstructions.getTransOption().equals("4")){
        	try{
        			validator.validateTxnRights(standingInstructions.getCreditAccountNo(),standingInstructions.getCreditBranchCode(),
            	        	standingInstructions.getUserName(),new Integer(BPConstants.CREDIT_NO));
        		}catch(SBIApplicationException sbiexce){
//        			//BPconstant added for ThirdParty - start
        			validator.validateAccountNature(standingInstructions.getCreditAccountNo(),standingInstructions.getCreditBranchCode(),
            	        	standingInstructions.getUserName(),BPConstants.THIRD_PARTY);
        			// end
        		}
        	
        }
        // end of Paladion
      
        
         
//validating same debit and credit account
        
        logger.info("Length of "+standingInstructions.getCreditBranchCode().length());
            if(standingInstructions.getCreditBranchCode()!= null && standingInstructions.getCreditBranchCode().length() > 0)
            {
                logger.info("Request Validator Object "+requestValidator);
                logger.info("standingInstructions.getBranchCode() "+standingInstructions.getBranchCode());
                logger.info("standingInstructions.getCreditBranchCode() "+standingInstructions.getCreditBranchCode());
                
                requestValidator.validateintraBranch(standingInstructions.getBranchCode(),standingInstructions.getCreditBranchCode());
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
            }
         
// validating dd limit
            
                logger.info("Amount is : "+standingInstructions.getAmount());
                Double amount = new Double(standingInstructions.getAmount().doubleValue());
                
                validator.validateLimit(amount, BPConstants.DEMAND_DRAFT);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
            }
         
//validating account limit  
            
           
           validator.validateTodaysTxnLimit(standingInstructions.getAccountNo(),standingInstructions.getBranchCode(),amount);
            
           if (logger.isDebugEnabled())
           {
               logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
           }

//validating Third Party User Limit
               
           validator.validateLimit(amount, BPConstants.THIRD_PARTY);
           
           if (logger.isDebugEnabled())
           {
               logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
           }

        
//validating transfer principle
           
           if(standingInstructions.getCreditAccountNo() != null &&  standingInstructions.getCreditAccountNo().length() > 0)
           {
               validator.validateTransfer(standingInstructions.getAccountNo(), standingInstructions.getCreditAccountNo(), BPConstants.PRINCIPLE);
           }
           if (logger.isDebugEnabled())
           {
               logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
           }
     
//validating start/enddate > todays date + enddate > stardate
           
           if( standingInstructions.getEndDate() != null )
           {
               requestValidator.validatedates(standingInstructions.getStartDate(), standingInstructions.getEndDate());
           }
           if (logger.isDebugEnabled())
           {
               logger.debug("validatedates(StartDate(),EndDate()) method - true");
           }
           
     
        } else
        {
        	SBIApplicationException.throwException(ErrorConstants.DATA_NULL_DESCRIPTION);
          }
        return true;
    }
     
    
//Injection for RequestValidator
    
    public void setRequestValidator(RequestValidator requestValidator)
    {
        this.requestValidator = requestValidator;
    }

//Injection for Validator
    
    
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }
    
}
    
