package com.sbi.bp;

import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import Encryption.Encrypt;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.PrepaidCardDao;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.PrepaidCardHistoryModel;
import com.sbi.utils.UtilsConstant;

public class PrepaidCardBP {
	
	private Logger logger = Logger.getLogger(getClass());
	
	private PrepaidCardDao prepaidCardDaoImpl;
	
	private ReferenceDataCache referenceDataCache;
	
	
	public boolean checkCardRegStaus(String username,String cardnumber) {
		logger.info("checkCardRegStaus Start");
		int recordCount = 0;

		recordCount=prepaidCardDaoImpl.fetchCardRegStatus(username,cardnumber);
		logger.info("checkCardRegStaus End");
		if(recordCount>0){
			return false;
		}else{	
			return true;
		}	
	}
	
	public boolean checkOnePerDay(String username,String cardType) {
		logger.info("checkOnePerDay Start");
		int recordCount = 0;
		recordCount=prepaidCardDaoImpl.fetchRegisterCards(username,cardType);
		logger.info("checkOnePerDay End");
		if(recordCount>0){
			return false;
		}else{
			return true;
		}
	}
	
	public void insertPrepaidPayoutCardDetails(String refNo, String cardnumber,
			String username, String cardStatus,String cardType,String nickName,String bankCode,String productType) {
		logger.info("insertPrepaidPayoutCardDetails Start");
		try{
			prepaidCardDaoImpl.insertPrepaidCardDetails(refNo,cardnumber,username,cardStatus,cardType,nickName,bankCode,productType);
		}catch (DAOException daoException){
        	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
		logger.info("insertPrepaidPayoutCardDetails End");
	}
	
	
	public List checkBin(String bankCode)  {
		logger.info("checkBin Start");
      //  logger.info("checkBin " +bankCode +" : cardType : "+cardType);
      	List prepaidCards=prepaidCardDaoImpl.validateCardBinRange(bankCode);
      	logger.info("checkBin End");
		return prepaidCards;
	}
	
	
	
	
	public String fetchDataFromReferenceCache(String cachRefKey)
	{
		
		Map cacheData=referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
		String cacheValue=(String)cacheData.get(cachRefKey);
		return cacheValue;
	}
	
	public String getReference(String fromFlag){
		String reference=null;
		try{
			reference = prepaidCardDaoImpl.getReferenceNo(fromFlag);
						
		}catch (DAOException daoException){
            	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
        }
		return reference;
	}
	
	public String encrypt(String data, String filePath) {
		logger.info("encrypt(String data, String filePath) method begins");
        Encrypt enc = new Encrypt(); 
        enc.setSecretkey(filePath);       
        String encData = null;
        try {
              data = URLDecoder.decode(data, "utf-8");
              encData = enc.encryptFile(data);
              if(encData == null){
            	  throw new SBIApplicationException("SE002");
              }
        } catch (Exception ex) {
        	logger.error("Exception occured while encrypting .. ",ex);
        	throw new SBIApplicationException("SE002");
        }           
        encData = encData.replaceAll("\n", "");
        encData = encData.replaceAll("\r", "");        
        logger.info("encrypt(String data, String filePath) method ends");
        return encData;		
	}
	
	public String decrypt(String encData, String filePath) {
		logger.info("decrypt(String encData, String filePath) method begins");
		Encrypt enc = new Encrypt();
		enc.setSecretkey(filePath);
        String decData = null;        
        decData = enc.decryptFile(encData);
        if(decData==null){
        	throw new SBIApplicationException("SE002");
        }
        logger.info("decrypt(String encData, String filePath) method ends");
        return decData;		
	}
	
	public String maskCardNumber(String prepaidCardNumber) {
	    final String s = prepaidCardNumber.replaceAll("\\D", "");
	    final int start = 4;
	    final int end = s.length() - 4;
	    final String overlay = StringUtils.repeat("X", end - start);
	    return StringUtils.overlay(s, overlay, start, end);
	}
	
	
	public Map constructTopUpPSGRequestString(String topupRefNo,String selectedCardNum,double debitAmount,String inbRefNo,String narration,String ip,String port){
		
		Map requestMap = new HashMap();
		requestMap.put("protocolID", "0134");
		requestMap.put("transaction_type", "S2");
		requestMap.put("txnName", "prepaidcard_topup");
		requestMap.put("reference_no", topupRefNo);
		requestMap.put("card_no",selectedCardNum );
		Double amount = debitAmount;
		if(amount == null)
			amount = new Double(0.0);
		DecimalFormat f = new DecimalFormat("00000000.00");
		String strAmount = f.format(amount);
		strAmount = strAmount.replace(".", "");
		requestMap.put("load_amt", strAmount );
		requestMap.put("narration", narration);
		requestMap.put("ib_ref_no", inbRefNo);
		requestMap.put("psgIp" ,ip);
		requestMap.put("psgPort", port);
		return requestMap;
}
	
	
	
	
public Map constructCardEnqRequestString(String topupRefNo,String selectedCardNum,String ip,String port){
	
	Map requestMap = new HashMap();
	requestMap.put("protocolID", "0064");
	requestMap.put("transaction_type", "S1");
	requestMap.put("txnName", "prepaidcard_reg");
	requestMap.put("reference_no", topupRefNo);
	requestMap.put("card_no",selectedCardNum );
	requestMap.put("psgIp" ,ip);
	requestMap.put("psgPort", port);
	return requestMap;
}
	
public Map constructPrepaidPayoutCardPSGRequestString(PrepaidCardHistoryModel prepaidCardModel) {
	Map requestMap = new HashMap();
	requestMap.put("protocolID", "0064");
	requestMap.put("transaction_type", "S1");
	requestMap.put("txnName", "prepaidcard_reg");
	String refNo=prepaidCardModel.getRefNo();
	refNo=refNo.replaceAll("\\n", "");
	refNo=refNo.replaceAll("\\r", "");
	requestMap.put("reference_no", refNo.trim());
	String cardNumber=prepaidCardModel.getCardNumber();
	cardNumber=cardNumber.replaceAll("\\n", "");
	cardNumber=cardNumber.replaceAll("\\r", "");
	requestMap.put("card_no", cardNumber.trim());		
	requestMap.put("psgIp",prepaidCardModel.getIp());
	requestMap.put("psgPort",prepaidCardModel.getPort());
	return requestMap;
}

public void deletePrepaidPayoutCardDetails(String username, String cardnumber) {
	try{
		prepaidCardDaoImpl.deregisterPrepaidCard(username,cardnumber);
	}catch (DAOException daoException){
    	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
	}
}

	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}



	public void setPrepaidCardDaoImpl(PrepaidCardDao prepaidCardDaoImpl) {
		this.prepaidCardDaoImpl = prepaidCardDaoImpl;
	}

}
