
package com.sbi.bp;

import com.sbi.dao.NitrStudentDetailsDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.Validator;
import java.io.PrintStream;
import java.util.Map;
import org.apache.log4j.Logger;

public class NitrCertValidatorBP
{

    public NitrCertValidatorBP()
    {
        nitrValidator = false;
        validateAmount = false;
        validateTxnRights = false;
    }

    public void validate(Map inParams)
        throws SBIApplicationException
    {       
        nitrValidator = validator.validateAmount(new Double(inParams.get("amountTransfer").toString().replaceAll(",", "")));
        if(nitrValidator)
            nitrValidator = validator.validateTxnRights(inParams.get("debitAccountNo").toString(), inParams.get("debitBranchCode").toString(), inParams.get("userName").toString(), new Integer(9));
        if(nitrValidator)
            nitrValidator = validator.validateTodaysTxnLimit(inParams.get("debitAccountNo").toString(), inParams.get("debitBranchCode").toString(), new Double(inParams.get("amountTransfer").toString().replaceAll(",", "")));
        if(nitrValidator)
        {
            int recCnt = nitrStudentDetailsDAOImpl.findCertNitrHackCheck(inParams.get("rollNo").toString(), inParams.get("courseName").toString(), inParams.get("feeType").toString(), inParams.get("studentName").toString());
            if(recCnt == 0)
            {
                nitrValidator = false;                
                if(!nitrValidator)
                    SBIApplicationException.throwException("V025");
            }
        }
    }

    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }

    public void setNitrStudentDetailsDAOImpl(NitrStudentDetailsDAO nitrStudentDetailsDAOImpl)
    {
        this.nitrStudentDetailsDAOImpl = nitrStudentDetailsDAOImpl;
    }

    private Validator validator;
    protected final Logger logger = Logger.getLogger(getClass());
    private NitrStudentDetailsDAO nitrStudentDetailsDAOImpl;
    boolean nitrValidator;
    boolean validateAmount;
    boolean validateTxnRights;
}
