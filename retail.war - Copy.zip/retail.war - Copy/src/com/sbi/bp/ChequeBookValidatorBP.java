/*
 * ChequeBookValidatorBP.java
 * Created on Nov 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 28, 2005 Sairam.T - Initial Creation
package com.sbi.bp;

import org.apache.log4j.Logger;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.ChequeDetails;
import com.sbi.model.Request;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

public class ChequeBookValidatorBP extends RequestValidatorBP {
	private Validator validator;

	private RequestValidator requestValidator;

	protected final Logger logger = Logger.getLogger(getClass());

	ChequeDetails chequeDetails;

	/**
	 * requestValidator.validateNoOfChequeLeaves method Call to Validate the NoOfChequeLeaves.
	 * validator.validateTxnRights() method Call validator.validateTxnRights()
	 * method Call validator.validateTodaysTxnLimit() method if debit and credit
	 * branch codes are different { Call validator.validateTodaysTxnLimit()
	 * method } if the bankSystem is NonCore { Call validator.validateTransfer()
	 * method } if any one of the method throw Exception, then throw
	 * SBIApplicationException else return true
	 * 
	 * @param request
	 * @return boolean
	 */
	public boolean validate(Request request) throws SBIApplicationException {
		logger
				.info("validate(Request request) "
						+ LoggingConstants.METHODBEGIN);

		ChequeDetails chequeDetails = (ChequeDetails) request;
		String productType = request.getProductType();
		Integer chequeLeaves = chequeDetails.getNoOfLeaves();

		if (chequeDetails != null) {
			if (logger.isDebugEnabled()) {
				logger.debug("request :" + request.toString());
			}
			//	Validating NoOfChequeLeaves       	
			logger.info("product Type " + productType);
			logger.info("chequeLeaves  " + chequeLeaves);
			logger.info("address :"+chequeDetails.getAddress());
			//requestValidator.validateNoOfChequeLeaves(productType,chequeLeaves); //commented for CR 2836

			if (logger.isDebugEnabled()) {
				logger
						.debug("validateNoOfChequeLeaves(String productType, Integer chequeLeaves) method - true");
			}
			/**CR:5533 MCC 09/12/2010 START */
			if(chequeDetails.getMultiCity() !=null 
					&& chequeDetails.getMultiCity().equals("0") && chequeDetails.getBankCode().equals("0")){
				//cr 5728 start
				String type="RETAIL_CHEQUE_THRESHOLD_LIMIT_"+chequeDetails.getBankCode();
				if("A1".equals(productType)) {
					type="RETAIL_CHEQUE_THRESHOLD_LIMIT_SB_"+chequeDetails.getBankCode();
				}
				if("A2".equals(productType) || "A4".equals(productType)) {
					type="RETAIL_CHEQUE_THRESHOLD_LIMIT_CA_OD_"+chequeDetails.getBankCode();
				}
				logger.info("type of threshold limit"+ type );
				//validator.validateLimit(chequeDetails.getThresholdLimit(),"RETAIL_CHEQUE_THRESHOLD_LIMIT_"+chequeDetails.getBankCode(),chequeDetails.getBankCode());
				validator.validateLimit(chequeDetails.getThresholdLimit(),type,chequeDetails.getBankCode());
				//cr 5728 end
			}/**CR:5533 MCC 09/12/2010 END */
			
			
			//  Validating accessLevel        
			validator.validateTxnRights(chequeDetails.getAccountNo(),
					chequeDetails.getBranchCode(),
					chequeDetails.getUserName(), new Integer(
							BPConstants.DEBIT_NO));

			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTxnRights(String accountNo, String branchCode,String userName,Integer accessLevel) method - true");
			}
			
			//Added for LCPC
			//If the second digit of the selected debit account's product code is '1', then that account is not entitled to get a cheque book
			//Commented as per Core request
			/*validator.validateProductCodeForChequeBookRequest(chequeDetails.getAccountNo(),
					chequeDetails.getBranchCode(),
					chequeDetails.getUserName());
			if(logger.isDebugEnabled())
				logger.debug("validateProductCodeForChequeBookRequest(String accNo,String branchCode,String userName) method - returns true");
			*/
			//Validate the max. no of cheque leaves allowed
			validator.validateNoOfChequeLeaves(new Integer("100"), chequeDetails.getNoOfLeaves());
			if(logger.isDebugEnabled())
				logger.debug("validateNoOfChequeLeaves(Integer maxLeavesAllowed, Integer noOfLeaves) method - returns true");
			
			//End - LCPC
			
		} else {
			 SBIApplicationException.throwException(ErrorConstants.DATA_NULL_DESCRIPTION);
			
		}

		logger.info("validate(Request request) " + LoggingConstants.METHODEND);

		return true;
	}

	/**
	 * TODO Validator object injection done here
	 * 
	 * @param validator
	 *            
	 */

	public void setValidator(Validator validator) {
		this.validator = validator;

	}

	/**

	 * TODO RequestValidator object injection done here
	 * 
	 * @param requestValidator
	 *            
	 */

	public void setRequestValidator(RequestValidator requestValidator) {
		this.requestValidator = requestValidator;
	}
}
