package com.sbi.bp;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.common.utils.CommissionUtils;
import com.sbi.dao.NpsDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Account;
import com.sbi.model.NPSPaymentDetails;
import com.sbi.service.ServiceConstant;
import com.sbi.service.ServiceErrorConstants;
/**
 * This BP class contains business logics that are used in the Payment flow of NPS module.
 * 
 * @author Manoj Kumar Mariappan
 */
public class NPSPaymentBP {
	
	private static Logger LOGGER = Logger.getLogger(NPSPaymentBP.class);
	private NpsDAO npsDAOImpl;
	private AccountInformationBP accountInformationBP;
	private ReferenceDataCache referenceDataCache;
	
	private CommissionUtils commissionUtils;

	/**
	 * This method is used to retrieve the PRAN and Account details that are mapped to the user.
	 * These details will be displayed in the NPS Payment initial page.
	 * 
	 * @param userName
	 * @return
	 */
	public Map getNpsPaymentInitialValues(String userName){
		LOGGER.info("getNpsPaymentInitialValues(String userName) - begins");
		
		Map outputParams = new HashMap();
	
		//First there should be some PRAN details need to be added for the logged in user. So here first 
		//we are checking that any PRAN number and nick name details are available for this user 
		List nickNameList = npsDAOImpl.getNickNameByUsername(userName);
		if(nickNameList != null && nickNameList.size()>0){
			LOGGER.info("Nick Name List - "+nickNameList);
			outputParams.put("nickNameList", nickNameList);
			
			//Once there is some PRAN details added, the debit account details are retrieved
			List debitAccountList = accountInformationBP.getTransactionAccounts(userName, ServiceConstant.DEBIT_ACCOUNT);
			LOGGER.info("account list - "+debitAccountList+"  size - "+debitAccountList.size());
			if(debitAccountList != null && debitAccountList.size()>0){
				LOGGER.info("Total accounts mapped for this user - "+debitAccountList.size());
				Iterator accIterator = debitAccountList.iterator();
				while(accIterator.hasNext()){
					Account account = (Account) accIterator.next();
					if(!account.getBankSystem().equalsIgnoreCase("Core")){
						accIterator.remove();
					}
				}
				outputParams.put(ServiceConstant.DEBIT_ACCOUNT, debitAccountList);
				
				//Then the minimum limit, commission and service tax details for NPS are added
				//These details are available in the SBI_NAME_VALUE_MASTER table and it is 
				//loaded in the referenceDataCache by the application.
				Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
				if(data != null){
					String tier1CommissionAmt = (String) data.get("NPS_TIER1_COMMISSION_AMOUNT");
					String tier2CommissionAmt = (String) data.get("NPS_TIER2_COMMISSION_AMOUNT");
					String tier1TaxAmount = (String) data.get("NPS_TIER1_TAX_AMOUNT");
					String tier2TaxAmount = (String) data.get("NPS_TIER2_TAX_AMOUNT");
					String tier1MinAmount = (String) data.get("NPS_TIER1_MIN_AMOUNT");
					String tier2MinAmount = (String) data.get("NPS_TIER2_MIN_AMOUNT");
					outputParams.put("tier1MinLimit", tier1MinAmount);
					outputParams.put("tier2MinLimit", tier2MinAmount);
					outputParams.put("tier1Comm", tier1CommissionAmt);
					outputParams.put("tier2Comm", tier2CommissionAmt);
					outputParams.put("tier1Tax", tier1TaxAmount);
					outputParams.put("tier2Tax", tier2TaxAmount);
				}
			}
			else {
				LOGGER.error("No transaction accounts mapped for this user");
				SBIApplicationException.throwException(ServiceErrorConstants.SE067);
            }
		}
		else{
			LOGGER.error("No PRAN details added for this user.");
			SBIApplicationException.throwException("NPS003");
		}
		LOGGER.info("getNpsPaymentInitialValues(String userName) - ends");
		return outputParams;
	}
	
	/**
	 * This method is to construct the NPSPaymentDetails object from the input values. This object values  
	 * will be inserted into NPS_PAYMENT_DETAILS table once the transaction is done successfully. 
	 * 
	 * @param inParams
	 * @return
	 */
	public NPSPaymentDetails constructNPSPaymentObject(Map inParams){
		LOGGER.info("INSIDE ##### NPSPaymentBP ##### constructNPSPaymentObject(Map inParams) - begins");
		double commission = 0;
		double tax = 0;
		String tierValue = inParams.get("tierValue").toString();
		Double tier1Amount = Double.valueOf("0");
		Double tier2Amount = Double.valueOf("0");
		String userBankCode=(String)inParams.get("bankCode");
		NPSPaymentDetails npsPaymentDetails = new NPSPaymentDetails();
		
		if("1".equalsIgnoreCase(tierValue) || "both".equalsIgnoreCase(tierValue)){
			commission = Double.parseDouble(inParams.get("tier1Comm").toString());
			tax = Double.parseDouble(inParams.get("tier1Tax").toString());
			tier1Amount = new Double(Double.parseDouble(inParams.get("tier1Amount").toString()) - (commission + tax));
			npsPaymentDetails.setTier1TaxAmount(tax);
			npsPaymentDetails.setTier1Commission(commission);
		}
		if("2".equalsIgnoreCase(tierValue) || "both".equalsIgnoreCase(tierValue)){
			commission = Double.parseDouble(inParams.get("tier2Comm").toString());
			tax = Double.parseDouble(inParams.get("tier2Tax").toString());
			tier2Amount = new Double(Double.parseDouble(inParams.get("tier2Amount").toString()) - (commission + tax));
			npsPaymentDetails.setTier2TaxAmount(tax);
			npsPaymentDetails.setTier2Commission(commission);
		}
		
		long npsSequenceNo = npsDAOImpl.getNPSRefNoSequence();
		npsPaymentDetails.setNpsRefNo(getNPSRefNum(userBankCode) + npsSequenceNo);
		npsPaymentDetails.setBranchCode(inParams.get("branchCode").toString());
		npsPaymentDetails.setPranNo(inParams.get("pranNo").toString());
		npsPaymentDetails.setTier1Amount(tier1Amount);
		npsPaymentDetails.setTier2Amount(tier2Amount);
		npsPaymentDetails.setTaxAmount(new Double(inParams.get("totalServiceTax").toString()));
		npsPaymentDetails.setCommissionAmount(new Double(inParams.get("totalCommission").toString()));
		npsPaymentDetails.setUserName(inParams.get("userName").toString());
		npsPaymentDetails.setTotalAmount(new Double(inParams.get("totalAmount").toString()));
		LOGGER.info("NPS Payment Details values  - "+npsPaymentDetails.toString());
		LOGGER.info("constructNPSPaymentObject(Map inParams) - ends");
		return npsPaymentDetails;
	}
	
	/**
	 * This method will construct a map with required parameters for NPS Transaction.
	 * 
	 * @param npsPaymentDetails
	 * @param params
	 * @return
	 */
	public Map getNPSTransactionParams(NPSPaymentDetails npsPaymentDetails, Map params){
		LOGGER.info("getNPSTransactionParams(NPSPaymentDetails npsPaymentDetails, Map params) - begins");
		
		LOGGER.info("Inparam to contruct transaction params - "+npsPaymentDetails.toString());
		LOGGER.info("Inparam to contruct transaction params - "+params);
		
		Map data = referenceDataCache.getReferenceData("TRANSACTION_LIMIT");
		String bankCode=(String)params.get("bankCode");
		LOGGER.info("BANKCODE INSIDE getNPSTransactionParams -@@@BANKCODE "+bankCode);
		String npsAccountNumber =""; 
		String npsBranchCode = "";
		if(bankCode!=null && (("0").equalsIgnoreCase(bankCode)||("A").equalsIgnoreCase(bankCode)
			||("3").equalsIgnoreCase(bankCode)||("6").equalsIgnoreCase(bankCode))){
			bankCode="0";
		}
		if((bankCode!=null && ("0").equalsIgnoreCase(bankCode))){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE");
		}
		else if(("1").equalsIgnoreCase(bankCode)){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER_1");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE_1");
		}
		else if(("2").equalsIgnoreCase(bankCode)){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER_2");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE_2");
		}
		else if(("4").equalsIgnoreCase(bankCode)){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER_4");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE_4");
		}
		else if(("5").equalsIgnoreCase(bankCode)){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER_5");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE_5");
		}
		else if(("7").equalsIgnoreCase(bankCode)){
			npsAccountNumber=(String) data.get("NPS_ACCOUNT_NUMBER_7");
			npsBranchCode=(String) data.get("NPS_BRANCH_CODE_7");
		}
		LOGGER.info("npsAccountNumber INSIDE getNPSTransactionParams -@@@npsAccountNumber "+npsAccountNumber);
		LOGGER.info("npsBranchCode INSIDE getNPSTransactionParams -@@@npsBranchCode "+npsBranchCode);
		Map transactionParams = new HashMap();
		
		double debitAmount = npsPaymentDetails.getCommissionAmount().doubleValue() + 
				npsPaymentDetails.getTaxAmount().doubleValue() + npsPaymentDetails.getTier1Amount().doubleValue() +
				npsPaymentDetails.getTier2Amount().doubleValue();
		transactionParams.put("bankCode", params.get("bankCode"));
		transactionParams.put(ServiceConstant.USER_NAME, npsPaymentDetails.getUserName());
		transactionParams.put(DEBIT_ACCOUNT_NO,  params.get("debitAccountNo"));
		transactionParams.put(DEBIT_ACCOUNT_TYPE, params.get("debitAccountType"));
		transactionParams.put(DEBIT_BRANCH_CODE, npsPaymentDetails.getBranchCode());
		transactionParams.put(DEBIT_AMOUNT,  ""+debitAmount);
		transactionParams.put(AMOUNT_TRANSFER, ""+debitAmount);
		transactionParams.put(TRANSACTION_NAME, "NPS");
		transactionParams.put("npsRefNum", npsPaymentDetails.getNpsRefNo());
		transactionParams.put(TRANSACTION_REMARKS, NPS_TXN_REMARKS);
		transactionParams.put("merchantCode", "NPS");
		
		transactionParams.put(CREDIT_ACCOUNT_TYPE, "");
		transactionParams.put(CREDIT_ACCOUNT_NO, npsAccountNumber);
		transactionParams.put(CREDIT_BRANCH_CODE, npsBranchCode);
		transactionParams.put(CREDIT_AMOUNT_TRANSFER, ""+debitAmount);
		transactionParams.put(CREDIT_TXN_COUNT, "1");
		transactionParams.put("mobileFlag",params.get("mobileFlag"));
		transactionParams.put("npsPaymentDetails", npsPaymentDetails);
		LOGGER.info("Transaction params - "+transactionParams);
		LOGGER.info("getNPSTransactionParams(NPSPaymentDetails npsPaymentDetails, Map params) - ends");
		return transactionParams;
	}
	
	/**
	 * This method is used to insert the PRAN details into SBI_NPS_MASTER table.   
	 * 
	 * @param inParams
	 * @return
	 */
	public int insertNpsDetails(Map inParams){
		LOGGER.info("insertNpsDetails(Map inParams) - begins");
		int insertStatus = 0;
		String userName=(String)inParams.get("userName");
		String nickName=(String)inParams.get("nickName");
		String pranNumber=(String)inParams.get("pranNumber");
		String confirmpranNo=(String)inParams.get("confirmpranNo");
		String phoneNumber=(String)inParams.get("phoneNumber");
		String sector=(String)inParams.get("sector");
		
		nickName = nickName.trim();
		pranNumber = pranNumber.trim();
		sector = sector.trim();
		
		if(!isValidSubscriberName(nickName)){
			LOGGER.error("Subscriber name information is not valid.");
			SBIApplicationException.throwException("NPS012");
		}
		
		if(!isValidPranNo(pranNumber) || !confirmpranNo.equals(pranNumber)){
			LOGGER.error("PRAN Number information is not valid.");
			SBIApplicationException.throwException("NPS011");
		}
		
		if(!isValidSector(sector)){
			LOGGER.error("Sector information is not valid.");
			SBIApplicationException.throwException("NPS013");
		}
		
		NPSPaymentDetails npsModel=new NPSPaymentDetails();
		npsModel.setUserName(userName);
		npsModel.setNickName(nickName);
		npsModel.setPranNo(pranNumber);
		npsModel.setPhoneNo(phoneNumber);
		npsModel.setSector(sector);
		
		insertStatus = npsDAOImpl.insertNPSDetails(npsModel);
		LOGGER.info("insertNpsDetails(Map inParams) - ends");
		return insertStatus;
	}
	
	/**
	 * This method is for server side validation of PRAN Number data
	 * 
	 * @param pranNo
	 * @return
	 */
	public boolean isValidPranNo(String pranNo){
		if(pranNo == null || pranNo.trim().equals("")){
			return false;
		}
		pranNo = pranNo.trim();
		if(pranNo.length()!=12){
			return false;
		}
		if(!pranNo.matches("^\\d+$")){
			return false;
		}
		return true;
	}

	/**
	 * This method is for server side validation of Subscriber Name data
	 * 
	 * @param subscriberName
	 * @return
	 */
	public boolean isValidSubscriberName(String subscriberName){
		if(subscriberName == null || subscriberName.trim().equals("")){
			return false;
		}
		if(!subscriberName.matches("^[a-z A-Z]+$")){
			return false;
		}
		return true;
	}
	
	/**
	 * This method is for Server side validation of Sector information
	 * 
	 * @param sector
	 * @return
	 */
	public boolean isValidSector(String sector){
		if(sector == null || sector.trim().equals("")){
			return false;
		}
		if(!sector.equals("Organized") && !sector.equals("Unorganized")){
			return false;
		}
		return true;
	}
	
	/**
	 * This method is for Server side validation of Tier Type information
	 * 
	 * @param tierType
	 * @return
	 */
	public boolean isValidTierType(String tierType){
		if(tierType == null || tierType.trim().equals("")){
			return false;
		}
		if(!"1".equals(tierType) && !"2".equals(tierType) && !"both".equals(tierType)){
			return false;
		}
		return true;
	}
	
	public boolean isValidDebitAccountDetails(Map inputValues){
		LOGGER.info("isValidDebitAccountDetails(Map inputValues, List availableAccountInfo) - begins");
    	boolean result = false;
    	String debitAccNo = (String)inputValues.get("debitAccountNo");
    	String debitBranchCode = (String)inputValues.get("debitBranchCode");
    	String debitAccType = (String)inputValues.get("debitAccountType");
    	String userName = (String)inputValues.get("userName");
    	LOGGER.info("debitAccNo:::"+debitAccNo+"  debitBranchCode:::"
    			+debitBranchCode+"  debitAccType:::"+debitAccType+"  userName:::"+userName);
    	
    	List debitAccountList = accountInformationBP.getTransactionAccounts(userName, ServiceConstant.DEBIT_ACCOUNT);
    	
    	if(debitAccNo == null || debitAccNo.trim().length() <= 0 || 
    			debitBranchCode == null || debitBranchCode.trim().length() <= 0 || 
    			debitAccType == null || debitAccType.trim().length() <= 0){
    		LOGGER.error("Debit Account Information is not valid.");
    		return result;
    	}
    	Iterator iterator = debitAccountList.listIterator();
    	while(iterator.hasNext()){
    		Account acc = (Account)iterator.next();
    		if(debitAccNo.equals(acc.getAccountNo()) && debitBranchCode.equals(acc.getBranchCode())
    				&& debitAccType.equals(acc.getProductType())){
    			result = true;
    		}
    	}
    	LOGGER.info("Is Valid Debit Acc - "+result);
    	LOGGER.info("isValidDebitAccountDetails(Map inputValues, List availableAccountInfo) - ends");
    	return result;
    }


	/**
	 * This method is used to retrieve the PRAN details of the given userName and nickName
	 * from SBI_NPS_MASTER table.
	 * 
	 * @param inParams
	 * @return
	 */
	public Map retrieveNpsDetails(Map inParams, Map outParams){
		LOGGER.info("retrieveNpsDetails(Map inParams, Map outParams) - begins");
		
		String userName=(String)inParams.get("userName");
		String nickName=(String)inParams.get("nickName");
		
		LOGGER.info("userName : "+userName);
		LOGGER.info("nickName : "+nickName);
		
		List nickNameList = new ArrayList(); 
		nickNameList = npsDAOImpl.getNickNameByUsername(userName);
		
		if(nickNameList != null && nickNameList.size() > 0){
			if(nickName!=null && nickName!=""){
				List pranDetails= new ArrayList();
				pranDetails=npsDAOImpl.getPranDetailsByUserName(nickName,userName);
				if(pranDetails == null || pranDetails.size() <= 0){
					LOGGER.error("Subscriber name information is not valid.");
					SBIApplicationException.throwException("NPS012");
				}
				LOGGER.info("pranDetails: "+pranDetails);
				outParams.put("pranDetails", pranDetails);
			}
			outParams.put("nickNameList", nickNameList);
		}
		else{
			LOGGER.info("No Data Found");
			SBIApplicationException.throwException("NPS001");
		}
	
		LOGGER.info("retrieveNpsDetails(Map inParams, Map outParams) - ends");
		return outParams;
	}
	
	/**
	 * This method will do all Server side validation on whether all the details given for contribution
	 * are valid
	 * 
	 * @param inputParams
	 * @return
	 */
	public boolean isValidPaymentDetails(Map inputParams){
		String pranNo = inputParams.get("pranNo").toString();
		String nickName = inputParams.get("nickName").toString();
		String tierValue = inputParams.get("tierValue").toString();
		String userName = inputParams.get("userName").toString();
		
		if(!isValidPranNo(pranNo)){
			LOGGER.error("PRAN Number information is not valid.");
			SBIApplicationException.throwException("NPS011");
		}
		
		if(!isValidSubscriberName(nickName)){
			LOGGER.error("Subscriber name information is not valid.");
			SBIApplicationException.throwException("NPS012");
		}
		
		if(!isValidTierType(tierValue)){
			LOGGER.error("Tier information is not valid.");
			SBIApplicationException.throwException("NPS014");
		}
		
		List pranDetails = npsDAOImpl.getPranDetailsByUserName(nickName, userName);
		NPSPaymentDetails npsDetails = (NPSPaymentDetails) pranDetails.get(0);
		if(npsDetails!=null){
			if(npsDetails.getPranNo().equals(pranNo)){
				if(npsDetails.getSector().equalsIgnoreCase("Organized")){
					if(!tierValue.equals("2")){
						LOGGER.error("Tier information is not valid.");
						SBIApplicationException.throwException("NPS014");
					}
				}
			}
			else{
				LOGGER.error("PRAN Number information is not valid.");
				SBIApplicationException.throwException("NPS011");
			}
		}
		else{
			LOGGER.error("Tier information is not valid.");
			SBIApplicationException.throwException("NPS014");
		}
		
		if(!isValidDebitAccountDetails(inputParams)){
			LOGGER.error("Debit account information is not valid.");
			SBIApplicationException.throwException("NPS015");
		}
		
		return true;
	}
	
	/**
	 * This method is to update the existing details in the SBI_NPS_MASTER table with the given details. 
	 * 
	 * @param inParams
	 * @return
	 */
	public void updateNpsDetails(Map inParams){
		LOGGER.info("updateNpsDetails(Map inParams) - begins");

		String userName=(String)inParams.get("userName");
		String nickName=(String)inParams.get("nickName");
		String pranNumber=(String)inParams.get("pranNumber");
		String confirmPran=(String)inParams.get("confirmPran");
		String phoneNo=(String)inParams.get("phoneNo");
		String sector=(String)inParams.get("sector");
		
		nickName = nickName.trim();
		pranNumber = pranNumber.trim();
		sector = sector.trim();
		
		if(!isValidPranNo(pranNumber)){
			LOGGER.error("PRAN Number information is not valid.");
			SBIApplicationException.throwException("NPS011");
		}
		
		if(!isValidSubscriberName(nickName) || !confirmPran.equals(pranNumber)){
			LOGGER.error("Subscriber name information is not valid.");
			SBIApplicationException.throwException("NPS012");
		}
		
		if(!isValidSector(sector)){
			LOGGER.error("Sector information is not valid.");
			SBIApplicationException.throwException("NPS013");
		}
		
		NPSPaymentDetails npsDetails = new NPSPaymentDetails();
		npsDetails.setNickName(nickName);
		npsDetails.setPhoneNo(phoneNo);
		npsDetails.setUserName(userName);
		npsDetails.setPranNo(pranNumber);
		npsDetails.setSector(sector);
		
		int updatedCount =npsDAOImpl.updateNpsDetails(npsDetails);
	
		if(updatedCount == 0){
			SBIApplicationException.throwException("SE002");
		}
	
		LOGGER.info("updateNpsDetails(Map inParams) - ends");
	
	}
	
	public void deleteNpsDetails(Map inParams){
		LOGGER.info("deleteNpsDetails(Map inParams) - begins");
		String userName = inParams.get("userName").toString();
		String nickName = inParams.get("nickName").toString();
		int updatedCount =npsDAOImpl.deleteNpsDetails(nickName, userName);
		if(updatedCount == 0){
			SBIApplicationException.throwException("SE002");
		}
		LOGGER.info("deleteNpsDetails(Map inParams) - ends");
	}
	
	/**
	 * This method is to calculate the commission charges for the contribution amount.
	 * Commission amount is 0.25 % of Contribution amount with the minimum Rs. 25 and 
	 * maximum of Rs. 25000
	 *   
	 * @param amount
	 * @return
	 */
	public double calculateCommissionCharges(double amount,String bankCode){
/*		double tmpAmount = (amount * COMMISSION_CHARGES_PERCENTAGE)/100;
		tmpAmount = roundOffPaiseforNPS(tmpAmount);
		System.out.println("Commission thru my api - "+ ((tmpAmount < MINIMUM_COMMISSION_AMOUNT) ? MINIMUM_COMMISSION_AMOUNT : 
			(tmpAmount > MAXIMUM_COMMISSION_AMOUNT) ? MAXIMUM_COMMISSION_AMOUNT : tmpAmount));
		//return roundOffPaiseforNPS(((amount * COMMISSION_CHARGES_PERCENTAGE)/100));
*/		LOGGER.info("bankCode  calculateCommissionCharges$$$$$$ bankCode"+bankCode);	
		return roundOffPaiseforNPS(commissionUtils.getPercentageCommissionForRetail(bankCode, new Double(amount), "NPS_COMM", "", ""));
	}
	
	/**
	 * This method is to calculate the service tax amount for the contribution amount.
	 * Service tax will be 12.36 % of Commission amount.
	 * 
	 * @param amount
	 * @return
	 */
	public double calculateServiceTax(double amount,String bankCode){
		//return roundOffPaiseforNPS(((amount * SERVICE_TAX_PERCENTAGE)/100));
		/*System.out.println("Service tax thru my api - "+roundOffPaiseforNPS(((amount * SERVICE_TAX_PERCENTAGE)/100)));
		*/
		LOGGER.info("bankCode  calculateServiceTax $$$$$ bankCode"+bankCode);	
		return roundOffPaiseforNPS(commissionUtils.getPercentageCommissionForRetail(bankCode, new Double(amount), "NPS_STAX", "", ""));
	}
	
	/**
	 * This method is round-off the paise part of amount value into next higher level value.
	 * Eg. Amount - 1.61
	 * Next 5  paise round-off - 1.65
	 * Next 10 paise round-off - 1.70
	 * Next 25 paise round-off - 1.75
	 * 
	 * @param amount
	 * @param nextRoundOffPaise
	 * @return
	 */
	public double roundOffPaise(double amount, double nextRoundOffPaise){
		LOGGER.info("roundOffPaise(double amount, double nextRoundOffPaise) - begins");
		BigDecimal commAmount = new BigDecimal(new DecimalFormat("#0.00").format(amount));//(amount);
		BigDecimal roundedComAmount=commAmount.setScale(0 ,BigDecimal.ROUND_FLOOR);
		double paise = new Double(commAmount.toString().substring(commAmount.toString().indexOf("."),commAmount.toString().length())).doubleValue();
		double finalAmount = roundedComAmount.doubleValue() + (Math.ceil(paise /nextRoundOffPaise) * nextRoundOffPaise) ;
		LOGGER.info("roundOffPaise(double amount, double nextRoundOffPaise) - ends");
		return finalAmount;
	}
	
	/**
	 * This method is for round-off the paise value as per the NPS requirement
	 * 0.00 to 0.49 ==> 0.00
	 * 0.50 to 0.99 ==> 1.00
	 * 
	 * @param amount
	 * @return
	 */
	private double roundOffPaiseforNPS(double amount){
		LOGGER.info("roundOffPaiseforNPS(double amount) - begins");
		BigDecimal commAmount = new BigDecimal(new DecimalFormat("#0.00").format(amount));
		BigDecimal roundedComAmount = commAmount.setScale(0 ,BigDecimal.ROUND_FLOOR);
		double paise = new Double(commAmount.toString().substring(commAmount.toString().indexOf("."), commAmount.toString().indexOf(".") + 3)).doubleValue();
		LOGGER.info("roundOffPaiseforNPS(double amount) - ends");
		if(paise >= .5)
			return roundedComAmount.doubleValue() + 1;
		else
			return roundedComAmount.doubleValue();
	}
	
	public ReferenceDataCache getReferenceDataCache() {
		return referenceDataCache;
	}

	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}

	public NpsDAO getNpsDAOImpl() {
		return npsDAOImpl;
	}

	public void setNpsDAOImpl(NpsDAO npsDAOImpl) {
		this.npsDAOImpl = npsDAOImpl;
	}
	
	public AccountInformationBP getAccountInformationBP() {
		return accountInformationBP;
	}

	public void setAccountInformationBP(AccountInformationBP accountInformationBP) {
		this.accountInformationBP = accountInformationBP;
	}
	
	public CommissionUtils getCommissionUtils() {
		return commissionUtils;
	}

	public void setCommissionUtils(CommissionUtils commissionUtils) {
		this.commissionUtils = commissionUtils;
	}
	
	
	/*
	 The NPS_REF_NUM value is hard coded as per URD.
	 12 - Denotes NPS contribution
	 6048770 - POP-SP registration number of SBI Mumbai Main Branch
	 6270865 - for SBT  
     6038900 - for SBH  
     6043715 - for SBP  
     6180904 - for SBBJ 
     6005462 - for SBM 

	 */
	//private static final String NPS_REF_NUM = "126005462"; //Commented for CR-DEV 360 Anil
	private String getNPSRefNum(String bankCode) {
		LOGGER.info("getNPSRefNum(String bankCode) - begins");
		String nps_ref_num="";
		       switch (Integer.parseInt(bankCode)) {

		       //Changed for CR-DEV 360 Anil
		       	case 0:  nps_ref_num = "126048770"; break;
                case 1:  nps_ref_num = "126180904"; break;
                case 2:  nps_ref_num = "126038900"; break;
                
                case 4:  nps_ref_num = "126005462"; break; 
                
                case 5:  nps_ref_num = "126043715"; break;
                case 7:  nps_ref_num = "126270865"; break;
                
	        }
		       LOGGER.info("getNPSRefNum(String bankCode)value of bankCode  "+bankCode+"value of POP SP(nps_ref_num) "+nps_ref_num);
		       LOGGER.info("getNPSRefNum(String bankCode) - ends");    
			return nps_ref_num;
			
	}
	private static final String CREDIT_ACCOUNT_NO = "creditAccountNo";
	private static final String DEBIT_ACCOUNT_NO = "debitAccountNo";
	private static final String CREDIT_BRANCH_CODE = "creditBranchCode";
	private static final String DEBIT_BRANCH_CODE = "debitBranchCode";
	private static final String DEBIT_AMOUNT = "debitAmount";
	private static final String AMOUNT_TRANSFER = "amountTransfer";
	private static final String CREDIT_TXN_COUNT = "creditTxnCount";
	private static final String TRANSACTION_NAME = "transactionName";
	private static final String DEBIT_ACCOUNT_TYPE = "debitAccountType";
	private static final String CREDIT_ACCOUNT_TYPE = "creditAccountType";
	private static final String TRANSACTION_REMARKS = "transactionRemarks";
	private static final String CREDIT_AMOUNT_TRANSFER = "creditAmountTransfer";
	private static final String NPS_TXN_REMARKS = "NPS Contribution";
	
	private static double SERVICE_TAX_PERCENTAGE = 12.36;
	private static double COMMISSION_CHARGES_PERCENTAGE = 0.25;
	private static double MINIMUM_COMMISSION_AMOUNT = 20; 
	private static double MAXIMUM_COMMISSION_AMOUNT = 25000; 
}
