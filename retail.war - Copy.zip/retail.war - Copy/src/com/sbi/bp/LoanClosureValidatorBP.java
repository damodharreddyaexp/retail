package com.sbi.bp;

import org.apache.log4j.Logger;

import com.sbi.exception.SBIApplicationException;
import com.sbi.model.LoanClosure;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.Validator;

public class LoanClosureValidatorBP {
	
	private Validator validator;	
	
	private RequestValidator requestValidator;
	
	protected final Logger logger = Logger.getLogger(getClass());

	public boolean validate(LoanClosure loanClosure) throws SBIApplicationException {

		logger.info("validate(LoanClosure loanClosure)" + LoggingConstants.METHODBEGIN);
		logger.info("loanClosure :" + loanClosure);

		if (loanClosure != null) {

			requestValidator.validateintraBranch(loanClosure.getDebitBranchCode(), loanClosure.getLoanBranchCode());
			
			logger.info("validateintraBranch return true");
			
			validator.validateAmount(loanClosure.getAmount());
	        if(logger.isDebugEnabled()){
	        	logger.debug("validateAmount() return true");
	        }
	        
	        validator.validateTransfer(loanClosure.getDebitAccountNo(),loanClosure.getLoanAccountNo(),BPConstants.INTEREST);
			if (logger.isDebugEnabled()) {
				logger
					.debug("validateTransfer(String debitAccountNo, String creditAccountNo, String transferType) method - true");
			}
	        
			validator.validateTxnRights(loanClosure.getLoanAccountNo(), loanClosure.getLoanBranchCode(), loanClosure.getUserName(), new Integer(5));
			
			logger.info("validateTxnRights for credit return true");
			
			validator.validateTxnRights(loanClosure.getDebitAccountNo(), loanClosure.getDebitBranchCode(), loanClosure.getUserName(), new Integer(9));
			
			logger.info("validateTxnRights for debit return true");			
			
		}

		return false;
	}
	
	public void setValidator(Validator validator) {
		this.validator = validator;
	}

	public void setRequestValidator(RequestValidator requestValidator) {
		this.requestValidator = requestValidator;
	}

}
