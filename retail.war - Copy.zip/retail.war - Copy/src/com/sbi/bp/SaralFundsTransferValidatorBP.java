/*
 * FundTransferValidatorBP.java
 * Created on Nov 8, 2005
 *  
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
//Changed on 30-June-2006 for Paladion by Saravanan N (Changed the order of validation)
package com.sbi.bp;

import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.CorpTransaction;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.Validator;

public class SaralFundsTransferValidatorBP extends TransactionValidatorBP
{
	 private BranchMasterDAO branchMasterDAOImpl;
    protected final Logger logger = Logger.getLogger(getClass());

    private Validator validator;

    /**
     * Call validator.validateInterBank() method Call
     * validator.validateTxnRights() method Call validator.validateTxnRights()
     * method Call validator.validateTodaysTxnLimit() method if debit and credit
     * branch codes are different { Call validator.validateTodaysTxnLimit()
     * method } if the bankSystem is NonCore { Call validator.validateTransfer()
     * method } if any one of the method throw Exception, then throw
     * SBIApplicationException else return true
     * 
     * @param transaction
     * @return boolean
     */
    public boolean validate(Transaction txn) throws SBIApplicationException
    {

    	this.transaction = txn;
        if (transaction != null)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("validate(Transaction transaction) " + LoggingConstants.METHODBEGIN);
                logger.debug("transaction :" + transaction.toString());
            }
            
            CorpTransaction transaction = (CorpTransaction)txn;
            
           /* validator.validateInterBank(transaction.getDebit().getBranchCode(),
                    transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
            if (logger.isDebugEnabled())
            {
                logger.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
            }*/
            
            
            validator.validateAmount(transaction.getDebit().getAmount());
            if(logger.isDebugEnabled()){
            	logger.debug("validateAmount() return true");
            }
            


            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),
                    transaction.getDebit().getUserName(), new Integer(BPConstants.DEBIT_NO));
            if (logger.isDebugEnabled())
            {
                logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
            }

            
            
            
            validator.validateTxnRights(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), transaction
                    .getCredit()[BPConstants.ZERO_INT].getBranchCode(), transaction.getCredit()[BPConstants.ZERO_INT]
                    .getUserName(), new Integer(BPConstants.CREDIT_NO));
            if (logger.isDebugEnabled())
            {
                logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for credit - true");
            }

			Date scheduledDate = null; 
			 logger.info("transaction.isScheduled() ::"+transaction.isScheduled());
	         logger.info("transaction.getScheduledDate() ::"+transaction.getScheduledDate());
			if(transaction.isScheduled())
				scheduledDate = new Date(transaction.getScheduledDate().getTime());
			else
				scheduledDate = new Date();     


            if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                                                                                                  .getBranchCode())))
            {
            	
            	logger.info("username :"+transaction.getDebit().getUserName());
            	logger.info("amount :"+transaction.getDebit().getAmount());
            	logger.info("name :"+transaction.getName());
            	logger.info("bankCode...FT :"+transaction.getBankCode());
            	if(logger.isDebugEnabled())
            	logger.debug("bankCode...FT :"+transaction.getBankCode());
            	//SARAL Limit Change
            	validator.validateCategoryILimitForSaral(transaction.getDebit().getUserName(), transaction.getDebit().getAmount(), scheduledDate, transaction.getBankCode(),"SARAL");
            	logger.info("validateCategoryILimit (String userName,Double amount,scheduled");
            	//validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getName(),transaction.getBankCode(),scheduledDate);//bank code added for CR 1734,schedule date added for CR2379
                if (logger.isDebugEnabled()){
                
                //    logger.debug("validateTodaysInterBranchTxnLimit(String userName, Double amount,String txnName) method - true");
                	logger.debug("validateCategoryGLimit (String userName,Double amount,scheduled");
                }
            //cr 1523 end

            }else{
//          changed for Retail FT/TP schedule payment CR2379 by Archana 
            //Commented for CR-5023
          /*  validator.validateTodaysTxnLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                    .getBranchCode(), transaction.getDebit().getAmount(),scheduledDate);*/
            //CR-5023 start
            //Commented for SARAL Limit Change
            //validator.validateIntraBranchLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
              //      .getBranchCode(), transaction.getDebit().getAmount(),scheduledDate);
            	
            	
            	validator.validateCategoryGLimitForSaral(transaction.getDebit().getUserName(), transaction.getDebit().getAmount(), scheduledDate, transaction.getBankCode(),"SARAL");
            logger.info("validateCategoryGLimit returns True");
            	
            }
            //CR-5023 end
            if (logger.isDebugEnabled())
            {
                logger.debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
            }

          /*  if (!(transaction.getDebit().getBranchCode().equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
                    .getBranchCode())))
            {
                validator.validateInterBranchLimit(transaction.getDebit().getAccountNo(), transaction.getDebit()
                        .getBranchCode(), transaction.getDebit().getAmount(), transaction.getName());
                if (logger.isDebugEnabled())
                {
                    logger
                            .debug("validateInterBranchLimit(String accountNo, String branchCode, Double amount, String name) method - true");
                }

            }*/
            
            
            String txnPath = transaction.getPath();
            if(logger.isDebugEnabled())
            logger.debug("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
//          Passing two additional arguments (productcode and flag) for getAccountSubType() for core for CR 1256
            if(transaction.getBankCode().equalsIgnoreCase("0")){
            
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
            	
            }
            
            else if(txnPath.equals("CMC")){
        		
      		  String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
      		  logger.info("Transaction path is CMC and creditBranchType is:"+creditBranchType);
	      		  if(creditBranchType.equals("C")){
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
	      		  }
	      		  else {
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
	      		  }
      		  
            }
            
            else if(txnPath.equals("NCMC")){
            	
            	 String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
            	 logger.info("Transaction path is NCMC and creditBranchType is:"+creditBranchType);
	      		  if(creditBranchType.equals("C")){
	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
	            	
	      		  }
	      		 else{
	             	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
	             	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
	             } 
            	
            }
            
            else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            
        }//end of SBI loop
         
            else // for Associate banks
            {
            	 if(txnPath.equals("CC")){
                 	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
                 	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
                 	
                 }else if(txnPath.equals("CNC")){
                 	
                 	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
                 	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
                 	
                 }else if(txnPath.equals("NCC")){
                 	
                 	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
                 	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
                 	
                 }else{
                 	
                 	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
                 	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
                 	
                 }
            }
            
            
            
            
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);

          /*  if (transaction.getPath().equalsIgnoreCase(BPConstants.NONCORE_TO_NONCORE))
            {
                validator.validateTransfer(transaction.getDebit().getAccountNo(),
                        transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), BPConstants.PRINCIPLE);
                if (logger.isDebugEnabled())
                {
                    logger
                            .debug("validateTransfer(String debitAccountNo, String creditAccountNo, String transferType) method - true");
                }

            }*/

            if(logger.isDebugEnabled())
            logger.debug("validate(Transaction transaction) " + LoggingConstants.METHODEND);
          

        }
        else
        { 
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return true;
    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }

    public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}

}
