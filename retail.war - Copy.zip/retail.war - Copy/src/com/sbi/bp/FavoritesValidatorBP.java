/*
 * FavoritesValidatorBP.java
 * Created on Dec 13, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 13, 2005 MURUGAN K - Initial Creation
package com.sbi.bp;

import java.util.List;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.dao.FavoritesDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Favorite;
import com.sbi.utils.LoggingConstants;

public class FavoritesValidatorBP {

    protected final Logger logger = Logger.getLogger(getClass());

    private FavoritesDAO favoritesDAOImpl;

    /**
     * TODO This method call This method validate get the favorite list from [favoritesDAOImpl.findFavorites(userName)],
     * if  size of returned list is greater or equal to 10, throw the own SBIApplicationException otherwise
     * return true.
     * @throws DAOException
     * @throws SBIApplicationException boolean
     */

    public  boolean validate(Favorite favorite) throws DAOException, SBIApplicationException {
        logger.debug(" validate(Favorite favorite)  method begin");
        String userName = favorite.getUserName();
        String nickname = favorite.getNickName();

        boolean flag = true;
        
            List favoriteList = favoritesDAOImpl.findFavorites(userName);

            if ( favoriteList.size() < 10 ) {
                logger.info("Size of favoriteList: "+favoriteList.size());
                flag =  true;
                       
                }
            else {

                SBIApplicationException.throwException(ErrorConstants.FAVORITES_LIMIT_VALID);
                }
       
           for (int i = 0; i < favoriteList.size(); i++) {
                Favorite retriveObj = (Favorite) favoriteList.get(i);
                String retriveNickName = retriveObj.getNickName();
                  if (retriveNickName.trim().equalsIgnoreCase(nickname.trim()))
                  {   

                      SBIApplicationException.throwException(ErrorConstants.FAVORITES_DUPLICATE);
                      }
                  else
                  {
                     flag = true;
                  }
               }
            
           logger.info("Validation for Favorite : " + flag );
           logger.debug(" validate(Favorite favorite)  method end");
           return flag;
    }
              
                  

           
              
                
              
    
    
    
    
    
    
 
   
   

    /**
     * TODO This method validate get the favorite list from [favoritesDAOImpl.findFavorites(userName)],
     * if  size of returned list is greater or equal to 10, throw the own SBIApplicationException otherwise
     * return true.
     * @param userName
     * @return boolean
     */

    public void setFavoritesDAOImpl(FavoritesDAO favoritesDAOImpl) {
        this.favoritesDAOImpl = favoritesDAOImpl;
    }
    

}
