package com.sbi.bp;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;

public class ResendLoginPwdBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private CoreDAOImpl coreDAOImpl;
	private SMSGatewayClient smsGatewayClient;
   
	
    static int ssize =8; 
    static char[] chars = new char[] {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
          'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
          'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
          'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
          'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
        };
    
    
	public Map getCustomerDetails(Map inParam) {
		logger.info("getCustomerDetails(...) Starts Here");
		Map responseMap=null;
		List response400List = postEnquriyToCore(inParam);
		if(response400List!=null && response400List.size()>0) {
			responseMap=(Map)response400List.get(0);
		}
		return responseMap;
	}
	public List postEnquriyToCore(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postEnquriyToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

			if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
				SBIApplicationException.throwException("F1");
			}   
			logger.info("txn:::"+requestMap.get("txnno"));
			if(status!=null && status.equalsIgnoreCase("ERR.")){
				SBIApplicationException.throwException("TL10");
			}
		}
		logger.info("postEnquriyToCore(...) Ends Here");
		return responseList;
	}
	
	
	
	public void sendSmsRequest(String userName,String mobileNo,String countryCode,String bankCode,String messageTypeId,String smsParamValues[])throws UnknownHostException, IOException{
		logger.info("sendSmsRequest method Starts hrere");
		//logger.info("smsParamValues::::::"+smsParamValues[0]);
		SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"0",userName,mobileNo,countryCode);
		String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
		logger.info("smsRequestString"+smsRequestString);
		smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
		logger.info("sendSmsRequest method Ends hrere");	
	}
	
	private SMSRequestParams populateSMSRequestParams(String messageTypeId,String smsParamValues[],String bankCode,String sendOrder, String userName,String mobileNumber,String countryCode)
	{
		logger.info("SMSGateWayRequestSender populateSMSRequestParams  for Beneficiary Starts. userName" + userName );
		SMSRequestParams smsRequestParams = new SMSRequestParams();
		smsRequestParams.setMessageId(StringUtils.uniqueNumberUsingDateAndRandom("RU"));
		smsRequestParams.setMessageTypeId(messageTypeId);
		smsRequestParams.setModuleName("retail");
		smsRequestParams.setUserName(userName);
		smsRequestParams.setBankCode(bankCode);
		smsRequestParams.setMobileNo(mobileNumber);
		smsRequestParams.setCountryCode(countryCode);
		smsRequestParams.setSendOrder(sendOrder);
		List<String> listParam = new ArrayList<String>();
		if( smsParamValues != null){
			for( int i=0; i<smsParamValues.length; i++){
				listParam.add(smsParamValues[i]);
			}
		}
		smsRequestParams.setParam(listParam);
		return smsRequestParams;
		
	}
	
	public String getRandomString(){
		Random ran = new java.util.Random();
		String randomString = "";
		for (int j = 0; j < ssize; j++){
			int r = ran.nextInt(chars.length);
			randomString += chars[r];
		}
		return randomString;
	}
public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
	this.coreDAOImpl = coreDAOImpl;
}

public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
	this.smsGatewayClient = smsGatewayClient;
}

}
