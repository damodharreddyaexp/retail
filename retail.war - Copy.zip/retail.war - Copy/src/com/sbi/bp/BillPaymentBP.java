/**
 * @(#) BillPaymentBP.java
 */

package com.sbi.bp;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.BillDAO;
import com.sbi.dao.BillPaymentHistoryDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.PaymentScheduleDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.Bill;
import com.sbi.model.BillDetails;
import com.sbi.model.BillPaymentHistory;
import com.sbi.model.BillPaymentSchedule;
import com.sbi.model.SPOutput;
import com.sbi.model.Transaction;
import com.sbi.service.ServiceConstant;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.StringUtils;

public class BillPaymentBP
{
    
    protected final Logger logger = Logger.getLogger(getClass());

    private BillDAO billDAOImpl;

    private PaymentScheduleDAO paymentScheduleDAOImpl;

    private BillPaymentHistoryDAO billPaymentHistoryDAOImpl;

    private FundsTransferBP fundsTransferBP;

    private HackCheckBP hackCheckBP;

    private BillDetails billDetails = null;

    public Map payWithBill(Map inputParams)
    {

        logger.info("payWithBill(Map inputParams) " + LoggingConstants.METHODBEGIN);
        logger.info("inputParams :" + inputParams);

        
        Map response = new HashMap(); 

        if (inputParams != null)
        {
            
            Integer accessLevel = new Integer(9);
            
            String billerId = (String) inputParams.get("billerId");
            String billNo = (String) inputParams.get("billNo");
            String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
            String accountNo = (String) inputParams.get("debitAccountNo");
            String branchCode = (String) inputParams.get("debitBranchCode");
            String allowYes = (String)inputParams.get("dtAllowYes");
            
            String allowNo = (String)inputParams.get("dtAllowNo");
            Date allowDate =null;
            if( allowYes != null && !allowYes.trim().equalsIgnoreCase("")){
                allowDate =coreDateToTimestamp(allowYes);
            }
            else if( allowNo != null && !allowNo.trim().equalsIgnoreCase(""))
            {
                allowDate =coreDateToTimestamp(allowNo);
            }   
             
            logger.info("allowDate :"+allowDate);
            
            if(branchCode == null)
                branchCode = "";

            
            Double amount = new Double((String) inputParams.get("amount"));
            String billerShortName = (String)inputParams.get("nickName");
            if(billerShortName == null)
                billerShortName = "";

            String remarks = (String)inputParams.get("remarks");
            if(remarks == null)
                remarks = "";
            
            
            BillPaymentSchedule billPaymentSchedule = new BillPaymentSchedule();
                Bill bill = new Bill();
                bill.setBillAmount(amount);
                bill.setBillerID(billerId);
                bill.setBillNo(billNo);
            
            billPaymentSchedule.setAmount(amount);
            billPaymentSchedule.setBill(bill);
            billPaymentSchedule.setBillerShortname(billerShortName);
            billPaymentSchedule.setDebitAccountNo(accountNo);
            billPaymentSchedule.setDebitBranchCode(branchCode);
            billPaymentSchedule.setRemarks(remarks);
            billPaymentSchedule.setUserName(userName);

            
            hackCheckBP.validatePayWithBills(billPaymentSchedule,accessLevel,(String)inputParams.get("debitProductCode"));

            BillPaymentHistory billPaymentHistory = billPaymentHistoryDAOImpl.findBillPaymentHistory(billNo, billerId, userName);
            //logger.info("outside billPayment Hostory" );
            if (billPaymentHistory == null)
            {
                
                Timestamp scheduledDate = StringUtils.coreDateToTimestamp((String) inputParams.get("scheduleDate"));                
                    if( logger.isDebugEnabled()){
                      logger.debug("scheduledDate :"+scheduledDate);
                      logger.debug("allowDate :"+allowDate);
                    }
                
                Date dt = new Date();
                    if( logger.isDebugEnabled())
                    logger.info("Date Comparison Result===:" + scheduledDate.compareTo(dt));
                if (scheduledDate.compareTo(dt) > 0)
                {
                    if(logger.isDebugEnabled())
                        logger.debug("scheduledDate.compareTo(dt) :"+scheduledDate.compareTo(dt));
                    response.put("insertPaymentSchedule",new Boolean(true));
                    if(scheduledDate.compareTo(allowDate) <= 0){
                        if(logger.isDebugEnabled())
                            logger.debug("scheduledDate.compareTo(allowDate) <= 0 :"+scheduledDate.compareTo(allowDate));
                        SPOutput result = billDAOImpl.insertBillSchedule(billPaymentSchedule, scheduledDate );
                        if(logger.isDebugEnabled())
                          logger.debug("insertResult :" + result);
                        response.put("spOutput",result);
                    }else{
                        logger.info("Scheduled date is greater than lastPaymentDate");
                        SBIApplicationException.throwException(ErrorConstants.SCH_DATE_GREATER_THAN_ALLOW_DATE);
                                              
                    }
                    
                }
                else
                {
                    Transaction transaction = fundsTransferBP.transferFunds(inputParams);
                    if(logger.isDebugEnabled())
                    logger.debug("transaction :" +transaction);
                    
                    response.put("transaction",transaction);
                    response.put("insertPaymentSchedule",new Boolean(false));
                    logger.info("status code"+transaction.getDebit().getStatusCode());
                    
                    if(transaction.getDebit().getStatusCode().equalsIgnoreCase("00") || transaction.getDebit().getStatusCode().equalsIgnoreCase("O.K.") || transaction.getDebit().getStatusCode().equalsIgnoreCase("08") || transaction.getDebit().getStatusCode().equalsIgnoreCase("F1")){//check
                        logger.info("procedure call.....");
                        SPOutput spOutput = paymentScheduleDAOImpl.updateBillStatus(billPaymentSchedule);
                        response.put("spOutput",spOutput);
                    }
                 
                }
            }
            else
            {
                logger.info("bill payment history found (bill already paid)");
                SBIApplicationException.throwException(ErrorConstants.BILL_ALREADY_PAID);
              
            }
        }
        else
        {
        	 SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
        
        return response;
    }

    /**
     * If cancelled successfully if bill in sbi_bp_bill_master
     * 
     * "update sbi_bp_bill_master set scheduled=1 where
     * bill_number='"+strBillNo+"' and biller_id='"+strBillerID+"'
     * 
     * "Payment scheduled for the biller is successfully cancelled. This bill
     * will appear back in the View/Pay Bills option for you to schedule payment
     * again. "
     * 
     * If bill is schduled call deletescheduledpayment Payment scheduled for the
     * biller is successfully cancelled.
     */

    public String cancelScheduled(String billerID, String billNo, Long oid,String userName)
    {
        
        logger.info("cancelScheduled( ) " + LoggingConstants.METHODBEGIN);
        logger.info("userName inside cancelScheduled ::"+userName);
        String status = null;
        
        billDetails = billDAOImpl.findBill(billerID, billNo); 
        
        logger.info("**********billDetails :"+billDetails);

        if (billDetails != null)
        { 
           // boolean result = billDAOImpl.updateBillScheduled(billNo, billerID, new Integer(1));
            SPOutput spOutput = billDAOImpl.updateBPPaymentSchedule(billNo,billerID,oid,userName);   //paladion fix         
            
            logger.info("spOutput : " + spOutput);
            if(spOutput != null)
                status = "Status Uptated";
            else
                status = "Unable to cancel schedule";
        }
        else
        {
            boolean deleted = paymentScheduleDAOImpl.deleteScheduledPayment(billerID,billNo,oid,userName); //paladion
            logger.info("Result " + deleted);
            if(deleted) {						//paladion
                status = "Status Deleted";
            }   
           /* else
                status = "Unable to Delete";*/
        }
        return status;
    }

    
    private Timestamp coreDateToTimestamp(String coreDateString) {
        Timestamp timestamp = null;
        SimpleDateFormat simpleDateFormat=null;
        try {

            if (coreDateString != null) {
                logger.info("Date:" + coreDateString.length());
                
                    logger.info("Date:" + coreDateString.length());
                    simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    logger.info("Date:" + simpleDateFormat);
               
                   Date sqlToday = new java.sql.Date(simpleDateFormat.parse(coreDateString).getTime());
                   timestamp = new Timestamp(sqlToday.getTime());
                return timestamp;
            }
           
            
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        return timestamp;

    }
    
    /**
     * If no bills found then check for the mapping in sbi_bp_user_biller_map if
     * record not found in user_biller_map then display You must add a biller
     * before you can view bills. if found Display the details
     */
    /*
     * public void viewBills(String userName,String billerID ) { try {
     * logger.info("cancelScheduled( ) " + LoggingConstants.METHODBEGIN);
     * 
     * billerBillMapList = billDAOImpl.findBills(userName); if(billerBillMapList
     * ==null) { userBillerMap=userBillerMapDAOImpl.findUserBiller(userName); } }
     * catch (DAOException e) { logger.info("BillPayment.CancelSchedule method
     * throws Exception :" + e.toString()); SBIApplicationException exception =
     * new SBIApplicationException(e.getMessage()); throw exception; } }
     */

    public void setBillDAOImpl(BillDAO billDAOImpl)
    {
        this.billDAOImpl = billDAOImpl;
    }

    public BillDAO getBillDAOImpl()
    {
        return billDAOImpl;
    }

    public void setBillPaymentHistoryDAOImpl(BillPaymentHistoryDAO billPaymentHistoryDAOImpl)
    {
        this.billPaymentHistoryDAOImpl = billPaymentHistoryDAOImpl;
    }

    public void setPaymentScheduleDAOImpl(PaymentScheduleDAO paymentScheduleDAOImpl)
    {
        this.paymentScheduleDAOImpl = paymentScheduleDAOImpl;
    }


    public void setFundsTransferBP(FundsTransferBP fundsTransferBP)
    {
        this.fundsTransferBP = fundsTransferBP;
    }

    public void setHackCheckBP(HackCheckBP hackCheckBP)
    {
        this.hackCheckBP = hackCheckBP;
    } 

} 
