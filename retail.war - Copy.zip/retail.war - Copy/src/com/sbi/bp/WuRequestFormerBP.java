package com.sbi.bp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.CoreDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.WuConstants;
import com.sbi.utils.WuRequestFormer;
import com.sbi.utils.WuRequestFormerFactory;

/**
 * This class is used to frame xml request to send it to external system.
 */
@SuppressWarnings(value="unchecked")
public class WuRequestFormerBP {
	private final Logger logger = Logger.getLogger(getClass());

	private WuRequestFormerFactory wuRequestFormerFactory;
	private CoreDAO coreDAOImpl;

	/**
	 * @param input
	 * @return Steps: 1. Get 'typeOfRequest' variable from input map. 2. call getRequestFormer()
	 * method of wuRequestFormerFactory to get appropriate request former by passing this
	 * variable. 3. return the framed xml output.
	 */
	public String formRequest(Map input) throws Exception {
		logger.info("formRequest - " + LoggingConstants.METHODBEGIN);
		WuRequestFormer wuRequestFormer = wuRequestFormerFactory.getRequestFormer((String)input.get(WuConstants.WU_REQUEST_TYPE));
		String reqXML = wuRequestFormer.formRequest(input);
		logger.info("formRequest - " + LoggingConstants.METHODEND);
		return reqXML;
	}

	public Map getCustomerDetails(Map inParam) throws SBIApplicationException,Exception {
		logger.info("getCustomerDetails - " + LoggingConstants.METHODBEGIN);
		logger.info("debitAccountNo : " + (String) inParam.get("debitAccountNo"));
		Map responseMap = null;
		try { 
			Map requestMap = new HashMap();
			requestMap.put("account_no", (String)inParam.get("debitAccountNo"));
			requestMap.put("fetch_indicator", "A");
			requestMap.put("bankCode", (String)inParam.get("bankCode"));
			requestMap.put("txnno", "060450");

			List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);

			logger.info("responseList : " + responseList);
			responseMap = (Map)responseList.get(0);

			if (((String) responseMap.get("status")) != null) {
				if ("F1".equalsIgnoreCase((String) responseMap.get("status")) || "F2".equalsIgnoreCase((String) responseMap.get("status"))) {
					SBIApplicationException.throwException("WUT014");
				}else if("ERR.".equalsIgnoreCase((String) responseMap.get("status"))){
					SBIApplicationException.throwException("WUT002");
				}
			}
			logger.info("responseMap : " + responseMap);
		} catch (SBIApplicationException exception) {			
			logger.info("inside SBIApplicationException ..."+exception.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, exception);			
			SBIApplicationException.throwException(exception.getErrorCode());

		} catch (Exception exception) {
			logger.error(LoggingConstants.EXCEPTION, exception);
			SBIApplicationException.throwException("WUT011", exception);
		}
		logger.info("getCustomerDetails - " + LoggingConstants.METHODEND);
		return responseMap;
	}

	public void setWuRequestFormerFactory(WuRequestFormerFactory wuRequestFormerFactory) {
		this.wuRequestFormerFactory = wuRequestFormerFactory;
	}

	public void setCoreDAOImpl(CoreDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}


}
