/* 
 * ThirdPartyValidatorBP.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
//Changed on 30-June-2006 for Paladion by Saravanan N
package com.sbi.bp;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import wac.logger.WACExceptionHandler;

import com.sbi.cache.ReferenceDataCache;
import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UserDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.CorpTransaction;
import com.sbi.model.Transaction;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;

public class SaralThirdPartyValidatorBP extends TransactionValidatorBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private Validator validator;
	
	private BranchMasterDAO branchMasterDAOImpl;
	
	 private UserDAO userDAOImpl;
	 
	 private ReferenceDataCache referenceDataCache;//Saral SubLimit Change

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	/**
	 * Call validator.validateInterBank() method Call validator.validateLimit()
	 * method Call validator.validateTxnRights() method Call
	 * validator.validateAccountNature() method if both credit and debit
	 * branches are different { Call validator.validateTodaysTxnLimit() method
	 * Call validator.validateInterBranchLimit() method } if bankSystem is
	 * NonCore { Call validator.validateTransfer() method }
	 * 
	 * @param transaction
	 * @return boolean
	 */
	public boolean validate(Transaction txn)
			throws SBIApplicationException {
		
		  logger.info("SaralThirdPartyValidatorBP validate method");
		  
		
		
		this.transaction = txn;
		
		if(null==txn.getDebit().getBranchCode()){
			logger.info("debit branch code from txn is null");
		}
		
		CorpTransaction transaction = (CorpTransaction)txn;
		
		if (transaction != null) {
			
			
			
			
			logger.info("validate(Transaction transaction)   "
					+ LoggingConstants.METHODBEGIN);
			if (logger.isDebugEnabled()) {
				logger.debug("transaction :" + transaction.toString());
			}
			
			if(null==validator){
				logger.info("validator is null");
			}

			if(null==transaction.getDebit().getBranchCode()){
				logger.info("debit branch code is null");
			}
			if(null==transaction.getCredit()[BPConstants.ZERO_INT]
					.getBranchCode()){
				logger.info("credit branch code is null");
			}
			
			/*validator.validateInterBank(transaction.getDebit().getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode());
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateInterBank(String debitBranchCode, String creditBranchCode) method - true");
			}*/
			
				logger.info("starting of validateAmount of validator");
			validator.validateAmount(transaction.getDebit().getAmount());
			if (logger.isDebugEnabled()) {
				logger.debug("validateAmount() return true");
			}
			
			logger.info("ending of validateAmount of validator");
			//commented for CR 1834
		/*	validator.validateLimit(transaction.getDebit().getAmount(),
					transaction.getName());
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateLimit(Double amount, String type) method - true");
			}*/
			// added for paladion on 30-june-06

			//CR 1834-start For intra branch limit validation
//          changed for Retail FT/Tp schedule payment CR2379 by archana
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime()); 
		//Commented for SARAL Limit Change
			/*validator.validateLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),
					transaction.getName(),transaction.getBankCode(),scheduledDate);
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateLimit(String username,Double amount, String type,String bankCode) method - true");
			}*/
			//CR 1834-end For intra branch limit validation
			logger.info("starting of validateAcctLimit of validator");
			validator.validateAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getUserName(),
			          transaction.getDebit().getAmount());
			
			
			
			logger.info("ending of validateAcctLimit of validator");
			if (logger.isDebugEnabled()) {
				logger.debug("validator.validateAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),"+
						          "transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),"+
						          "transaction.getCredit()[BPConstants.ZERO_INT].getUserName(),"+
						          "transaction.getDebit().getAmount()) method - true");
			}
			
			logger.info("starting of validateTxnRights of validator");
			// end for paladion
			validator.validateTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), new Integer(
							BPConstants.DEBIT_NO));
			
			logger.info("ending of validateTxnRights of validator");
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method - true");
			}
			logger.info("starting of validateAccountNature of validator");
			validator
					.validateAccountNature(
							transaction.getCredit()[BPConstants.ZERO_INT]
									.getAccountNo(),
							transaction.getCredit()[BPConstants.ZERO_INT]
									.getBranchCode(),
							transaction.getCredit()[BPConstants.ZERO_INT]
									.getUserName(), transaction.getName());
			
			
			logger.info("ending of validateAccountNature of validator");
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateAccountNature(String creditAccountNo, String branchCode, String userName, String type) method - true");
			}


			
			
			 //cr 1523 start
			//Commented for SARAL Limit Change
			/*if (!(transaction.getDebit().getBranchCode()
					.equalsIgnoreCase(transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode()))) {
//	          changed for Retail FT/Tp schedule payment CR2379 by archana
            validator.validateTodaysInterBranchTxnLimit(transaction.getDebit().getUserName(),transaction.getDebit().getAmount(),transaction.getName(),transaction.getBankCode(),scheduledDate);//bank code added for CR 1734
            if (logger.isDebugEnabled()){
            
                logger
                        .debug("validateTodaysInterBranchTxnLimit(String userName, Double amount, String txnName,String bankCode) method - true");
           
            
            }
			}*/
			
//          changed for Retail FT/Tp schedule payment CR2379 by archana
			//Commented for SARAL Limit Change
			/*validator.validateTodaysTxnLimit(transaction.getDebit()
					.getAccountNo(), transaction.getDebit().getBranchCode(),
					transaction.getDebit().getAmount(),scheduledDate);
			if (logger.isDebugEnabled()) {
				logger
						.debug("validateTodaysTxnLimit(String accountNo, String branchCode, Double amount) method - true");
			}
*/
			//added for beneficiary process flow
			int newBeneficairyCount=0;
			
			newBeneficairyCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "THIRDPARTY", transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "SARAL",transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
			
			if(newBeneficairyCount>0){
				transaction.getDebit().setIsNewlyAddedTp("YES");
				logger.info("Newly Added Beneficiary:::");
				
				if(transaction.isScheduled()){
					SBIApplicationException.throwException("TPB006");
				}else{
					logger.info("credit branch code-->"+transaction.getCredit()[0].getBranchCode());
					logger.info("starting of newBeneficiaryAdditionLimitValidationForSaral of validator");
					validator.newBeneficiaryAdditionLimitValidationForSaral(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "SARAL", "THIRDPARTY", transaction.getBankCode(),transaction.getDebit().getAmount(),transaction.getCredit()[0].getBranchCode());
					logger.info("ending of newBeneficiaryAdditionLimitValidationForSaral of validator");
				}
			}
			//added for beneficiary process flow ends
			String txnPath = transaction.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
            
            if(transaction.getBankCode().equalsIgnoreCase("0")){
            	logger.info("NRE accounts validations for SBI bank -part");
            if(txnPath.equals("CC")){
            	logger.info("starting of debit  getAccountSubType of validator");
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
            	logger.info("debitSubType--->"+debitSubType);
            	logger.info("ending of debit  getAccountSubType of validator");
            	logger.info("starting of credit  getAccountSubType of validator");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
            	logger.info("creditSubType--->"+creditSubType);
            	logger.info("starting of credit  getAccountSubType of validator");
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
            	
            }
            
            else if(txnPath.equals("CMC")){
        		
        		  String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
        		  logger.info("TP Transaction path is CMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
  	      		  }
  	      		  else {
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	      		  }
        		  
              }
              
              else if(txnPath.equals("NCMC")){
              	
              	 String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
              	 logger.info("TP Transaction path is NCMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getProductCode(),"Y");
  	            	
  	      		  }
  	      		 else{
  	             	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	             	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	             } 
              	
              }
            
            else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of SBI loop 
            else{ // for associate banks
            	logger.info("NRE accounts validations for Associate banks -part");
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of else part-Associate banks
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            logger.info("starting of validateTransferTypes of validator");
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);
            
            logger.info("ending of validateTransferTypes of validator");

            //Added for SARAL Limit Change
        	String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
            
            if(null==referenceDataCache){
            	logger.info("referenceDataCache is null");
            }
            
        Map data = referenceDataCache.getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
		 String limit = (String) data.get("SARAL_SUBCAT_TP_CATEGORY_A_"+bankCode);
     	 double interBankTransferLimit = Double.parseDouble(limit);
     	 if (transaction.getDebit().getAmount().doubleValue()>interBankTransferLimit) {
			SBIApplicationException.throwException("LMT001");
     	 }
     	 logger.info("starting of validateSubCategoryGroupALimitForSaral of validator");
     	validator.validateSubCategoryGroupALimitForSaral(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, bankCode, "Thirdparty","SARAL");
     	
     	logger.info("ending of validateSubCategoryGroupALimitForSaral of validator");
            
     	 logger.info("starting of validateCategoryALimitForSaral of validator");
     	validator.validateCategoryALimitForSaral(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode(),"SARAL");
          
            logger.info("ending of validateCategoryALimitForSaral of validator");
            
          
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODEND);
			

		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			
			}
		return true;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*this.transaction = transaction;
		if (transaction != null) {
			logger.info("validate(Transaction transaction) "
					+ LoggingConstants.METHODBEGIN);
			if (logger.isDebugEnabled()) {
				logger.debug("transaction :" + transaction.toString());
			}
			validator.validateTxnRights(transaction.getDebit().getAccountNo(),
					transaction.getDebit().getBranchCode(), transaction
							.getDebit().getUserName(), new Integer(
							BPConstants.DEBIT_NO));
			validator.validateInterBank(transaction.getDebit().getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode());
			validator.validateAccountNature(
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getAccountNo(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getBranchCode(),
					transaction.getCredit()[BPConstants.ZERO_INT]
							.getUserName(), transaction.getName());

			validator.validateAmount(transaction.getDebit().getAmount());
			if(!(transaction.getDebit().getAmount().doubleValue()==transaction.getCredit()[0].getAmount().doubleValue())){
				logger.info("Debi and credit amount is not same");
				SBIApplicationException.throwException("TAM001");
			}
			validator.validateAcctLimit(transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode(),
			          transaction.getCredit()[BPConstants.ZERO_INT].getUserName(),
			          transaction.getDebit().getAmount());
			validator.validateLVTLimitPerDay (transaction.getDebit().getAmount(),transaction.getDebit().getUserName(), transaction.getBankCode());
			Date scheduledDate = new Date(transaction.getScheduledDate().getTime()); 
			
			int newBeneficairyCount=0;
			
			newBeneficairyCount=userDAOImpl.isNewBeneficiaryExists(transaction.getDebit().getUserName(), "THIRDPARTY", transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "RETAIL",transaction.getCredit()[BPConstants.ZERO_INT].getBranchCode());
			
			if(newBeneficairyCount>0){
				transaction.getDebit().setIsNewlyAddedTp("YES");
				if(transaction.isScheduled()||transaction.isSiTxn()){
					SBIApplicationException.throwException("TPB006");
				}else{
					validator.newBeneficiaryAdditionLimitValidation(transaction.getDebit().getUserName(), transaction.getCredit()[BPConstants.ZERO_INT].getAccountNo(), "RETAIL", "THIRDPARTY", transaction.getBankCode(),transaction.getDebit().getAmount(),transaction.getCredit()[0].getBranchCode());
				}
			}
			
			
			String txnPath = transaction.getPath();
            
            logger.info("txnPath :"+txnPath);
            
            String debitSubType = "";
            String creditSubType = "";
            
            if(transaction.getBankCode().equalsIgnoreCase("0")){
            	logger.info("NRE accounts validations for SBI bank -part");
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
            	
            }
            
            else if(txnPath.equals("CMC")){
        		
        		  String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
        		  logger.info("TP Transaction path is CMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
  	      		  }
  	      		  else {
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName(),transaction.getDebit().getDebitProductCode(),"N");
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	      		  }
        		  
              }
              
              else if(txnPath.equals("NCMC")){
              	
              	 String creditBranchType = branchMasterDAOImpl.findBankSystem(transaction.getCredit()[0].getBranchCode());
              	 logger.info("TP Transaction path is NCMC and creditBranchType is:"+creditBranchType);
  	      		  if(creditBranchType.equals("C")){
  	      			debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName(),transaction.getCredit()[BPConstants.ZERO_INT].getCreditProductCode(),"Y");
  	            	
  	      		  }
  	      		 else{
  	             	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
  	             	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
  	             } 
              	
              }
            
            else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of SBI loop 
            else{ // for associate banks
            	logger.info("NRE accounts validations for Associate banks -part");
            if(txnPath.equals("CC")){
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else if(txnPath.equals("CNC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(), transaction.getDebit().getUserName());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }else if(txnPath.equals("NCC")){
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo(), transaction.getCredit()[0].getBranchCode(), transaction.getCredit()[0].getUserName());
            	
            }else{
            	
            	debitSubType = validator.getAccountSubType(transaction.getDebit().getAccountNo());
            	creditSubType = validator.getAccountSubType(transaction.getCredit()[0].getAccountNo());
            	
            }
            }// end of else part-Associate banks
            logger.info("debitSubType :"+debitSubType);
            logger.info("creditSubType :"+creditSubType);
            
            validator.validateTransferTypes(debitSubType, creditSubType, BPConstants.PRINCIPLE);

			
			 // Calling New Method to Validate the Based on the Category Wise overriding the existing all limit Validation
			 
			
            String bankCode=transaction.getBankCode();
            if(bankCode!=null && "0|3|A|6".contains(bankCode)){
            	bankCode="0";
            }
            validator.validateSubCategoryGroupALimit(transaction.getDebit().getUserName(), new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate, bankCode, "Thirdparty");
            
            logger.info("Validation returns true");
            
			validator.validateCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,bankCode);			
		
		
			if(transaction.getMobileFlag()!=null && "yes".equalsIgnoreCase(transaction.getMobileFlag())){
				logger.info("Mobile category wise validation");
						validator.validateMobileCategoryALimit(transaction.getDebit().getUserName(),  new Double(transaction.getDebit().getAmount().doubleValue()), scheduledDate,transaction.getBankCode());
			}	
		 
		
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		return true;*/
	}

	/**
	 * Validator injection
	 * 
	 * @param validator
	 */
	public void setValidator(Validator validator) {
		this.validator = validator;
	}

	public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}

	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	

}
