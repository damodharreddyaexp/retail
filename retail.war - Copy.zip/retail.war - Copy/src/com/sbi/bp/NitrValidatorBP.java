
package com.sbi.bp;

import com.sbi.dao.NitrStudentDetailsDAO;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.Validator;
import java.util.Map;
import org.apache.log4j.Logger;

public class NitrValidatorBP
{

    public NitrValidatorBP()
    {
        nitrValidator = true;
        validateAmount = false;
        validateTxnRights = false;
    }

    public boolean validate(Map inParams)
        throws SBIApplicationException
    {
        int recCnt = nitrStudentDetailsDAOImpl.findNitrHackCheck(inParams.get("rollNo").toString(), inParams.get("courseName").toString(), "Fees", inParams.get("userName").toString(), inParams.get("totamount").toString());
        if(recCnt == 0)
            nitrValidator = false;
        logger.info("recCnt..." + recCnt);
        if(nitrValidator)
            nitrValidator = validator.validateAmount(new Double(inParams.get("totamount").toString()));
        if(nitrValidator)
            nitrValidator = validator.validateTxnRights(inParams.get("debitAccountNo").toString(), inParams.get("debitBranchCode").toString(), inParams.get("userName").toString(), new Integer(9));
        if(nitrValidator)
            nitrValidator = validator.validateTodaysTxnLimit(inParams.get("debitAccountNo").toString(), inParams.get("debitBranchCode").toString(), new Double(inParams.get("totamount").toString()));
        logger.info("nitrValidator....." + nitrValidator);
        return nitrValidator;
    }

    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }

    public void setNitrStudentDetailsDAOImpl(NitrStudentDetailsDAO nitrStudentDetailsDAOImpl)
    {
        this.nitrStudentDetailsDAOImpl = nitrStudentDetailsDAOImpl;
    }

    private Validator validator;
    protected final Logger logger = Logger.getLogger(getClass());
    private NitrStudentDetailsDAO nitrStudentDetailsDAOImpl;
    boolean nitrValidator;
    boolean validateAmount;
    boolean validateTxnRights;
}
