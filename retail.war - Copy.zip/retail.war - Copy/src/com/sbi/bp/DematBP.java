
/*
 * DematBp.java
 * Created on Aug 9, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 9, 2006 VS23778 � Initial Creation

package com.sbi.bp;


import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.exception.SBIApplicationResponse;
import com.sbi.service.ServiceConstant;
import com.sbi.service.ServiceErrorConstants;
import com.sbi.utils.LoggingConstants;

public class DematBP{
    String dpID;
    String flag;
    Map outParams=new HashMap();
    String cdslcmcTargetUrl;
    String nsdlcmcTargetUrl;
    
    String accountDetailsOption;
    String holdingStatementOption;
    String transactionStatementOption;
    String billingStatementOption;
    String accountDetailsPar4;
    String holdingStatementPar4;
    String transactionStatementPar2;
    String transactionStatementPar3;
    String transactionStatementPar7;
    String transactionStatementPar8;
    String transactionStatementPar9;
    String billingStatementPar3;
    String billingStatementPar4;
    String billingStatementPar6;
    String billingStatementPar7;
    String billingStatementPar8;
    String billingStatementPar9;
    String holdingStatement,bankDetails;
    String showBilldp_client_id,showBillOption;
    String startDate,endDate;
    String showBillPar4,invoiceID;
  
    String id;
    String targetUrl;
    
    
    
    private final Logger logger=Logger.getLogger(getClass());
    private SBIApplicationResponse response=new SBIApplicationResponse();
    String str[][];
    
    public Map formatString(Map inParams){
        logger.info("formatString(Map inParams) " +LoggingConstants.METHODBEGIN);
        response.setErrorStatus(ServiceConstant.FAILURE);
        
        dpID=(String) inParams.get(BPConstants.DP_ID);
        flag=(String) inParams.get(BPConstants.DEMAT_REQUST);
        String channel = (String) inParams.get("channel");
        
        logger.info("flag "+flag);
        logger.info("channel "+channel);
        try{
        	if(channel.equalsIgnoreCase("CDSL")){
        		id="BO_ID";
        		targetUrl = cdslcmcTargetUrl;
        	}else if(channel.equalsIgnoreCase("NSDL")){
        		id="dpclient_id";
        		targetUrl = nsdlcmcTargetUrl;
        	}
        	
        	logger.info(" IDS :"+id);
        	logger.info(" targetUrl :"+targetUrl);
	        if (flag.equals("DP_ACCOUNT")){
	             str=new String[2][2];
	                str[0][0] = "option";
	                str[0][1] = accountDetailsOption;
	                str[1][0] = id;
	                str[1][1] = dpID;	               
	               outParams.put("cmcTargetUrl",targetUrl);
	               
	        }
	        else if (flag.equals("DP_HOLDING")){
	            str=new String[3][2];
	            str[0][0] = "option";
	            str[0][1] = holdingStatementOption;
	            str[1][0] = id;
	            str[1][1] = dpID;
	            str[2][0] = "par4";
	            str[2][1] = holdingStatementPar4;
	            outParams.put("cmcTargetUrl",targetUrl);
//	            logger.info("cmcTargetUrl" +targetUrl);
	            
	        }
	        else if (flag.equals("DP_STATEMENT_TRANS")){
	            str=new String[9][2];
	            holdingStatement=(String) inParams.get("holdingStatement");
	            bankDetails=(String) inParams.get("bankDetails");
	            startDate= (String)inParams.get("startdate");
	            endDate= (String)inParams.get("enddate");
	            /*logger.info("startDate= "+startDate);
	            logger.info("endDate= "+endDate);
	            logger.info("holdingStatement= "+holdingStatement);
	            logger.info("bankDetails= "+bankDetails);*/
	            if((holdingStatement != null)&& (holdingStatement.trim().length()>0)){
	            	 if (holdingStatement.equalsIgnoreCase("HoldingStatement")) {
	                     transactionStatementPar2="on";                                      
	                 }         	
	            }else{
	                transactionStatementPar2="off";
	            }   
	            if ((bankDetails!=null)){
	           	 if (bankDetails.equalsIgnoreCase("BankDetails")){
	                    transactionStatementPar3="Y";
	                }                	 
	            }else{
	                transactionStatementPar3="N";
	            }
	            logger.info("Array1"+str.toString());
	            str[0][0] = "option";
	            str[0][1] = transactionStatementOption;
	            str[1][0] = "par2";
	            str[1][1] = transactionStatementPar2;
	            str[2][0] = "par3";
	            str[2][1] = transactionStatementPar3;
	            str[3][0] = "par4";
	            str[3][1] = dpID;
	            str[4][0] = "par5";
	            str[4][1] = startDate;
	            str[5][0] = "par6";
	            str[5][1] = endDate;
	            str[6][0] = "par7";
	            str[6][1] = transactionStatementPar7;
	            str[7][0] = "par8";
	            str[7][1] = transactionStatementPar8;
	            str[8][0] = "par9";
	            str[8][1] = transactionStatementPar9;
	            outParams.put("cmcTargetUrl",targetUrl);
	            logger.info("cmcTargetUrl" +targetUrl);
	        }
	        else if (flag.equals("DP_BILLING_STATEMENT")){
	        	logger.info("show bills");
	            str=new String[2][2];
	            str[0][0] = "option";
	            str[0][1] = showBillOption;
	            str[1][0] = id;
	            str[1][1] = dpID;
	            outParams.put("cmcTargetUrl",targetUrl);
	            //logger.info("cmcTargetUrl" +targetUrl);
	            
	        }
	        else{
	        	invoiceID=(String) inParams.get("invoiceId");
	            str=new String[8][2];
	            str[0][0] = "option";
	            str[0][1] = billingStatementOption;
	            str[1][0] = "par3";
	            str[1][1] = billingStatementPar3;
	            str[2][0] = "par4";
	            str[2][1] = invoiceID;
	            str[3][0] = "par5";
	            str[3][1] = dpID;
	            str[4][0] = "par6";
	            str[4][1] = billingStatementPar6;
	            str[5][0] = "par7";
	            str[5][1] = billingStatementPar7;
	            str[6][0] = "par8";
	            str[6][1] = billingStatementPar8;
	            str[7][0] = "par9";
	            str[7][1] = billingStatementPar9;
	            outParams.put("cmcTargetUrl",targetUrl);
	            //logger.info("cmcTargetUrl" +targetUrl);
	          
	        }
        } catch(Exception e){
        	logger.info("Exception occured"+e.toString());
        	SBIApplicationException.throwException(ServiceErrorConstants.SE002);		
	        	
	    }
        outParams.put("StringArray",str);
        
        //logger.info("StringArray"+str);
        logger.info("formatString(Map inParams) " +LoggingConstants.METHODEND);
        return outParams;
       
        
    }
    public void setAccountDetailsOption(String accountDetailsOption)
    {
        this.accountDetailsOption = accountDetailsOption;
    }
    public void setAccountDetailsPar4(String accountDetailsPar4)
    {
        this.accountDetailsPar4 = accountDetailsPar4;
    }
  
    public void setHoldingStatementOption(String holdingStatementOption)
    {
        this.holdingStatementOption = holdingStatementOption;
    }
    public void setHoldingStatementPar4(String holdingStatementPar4)
    {
        this.holdingStatementPar4 = holdingStatementPar4;
    }
    public void setBillingStatementOption(String billingStatementOption)
    {
        this.billingStatementOption = billingStatementOption;
    }
    public void setBillingStatementPar3(String billingStatementPar3)
    {
        this.billingStatementPar3 = billingStatementPar3;
    }
    public void setBillingStatementPar4(String billingStatementPar4)
    {
        this.billingStatementPar4 = billingStatementPar4;
    }
    public void setBillingStatementPar6(String billingStatementPar6)
    {
        this.billingStatementPar6 = billingStatementPar6;
    }
    public void setBillingStatementPar7(String billingStatementPar7)
    {
        this.billingStatementPar7 = billingStatementPar7;
    }
    public void setBillingStatementPar8(String billingStatementPar8)
    {
        this.billingStatementPar8 = billingStatementPar8;
    }
    public void setBillingStatementPar9(String billingStatementPar9)
    {
        this.billingStatementPar9 = billingStatementPar9;
    }
    public void setShowBillOption(String showBillOption)
    {
        this.showBillOption = showBillOption;
    }
  
    public void setTransactionStatementOption(String transactionStatementOption)
    {
        this.transactionStatementOption = transactionStatementOption;
    }
     
    public void setTransactionStatementPar7(String transactionStatementPar7)
    {
        this.transactionStatementPar7 = transactionStatementPar7;
    }
    public void setTransactionStatementPar8(String transactionStatementPar8)
    {
        this.transactionStatementPar8 = transactionStatementPar8;
    }
    public void setTransactionStatementPar9(String transactionStatementPar9)
    {
        this.transactionStatementPar9 = transactionStatementPar9;
    }
    public void setShowBilldp_client_id(String showBilldp_client_id)
    {
        this.showBilldp_client_id = showBilldp_client_id;
    }
	/**
	 * @param showBillPar4 The showBillPar4 to set.
	 */
	public void setShowBillPar4(String showBillPar4) {
		this.showBillPar4 = showBillPar4;
	}

	/**
	 * @param cdslcmcTargetUrl The cdslcmcTargetUrl to set.
	 */
	public void setCdslcmcTargetUrl(String cdslcmcTargetUrl) {
		this.cdslcmcTargetUrl = cdslcmcTargetUrl;
	}
	/**
	 * @param nsdlcmcTargetUrl The nsdlcmcTargetUrl to set.
	 */
	public void setNsdlcmcTargetUrl(String nsdlcmcTargetUrl) {
		this.nsdlcmcTargetUrl = nsdlcmcTargetUrl;
	}

}
