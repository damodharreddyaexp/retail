package com.sbi.bp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.CoreDAO;
import com.sbi.dao.NewppfAccountDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.NewPPFAccount;
import com.sbi.model.NewPPFNomineeModel;


@SuppressWarnings(value="unchecked")
public class NewppfAccountBp {
	private static final Logger logger = Logger.getLogger(NewppfAccountBp.class);

	private CoreDAO coreDAOImpl;
	private NewppfAccountDAO newppfAccountDAOImpl;

	public Map getCustomerDetails(Map inParam) {
		logger.info("getCustomerDetails(...) Starts Here");
		Map responseMap = null;
		try {
			List CIFNumbersList = new ArrayList();
			CIFNumbersList = newppfAccountDAOImpl.findUserDetails(inParam);
			if(CIFNumbersList!=null && CIFNumbersList.size()>0) {
				responseMap=(Map)CIFNumbersList.get(0);
			}
		}
		catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("getCustomerDetails(...) Ends Here");
		return responseMap;
	}

	public List construct60459Request(Map inParams) {
		logger.info("construct60459Request(...) Starts Here");
		Map enquiryMap = new HashMap();
		enquiryMap.put("txnno", "060459");
		enquiryMap.put("bankCode", ((String)inParams.get("bankCode")));
		enquiryMap.put("Customer_Number",((String)inParams.get("cifNumber")));
		List requestToCore = postToCore(enquiryMap);
		logger.info("construct60459Request(...) Ends Here");
		return requestToCore;
	}


	public NewPPFAccount populate60459Response(NewPPFAccount ppfModel, Map inParams) {
		logger.info("populate60459Response(...) Starts Here");
		if((String)inParams.get("Customer Name")!=null && ((String)inParams.get("Customer Name")).length()>0) {
			ppfModel.setCustomerName((String)inParams.get("Customer Name"));
		}else {
			ppfModel.setCustomerName(" ");
		}
		if((String)inParams.get("Customer Number")!=null && ((String)inParams.get("Customer Number")).length()>0) {
			ppfModel.setCustomerNumber((String)inParams.get("Customer Number"));
		}else {
			ppfModel.setCustomerNumber(" ");
		}
		if((String)inParams.get("Address 1")!=null && ((String)inParams.get("Address 1")).length()>0) {
			ppfModel.setAddress1((String)inParams.get("Address 1"));
		}else {
			ppfModel.setAddress1(" ");
		}
		if((String)inParams.get("Address 2")!=null && ((String)inParams.get("Address 2")).length()>0) {
			ppfModel.setAddress2((String)inParams.get("Address 2"));
		}else {
			ppfModel.setAddress2(" ");
		}
		if((String)inParams.get("Address 3")!=null && ((String)inParams.get("Address 3")).length()>0) {
			ppfModel.setAddress3((String)inParams.get("Address 3"));
		}else {
			ppfModel.setAddress3(" ");
		}
		if((String)inParams.get("Address 4")!=null && ((String)inParams.get("Address 4")).length()>0) {
			ppfModel.setAddress4((String)inParams.get("Address 4"));
		}else {
			ppfModel.setAddress4(" ");
		}
		if((String)inParams.get("Pan Number")!=null && ((String)inParams.get("Pan Number")).length()>0) {
			ppfModel.setPanNumber((String)inParams.get("Pan Number"));
			//New CR begins
			ppfModel.setMaskedPan(ppfModel.getPanNumber().substring(0,2)+"XXXXXX"+ppfModel.getPanNumber().substring(8,10));
			//New CR ends
		}else {
			ppfModel.setPanNumber(" ");
			//New CR begins
			ppfModel.setMaskedPan(" ");
			//New CR ends
		}
		logger.info("populate60459Response(...) Ends Here");
		return ppfModel;
	}

	public NewPPFAccount loadInputtedValues(NewPPFAccount ppfModel, Map inparam) {
		logger.info("loadInputtedValues(..) -Begins");
		ppfModel.setIsMinor((String)inparam.get("isMinor"));
		ppfModel.setMinorName((String)inparam.get("MinorName"));
		ppfModel.setMinorDob((String)inparam.get("minordob"));
		ppfModel.setMinorRelationship((String)inparam.get("minorRelationship"));
		
		if((String)inparam.get("branchCode")!=null && ((String)inparam.get("branchCode")).trim().length()>0) {
			ppfModel.setBranchCode((String)inparam.get("branchCode"));
		} else {
			ppfModel.setBranchCode(" ");
		 }
		if((String)inparam.get("branchName")!=null && ((String)inparam.get("branchName")).trim().length()>0) {
			ppfModel.setBranchName((String)inparam.get("branchName"));
		}else {
			ppfModel.setBranchName(" ");
		}
		if((String)inparam.get("districtName")!=null && ((String)inparam.get("districtName")).trim().length()>0) {
			ppfModel.setDistrictName((String)inparam.get("districtName"));
		}else {
			ppfModel.setDistrictName(" ");
		}
		if((String)inparam.get("stateName")!=null && ((String)inparam.get("stateName")).trim().length()>0) {
			ppfModel.setStateName((String)inparam.get("stateName"));
		}else {
			ppfModel.setStateName(" ");
		}

		logger.info("loadInputtedValues(..) -Ends");
		return ppfModel;    	
	}	
	
	public String getBankRefNo() {
		logger.info("getBankRefNo(...) Starts Here");
		String ppfReferenceNo = null;		
		try {
			ppfReferenceNo = newppfAccountDAOImpl.createSequenceID();	                
		}catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}	        
		logger.info("getBankRefNo(...) Ends Here");
		return ppfReferenceNo;
	}


	public void insertCustomerDetails(Map ppfMap,NewPPFAccount ppfModel,List nomineeDetailList) {
		logger.info("insertCustomerDetails(...) Starts Here");
		try {
			newppfAccountDAOImpl.insertNewPPFAccountDetails(ppfMap,ppfModel,nomineeDetailList);
		}catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("insertCustomerDetails(...) Ends Here");
	}

	public List postToCore(Map requestMap) throws DAOException,SBIApplicationException {
		logger.info("postToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			if(status!=null && ("F1".equals(status)) || ("F2".equals(status))) {
				SBIApplicationException.throwException("F1");
			}else if(status!=null && "ERR.".equals(status)) {                	 
				SBIApplicationException.throwException("PJ009");
			}
		}
		logger.info("postToCore(...) Ends Here");
		return responseList;
	}

	public List retrieveNomineeDetails(Map nomineeMap) {
		logger.info("retrieveNomineeDetails(..) Starts Here");
		List nomineeDetailsList = new ArrayList();

		for(int sequenceNo=1;sequenceNo<=5;sequenceNo++) {
			String nomineeName = (String)nomineeMap.get("nominee"+sequenceNo);
			String nomineeDob = (String)nomineeMap.get("nominedob"+sequenceNo);
			String nomineePercentage = (String)nomineeMap.get("ppfpercentage"+sequenceNo);
			logger.info("S.No -->"+sequenceNo+"  NomineeName -->"+nomineeName+"  NomineeDob -->"+nomineeDob+"  NomineePercentile -->"+nomineePercentage);

			if((nomineeName!=null && nomineeName.trim().length()>0)) {
			//		(nomineeDob!=null && nomineeDob.trim().length()>0)&&
			//		(nomineePercentage!=null && nomineePercentage.trim().length()>0)) {
				NewPPFNomineeModel ppfNomineeModel= new NewPPFNomineeModel();
				//ppfNomineeModel.setSequenceNo(sequenceNo);
				ppfNomineeModel.setNomineeName(nomineeName);
				ppfNomineeModel.setNomineeDob(nomineeDob);
				ppfNomineeModel.setNomineePercentage(nomineePercentage);
				nomineeDetailsList.add(ppfNomineeModel);
			}	
		}
		logger.info("Nominee List Size -->"+nomineeDetailsList.size());
		logger.info("retrieveNomineeDetails(..) Ends Here");
		return nomineeDetailsList;
	}
	
	public Map getPrintHistoryDetails(Map inParam) {
		logger.info("getPrintHistoryDetails(..) Starts Here - ");
		Map printDetails = new HashMap();		
		try { 
			printDetails=newppfAccountDAOImpl.findPrintDetails(inParam);				
		}catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("getPrintHistoryDetails(..) Ends Here - ");
		return printDetails;
	}	

	public Map getPrintCustomerDetails(Map inParam) {
		logger.info("getPrintCustomerDetails(...) Starts Here");
		Map printDetails = new HashMap();
		try {
			printDetails = newppfAccountDAOImpl.findPrintUserDetails(inParam);
		}catch (DAOException daoExc) {
			SBIApplicationException.throwException(daoExc.getErrorCode(), daoExc);
		}
		logger.info("getPrintCustomerDetails(...) Ends Here");
		return printDetails;
	}
	


	public void setNewppfAccountDAOImpl(NewppfAccountDAO newppfAccountDAOImpl) {
		this.newppfAccountDAOImpl = newppfAccountDAOImpl;
	}

	public void setCoreDAOImpl(CoreDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}


}
