package com.sbi.bp;

import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import com.sbi.authentication.user.RequestResponseService;
import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;
import com.sbi.dao.CoreDAOImpl;
import com.sbi.dao.ErrorConstants;
import com.sbi.dao.UribDetailsDAO;
import com.sbi.dao.UserDAO;
import com.sbi.exception.DAOException;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.UribRegistrationDetails;
import com.sbi.utils.EncryptMD5;
import com.sbi.utils.LogonValidator;

public class UribValidationBP {
	protected final Logger logger = Logger.getLogger(getClass());
	private CoreDAOImpl coreDAOImpl;
	private SMSGatewayClient smsGatewayClient;
	private LogonValidator logonValidator;
	private RequestResponseService requestResponseService;
	private UribDetailsDAO uribDetailsDAOImpl;

	static int ssize =8; 
	static char[] chars = new char[] {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
		'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
		'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
		'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
	};

	public void sendSmsRequest(String mobileNo,String bankCode,String custId,String messageTypeId,String smsParamValues[],String countryCode)throws UnknownHostException, IOException{
		logger.info("sendSmsRequest method Starts hrere");
		//String countryCode="91";
		//logger.info("smsParamValues::::::"+smsParamValues[0]);
		SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"0",custId,mobileNo,countryCode);
		String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
		logger.info("smsRequestString"+smsRequestString);
		smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
		logger.info("sendSmsRequest method Ends hrere");	
	}
	
	public void sendSmsRequestResend(String mobileNo,String bankCode,String custId,String messageTypeId,String smsParamValues[],String countryCode)throws UnknownHostException, IOException{
		logger.info("sendSmsRequest method Starts hrere");
		//String countryCode="91";
		//logger.info("smsParamValues::::::"+smsParamValues[0]);
		SMSRequestParams smsRequestParams = populateSMSRequestParams(messageTypeId ,smsParamValues,bankCode,"1",custId,mobileNo,countryCode);
		String smsRequestString = ConstructSMSRequest.constructSMSRequest(smsRequestParams);
		logger.info("smsRequestString"+smsRequestString);
		smsGatewayClient.postMessageToSgate(smsRequestString, StringUtils.getServerHost());
		logger.info("sendSmsRequest method Ends hrere");	
	}

	private SMSRequestParams populateSMSRequestParams(String messageTypeId,String smsParamValues[],String bankCode,String sendOrder, String userName,String mobileNumber,String countryCode)
	{
		logger.info("SMSGateWayRequestSender populateSMSRequestParams  for Beneficiary Starts. Cutomer Number " + userName );
		SMSRequestParams smsRequestParams = new SMSRequestParams();
		smsRequestParams.setMessageId(StringUtils.uniqueNumberUsingDateAndRandom("RU"));
		smsRequestParams.setMessageTypeId(messageTypeId);
		smsRequestParams.setModuleName("retail");
		smsRequestParams.setUserName(userName);
		smsRequestParams.setBankCode(bankCode);
		smsRequestParams.setMobileNo(mobileNumber);
		smsRequestParams.setCountryCode(countryCode);
		smsRequestParams.setSendOrder(sendOrder);
		List<String> listParam = new ArrayList<String>();
		if( smsParamValues != null){
			for( int i=0; i<smsParamValues.length; i++){
				listParam.add(smsParamValues[i]);
			}
		}
		smsRequestParams.setParam(listParam);
		return smsRequestParams;
	}

	public void changeLoginPassword(UribRegistrationDetails uribRegistrationDetails){    	
		if(uribRegistrationDetails != null ){
			String newMD5Password = "";
			String newSHAPassword = ""; 
			if(!logonValidator.firstTimeLoginPassword(uribRegistrationDetails.getUribPassword())){
				SBIApplicationException.throwException(ErrorConstants.INVALID_USERNAME_PASSWORD);
			}
			try{
				newMD5Password=EncryptMD5.hashMessage(uribRegistrationDetails.getUribUserName() + "#" + uribRegistrationDetails.getUribPassword()); //added for CR 5034
				newSHAPassword= requestResponseService.getSHA2Hashing(uribRegistrationDetails.getUribUserName(),uribRegistrationDetails.getUribPassword(),"#");
				uribRegistrationDetails.setUribPassword(newSHAPassword);
				uribRegistrationDetails.setUribMd5Password(newMD5Password);
				uribDetailsDAOImpl.changeLoginPassword(uribRegistrationDetails);
			}catch(DAOException daoExp){
				SBIApplicationException.throwException(daoExp.getErrorCode());
			}	    	
		}
	}

	public boolean validateMobileNo(String mobileNo){
		logger.info("validateMobileNo(String) - Begins");
		boolean validateFlag =true;
		int count =0;
		if((mobileNo == null || mobileNo.isEmpty())||mobileNo.trim().length()==0 )
		{
			validateFlag =false;
		}
		if(mobileNo.matches("^[0-9]$"))
		{
			logger.info("validation for mobile number to accept only numbers");
			validateFlag =false;
		}
		if((mobileNo.length()<6|| mobileNo.length()>11 ))
		{
			logger.info("Enter Valid Mobile Number");
			validateFlag= false;
		}
		logger.info("validateMobileNo(String) - ends");
		return validateFlag;
	}

	public boolean validateBranchCode(String branchCode) {
		boolean validateFlag =true;
		if((branchCode == null || branchCode.isEmpty())||branchCode.trim().length()==0 )
		{
			validateFlag =false;
		}
		if (branchCode.trim().length() == 5) {
			if(branchCode.matches("^[0-9]$"))
			{
				logger.info("validation for branch Code accept only numbers");
				validateFlag =false;
			}
		}
		return validateFlag;
	}

	public boolean validateAccountDetails(String accountNo, String flag) {
		boolean validateFlag =true;
		if((accountNo == null || accountNo.isEmpty())||accountNo.trim().length()==0 )
		{
			validateFlag =false;
		}
		if(accountNo.matches("^[0-9]$"))
		{
			logger.info("validation for Account Number/ Cif Number to accept only numbers");
			validateFlag =false;
		}

		if((accountNo.length()<11|| accountNo.length()>17 ))
		{
			if ("cifNo".equalsIgnoreCase(flag)) {
				logger.info("Enter Valid Cif Number");
			} else if ("accountNo".equalsIgnoreCase(flag)) {
				logger.info("Enter Valid Account Number");
			}
			validateFlag= false;
		}
		return validateFlag;
	}

	public boolean validateIdentical(String accountNo, String cifNo) {
		boolean validateFlag =true;
		if(cifNo!=null && cifNo.trim().length()>0 && accountNo!=null && accountNo.trim().length()>0 && cifNo.equalsIgnoreCase(accountNo)){
			logger.info("Both CIF Number and account number is same");
			validateFlag =false;
		}
		return validateFlag;
	}
	
	public boolean validateIdenticalCaptcha(String accountNo, String cifNo) {
		boolean validateFlag =true;
		if(cifNo!=null && cifNo.trim().length()>0 && accountNo!=null && accountNo.trim().length()>0 && !cifNo.equalsIgnoreCase(accountNo)){
			logger.info("Captcha is not same");
			validateFlag =false;
		}
		return validateFlag;
	}

	// Connecting Core To Get AccountInfo for the customer 
	public boolean validateMobileNo(String userMobileNo, String coreMobileNo) {
		boolean validateflag = true;
		if (coreMobileNo != null && coreMobileNo.trim().length()>0 && userMobileNo != null && userMobileNo.trim().length() > 0 && userMobileNo.equalsIgnoreCase(coreMobileNo)) {
			logger.info("Mobile Number remains same with CBS");
			validateflag = false;
		}
		return validateflag;
	}

	public boolean validateCifNumber(String userCifNo, String coreCifNo) {
		boolean validateflag = true;
		if (coreCifNo != null && coreCifNo.trim().length()>0 && userCifNo != null && userCifNo.trim().length() > 0 && userCifNo.equalsIgnoreCase(coreCifNo)) {
			logger.info("Customer Number remains same with CBS");
			validateflag = false;
		}
		return validateflag;
	}

	public boolean validateBranchCode(String userBranchCode, String coreBranchcode) {
		boolean validateflag = true;
		if (coreBranchcode != null && coreBranchcode.trim().length()>0 && userBranchCode != null && userBranchCode.trim().length() > 0 && userBranchCode.equalsIgnoreCase(coreBranchcode)) {
			logger.info("Entered Branch Code remains same with CBS");
			validateflag = false;
		}
		return validateflag;
	}
	
	public boolean validateTxnRghts(String txnRights) {
		boolean validateflag = true;
		if (txnRights != null && txnRights.trim().length()>0 && !(("09".equalsIgnoreCase(txnRights)) || ("08".equalsIgnoreCase(txnRights)) || ("05".equalsIgnoreCase(txnRights)))) {
			logger.info("Invalid Transaction Rights");
			validateflag = false;
		}
		return validateflag;
	}

	// Connecting the Core ::
	public List postEnquriyToCore(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postEnquriyToCore(...) Starts Here");
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList); 
		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");
			logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);

			if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) ){
				SBIApplicationException.throwException("F1");
			}   
			logger.info("txn:::"+requestMap.get("txnno"));
			if(status!=null && status.equalsIgnoreCase("ERR.")){
				SBIApplicationException.throwException("TL10");
			}
		}
		logger.info("postEnquriyToCore(...) Ends Here");
		return responseList;
	}

	public String getRandomString(){
		Random ran = new java.util.Random();
		String randomString = "";
		for (int j = 0; j < ssize; j++){
			int r = ran.nextInt(chars.length);
			randomString += chars[r];
		}
		return randomString;
	}

	public int uribRegCount(String coreCifNo, String status){
		logger.info("uribRegCount method begin");
		int count=0;
		count=uribDetailsDAOImpl.cifExsitenceCount(coreCifNo, status);
		logger.info("uribRegCount method ends");
		return count;
	}
	
	public List getUribDetails(String cifNo){
		logger.info("getUribDetails(String) - starts");
		List uribDetailList = uribDetailsDAOImpl.getUribDetails(cifNo);
		/*if(uribDetailList == null || uribDetailList.size() == 0){
			LOGGER.error("No FOR transactions found.");
			SBIApplicationException.throwException("URIB010");
		}*/
		logger.info("getUribDetails(String) - ends");
		return uribDetailList;
	}
	
 

	public void updateLogDetails(Map userLogDetails){
		logger.info("updateLogDetails(String coreCifNo) method begin");
		uribDetailsDAOImpl.insertLoginTime(userLogDetails);
		logger.info("updateLogDetails(String coreCifNo) method ends");
	}

	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}

	public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
		this.smsGatewayClient = smsGatewayClient;
	}

	public void setLogonValidator(LogonValidator logonValidator) {
		this.logonValidator = logonValidator;
	}

	public void setRequestResponseService(
			RequestResponseService requestResponseService) {
		this.requestResponseService = requestResponseService;
	}

	public void setUribDetailsDAOImpl(UribDetailsDAO uribDetailsDAOImpl) {
		this.uribDetailsDAOImpl = uribDetailsDAOImpl;
	}

}
