package com.sbi.bp;

import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.WuValidator;

@SuppressWarnings(value="unchecked")
public class WuValidatorBP {
	protected final Logger logger = Logger.getLogger(getClass());

	private WuValidator wuValidator;

	public boolean validate(Map inParam, Map responseMap) throws SBIApplicationException {
		logger.info("validate " + LoggingConstants.METHODBEGIN);
		if (inParam != null && responseMap != null) {
			if (logger.isInfoEnabled()) {
				logger.info("MTCNumber :" + (String)inParam.get("mtcNumber"));
			}
			boolean validMTCNumber = wuValidator.validateMTCNumber(inParam, responseMap);
			boolean validAmount = wuValidator.validateAmount(inParam, responseMap);
			boolean validOrgCountry = wuValidator.validateOrgCountry(inParam, responseMap);
			//boolean validSenderName = wuValidator.validateSenderName(inParam, responseMap);

			if (!(validMTCNumber && validAmount && validOrgCountry)){ //&& validSenderName)) {
				logger.info("inside validate throw Exception");
				//SBIApplicationException.throwException("WUT003");
				return false;
			}
		} else {
			SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("validate " + LoggingConstants.METHODEND);
		return true;
	}
	public void setWuValidator(WuValidator wuValidator) {
		this.wuValidator = wuValidator;
	}


}
