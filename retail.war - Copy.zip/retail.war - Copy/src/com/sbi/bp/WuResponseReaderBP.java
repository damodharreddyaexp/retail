package com.sbi.bp;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.utils.LoggingConstants;
import com.sbi.utils.WuConstants;
import com.sbi.utils.WuResponseReader;
import com.sbi.utils.WuResponseReaderFactory;

/**
 * This class is used to read the response xml from external system.
 */
@SuppressWarnings(value="unchecked")
public class WuResponseReaderBP {
    private final Logger logger=Logger.getLogger(getClass());
	
	private WuResponseReaderFactory wuResponseReaderFactory;
	
	/**
	 * @param xmlDocument
	 * @return
	 * Steps:
	 * 1. Get 'typeOfResponse' variable from input map.
	 * 2. Call readResponse() method of wuResponseReaderFactory to get
	 *    appropriate reader by passing this variable.
	 */   
	public Map readResponse(Map input ) throws Exception {
        logger.info("readResponse - "+ LoggingConstants.METHODBEGIN);        
        Map responseMap = new HashMap();
	        logger.info("Response Type :"+(String)input.get(WuConstants.WU_RESPONSE_TYPE));
	        WuResponseReader wuResponseReader = wuResponseReaderFactory.readResponse((String)input.get(WuConstants.WU_RESPONSE_TYPE));
			responseMap = wuResponseReader.readResponse(input);

			if(logger.isInfoEnabled()){
				logger.info("Root Element :"+responseMap.get("rootElement"));
				logger.info("Response Error Code-->"+responseMap.get("error"));
				logger.info("response statusCode -->"+responseMap.get("status_code"));
			}			
        logger.info("readResponse - "+ LoggingConstants.METHODEND);        
        return responseMap;
	}

    public void setWuResponseReaderFactory(WuResponseReaderFactory wuResponseReaderFactory) {
        this.wuResponseReaderFactory = wuResponseReaderFactory;
    }

}
