/*
 * DepositRenewalValidatorBP.java
 * Created on Dec 01, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec  2 ,2005 Naveen Kumar - Initial Creation

package com.sbi.bp;


import org.apache.log4j.Logger;
import com.sbi.bp.BPConstants;
import com.sbi.bp.RequestValidatorBP;
import com.sbi.dao.ErrorConstants;
import com.sbi.exception.SBIApplicationException;
import com.sbi.model.DepositRenewDetails;
import com.sbi.model.Request;
import com.sbi.utils.LoggingConstants;
import com.sbi.utils.RequestValidator;
import com.sbi.utils.UtilsConstant;
import com.sbi.utils.Validator;



public class DepositRenewalValidatorBP extends RequestValidatorBP

{
    protected final Logger logger = Logger.getLogger(getClass());
    private RequestValidator requestValidator;
    private Validator validator;
    DepositRenewDetails depositRenewDetails;

    
    public boolean validate(Request request) throws SBIApplicationException 
    
        {

                if (request != null)
                {
                    logger.info("validate(Request request) " + LoggingConstants.METHODBEGIN);
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("request :" + request.toString());
                    }
               DepositRenewDetails depositRenewDetails = (DepositRenewDetails) request;
                                  
// validating same debit and credit account    
                    if(depositRenewDetails.getRenew_mi_cr_account_no() != null &&  depositRenewDetails.getRenew_mi_cr_account_no().length() > 0)
                    {
                        requestValidator.validateSameDebitCreditAccount(depositRenewDetails.getAccountNo(),depositRenewDetails.getRenew_mi_cr_account_no());
                    }      
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateSameDebitCreditAccount(debitAccountNo,creditAccountNo) method - true");
                    }
                    
                    // Validating Debit Account 
                    logger.debug("depositRenewDetails.getAccountNo()"+depositRenewDetails.getAccountNo()+"depositRenewDetails.getBranchCode()"+depositRenewDetails.getBranchCode()+" depositRenewDetails.getUser_name()"+ depositRenewDetails.getUserName());
                    validator.validateTxnRights(depositRenewDetails.getAccountNo(),depositRenewDetails.getBranchCode(),
                                        depositRenewDetails.getUserName(), new Integer(BPConstants.DEBIT_NO));
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for debit - true");
                    }

                    logger.info("depositRenewDetails.getRenew_mi_cr_account_no()--->"+depositRenewDetails.getRenew_mi_cr_account_no());
                    logger.info("depositRenewDetails.getBranchCode()--->"+depositRenewDetails.getBranchCode());
                    
                    //  Validating Credit Account 
                    if(depositRenewDetails.getRenew_mi_cr_account_no() != null &&  depositRenewDetails.getRenew_mi_cr_account_no().length() > 0 && depositRenewDetails.getRenew_mi_cr_branch_code() != null && depositRenewDetails.getUserName() != null)
                    {
                        validator.validateTxnRights(depositRenewDetails.getRenew_mi_cr_account_no(), depositRenewDetails.getRenew_mi_cr_branch_code(),
                                                    depositRenewDetails.getUserName(), new Integer(BPConstants.DEBIT_NO));
                    }
                            
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateTxnRights(String accountNo, String branchCode,String UserName,Integer Access Level) method for credit- true");
                    }
                    /*  validating account nature                 
                    
                    if(depositRenewDetails.getRenew_mi_cr_account_no() != null && depositRenewDetails.getRenew_mi_cr_account_no().length() > 0)
                    {
                    validator.validateAccountNature(depositRenewDetails.getRenew_mi_cr_account_no(), depositRenewDetails.getBranchCode(),
                                                           depositRenewDetails.getUser_name(),UtilsConstant.THIRD_PARTY); 
                    }
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateAccountNature(String creditAccountNo, String branchCode, String userName, String type) method for debit - true");
                    }
                    */
                    //validating AccountTypeTenor
                    
                    String accSubType = validator.getAccountSubType(depositRenewDetails.getAccountNo());
                        
                    logger.info("Account Sub Type is "+accSubType);
                    logger.info("Renew Deposit Type is : "+depositRenewDetails.getRenew_deposit_type());
                        
                    requestValidator.validateccountTypeTenor(depositRenewDetails.getRenew_deposit_type(), accSubType, depositRenewDetails.getRenew_months(),
                                                                 depositRenewDetails.getRenew_days());
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateccountTypeTenor(String accountType,String accountSubType,Integer month,Integer day) method for credit- true");
                    }
                    	logger.info("Reneul Account-----> " + depositRenewDetails.getRenew_mi_cr_account_no());
//Validating credit account
                  
                    
                    
                  
                    
                    
//validating Transfer Interst
                    
//                  String accSubTypeDebit = validator.getAccountSubType(depositRenewDetails.getAccountNo());
//                  String accSubTypeCredit = validator.getAccountSubType(depositRenewDetails.getRenew_mi_cr_account_no());
                    
                    if(depositRenewDetails.getRenew_mi_cr_account_no() != null &&  depositRenewDetails.getRenew_mi_cr_account_no().length() > 0)
                    {
                        validator.validateTransfer(depositRenewDetails.getAccountNo(), depositRenewDetails.getRenew_mi_cr_account_no(),BPConstants.INTEREST);
                    }
                            
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("validateTransfer(String accountNo, String creditaccountno, String Interest) method for credit- true");
                    } 
                    logger.info("validateTransfer(String accountNo, String creditaccountno, String Interest)" + LoggingConstants.METHODEND);
                    }
                else
                {
                	SBIApplicationException.throwException(ErrorConstants.DATA_NULL_DESCRIPTION);
                }
                return true;
    }


          
// Validator injection
             
            public void setValidator(Validator validator)
            {
                this.validator = validator;
            }


            
// RequestValidator injection 
            
            public void setRequestValidator(RequestValidator requestValidator)
            {
                this.requestValidator = requestValidator;
            }
    }
    
