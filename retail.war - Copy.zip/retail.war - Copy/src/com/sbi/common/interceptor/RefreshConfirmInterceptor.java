
/*
 * RefreshConfirmInterceptor.java
 * Created on Jan 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 18, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.sbi.common.handler.UIConstant;

public class RefreshConfirmInterceptor extends WebContentInterceptor
{
    protected final Logger logger = Logger.getLogger(getClass());
   
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) 
    {
        HttpSession session = request.getSession(false);
        logger.info("the value of refresh flag ="+session.getAttribute(UIConstant.REFRESH_FLAG));
        if(session.getAttribute(UIConstant.REFRESH_FLAG).equals(new Boolean(false)))
        {
            logger.info("First time:");
            session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(true));
            logger.info("refresh flag ="+session.getAttribute(UIConstant.REFRESH_FLAG));  
            String randNo = request.getParameter("randNo");//Added For CR 5289
            logger.info("Random Number >>>"+randNo);
            logger.info("session random number :"+session.getAttribute("TXN_RDN"));
            if(randNo != null && randNo.trim().length()>0 ){
	            if(session.getAttribute("TXN_RDN") != null ){        	
	            	String rNo = (String)session.getAttribute("TXN_RDN");        	
	            	if( randNo.equals(rNo)){
	            		 try{
	            			 logger.info("Inside if "+"randNo = "+randNo+"rNo ="+rNo);
	            			 String url = request.getServletPath().replaceAll("/","");
	            			 logger.info("url ="+url);
	            			 request.setAttribute(UIConstant.REFRESH_URL,url);
	            			 getServletContext().getRequestDispatcher("/refresh.htm").forward(request, response);
	            			 return false;
	            		 }catch (Exception ex)
	                     {
	                         //ex.printStackTrace();
	                         logger.error("Exception occure in CommonInterceptor : " , ex);
	                     }
	            		 return false;
	                  
	            	}else{
	            		logger.info("replacing oldno="+rNo+" new no."+randNo+" in session");
	                	session.setAttribute("TXN_RDN",randNo);
	                }
	            }else{
	            	logger.info("Setting first time in session"+randNo);
	            	session.setAttribute("TXN_RDN",randNo);
	            }
            }
            return true;
        }else 
        {
            try{
                String url = request.getServletPath().replaceAll("/","");
                logger.info("url ="+url);
                request.setAttribute(UIConstant.REFRESH_URL,url);
                getServletContext().getRequestDispatcher("/refresh.htm").forward(request, response);
            }catch (Exception ex)
            {
                ex.printStackTrace();
                logger.info("Exception occure in CommonInterceptor : " + ex.getMessage());
            }
            return false;
        }
        
    }

}
