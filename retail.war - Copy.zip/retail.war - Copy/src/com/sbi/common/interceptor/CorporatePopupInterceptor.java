
/*
 * CorporatePopupInterceptor.java
 * Created on Aug 14, 2008
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 14, 2008 im42510 � Initial Creation


package com.sbi.common.interceptor;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.User;

/**
 * Pre handle is for checking null sessions post handle for redirecting to error
 * page on error in application status.
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class CorporatePopupInterceptor extends WebContentInterceptor {

	protected final Logger log = Logger.getLogger(getClass());

	boolean flag = true;
	static int requestID = 0;

	/*
	 * (non-Javadoc)
	 * 
     * @see org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, java.lang.Object,
     *      org.springframework.web.servlet.ModelAndView)
	 */
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		log.info("Inside the Error Interceptor for "
				+ handler.getClass().getName());
		String error_view = "popuperror";//Changed for CorpDynamicLinks

		if (request.getAttribute(UIConstant.APPLICATION_RESPONSE) != null) {
			SBIApplicationResponse errorResponse = (SBIApplicationResponse) request
					.getAttribute(UIConstant.APPLICATION_RESPONSE);
			log.info("error response " + errorResponse);
			if (errorResponse.getErrorStatus().equalsIgnoreCase(
					UIConstant.FAILURE)) {
				log.info("Status is error");
				log.info("returning to the error view =" + error_view);
				Map outParam = new HashMap();
				outParam.put(UIConstant.APPLICATION_RESPONSE, errorResponse);
				modelAndView.addObject(UIConstant.ERROR_MODEL, outParam);
				modelAndView.setViewName(error_view);

			}

		}

		else {

			if (modelAndView != null) {
				Map outParam = new HashMap();
				Map model = new HashMap();
				model = modelAndView.getModel();
				String modelName = new String();
				log.info("size of model =" + model.size());
				log.info("size of key set id =" + model.keySet().size());
				for (int i = 0; i < model.keySet().size(); i++) {
					log.info("inside while");
					modelName = (String) model.keySet().iterator().next();
				}
				log.info("model name is " + modelName);
				outParam = (Map) model.get(modelName);
				SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
				log.info("error response " + errorResponse);

				if (errorResponse != null && errorResponse.getErrorStatus().equalsIgnoreCase(UIConstant.FAILURE)) {
					log.info("Status is error");
					log.info("returning to the error view =" + error_view);
					modelAndView.addObject(UIConstant.ERROR_MODEL, outParam);
					modelAndView.setViewName(error_view);

				}
			}
		}
		// Remove the username from the diagnostic context.
		MDC.remove("username");
		MDC.remove("url");
		MDC.remove("sessionID");
		MDC.remove("requestID");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet
	 * .http.HttpServletRequest, javax.servlet.http.HttpServletResponse,
	 * java.lang.Object)
	 */
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) {

		log.info("Inside preHandle method of CorporatePopupInterceptor"
				+ handler.getClass().getName());
		HttpSession session = request.getSession(false);
		if (session == null) {
			log.info("session is null");
			try {
				request.setAttribute(UIConstant.SESSION_ERROR,
						UIConstant.SESSION_ERROR_MESSAGE);
				getServletContext().getRequestDispatcher("/sessiontimeout.htm")
						.forward(request, response);
				// response.sendRedirect("/login.htm");

			} catch (Exception ex) {
				ex.printStackTrace();
				log.info("Exception occure in CommonInterceptor : "
						+ ex.getMessage());
			}
			return false;
		} else {
			String sessionId = session.getId();
			MDC.put("username", sessionId);
			log.info("session is not null");
			if (session.getAttribute(UIConstant.USER) == null) {
				try {
					request.setAttribute(UIConstant.SESSION_ERROR,
							UIConstant.SESSION_ERROR_MESSAGE);
					getServletContext().getRequestDispatcher("/login.htm")
							.forward(request, response);

				} catch (Exception ex) {
					ex.printStackTrace();
					log.info("Exception occure in CommonInterceptor : "
							+ ex.getMessage());
				}
				return false;
			}

			User user = (User) session.getAttribute(UIConstant.USER);
			if (session != null
					&& session.getAttribute(UIConstant.USER) != null) {

				MDC.put("username", user.getUserAlias());
				MDC.put("url", request.getRequestURI());
				MDC.put("sessionID", request.getRequestedSessionId());
				MDC.put("requestID", new Integer(requestID).toString());
				requestID++;
			}
			return true;
		}

	}
}
