package com.sbi.common.interceptor;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.LinkDetails;
import com.sbi.common.model.UserProfile;

public class CorpDynamicLinkInterceptor extends WebContentInterceptor {
	Logger logger = Logger.getLogger(getClass());
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) {
		logger.info("Inside PreHandle method of CorpDynamicLinkInterceptor");
		HttpSession session = request.getSession(false);
		String url = request.getServletPath().substring(1);
		logger.info("Current URL :"+url);
		ServletContext ctx = session.getServletContext();
		UserProfile userProfile = (UserProfile) session
				.getAttribute(UIConstant.USER);
		Map<String, LinkDetails> links = (Map<String, LinkDetails>) ctx.getAttribute("links" + userProfile.getBankCode()
				+ userProfile.getRoles().get(0) + userProfile.getUserType());
		LinkDetails linkDetails = links.get(url);
		logger.info("TAB NAME"+linkDetails.getTabName());
		//added for CR5550
		if(linkDetails.getTabName()!= null &&!linkDetails.getTabName().equals("Profile")){
			session.setAttribute(UIConstant.VERIFY_STATUS, "false");
			
		}
		if (linkDetails.getBaseURL() != null
				&& linkDetails.getBaseURL().trim().length() > 0)
			url = linkDetails.getBaseURL();
		logger.info("base URL :"+url);
		if (linkDetails.getErrorCode() != null)
			request.setAttribute("newErrorCode", linkDetails.getErrorCode());
		session.setAttribute("baseURL", url);
		session.setAttribute("bodyTab", linkDetails.getBodyTab());
		return true;
	}	
}
