
/*
 * RefreshDisplayInterceptor.java
 * Created on Jan 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 18, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.sbi.common.handler.UIConstant;


public class RefreshDisplayInterceptor extends WebContentInterceptor
{

    protected final Logger logger = Logger.getLogger(getClass());
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
    {
        HttpSession session = request.getSession(false);
        session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
        logger.info("Refresh flag is set to false");
        return true;
    }

}
