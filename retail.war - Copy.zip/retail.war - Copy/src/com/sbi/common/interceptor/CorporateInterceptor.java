/*  
 * CorporateInterceptor.java
 * Created on Nov 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 21, 2005 KRISHNA KUMAR - Initial Creation
package com.sbi.common.interceptor;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.User;

/**
 * Pre handle is for checking null sessions post handle for redirecting to error
 * page on error in application status.
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class CorporateInterceptor extends WebContentInterceptor {

    protected final Logger log = Logger.getLogger(getClass());

    boolean flag = true;
    static int requestID = 0;

    /**
     *  @see org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, java.lang.Object,
     *      org.springframework.web.servlet.ModelAndView)
     */
    public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
    	log.info("Inside the Error Interceptor for "+ handler.getClass().getName());

		HttpSession session = request.getSession(false);
		//CorpDynamic Link Change
		String errorView = "commonerror";
		if (session != null && session.getAttribute("bodyTab") != null)
			errorView = "bodytaberror";
		if (request.getAttribute("DWRPage") != null)
			errorView = "dwrpageerror";

		if (modelAndView != null) {
			Map outParam = new HashMap();
			Map model = new HashMap();
			model = modelAndView.getModel();
			String modelName = new String();
			log.info("size of model =" + model.size());
			log.info("size of key set id =" + model.keySet().size());
			for (int i = 0; i < model.keySet().size(); i++) {
				log.info("inside while");
				modelName = (String) model.keySet().iterator().next();
			}
			log.info("model name is " + modelName);
			outParam = (Map) model.get(modelName);
			SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
			log.info("error response " + errorResponse);
			if(errorResponse != null){            	
                String status = errorResponse.getErrorStatus();
                if(request.getAttribute("newErrorCode")!=null){
                    status = "failure";
                    errorResponse.setErrorCode(request.getAttribute("newErrorCode").toString());
                }
              //IR 71227 (status!= null)
                if (status!= null && status.equalsIgnoreCase("failure")) {
                	modelAndView.addObject(UIConstant.ERROR_MODEL, outParam);
                	log.info("error_view :"+errorView);
                    modelAndView.setViewName(errorView);
                }
            }
		}
		
		// Remove the username from the diagnostic context.
		MDC.remove("username");
		MDC.remove("url");
		MDC.remove("sessionID");
		MDC.remove("requestID");


    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.HandlerInterceptor#preHandle(javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse, java.lang.Object)
     */
    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) {

        log.info("Inside preHandle method of CorporateInterceptor"
                + handler.getClass().getName());
        HttpSession session = request.getSession(false);
        
        //Referer check - starts
        String refervalue = request.getHeader("referer");
        if (refervalue== null) {
            log.info("referer is null");
            if (session != null)
                session.invalidate();
            try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                log.info("Exception occure in CorporateInterceptor : "
                        + ex.getMessage());
            }
            return false;
        }else{
            //Referer check - ends
            if (session == null) {
                log.info("session is null");
                try {
                    request.setAttribute(UIConstant.SESSION_ERROR,
                            UIConstant.SESSION_ERROR_MESSAGE);
                    getServletContext().getRequestDispatcher("/sessiontimeout.htm").forward(
                            request, response);
                    // response.sendRedirect("/login.htm");
    
                } catch (Exception ex) {
                    ex.printStackTrace();
                    log.info("Exception occure in CommonInterceptor : "
                            + ex.getMessage());
                }
                return false;
            } else {
            	
            	Boolean mailAlertFlag=(Boolean)session.getAttribute("mailAlertFlag");
                if(mailAlertFlag!=null && !mailAlertFlag)
                	session.removeAttribute("mailAlertFlag");
                
                log.info("session is not null");
                if (session.getAttribute(UIConstant.USER) == null) {
                    try {
                        request.setAttribute(UIConstant.SESSION_ERROR,
                                UIConstant.SESSION_ERROR_MESSAGE);
                        getServletContext().getRequestDispatcher("/login.htm")
                                .forward(request, response);
    
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        log.info("Exception occure in CommonInterceptor : "
                                + ex.getMessage());
                    }
                    return false;
                }
    
                User user = (User) session.getAttribute(UIConstant.USER);
                if (session != null
                        && session.getAttribute(UIConstant.USER) != null) {
    
                    MDC.put("username", user.getUserAlias());
                    MDC.put("url", request.getRequestURI());
                    MDC.put("requestID", new Integer(requestID).toString());
                    requestID++;
                    //ADDED FOR CR 5266 STARTS
                    try{
                    	log.info("Request From "+request.getServletPath());
                    if (session.getAttribute("profilePWDStatus") != null
								&& !request.getServletPath().equals("/setpassword.htm")
								&& !request.getServletPath().equals("/setprofilpasswordconfim.htm")
								&& !request.getServletPath().equals("/setsfaprofilepassword.htm")
                    			&& !request.getServletPath().equals("/setprofilpasswordsfaconfim.htm"))
                    {
                    	getServletContext().getRequestDispatcher("/setpassword.htm").forward(request, response);
                    	return false;
                    }
                    else if (session.getAttribute("txnPWDStatus") != null
								&& session.getAttribute("profilePWDStatus") == null
								&& !request.getServletPath().equals("/changetxnpasswordconfirm.htm")
								&& !request.getServletPath().equals("/setpassword.htm")
								&& !request.getServletPath().equals("/setprofilpasswordconfim.htm")
								) 
                    {
                    	session.setAttribute(UIConstant.VERIFY_STATUS, "true");
                    	getServletContext().getRequestDispatcher("/changetxnpassword.htm").forward(request, response);
                        return false;
                    }
                    
                    else if(session.getAttribute("profilePWDStatus")==null && session.getAttribute("forceChangeFlag")!=null){
                    	getServletContext().getRequestDispatcher("/forceChangeLoginPwd.htm").forward(request, response);
                    	return false;
                    }
                    else if(session.getAttribute("kLoginChangePwd")!=null){
                    	getServletContext().getRequestDispatcher("/kloginchangepwd.htm").forward(request, response);
                    	return false;
                    }//force change
                    else if(session.getAttribute("firstLoginFlag")!=null){
                    	getServletContext().getRequestDispatcher("/changeusername.htm").forward(request, response);
                    	return false;
                    }//force change
                    else if(session.getAttribute("profilePWDStatus")!=null && request.getServletPath().equals("/setpassword.htm") && (new Integer("7").equals(session.getAttribute("userRole"))/* || new Integer("8").equals(session.getAttribute("userRole"))*/))
                    {
                    	getServletContext().getRequestDispatcher("/setsfaprofilepassword.htm").forward(request, response);
                    	return false;
                    }
                    else
         			if (session != null && (
         					request.getServletPath().equals("/viewinbox.htm") 
         					||request.getServletPath().equals("/viewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/bulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/bulkinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/bulkinboxquerybyupload.htm")
         					||request.getServletPath().equals("/bulkechequesinbox.htm")
         					||request.getServletPath().equals("/editechequedetails.htm")
         					||request.getServletPath().equals("/editecheque.htm")
         					||request.getServletPath().equals("/corpapprviewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/approverviewinbox.htm")
         					||request.getServletPath().equals("/approverbulkechequesinbox.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyupload.htm")) )
         					{
         				session.removeAttribute("BackButtonFlagVI");
         				session.removeAttribute("fromDateVI");
         				session.removeAttribute("toDateVI");
         				session.removeAttribute("productTypeVI");
         			}
         			if (session != null && (
         					request.getServletPath().equals("/viewinbox.htm") 
         					||request.getServletPath().equals("/viewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/bulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/viewinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/bulkinboxquerybyupload.htm")
         					||request.getServletPath().equals("/bulkechequesinbox.htm")
         					||request.getServletPath().equals("/editechequedetails.htm")
         					||request.getServletPath().equals("/editecheque.htm")
         					||request.getServletPath().equals("/corpapprviewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/approverviewinbox.htm")
         					||request.getServletPath().equals("/approverbulkechequesinbox.htm")
         					||request.getServletPath().equals("/corpapprviewinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyupload.htm")) )
         					{
         				session.removeAttribute("BackButtonFlagBI");
         				session.removeAttribute("fromDateBI");
         				session.removeAttribute("toDateBI");
         				session.removeAttribute("productTypeBI");
         				session.removeAttribute("accountNoBI");
         			}
         			if (session != null && (
         					request.getServletPath().equals("/viewinbox.htm") 
         					||request.getServletPath().equals("/viewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/bulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/viewinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/bulkinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/bulkechequesinbox.htm")
         					||request.getServletPath().equals("/editechequedetails.htm")
         					||request.getServletPath().equals("/editecheque.htm")
         					||request.getServletPath().equals("/corpapprviewinboxquerybyecheque.htm") 
         					||request.getServletPath().equals("/approverviewinbox.htm")
         					||request.getServletPath().equals("/approverbulkechequesinbox.htm")
         					||request.getServletPath().equals("/corpapprviewinboxquerybyaccount.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyecheque.htm")
         					||request.getServletPath().equals("/corpapprbulkinboxquerybyaccount.htm")) )
         					{
         				session.removeAttribute("BackButtonFlagUBI");
         				session.removeAttribute("UploaderIDUBI");
         				session.removeAttribute("productTypeUBI");
         				session.removeAttribute("accountNoUBI");
         			}
                    	return true;
                    }
                    catch(Exception ex)
                    {
                    	ex.printStackTrace();
                        log.info("Exception occur in CommonInterceptor : "+ ex.getMessage());	
                    }
                    //ADDED FOR CR 5266 ENDS
                }
                return true;
            }
    
        }
    }
}
