
/*
 * NoCachingFilter.java
 * Created on Jan 25, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 25, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.interceptor;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

public class NoCachingFilter implements Filter {

    private FilterConfig filterConfig = null;
    protected final Logger logger = Logger.getLogger(getClass());

    public void init(FilterConfig filterConfig) throws ServletException{
             this.filterConfig = filterConfig;
             logger.debug("Filter : " + this.filterConfig);
     }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException{
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setHeader("Cache-Control", "no-cache");
        httpResponse.setDateHeader("Expires", 0);
        httpResponse.setHeader("Pragma", "No-cache");
        httpResponse.setHeader("Cache-control","no-store");//Added for Cr-2608
        httpResponse.setHeader("Pragma","No-store");//Added for Cr-2608
        chain.doFilter(request, response);
    }

    public void destroy(){
        this.filterConfig = null;
     }

}
