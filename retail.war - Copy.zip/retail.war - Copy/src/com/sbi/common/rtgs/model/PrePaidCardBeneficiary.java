/*
 * CorporateTP.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 SG33414 - Initial Creation
package com.sbi.common.rtgs.model;

import java.sql.Timestamp;

public class PrePaidCardBeneficiary {

	private String id;
	
	private String cardNumber;
	
	private String cardReferenceNo;

	private String fileName;

	private String cardHolderName;

	private String branchCode;

	private String cardStatus;

	private String cardActive;

	private String corporateId;

	private String uploaderName;

	private Timestamp createdTime;

	private Timestamp lastModTime;

	private String approvedBy;

	public String toString() {
		StringBuffer tempStringBuf = new StringBuffer();
		tempStringBuf.append(id);
		tempStringBuf.append(" | ");
		tempStringBuf.append(cardNumber);
		tempStringBuf.append(" | ");
		tempStringBuf.append(cardReferenceNo);
		tempStringBuf.append(" | ");
		tempStringBuf.append(fileName);
		tempStringBuf.append(" | ");
		tempStringBuf.append(cardHolderName);
		tempStringBuf.append(" | ");
		tempStringBuf.append(branchCode);
		tempStringBuf.append(" | ");
		tempStringBuf.append(cardStatus);
		tempStringBuf.append(" | ");
		tempStringBuf.append(cardActive);
		tempStringBuf.append(" | ");
		tempStringBuf.append(corporateId);
		tempStringBuf.append(" | ");
		tempStringBuf.append(uploaderName);
		tempStringBuf.append(" | ");
		tempStringBuf.append(createdTime);
		tempStringBuf.append(" | ");
		tempStringBuf.append(lastModTime);
		tempStringBuf.append(" | ");
		tempStringBuf.append(approvedBy);
		tempStringBuf.append(" | ");
		return tempStringBuf.toString();
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getCardActive() {
		return cardActive;
	}

	public void setCardActive(String cardActive) {
		this.cardActive = cardActive;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardReferenceNo() {
		return cardReferenceNo;
	}

	public void setCardReferenceNo(String cardReferenceNo) {
		this.cardReferenceNo = cardReferenceNo;
	}

	public String getCardStatus() {
		return cardStatus;
	}

	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Timestamp getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Timestamp lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getUploaderName() {
		return uploaderName;
	}

	public void setUploaderName(String uploaderName) {
		this.uploaderName = uploaderName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


}
