/*
 * CorporateTP.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 SG33414 - Initial Creation
package com.sbi.common.rtgs.model;

import java.sql.Timestamp;

import com.sbi.common.model.BaseModel;

public class CorporateTP implements BaseModel {
	private String corporateID;

	private String name;

	private String accountNo;

	private String branchCode;
	
	private String outRef1;

	private String outRef2;

	private String outRef3;

	private String outRef4;

	private String outRef5;

	private String outRef6;

	private String outRef7;

	private Integer status;

//	private Integer oid;
	
	private Long  oid;
    
    private String deletionFileNo;
    
    private String deletionApprovedBy;
    
    private String addedBy;//Added For CR 5390
    
    private String productCode;//Added For CR 5390
    
    private String productDesc;//Added For CR 5390
    
    private Timestamp addedDate;//Added For CR 5390
    
    private String approvedStatus;//Added For CR 5390
    
    private String remarks;//Added For CR 5390

	private String mobileNo;// Added for CR-5603
	
	private String emailId;//Added for CR-5603
	
	private String employeeCode;//Added for CR 5603
    
	private String tpFileStatus;//Added for mobile Registration Phase 2
	
	/*Added for Enhancement in approve beneficiary -Phase I - Start*/
	private String address1;
	
	private String address2;
	private String address3;
	/*Added for Enhancement in approve beneficiary -Phase I - End*/
	/* Added for  benefiacry revamp form based with starts*/
	private String branchName;
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) { 
		this.branchName = branchName;
	}
	/* Added for  benefiacry revamp form based with ends*/
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	public String getCorporateID() {
		return corporateID;
	}

	public void setCorporateID(String corporateID) {
		this.corporateID = corporateID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOutRef1() {
		return outRef1;
	}

	public void setOutRef1(String outRef1) {
		this.outRef1 = outRef1;
	}

	public String getOutRef2() {
		return outRef2;
	}

	public void setOutRef2(String outRef2) {
		this.outRef2 = outRef2;
	}

	public String getOutRef3() {
		return outRef3;
	}

	public void setOutRef3(String outRef3) {
		this.outRef3 = outRef3;
	}

	public String getOutRef4() {
		return outRef4;
	}

	public void setOutRef4(String outRef4) {
		this.outRef4 = outRef4;
	}

	public String getOutRef6() {
		return outRef6;
	}

	public void setOutRef6(String outRef6) {
		this.outRef6 = outRef6;
	}

	public String getOutRef7() {
		return outRef7;
	}

	public void setOutRef7(String outRef7) {
		this.outRef7 = outRef7;
	}

	public String getOutRef5() {
		return outRef5;
	}

	public void setOutRef5(String outRef5) {
		this.outRef5 = outRef5;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

/*	public Integer getOid() {
		return oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}*/
	
	
	public Long getOid() {
		return oid;
	}

	public void setOid(Long oid) {
		this.oid = oid;
	}
	
    
	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
    
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc= productDesc;
	}

	public Timestamp getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(Timestamp addedDate) {
		this.addedDate = addedDate;
	}
    
	
	public String getApprovedStatus() {
		return approvedStatus;
	}

	public void setApprovedStatus(String approvedStatus) {
		this.approvedStatus = approvedStatus;
	}
 
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

		
	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String toString() {
		StringBuffer tempStringBuf = new StringBuffer();
		tempStringBuf.append(corporateID);
		tempStringBuf.append(" | ");
		tempStringBuf.append(name);
		tempStringBuf.append(" | ");
		tempStringBuf.append(accountNo);
		tempStringBuf.append(" | ");
		tempStringBuf.append(branchCode);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef1);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef2);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef3);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef4);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef5);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef6);
		tempStringBuf.append(" | ");
		tempStringBuf.append(outRef7);
		tempStringBuf.append(" | ");
		tempStringBuf.append(status);
		tempStringBuf.append(" | ");
		tempStringBuf.append(oid);
		tempStringBuf.append(" | ");
		tempStringBuf.append(addedBy);
		tempStringBuf.append(" | ");
		tempStringBuf.append(tpFileStatus);
		tempStringBuf.append(" | ");
		tempStringBuf.append(address1);
		tempStringBuf.append(" | ");
		tempStringBuf.append(address2);
		tempStringBuf.append(" | ");
		tempStringBuf.append(address3);
		tempStringBuf.append(" | ");
		tempStringBuf.append(branchName);
		return tempStringBuf.toString();
	}

    public String getDeletionApprovedBy()
    {
        return deletionApprovedBy;
    }

    public void setDeletionApprovedBy(String deletionApprovedBy)
    {
        this.deletionApprovedBy = deletionApprovedBy;
    }

    public String getDeletionFileNo()
    {
        return deletionFileNo;
    }

    public void setDeletionFileNo(String deletionFileNo)
    {
        this.deletionFileNo = deletionFileNo;
    }

    public String getTpFileStatus() {
		return tpFileStatus;
	}

	public void setTpFileStatus(String rtgsStatus) {
		this.tpFileStatus = rtgsStatus;
	}


}
