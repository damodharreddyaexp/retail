package com.sbi.common.rtgs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;


public class ApproveFileConfirmService extends BaseService {

	
	  protected final Logger logger = Logger.getLogger(getClass());

	    private ThirdPartyDAO externalthirdPartyDAOImpl;
	    private ThirdPartyDAO thirdPartyDAOImpl;
	    
	    

		/**
	     * call the [thirdPartyDAOImpl.updateTPState(apprIds,unApprIds,
	     * userName,banktype),updateTPStateALL(apprIds,unApprIds, userName)] to get the
	     * ApproveFile Details return objectArray which is contains ApproveTpFile
	     * Approve and UnApprove Details.
	     * 
	     * @param inputParams
	     * @return Map
	     * 
	     */

	    public Map execute(Map inputParam)
	    {
	        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
	        Map outParam = new HashMap();
	        SBIApplicationResponse response;
	        response = new SBIApplicationResponse();
	        response.setErrorStatus("failure");
	       // String apprIds = null;
	        String unApprIds = null;
	        boolean status = false;
	        Integer userRole = (Integer) inputParam.get("userRole");
	        CorporateTP[] corporateTP = null;
	        String fileName = (String) inputParam.get("fileName");
	        int index = fileName.indexOf('.');
	        String filename = fileName.substring(0, index);
	        String userName = (String) inputParam.get("userName");
	        String bankType = (String) inputParam.get("bankType");// added for default file config
	        String functionType = (String) inputParam.get("functionType");
	        String actionType=  (String) inputParam.get("actionType");
			String corporateId=  (String) inputParam.get("corporateId");
	       
	        logger.info("fileName :"+fileName);
	        logger.info("bankType :"+bankType);
	        logger.info("userRole :"+userRole);
	        logger.info("functionType :"+functionType);
	        logger.info("actionType :"+actionType);
	        logger.info("userName :"+userName+"tpName :" + fileName +"bankType :"+bankType);
	        
	        try
	        {
	            if (userName != null && !userName.equals("")&& filename != null )
	            {
                  // modified for default file config module starts here
	            	 if (fileName != null && fileName.trim().length() > 0)
                     { 
	            		  if(actionType.equalsIgnoreCase("AppInterBankBenFile")){
	            			  status = externalthirdPartyDAOImpl.updateTPStateALL(userName, filename, bankType, corporateId);
	            		  }else if(actionType.equalsIgnoreCase("AppThirdPartyBenFile")){ //Added by Sairam Mobile Registration Phase2 
	            			  status = externalthirdPartyDAOImpl.approveTPFile(userName, filename);  
	            		  }else if(actionType.equalsIgnoreCase("AppManagePrepaidCard")){
	            			  status = externalthirdPartyDAOImpl.approvePrepaidBenFile(userName, filename,corporateId);
	            		  }else if(actionType.equalsIgnoreCase("RejectInterBankBenFile")){ // Added for Reject Inter Bank Beneficiary File
	            			  status = externalthirdPartyDAOImpl.rejectTPStateALL(userName, filename, bankType, corporateId);
	            		  }else if(actionType.equalsIgnoreCase("RejectIntraBankBenFile")){ // Added for Reject Intra Bank Beneficiary File
	            			  status = externalthirdPartyDAOImpl.rejectTPFile(userName, filename);  
	            		  }
	            		  
                     }
	            	 logger.info("status :" + status);
	            	 if(status){
	            		 response.setErrorStatus("success");
	            		
	            	 }else{
	            		 response.setErrorCode("CR002");
	            	 }
	            	 
	            	/*	 status = externalthirdPartyDAOImpl.updateTPStateALL(userName, filename, bankType);
	                    logger.info("status :" + status);
	                    
	                  if(status){
	                	  if (fileName != null && fileName.trim().length() > 0)
	                        { 
	                		  if(actionType.equalsIgnoreCase("AppInterBankBenFile")){
	                          corporateTP = externalthirdPartyDAOImpl.findTPsByFile(userName, filename, userRole,bankType,functionType);
	                		  }else if(actionType.equalsIgnoreCase("AppThirdPartyBenFile")){
	                			  flag = externalthirdPartyDAOImpl.approveTPFile(userName, filename);
	                			  
	                			  if(flag){
	                				  response.setErrorStatus("success");
	                			  }else{
	                				  response.setErrorCode("CR002");
	                			  }
	                		  }
	                        }
	                	  
	                	  logger.info("corporateTP.length  " + corporateTP.length);
                          // modified for default file config module ends here
                          if (corporateTP.length >= 1)
                          {
                              List unApprovedList = new ArrayList();
                              List approvedList = new ArrayList();

                              if (corporateTP != null)
                              {
                                  outParam.put("approveTPFileConfirmDetails", corporateTP);

                                  for (int j = 0; j < corporateTP.length; j++)
                                  {

                                      CorporateTP c = corporateTP[j];
                                      if (c.getStatus().toString().equals("1") )
                                      {
                                          unApprovedList.add(c);

                                      }
                                      else
                                      {
                                          approvedList.add(c);
                                      }

                                  }
                                  if(bankType.equalsIgnoreCase("DIBTP")){
                                      unApprovedList=null;
                                  }
                                  outParam.put("unApprovedList", unApprovedList);
                                  outParam.put("approvedList", approvedList);
                                  logger.info("unApprovedList :"+unApprovedList.size());
                                  logger.info("approvedList :"+approvedList.size());
                                 // outParam.put("approveall", approveall);
                                  //logger.info("approveall ::::;;;;;;;;;;;"+approveall);
                                  if(unApprovedList != null && approvedList != null)
                                  logger.info("approvedList :"+approvedList.size()+"unApprovedList :"+unApprovedList.size());
                                  response.setErrorStatus("success");
                              }
                              else
                              {
                                  response.setErrorCode("CR001");
                              }
                          }
	                	  
	                  }   */
	                 /*   if (status)
	                    {

	                        if (fileName != null && fileName.trim().length() > 0)
	                        {
	                          
	                            if (bankType.equalsIgnoreCase("DIBTP"))
	                            {
	                                corporateTP = externalthirdPartyDAOImpl.findTPsByFileConfirm(apprIds,userName, filename,
	                                        userRole, bankType);
	                            }
	                            else
	                            {
	                                corporateTP = externalthirdPartyDAOImpl.findTPsByFile(userName, filename, userRole,
	                                        bankType,functionType);
	                            }
	                            logger.info("corporateTP.length  " + corporateTP.length);
	                            // modified for default file config module ends here
	                            if (corporateTP.length >= 1)
	                            {
	                                List unApprovedList = new ArrayList();
	                                List approvedList = new ArrayList();

	                                if (corporateTP != null)
	                                {
	                                    outParam.put("approveTPFileConfirmDetails", corporateTP);

	                                    for (int j = 0; j < corporateTP.length; j++)
	                                    {

	                                        CorporateTP c = corporateTP[j];
	                                        if (c.getStatus().toString().equals("1") )
	                                        {
	                                            unApprovedList.add(c);

	                                        }
	                                        else
	                                        {
	                                            approvedList.add(c);
	                                        }

	                                    }
	                                    if(bankType.equalsIgnoreCase("DIBTP")){
	                                        unApprovedList=null;
	                                    }
	                                    outParam.put("unApprovedList", unApprovedList);
	                                    outParam.put("approvedList", approvedList);
	          //                          outParam.put("approveall", approveall);
	            //                        logger.info("approveall ::::;;;;;;;;;;;"+approveall);
	                                    if(unApprovedList != null && approvedList != null)
	                                    logger.info("approvedList :"+approvedList.size()+"unApprovedList :"+unApprovedList.size());
	                                    response.setErrorStatus("success");
	                                }
	                                else
	                                {
	                                    response.setErrorCode("CR001");
	                                }
	                            }
	                        }
	                        else
	                        {
	                            response.setErrorCode("CR002");
	                        }
	                    }*/
	            }else
		                {

		                    response.setErrorCode("CR002");
		                }
	             
	                
	           
	        }
	        catch (SBIApplicationException appex)
	        {
	            response.setErrorStatus("failure");
	            logger.error(LoggingConstants.EXCEPTION + appex);
	            response.setErrorCode(appex.getErrorCode());
	        }
	        catch (DAOException daoException)
	        {
	            response.setErrorStatus("failure");
	            response.setErrorCode(daoException.getErrorCode());
	            logger.error(LoggingConstants.EXCEPTION, daoException);
	        }
	        catch (Exception exp)
	        {
	            response.setErrorStatus("failure");
	            response.setErrorCode("SE002");
	            logger.error(LoggingConstants.EXCEPTION + exp);

	        }
	        outParam.put("filename", filename);
	        outParam.put("applicationResponse", response);

	        return outParam;
	    }

	    
	    
	    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl) {
			this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
		}
	    

		public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl) {
			this.thirdPartyDAOImpl = thirdPartyDAOImpl;
		}


}
