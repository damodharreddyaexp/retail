package com.sbi.common.rtgs.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.PrePaidCardBeneficiary;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class ApprovePrepaidFileViewService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO externalthirdPartyDAOImpl;


    public Map execute(Map inputParam) {
        logger.debug("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        String fileName = "";
        String userName = "";
        PrePaidCardBeneficiary[] prePaidCardBeneficiary;
        fileName = (String) inputParam.get("tpFileName");
        Integer userRole=(Integer)inputParam.get("userRole");
        userName = (String) inputParam.get("userName");
        String bankType = (String) inputParam.get("bankType");
        logger.info("userRole :" + userRole+"bankType :"+bankType+"fileName :"+fileName);
        int index = fileName.indexOf('.');
        String name = fileName.substring(0, index);
           try {
            if (fileName != null
                    && !fileName.trim().equals("")
                    && userName != null
                    && !userName.trim().equals("")) {
            	prePaidCardBeneficiary = externalthirdPartyDAOImpl.findPCsByFileView(userName,name,userRole,bankType);
                if (prePaidCardBeneficiary != null && prePaidCardBeneficiary.length > 0) {
                       
                        
                    outParam.put("approveTPFileDetails", prePaidCardBeneficiary);
                    outParam.put("totalFileDetails",new Integer(prePaidCardBeneficiary.length));
                    logger.info("databaseRecordsLength=="+prePaidCardBeneficiary.length);
                    response.setErrorStatus("success");
                } else {
                    response.setErrorCode("RTGS001");
                }
            } else {
                response.setErrorStatus("RTGS002");
            }
        } catch (SBIApplicationException appex) {
        	response.setErrorStatus("failure");
            response.setErrorCode(appex.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION , appex);
        } catch (Exception exp) {
            response.setErrorStatus("failure");
            response.setErrorCode("SE002");
        	logger.error(LoggingConstants.EXCEPTION, exp);
        }

        outParam.put("applicationResponse", response);
        logger.debug("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParam;


    }


    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }
    
}
