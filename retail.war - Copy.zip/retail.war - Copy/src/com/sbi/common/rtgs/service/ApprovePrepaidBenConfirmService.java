/*
 * ApprovePrepaidBenConfirmService.java
 * Created on Jan '09 by Madhan Kumar.B
 *
 * Copyright (c) 2009 by SBI All Rights Reserved.
 */

package com.sbi.common.rtgs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.rtgs.model.PrePaidCardBeneficiary;
import com.sbi.common.utils.LoggingConstants;

public class ApprovePrepaidBenConfirmService extends BaseService
{

    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO externalthirdPartyDAOImpl;

    /**
     * call the [thirdPartyDAOImpl.updateTPState(apprIds,unApprIds,
     * userName,banktype),updateTPStateALL(apprIds,unApprIds, userName)] to get the
     * ApproveFile Details return objectArray which is contains ApproveTpFile
     * Approve and UnApprove Details.
     * 
     * @param inputParams
     * @return Map
     * 
     */

    public Map execute(Map inputParam)
    {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        Map resultMap = new HashMap();
        List rejectedRecords=null;
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        String apprIds = null;
        String unApprIds = null;
        boolean status = false;
        Integer userRole = (Integer) inputParam.get("userRole");
        PrePaidCardBeneficiary[] prePaidCardBeneficiary = null;
       Object obapprId = null;
        Object obunApprId = null;
        Object approveIds = inputParam.get("approveIds");
        Object unApproveIds = inputParam.get("unApproveIds");
        Object approvedIds = inputParam.get("approvedIds");
        Object unApprovedIds = inputParam.get("unApprovedIds");
        if (approveIds != null && unApproveIds != null)
        {
        	 obapprId = inputParam.get("approveIds");
              obunApprId = inputParam.get("unApproveIds");
        }else{
        	 obapprId = inputParam.get("approvedIds");
            obunApprId = inputParam.get("unApprovedIds");
        }
        String fileName = (String) inputParam.get("tpFileName");
        int index = fileName.indexOf('.');
        String filename = fileName.substring(0, index);
        String userName = (String) inputParam.get("userName");
        String approveall = (String) inputParam.get("Approveflag");
        String bankType = (String) inputParam.get("bankType");// added for default file config
        String functionType = (String) inputParam.get("functionType");
        String actionType = (String) inputParam.get("actionType");
        /* Ramanan M - Corp Admin Paladion Security Changes */
        String corporateID = (String) inputParam.get("coporateID");
        logger.info("tpName :" + fileName +"bankType :"+bankType+"functionType :"+functionType+"actionType :"+actionType + " corporateID: " +corporateID);
        try
        {
            if (userName != null && !userName.equals(""))
            {

                if (obapprId != null && obunApprId != null)
                {
                    apprIds = (String) obapprId;
                    unApprIds = (String) obunApprId;
                    logger.info(" apprIds  " +apprIds);
                    logger.info("approveall: "+approveall);
                    if (approveall != null && approveall.equalsIgnoreCase("true") )
                    {
                    	/* Ramanan M - Corp Admin Paladion Security Changes */
                  		status = externalthirdPartyDAOImpl.updatePrepaidBenAll(userName, filename, bankType,actionType,corporateID);
                    }
                    else
                    {
                    	/* Ramanan M - Corp Admin Paladion Security Changes */
                    	resultMap = externalthirdPartyDAOImpl.updatePrepaidBen(apprIds, unApprIds, userName, bankType,actionType,corporateID);
                   		Boolean tempBoolean = ((Boolean)resultMap.get("status"));
                   		if(tempBoolean !=null)
                   			status=tempBoolean.booleanValue();
                   		else 
                   			status=false;
                   		rejectedRecords = (List)resultMap.get("rejectedRecords");
                   		if(rejectedRecords!=null)
                   			logger.info("rejectedRecords size: "+rejectedRecords.size());
                   		else
                   			logger.info("No rejected records");
                    }

                    logger.info("status :" + status);
                    if (status)
                    {
                        if (fileName != null && fileName.trim().length() > 0)
                        {
                            	prePaidCardBeneficiary = externalthirdPartyDAOImpl.findApprUnapprByFile(userName,filename,userRole,bankType,functionType);
                                logger.info("prePaidCardBeneficiary.length  " + prePaidCardBeneficiary.length);
                                List unApprovedList = new ArrayList();
                                List approvedList = new ArrayList();
                                if (prePaidCardBeneficiary != null && prePaidCardBeneficiary.length >= 1)
                                {
                                        outParam.put("approveTPFileConfirmDetails", prePaidCardBeneficiary);
                                        String[] approveIdArray=StringUtils.tokenizeToStringArray(apprIds,",");
                                        String[] unapproveIdArray=StringUtils.tokenizeToStringArray(unApprIds,",");
                                        if(logger.isDebugEnabled()){
                                        	logger.debug("approveIdArray size::: "+approveIdArray.length);
                                        	logger.debug("unapproveIdArray size::: "+unapproveIdArray.length);
                                        }
                                        
                                        for (int j = 0; j < prePaidCardBeneficiary.length; j++)
                                        {

                                        	PrePaidCardBeneficiary c = prePaidCardBeneficiary[j];
                                            if (c.getCardStatus().equals("PSG_OUT") )
                                            {
                                                unApprovedList.add(c);

                                            }//check with user selected status 
                                            else if (c.getCardStatus().equals("APPROVED"))
                                            {
                                            	if("true".equals(approveall))
                                            	{
                                            		for(int k=0;k<unapproveIdArray.length;k++){
                                            		 if(logger.isDebugEnabled()){
                                            				 logger.debug("unapproveIdArray[ "+k+" ]: "+unapproveIdArray[k]);
                                            				 logger.debug("c.getId: "+"'"+c.getId()+"'");
                                            			 }
                                        			if(("'"+c.getId()+"'").equals(unapproveIdArray[k])){
                                        				approvedList.add(c);
                                        			}
                                            		}
                                            	}else{
                                            		for(int k=0;k<approveIdArray.length;k++){
                                            			 if(logger.isDebugEnabled()){
                                            				 logger.debug("approveIdArray[ "+k+" ]: "+approveIdArray[k]);
                                            				 logger.debug("c.getId: "+"'"+c.getId()+"'");
                                            			 }
                                            			if(("'"+c.getId()+"'").equals(approveIdArray[k])){
                                            				approvedList.add(c);
                                            				break;
                                            			}
                                            		}
                                            	}
                                            }
                                        }
                                        if (rejectedRecords!=null && actionType.equals("REJECTED")){
                                        	logger.debug("partial rejected case");
                                        	for(int i=0;i<rejectedRecords.size();i++){
                                        		PrePaidCardBeneficiary rejRec=(PrePaidCardBeneficiary)rejectedRecords.get(i);
                                        		rejRec.setCardStatus("REJECTED");
                                        		approvedList.add(rejRec);
                                        	}
                                        }
                                        outParam.put("unApprovedList", unApprovedList);
                                        outParam.put("approvedList", approvedList);
                                        outParam.put("approveall", approveall);
                                        if(unApprovedList != null && approvedList != null)
                                        logger.info("approvedList :"+approvedList.size()+"unApprovedList :"+unApprovedList.size());
                                        response.setErrorStatus("success");

                                }else{
                                	//may be everything is rejected 
                                	logger.debug("all rejected case");
                                    if (rejectedRecords!=null && actionType.equals("REJECTED")){
                                    	for(int i=0;i<rejectedRecords.size();i++){
                                    		PrePaidCardBeneficiary rejRec=(PrePaidCardBeneficiary)rejectedRecords.get(i);
                                    		rejRec.setCardStatus("REJECTED");
                                    		approvedList.add(rejRec);
                                    	}
                                    }
                                    outParam.put("unApprovedList", unApprovedList);
                                    outParam.put("approvedList", approvedList);
                                    outParam.put("approveall", approveall);
                                    if(unApprovedList != null && approvedList != null)
                                    logger.info("approvedList :"+approvedList.size()+"unApprovedList :"+unApprovedList.size());
                                    response.setErrorStatus("success");
                                }
                        }
                        else
                        {
                            response.setErrorCode("CR002");
                        }
                    }
                    else
                    {
                        response.setErrorCode("CR011");

                    }
                }
                else
                {

                    response.setErrorCode("CR002");
                }
            }

            else
            {

                response.setErrorCode("CR002");
            }
        }
        catch (SBIApplicationException appex)
        {
        	response.setErrorStatus("failure");
            response.setErrorCode(appex.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION , appex);
        }
        catch (DAOException daoException)
        {
            response.setErrorStatus("failure");
            response.setErrorCode(daoException.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, daoException);
        }
        catch (Exception exp)
        {
            response.setErrorStatus("failure");
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION , exp);

        }

        outParam.put("applicationResponse", response);

        return outParam;
    }

    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }

}
