/*
 * ApproveTPConfirmService.java
 * Created on Jan '08 by Treesa
 *
 * Copyright (c) 2008 by SBI All Rights Reserved.
 */

package com.sbi.common.rtgs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.utils.LoggingConstants;

public class ApproveTPConfirmService extends BaseService
{

    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO externalthirdPartyDAOImpl;

    /**
     * call the [thirdPartyDAOImpl.updateTPState(apprIds,unApprIds,
     * userName,banktype),updateTPStateALL(apprIds,unApprIds, userName)] to get the
     * ApproveFile Details return objectArray which is contains ApproveTpFile
     * Approve and UnApprove Details.
     * 
     * @param inputParams
     * @return Map
     * 
     */

    public Map execute(Map inputParam)
    {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        String apprIds = null;
        String unApprIds = null;
        boolean status = false;
        Integer userRole = (Integer) inputParam.get("userRole");
        CorporateTP[] corporateTP = null;
        Object obapprId = null;
        Object obunApprId = null;
        Object approveIds = inputParam.get("approveIds");
        Object unApproveIds = inputParam.get("unApproveIds");
        Object approvedIds = inputParam.get("approvedIds");
        Object unApprovedIds = inputParam.get("unApprovedIds");
        Object actionType=inputParam.get("actionType"); //Added for Reject Benificiary File
        String actionTypeStr="";
        if(actionType!=null)
        	actionTypeStr=actionType.toString();
        
       // Object obapprId = inputParam.get("approveIds");
      //  Object obunApprId = inputParam.get("unApproveIds");
//        <!-- Ramanan M - SR-88046 - Delete3P Defect-->
		if (approveIds != null && unApproveIds != null
				//condition changed for SR93990 starts here
				&& (approveIds.toString().length() > 0
				|| unApproveIds.toString().length() > 0)) {
			//condition changed for SR93990 ends here
         obapprId = inputParam.get("approveIds");
         obunApprId = inputParam.get("unApproveIds");
        }else{
        	obapprId = inputParam.get("approvedIds");
            obunApprId = inputParam.get("unApprovedIds");
        }
        String fileName = (String) inputParam.get("tpFileName");
        int index = fileName.indexOf('.');
        String filename = fileName.substring(0, index);
        String userName = (String) inputParam.get("userName");
        String approveall = (String) inputParam.get("Approveflag");
        String bankType = (String) inputParam.get("bankType");// added for default file config
        String functionType = (String) inputParam.get("functionType");
        /* Ramanan M - Corp Admin Paladion Security Changes */
        String corporateID = (String) inputParam.get("coporateID");
        logger.info("tpName :" + fileName +"bankType :"+bankType+"functionType :"+functionType+ " coporateID:" + corporateID);
        logger.info("obapprId : " + obapprId);
        logger.info("obunApprId : " + obunApprId);
        try
        {
            if (userName != null && !userName.equals(""))
            {

                if (obapprId != null && obunApprId != null)
                {
                    apprIds = (String) obapprId;
                    unApprIds = (String) obunApprId;
                    logger.info(" apprIds  " +apprIds);

                    if (approveall != null && approveall.equalsIgnoreCase("true") ){
                        // modified for default file config module starts here
                    	/* Ramanan M - Corp Admin Paladion Security Changes */
                        status = externalthirdPartyDAOImpl.updateTPStateALL(userName, filename, bankType, corporateID);
                    }else{
                    	/* Ramanan M - Corp Admin Paladion Security Changes */
                		if("Reject".equals(actionTypeStr))
                			status = externalthirdPartyDAOImpl.rejectTPState(apprIds, userName, bankType, corporateID);
                		else
                    		status = externalthirdPartyDAOImpl.updateTPState(apprIds, unApprIds, userName, bankType, corporateID);
                    }
                    logger.info("status :" + status);
                    if (status)
                    {

                        if (fileName != null && fileName.trim().length() > 0)
                        {
                          
                            if (bankType.equalsIgnoreCase("DIBTP"))
                            {
                                corporateTP = externalthirdPartyDAOImpl.findTPsByFileConfirm(apprIds,userName, filename,
                                        userRole, bankType);
                            }
                            else
                            {
                                corporateTP = externalthirdPartyDAOImpl.findTPsByFile(userName, filename, userRole,
                                        bankType,functionType);
                            }
                            logger.info("corporateTP.length  " + corporateTP.length);
                            // modified for default file config module ends here
                            if (corporateTP.length >= 1)
                            {
                                List unApprovedList = new ArrayList();
                                List approvedList = new ArrayList();
                                List rejectedList = new ArrayList();
                                if (corporateTP != null)
                                {
                                    outParam.put("approveTPFileConfirmDetails", corporateTP);

                                    for (int j = 0; j < corporateTP.length; j++)
                                    {

                                        CorporateTP c = corporateTP[j];
                                        if (c.getStatus().toString().equals("1") )
                                        {
                                            unApprovedList.add(c);

                                        }
                                        else if (c.getStatus().toString().equals("2"))
                                        {
                                        	rejectedList.add(c);
                                        }
                                        else
                                        {
                                            approvedList.add(c);
                                        }

                                    }
                                    if(bankType.equalsIgnoreCase("DIBTP")){
                                        unApprovedList=null;
                                    }
                                    outParam.put("unApprovedList", unApprovedList);
                                    outParam.put("approvedList", approvedList);
                                    outParam.put("rejectedList", rejectedList);
                                    outParam.put("approveall", approveall);
                                    logger.info("approveall ::::;;;;;;;;;;;"+approveall);
                                    if(unApprovedList != null && approvedList != null)
                                    logger.info("approvedList :"+approvedList.size()+"unApprovedList :"+unApprovedList.size());
                                    if(rejectedList != null)
                                        logger.info("rejectedList :"+rejectedList.size());
                                    response.setErrorStatus("success");
                                }
                                else
                                {
                                    response.setErrorCode("CR001");
                                }
                            }
                            else
                            {
                            	response.setErrorStatus("success");
                            }
                        }
                        else
                        {
                            response.setErrorCode("CR002");
                        }
                    }
                    else
                    {
                        response.setErrorCode("CR011");

                    }
                }
                else
                {

                    response.setErrorCode("CR002");
                }
            }

            else
            {

                response.setErrorCode("CR002");
            }

        }
        catch (SBIApplicationException appex)
        {
            response.setErrorStatus("failure");
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        }
        catch (DAOException daoException)
        {
            response.setErrorStatus("failure");
            response.setErrorCode(daoException.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, daoException);
        }
        catch (Exception exp)
        {
            response.setErrorStatus("failure");
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);

        }

        outParam.put("applicationResponse", response);

        return outParam;
    }

    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }

}
