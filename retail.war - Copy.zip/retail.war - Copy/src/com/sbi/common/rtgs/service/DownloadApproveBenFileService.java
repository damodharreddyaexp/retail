/* 
 * ApproveTPFileService.java
 * Created on  Jan '08 by Treesa.
 *
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * $Header: $
 */


package com.sbi.common.rtgs.service;
      
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.utils.LoggingConstants;

public class DownloadApproveBenFileService extends BaseService {

    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO externalthirdPartyDAOImpl;

    
     /**
     * call the [thirdPartyDAOImpl.findTPsByFile(userName,name,userRole,bankType,functionType)] to get the ApproveFile Details
     * return objectArray which is contains ApproveTpFile Approve and UnApprove Details.
     * 
     * @param inputParams
     * @return Map
     * 
     */
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        String fileName = "";
        String userName = "";
        CorporateTP[] corporateTP= null;
        fileName = (String) inputParam.get("fileName");
        Integer userRole=(Integer)inputParam.get("userRole");
        userName = (String) inputParam.get("userName");
        String bankType = (String) inputParam.get("bankType");//added for default file config
        String functionType = (String) inputParam.get("functionType");
        logger.info("userRole :" + userRole+"bankType :"+bankType+"functionType :"+functionType+"fileName :"+fileName);
        int index = fileName.indexOf('.');
        String name =""; 
       
        try {
            if (fileName != null
                    && !fileName.trim().equals("")
                    && userName != null
                    && !userName.trim().equals("")) {
            	if(index != -1){
            	name = fileName.substring(0, index);
            	}else{
            		name = fileName;
            	}
           
            	corporateTP = externalthirdPartyDAOImpl.findTPsByFile(userName,name,userRole,bankType,functionType);
                logger.info("corporateTP Length :"+corporateTP.length);
                if (corporateTP != null && corporateTP.length > 0) {
                    outParam.put("approveTPFileDetails", corporateTP);
                    response.setErrorStatus("success");
                } else {
                    response.setErrorCode("RTGS001");
                }
            } else {
                response.setErrorStatus("RTGS002");
            }
        } catch (SBIApplicationException appex) {
            response.setErrorStatus("failure");
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorStatus("failure");
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put("applicationResponse", response);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParam;

    }

    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }
    
}
