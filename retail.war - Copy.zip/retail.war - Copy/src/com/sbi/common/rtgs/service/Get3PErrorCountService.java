package com.sbi.common.rtgs.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;





public class Get3PErrorCountService extends BaseService {
	protected static Logger logger = Logger.getLogger(Get3PErrorCountService.class);
	
	 private ThirdPartyDAO externalthirdPartyDAOImpl;
	
	public Map execute(Map inParams) {
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String filename  = (String)inParams.get("tpFileName");
			String fileno = filename.substring(0, filename.length()-4);
			logger.info("filename"+filename);
			String  Countval = null;
			if(filename != null ){
				Countval = externalthirdPartyDAOImpl.findErrorCount(fileno);
				outParams.put("Countval",Countval);
			}else{
				response.setErrorCode("SUV001");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParams;
	}
	
	 public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
	    {
	        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
	    }
}
