/* 
 * ApproveTPService.java
 * Created on  Jan 08 by Treesa
 *
 *  This service is used to display the Files Uploaded.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */



package com.sbi.common.rtgs.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateFile;



/**
 * This class used for to display the ApproveThirdParty Information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class ApproveTPService extends BaseService {

    private ThirdPartyDAO externalthirdPartyDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    
     /**
     * call the [thirdPartyDAOImpl.findTPFiles(userName,userRole,bankType,startDate,endDate,functiontype)] return Map which is contains 
     * ApproveTpFile Names.
     * 
     * @param inputParams userName,userRole,bankType,startDate,endDate and functiontype
     * @return Map
     * 
     */
 
    public Map execute(Map inputParam) {
        logger.debug("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);

        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        Integer userRole=(Integer)inputParam.get("userRole");
        String userName = (String) inputParam.get("userName");
        String bankType = (String) inputParam.get("bankType");
        String startDate = (String) inputParam.get("startDate");
        String endDate = (String) inputParam.get("endDate");
        String functionType = (String) inputParam.get("functionType");
        CorporateFile[] corporateFile = null;
        try {
          
            if (userName != null
                    && userName.trim().length() > 0 ) {
                corporateFile = externalthirdPartyDAOImpl.findTPFiles(userName,userRole,bankType,startDate,endDate,functionType);//modified by siva for default file config module
                
                if (corporateFile != null && corporateFile.length >0) {
                    outParam.put("approveTPFileDetails", corporateFile);
                    response.setErrorStatus("success");
                } else {
                	if(("PC".equals(bankType)) || ("SMT".equals(bankType)) || ("UAE".equals(bankType))) // Added for Pre Paid Card Module
                		response.setErrorCode("PC002"); //Added for Pre Paid Card Module
                	else
                    response.setErrorCode("RTGS003"); //There are no Inter bank beneficiary files for approval.
                }

            } else {
                response.setErrorStatus("CR002");//Request cannot be processed currently
            }
        } catch (SBIApplicationException appex) {
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put("applicationResponse", response);
        if(logger.isDebugEnabled()){
        	logger.debug("outParam :" + outParam);
        	logger.debug("execute(Map inputParams)" + LoggingConstants.METHODEND);
        }

        return outParam;

    }


    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }

    

}
