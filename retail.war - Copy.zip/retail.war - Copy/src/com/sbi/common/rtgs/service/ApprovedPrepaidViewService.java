package com.sbi.common.rtgs.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.rtgs.dao.ThirdPartyDAO;
import com.sbi.common.rtgs.model.CorporateFile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class ApprovedPrepaidViewService extends BaseService{
	private ThirdPartyDAO externalthirdPartyDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());
    
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);

        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        Integer userRole=(Integer)inputParam.get("userRole");
        String userName = (String) inputParam.get("userName");
        String bankType = (String) inputParam.get("bankType");
        CorporateFile[] corporateFile = null;
        logger.info("Executing PC service for banktype " +bankType );
        try {
          
            if (userName != null
                    && userName.trim().length() > 0 ) {
                corporateFile = externalthirdPartyDAOImpl.findTPFilesView(userName,userRole,bankType);
                
                if (corporateFile != null && corporateFile.length >0) {
                    outParam.put("approveTPFileDetails", corporateFile);
                    response.setErrorStatus("success");
                } else {
                	if(("PC".equals(bankType)) || ("SMT".equals(bankType)) || ("UAE".equals(bankType))) // Added for Mobile Reg Phase 2
                		response.setErrorCode("PC003");
                	else
                        response.setErrorCode("RTGS004");//There are no Inter bank beneficiary files approved.
                }

            } else {
                response.setErrorStatus("CR002");//Request cannot be processed currently
            }
        } catch (SBIApplicationException appex) {
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put("applicationResponse", response);
        if(logger.isDebugEnabled()){
        	logger.debug("outParam :" + outParam);
        	logger.debug("execute(Map inputParams)" + LoggingConstants.METHODEND);
        }

        return outParam;

    }


    public void setExternalthirdPartyDAOImpl(ThirdPartyDAO externalthirdPartyDAOImpl)
    {
        this.externalthirdPartyDAOImpl = externalthirdPartyDAOImpl;
    }

}
