/*
 * ThirdPartyDAO.java
 * Created on Dec 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 9, 2005 SG33414 - Initial Creation
package com.sbi.common.rtgs.dao;


import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.rtgs.model.CorporateFile;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.rtgs.model.PrePaidCardBeneficiary;


public interface ThirdPartyDAO {
    
   
    /**
     * Method is used to find the files pending to approval or delete for third parties 
     * passing Map as a inparam which has userName, bankType, startDate,endDate and functionType
     * 
     * */
//  modified by siva for default file config module starts here
    public CorporateFile[] findTPFiles(String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType);

    /**
     * Method is used to find the contents of the files pending to approval or delete for third parties 
     * passing Map as a inparam which has userName, fileName, bankType and functionType
     * 
     * */
    public CorporateTP[] findTPsByFile(String userName, String fileName,Integer userRole,String bankType,String functionType);
    /**
     * Method is used to exclusively for DIBTP to show the status of the thirdparty to the user. 
     * passing Map as a inparam which has approvedOIDs,userName, fileName, bankType and functionType
     * 
     * */
    public CorporateTP[] findTPsByFileConfirm(String approvedOIDs, String userName, String fileName,Integer userRole,String bankType);
    /**
     * Method is used to update the status of the thirdparty for approving or deleting. 
     * passing Map as a inparam which has approvedOIDs,userName, fileName and bankType.
     * 
     * */
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean updateTPState(String approvedOIDs, String unApproveOIds_arr, String userName,String bankType, String corporateID);
    /**
     * Method is used for updating thr bulk records at a once for approving or deleting. 
     * passing Map as a inparam which has approvedOIDs,userName, fileName and bankType with corporateID.
     * 
     * */
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean updateTPStateALL(String userName,String filename,String bankType, String corporateID);
    
//  modified by siva for default file config module ends here     
    Map findHoliday(String DateTime,String merchantCode,String bankCode) throws DAOException;
    
    //Added for Prepaid card Module
    public PrePaidCardBeneficiary[] findPCsByFile(String userName, String fileName, Integer userRole, String bankType,
            String functionType);
    public PrePaidCardBeneficiary[] findApprUnapprByFile(String userName, String fileName, Integer userRole, String bankType,
            String functionType);
    public boolean updatePrepaidBenAll(String userName,String filename,String bankType,String actionType, String corporateID);
    public Map updatePrepaidBen(String approvedOIDs, String unApproveOIds_arr, String userName,String bankType,String actionType, String corporateID);
    //End Module
    
    // Added by Sairam Mobile Registration Phase2 - Start-->
   
    public boolean approveTPFile(String userName,String fileName);
    public boolean approvePrepaidBenFile(String userName,String fileName,String corporateID);
    
    //Added by Sairam Mobile Registration Phase2 - End-->

    public CorporateFile[] findTPFilesView(String userName, Integer userRole,
			String bankType);

	public PrePaidCardBeneficiary[] findPCsByFileView(String userName,
			String name, Integer userRole, String bankType);
	
	// Added for Reject Inter Bank Benificiary File - Start
	public boolean rejectTPStateALL(String userName,String filename,String bankType, String corporateID);
	public boolean rejectTPState(String rejectedOIDs, String userName,String bankType, String corporateID);
	// Added for Reject Inter Bank Beneficiary File - End
	
	// Added for Reject Intra Bank Benificiary File - Start
	public boolean rejectTPFile(String userName,String fileName);
	// Added for Reject Intra Bank Beneficiary File - End
	
	//Find error count
	
	public String findErrorCount(String fileno) throws DAOException;
	

    
}
