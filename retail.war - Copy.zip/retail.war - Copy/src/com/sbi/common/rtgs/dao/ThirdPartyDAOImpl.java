/*
 * ThirdPartyDAOImpl.java
 * Created on JAN '08 by Treesa
 *This class is common to Regulator,Admin and Approver
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */
//History
//JAN '08  - Initial Creation
package com.sbi.common.rtgs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.rtgs.model.CorporateFile;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.rtgs.model.PrePaidCardBeneficiary;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;


public class ThirdPartyDAOImpl extends JdbcDaoSupport implements ThirdPartyDAO
{

    protected final Logger logger = Logger.getLogger(getClass());

 //Added for mobile Resgistration Phase2-Sulthan
//    private static final String CORPORATE_FILE_VIEW="SELECT * FROM SBI_FILE_MASTER SFM WHERE FILE_STATUS = 'Processed' " +
//    		"AND UPPER (ADDITIONAL_FIELD5) =? AND ( NOT EXISTS (select 1 from sbi_rtgs_beneficiary d where d.file_sno = sfm.sno and status in ('Pending','pending_approval','inactive'))) " +
//    		"AND ( EXISTS (select 1 from sbi_rtgs_beneficiary d where d.file_sno = sfm.sno))"+
//    		"AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B WHERE A.USER_ID = B.USER_ID AND B.CREATED_BY_BRANCH =? " +
//    		"AND A.USER_ALIAS = SFM.USERNAME) OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C WHERE C.CA_USER =? " +
//    		"AND C.USER_NAME = SFM.USERNAME)) order by sfm.creation_time desc"; 
    private static final String CORPORATE_FILE_VIEW="SELECT * FROM SBI_FILE_MASTER SFM WHERE FILE_STATUS = 'Processed' " +
		"AND UPPER (ADDITIONAL_FIELD5) =? " +
		"AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B WHERE A.USER_ID = B.USER_ID AND B.CREATED_BY_BRANCH =? " +
		"AND A.USER_ALIAS = SFM.USERNAME) OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C WHERE C.CA_USER =? " +
		"AND C.USER_NAME = SFM.USERNAME)) order by sfm.creation_time desc"; 

 // Added for Reject Inter Bank Beneficiary File --for file view operation
    private static final String CORPORATE_BEN_FILE_VIEW="SELECT file_no,file_name, creation_time,username, SUM(active) ACTIVE_COUNT,SUM(inactive) INACTIVE_COUNT,SUM(REJECTED) REJECTED_COUNT,SUM(pending_approval) PENDING_COUNT "+
		" FROM ( SELECT sfm.sno file_no,sfm.file_name,sfm.creation_time,sfm.username, decode(srb.status,'active',1,0) active,decode(srb.status,'inactive',1,0) inactive,decode(upper(srb.status),'REJECTED',1,0) REJECTED, "+
		" decode(srb.status,'pending_approval',1,0) pending_approval "+
		" FROM SBI_FILE_MASTER SFM ,sbi_rtgs_beneficiary srb "+
		" WHERE FILE_STATUS = 'Processed' "+
		" AND sfm.sno = srb.file_sno "+
		" AND UPPER (ADDITIONAL_FIELD5) =? "+ 
		" AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B WHERE A.USER_ID = B.USER_ID AND B.CREATED_BY_BRANCH =? "+
		" AND A.USER_ALIAS = SFM.USERNAME) OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C WHERE C.CA_USER =? "+
		" AND C.USER_NAME = SFM.USERNAME)) "+
		" ) group by file_no,file_name,creation_time,username order by creation_time desc"; // modify for the CR by krishna
    
   /* Added by Sairam Mobile Registration Phase2 - Start */
    
  /*  private static final String CORPORATE_FILE = "SELECT * FROM sbi_file_master sfm "
            + "WHERE file_status = 'Processed'  AND UPPER (additional_field5) =? AND "
            + "( EXISTS ( SELECT 1 FROM bv_user a, bv_user_profile b"
            + " WHERE a.user_id = b.user_id  AND b.created_by_branch = ?" + " AND a.user_alias = sfm.username)"
            + " OR EXISTS (SELECT 1 " + "FROM sbicorp_ca_user_map c"
            + " WHERE c.ca_user = ? AND c.user_name = sfm.username))";*/
    
    
    private static final String CORPORATE_FILE = "SELECT sno, file_name, username, creation_time,FILE_STATUS," +
    		"(select decode(count(1),'0' ,'Y','N') from sbi_rtgs_beneficiary h where h.file_sno = sfm.sno " +
    		"  and status = 'pending_approval' ) FILESTAT FROM sbi_file_master sfm WHERE file_status = 'Processed'" +
    		"  AND UPPER (additional_field5) =? AND( EXISTS ( SELECT 1 FROM bv_user a, bv_user_profile b" +
    		" WHERE a.user_id = b.user_id  AND b.created_by_branch =? AND a.user_alias = sfm.username)OR " +
    		"EXISTS (SELECT 1 FROM sbicorp_ca_user_map c WHERE c.ca_user = ? " +
    		"AND c.user_name = sfm.username)) order by sfm.creation_time asc"; //Corp Admin Change

    // Added for Enhancement of approve beneficiary IOCL � Phase II
    private static final String CORPORATE_FILE_ADMIN = "SELECT sno, file_name, username, creation_time,FILE_STATUS," +
                  "(select decode(count(1),'0' ,'Y','N') from sbi_rtgs_beneficiary h " +
                  "where h.file_sno = sfm.sno and status = 'pending_approval') FILESTAT  " +
           "FROM sbi_file_master sfm WHERE file_status = 'Processed' AND UPPER (additional_field5) = ? " + 
            "AND( EXISTS ( SELECT 1 FROM bv_user a, bv_user_profile b WHERE a.user_id = b.user_id  AND " +
                  "b.created_by_branch = ? AND a.user_alias = sfm.username)" +  
                "OR EXISTS (SELECT 1 FROM sbicorp_ca_user_map c WHERE c.ca_user = ? AND c.user_name = sfm.username))" +
            "AND EXISTS (select 1 from sbi_rtgs_beneficiary k " +
                  "where sfm.sno = k.file_sno and K.status in('active','pending_approval')) order by sfm.creation_time desc"; //Corp Admin Change
    
 // Added for Enhancement of approve beneficiary IOCL � Phase II
    private static final String CORPORATE_FILE_REG = "SELECT sno, file_name, username, creation_time,FILE_STATUS," +
            "(select decode(count(1),'0' ,'Y','N') from sbi_rtgs_beneficiary h where h.file_sno = sfm.sno " +
            "  and status = 'pending_approval' ) FILESTAT " +
            " FROM sbi_file_master sfm WHERE file_status = 'Processed' AND UPPER (additional_field5) =? " +
                  "AND( EXISTS ( SELECT 1 FROM bv_user a, bv_user_profile b WHERE a.user_id = b.user_id  " +
                  "AND b.created_by_branch =? AND a.user_alias = sfm.username)" +
                  "OR EXISTS (SELECT 1 FROM sbicorp_ca_user_map c WHERE c.ca_user = ? " +
            "AND c.user_name = sfm.username)) order by sfm.creation_time desc"; //Corp Admin Change
    
   /* Added by Sairam Mobile Registration Phase2 - End */
/*Modified by Ramanan*/
    private static final String CORPORATE_FILE_APPR = "select a.* from bv_user_profile c, bv_user b, sbi_file_master a where a.file_status = 'Processed' and upper(a.ADDITIONAL_FIELD5) =? and a.username = b.user_alias and c.user_id = b.user_id and c.created_by_branch in ((SELECT n.created_by_branch FROM bv_user_profile n, bv_user m  WHERE m.user_alias =?  AND m.user_id = n.user_id) union (select  ca_user from sbicorp_ca_user_map where user_name =?)) order by a.creation_time asc"; //Corp Admin Change

    //Added for Prepaid card Module
    private static final String CORPORATE_FILE_PREPAID_BEN = "SELECT * FROM SBI_FILE_MASTER SFM WHERE FILE_STATUS = 'Processed' "
    									+"AND UPPER (ADDITIONAL_FIELD5)IN('PC','SMT','UAE')AND ( EXISTS ( select 1 from sbi_prepaid_beneficiary_master d where d.file_name = sfm.sno " 
    									+"and d.card_status='PSG_OUT')) AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
    									+"WHERE A.USER_ID = B.USER_ID "
    									+"AND B.CREATED_BY_BRANCH = ? "
    									+"AND A.USER_ALIAS = SFM.USERNAME) "
    									+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C " 
    									+"WHERE C.CA_USER = ? AND C.USER_NAME = SFM.USERNAME)) order by sfm.creation_time desc";
    //Added for mobile Resgistration Phase2 - Sulthan
    private static final String CORPORATE_FILE_PREPAID_VIEW = "SELECT * FROM SBI_FILE_MASTER SFM WHERE FILE_STATUS = 'Processed' "
		+"AND UPPER (ADDITIONAL_FIELD5)IN('PC','SMT','UAE') AND  FILETYPE='PC' AND (EXISTS ( select 1 from sbi_prepaid_beneficiary_master d where d.file_name = sfm.sno " 
		+"and d.card_status='APPROVED')) " 
		+"AND (EXISTS ( select 1 from sbi_prepaid_beneficiary_master d where d.file_name = sfm.sno))"
		+"AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
		+"WHERE A.USER_ID = B.USER_ID "
		+"AND B.CREATED_BY_BRANCH = ? "
		+"AND A.USER_ALIAS = SFM.USERNAME) "
		+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C " 
		+"WHERE C.CA_USER = ? AND C.USER_NAME = SFM.USERNAME)) order by sfm.creation_time desc";
    
    private static final String CORPORATE_FILE_PREPAID_BPC = "SELECT * FROM SBI_FILE_MASTER SFM WHERE FILE_STATUS = 'Processed' "
		+"AND UPPER (ADDITIONAL_FIELD5) in ('PC','SMT','UAE' AND  FILETYPE='PC' AND (EXISTS ( select 1 from sbi_prepaid_beneficiary_master d where d.file_name = sfm.sno " 
		+"and d.card_status='APPROVED')) " 
		+"AND (EXISTS ( select 1 from sbi_prepaid_beneficiary_master d where d.file_name = sfm.sno))"
		+"AND (EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
		+"WHERE A.USER_ID = B.USER_ID "
		+"AND B.CREATED_BY_BRANCH = ? "
		+"AND A.USER_ALIAS = SFM.USERNAME) "
		+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C " 
		+"WHERE C.CA_USER = ? AND C.USER_NAME = SFM.USERNAME)) order by sfm.creation_time desc";

    private static final String CORPORATE_FILE_PREPAID_BEN_APPR = "SELECT   A.* FROM BV_USER_PROFILE C, BV_USER B, SBI_FILE_MASTER A "
												+"WHERE A.FILE_STATUS = 'Processed' AND UPPER (A.ADDITIONAL_FIELD5) in ('PC','SMT','UAE') "
												+"AND A.USERNAME = B.USER_ALIAS AND C.USER_ID = B.USER_ID "
												+"AND EXISTS ( select 1 from sbi_prepaid_beneficiary_master d " 
												+"where d.file_name = A.sno and  d.card_status='PSG_OUT') "
												+"AND (EXISTS(SELECT 1 FROM BV_USER_PROFILE N, BV_USER M "
												+"WHERE M.USER_ALIAS = ? AND M.USER_ID = N.USER_ID "
												+"AND N.CREATED_BY_BRANCH= C.CREATED_BY_BRANCH) "
												+"OR EXISTS(SELECT CA_USER FROM SBICORP_CA_USER_MAP CA "
												+"WHERE USER_NAME = ? AND CA.CA_USER =C.CREATED_BY_BRANCH)) ORDER BY CREATION_TIME DESC";
    
    private static final String FIND_PREPAID_BEN="SELECT spbm.*, DECODE (CARD_STATUS, 'PSG_OUT', 0, 1) CARD_STATUS "
    											+"FROM sbi_prepaid_beneficiary_master spbm "
    											+"WHERE spbm.card_status='PSG_OUT' "
    											+"AND FILE_NAME = ? "
    											+"AND (  EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
    											+"WHERE A.USER_ID = B.USER_ID "
    											+"AND B.CREATED_BY_BRANCH = ? "
    											+"AND A.USER_ALIAS = spbm.CREATED_BY) "
    											+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C "
    											+"WHERE C.CA_USER = ? "
    											+"AND C.USER_NAME = spbm.CREATED_BY))";
    //Added for Mob Regis Phase2 - Sulthan
    private static final String FIND_PREPAID_BEN_FILE_VIEW="SELECT spbm.*"
												+"FROM sbi_prepaid_beneficiary_master spbm "
												+"WHERE spbm.card_status='APPROVED' "
												+"AND FILE_NAME = ? "
												+"AND (  EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
												+"WHERE A.USER_ID = B.USER_ID "
												+"AND B.CREATED_BY_BRANCH = ? "
												+"AND A.USER_ALIAS = spbm.CREATED_BY) "
												+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C "
												+"WHERE C.CA_USER = ? "
												+"AND C.USER_NAME = spbm.CREATED_BY))";
    

    private static final String FIND_PREPAID_BEN_APPR="SELECT A.*, DECODE (CARD_STATUS, 'PSG_OUT', 0, 1) CARD_STATUS "
    												 +"FROM sbi_prepaid_beneficiary_master A, BV_USER_PROFILE C, BV_USER B "
    												 +"WHERE A.CARD_STATUS='PSG_OUT' " 
    												 +"AND A.CREATED_BY = B.USER_ALIAS "
    												 +"AND C.USER_ID = B.USER_ID "
    												 +"AND C.CREATED_BY_BRANCH IN ((SELECT N.CREATED_BY_BRANCH "
    												 +"FROM BV_USER_PROFILE N, BV_USER M "
    												 +"WHERE M.USER_ALIAS = ? AND M.USER_ID = N.USER_ID) "
    												 +"UNION "
    												 +"(SELECT CA_USER "
    												 +"FROM SBICORP_CA_USER_MAP "
    												 +"WHERE USER_NAME = ?)) "
    												 +"AND FILE_NAME = ?";

    private static final String FIND_PREPAID_BEN_APPROVER_APPR_UNAPPR_LIST="SELECT A.*, DECODE (CARD_STATUS, 'PSG_OUT', 0, 1) CARD_STATUS "
		 														  +"FROM sbi_prepaid_beneficiary_master A, BV_USER_PROFILE C, BV_USER B "
		 														  +"WHERE A.CREATED_BY = B.USER_ALIAS "
		 														  +"AND C.USER_ID = B.USER_ID "
		 														  +"AND C.CREATED_BY_BRANCH IN ((SELECT N.CREATED_BY_BRANCH "
		 														  +"FROM BV_USER_PROFILE N, BV_USER M "
		 														  +"WHERE M.USER_ALIAS = ? AND M.USER_ID = N.USER_ID) "
		 														  +"UNION "
		 														  +"(SELECT CA_USER "
		 														  +"FROM SBICORP_CA_USER_MAP "
		 														  +"WHERE USER_NAME = ?)) "
		 														  +"AND FILE_NAME = ?";
    private static final String FIND_PREPAID_BEN_APPR_UNAPPR_LIST="SELECT spbm.*, DECODE (CARD_STATUS, 'PSG_OUT', 0, 1) CARD_STATUS "
																	+"FROM sbi_prepaid_beneficiary_master spbm "
																	+"WHERE FILE_NAME = ? "
																	+"AND (  EXISTS (SELECT 1 FROM BV_USER A, BV_USER_PROFILE B "
																	+"WHERE A.USER_ID = B.USER_ID "
																	+"AND B.CREATED_BY_BRANCH = ? "
																	+"AND A.USER_ALIAS = spbm.CREATED_BY) "
																	+"OR EXISTS (SELECT 1 FROM SBICORP_CA_USER_MAP C "
																	+"WHERE C.CA_USER = ? "
																	+"AND C.USER_NAME = spbm.CREATED_BY))";
    
    private static final String UPDATE_PREPAID_BEN_APPROVED = "update sbi_prepaid_beneficiary_master set card_status =?, APPROVED_BY = ? ,last_mod_time=sysdate where id in(#tobereplaced#)  and CORPORATE_ID = ?"; /* Ramanan M - Corp Admin Paladion Security Changes */

    private static final String UPDATE_PREPAID_BEN_APPROVED_ALL = "update sbi_prepaid_beneficiary_master set card_status =?, APPROVED_BY = ? ,last_mod_time=sysdate where file_name=? and CORPORATE_ID = ?"; /* Ramanan M - Corp Admin Paladion Security Changes */

    private static final String FIND_PREPAID_BEN_REJECTED = "select * from sbi_prepaid_beneficiary_master where id in(#tobereplaced#) and CORPORATE_ID = ?"; /* Ramanan M - Corp Admin Paladion Security Changes */
    
    private static final String INSERT_PREPAID_BEN_ARCHIVAL = "INSERT INTO SBI_PREPAID_BEN_ARCHIVAL(CARD_NUMBER,CARD_REFERENCE_NO,FILE_NAME,CARD_HOLDER_NAME,CREATED_BY,CARD_STATUS,CREATION_TIME,MOVED_BY) VALUES(?,?,?,?,?,?,sysdate,?)"; 

    private static final String DELETE_PREPAID_BEN_REJECTED = "DELETE FROM sbi_prepaid_beneficiary_master WHERE ID IN(#tobereplaced#) and CORPORATE_ID = ?"; /* Ramanan M - Corp Admin Paladion Security Changes */

    //Added for Prepaid card Module Ends

    
    // added for default file config starts here

    private static final String CORPORATE_FILE_DEL_APPR = " SELECT a.* FROM bv_user_profile c, bv_user b, sbi_file_master a WHERE a.file_status = 'Processed' AND "
        + " UPPER (a.additional_field5) = ? AND a.username = b.user_alias AND c.user_id = b.user_id AND  ( EXISTS (SELECT 1 FROM bv_user_profile n, bv_user m WHERE m.user_alias = ? AND m.user_id = n.user_id "
        + " AND n.created_by_branch = c.created_by_branch) OR EXISTS (SELECT 1 FROM sbicorp_ca_user_map WHERE user_name = ? AND ca_user = c.created_by_branch)) AND EXISTS(select 1 from bvsbi.sbi_rtgs_beneficiary dt where #tobereplaced# deletion_file_no = a.sno) "
        + " AND TRUNC (creation_time) BETWEEN TO_DATE (?, 'dd/mm/yyyy') AND TO_DATE (?, 'dd/mm/yyyy') ORDER BY a.creation_time DESC";

    private static final String CORPORATE_DEL_FILE = "SELECT * FROM sbi_file_master sfm WHERE file_status = 'Processed' AND UPPER (additional_field5) = ? "
        + " AND (  EXISTS (SELECT 1 FROM bv_user a, bv_user_profile b WHERE a.user_id = b.user_id AND b.created_by_branch = ? AND a.user_alias = sfm.username) OR EXISTS (SELECT 1 FROM sbicorp_ca_user_map c WHERE c.ca_user = ? "
        + " AND c.user_name = sfm.username) ) AND EXISTS(select 1 from bvsbi.sbi_rtgs_beneficiary dt where #tobereplaced# deletion_file_no = sfm.sno) AND TRUNC (creation_time) BETWEEN TO_DATE (?, 'dd/mm/yyyy') AND TO_DATE (?, 'dd/mm/yyyy') ORDER BY sfm.creation_time DESC ";
    
   
 /*final query change during testing*/
    private static final String FIND_TP_BY_DEL_FILE = "select rtgs.*,decode(STATUS,'inactive',0,1)status_rtgs from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ? and  (exists (select 1 from bv_user a, bv_user_profile b where a.user_id=b.user_id and b.created_by_branch= ? "
            + " and a.user_alias = rtgs.user_name) or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? and c.user_name = rtgs.user_name))  #tobereplaced# ORDER BY deletion_file_no DESC";

    private static final String FIND_TP_BY_FILE_DEL_APPR = "select rtgs.*,decode(STATUS,'inactive',0,1)status_rtgs from sbi_rtgs_beneficiary rtgs where  DELETION_FILE_NO=? and  (exists (select 1 from bv_user a, "
        + " bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=(SELECT n.created_by_branch FROM bv_user_profile n, bv_user m WHERE m.user_alias =?  AND m.user_id = n.user_id) and a.user_alias = rtgs.user_name) or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? and c.user_name = rtgs.user_name)) "
        + " #tobereplaced# order by DELETION_FILE_NO desc ";

    /* Ramanan M - Corp Admin Paladion Security Changes */
    private static final String UPDATE_TP_STATE_DEL_APPROVED = "update sbi_rtgs_beneficiary  set  status ='inactive', DELETION_APPROVED_BY =? ,last_modified_time=sysdate where id in(#tobereplaced#) and CORPORATE_ID = ? ";

    /* Ramanan M - Corp Admin Paladion Security Changes */
    private static final String UPDATE_TP_STATE_DEL_BULK_APPROVED = "update sbi_rtgs_beneficiary set status ='inactive', DELETION_APPROVED_BY = ? ,last_modified_time=sysdate where DELETION_FILE_NO=? and CORPORATE_ID = ? ";

    //query change by mani on 1/12/2008
    private static final String FIND_TP_BY_DEL_FILE_CONFIRM =" select rtgs.*,decode(STATUS,'inactive',0,1)status_rtgs from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ? and (exists (select 1 from bv_user a, bv_user_profile b where a.user_id=b.user_id and b.created_by_branch= ? " + 
" and a.user_alias = rtgs.user_name) or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? " +
" and c.user_name = rtgs.user_name))  and id in (#tobereplaced#) ORDER BY deletion_file_no DESC";
    
    private static final String FIND_TP_BY_FILE_DEL_APPR_CONFIRM = " select rtgs.*,decode(STATUS,'inactive',0,1)status_rtgs from sbi_rtgs_beneficiary rtgs where  DELETION_FILE_NO=? and  (exists (select 1 from bv_user a, bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=(SELECT n.created_by_branch FROM bv_user_profile n, bv_user m WHERE m.user_alias =?  AND m.user_id = n.user_id)  and a.user_alias = rtgs.user_name) or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? and c.user_name = rtgs.user_name)) and id in(#tobereplaced#) " + 
  "  order by DELETION_FILE_NO desc " ;

    // added for default file config ends here
    private static final String FIND_TP_BY_FILE = "select rtgs.*,decode(STATUS,'active',0,'rejected',2,1)status_rtgs from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?  and (exists (select 1 from bv_user a,"
            + "bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=?  "
            + "and a.user_alias = rtgs.user_name) "
            + " or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? "
            + "and c.user_name = rtgs.user_name)) ORDER BY UPPER(rtgs.third_party_name) ASC";
    
    // Added for Reject Beneficiary File
    private static final String FIND_TP_BY_FILE_REJ = "select rtgs.*,decode(STATUS,'active',0,'rejected',2,1)status_rtgs from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?  and (exists (select 1 from bv_user a,"
            + "bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=?  "
            + "and a.user_alias = rtgs.user_name) "
            + " or exists (select 1 from sbicorp_ca_user_map c where c.ca_user =? "
            + "and c.user_name = rtgs.user_name)) ORDER BY UPPER(rtgs.third_party_name) ASC";

    private static final String FIND_TP_BY_FILE_APPR = "SELECT a.*, DECODE (STATUS,'active',0,'rejected',2,1) status_rtgs "
            + " FROM sbi_rtgs_beneficiary a,bv_user_profile c, bv_user b where a.user_name = b.user_alias "
            + " AND c.user_id = b.user_id  AND c.created_by_branch IN "
            + "((SELECT n.created_by_branch FROM bv_user_profile n, bv_user m"
            + " WHERE m.user_alias =?  AND m.user_id = n.user_id)"
            + "UNION (SELECT ca_user  FROM sbicorp_ca_user_map WHERE user_name =?))" + " AND file_sno =? AND STATUS  in ('Pending','pending_approval') ORDER BY UPPER(a.third_party_name) ASC";
    /* Ramanan M - Corp Admin Paladion Security Changes */
    private static final String UPDATE_TP_STATE_APPROVED = "update sbi_rtgs_beneficiary  set  status ='active', approved_by =? ,last_modified_time=sysdate where id in(#tobereplaced#) and DELETION_APPROVED_BY is null and status != 'rejected' and CORPORATE_ID = ?";
    /* Ramanan M - Corp Admin Paladion Security Changes */
    private static final String UPDATE_TP_STATE_UNAPPROVED = "update sbi_rtgs_beneficiary set status='pending_approval',approved_by=?,last_modified_time=sysdate where id in(#tobereplaced#)and DELETION_APPROVED_BY is null and status != 'rejected' and CORPORATE_ID = ? and approved_by is not null";
    /* Ramanan M - Corp Admin Paladion Security Changes */
    private static final String finalQuery = "update sbi_rtgs_beneficiary set status ='active', approved_by =? ,last_modified_time=sysdate where file_sno=? and DELETION_APPROVED_BY is null and status != 'rejected' and trim(CORPORATE_ID) = ?";
    
    private static final String rejectUpdateQuery = "update sbi_rtgs_beneficiary set status ='rejected', approved_by =? ,last_modified_time=sysdate where file_sno=? and DELETION_APPROVED_BY is null and CORPORATE_ID = ?"; //Added for Reject Beneficiary File
    
    private static final String UPDATE_TP_STATE_REJECTED = "update sbi_rtgs_beneficiary  set  status ='rejected', approved_by =? ,last_modified_time=sysdate where id in(#tobereplaced#) and DELETION_APPROVED_BY is null and status != 'rejected' and CORPORATE_ID = ?"; //Added for Reject Beneficiary File

    // Added for RTGS/NEFT -- CR 2655
  /*  private static final String GET_HOLIDAY_COUNT_AND_DATE = "SELECT COUNT (*) COUNT, TO_DATE (?, 'dd/mm/yyyy') schdate "
        + " FROM DUAL WHERE ((TO_CHAR (TRUNC (TO_DATE (?, 'dd/mm/yyyy')), 'DY') = 'SUN')and 1!=1) "
        + " OR (TRUNC (TO_DATE (?, 'dd/mm/yyyy')) IN (SELECT TRUNC (holiday_date) "
        + " FROM sbi_rtgs_holiday_master ))";*/
   /*private static final String GET_HOLIDAY_COUNT_AND_DATE = "SELECT COUNT (*) COUNT, TO_DATE (?, 'dd/mm/yyyy') schdate "
            + " FROM DUAL WHERE (TO_CHAR (TRUNC (TO_DATE (?, 'dd/mm/yyyy')), 'DY') = 'SUN') "
            + " OR (TRUNC (TO_DATE (?, 'dd/mm/yyyy')) IN (SELECT TRUNC (holiday_date) "
            + " FROM sbi_rtgs_holiday_master ))";
*/
    private static final String GET_HOLIDAY_COUNT_AND_DATE= " SELECT COUNT(*) COUNT,TO_DATE (?, 'dd/mm/yyyy') schdate "+
    " FROM sbi_rtgs_holiday_master "+
    " WHERE (TRUNC(HOLIDAY_DATE) = TRUNC(TO_DATE(?, 'dd/mm/yyyy')) AND UPPER(TYPE) LIKE ? ) "+
    " OR UPPER(TRIM(TYPE)) =  trim(? || '_' ||TO_CHAR(TO_DATE(?, 'dd/mm/yyyy'),'DAY'))";
    
    private static final String GET_HOLIDAY_COUNT_AND_DATE_MERCHANT = "SELECT COUNT (*) COUNT, TO_DATE (?, 'dd/mm/yyyy')"
            + " schdate FROM DUAL WHERE (TRUNC (TO_DATE (?, 'dd/mm/yyyy')) IN (SELECT TRUNC (holiday_date)"
            + "FROM SBI_MERCHANT_HOLIDAY_MASTER WHERE MERCHANT_CODE =? AND BANK_CODE=? and lower(status)='online'))";

    
    /* Added by Sairam Mobile Registration Phase2 - Start */
    static final String UPDATE_TP_APPROVED_FILE = "update sbicorp_third_party set  status =1, user_name =?, last_mod_time = sysdate where File_name =? and status!=2";
    /* Added by Sairam Mobile Registration Phase2 - End */
    
    // Added for Reject Intra Bank Beneficiary File - Start
    static final String REJECT_TP_APPROVED_FILE = "update sbicorp_third_party set status =2, user_name =? ,last_mod_time = sysdate where File_name =? ";
    // Added for Reject Intra Bank Beneficiary File - End
    
    /* added for CR 5756 */
    //private static final String CORPORATE_FILE_PREPAID_BEN_REG = "select distinct sno, file_name, username, file_status ,creation_time from sbi_file_master m where file_status='Processed' and upper(ADDITIONAL_FIELD5) ='PC' and exists (select 1 from sbi_prepaid_beneficiary_master n where m.sno=n.file_name and n.CARD_STATUS='PSG_OUT' ) and (exists (select user_alias from bv_user a,  bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=? and m.username = a.user_alias) or exists (select user_name from sbicorp_ca_user_map g where ca_user=? and g.user_name = m.username) )order by SNO"; 
    
    
    //added by damodar
    private static final String CORPORATE_FILE_PREPAID_BEN_REG = "select distinct sno, file_name, username, file_status ,creation_time from sbi_file_master m where file_status='Processed' and upper(ADDITIONAL_FIELD5)in ('PC','SMT','UAE') and exists (select 1 from sbi_prepaid_beneficiary_master n where m.sno=n.file_name and n.CARD_STATUS='PSG_OUT' ) and (exists (select user_alias from bv_user a,  bv_user_profile b where a.user_id=b.user_id and b.created_by_branch=? and m.username = a.user_alias) or exists (select user_name from sbicorp_ca_user_map g where ca_user=? and g.user_name = m.username) )order by SNO";
    
    private static final String FIND_PREPAID_BEN_REG_APPR="SELECT A.*, DECODE (CARD_STATUS, 'PSG_OUT', 0, 1) CARD_STATUS "
		 													+"FROM sbi_prepaid_beneficiary_master A, BV_USER_PROFILE C, BV_USER B "
		 													+"WHERE A.CARD_STATUS='PSG_OUT' " 
		 													+"AND A.CREATED_BY = B.USER_ALIAS "
		 													+"AND C.USER_ID = B.USER_ID "
		 													+"AND C.CREATED_BY_BRANCH IN ((SELECT M.USER_ALIAS "
		 													+"FROM BV_USER_PROFILE N, BV_USER M "
		 													+"WHERE M.USER_ALIAS = ? AND M.USER_ID = N.USER_ID) "
		 													+"UNION "
		 													+"(SELECT CA_USER "
		 													+"FROM SBICORP_CA_USER_MAP "
		 													+"WHERE USER_NAME = ?)) "
		 													+"AND FILE_NAME = ?";
    /* CR 5756 ends here */
    
    //Error  count
    
  //Added to fetch error count
    private static final String FETCH_ERROR_COUNT ="select ADDITIONAL_FIELD1 from sbi_file_master where sno = ?";
  	
    
    // Added for Reject Beneficiary File
    private static final String INSERT_AUDIT_QUERY = "insert into wac_audit_trail values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
    
    /**
     * This Method is used to find ThirdParty Files in sbi_file_master and
     * returns array of CorporateFile objects
     * 
     * This method is used for two scenarios:
     * 1.Approve Third Parties(IBTP)
     * 2.Approve to Delete Third Parties(DIBTP)
     * 
     */
    // modified for default file config module
    public CorporateFile[] findTPFiles(String userName, Integer userRole, String bankType, String startDate,
            String endDate, String functionType)
    {

        logger.info("findTPFiles( String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType)"+ LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName +"userRole :"+userRole+"bankType :"+bankType+"functionType :"+functionType);
        
        List result = new ArrayList();
        CorporateFile[] corporateFileArray = null;

        if (userName != null && userName.trim().length() > 0 && bankType != null)
        {

            try
            {
                
                if (bankType.equals("DIBTP"))// modified  for DFC
                {
                    
                    Object[] parameters = new Object[] { bankType, userName, userName, startDate, endDate };

                    if (userRole.intValue() == 42)
                    {
                        if (functionType.equalsIgnoreCase("approve"))
                        {
                            String finaltpapprovequery = CORPORATE_FILE_DEL_APPR.replaceAll("#tobereplaced#",
                                    "DELETION_APPROVED_BY is null and");
                            result = getJdbcTemplate().query(finaltpapprovequery, parameters,
                                    new CorporateFileRowMapper(bankType, functionType));
                        }
                        else
                        {
                            String finaltpapprovequery = CORPORATE_FILE_DEL_APPR.replaceAll("#tobereplaced#", " ");
                            result = getJdbcTemplate().query(finaltpapprovequery, parameters,
                                    new CorporateFileRowMapper(bankType, functionType));

                        }

                    }
                    else
                    {
                        if (functionType.equalsIgnoreCase("approve"))
                        {
                            String finaltpapprovequery = CORPORATE_DEL_FILE.replaceAll("#tobereplaced#",
                                    "DELETION_APPROVED_BY is null and");
                            result = getJdbcTemplate().query(finaltpapprovequery, parameters,
                                    new CorporateFileRowMapper(bankType, functionType));
                        }
                        else
                        {
                            String finaltpapprovequery = CORPORATE_DEL_FILE.replaceAll("#tobereplaced#", " ");
                            result = getJdbcTemplate().query(finaltpapprovequery, parameters,
                                    new CorporateFileRowMapper(bankType, functionType));

                        }
                 
                    }
                }//Added for Prepaid card Module
                else if(("PC".equals(bankType)) || ("SMT".equals(bankType)) || ("UAE".equals(bankType)) || ("BPC".equals(bankType)))
                {
                	logger.info("dao bank type: "+bankType+" role: "+userRole.intValue());
                    Object[] parameters = new Object[] {userName, userName };

                    if (userRole.intValue() == 42)
                    {
                        result = getJdbcTemplate().query(CORPORATE_FILE_PREPAID_BEN_APPR, parameters,
                                new CorporateFileRowMapper(bankType, functionType));
                    }
                    //added for CR 5756
                    else if (userRole.intValue() == 10)
                    {
                    	parameters = new Object[] {userName, userName };
                        result = getJdbcTemplate().query(CORPORATE_FILE_PREPAID_BEN_REG, parameters,
                        		new CorporateFileRowMapper ( bankType, functionType));
                    } //CR 5756 ends here 
                else
                        result = getJdbcTemplate().query(CORPORATE_FILE_PREPAID_BEN, parameters,
                                new CorporateBenFileRowMapper(bankType, functionType));

                }//Added for Prepaid card Module 
                else
                {
                    Object[] parameters = new Object[] { bankType, userName, userName };

                    if (userRole.intValue() == 42)
                    {
                        result = getJdbcTemplate().query(CORPORATE_FILE_APPR, parameters,
                                new CorporateFileRowMapper(bankType, functionType));
                    } else if (userRole.intValue() == 7){
                        result = getJdbcTemplate().query(CORPORATE_FILE_ADMIN, parameters,
                                new CorporateInterBankAppFileRowMapper(bankType, functionType));
                    } else {
                        result = getJdbcTemplate().query(CORPORATE_FILE_REG, parameters,
                                    new CorporateInterBankAppFileRowMapper(bankType, functionType));
                    }

//                    {
//                        result = getJdbcTemplate().query(CORPORATE_FILE_APPR, parameters,
//                                new CorporateFileRowMapper(bankType, functionType));
//                    }
//                    else
//                        result = getJdbcTemplate().query(CORPORATE_FILE, parameters,
//                                new CorporateInterBankAppFileRowMapper(bankType, functionType));

                } 

                if (result != null && result.size() > 0)
                {

                    logger.info("Result size in side if loop:" + result.size());
                    corporateFileArray = new CorporateFile[result.size()];

                    for (int i = 0; i < result.size(); i++)
                    {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }

                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType"+ LoggingConstants.METHODEND);
        return corporateFileArray;

    }
    //Added for mobile registration Phase2
    public CorporateFile[] findTPFilesView(String userName, Integer userRole, String bankType)
    {

        logger.info("findTPFilesView( String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType)"+ LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName +"userRole :"+userRole+"bankType :"+bankType);
        
        List result = new ArrayList();
        CorporateFile[] corporateFileArray = null;

        if (userName != null && userName.trim().length() > 0 && bankType != null)
        {
        	logger.info("-----BANKTYPE-----"+bankType);
            try
            {
            	if(("PC".equals(bankType)) || ("SMT".equals(bankType)) || ("UAE".equals(bankType)) )
                {      
                	logger.info("Prepaid Card is executing");
                    Object[] parameters = new Object[] { userName, userName };
                        result = getJdbcTemplate().query(CORPORATE_FILE_PREPAID_VIEW, parameters,
                                new CorporatePrePadiCardViewRowMapper());

                }            	
            	else if(userRole==7)
            	{
            		Object[] parameters = new Object[] { bankType, userName, userName };
                    result = getJdbcTemplate().query(CORPORATE_BEN_FILE_VIEW, parameters,
                                new ViewCorporateBenFileRowMapper());
            	}
            	else
                {
                    Object[] parameters = new Object[] { bankType, userName, userName };
                    result = getJdbcTemplate().query(CORPORATE_FILE_VIEW, parameters,
                                new CorporatePrePadiCardViewRowMapper());
                    } 

                if (result != null && result.size() > 0)
                {

                    logger.info("Result size in side if loop:" + result.size());
                    corporateFileArray = new CorporateFile[result.size()];

                    for (int i = 0; i < result.size(); i++)
                    {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }

                }
            }catch (DataAccessException ex)
                {
                    DAOException.throwException("F001", ex);
                }
            }
            else
            {
                DAOException.throwException("CR002");
            }
            logger.info("String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType"+ LoggingConstants.METHODEND);
            return corporateFileArray;
     }
    /**
     * This method is used to find the third party list in the file selcted by
     * th Admin,Regulator or Approver to Approve. select
     * a.*,decode(STATUS,'active',0,1)status_rtgs from sbi_rtgs_beneficiary a
     * where user_name in (select user_alias from bv_user a, bv_user_profile b
     * where a.user_id=b.user_id and created_by_branch=?) and FILE_SNO=?
     */
    public CorporateTP[] findTPsByFile(String userName, String fileName, Integer userRole, String bankType,
            String functionType)
    {
        logger.info("findTPsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        CorporateTP[] corporateTPArray = null;
        Object[] params_appr;
        Object[] params;
        logger.info("fileName :" + fileName + " userName:" + userName + " bankType " + bankType + "functionType "+ functionType);
      if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + " bankType " + bankType + "functionType "
                + functionType);
         }
        if (fileName != null && userName != null)
        {

            try
            {
                if (bankType.equals("DIBTP"))// modified  for DFC
                {
                    params_appr = new Object[] { fileName, userName, userName };
                    params = new Object[] { fileName , userName, userName};
                    
                    if (userRole.intValue() == 42)
                    {
                        if (functionType.equalsIgnoreCase("approve"))
                        {   /***
                            The following aueries has to used to find the contents of the file for approver.
                        */
                       
                            String finaltpbyfileapprovequery = FIND_TP_BY_FILE_DEL_APPR.replaceAll("#tobereplaced#",
                                    "AND DELETION_APPROVED_BY is null ");//condition has included to show the unapproved records only
                            result = getJdbcTemplate().query(finaltpbyfileapprovequery, params_appr,
                                    new CorporateTPRowMapper());
                        }
                        else
                        {
                            String finaltpbyfileviewquery = FIND_TP_BY_FILE_DEL_APPR.replaceAll("#tobereplaced#", " ");//condition has included to view the records history
                            result = getJdbcTemplate().query(finaltpbyfileviewquery, params_appr,
                                    new CorporateTPRowMapper());
                        }

                    }
                    else
                    {
                        if (functionType.equalsIgnoreCase("approve"))
                        {
                            String finaltpbyfileapprovequery = FIND_TP_BY_DEL_FILE.replaceAll("#tobereplaced#",
                                    "AND DELETION_APPROVED_BY is null ");//condition has included to show the unapproved records only
                            result = getJdbcTemplate().query(finaltpbyfileapprovequery, params,
                                    new CorporateTPRowMapper());
                        }
                        else
                        {
                            String finaltpbyfileviewquery = FIND_TP_BY_DEL_FILE.replaceAll("#tobereplaced#", " ");//condition has included to view the records history
                            result = getJdbcTemplate().query(finaltpbyfileviewquery, params,
                                    new CorporateTPRowMapper());
                        }
                    }
                }
                else
                {
                    params_appr = new Object[] { userName, userName, fileName };
                    params = new Object[] { fileName, userName, userName };
                    if (userRole.intValue() == 42)
                    {
                        result = getJdbcTemplate().query(FIND_TP_BY_FILE_APPR, params_appr, new CorporateTPRowMapper());
                    }
                	else if(userRole.intValue() == 7)
                	{
                		result = getJdbcTemplate().query(FIND_TP_BY_FILE_REJ, params, new CorporateTPRowMapper());
                	}
                	else
                        result = getJdbcTemplate().query(FIND_TP_BY_FILE, params, new CorporateTPRowMapper());
                }

                corporateTPArray = new CorporateTP[result.size()];

                for (int i = 0; i < result.size(); i++)
                {
                    corporateTPArray[i] = (CorporateTP) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.info("findTPsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType)"+ LoggingConstants.METHODEND);
        return corporateTPArray;
    }


    //Added for Prepaid card Module
    public PrePaidCardBeneficiary[] findPCsByFile(String userName, String fileName, Integer userRole, String bankType,
            String functionType)
    {
        logger.debug("findPCsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        PrePaidCardBeneficiary[] prePaidCardBeneficiaryArray = null;
        Object[] params_appr;
        Object[] params;
      if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + " bankType " + bankType + "functionType "
                + functionType);
         }
        if (fileName != null && userName != null)
        {

            try
            {
                	logger.info("dao bank type: "+bankType+" role: "+userRole.intValue());
                    params_appr = new Object[] { userName, userName, fileName };
                    params = new Object[] { fileName, userName, userName };
                    if (userRole.intValue() == 42)
                    {
                        result = getJdbcTemplate().query(FIND_PREPAID_BEN_APPR, params_appr, new PrePaidCardRowMapper());
                    }
                  //added for CR 5756
                    else if (userRole.intValue() == 10)
                    {                   	
                    	params_appr = new Object[] {  userName, userName ,fileName};
                    	params = new Object[] { fileName, userName, userName };
                        result = getJdbcTemplate().query(FIND_PREPAID_BEN_REG_APPR, params_appr, new PrePaidCardRowMapper());
                    } 
                    //CR 5756 ends here 
                    else

                        result = getJdbcTemplate().query(FIND_PREPAID_BEN, params, new PrePaidCardRowMapper());
                	prePaidCardBeneficiaryArray = new PrePaidCardBeneficiary[result.size()];

                for (int i = 0; i < result.size(); i++)
                {
                		prePaidCardBeneficiaryArray[i] = (PrePaidCardBeneficiary) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("findPCsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType)"+ LoggingConstants.METHODEND);
       	return prePaidCardBeneficiaryArray;
    }
//Added for Mobile Registration Phase-2 Starts
    public PrePaidCardBeneficiary[] findPCsByFileView(String userName, String fileName, Integer userRole, String bankType)
    {
        logger.debug("findPCsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        PrePaidCardBeneficiary[] prePaidCardBeneficiaryArray = null;
        Object[] params_appr;
        Object[] params;
      if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + " bankType " + bankType );
         }
        if (fileName != null && userName != null)
        {

            try
            {
                	logger.info("dao bank type: "+bankType+" role: "+userRole.intValue());
                    params_appr = new Object[] { userName, userName, fileName };
                    params = new Object[] { fileName, userName, userName };
                    
                     result = getJdbcTemplate().query(FIND_PREPAID_BEN_FILE_VIEW, params, new PrePaidCardRowMapper());
                	prePaidCardBeneficiaryArray = new PrePaidCardBeneficiary[result.size()];

                for (int i = 0; i < result.size(); i++)
                {
                		prePaidCardBeneficiaryArray[i] = (PrePaidCardBeneficiary) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("findPCsByFile( String userName, String fileName,Integer userRole,String bankType,String functionType)"+ LoggingConstants.METHODEND);
       	return prePaidCardBeneficiaryArray;
    }
    //Added for Mobile Registration Phase-2 Ends
    
    public PrePaidCardBeneficiary[] findApprUnapprByFile(String userName, String fileName, Integer userRole, String bankType,
            String functionType)
    {
        logger.debug("findApprUnapprByFile( String userName, String fileName,Integer userRole,String bankType,String functionType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        PrePaidCardBeneficiary[] prePaidCardBeneficiaryArray = null;
        Object[] params_appr;
        Object[] params;
      if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + " bankType " + bankType + "functionType "
                + functionType);
         }
        if (fileName != null && userName != null)
        {

            try
            {
                	logger.info("dao bank type: "+bankType+" role: "+userRole.intValue());
                    params_appr = new Object[] { userName, userName, fileName };
                    params = new Object[] { fileName, userName, userName };
                    if (userRole.intValue() == 42)
                    {
                        result = getJdbcTemplate().query(FIND_PREPAID_BEN_APPROVER_APPR_UNAPPR_LIST, params_appr, new PrePaidCardRowMapper());
                    }
                    else

                        result = getJdbcTemplate().query(FIND_PREPAID_BEN_APPR_UNAPPR_LIST, params, new PrePaidCardRowMapper());
                	prePaidCardBeneficiaryArray = new PrePaidCardBeneficiary[result.size()];

                
                for (int i = 0; i < result.size(); i++)
                {
                		prePaidCardBeneficiaryArray[i] = (PrePaidCardBeneficiary) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("findApprUnapprByFile( String userName, String fileName,Integer userRole,String bankType,String functionType)"+ LoggingConstants.METHODEND);
       	return prePaidCardBeneficiaryArray;
    }
    //Added for Prepaid card Module
    /**
     * This method is used to find the third party list in the file selcted by
     * th Admin,Regulator or Approver to Approve. select
     * a.*,decode(STATUS,'active',0,1)status_rtgs from sbi_rtgs_beneficiary a
     * where user_name in (select user_alias from bv_user a, bv_user_profile b
     * where a.user_id=b.user_id and created_by_branch=?) and FILE_SNO=?
     */
    
    /**
     * This method is used to show the updated records in the confirmation screen only for approve delete 3p
     * */
    // Method added  for default file config
    public CorporateTP[] findTPsByFileConfirm(String approvedOIDs, String userName, String fileName, Integer userRole,
            String bankType)
    {
        logger.debug("findTPsByFileConfirm(String approvedOIDs, String userName, String fileName,Integer userRole,String bankType )"+ LoggingConstants.METHODBEGIN);

        List result = new ArrayList();
        CorporateTP[] corporateTPArray = null;
        Object[] params_appr;
        Object[] params;
         if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + "bankType :" + bankType + "approvedOIDs :"
                + approvedOIDs);
       }
        if (fileName != null && userName != null)
        {

            try
            {
                params_appr = new Object[] { fileName, userName, userName };
                params = new Object[] {  fileName ,userName, userName};
                if (userRole.intValue() == 42)
                {
                    String finaltpbyfileapprovequery = FIND_TP_BY_FILE_DEL_APPR_CONFIRM.replaceAll("#tobereplaced#",
                            approvedOIDs);
                    result = getJdbcTemplate()
                            .query(finaltpbyfileapprovequery, params_appr, new CorporateTPRowMapper());

                }
                else
                {
                    String finaltpbyfileapprovequery = FIND_TP_BY_DEL_FILE_CONFIRM.replaceAll("#tobereplaced#",
                            approvedOIDs);
                    result = getJdbcTemplate().query(finaltpbyfileapprovequery, params, new CorporateTPRowMapper());
                }
                corporateTPArray = new CorporateTP[result.size()];

                for (int i = 0; i < result.size(); i++)
                {
                    corporateTPArray[i] = (CorporateTP) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("findTPsByFileConfirm( String userName, String fileName,Integer userRole,String bankType)"+ LoggingConstants.METHODEND);
        return corporateTPArray;
    }

    /**
     * This method is used to update the status of the third parties in the file
     * approved by Admin,Regulator or Approver.
     */
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean updateTPState(String approvedOIDs, String unapprovedOIDs, String userName, String bankType, String corporateID)
    {// modified  for default file config
        logger.debug("updateTPState(String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);

        if (logger.isDebugEnabled())
        {
            logger.debug("approvedOIDs  :" + approvedOIDs + " unapprovedOIDs :" + unapprovedOIDs + "userName"+ userName + "bankType" + bankType + " corporateID :" + corporateID);
        }

        int approvedCount = 0;
        if (approvedOIDs != null && approvedOIDs.trim().length() > 0)
        {

            try
            {
            	/* Ramanan M - Corp Admin Paladion Security Changes */
                Object[] approvedParams = new Object[] { userName, corporateID };
                if (bankType.equals("DIBTP"))// modified  for DFC
                {
                    String finaldelapproveQuery = UPDATE_TP_STATE_DEL_APPROVED.replaceAll("#tobereplaced#",
                            approvedOIDs);
                    approvedCount = getJdbcTemplate().update(finaldelapproveQuery, approvedParams);
                }
                else
                {
                    String finalQuery = UPDATE_TP_STATE_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                    approvedCount = getJdbcTemplate().update(finalQuery, approvedParams);
                }
                if (logger.isDebugEnabled())
                {

                    logger.debug("updateTPState  :" + approvedCount);
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }

        if (unapprovedOIDs != null && unapprovedOIDs.trim().length() > 0 && bankType != "DIBTP")
        {
            try
            {
                int unapprovedCount = 0;
                /* Ramanan M - Corp Admin Paladion Security Changes */
                Object[] unapprovedParams = new Object[] { userName, corporateID };
                String finalQuery1 = UPDATE_TP_STATE_UNAPPROVED.replaceAll("#tobereplaced#", unapprovedOIDs);
                unapprovedCount = getJdbcTemplate().update(finalQuery1, unapprovedParams);

                if (logger.isDebugEnabled())
                {
                    logger.debug("updateTPState  :" + unapprovedCount);
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }

        logger.debug("updateTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return true;
    }

    /**
     * This method is used to Approve all the third parties listed in the
     * particluar file selcted by the Admin,Regulator or Approver.
     */
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean updateTPStateALL(String userName, String filename, String bankType, String corporateID)
    {
        logger.debug("updateTPStateALL(String userName,String filename,String bankType, String corporateID )"+ LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("userName  :" + userName + "filename :" + filename + "bankType  " + bankType + " corporateID :" + corporateID );
        }

        int approvedCount = 0;
        try
        {
        	/* Ramanan M - Corp Admin Paladion Security Changes */
            Object[] approvedParams = new Object[] { userName, filename, corporateID };
            Object[] params = new Object[] { userName,filename, corporateID };
            if (bankType.equals("DIBTP"))// modified  for DFC
            {
                approvedCount = getJdbcTemplate().update(UPDATE_TP_STATE_DEL_BULK_APPROVED, params);

            }
            else
            {
                approvedCount = getJdbcTemplate().update(finalQuery, approvedParams);
            }

            if (logger.isDebugEnabled())
            {
                logger.debug("updateTPState  :" + approvedCount);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException("F001", ex);
        }

        logger.debug("updateTPStateALL(String userName,String filename,,String bankType, String corporateID)" + LoggingConstants.METHODEND);
        return true;
    }
    //Added for Prepaid card Module 
    public Map updatePrepaidBen(String approvedOIDs, String unapprovedOIDs, String userName, String bankType,String actionType, String corporateID)
    {
     logger.debug("updatePrepaidBen(String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);
     List rejectedRecords = new ArrayList();
     Map result = new HashMap();
       // if (logger.isDebugEnabled())
       // {
            logger.info("approvedOIDs  :" + approvedOIDs + " unapprovedOIDs :" + unapprovedOIDs + "userName"+ userName + "bankType" + bankType+ "actionType: " + actionType);
      //  }

        int approvedCount = 0;
        if (approvedOIDs != null && approvedOIDs.trim().length() > 0)
        {

            try
            {
            	if("APPROVED".equals(actionType)){
            		/* Ramanan M - Corp Admin Paladion Security Changes */
            		Object[] approvedParams = new Object[] { actionType,userName, corporateID };
            		String finalQuery = UPDATE_PREPAID_BEN_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                	int sqlType[] =
                	{ Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

            		approvedCount = getJdbcTemplate().update(finalQuery, approvedParams,sqlType);
            		/* Ramanan M - Corp Admin Paladion Security Changes */
            		if(approvedCount == 0){
            			result.put("status",new Boolean(false));
            	        result.put("rejectedRecords",rejectedRecords);
            		} else {
            			 result.put("status",new Boolean(true));
            			 result.put("rejectedRecords",rejectedRecords);
            		}
            	}else if("REJECTED".equals(actionType)){
            		//1)fetch only rejected record. 2)insert in archive table 3)delete at one shot
            		/* Ramanan M - Corp Admin Paladion Security Changes */
            		Object[] rejectedParams = new Object[] { corporateID };
                    String finalQuery = FIND_PREPAID_BEN_REJECTED.replaceAll("#tobereplaced#",
                            approvedOIDs);
                    logger.debug("rejected final query: "+finalQuery);
                    rejectedRecords = getJdbcTemplate().query(finalQuery, rejectedParams ,new PrePaidCardRowMapper());
                    /* Ramanan M - Corp Admin Paladion Security Changes */
                    if(rejectedRecords!= null && rejectedRecords.size() >= 1){
                    for(int i=0;i<rejectedRecords.size();i++){
                    	PrePaidCardBeneficiary prePaidCardBeneficiary= (PrePaidCardBeneficiary)rejectedRecords.get(i);
                    	logger.info("data: "+prePaidCardBeneficiary.toString());
                    	
                    	Object[] params = new Object[] {prePaidCardBeneficiary.getCardNumber(),prePaidCardBeneficiary.getCardReferenceNo(),prePaidCardBeneficiary.getFileName(),
                    			prePaidCardBeneficiary.getCardHolderName(),prePaidCardBeneficiary.getUploaderName(),"REJECTED",userName};
                    	int sqlType[] =
                    	{ Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
		            	
                    	int noOfRowsInserted = getJdbcTemplate().update(INSERT_PREPAID_BEN_ARCHIVAL, params, sqlType);
			            logger.info("noOfRowsInserted="+ noOfRowsInserted);
                    }
                    /* Ramanan M - Corp Admin Paladion Security Changes */
            		Object[] deleteParams = new Object[] { corporateID };
            		String finalDelQuery = DELETE_PREPAID_BEN_REJECTED.replaceAll("#tobereplaced#", approvedOIDs);
            		int deleteCount = getJdbcTemplate().update(finalDelQuery, deleteParams);
            		logger.info("delete count:: "+deleteCount);
            		
            		result.put("status",new Boolean(true));
                    result.put("rejectedRecords",rejectedRecords);
                    } else {
                    	/* Ramanan M - Corp Admin Paladion Security Changes */
                    	result.put("status",new Boolean(false));
                        result.put("rejectedRecords",rejectedRecords);
                    }
            	}
                if (logger.isDebugEnabled())
                {

                    logger.debug("updatePrepaidBen  :" + approvedCount);
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        /* Ramanan M - Corp Admin Paladion Security Changes */
//        result.put("status",new Boolean(true));
//        result.put("rejectedRecords",rejectedRecords);
 
        logger.debug("updatePrepaidBen( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return result;
    }

    public boolean updatePrepaidBenAll(String userName, String filename, String bankType,String actionType, String corporateID)
    {
        logger.debug("updatePrepaidBenAll(String userName,String filename,String bankType,String actionType, String corporateID )"+ LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("userName  :" + userName + "filename :" + filename + "bankType  " + bankType+" actionType: "+actionType);
        }

        int approvedCount = 0;
        try
        {
        	if("APPROVED".equals(actionType)){
        		/* Ramanan M - Corp Admin Paladion Security Changes */
        		Object[] params = new Object[] {actionType, userName,filename, corporateID};
            	int sqlType[] =
            	{ Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
            	approvedCount = getJdbcTemplate().update(UPDATE_PREPAID_BEN_APPROVED_ALL, params,sqlType);
        	}/*else if("REJECTED".equals(actionType)){
        		//1)fetch only rejected record. 2)insert in archive table 3)delete at one shot
        		
        	}*/
            if (logger.isDebugEnabled())
            {
                logger.debug("updatePrepaidBenAll  :" + approvedCount);
            }
            /* Ramanan M - Corp Admin Paladion Security Changes */
            if(approvedCount == 0 ){
            	return false;
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException("F001", ex);
        }

        logger.debug("updatePrepaidBenAll(String userName,String filename,String bankType,String actionType, String corporateID)" + LoggingConstants.METHODEND);
        return true;
    }
 //End Prepaid card Module  
/* Added by Sairam Mobile Registration Phase2 - Start */
    public boolean approveTPFile(String userName,String fileName) {
        logger.info("approveTPFile(String userName,String fileName)"
                        + LoggingConstants.METHODBEGIN);
        logger.info("userName :"+userName+" fileName :"+fileName);
       try{
        int approvedCount = 0;                            
                        Object[] approvedParams = new Object[] {userName,fileName };
                        
                        approvedCount = getJdbcTemplate().update(UPDATE_TP_APPROVED_FILE,
                                approvedParams);
                        
                        
            }

               catch (DataAccessException ex) {
                    DAOException.throwException(
                            ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
                }
        logger.info("approveTPFile(String userName,String fileName)"
                       + LoggingConstants.METHODEND);
               return true;
            }
   
    
    
    
    public boolean approvePrepaidBenFile(String userName, String filename,String corporateId)
    {
        logger.info("approvePrepaidBenFile(String userName,String filename )"+ LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName + "filename :" + filename+"corporateId :"+corporateId );
        if (logger.isDebugEnabled())
        {
            logger.debug("userName  :" + userName + "filename :" + filename );
        }
        String actionType = "APPROVED";
        int approvedCount = 0;
        try
        {
        	
        		Object[] params = new Object[] {actionType, userName,filename ,corporateId};
            	int sqlType[] =
            	{ Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR};
            	approvedCount = getJdbcTemplate().update(UPDATE_PREPAID_BEN_APPROVED_ALL, params,sqlType);
        	/*else if("REJECTED".equals(actionType)){
        		//1)fetch only rejected record. 2)insert in archive table 3)delete at one shot
        		
        	}*/
            if (logger.isDebugEnabled())
            {
                logger.debug("updatePrepaidBenAll  :" + approvedCount);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException("F001", ex);
        }

        logger.info("approvePrepaidBenFile(String userName,String filename)" + LoggingConstants.METHODEND);
        return true;
    }
    
    
    
    public class CorporateBenFileRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateFile
         */
    	
        String bankType;

        String functionType;

        public CorporateBenFileRowMapper(String banktype, String functiontype)// added  for default file config
        {
            //Two additional parameters is added for approve delete 3P
            this.bankType = banktype;
            this.functionType = functiontype;
        }
       

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateFile corporateFile = new CorporateFile();
            String fileName = rs.getString("FILE_NAME");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            while (st.hasMoreTokens())
            {
                corporateFile.setSno((rs.getString("SNO")));
                corporateFile.setFileName(st.nextToken());
                corporateFile.setUploaderName(rs.getString("USERNAME"));
                corporateFile.setUploadedDate(rs.getTimestamp("CREATION_TIME"));
               // corporateFile.setFileStat(rs.getString("FILESTAT"));
				corporateFile.setTpStatus(rs.getString("FILE_STATUS"));//Added for mmobile Registration Phase 2
            }
            corporateFile.setBankType(bankType);// added  for default file config
            corporateFile.setFunctionType(functionType); 
            return corporateFile;
        }
    }
    
    
    public class CorporateInterBankAppFileRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateFile
         */
        String bankType;

        String functionType;   

        public CorporateInterBankAppFileRowMapper(String banktype, String functiontype)// added  for default file config
        {
            //Two additional parameters is added for approve delete 3P
            this.bankType = banktype;
            this.functionType = functiontype;
        }
               
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	logger.info("FILESTAT ::::"+rs.getString("FILESTAT"));
            CorporateFile corporateFile = new CorporateFile();
            String fileName = rs.getString("FILE_NAME");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            while (st.hasMoreTokens())
            {
                corporateFile.setSno((rs.getString("SNO")));
                corporateFile.setFileName(st.nextToken());
                corporateFile.setUploaderName(rs.getString("USERNAME"));
                corporateFile.setUploadedDate(rs.getTimestamp("CREATION_TIME"));
                corporateFile.setFileStat(rs.getString("FILESTAT"));
            }
            corporateFile.setBankType(bankType);// added  for default file config
            corporateFile.setFunctionType(functionType); 
            return corporateFile;
        }
    }
    
    /* Added by Sairam Mobile Registration Phase2 - End */

    public class CorporateFileRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateFile
         */
        String bankType;

        String functionType;

        public CorporateFileRowMapper(String banktype, String functiontype)// added  for default file config
        {
            //Two additional parameters is added for approve delete 3P
            this.bankType = banktype;
            this.functionType = functiontype;
        }

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateFile corporateFile = new CorporateFile();
            String fileName = rs.getString("FILE_NAME");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            while (st.hasMoreTokens())
            {
                corporateFile.setSno((rs.getString("SNO")));
                corporateFile.setFileName(st.nextToken());
                corporateFile.setUploaderName(rs.getString("USERNAME"));
                corporateFile.setUploadedDate(rs.getTimestamp("CREATION_TIME"));
             //   corporateFile.setFileStat(rs.getString("FILESTAT"));
				corporateFile.setTpStatus(rs.getString("FILE_STATUS"));//Added for mmobile Registration Phase 2
            }
            corporateFile.setBankType(bankType);// added  for default file config
            corporateFile.setFunctionType(functionType); 
            return corporateFile;
        }
    }

    public class CorporateTPRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateTP corporateTP = new CorporateTP();
          //  corporateTP.setOid(new Integer(rs.getInt("ID")));
            corporateTP.setOid(rs.getLong("ID"));
            corporateTP.setCorporateID(rs.getString("CORPORATE_ID"));
            corporateTP.setStatus(new Integer(rs.getInt("STATUS_RTGS")));
            corporateTP.setAccountNo(rs.getString("ACCOUNT_NUMBER"));
            corporateTP.setBranchCode(rs.getString("SENDER_BRANCH_CODE"));
            corporateTP.setName(rs.getString("THIRD_PARTY_NAME"));
            corporateTP.setOutRef1(rs.getString("BANK_RECEIVER"));
            corporateTP.setOutRef2(rs.getString("IFSC_CODE_RECEIVER"));
            corporateTP.setDeletionApprovedBy(rs.getString("DELETION_APPROVED_BY"));
            corporateTP.setDeletionFileNo(rs.getString("DELETION_FILE_NO"));
            corporateTP.setTpFileStatus(rs.getString("STATUS"));//Added for mobile Registration Phase 2
            /*Added for Enhancement in approve beneficiary -Phase I - Start*/
            corporateTP.setAddress1(rs.getString("ADDRESS1"));
            corporateTP.setAddress2(rs.getString("ADDRESS2"));
            corporateTP.setAddress3(rs.getString("ADDRESS3"));
            corporateTP.setMobileNo(rs.getString("PHONE_NO"));
            corporateTP.setEmailId(rs.getString("EMAIL_ID"));
            corporateTP.setEmployeeCode(rs.getString("EMP_CODE"));
            /*Added for Enhancement in approve beneficiary -Phase I - End*/
            return corporateTP;

        }
    }

    // Added for RTGS/NEFT

    //Added for Prepaid card Module
    public class PrePaidCardRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
         	PrePaidCardBeneficiary prePaidCardBeneficiary = new PrePaidCardBeneficiary();
         	prePaidCardBeneficiary.setId(rs.getString("ID"));
        	prePaidCardBeneficiary.setCardNumber(rs.getString("CARD_NUMBER"));
        	prePaidCardBeneficiary.setCardReferenceNo(rs.getString("CARD_REFERENCE_NO"));
        	prePaidCardBeneficiary.setFileName(rs.getString("FILE_NAME"));
        	prePaidCardBeneficiary.setCardHolderName(rs.getString("CARD_HOLDER_NAME"));
        	prePaidCardBeneficiary.setBranchCode(rs.getString("BRANCH_CODE"));
        	prePaidCardBeneficiary.setCardStatus(rs.getString("CARD_STATUS"));
        	prePaidCardBeneficiary.setCardActive(rs.getString("CARD_ACTIVE"));
        	prePaidCardBeneficiary.setCorporateId(rs.getString("CORPORATE_ID"));
        	prePaidCardBeneficiary.setUploaderName(rs.getString("CREATED_BY"));
        	prePaidCardBeneficiary.setCreatedTime(rs.getTimestamp("CREATED_TIME"));
            return prePaidCardBeneficiary;
        }
    }
    //End Prepaid card Module 

    public Map findHoliday(String DateTime, String merchantCode, String bankCode) throws DAOException
    {
        logger.debug("findHoliday - method begin. DateTime : " + DateTime);
        Map resultMap = null;
        try
        {
        	String test = "%"+merchantCode+"%"; // Added for Restriction of Sunday Txn
            if (merchantCode.equalsIgnoreCase(UtilsConstant.RTGS) || merchantCode.equalsIgnoreCase(UtilsConstant.NEFT)
                    || merchantCode.equalsIgnoreCase(UtilsConstant.GRPT))// Added
            // for
            // GRPT
            {
                Object parameters[] = { DateTime, DateTime,test,merchantCode,DateTime };
                resultMap = (Map) getJdbcTemplate().queryForObject(GET_HOLIDAY_COUNT_AND_DATE, parameters,
                        new HolidayRowMapper());
            }
            else
            {
                Object parameters[] = { DateTime, DateTime, merchantCode, bankCode };
                resultMap = (Map) getJdbcTemplate().queryForObject(GET_HOLIDAY_COUNT_AND_DATE_MERCHANT, parameters,
                        new HolidayRowMapper());
            }
        }
        catch (DataAccessException ex)
        {
            ex.printStackTrace();
            DAOException.throwException("CU0055", new Object[] { resultMap, DateTime });
        }
        logger.debug("findHoliday - method end");
        return resultMap;
    }

    private class HolidayRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int arg1) throws SQLException
        {
            Map dateMap = new HashMap();
            dateMap.put("count", rs.getString("count"));
            dateMap.put("date", rs.getDate("schdate"));
            return dateMap;
        }
    }
  //Added for mmobile Registration Phase 2
    public class CorporatePrePadiCardViewRowMapper implements RowMapper
    {
                    

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateFile corporateFile = new CorporateFile();
            String fileName = rs.getString("FILE_NAME");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            while (st.hasMoreTokens())
            {
                corporateFile.setSno((rs.getString("SNO")));
                corporateFile.setFileName(st.nextToken());
                corporateFile.setUploaderName(rs.getString("USERNAME"));
                corporateFile.setUploadedDate(rs.getTimestamp("CREATION_TIME"));
             	corporateFile.setTpStatus(rs.getString("FILE_STATUS"));
            }
            
            return corporateFile;
        }
    }
    //Added for mmobile Registration Phase 2
    
    // Added for Reject Inter Bank Beneficiary File - Start
    public class ViewCorporateBenFileRowMapper implements RowMapper
    {
                    

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateFile corporateFile = new CorporateFile();
            Integer activeCount=0;
            Integer inactiveCount=0;
            Integer rejectedCount=0;
            Integer pendingCount=0;
            String resultStr="";
            String benFileViewStatus="";
            String fileName = rs.getString("file_name");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            
            while (st.hasMoreTokens())
            {
	            corporateFile.setSno((rs.getString("file_no")));
	            corporateFile.setFileName(st.nextToken());
	            corporateFile.setUploaderName(rs.getString("username"));
	            corporateFile.setUploadedDate(rs.getTimestamp("creation_time"));
	         	//corporateFile.setTpStatus(rs.getString("FILE_STATUS"));
	
	            activeCount=Integer.parseInt(rs.getString("ACTIVE_COUNT"));
	            inactiveCount=Integer.parseInt(rs.getString("INACTIVE_COUNT"));
	            rejectedCount=Integer.parseInt(rs.getString("REJECTED_COUNT"));
	            pendingCount=Integer.parseInt(rs.getString("PENDING_COUNT"));
	
	            if(activeCount>0)
	            {
	            	resultStr+="A";
	            }
	            if(inactiveCount>0)
	            {
	            	resultStr+="I";
	            }
	            if(rejectedCount>0)
	            {
	            	resultStr+="R";
	            }
	            if(pendingCount>0)
	            {
	            	resultStr+="P";
	            }
	            
	            resultStr=resultStr.trim();
	            if(resultStr.length()==1)
	            {
	            	if("A".equals(resultStr))
	            			benFileViewStatus="Approved";
	            	else if("I".equals(resultStr))
	            		benFileViewStatus="Deleted";
	            	else if("R".equals(resultStr))
	            		benFileViewStatus="Rejected";
	            	else if("P".equals(resultStr))
	            		benFileViewStatus="Pending for approval";
	            	
	            }
	            else if(resultStr.length()==2)
	            {
	            	if("AI".equals(resultStr) || "AR".equals(resultStr))
	            		benFileViewStatus="Partially Approved/Rejected";
	            	else if("AP".equals(resultStr))
	            		benFileViewStatus="Partially Approved";
	            	else if("IR".equals(resultStr) || "IP".equals(resultStr) || "RP".equals(resultStr))
	            		benFileViewStatus="Partially Rejected";
	            }
	            else if(resultStr.length()==3 || resultStr.length()==4)
	            {
	            	benFileViewStatus="Partially Approved/Rejected";
	        	}
	            logger.info("fileBenStatus"+benFileViewStatus);
	            corporateFile.setBenFileViewStatus(benFileViewStatus);
	            
            }
	        return corporateFile;  
        }
     }

    /**
     * This method is used to Reject all the third parties listed in the
     * particluar file selcted by the Admin,Regulator or Approver.
     */
    public boolean rejectTPStateALL(String userName, String filename, String bankType, String corporateID)
    {
        logger.info("rejectTPStateALL(String userName,String filename,String bankType, String corporateID )"+ LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName + "filename :" + filename + "bankType  " + bankType + " corporateID :" + corporateID );
        
        int rejectedCount = 0;
        try
        {
        	/* Ramanan M - Corp Admin Paladion Security Changes */
            Object[] approvedParams = new Object[] { userName, filename, corporateID };
            Object[] param = new Object[] { userName,filename, corporateID };
            if (bankType.equals("IBTP"))// modified  for DFC
            {
            	rejectedCount = getJdbcTemplate().update(rejectUpdateQuery, approvedParams);
            	if (rejectedCount <= 0) {
					DAOException.throwException("RTGS018");
				} else {
					try {
						Object params[] = { "RTGSA005", this.getClass().getName(), "rejectTPStateALL", userName, filename,bankType, corporateID, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
						int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY,
								params, sqlTypes);
						logger.info("Count :" + count);
					} catch (Exception e) {
						logger.error("Failed to insert in wac_audit_trail for corporateID : " +corporateID +" and file name :" +filename);
					}

				}
            }

            logger.info("rejectTPState  :" + rejectedCount);
        }
        catch (DataAccessException ex)
        {
            DAOException.throwException("F001", ex);
        }

        logger.info("rejectTPStateALL(String userName,String filename,,String bankType, String corporateID)" + LoggingConstants.METHODEND);
        return true;
    }
    /**
     * This method is used to update the status of the third parties in the file
     * rejected by Admin,Regulator or Approver.
     */
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean rejectTPState(String rejectedOIDs, String userName, String bankType, String corporateID)
    {
        logger.info("rejectTPState(String rejectedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);
        int rejectedCount = 0;
        if (rejectedOIDs != null && rejectedOIDs.trim().length() > 0)
        {

            try
            {
            	/* Ramanan M - Corp Admin Paladion Security Changes */
                Object[] rejectedBeneficiaryParams = new Object[] { userName, corporateID };
                if (bankType.equals("IBTP"))// modified  for DFC
                {
                    String rejectBeneficiaryQuery = UPDATE_TP_STATE_REJECTED.replaceAll("#tobereplaced#", rejectedOIDs);
                    rejectedCount = getJdbcTemplate().update(rejectBeneficiaryQuery, rejectedBeneficiaryParams);
                    logger.info("rejectedCount " + rejectedCount + ", rejectedOIDs : " + rejectedOIDs);
                    
                    if (rejectedCount <= 0) {
    					DAOException.throwException("RTGS018");
    				} else {
    					try {
    						Object params[] = { "RTGSA005", this.getClass().getName(), "rejectTPState", rejectedOIDs, userName, bankType, corporateID,"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
    						int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
    						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY, params, sqlTypes);
    					} catch (Exception e) {
    						logger.error("Failed to insert in wac_audit_trail for corporateID : " +corporateID +" and rejectedOIDs :"+rejectedOIDs);
    					}

    				}
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }     
        logger.info("rejectTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return true;
    }
    // Added for Reject Inter Bank Beneficiary File - End
    
    // Added for Reject Intra Bank Beneficiary File - Start
    public boolean rejectTPFile(String userName,String fileName) {
	    logger.info("rejectTPFile(String userName,String fileName)"+ LoggingConstants.METHODBEGIN);
	    logger.info("userName :"+userName+" fileName :"+fileName);
	    try {
		    int rejectedCount = 0;
		    Object[] approvedParams = new Object[] {userName,fileName };
		    rejectedCount = getJdbcTemplate().update(REJECT_TP_APPROVED_FILE,approvedParams);
		    logger.info("rejectedCount : " + rejectedCount);
		    if (rejectedCount <= 0) {
				DAOException.throwException("RTGS018");
			} else {
				try {
					Object params[] = { "RTGSA005", this.getClass().getName(), "rejectTPFile", userName, fileName,"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""};
					int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
							Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
							Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
							Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
							Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
					int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY,
							params, sqlTypes);
					logger.info("Count :" + count);
				} catch (Exception e) {
					logger.error("Failed to insert in wac_audit_trail for userName : " +userName +" and file name :" +fileName);
				}
			}
	    }
	    catch (DataAccessException ex) {
		    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	    }
	    logger.info("rejectTPFile(String userName,String fileName)"+ LoggingConstants.METHODEND);
	    return true;
    }
    // Added for Reject Intra Bank Beneficiary File - End
    
    // Find 3P ERror count
    
	public String findErrorCount(String fileno) throws DAOException {
		logger.info("findErrorCount(String fileno) method begins");
		logger.info("fileno: " + fileno);
		String  Countval = null;
		try{
			Object[] params={fileno};
			Countval =  (String) getJdbcTemplate().queryForObject(FETCH_ERROR_COUNT, params, String.class);
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		
		logger.info("findErrorCount(String fileno) method ends");
		return Countval;
	}
}
