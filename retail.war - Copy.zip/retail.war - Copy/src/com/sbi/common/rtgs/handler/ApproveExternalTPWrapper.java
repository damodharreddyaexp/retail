/**ApproveExternalTPWrapper.java
 * Created on Jan '08 by Treesa for RTGS 3P Upload
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */
package com.sbi.common.rtgs.handler;

import org.displaytag.decorator.TableDecorator;
import  com.sbi.common.rtgs.model.CorporateFile;
import com.sbi.common.rtgs.model.CorporateTP;

public class ApproveExternalTPWrapper extends TableDecorator
{       
    /**
     * 
     * TODO This method is used to provide the hyperlink for the file name displayed.
     * @return String
     */
public String getFileName()
{
    CorporateFile corporateFile=  (CorporateFile) super.getCurrentRowObject();          
    String fileName="&nbsp;";    
    if(corporateFile!= null)
    {
        fileName="<a href=\"javaScript:submitApproveBulkThirdPartisForm('"+ corporateFile.getFileName() +"','"+ corporateFile.getBankType() +"','"+corporateFile.getFunctionType()+"');\" onMouseOver=\"statusChange();return true;\">" + corporateFile.getFileName()+" </a>";
    }
    return fileName;
}  
/**
 * 
 * TODO This method is used to display checkboxes and assign values to it.
 * @return String
 */
public String getOutRef7()
{
    
CorporateTP corporateFile=  (CorporateTP)super.getCurrentRowObject();          
String outRef7="&nbsp;";    

String status=corporateFile.getStatus().toString();
String delectionFileNo=corporateFile.getDeletionFileNo();
String delectionApprovedBy=corporateFile.getDeletionApprovedBy();


if(status.equalsIgnoreCase("0"))
{
    if(delectionApprovedBy != null && !delectionApprovedBy.equalsIgnoreCase(""))
    {
        outRef7="<input id='check'  name='check' type='checkbox' disabled checked value=\"'" +corporateFile.getOid() +"',\">";
        outRef7=  outRef7+"<input type='hidden' name='rec_selected' id='rec_selected' value='True'>";
        
    }else{
    outRef7="<input id='check'  name='check' type='checkbox' checked value=\"'" +corporateFile.getOid() +"',\">";
    outRef7=  outRef7+"<input type='hidden' name='rec_selected' id='rec_selected' value='True'>";
    }
    
}
else if(status.equalsIgnoreCase("1"))
{
    if(delectionApprovedBy != null && !delectionApprovedBy.equalsIgnoreCase(""))
    {
        outRef7="<input id='check' name='check' type='checkbox' disabled value=\"'" +corporateFile.getOid() +"',\">";   
    }else
    {
    outRef7="<input id='check' name='check' type='checkbox'  value=\"'" +corporateFile.getOid() +"',\">";
    }
    
}
else if(status.equalsIgnoreCase("2"))  //Added for Reject Beneficiary
{
	outRef7="<input id='check' name='check' type='checkbox' disabled value=\"'" +corporateFile.getOid() +"',\">";
}

return outRef7;
}   
//added for default file config to show the status of the file
public String getStatus()
{
    
CorporateTP corporateFile=  (CorporateTP)super.getCurrentRowObject();          
String dibtpStatus="&nbsp;";    

String status=corporateFile.getStatus().toString();


if(status.equalsIgnoreCase("0"))
{
    
    
    
    dibtpStatus=  "Inactive";
   
    
}
else if(status.equalsIgnoreCase("1"))
{
    
    dibtpStatus=  "Active";
}

return dibtpStatus;
}   
}
    