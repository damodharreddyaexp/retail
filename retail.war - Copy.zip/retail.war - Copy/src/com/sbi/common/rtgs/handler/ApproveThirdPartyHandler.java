/* *
 * ApproveThirdPartyHandler.java
 * Created on Jan '08 by Treesa for RTGS 3P Upload
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 */

package com.sbi.common.rtgs.handler;
  

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.FilesDownloadUtils;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.RandomString;
public class ApproveThirdPartyHandler extends MultiActionController {

    protected final Logger logger = Logger.getLogger(getClass());

    BaseService approveExternalTPService;

    BaseService approveExternalTPFileService;

    BaseService approveExternalTPConfirmService;
    
    private BaseService  get3PErrorCountService;
    
    BaseService verify3PforDeleteService;
    //Added for Prepaid Card Module
    BaseService approvePrePaidBenFileService;
    
    BaseService approvePrepaidBenConfirmService;
     /*Added by Sairam Mobile Registration Phase2 - Start*/
   	public BaseService approveFileConfirmService; 
  

/*Added by Sairam Mobile Registration Phase2 - End*/
    //End Module
    
    BaseService approveExternalTPServiceView;
//Added for mobile Registration Phase 2
    BaseService approvePrePaidFileServiceView;
    
    BaseService approvePrepaidTPService;

    /*Added for Enhancement in approve beneficiary -Phase I - Start*/
    private BaseService downloadApproveBenFileService;
    
    private FilesDownloadUtils filesDownloadUtils;
    
    private RandomString randomString;
    
    private ReverseFileConverter reverseFileConverter;
    /*Added for Enhancement in approve beneficiary -Phase I - End*/

	private ResourceBundleMessageSource transactionProperties;


/**
 * This Method is executed to display the files pending to approve or delete the Thirdparty 
 * It calls ApproveTPService by
 * passing Map as a inparam which has startdate,enddate,username,banktype,functiontype
 * depends on the function Type view name will get change for DIBTP
 * 
 * @param request
 * @param response
 * */
    public ModelAndView approveTPDisplayHandler(HttpServletRequest request,
            HttpServletResponse responce) {
        logger.info("approveTPDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String viewName;// added for default file config starts here
        String errorView;
        String bankType;
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");
        String functionType = request.getParameter("functionType");
        String urlSelected = request.getServletPath().substring(1);
        String corporateId = user.getCorporateId();
        logger.info("start date :" + startDate + "," + "End Date :" + endDate+ "functionType :"+functionType);
        if (urlSelected.equals("approvedeltpdisplay.htm"))
        {
            if(functionType.equalsIgnoreCase("view")){
                viewName = "viewDelTpdisplay";
                errorView = "errorviewDelTpdisplay";
           }
            else{
                viewName = "approveDelTpdisplay";
                errorView = "errorapproveDelTpdisplay";
            }
            bankType="DIBTP";
        }
        //Added for mobile Registration Phase 2
        //vijaya added for fetching pending recrods

        else if ("approveprepaidbendisplay.htm".equals(urlSelected))
        {
        	viewName = "approveprepaidbendisplaydetails";
        	errorView = "errorapproveprepaidbendisplaydetails";
        	bankType="PC";
        	logger.info("bankType" +bankType);
        }
        else if ("approveprepaidbendisplayview.htm".equals(urlSelected))
        {
            viewName = "approveprepaidbendisplayview";
            errorView = "errorapproveprepaidbendisplayview";
            bankType="PC";
        }
        else if ("approvebulkexternalthirdpartyview.htm".equals(urlSelected))
        {
            viewName = "approveBulkexternalThirdPartiesView";
            errorView = "approvebulkexternalthirdpartieserrorView";
            bankType="IBTP";
        }
        else
        {
            viewName = "approveBulkexternalThirdPartiesAdmin";
            errorView = "approvebulkexternalthirdpartieserrorAdmin";
            bankType="IBTP";
        }

        Integer userRole = (Integer) user.getRoles().get(0);
        Integer roleValue=(Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        inputParam.put("userName", userName);
        inputParam.put("bankType", bankType);
        inputParam.put("startDate", startDate);
        inputParam.put("endDate", endDate);
        inputParam.put("functionType", functionType);
        inputParam.put("corporateId",corporateId);
      //Approver 3rdparty  enhancement changes 
		String UploaderID = request.getParameter("UploaderID");
		inputParam.put("UploaderID", UploaderID);
		session.setAttribute("UploaderID",UploaderID);
		
        logger.info("roleValue "+roleValue);
        logger.info("corporateID :" + corporateId);
        if (roleValue.intValue()==7 || roleValue.intValue()==42)
        {  
            logger.info("roleValue if "+roleValue);          
        outputParam = verify3PforDeleteService.execute(inputParam); 
        String status  = (String) outputParam.get("status");
        if(status.equalsIgnoreCase("1"))  
        {
             
            SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
            outputParam.put(UIConstant.APPLICATION_RESPONSE, errorResponse);
            outputParam.put(UIConstant.ERROR_VIEW, errorView);
            return new ModelAndView(viewName,"approveTPDisplayDetails", outputParam);
        }
        }
// added for default file config ends here
        logger.info("bankType" +bankType);
        if((("PC".equals(bankType) || "SMT".equals(bankType) || "UAE".equals(bankType)) && viewName=="approveprepaidbendisplayview")
        	||	(bankType.equalsIgnoreCase("IBTP") && viewName=="approveBulkexternalThirdPartiesView")){
        	logger.info("Execute PC Service View");
        	outputParam = approvePrepaidTPService.execute(inputParam);
        	}
        else
        outputParam = approveExternalTPService.execute(inputParam);
        session.setAttribute("approveTPFileDetails",outputParam.get("approveTPFileDetails"));
        outputParam.put("applicationResponse", outputParam.get("applicationResponse"));
        outputParam.put("errorView",errorView);
        outputParam.put("functionType",functionType);
        outputParam.put("bankType",bankType);
        outputParam.put("userRole", userRole); //Added for Pre Paid Card Module.
        /* Added by Sairam Mobile Registration Phase2 - Start */	     
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        String ehsEnable =null;
        String ehsType =null;
        String transactionName = "ApproveBenFile";;  
		// added for CR 5756 
        if ("PC".equalsIgnoreCase(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType)){
        	transactionName = "ManagePrepaidCard";
        }
		// CR 5756 ends here
        if(corporateProfile != null){
        	ehsEnable = corporateProfile.getEhsEnable();
        	ehsType = corporateProfile.getEhsType();
        }
        logger.info("ehsEnable :"+ehsEnable);
        logger.info("ehsType :"+ehsType);
        outputParam.put("ehsEnable", ehsEnable);
        outputParam.put("ehsType", ehsType);
        outputParam.put("transactionName", transactionName);
        /* Added by Sairam Mobile Registration Phase2 - End */
       session.setAttribute("bankType", bankType);
        logger.info("viewName :"+viewName);
        logger.info("functionType :"+functionType);
        logger.info("approveTPDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"approveTPDisplayDetails", outputParam);
    }
    
  //Added for Mobile Registration Phase-2 Starts
    public ModelAndView approveTPFileDisplayHandlerView(HttpServletRequest request,
            HttpServletResponse responce) {
        logger.info("approveTPFileDisplayHandlerView(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveTPFileDetails = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String viewName;
        String errorView;
        String tpFileName = request.getParameter("fileName");
     //   String bankType = request.getParameter("bankType");
        String bankType=(String) session.getAttribute("bankType");
        logger.info("BANK TYPE  :"+bankType);
        inputParam.put("userName", userName);
        inputParam.put("tpFileName", tpFileName);
        String noOfRows="100";
        inputParam.put("noOfRows",noOfRows);
        Integer userRole = (Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        approveTPFileDetails.put("tpFileName",tpFileName);   
        inputParam.put("bankType", bankType);
        if("PC".equals(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType)){
            outputParam = approvePrePaidFileServiceView.execute(inputParam);
            viewName="approvePrepaidCardFileView";
            errorView="approvebulkexternalthirdpartiesfileerrorView";
        }
        else{
        	outputParam = approveExternalTPFileService.execute(inputParam);
            viewName="approveBulkexternalThirdPartiesFileView";
            errorView="approvebulkexternalthirdpartiesfileerrorView";
        }
        session.setAttribute("approveFileDetails",outputParam.get("approveTPFileDetails"));
        approveTPFileDetails.put("approveFileDetails", outputParam.get("approveTPFileDetails"));
        approveTPFileDetails.put("tpFileName", tpFileName);
        approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
        approveTPFileDetails.put("noOfRows","100");
        approveTPFileDetails.put("totalPage",outputParam.get("totalPage"));
        approveTPFileDetails.put("bankType",bankType);
        approveTPFileDetails.put("applicationResponse", outputParam.get("applicationResponse"));
        approveTPFileDetails.put("deleteCount", outputParam.get("deleteCount"));
        approveTPFileDetails.put("errorView",errorView);
        logger.info("approveTPFileDisplayHandlerView(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"approveTPFileDetails", approveTPFileDetails);
    }
    
    /**
     * This Method is executed to display the contents of the file pending to approve or delete the Thirdparty 
     * It calls ApproveTPService by
     * passing Map as a inparam which has file name,banktype and function type
     * 
     * @param request
     * @param response
     * */    
    public ModelAndView approveTPFileDisplayHandler(HttpServletRequest request,
            HttpServletResponse response) {
        logger.info("approveTPFileDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map outParams = new HashMap();
        Map approveTPFileDetails = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String viewName;
        String errorView;
        String transactionName = null; //Added by Sairam Mobile Registration Phase2
        String tpFileName = request.getParameter("fileName");
        String bankType = request.getParameter("bankType");//added for default file config 
        String functionType = request.getParameter("functionType");
        String urlSelected = request.getServletPath().substring(1);  //added for htm filter for count pages
        inputParam.put("userName", userName);
        inputParam.put("tpFileName", tpFileName);
        String noOfRows="100";
        inputParam.put("noOfRows",noOfRows);
        Integer userRole = (Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        approveTPFileDetails.put("tpFileName",tpFileName);   
        inputParam.put("bankType", bankType);//added by siva for default file config 
        inputParam.put("functionType", functionType);
        //Modified for Prepaid card Module
        if("PC".equals(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType))
            outputParam = approvePrePaidBenFileService.execute(inputParam);
        else
        outputParam = approveExternalTPFileService.execute(inputParam);
        //Modified for Prepaid card Module
        if (bankType.equals("DIBTP"))
        {
            if(functionType.equalsIgnoreCase("view")){
                viewName = "viewDelTpFileDisplay";
                errorView = "errorviewDelTpFileDisplay";
       
            }else{
                viewName = "approveDelTpFileDisplay";
                errorView = "errorapproveDelTpFileDisplay";
            }
        }//Modified for Prepaid card Module
        else if("PC".equals(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType) ){
            viewName = "findprepaidbenfiledisplay";
            errorView = "errorfindprepaidbenfiledisplay";
            transactionName = "ManagePrepaidCard";            //Added by Sairam Mobile Registration Phase2 
            logger.info("viewName ::::::"+viewName);
        }//Modified for Prepaid card Module
        else
        {
        	if(functionType.equalsIgnoreCase("view")){
        		viewName = "approveBulkexternalThirdPartiesFileView";
        		errorView="approvebulkexternalthirdpartiesfileerrorView";
        	}
        	else
        	{
              if (urlSelected!=null && urlSelected.equals("approveexternalthirdpartiescountfilenameadmin.htm"))
 		        {
            	  outParams = get3PErrorCountService.execute(inputParam);
 				 approveTPFileDetails.put("Countval", outParams.get("Countval"));
            	viewName = "BulkExternalTPCountFileNameAdmin";
 		        }
 			   else
 			   {
                 viewName = "BulkExternalTPFileNameAdmin";
 			   }
            errorView = "bulkexternalthirdpartiesfileerrorAdmin";
            transactionName = "ManInterBkAppBenFile";      ////Added by Sairam Mobile Registration Phase2 
        }
            
        }
        logger.info("viewName ::::::"+viewName);
     
        /* Added by Sairam Mobile Registration Phase2 - Start */	     
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        String ehsEnable =null;
        String ehsType =null;
        
        if(corporateProfile != null){
        	ehsEnable = corporateProfile.getEhsEnable();
        	ehsType = corporateProfile.getEhsType();
        }
        logger.info("ehsEnable :"+ehsEnable);
        logger.info("ehsType :"+ehsType);
        approveTPFileDetails.put("ehsEnable", ehsEnable);
        approveTPFileDetails.put("ehsType", ehsType);
        approveTPFileDetails.put("transactionName", transactionName);
        /* Added by Sairam Mobile Registration Phase2 - End */
       
        
        session.setAttribute("approveFileDetails",outputParam.get("approveTPFileDetails"));
        approveTPFileDetails.put("approveFileDetails", outputParam.get("approveTPFileDetails"));
        approveTPFileDetails.put("tpFileName", tpFileName);
        approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
        approveTPFileDetails.put("noOfRows","100");
        approveTPFileDetails.put("totalPage",outputParam.get("totalPage"));
        approveTPFileDetails.put("bankType",bankType);//added for default file config
        approveTPFileDetails.put("functionType",functionType);
        approveTPFileDetails.put("applicationResponse", outputParam.get("applicationResponse"));
        approveTPFileDetails.put("deleteCount", outputParam.get("deleteCount"));
        approveTPFileDetails.put("errorView",errorView);
        logger.debug("approveTPDisplayHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"approveTPFileDetails", approveTPFileDetails);
    }
    /**
     * This Method is executed to approve the ThirdParty,prepaid card and to delete the Thirdparty 
     * It calls ApproveTPService by
     * passing Map as a inparam which has  approvedIds,unApprovedIds,filename,banktype and function type
     * 
     * @param request
     * @param response
     * */

    public ModelAndView approveTPConfirmationHandler(
            HttpServletRequest request, HttpServletResponse response) {
        logger.info("approveTPConfirmationHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveDetailsConfirm = new HashMap();
        String approveIds;
        String unApproveIds;
        String approvedIds; //Added by Sairam Mobile Registration Phase2 
        String unApprovedIds; //Added by Sairam Mobile Registration Phase2 
        String fileName;
        String approveall;
        String viewName;
        String errorView;
        approveIds = request.getParameter("approveIds");//Change by Sairam Mobile Registration Phase2
        unApproveIds = request.getParameter("unApproveIds");//Change by Sairam Mobile Registration Phase2
        unApprovedIds = request.getParameter("unApprovedIds");//Added by Sairam Mobile Registration Phase2 
        approvedIds = request.getParameter("approvedIds");//Added by Sairam Mobile Registration Phase2 
        fileName = request.getParameter("tpFileName");
        approveall=request.getParameter("Approveflag");
        String bankType = request.getParameter("bankType");//added for default file config 
        String functionType = request.getParameter("functionType");
        String actionType=null; //Change by Sairam Mobile Registration Phase2
        actionType = request.getParameter("actionType");
        logger.info("actionType:::: "+actionType);
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String corporateId = user.getCorporateId();
        String userName = user.getUserAlias();
        Integer userRole = (Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        inputParam.put("tpFileName", fileName);
        inputParam.put("coporateID", corporateId);
        inputParam.put("userName", userName);
        inputParam.put("corporateId", user.getCorporateId());//shanta
        inputParam.put("approveIds", approveIds);
        inputParam.put("unApproveIds", unApproveIds);
        inputParam.put("Approveflag",approveall);
        inputParam.put("bankType",bankType);
        inputParam.put("functionType",functionType);
        inputParam.put("actionType",actionType);
        inputParam.put("unApprovedIds",unApprovedIds);//Added by Sairam Mobile Registration Phase2 
        inputParam.put("approvedIds",approvedIds);
        logger.info("approveIds:::: "+approveIds);
        logger.info("unApproveIds:::: "+unApproveIds);
        logger.info("approvedIds:::: "+approvedIds);
        logger.info("unApprovedIds:::: "+unApprovedIds);
        //Modified for Prepaid card Module
        if("PC".equals(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType))
            outputParam = approvePrepaidBenConfirmService.execute(inputParam);
        else
        outputParam = approveExternalTPConfirmService.execute(inputParam);
        //Modified for Prepaid card Module
        if (bankType.equals("DIBTP"))
        {
            if(approveall.equalsIgnoreCase("true"))
            {    
                viewName = "bulkapproveDelDetailsConfirm";   
            }else{
                viewName = "approveDelDetailsConfirm";   
            }
            errorView = "errorapproveDelDetailsConfirm";
        } //Modified for Prepaid card Module
        else if("PC".equals(bankType)|| "SMT".equals(bankType) || "UAE".equals(bankType))
        {
            viewName = "bulkPrepaidBenConfirm";
            errorView = "bulkPrepaidBenErrorConfirm";
        } //Modified for Prepaid card Module
        else
        {
            viewName = "BulkExternalTPConfirmAdmin";
            errorView = "bulkexternalthirdpartiesconfirmerrorAdmin";
        }
        approveDetailsConfirm.put("tpFileName", fileName);
        approveDetailsConfirm.put("approveFileConfirmDetails", outputParam.get("approveTPFileConfirmDetails"));
        approveDetailsConfirm.put("approvedList",outputParam.get("approvedList"));
        approveDetailsConfirm.put("unApprovedList",outputParam.get("unApprovedList"));
		// Added for Reject Benificiary File
        approveDetailsConfirm.put("rejectedList",outputParam.get("rejectedList"));
        approveDetailsConfirm.put("approveall",outputParam.get("approveall"));//added  by siva for DFC
        approveDetailsConfirm.put("bankType",bankType);
        approveDetailsConfirm.put("functionType",functionType);
        if(actionType != null && actionType.trim().length()>0){
        	logger.info("Inside actionType if:::");
        	approveDetailsConfirm.put("actionType",actionType.toLowerCase());
        }
        approveDetailsConfirm.put("applicationResponse", outputParam.get("applicationResponse"));
        approveDetailsConfirm.put("errorView",errorView);
        return new ModelAndView(viewName,"approveDetailsConfirm", approveDetailsConfirm);
    }
    
    /* //Added by Sairam Mobile Registration Phase2 - start*/
    public ModelAndView approveFileConfirmHandler(
            HttpServletRequest request, HttpServletResponse response) {
    	  logger.info("approveFileConfirmHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);	
    	 Map inputParams = new HashMap();
         Map outputParam = new HashMap();
    	String fileName = request.getParameter("approveFileName");
    	String bankType = request.getParameter("bankType");//added for default file config 
    	HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String corporateId = user.getCorporateId();
        String userName = user.getUserAlias();
        Integer userRole = (Integer) user.getRoles().get(0);
        String functionType = request.getParameter("functionType");
       // String actionType ="AppInterBankBenFile";
        String actionType=  request.getParameter("actionType");
    	logger.info("fileName>>>>"+fileName);
    	logger.info("fileName>>>>"+fileName);
    	logger.info("actionType>>>>"+actionType);
    	inputParams.put("fileName",fileName);
    	inputParams.put("bankType",bankType);
    	inputParams.put("userName",userName);
    	inputParams.put("userRole",userRole);
    	inputParams.put("functionType",functionType);
    	inputParams.put("actionType",actionType);
		inputParams.put("corporateId",corporateId);
    	outputParam = approveFileConfirmService.execute(inputParams);
    	
		
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam
				.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response = "
				+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		logger.info("Error status : " + errorResponse.getErrorStatus());
		logger.info("Error code : " + errorResponse.getErrorCode());
		logger.info("Error message : " + errorResponse.getErrorMessage());
		logger.info("Application response : "
				+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put("actionType", actionType);
		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.ERROR_VIEW,"bulkthirdpartiesconfirmerrorAdmin");

    	 return new ModelAndView("ApproveInterBKFileConfirm","approveDetailsConfirm", outputParam);	
    }
    
    
    /* //Added by Sairam Mobile Registration Phase2 - end*/

    
    
    /*Added for Enhancement in approve beneficiary -Phase I - Start*/
    
    public ModelAndView downloadapproveTPFileHandler(HttpServletRequest request,
            HttpServletResponse response)  throws Exception {
        logger.info("downloadapproveTPFileHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveTPFileDetails = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String viewName="";
        String errorView;
        StringBuffer textBuffer = new StringBuffer();
        CorporateTP corporateTp = new CorporateTP();
        String fileName = request.getParameter("approveFileName");
        String bankType = request.getParameter("bankType"); 
        String functionType = request.getParameter("functionType");
        inputParam.put("userName", userName);
        inputParam.put("fileName", fileName);
        Integer userRole = (Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        inputParam.put("bankType", bankType); 
        inputParam.put("functionType", functionType);
        
        logger.info("fileName :"+fileName);
        logger.info("bankType :"+bankType);
      logger.info("functionType :"+functionType);
        logger.info("userName :"+userName);
        logger.info("userRole :"+userRole);
        
        outputParam = downloadApproveBenFileService.execute(inputParam);
        textBuffer = reverseFileConverter.csvInterBankBeneficiaryConverter(outputParam);
        String filename = randomString.getRandomString()+randomString.getRandomString();  
        String filenameConcat = randomString.getRandomString();
        filename = filename+filenameConcat;
        filesDownloadUtils.downloadMsExcel(filename,response,textBuffer); 
   
     
        return null;
    } 
   
    /*Added for Enhancement in approve beneficiary -Phase I - End*/
    
  /*  Added for UAE Card */
    
    public ModelAndView managePrepaidCardDisplay(HttpServletRequest request, HttpServletResponse response) throws IOException {
        logger.info("managePrepaidCardDisplay(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outputParam = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String corpId=user.getCorporateId();
        String cardReq="No";
        try{
        	
        	cardReq=transactionProperties.getMessage("UAECardRequired."+corpId, null, null);
        

        }catch(Exception exp){
            logger.error(LoggingConstants.EXCEPTION + exp);

        } 
        
        String urlSelected = request.getServletPath().substring(1);
        String viewName="";
        String errorView="";
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outputParam.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
		outputParam.put(UIConstant.ERROR_VIEW,"errorapproveprepaidbendisplay");
		outputParam.put("urlSelected",urlSelected);		
		outputParam.put("cardReq", cardReq) ;

        logger.info("managePrepaidCardDisplay(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);
        return new ModelAndView("approveprepaidbendisplay","approveTPDisplayDetails", outputParam);
        
    }
    
    public void setApproveExternalTPConfirmService(BaseService approveExternalTPConfirmService)
    {
        this.approveExternalTPConfirmService = approveExternalTPConfirmService;
    }

    public void setApproveExternalTPFileService(BaseService approveExternalTPFileService)
    {
        this.approveExternalTPFileService = approveExternalTPFileService;
    }

    public void setApproveExternalTPService(BaseService approveExternalTPService)
    {
        this.approveExternalTPService = approveExternalTPService;
    }


    public void setVerify3PforDeleteService(BaseService verify3PforDeleteService)
    {
        this.verify3PforDeleteService = verify3PforDeleteService;
    }
    //Added for Prepaid card Module
	public void setApprovePrePaidBenFileService(
			BaseService approvePrePaidBenFileService) {
		this.approvePrePaidBenFileService = approvePrePaidBenFileService;
	}
  //End Module
  
	public void setApprovePrepaidBenConfirmService(
			BaseService approvePrepaidBenConfirmService) {
		this.approvePrepaidBenConfirmService = approvePrepaidBenConfirmService;
	}
	//Aded for Mobile Registration Phase-2 
	public void setApprovePrePaidFileServiceView(
			BaseService approvePrePaidFileServiceView) {
		this.approvePrePaidFileServiceView = approvePrePaidFileServiceView;
	}

	public void setApprovePrepaidTPService(BaseService approvePrepaidTPService) {
		this.approvePrepaidTPService = approvePrepaidTPService;
	}
	
	
	public void setApproveFileConfirmService(BaseService approveFileConfirmService) {
		this.approveFileConfirmService = approveFileConfirmService;
		}
	
	 /*Added for Enhancement in approve beneficiary -Phase I - Start*/
	public void setDownloadApproveBenFileService(
			BaseService downloadApproveBenFileService) {
		this.downloadApproveBenFileService = downloadApproveBenFileService;
	}
	
	public void setFilesDownloadUtils(FilesDownloadUtils filesDownloadUtils) {
		this.filesDownloadUtils = filesDownloadUtils;
	}
	
	 public void setRandomString(RandomString randomString)
	   {
	      this.randomString = randomString;
	   }
	 
	 public void setReverseFileConverter(ReverseFileConverter reverseFileConverter) {
			this.reverseFileConverter = reverseFileConverter;
		}

	public void setTransactionProperties(
			ResourceBundleMessageSource transactionProperties) {
		this.transactionProperties = transactionProperties;
	}




	 /*Added for Enhancement in approve beneficiary -Phase I - End*/
	 //added for Enhancement in approve 3P
	 public void setGet3PErrorCountService(BaseService get3PErrorCountService) {
	        this.get3PErrorCountService = get3PErrorCountService;
	    }

}
