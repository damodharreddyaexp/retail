/**ApprovePrePaidBenWrapper.java
 * Created on Feb '09 by Madhan for Pre Paid Card Module
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2009 by SBI All Rights Reserved.
 * 
 */
package com.sbi.common.rtgs.handler;

import org.displaytag.decorator.TableDecorator;
import  com.sbi.common.rtgs.model.CorporateFile;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.rtgs.model.PrePaidCardBeneficiary;

public class ApprovePrePaidBenWrapper extends TableDecorator
{       
public String getFileName()
{
    CorporateFile corporateFile=  (CorporateFile) super.getCurrentRowObject();          
    String fileName="&nbsp;";    
    if(corporateFile!= null)
    {
        fileName="<a href=\"javaScript:submitApprovePrePaidBenisForm('"+ corporateFile.getFileName() +"','"+ corporateFile.getBankType() +"','"+corporateFile.getFunctionType()+"');\" onMouseOver=\"statusChange();return true;\">" + corporateFile.getFileName()+" </a>";
    }
    return fileName;
}  
/**
 * 
 * TODO This method is used to display checkboxes and assign values to it.
 * @return String
 */
public String getOutRef7()
{
    
	PrePaidCardBeneficiary prePaidCardBeneficiary=  (PrePaidCardBeneficiary)super.getCurrentRowObject();          
	String outRef7="&nbsp;";    
    outRef7="<input id='check' name='check' type='checkbox' value=\"'" +prePaidCardBeneficiary.getId() +"',\">";
    return outRef7;
}   
 
public String getPrepaidStatementRadio()
{
    
	PrePaidCardBeneficiary prePaidCardBeneficiary=  (PrePaidCardBeneficiary)super.getCurrentRowObject();
	String prepaidStatementRadio="&nbsp;";    
	prepaidStatementRadio="<input id='stmtid'  name='stmtid' type='checkbox' value='|" +prePaidCardBeneficiary.getId()+","+prePaidCardBeneficiary.getCardNumber()+","+prePaidCardBeneficiary.getCardReferenceNo()+","+prePaidCardBeneficiary.getCardHolderName()+"' onClick=\"javaScript:loadStatementRequestDetails('"+prePaidCardBeneficiary.getId()+"','"+prePaidCardBeneficiary.getCardHolderName()+"','"+prePaidCardBeneficiary.getCardNumber()+"','"+prePaidCardBeneficiary.getCardReferenceNo()+"');\">";
	return prepaidStatementRadio;
}
}
    