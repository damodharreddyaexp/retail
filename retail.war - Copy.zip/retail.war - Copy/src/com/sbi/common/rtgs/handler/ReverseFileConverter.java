/*        
 * FileConverter.java
 * Created on Nov 15, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $ 
 */
//History
//Nov 15, 2005 MURUGAN K - Initial Creation
//Nov 18, 2005 MURUGAN K - method implemetation in for pdf convertor and cvs convertor
//Dec 22, 2005 KRISHNA   - Commons logging removed and log4j method added.
package com.sbi.common.rtgs.handler;


import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.rtgs.model.CorporateTP;


/**
 * TODO This class is used to display the datas into CVS format. 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class ReverseFileConverter
{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	  public StringBuffer csvInterBankBeneficiaryConverter(Map inputParams)
	    {
	logger.info("csvInterBankBeneficiaryConverter(Map inputParams) begin with inputParams - Start"+inputParams);
	        
	        StringBuffer outBuffer = new StringBuffer();
	        CorporateTP[] corporateTP = null;
	        	StringBuffer detailsBuf = new StringBuffer();
	        		detailsBuf.append("Name of the Beneficiary" + "\t");
	        		detailsBuf.append("Account No" + "\t");
	        		detailsBuf.append("IFSC Code" + "\t");
	        		detailsBuf.append("Address1" + "\t");
	        		detailsBuf.append("Address2" + "\t");
	        		detailsBuf.append("Address3" + "\t");
	        		detailsBuf.append("Mobile Number" + "\t");
	        		detailsBuf.append("Email Id" + "\t");
	        		detailsBuf.append("Beneficiary Code");
	        		outBuffer.append(detailsBuf + "\n");
			if(inputParams.get("approveTPFileDetails") != null){
				corporateTP = (CorporateTP[]) inputParams.get("approveTPFileDetails");
				logger.info("corporateTP.length   :::"+corporateTP.length);
	    		if(corporateTP != null && corporateTP.length >= 1){
	        		for (int i = 0; i < corporateTP.length; i++) {
	        			CorporateTP beneficiaryDetails = corporateTP[i];
	        			if(beneficiaryDetails != null){
	        				String name =beneficiaryDetails.getName() == null ? "-" : beneficiaryDetails.getName();
	        				String AccountNo = beneficiaryDetails.getAccountNo()== null ? "-" : beneficiaryDetails.getAccountNo();
	        				String ifscCode = beneficiaryDetails.getOutRef2() == null ? "-" : beneficiaryDetails.getOutRef2();
	        				String address1 = beneficiaryDetails.getAddress1()== null ? "-" : beneficiaryDetails.getAddress1();
	        				String address2 = beneficiaryDetails.getAddress2()== null ? "-" : beneficiaryDetails.getAddress2();
	        				String address3 = beneficiaryDetails.getAddress3()== null ? "-" : beneficiaryDetails.getAddress3();
	        				outBuffer.append(name+ "\t");
	        				outBuffer.append("'"+ AccountNo+ "\t");
	        				outBuffer.append("'"+ifscCode+ "\t");
	        				outBuffer.append(address1+ "\t");
	        				outBuffer.append(address2 + "\t");
	        				outBuffer.append(address3 + "\t");
	        				if(beneficiaryDetails.getMobileNo() == null){
	        					outBuffer.append(" \t");
	        				}else{
	        					outBuffer.append("'" +beneficiaryDetails.getMobileNo()+ "\t");
	        				}
	        				if(beneficiaryDetails.getEmailId() == null){
	        					outBuffer.append(" \t");
	        				}else{
	        					outBuffer.append(beneficiaryDetails.getEmailId()+ "\t");
	        				}
	        				if(beneficiaryDetails.getEmployeeCode() == null){
	        					outBuffer.append(" \n");
	        				}else{
	        					outBuffer.append("'" +beneficiaryDetails.getEmployeeCode() + "\n");
	        				}
	        			}
					}
	        		
	        	} else {
	        		outBuffer.append("\t\t"+ "There are no Inter bank beneficiaries  for the selected file.");
	        	}
	        } else {
	    		outBuffer.append("\t\t"+ "There are no Inter bank beneficiaries for the selected file.");
	    	}
			outBuffer.append("\n");
			outBuffer.append("\n");
			outBuffer.append("\n");
			outBuffer.append("Note :"+"\t");
			outBuffer.append("Please contact your uploader for error file."+"\n");
	        logger.info("csvInterBankBeneficiaryConverter(Map inputParams end, inputParams - end");
	       
	        return outBuffer;
	    }
}