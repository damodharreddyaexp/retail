/*   
 * CorpTransactionDAO.java
 * Created on Oct 20, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 12, 2006 Aparna S - Initial Creation 

package com.sbi.common.etdr.dao;

import com.sbi.common.model.Transaction;


public interface CorpTransactionDAO {
	
 /**
  * TODO Method to execute java_corporate_transaction.processTransaction procedure for make echeque.
 * @param transaction object
 * @return string
 */

public String createTransaction( Transaction transaction );
    
 
/**
	 * TODO Method to xecute java_corporate_transaction.editTransaction procedure for edit echeque.
	 * @param transaction object
	 * @return string
	 */
public String editTransaction(Transaction transaction);    
 
}
