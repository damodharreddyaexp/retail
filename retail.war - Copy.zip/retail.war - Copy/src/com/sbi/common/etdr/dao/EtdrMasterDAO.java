/**
 * @(#) EchequeMasterDAO.java
 */

package com.sbi.common.etdr.dao;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.sbi.common.etdr.model.EtdrMaster;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;
 

public interface EtdrMasterDAO
{
	int getUnauditCount(String accountNo,String branchCode,Double unauditMaxAmount, String corporateID)throws DAOException;
	
	Timestamp getPayByDate(String echequeNo) throws DAOException;
	   
    List getEtdrPendingRequests(String userName);
    
    EtdrMaster getEtdrDetails(String referenceNo);
    
    int sendForSecondLevelAuthorize(Map inparams);
    
    int cancelEtdrRequest(EtdrMaster etdrMaster);
    
    List getPreCloseEtdrPendingRequests(String userName);
    
    EtdrMaster getPreCloseEtdrDetails(String preCloseReferenceNo);
    
    int sendForSecondLevelPreCloseAuthorize(Map inparams);
 
    void closeFixedDepositAccount(FixedDepositModel preModel);
    
    int findUserAuthType(String accountNo, String branchCode, Double amount, String userName);
    
    int cancelPreCloseEtdrRequest(EtdrMaster etdrMaster);
    
}