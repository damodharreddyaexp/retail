package com.sbi.common.etdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.etdr.dao.CorpUserDAO;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CorpTransactionLeg;

public class IBCreditDAOImpl extends JdbcDaoSupport implements IBCreditDAO  {
	
	protected final Logger logger = Logger.getLogger(getClass());
	//private static final String FindCreditDetails = "select * from sbi_ib_credits where debit_reference_no = ?";
    
   /* private static final String FindCreditDetails ="select decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY " + 
            " from sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and " + 
            " rownum < 2 ), CREDIT_NARRATIVE3) credit_narrative3,(select outref7 from sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code, a.* "+
            " from sbi_ib_credits a  where debit_reference_no = ? ";*/
	
	//changed by swarupa
	
	private static final String FindCreditDetails ="SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select b.NAME_THIRD_PARTY from bvsbi.sbicorp_third_party b where b.account_no=a.account_no and b.branch_code=a.branch_code "+
" and b.corporate_id = a.corporate_id and status = 1 and b.creation_time= (select max(creation_time) from bvsbi.sbicorp_third_party c where c.account_no=b.account_no  and b.branch_code=c.branch_code and b.corporate_id = c.corporate_id and c.status = 1  ) "+
" and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7, (select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no "+
" and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,a.*  from bvsbi.sbi_ib_credits a  where debit_reference_no = ? )";


	
	private CorpUserDAO corpUserDAOImpl;

	//for RTGS  
	private static final String FIND_RTGS_BEN_ADDRESS ="select address1, address2,address3,third_party_name,user_name from sbi_rtgs_beneficiary  where status='active' and " +
			" IFSC_CODE_RECEIVER = ? and ACCOUNT_NUMBER = ?  and corporate_id=? and third_party_name=? ";

	private static final String FIND_SENDER_IFSC_CODE ="select * from sbi_branch_master where branch_code=?";
	// RTGS end
	
	//Added for Credit Account Validation
	
	private static final String VALIDATION_NEFT_AND_RTGS ="SELECT sum(count) FROM (SELECT count(*) count FROM sbi_rtgs_beneficiary WHERE account_number = ? AND user_name = ? AND corporate_id = ?   AND status = 'active' " +
   " AND file_sno IS NULL AND(payment_mode = 'BOTH' OR payment_mode = ?) UNION all SELECT count(*) count FROM sbi_rtgs_beneficiary WHERE corporate_id = ? AND account_number = ? AND user_role = '10'  AND status = 'active' " +
   " AND file_sno IS NULL AND(payment_mode = 'BOTH' OR payment_mode = ?) UNION all SELECT count(*) count FROM sbi_rtgs_beneficiary a, sbicorp_ca_user_map b WHERE b.user_name = ? AND a.user_name = b.ca_user  AND a.corporate_id = ? "+
   " AND a.status = 'active' AND a.account_number = ? AND file_sno IS NULL AND(payment_mode = 'BOTH' OR payment_mode = ?) UNION all select count(*)  count from SBI_SUPPLIER_ACCOUNT_MAP A, SBI_SUPPLIER_MASTER B, SBI_BRANCH_MASTER C " +  
   " where A.OID=B.OID and  A.branch_code=C.branch_code  and b.status=1  and C.status=1 and a.account_no=?)";

	private static final String VALIDATE_THIRD_PARTY="SELECT sum(count)FROM ((SELECT count(*) count FROM sbi_customer_account_map a,sbi_branch_master b WHERE a.account_no NOT LIKE 'none%' AND a.branch_code = b.branch_code " +
   " and a.account_no=? AND account_nature = 1  AND user_name = ? AND a.status = 1 AND b.status = 1 AND(b.live = 0 OR b.live IS NULL)) UNION all (SELECT count(*) count    FROM sbicorp_third_party a, "+
       " sbi_branch_master b  WHERE a.branch_code = b.branch_code AND a.account_no NOT LIKE 'none%'  and a.account_no=? AND a.user_name IN (SELECT user_alias FROM bv_user WHERE user_id IN (SELECT a.user_id  " +
         " FROM bv_user_profile a, bv_user_role b WHERE a.corporate_id = ? AND b.user_role = 10 AND a.user_id = b.user_id) UNION ALL SELECT DISTINCT ca_user FROM sbicorp_ca_account_map WHERE account_no IN (SELECT account_no "+
         " FROM sbi_customer_account_map WHERE user_name = ? AND status = 1 AND account_nature = 0  AND access_level != 0)) AND a.status = 1))";
	
	private static final String VALIDATE_GRPT="SELECT sum(count) FROM (SELECT count(*) count FROM sbi_rtgs_beneficiary WHERE user_name = ? AND corporate_id = ? AND status = 'active' AND file_sno IS NULL  and account_number=?  AND UPPER(grpt) = 'Y' " +
   " UNION ALL  SELECT count(*) count FROM sbi_rtgs_beneficiary WHERE corporate_id = ? AND user_role = '10' AND status = 'active' AND file_sno IS NULL AND UPPER(grpt) = 'Y'  and account_number=?  UNION ALL  SELECT count(*) count FROM sbi_rtgs_beneficiary a, sbicorp_ca_user_map b "+
   " WHERE b.user_name = ? AND a.user_name = b.ca_user AND a.corporate_id = ? AND a.status = 'active' AND file_sno IS NULL  and account_number=? AND UPPER(a.grpt) = 'Y' UNION ALL select count(*)  count from SBI_SUPPLIER_ACCOUNT_MAP A, SBI_SUPPLIER_MASTER B, SBI_BRANCH_MASTER C "+  
   " where A.OID=B.OID and  A.branch_code=C.branch_code  and b.status=1  and C.status=1 and a.account_no=?)"; 

	private static final String VALIDATE_FUNDS_TRANSFER ="Select count(*) from SBICORP_CA_ACCOUNT_MAP A, SBICORP_CA_CORPORATE_MAP B,SBI_BRANCH_MASTER C where  C.BRANCH_CODE=A.BRANCH_CODE AND A.status=1 and B.status=1 and A.Ca_user=B.ca_user  and B.corporate_id=?  and account_no=?";
	
	private static final String VALIDATE_SUPPLIER_SBI ="select count(*) from SBI_SUPPLIER_ACCOUNT_MAP A, SBI_SUPPLIER_MASTER B, SBI_BRANCH_MASTER C  where A.OID=B.OID and  A.branch_code=C.branch_code  and b.status=1  and C.status=1 and a.account_no=?";
	

	
	public List findCredits(String debitReferenceNumber) {
		
		logger.info("findCredits(String debitReferenceNumber) method begin");
		if (logger.isDebugEnabled()) {
            logger.debug("DebitReferenceNumber  : " + debitReferenceNumber);     
        }
		List allechequeslst = null;
		if(debitReferenceNumber!=null){
			try
			{ 
				Object[] params = {debitReferenceNumber};
				logger.info("params are " + params);
			
				allechequeslst = getJdbcTemplate().query(FindCreditDetails,params, new CorpTransactionLegRowMapper());
				logger.info("Credit list count : "+allechequeslst);
				logger.info("findCredits(String debitReferenceNumber) method End");
				return allechequeslst;
			
			}
			catch(DataAccessException dataAccessException)
			{
				DAOException.throwException("CU0001",new Object [] {debitReferenceNumber});
			}
		
		}
		else{
			 DAOException.throwException("CU0002",new Object [] {debitReferenceNumber});
		}
	
		 return allechequeslst;
	}
	
	public List findRTGSBenAddress (String ifscCode, String accountNo,String corpId, String thirdPartyName) {
		
		logger.info("findRTGSBenAddress - method begin. IfscCode : "+ifscCode+
				" Account No : "+accountNo+" Corporate Id :" +corpId+" Third party name: "+thirdPartyName);
		
		List addressList = null;
		
		if(ifscCode != null && accountNo != null) {
			try{
				Object[] params = {ifscCode, accountNo, corpId, thirdPartyName};
				addressList = getJdbcTemplate().queryForList(FIND_RTGS_BEN_ADDRESS, params);
			} catch (DataAccessException dataAccessException) {
				
				DAOException.throwException("CU0002",new Object[] {ifscCode, accountNo, corpId, thirdPartyName});
			}
			
		}else {
			
			DAOException.throwException("CU0002",new Object [] {ifscCode, accountNo, corpId, thirdPartyName});
		}
		
 		logger.info("findRTGSBenAddress - method end");
		return addressList;
	}
	
	public List findSenderBankIfscCode(String branchCode) {
		
		logger.info("findSenderBankIfscCode(String branchCode) - method beging : branchCode ::"+ branchCode);
		List senderIfscCodeList=null;
		
		if(branchCode != null) {
			try{
				Object[] params = {branchCode};
				senderIfscCodeList = getJdbcTemplate().queryForList(FIND_SENDER_IFSC_CODE, params);
			} catch (DataAccessException dataAccessException) {
				
				DAOException.throwException("CU0002",new Object[] {branchCode});
			}
			
		}else {
			
			DAOException.throwException("CU0002",new Object [] {branchCode});
		}		
		
		
		logger.info("findSenderBankIfscCode(String branchCode) - method end");
		return senderIfscCodeList;
	}
	
	
	//Added by Sunjay S Galen for Credit Acount Validation
	
	public	int  validateCreditDetails( String userName, String functionType ,String accountNo,String corporateId,String creditBranch )
	{
		logger.info("validateCreditDetails( String userName, String functionType ,String accountNo,String corporateId) Method Begin");
		logger.info("userName : " + userName + "," + " functionType: "  + functionType + "," +"Account no: "+accountNo + "," + "corporateId::" +corporateId);
		String sql=null;
		String transactionType = null;
		int validateCount  = 0;
		//corporateId = null;
		Object[] parameters;
		String bankCode = creditBranch.substring(0,1).toString();
		logger.info("bank code for supplier::"+ bankCode);
		try{
		if(userName != null && functionType != null )
		{
		if (functionType.equalsIgnoreCase("CN"))
		{
			 transactionType="NEFT";
			 parameters = new Object[]{ accountNo,userName,corporateId,transactionType,corporateId,accountNo,transactionType,userName,corporateId,accountNo,transactionType,accountNo};
			 int sqlTypes[] =
	            { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
			 sql= VALIDATION_NEFT_AND_RTGS;
			 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
		}
			else if (functionType.equals("CR"))
			{
				 transactionType="RTGS";
				parameters = new Object[]{ accountNo,userName,corporateId,transactionType,corporateId,accountNo,transactionType,userName,corporateId,accountNo,transactionType,accountNo};
				int  sqlTypes[] =
		            { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
				 sql= VALIDATION_NEFT_AND_RTGS;
				 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
			}
			else if (functionType.equals("CZ"))
			{
				 transactionType="GRPT";
				 parameters = new Object[]{ userName,corporateId,accountNo,corporateId,accountNo,userName,corporateId,accountNo,accountNo};
					int  sqlTypes[] =
		            { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
				 sql =VALIDATE_GRPT;
				 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
			}
			else if (functionType.equals("CT"))
			{
				parameters = new Object[]{ accountNo,userName,accountNo,corporateId,userName};
				int  sqlTypes[] =
	            { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,};
				 sql=VALIDATE_THIRD_PARTY;	
				 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
			}
		
			else if (functionType.equals("CI"))
			{
				 transactionType="fundsTransfer";
					parameters = new Object[]{corporateId,accountNo};
					int  sqlTypes[] =
		            { Types.VARCHAR,Types.VARCHAR,};
					 sql=VALIDATE_FUNDS_TRANSFER;	
					 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
			}
			else if (functionType.equals("CS"))
			{
					logger.info("Inside CS");
					parameters = new Object[]{accountNo};
					int  sqlTypes[] =
		            { Types.VARCHAR,};
					 sql=VALIDATE_SUPPLIER_SBI;	
					 validateCount = getJdbcTemplate().queryForInt(sql, parameters, sqlTypes);
				
			}
		
			
//			
			else{//function type is invalid
				DAOException.throwException("CU0005",new Object [] {functionType});
			
			}
			
		
		   
			
			logger.info("Credit Validation count: "+validateCount);
			if (validateCount < 1)
			{
				DAOException.throwException("V114",new Object [] {userName,functionType,accountNo,corporateId});	//Changed For Fixing Defect 5287 
			}
		
		
		
		}else
		{//Input values are null
		 DAOException.throwException("CU0005",new Object [] {userName,functionType,accountNo,corporateId});
		}
		} catch (DataAccessException ex) {
            
            ex.printStackTrace();
            DAOException.throwException("CU0005",new Object [] {userName});
	
		}
		logger.info(" validateCreditDetails (String userName, String functionType ,String accountNo,String corporateId) method ends");
	return validateCount;	
	}
	
	class CorpTransactionLegRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	
        	CorpTransactionLeg  corpTransactionLeg = new CorpTransactionLeg();
        	corpTransactionLeg.setDebitReferenceNo(rs.getString("debit_reference_no"));        	
        	corpTransactionLeg.setCreditReferenceNo(rs.getString("credit_reference_no"));
        	corpTransactionLeg.setAccountNo(rs.getString("account_no"));
        	corpTransactionLeg.setBranchCode(rs.getString("branch_code"));
        	corpTransactionLeg.setAmount(new Double(rs.getDouble("amount")));
        	corpTransactionLeg.setOriginalDebitBranch(rs.getString("original_debit_branch"));
        	corpTransactionLeg.setCreditStatus(rs.getString("credit_status"));
        	corpTransactionLeg.setStatusDescription(rs.getString("status_description"));
        	corpTransactionLeg.setCreditDescription(rs.getString("credit_description"));
        	corpTransactionLeg.setCreditNarrative1(rs.getString("credit_narrative1"));
        	corpTransactionLeg.setCreditNarrative2(rs.getString("credit_narrative2"));
        	corpTransactionLeg.setCreditNarrative3(rs.getString("credit_narrative3"));
        	// Beneficiary name display for CT in Bulk Echeques Inbox 
        	try {
        		if(rs.getString("credit_narrative3") == null || rs.getString("credit_narrative3").equals("")){
        			corpTransactionLeg.setCreditNarrative3(rs.getString("credit_narrative7"));
        		}
			} catch (Exception e) {			}
        	
			corpTransactionLeg.setCorpRefNo(rs.getString("corp_ref_no"));
        	corpTransactionLeg.setRecoRequired(rs.getString("reco_required"));
        	corpTransactionLeg.setCreationTime(rs.getString("creation_time"));
        	
        	corpTransactionLeg.setFileName(rs.getString("file_name"));
        	corpTransactionLeg.setCreditsCreated(rs.getString("credits_created"));
        	corpTransactionLeg.setErrorCode(rs.getString("error_code"));
        	corpTransactionLeg.setName(rs.getString("name"));
        	corpTransactionLeg.setUserName(rs.getString("user_name"));
        	//corpTransactionLeg.setBranchName(corpUserDAOImpl.getBranchNameForTxn(corpTransactionLeg.getBranchCode()));
        	corpTransactionLeg.setProductType("product_type");
        	corpTransactionLeg.setLastModTime(rs.getTimestamp("last_mod_time"));
        	corpTransactionLeg.setType(rs.getString("CREDIT_TYPE"));
        	corpTransactionLeg.setNarrative1(rs.getString("credit_narrative1"));
        	corpTransactionLeg.setNarrative2(rs.getString("credit_narrative2"));
        	corpTransactionLeg.setBeneficiaryCode(rs.getString("beneficiary_code")); //<!-- CR5603 Phase3 Bulk Inbox Pagination-->

        	
        	//Added forCR 2921
        	
            logger.info("substring of credit reference NO :"+corpTransactionLeg.getCreditReferenceNo().substring(0,2));
            
            String merchCode="|CR|CN|CZ";
            if (merchCode.indexOf(corpTransactionLeg.getCreditReferenceNo().substring(0,2))>0)
            {
                                corpTransactionLeg.setUtrNo(rs.getString("utr_no"));
                                
                                logger.info("utr no :::"+corpTransactionLeg.getUtrNo());
               
            }
        	
        	//Added by Deepika to get the commmission amount
        	//corpTransactionLeg.setRateOfInterest(rs.getString("commission_amount"));
        	
        	return corpTransactionLeg; 
        }
    }
	
//  <!-- CR5603 Phase3 Bulk Inbox Pagination - Begin -->
	public Map findCredits(String debitReferenceNumber, String pageNo, String limit) {
		
		logger.info("findCredits(String debitReferenceNumber, String pageNo, String limit) method begin");
		if (logger.isDebugEnabled()) {
            logger.debug("DebitReferenceNumber  : " + debitReferenceNumber);     
        }
		Map result=new HashMap();//shanta
//		String pagenationQuery = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,a.* from sbi_ib_credits a  where debit_reference_no = ?) WHERE RNO BETWEEN ? AND ?";//shanta
	//	String pagenationQuery = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from bvsbi.sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,(select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,a.* from bvsbi.sbi_ib_credits a  where debit_reference_no = ? ) WHERE RNO BETWEEN ? AND ?";//shanta
		String pagenationQuery = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select b.NAME_THIRD_PARTY from bvsbi.sbicorp_third_party b where b.account_no=a.account_no and b.branch_code=a.branch_code and b.corporate_id = a.corporate_id and status = 1 and b.creation_time= (select max(creation_time) from bvsbi.sbicorp_third_party c where c.account_no=b.account_no  and b.branch_code=c.branch_code and b.corporate_id = c.corporate_id and c.status = 1  ) and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,(select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,a.* from bvsbi.sbi_ib_credits a  where debit_reference_no = ? ) WHERE RNO BETWEEN ? AND ? "; //swarupa
		
		//String sqlCount = "SELECT COUNT(*) FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,a.* from sbi_ib_credits a  where debit_reference_no = ?)";//shanta
		String sqlCount = "SELECT COUNT(*) FROM SBI_IB_CREDITS WHERE DEBIT_REFERENCE_NO = ?";//shanta
		if(debitReferenceNumber!=null){
			try
			{ 
				Object[] params = {debitReferenceNumber, ((Integer.parseInt(pageNo)*Integer.parseInt(limit))-Integer.parseInt(limit))+1,Integer.parseInt(pageNo)*Integer.parseInt(limit)};
				logger.info("params are " + params);
				Object[] parametersCount = {debitReferenceNumber};
				logger.info("Parametes for count : " + parametersCount);
				int[]sqlTypesCount = {Types.VARCHAR};
				int count=getJdbcTemplate().queryForInt(sqlCount,parametersCount,sqlTypesCount);
				//allechequeslst = getJdbcTemplate().query(FindCreditDetails,params, new CorpTransactionLegRowMapper());
				List pendingEhequeList = getJdbcTemplate().query(pagenationQuery,params, new CorpTransactionLegRowMapper());
				//logger.info("Credit list count : "+allechequeslst);
				
				logger.info("The Pagination query size : "+ pendingEhequeList.size());
				result.put("pendingEcheques", pendingEhequeList);
				result.put("totalCount", count);
				
				logger.info("findCredits(String debitReferenceNumber, String pageNo, String limit) method End");
				return result;
			
			}
			catch(DataAccessException dataAccessException)
			{
				DAOException.throwException("CU0001",new Object [] {debitReferenceNumber});
			}
		
		}
		else{
			 DAOException.throwException("CU0002",new Object [] {debitReferenceNumber});
		}
	
		 return result;
	}

	public void setCorpUserDAOImpl(CorpUserDAO corpUserDAOImpl) {
		this.corpUserDAOImpl = corpUserDAOImpl;
	}
		
	
}
