package com.sbi.common.etdr.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;

public interface FixedDepositPreClosureDAO {

	
	public String getPreclosureReferenceNo() throws DAOException;
	public List getFdAccounts(String userName,String bankCode, String debitAccountNo,String corporateId);
	public List getFddetails(String userName,String bankCode,String fdAccountNo,String corporateId);
	public List getPreClosureDetails(String fdAccountNo);
	public Map  updatePreclosureDetails(FixedDepositModel preclosureModel);
	
}