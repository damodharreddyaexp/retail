package com.sbi.common.etdr.dao;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;

public class CorpUserDAOImpl extends JdbcDaoSupport implements CorpUserDAO{
	 //put in corporateUserDAO
    protected final Logger logger = Logger.getLogger(getClass());
    public String getAuthorizerName(String authName) throws DAOException {
		//logger.info("getAuthorizerName(String authName) - begin");
		String query="select name from bv_user a, bv_user_profile b where a.user_id = b.user_id and a.user_state = 0 and a.user_alias = ?";
		String authorizerName="";
		if(authName!=null && authName.length()>0){
			try{
			Object[] params={authName};
			List authList=getJdbcTemplate().queryForList(query,params);
			if(authList!=null && authList.size()>0){
				Map authMap=(Map)authList.get(0);
				if(authMap!=null && authMap.size()>0 && authMap.get("NAME")!=null)
					authorizerName=authMap.get("NAME").toString();
			}
			}catch(DataAccessException dataAccessException){
				logger.info("Authorizer name not found");
			}
		}
		logger.info("getAuthorizerName(String authName) - end");
		return authorizerName;
	}
	
	  public String getBranchNameForTxn(String brcode)
	  {
		  String branchName = null;
		  
		  Object[] branchparams = new Object[] { brcode };	
			logger.info(" branchCode " + brcode);
			List brDetails = getJdbcTemplate().queryForList("select branch_name from sbi_branch_master where branch_code = ? and status=1", branchparams);
			if(brDetails!=null && brDetails.size()>0){
				Map branchDetails=(Map)brDetails.get(0);
				branchName=(String)branchDetails.get("BRANCH_NAME");
				logger.info(" branchName " + branchName);		
				
			}	
			else{
				brDetails = getJdbcTemplate().queryForList("select branch_name from sbi_all_branches where branch_code = ? and status=1", branchparams);
				if(brDetails!=null && brDetails.size()>0){
					Map branchDetails=(Map)brDetails.get(0);
					branchName=(String)branchDetails.get("BRANCH_NAME");
					logger.info(" branchName ALL Branches" + branchName);		
									
				}	

			}
			
			return branchName;
	  }
	  //Added By marimuthu for DD commision
	  public void updateDraftCommision(String referenceNo, Double commAmount, String commRefNo) throws DAOException {
		  String query = "update sbicorp_echeque_master set rate_of_interest =? , third_party_ref=? where echeque_no=?";
		  try {
			  Object params[]= {commAmount,commRefNo,referenceNo};
			  getJdbcTemplate().update(query,params);
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
			}
			
	  }
	  
	  public String getDDSequence() throws DAOException {
		    logger.info("getDDSequence method starts");
		    String GET_DD_SEQUENCEID = "select 'DEX' || LPAD(SEQ_DD_COMMISSION.nextval,7,0) refno from dual";
			String sequenceID = null;
			try {
				sequenceID = (String) getJdbcTemplate().queryForObject(GET_DD_SEQUENCEID, String.class);
				logger.info("sequenceID Created : " + sequenceID);
			} catch (DataAccessException dataAccessException) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
			}
			logger.info("getDDSequence method ends");
			return sequenceID;
		} 
	 //end 
	//Updated by Sulthan for IR 71772
	  public String registerMT940Accounts(String accountNo,String userName,String fromBicid,String toBicid, String action) throws DAOException
	    {
	        logger.info("registerMT940Accounts(String accountNo,String userName,String fromBicid,String toBicid) method begin");
	        String status=null;
	        String selectCount="select count(*) from SBI_MT940_ACCOUNT_STATEMENT where account_number=? and user_name=?";
	        String selectQuery="select registration_status from SBI_MT940_ACCOUNT_STATEMENT where account_number=? and user_name=?";
	        
	        if (accountNo != null && userName!=null)
	        {
	            try
	            {
	            	Object params[]= {accountNo,userName};
	            	int count1=getJdbcTemplate().queryForInt(selectCount, params);
	              if(action=="C"){	            	
	            	if (count1>0){
	            	  status = (String) getJdbcTemplate().queryForObject(selectQuery, params,String.class);
	            	  logger.info("=============="+status);
	            	}
	              if(status==null){	
	            	logger.info("CCC==========="+status); 
	            	String selectcorpId="select corporate_id from  bv_user_profile where user_id in(select user_id from bv_user where user_alias=?)";
	            	Object params1[]= {userName};
	            	String corpId = (String) getJdbcTemplate().queryForObject(selectcorpId, params1,String.class);
	       	        String insertQusery="insert into SBI_MT940_ACCOUNT_STATEMENT (corporate_id,creation_time,status,user_name,account_number,registration_status,frombic_id,tobic_id)values(?,sysdate,'1',?,?,'Processed',?,?)";
	       	        Object param[]= {corpId,userName,accountNo,fromBicid,toBicid};  
	       	        int count=getJdbcTemplate().update(insertQusery, param);
	       	        if (count>0)
	       	        	status="success";
	               }
	              else{
	            	  String updateQusery="update SBI_MT940_ACCOUNT_STATEMENT set REGISTRATION_STATUS='Processed',CREATION_TIME=sysdate,frombic_id=?,tobic_id=? where account_number=? and USER_NAME=?";
	            	  Object paramet[]= {fromBicid,toBicid,accountNo,userName};
	            	  int count=getJdbcTemplate().update(updateQusery, paramet);
	              }
	            }
	            else if(action=="A"){
	            	logger.info("AAA==========="+status);
	            	if (count1>0){
	       	        String insertQusery="update SBI_MT940_ACCOUNT_STATEMENT set frombic_id=?,tobic_id=?,registration_status='Processed' where account_number=? and user_name=? and registration_status<>'Deleted'";
	       	        Object param[]= {fromBicid,toBicid,accountNo,userName};  
	       	        int count=getJdbcTemplate().update(insertQusery, param);
	            	}
	           	}
	            else{
	            	if (count1>0){
	            		logger.info("DDD==========="+status);	
	       	        String insertQusery="update SBI_MT940_ACCOUNT_STATEMENT set registration_status='Deleted' where account_number=? and user_name=?";
	       	        Object param[]= {accountNo,userName};  
	       	        int count=getJdbcTemplate().update(insertQusery, param);
	       	        
	            	}
	            }
	            }
	            catch (DataAccessException dataAccessException) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
			
	        }
	        //else
	        
	        }
	        return status;
	    }
//To get product code for EDIT ECHEQUE for DD Commission
	  //CR 5774
	public String getProductForAccount(String debitAccountNo) {
		String GET_PRDUCT_CODE="select PRODUCT_CODE from sbi_customer_account_map where account_no=? and rownum =1";
		String prodCode="";
		Object params[]= {debitAccountNo};
		try {
			prodCode = (String) getJdbcTemplate().queryForObject(GET_PRDUCT_CODE,params, String.class);
			logger.info("Product code: " + prodCode);
		} catch (DataAccessException dataAccessException) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
		}
		return prodCode;
	}
	  
}
