/**
 * @(#) IBCreditDAO.java
 */

package com.sbi.common.etdr.dao;

import java.util.List;
import java.util.Map;
public interface IBCreditDAO
{
	/**
	 * Quering credit details from ,
	 * select * from sbi_ib_credits where debit_reference_no = ?
	 * 
	 * and construct CorpTransactionLeg objects.
	 * 
	 * Return List of CorpTransactionLeg.
	 */
	List findCredits( String debitReferenceNumber );
	
	
	List findRTGSBenAddress (String ifscCode, String accountNo, String corpId, String thirdPartyName);

	List findSenderBankIfscCode(String branchCode);
	
	int validateCreditDetails( String userName, String functionType ,String AccountNo, String CorporateId, String creditBranch) ;

//  <!-- CR5603 Phase3 Bulk Inbox Pagination - Begin -->
	Map findCredits( String debitReferenceNumber, String pageNo, String limit );
}
