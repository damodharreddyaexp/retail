package com.sbi.common.etdr.dao;
import com.sbi.common.exception.DAOException;


public interface EtdrCorpUserDAO {
	
	String getAuthorizerName(String authName) throws DAOException;
	String getBranchNameForTxn(String brcode);	
	//Added by marimuthu
	void  updateDraftCommision(String referenceNo, Double commAmount, String commRefNo);
	String getDDSequence();
	//End
	public String registerMT940Accounts(String accountNo,String userName,String fromBicid,String toBicid, String status) throws DAOException;//IR71772
	String getProductForAccount(String debitAccountNo);//CR 5774-Sulthan
}
