package com.sbi.common.etdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.driver.OracleTypes;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.dao.BankSystemDAO;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

public class FixedDepositPreClosureDAOImpl extends JdbcDaoSupport implements FixedDepositPreClosureDAO {
	  private BankSystemDAO coreDAOImpl; //sr 87929
	
	private static final Logger LOGGER = Logger.getLogger(FixedDepositPreClosureDAOImpl.class);
	
	private static final String UPDATE_PRE_CLOSURE_STATUS = "UPDATE SBICORP_FD_ACCOUNT_MAP SET PRECLOSURE_STATUS=?,PRECLOSURE_SCHEDULED=?,CLOSED_DATE=TO_DATE(?,'dd/mm/yyyy'), PRECLOSURE_REMARKS=?, PRECLOSURE_REFERENCE_NO=?, PRECLOSURE_REQUEST_DATE=sysdate, LAST_MOD_TIME=SYSDATE WHERE FD_ACCOUNT_NO=? ";
	private static final String GET_PRECLOSURE_SEQ_NO = "SELECT 'CPC'||LPAD(corpfd_preclosure_seqno.NEXTVAL,7,0) FROM DUAL";
	
	private static final String UPDATE_PRECLOSURE_DETAILS= "UPDATE 	SBICORP_FD_ACCOUNT_MAP SET  PRECLOSURE_REFERENCE_NO=?,"+
	" PRECLOSURE_REMARKS=?,PRECLOSURE_CURRENT_AUTH_LEVEL=1,PRECLOSURE_AUTH_STATUS='Pending',PRECLOSURE_STATUS='Pending',PRECLOSURE_AUTH_TYPE=0,PRECLOSURE_AUTH_OPTION=1,LAST_MOD_TIME=SYSDATE,PRECLOSURE_REQUEST_DATE=SYSDATE,PRECLOSURE_REQ_RAISED_BY=? WHERE DEBIT_ACCOUNT_NO=? AND FD_ACCOUNT_NO=? AND DEBIT_BRANCH_CODE=? ";
	

	/* Query modified for ETDR change */
	/*private static final String GET_FD_ACCOUNT_NO = "SELECT a.user_name ,a.maturity_date,a.maturity_value,a.interest_rate,'INR' as currency, a.tenure_day,a.tenure_month,a.tenure_year,a.tenure,a.preclosure_status, a.fd_account_no,a.fd_amount, a.fd_branch_code,a.deposit_open_date, b.product_type,c.branch_name,a.preclosure_status FROM sbicorp_fd_account_map a, sbi_customer_account_map b, sbi_branch_master c WHERE a.status='active' and" +
	" a.fd_type in ('TDR','STDR') and a.user_name =? and decode(substr(a.debit_branch_code,0,1),'A','0','6','0','3','0',substr(a.debit_branch_code,0,1))=? and a.debit_account_no=? and a.fd_account_no = b.account_no and a.user_name=b.user_name AND b.status = '1' and b.branch_code=c.branch_code and b.access_level <> 0 and nvl(a.preclosure_status,'*') not in ('closed','scheduled') order by a.deposit_open_date desc";*/
	
	private static final String GET_FD_ACCOUNT_NO = "SELECT a.user_name ,a.maturity_date,a.maturity_value,a.interest_rate,'INR' as currency, a.tenure_day,a.tenure_month,a.tenure_year,a.tenure,a.preclosure_status, a.fd_account_no,a.fd_amount, a.fd_branch_code,a.deposit_open_date, b.product_type,c.branch_name,a.preclosure_status FROM sbicorp_fd_account_map a, sbi_customer_account_map b, sbi_branch_master c WHERE a.status='active' and" +
	" a.fd_type in ('TDR','STDR') and decode(substr(a.debit_branch_code,0,1),'A','0','6','0','3','0',substr(a.debit_branch_code,0,1))=? and a.debit_account_no=? and a.fd_account_no = b.account_no AND b.status = '1' and b.branch_code=c.branch_code and b.account_nature='0' and nvl(a.preclosure_status,'*') not in ('closed','scheduled') and a.corporate_id=? and a.corporate_id=b.corporate_id order by a.deposit_open_date desc";
	
	private static final String GET_FD_CREDITACCOUNT = "select  a.fd_account_no credit_account_no, a.debit_account_no debit_account_no, a.fd_amount amount, a.maturity_date, a.fd_branch_code,a.deposit_open_date,a.corporate_id from sbicorp_fd_account_map a, sbicorp_echeque_master b, sbi_customer_account_map c "
		+ "where a.status='active' and c.status='1' and a.fd_account_no=b.corp_ref_no and a.fd_account_no=c.account_no and b.corp_ref_no=c.account_no and a.user_name=c.user_name and a.fd_account_no=?";

	private static final String GET_FD_CREDITACCOUNT_FROM_SBIARCHIVE_CORP_ECHEQUE_MASTER = "select  a.fd_account_no credit_account_no, a.debit_account_no debit_account_no, a.fd_amount amount, a.maturity_date, a.fd_branch_code,a.corporate_id from sbicorp_fd_account_map a, sbi_archive.sbicorp_echeque_master b, sbi_customer_account_map c "
		+ "where a.status='active' and c.status='1' and a.fd_account_no=b.corp_ref_no and a.fd_account_no=c.account_no and b.corp_ref_no=c.account_no and a.user_name=c.user_name and a.fd_account_no=?";

		
	
	private static final String GET_FD_INTERIM_DETAILS="select a.maturity_date,a.maturity_value,a.interest_rate, a.tenure_day,a.tenure_month,a.tenure_year,a.tenure,a.creation_time,a.debit_branch_code,a.deposit_open_date from sbicorp_fd_account_map a,sbi_customer_account_map b, sbi_branch_master c where a.status='active'" +
	" and a.fd_type in ('TDR','STDR')and decode(substr(a.debit_branch_code,0,1),'A','0','6','0','3','0',substr(a.debit_branch_code,0,1))=? and a.fd_account_no = b.account_no and a.fd_account_no=? and a.user_name=b.user_name AND b.status = '1' and b.branch_code=c.branch_code and b.access_level <> 0 and nvl(a.preclosure_status,'*') not in ('closed','scheduled') and a.corporate_id=? order by a.preclosure_status desc";
	
	private static final String GET_PRECLOSURE_PENDING="select count(*) from sbicorp_fd_account_map where  fd_account_no=? and debit_branch_code=? and PRECLOSURE_AUTH_STATUS='Pending'"; 
	
	public List getFdAccounts(String userName, String bankCode,String debitAccountNo,String corporateId) {
		LOGGER.info("getFDAccounts - Starts ");
		List fdAccountNoList = null;
		if (userName != null && bankCode != null) {
			try {
				LOGGER.info("bank code is :"+ bankCode);
				LOGGER.info("debit account no is :"+debitAccountNo);
				LOGGER.info("bank code is :"+ corporateId);
				final int sqlTypes[] = { OracleTypes.VARCHAR,OracleTypes.VARCHAR,OracleTypes.VARCHAR};
				final Object[] params = new Object[] { bankCode, debitAccountNo,corporateId};
				fdAccountNoList = (List) getJdbcTemplate().query(GET_FD_ACCOUNT_NO, params, sqlTypes,new PreClosureAccountsRowMapper());
				
				
				if(fdAccountNoList!=null && fdAccountNoList.size()>0) {
				for(int i=0; i < fdAccountNoList.size(); i++ ) {
					Account acc= (Account) fdAccountNoList.get(i);
					String  txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;

				        Map requestParam = new HashMap();
				        requestParam.put(DAOConstants.TXNNO, txnno);
				        requestParam.put(DAOConstants.ACCNO, (String)acc.getAccountNo());
				        requestParam.put("bankCode",String.valueOf(acc.getBranchCode().charAt(0)));
				        List responseList = coreDAOImpl.getDataFromBankSystem(requestParam);
				   HashMap coreData = (HashMap) responseList.get(DAOConstants.ZERO_INT);
				   LOGGER.info("Product type is:"+acc.getProductType());
				   LOGGER.info("balance is:"+coreData.get(DAOConstants.TERM_VALUE));
				   if (LOGGER.isDebugEnabled()) {
					   LOGGER.debug("coreDataHash :" + coreData);
				   }
				   String status = null;
                   String errorCode = null;
                   if (coreData.get("status") != null) {
                	  status = (String) coreData.get("status");
                   }  
                   if (coreData.get("error_code") != null) {
                	   errorCode = (String) coreData.get("error_code");
                       status = errorCode;
                   }
                   if (status == null && errorCode == null) {
                	
                	 if ("A5".equalsIgnoreCase(acc.getProductType().trim())){
                		 acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.TERM_VALUE)));
                      	 acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.INTEREST_RATE)));                                
                      	 acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE));
                      	 acc.setProfileUserName((String) coreData.get(DAOConstants.PROFILE_USER_NAME));
                         acc.setMaturityAmount(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.MATURITY_AMT)));
                       	 acc.setMaturityDate(StringUtils.coreDateToTimestamp((String) coreData.get(DAOConstants.MATURITY_DATE)));
                       	 acc.setPrincipal(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.TERM_VALUE)));
                       	 acc.setAccumulatedInterest(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.ACCUMULATED_INTEREST)));
                       	 acc.setOpeningDate(StringUtils.coreDateToTimestamp((String) coreData.get(DAOConstants.OPENING_DATE)));
                       	 acc.setTenorDays(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_DAYS)));
                       	 acc.setTenorMonth(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_MONTH)));
                       	 acc.setTenorYear(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_YEAR)));
                       	//Added to display the TenureDays                         	
                       	 acc.setTenorINDays(emptyStringCheckForInteger((String) coreData.get("tenureInDays"))); 
                    	
				}
                  
                   }
				}
				}
				//by uday end sr 87929
				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("UserName --->" + userName);
					LOGGER.info("BankCode --->" + bankCode);
					LOGGER.info("FD AccountList -->" + fdAccountNoList);
				}
			} catch (DataAccessException e) {
				LOGGER.error("ERROR: Unable to get the FD Account DetailsList for this Username/BankCode :: "+ e.getMessage(), e);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		LOGGER.info("getFDAccounts(...) Ends here");
		return fdAccountNoList;
	}

			
		//sr 87929 start
			
			
		    private Integer emptyStringCheckForInteger(String responseString)
		    {
		    	if (LOGGER.isDebugEnabled())
		    		LOGGER.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODBEGIN);
		        Integer intValue = new Integer(DAOConstants.ZERO);
		        if(responseString != null && responseString.trim().length()>0){	        
			        if (responseString != null)
			        {
			            try
			            {
			                intValue = new Integer(responseString);
			            }
			            catch (NumberFormatException nfx)
			            {
			            	LOGGER.fatal(LoggingConstants.EXCEPTION, nfx);
			                //DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			            }
			        }
		        }
		        if (LOGGER.isDebugEnabled())
		        {
		        	LOGGER.debug("intValue :" + intValue);
		        	LOGGER.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODEND);
		        }
		        
		        return intValue;
		    }	
			
		//sr 87929 end	
	public List getPreClosureDetails(String fdAccountNo) {
		LOGGER.info("getPreClosureDetails(..) Starts Here ");
		List preclosureDetailsList = new ArrayList();
		if (fdAccountNo != null) {
			try {
				final int sqlTypes[] = { OracleTypes.VARCHAR };
				final Object[] params = new Object[] { fdAccountNo };
				preclosureDetailsList = (List) getJdbcTemplate().query(GET_FD_CREDITACCOUNT, params, new PreClosureAccountDetailesRowMapper());

				LOGGER.info("preclosureList.size() from bvsbi.sbicorp_echeque_master:"+preclosureDetailsList.size());
				LOGGER.info("preclosureDetailsList.isEmpty()::"+preclosureDetailsList.isEmpty());
				
				if(preclosureDetailsList.isEmpty() || preclosureDetailsList.size()==0){
					LOGGER.info("preclosureList.size() from sbi_archive.sbicorp_echeque_master: inside--->"+preclosureDetailsList.size());
					LOGGER.info("preclosureDetailsList.isEmpty() -->"+preclosureDetailsList.isEmpty());
					preclosureDetailsList = (List) getJdbcTemplate().query(GET_FD_CREDITACCOUNT_FROM_SBIARCHIVE_CORP_ECHEQUE_MASTER, params, new PreClosureAccountDetailesRowMapper());
				}

				if (LOGGER.isInfoEnabled()) {
					LOGGER.info("FD Account No --->" + fdAccountNo);
					LOGGER.info("preClosureDetailsList -->"+ preclosureDetailsList);
				}
			} catch (DataAccessException e) {
				LOGGER.error("ERROR: Unable to get the preClosure Details For FD Account No:: "+ e.getMessage(), e);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		LOGGER.info("getPreClosureDetails(..) Ends Here ");
		return preclosureDetailsList;
	}

	private class PreClosureAccountsRowMapper implements RowMapper {
		public Account mapRow(ResultSet rs, int index) throws SQLException {
			Account accountModel = new Account();
			accountModel.setUserName(rs.getString("user_name"));
			accountModel.setAccountNo(rs.getString("fd_account_no"));
			accountModel.setBranchCode(rs.getString("fd_branch_code"));
			accountModel.setProductType(rs.getString("product_type"));
			accountModel.setBranchName(rs.getString("branch_name"));
			accountModel.setAccountNickName(rs.getString("fd_account_no"));
			accountModel.setInterestRate(rs.getDouble("interest_rate"));
			accountModel.setMaturityAmount(rs.getDouble("maturity_value"));
			accountModel.setMaturityDate(rs.getTimestamp("maturity_date"));
			accountModel.setCurrency(rs.getString("currency"));
			accountModel.setTenorDays(rs.getInt("tenure"));
			accountModel.setTenorINDays(rs.getInt("tenure_day"));
			accountModel.setTenorMonth(rs.getInt("tenure_month"));
			accountModel.setTenorYear(rs.getInt("tenure_year"));
			accountModel.setOpeningDate(rs.getTimestamp("deposit_open_date"));
			accountModel.setTenorYear(rs.getInt("tenure_year"));
			accountModel.setPreCloseStatus(rs.getString("preclosure_status"));
			return accountModel;
		}
	}

	private class PreClosureFDInterimRowMapper implements RowMapper {
		public FixedDepositModel mapRow(ResultSet rs, int index)throws SQLException {
			FixedDepositModel fdPreclosureModel = new FixedDepositModel();
			fdPreclosureModel.setMaturityAmount(rs.getString("maturity_value"));
			fdPreclosureModel.setDebitBranchCode(rs.getString("debit_branch_code"));
			fdPreclosureModel.setValueDate(rs.getDate("creation_time"));
			fdPreclosureModel.setInterestRate(rs.getDouble("interest_rate"));
			fdPreclosureModel.setYears(rs.getInt("tenure_year"));
			fdPreclosureModel.setMonths(rs.getInt("tenure_month"));
			fdPreclosureModel.setDays(rs.getInt("tenure_day"));
			fdPreclosureModel.setTenureInDays(rs.getInt("tenure"));
			fdPreclosureModel.setValueDate(rs.getDate("maturity_date"));
			fdPreclosureModel.setFdCreationDate(rs.getDate("deposit_open_date"));
			return fdPreclosureModel;
		}
	}
	
	
	private class PreClosureAccountDetailesRowMapper implements RowMapper {
		public FixedDepositModel mapRow(ResultSet rs, int index)throws SQLException {
			FixedDepositModel fdPreclosureModel = new FixedDepositModel();
			fdPreclosureModel.setDebitAccountNo(rs.getString("debit_account_no"));
			fdPreclosureModel.setCreditAccountNo(rs.getString("credit_account_no"));
			fdPreclosureModel.setPrincipalAmount(rs.getDouble("amount"));
			fdPreclosureModel.setDebitBranchCode(rs.getString("fd_branch_code"));
			fdPreclosureModel.setValueDate(rs.getDate("maturity_date"));
			fdPreclosureModel.setCorporateId(rs.getString("corporate_id"));
			
			return fdPreclosureModel;
		}
	}

	/* Code From Jyothi Puram Ends here */

	/* Code of Srinivas Starts Here */

	

	

	public String getPreclosureReferenceNo() {
		LOGGER.info("getPreclosureReferenceNo() Starts Here..");
		String preClosureReferenceNo = "";
		try {
			preClosureReferenceNo = (String) getJdbcTemplate().queryForObject(GET_PRECLOSURE_SEQ_NO, String.class);
			LOGGER.info("preClosure_referenceNo -->" + preClosureReferenceNo);

		} catch (DAOException exp) {
			LOGGER.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);

		} catch (DataAccessException ex) {
			LOGGER.error("Unable to get the sequence for Reference Number:::"+ ex.getMessage(), ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		LOGGER.info("getPreclosureReferenceNo() Ends Here..");
		return preClosureReferenceNo;
	}

	

	
	public List getFddetails(String userName, String bankCode,String fdAccountNo,String corporateId) 
	{
		LOGGER.info("getFDAccounts(...) Starts here");
		List fdDetailsList = null;
		if (userName != null && bankCode != null) {
			try {
				final int sqlTypes[] = { OracleTypes.VARCHAR,OracleTypes.VARCHAR,OracleTypes.VARCHAR};
				final Object[] params = new Object[] {bankCode,fdAccountNo,corporateId};
				fdDetailsList = (List) getJdbcTemplate().query(GET_FD_INTERIM_DETAILS, params, sqlTypes,new PreClosureFDInterimRowMapper());
				LOGGER.info("Account list" +fdDetailsList);
				                
				
				}
				
				
				
			 catch (DataAccessException e) {
				LOGGER.error("ERROR: Unable to get the FD Account DetailsList for this Username/BankCode :: "+ e.getMessage(), e);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		LOGGER.info("getFDAccounts(...) Ends here");
		return fdDetailsList;
		
		
	}
	
	public Map updatePreclosureDetails(FixedDepositModel preclosureModel)
	{
		
		LOGGER.info("updateFDAccountMap(..) Starts Here");
		LOGGER.info("preclosure remarks is:"+ preclosureModel.getPreClosureRemarks());
		int rowsEffected = 0;
		int pendingCount =0;
		if (preclosureModel != null) {
			
			try {
				 
				final int sqlTypes[] = { OracleTypes.VARCHAR,
						OracleTypes.VARCHAR, OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,OracleTypes.VARCHAR,OracleTypes.VARCHAR};
				final int pending_sqlTypes[] = { OracleTypes.VARCHAR,
						OracleTypes.VARCHAR};
				final Object[] params = new Object[] {
						preclosureModel.getPreClosureReferenceNo(),
						preclosureModel.getPreClosureRemarks(),
						preclosureModel.getPreclosureReqRaisedBy(),
						preclosureModel.getDebitAccountNo(),
						preclosureModel.getCreditAccountNo(),
						preclosureModel.getDebitBranchCode()						
						
				};
				
				final Object[] pending_params = new Object[] {
						
						preclosureModel.getCreditAccountNo(),
						preclosureModel.getDebitBranchCode()
						
						
				};
				pendingCount = getJdbcTemplate().queryForInt(GET_PRECLOSURE_PENDING, pending_params, pending_sqlTypes);
				LOGGER.info("pendingCount>>>>"+pendingCount);
				if(pendingCount == 0)
				{
					rowsEffected = getJdbcTemplate().update(UPDATE_PRECLOSURE_DETAILS, params, sqlTypes);
					LOGGER.info("No of Rows effected : " + rowsEffected);
				}	
				
				

			} catch (DAOException exp) {
				LOGGER.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);

			} catch (DataAccessException exp) {
				LOGGER.error("Unable to update sbicorp_fd_account_map:: "+ exp.getMessage(), exp);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);
			}
		
		}

			LOGGER.info("updateFDAccountMap(..) Ends Here");
		
		HashMap resultcount=new HashMap();
		resultcount.put("pendingCount", pendingCount); 
		resultcount.put("rowsEffected", rowsEffected); 
		
		return resultcount;
	}
	
	
	 public void setCoreDAOImpl(BankSystemDAO coreDAOImpl) {
	        this.coreDAOImpl = coreDAOImpl;
	    }
	 

}