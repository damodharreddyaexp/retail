package com.sbi.common.etdr.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;

public interface FixedDepositDAO  {

	public String getFdReferenceNo();
	public String getReferenceNo();
	public String findIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount);	//bank code added for associate bank by viswa
	public String findIntCategoryForAssociate(int tenure, String subCat,String bankCode,String fdRate,String fdAmount);	//bank code added for associate bank by viswa
	public int insertFdAccountDetails(FixedDepositModel fixedDepositModel);
	public int updateFdAccountDetails(FixedDepositModel fixedDepositModel);
	public String fdSegmentCodeFinder(String accountType , String subType ,int tenure);
    public Map getFdAmountDetails(String productCode,int totalnoofdays,String bankCode,String fdRate,String fdAmount);//bank code added for associate bank by viswa
    public Map getFdAmountDetailsForAssociate(String productCode,int totalNoOfDays,String bankCode,String fdRate,String fdAmount) throws DAOException;
    public List getFixedDepositDetails(String fdAccNo);
    public List findFDAccountNature(String accountNumber);
    public void closeFixedDepositAccount(Map fdClosureMap);
    public void updateMaturityDetails(Map maturityDetails);
	public Map getINBRefNoFDType(String fdAccountNo) throws DAOException;
	public String getProductDesc(String productCode,String bankCOde,String fdRate);//bank code added for associate bank by viswa
	public void customerAccountMapDetails(Map<String, Object> paramMap);
	public Map getFdAccountDetailsForChallan(String fdAccountNo);
	public Integer getTenureInDays(String fdAccountNo) throws DAOException;
	public String getProductDescAssociateBanks(String productCode,String bankCode) throws DAOException;
	public void updateAutoRenewalInfo(FixedDepositModel fixedDepositModel);
	/*DEV - 262 SBH Double Impl Starts Here */
	public Map getSBHDoubleTenureDetails(String productCode,String bankCode) throws DAOException;
	public Map getSBHDoubleFdAmountDetails(String productCode,int totalNoOfDays,String bankCode) throws DAOException;
	public String getSBHDoubleIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount);
	public String getSBHDoubleProductDesc(String productCode,String bankCode);
	/*DEV - 262 SBH Double Impl Ends Here */
	public int getAuthOption(String userName,String accountNo,String branchCode,Double amount);
	
	/* Master Product Code Logic (Table Based) Impl Starts Here */
	public int chkDebitProductCodeExists(String debitProductCode,String bankCode,String segmentCode);
	public List getProductCodeList(String debitProductCode,String bankCode,String segmentCode);
	/* Master Product Code Logic (Table Based) Impl ends Here */
	public void updateFdAccStatus(FixedDepositModel fixedDepositModel);
	
	public List getFixedDepositStatus(String userName, String bankCode, String debitAccountNo);
	public List getFixedDepositAccountDtls(String corporateId, String debitAccountNo);
}
