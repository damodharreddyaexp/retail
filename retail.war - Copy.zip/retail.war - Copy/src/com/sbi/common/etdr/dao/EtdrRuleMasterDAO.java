

/*     
 *RuleMasterDAOImpl.java
 * Created on Sep 22, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Sep, 2006 Aparna S  - Initial Creation

package com.sbi.common.etdr.dao;

import com.sbi.common.exception.DAOException;
import java.sql.Timestamp;

public interface EtdrRuleMasterDAO {
	
	/**
	 * @param accountNo
	 * @param branchCode
	 * @param amount
	 * @param corporateId
	 * @return Double
	 * @throws DAOException
	 */
	Double findBranchLimit(String accountNo,String branchCode,Double amount,Integer corporateId)throws DAOException;

	/**
	 * @param accountNo
	 * @param branchCode
	 * @return Double
	 * @throws DAOException
	 */
	Double findCorpAdminTransferLimit(String accountNo,String branchCode) throws DAOException;

	/**
	 * @param accountNo
	 * @param branchCode
	 * @return Double[]
	 * @throws DAOException
	 */
	Double[] getAdminUnauditCount(String accountNo,String branchCode)throws DAOException;

		/**
	 * @param billNo
	 * @return
	 * @throws DAOException
	 */
	public Timestamp getBillDate(String billNo) throws DAOException;
}
