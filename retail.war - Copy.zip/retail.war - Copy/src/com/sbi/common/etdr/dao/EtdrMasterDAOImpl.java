package com.sbi.common.etdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.etdr.model.EtdrMaster;
import com.sbi.common.etdr.model.FixedDepositModel;
import oracle.jdbc.driver.OracleTypes;

public class EtdrMasterDAOImpl  extends JdbcDaoSupport implements EtdrMasterDAO {
	
	
	protected final Logger logger = Logger.getLogger(getClass());
	private static final String GET_PAYBYDATE_BULK_PAYMENT = "select pay_by_date from sbicorp_echeque_master where echeque_no =  ?";
	
	private static final String GET_ETDR_INBOX = "select * from view_etdr_stdr_inbox a where a.user_name = ?";
	private static final String GET_ETDR_DETAILS = "select a.*,b.product_code from sbicorp_fd_account_map a, sbi_customer_account_map b where a.debit_account_no=b.account_no and a.user_name= b.user_name and a.reference_no = ?";
	private static final String AUTHORIZE_ETDR_REQUEST = "update sbicorp_fd_account_map set current_auth_level='2', auth_type='1', auth1_name=?, last_mod_time=sysdate where reference_no=?";
	private static final String CANCEL_ETDR_REQUEST = "update sbicorp_fd_account_map set status='cancel',auth_status='cancel' #tobereplaced# ,last_mod_time=sysdate where reference_no=?";
		
	private static final String GET_PRECLOSE_ETDR_INBOX = "select * from view_etdr_stdr_preclo_inbox a where a.user_name = ?";
	private static final String GET_PRECLOSE_ETDR_DETAILS = "select a.*,b.product_code from sbicorp_fd_account_map a, sbi_customer_account_map b where a.debit_account_no=b.account_no and a.user_name= b.user_name and a.preclosure_reference_no = ?";
	private static final String AUTHORIZE_PRECLOSE_ETDR_REQUEST = "update sbicorp_fd_account_map set preclosure_current_auth_level='2', preclosure_auth_type='1', preclosure_auth1_name=?, last_mod_time=sysdate where reference_no=?";
	   
	private static final String UNAUDIT_COUNT = "Select oid from sbicorp_echeque_master where account_no=? and branch_code =? and audited =1 and status=1 and current_auth_level!=-1 and debit_status in ('00','F1','REP.') and echeque_amount > ? and corporate_id = ?";
    
	private static final String UPDATE_PRE_CLOSURE_STATUS = "UPDATE SBICORP_FD_ACCOUNT_MAP SET PRECLOSURE_STATUS=?,CLOSED_DATE=sysdate,PRECLOSURE_REFERENCE_NO=?, PRECLOSURE_AUTH_STATUS='success',PRECLOSURE_CURRENT_AUTH_LEVEL=0,#tobereplaced# LAST_MOD_TIME=SYSDATE WHERE FD_ACCOUNT_NO=? ";
   
	private static final String UPDATE_FD_CLOSE_CUSTOMER_ACC_MAP_TABLE = "UPDATE SBI_CUSTOMER_ACCOUNT_MAP SET ACCESS_LEVEL=0, LAST_MOD_TIME=SYSDATE WHERE USER_NAME = ? AND ACCOUNT_NO = ? AND BRANCH_CODE = ?";
	private static final String ECHEQUEAUTHTYPE= " SELECT auth_type from  SBICORP_RULE_DETAILS  a,SBICORP_RULE_MASTER b where a.rule_id=b.rule_id and  a.user_name=? and a.status=1 and b.status=1 and b.from_limit <= ? and b.to_limit >= ? and B.account_no=? and B.branch_code=? and b.limit_status!=2 and b.limit_status!=3 and b.limit_status!=4 order by auth_type asc";
    private static final String CANCEL_PRECLOSE_ETDR_REQUEST = "update sbicorp_fd_account_map set preclosure_status='cancel',preclosure_auth_status='cancel' #tobereplaced# , last_mod_time=sysdate where reference_no=?";
	
 public Timestamp getPayByDate(String echequeNo) throws DAOException
   {
	   logger.info("getPayByDate(String echequeNo) method begins.");
		logger.info("echequeNo  " + echequeNo);
		Object[] params = {echequeNo};
		List payByDateList  = getJdbcTemplate().queryForList(GET_PAYBYDATE_BULK_PAYMENT,params);
		logger.info("echequeNo " + echequeNo);
		if (echequeNo != null ) {
			Map payByDateMap = new HashMap();
			payByDateMap = (Map)payByDateList.get(0);
			logger.info("payByDateMap " + payByDateMap);
			Timestamp payByDate = null;
			if(payByDateMap.get("PAY_BY_DATE") != null)
			{
				payByDate = (Timestamp)payByDateMap.get("PAY_BY_DATE");
				
			}
					
			return payByDate;			
		}		
		logger.info("getPayByDate(String echequeNo) method ends.");
		return null;
   }
    /* (non-Javadoc)
     * @see com.sbi.common.etdr.dao.EtdrMasterDAO#getUnauditCount(java.lang.String, java.lang.String, java.lang.Double)
     */
  //SR-97333 Included the corporate_id
    public int getUnauditCount(String accountNo, String branchCode, Double unauditMaxAmount, String corporateID) throws DAOException {
		
    	logger
		.info("getUnauditCount(String accountNo, String branchCode, Double unauditMaxAmount, String corporateID)Method Begin ");
    	logger.info("accountNo"+accountNo+","+"branchCode"+branchCode+","+"unauditMaxAmount"+unauditMaxAmount+","+"corporateID"+corporateID);
    	
    	List result = null;
    	int unauditCount = 0;
    	if(accountNo==null || branchCode==null || unauditMaxAmount==null || corporateID == null){
    		
    		DAOException.throwException("CU0030",new Object [] {});//input params are null
    	}else{
    		try{
    			int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.DOUBLE, Types.VARCHAR};//SR-97333 Included the corporate_id
				Object[] params = { accountNo, branchCode, unauditMaxAmount,corporateID};//SR-97333 Included the corporate_id
				result = getJdbcTemplate().queryForList(UNAUDIT_COUNT, params,
						sqlTypes);
				if(result!=null && result.size()>0){
				unauditCount = result.size();
				}
				logger.info("unauditCount from query"+unauditCount);
				
    		}catch(DataAccessException e){
    			
    			DAOException
				.throwException("CU0034",new Object [] {accountNo,branchCode,unauditMaxAmount});//select fails
    		}catch (Exception exp) {
	        	logger.error(LoggingConstants.EXCEPTION, exp);
	            
	        }
    	}
    	
    	logger
		.info("getUnauditCount(String accountNo, String branchCode, Double unauditMaxAmount, String corporateID)Method Ends ");
    	return unauditCount;
	}
    
 	public List getEtdrPendingRequests(String userName)
	{
		logger.info("getEtdrPendingRequests(String userName)" + LoggingConstants.METHODBEGIN);
		logger.info("userName : " + userName);
		String sql=null;
		List etdrPendingList = null;
		if(userName != null)
		{
			Object[] parameters = new Object[]{userName};
			int sqlTypes[] ={Types.VARCHAR};
			sql= GET_ETDR_INBOX;
			
			try{
			
				etdrPendingList = getJdbcTemplate().query(sql, parameters,sqlTypes, new EtdrMasterViewRowMapper());
				logger.info("list size: "+etdrPendingList.size());
				
			}catch (DataAccessException ex) {
	            ex.printStackTrace();
	            DAOException.throwException("CU0002",new Object [] {userName});
			}
		
		}else
		{
			DAOException.throwException("CU0001",new Object [] {userName});//Input values are null
		}
		logger.info("getEtdrPendingRequests(String userName) method ends");
		return etdrPendingList;	
	}
 	
 	public EtdrMaster getEtdrDetails(String referenceNo)
	{
		logger.info("getEtdrDetails(String referenceNo) method begins");
		logger.info("referenceNo : " + referenceNo);
		String sql=null;
		List etdDetailsList = null;
		EtdrMaster etdrMaster = null;
		if(referenceNo != null)
		{
			Object[] parameters = new Object[]{referenceNo};
			int sqlTypes[] ={Types.VARCHAR};
			sql= GET_ETDR_DETAILS;
			
			try{
				
				etdDetailsList = getJdbcTemplate().query(sql, parameters,sqlTypes, new EtdrMasterRowMapper());
				if(etdDetailsList!=null && etdDetailsList.size()>0)
					etdrMaster=(EtdrMaster)etdDetailsList.get(0);
				logger.info("Etdr details: "+etdrMaster);
				
			}catch (DataAccessException ex) {
	             ex.printStackTrace();
	             DAOException.throwException("CU0002",new Object [] {referenceNo});
			}
		
		}
		logger.info("getEtdrDetails(String referenceNo) method ends");
		return etdrMaster;	
	}
 	public int sendForSecondLevelAuthorize(Map inparams)
	{
		logger.info("sendForSecondLevelAuthorize(Map inparams) method begins");
		String sql=null;
		int updateCount=0;
		EtdrMaster etdrMaster=(EtdrMaster)inparams.get("etdrMaster");
		String userName=(String)inparams.get("userName");
		String referenceNo=etdrMaster.getReferenceNo();
		
		Object[] parameters = new Object[]{userName,referenceNo};
		int sqlTypes[] ={Types.VARCHAR,Types.VARCHAR};
		sql= AUTHORIZE_ETDR_REQUEST;
		
		try{
			
			updateCount = getJdbcTemplate().update(sql, parameters,sqlTypes);
			logger.info("update for first level authorization: "+updateCount);
			
		}catch (DataAccessException ex) {
             ex.printStackTrace();
             DAOException.throwException("CU0002",new Object [] {etdrMaster.getReferenceNo()});
		}
		
		logger.info("sendForSecondLevelAuthorize(Map inparams) method begins");
		return updateCount;	
	}
 	class EtdrMasterViewRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
	        EtdrMaster etdrMaster = new EtdrMaster();
	        
	        etdrMaster.setReferenceNo(rs.getString("reference_no"));
	        etdrMaster.setDebitAccountNo(rs.getString("debit_account_no"));
	        etdrMaster.setDebitBranchCode(rs.getString("debit_branch_code"));
	        etdrMaster.setCreationTime(rs.getTimestamp("creation_time"));
	        etdrMaster.setFdAmount(rs.getDouble("fd_amount"));
	        
	        etdrMaster.setMaker(rs.getString("maker"));
	        etdrMaster.setCurrentAuthLevel(rs.getString("current_auth_level"));
	        etdrMaster.setCorporateId(rs.getString("corporate_id"));
	        etdrMaster.setAuthType(rs.getString("auth_type"));
	        etdrMaster.setAccountNickname(rs.getString("account_nickname"));
	        
	        etdrMaster.setBranchName(rs.getString("branch_name"));
	        etdrMaster.setAuthOption(rs.getString("auth_option"));
	        etdrMaster.setUserName(rs.getString("user_name"));
	        etdrMaster.setStatus(rs.getString("status"));
	        etdrMaster.setAuth1Name(rs.getString("auth1_name"));
	        
	        etdrMaster.setAuth2Name(rs.getString("auth2_name"));
	        etdrMaster.setScheduled(rs.getString("scheduled"));
	        etdrMaster.setScheduledDate(rs.getTimestamp("scheduled_date"));
	        etdrMaster.setDebitStatus(rs.getString("debit_status"));
	        etdrMaster.setProductType(rs.getString("product_type"));
	        
	        etdrMaster.setRateOfInterest(rs.getDouble("rate_of_interest"));
	        etdrMaster.setProductDesc(rs.getString("product_desc"));
	        etdrMaster.setProductCode(rs.getString("product_code"));
	        
	        etdrMaster.setFdType(rs.getString("fd_type"));
	        etdrMaster.setFdAccountNature(rs.getString("fd_account_nature"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityInstruction(rs.getString("auto_renew_type"));
	        etdrMaster.setAutoRenewType(rs.getString("auto_renew_type"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        
	        etdrMaster.setTenureMaturityDate(rs.getTimestamp("tenure_maturity_date"));
	        etdrMaster.setTenure(rs.getInt("tenure"));
	        etdrMaster.setTenureDay(rs.getInt("tenure_day"));
	        etdrMaster.setTenureMonth(rs.getInt("tenure_month"));
	        etdrMaster.setTenureYear(rs.getInt("tenure_year"));
	        
	         
	        etdrMaster.setAutoRenewDays(rs.getInt("auto_renew_tenure_day"));
	        etdrMaster.setAutoRenewMonths(rs.getInt("auto_renew_tenure_month"));
	        etdrMaster.setAutoRenewYears(rs.getInt("auto_renew_tenure_year"));
	        
	        if(etdrMaster.getTenureMaturityDate()!=null && !"".equals(etdrMaster.getTenureMaturityDate())){
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("maturitymode");
	        }
	        else if((etdrMaster.getTenureDay()>0 && etdrMaster.getTenure()==0) || etdrMaster.getTenureMonth()>0 || etdrMaster.getTenureYear()>0) {
	        	etdrMaster.setDtMonYr(true);
	        	etdrMaster.setTenureType("yearmode");
	        }
	        else{
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("daymode");
	        }
	        //if((etdrMaster.getAutoRenewDays()>0 || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) && !(etdrMaster.getAutoRenewTenureInDays()>=0)) {
	        if((etdrMaster.getAutoRenewDays()>0 && etdrMaster.getAutoRenewTenureInDays()==0) || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) {
        		etdrMaster.setAutoRenewDtMonYr(true);
	        	etdrMaster.setAutoRenewTenureType("renewalyearmode");
        	}
	        else{
	        	etdrMaster.setAutoRenewDtMonYr(false);
	        	etdrMaster.setAutoRenewTenureType("renewaldaymode");
	        }  
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        etdrMaster.setInterestPayout(rs.getString("interest_payout"));
	        etdrMaster.setAutoRenewInterestPayout(rs.getString("auto_renew_interest_payout"));
	        
	        
	        return etdrMaster;
        }
	 }
 	class EtdrMasterRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
	        EtdrMaster etdrMaster = new EtdrMaster();
	        
	        etdrMaster.setReferenceNo(rs.getString("reference_no"));
	        etdrMaster.setDebitAccountNo(rs.getString("debit_account_no"));
	        etdrMaster.setDebitHolderName(rs.getString("debit_account_holder_name"));
	        etdrMaster.setDebitBranchCode(rs.getString("debit_branch_code"));
	        etdrMaster.setCreationTime(rs.getTimestamp("creation_time"));
	        etdrMaster.setFdAmount(rs.getDouble("fd_amount"));
	        etdrMaster.setFdAccountNo(rs.getString("fd_account_no"));
	        
	        etdrMaster.setMaker(rs.getString("user_name"));
	        etdrMaster.setCurrentAuthLevel(rs.getString("current_auth_level"));
	        etdrMaster.setCorporateId(rs.getString("corporate_id"));
	        etdrMaster.setAuthType(rs.getString("auth_type"));
	        
	        etdrMaster.setAuthOption(rs.getString("auth_option"));
	        etdrMaster.setUserName(rs.getString("user_name"));
	        etdrMaster.setStatus(rs.getString("status"));
	        etdrMaster.setAuth1Name(rs.getString("auth1_name"));
	        
	        etdrMaster.setAuth2Name(rs.getString("auth2_name"));
	        etdrMaster.setScheduled(rs.getString("scheduled"));
	        etdrMaster.setScheduledDate(rs.getTimestamp("scheduled_date"));
	        
	        etdrMaster.setRateOfInterest(rs.getDouble("interest_rate"));
	        
	        etdrMaster.setFdType(rs.getString("fd_type"));
	        etdrMaster.setFdAccountNature(rs.getString("fd_account_nature"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityInstruction(rs.getString("auto_renew_type"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        etdrMaster.setProductCode(rs.getString("product_code"));
	        etdrMaster.setInterestPayout(rs.getString("interest_payout"));
	        
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setTenureMaturityDate(rs.getTimestamp("tenure_maturity_date"));
	        etdrMaster.setTenure(rs.getInt("tenure"));
	        etdrMaster.setTenureDay(rs.getInt("tenure_day"));
	        etdrMaster.setTenureMonth(rs.getInt("tenure_month"));
	        etdrMaster.setTenureYear(rs.getInt("tenure_year"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        
	        etdrMaster.setAutoRenewType(rs.getString("auto_renew_type"));
	        etdrMaster.setAutoRenewTenureInDays(rs.getInt("auto_renew_tenure"));
	        etdrMaster.setAutoRenewDays(rs.getInt("auto_renew_tenure_day"));
	        etdrMaster.setAutoRenewMonths(rs.getInt("auto_renew_tenure_month"));
	        etdrMaster.setAutoRenewYears(rs.getInt("auto_renew_tenure_year"));
	        etdrMaster.setAutoRenewInterestPayout(rs.getString("auto_renew_interest_payout"));
	        
	        etdrMaster.setPreCloseRemarks(rs.getString("preclosure_remarks"));
	        etdrMaster.setPreCloseReferenceNo(rs.getString("preclosure_reference_no"));
	        etdrMaster.setPreCloseReqRaisedBy(rs.getString("preclosure_req_raised_by"));
	        etdrMaster.setPreCloseCurrentAuthLevel(rs.getString("preclosure_current_auth_level"));
	        
	        if(etdrMaster.getTenureMaturityDate()!=null && !"".equals(etdrMaster.getTenureMaturityDate())){
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("maturitymode");
	        }
	        else if((etdrMaster.getTenureDay()>0 && etdrMaster.getTenure()==0) || etdrMaster.getTenureMonth()>0 || etdrMaster.getTenureYear()>0) {
	        	etdrMaster.setDtMonYr(true);
	        	etdrMaster.setTenureType("yearmode");
	        }
	        else{
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("daymode");
	        }
	        //if((etdrMaster.getAutoRenewDays()>0 || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) && !(etdrMaster.getAutoRenewTenureInDays()>=0)) {
	        if((etdrMaster.getAutoRenewDays()>0 && etdrMaster.getAutoRenewTenureInDays()==0) || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) {
        		etdrMaster.setAutoRenewDtMonYr(true);
	        	etdrMaster.setAutoRenewTenureType("renewalyearmode");
        	}
	        else{
	        	etdrMaster.setAutoRenewDtMonYr(false);
	        	etdrMaster.setAutoRenewTenureType("renewaldaymode");
	        }
	        
	        return etdrMaster;
        }
	 }
 	public int cancelEtdrRequest(EtdrMaster etdrMaster)
	{
		logger.info("cancelEtdrRequest(EtdrMaster etdrMaster) method begins");
		int updateCount=0;
		String currAuthNameVal="";
		String currAuthInfo="";
		
		if(etdrMaster.getAuth2Name()!=null && !"".equals(etdrMaster.getAuth2Name())) {
			currAuthNameVal=etdrMaster.getAuth2Name();
			currAuthInfo=",auth2_name=?,current_auth_level=-2 ";
		}
		else { 
			currAuthNameVal=etdrMaster.getAuth1Name();
			currAuthInfo=",auth1_name=?,current_auth_level=-1 ";
		}
		
		Object[] parameters = new Object[]{currAuthNameVal,etdrMaster.getReferenceNo()};
		int sqlTypes[] ={Types.VARCHAR,Types.VARCHAR};
		String query =  CANCEL_ETDR_REQUEST.replaceAll("#tobereplaced#", currAuthInfo);
		
		try{
			
			updateCount = getJdbcTemplate().update(query, parameters,sqlTypes);
			logger.info("update for cancel etdr request: "+updateCount);
			
		}catch (DataAccessException ex) {
             ex.printStackTrace();
             DAOException.throwException("CU0002",new Object [] {etdrMaster.getReferenceNo()});
		}
		
		logger.info("cancelEtdrRequest(EtdrMaster etdrMaster) method begins");
		return updateCount;	
	}
 	
 	public List getPreCloseEtdrPendingRequests(String userName)
	{
		logger.info("getPreCloseEtdrPendingRequests(String userName)" + LoggingConstants.METHODBEGIN);
		logger.info("userName : " + userName);
		String sql=null;
		List etdrPendingList = null;
		if(userName != null)
		{
			Object[] parameters = new Object[]{userName};
			int sqlTypes[] ={Types.VARCHAR};
			sql= GET_PRECLOSE_ETDR_INBOX;
			
			try{
			
				etdrPendingList = getJdbcTemplate().query(sql, parameters,sqlTypes, new PreCloseEtdrMasterViewRowMapper());
				
				
			}catch (DataAccessException ex) {
	            ex.printStackTrace();
	            DAOException.throwException("CU0002",new Object [] {userName});
			}
		
		}
		logger.info("getPreCloseEtdrPendingRequests(String userName) method ends");
		return etdrPendingList;	
	}
 	class PreCloseEtdrMasterViewRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
	        EtdrMaster etdrMaster = new EtdrMaster();
	        
	        //etdrMaster.setReferenceNo(rs.getString("reference_no"));
	        etdrMaster.setPreCloseReferenceNo(rs.getString("preclosure_reference_no"));
	        etdrMaster.setDebitAccountNo(rs.getString("debit_account_no"));
	        etdrMaster.setFdAccountNo(rs.getString("fd_account_no"));
	        etdrMaster.setDebitBranchCode(rs.getString("debit_branch_code"));
	        etdrMaster.setCreationTime(rs.getTimestamp("creation_time"));
	        etdrMaster.setFdAmount(rs.getDouble("fd_amount"));
	        
	        etdrMaster.setMaker(rs.getString("maker"));
	        etdrMaster.setCurrentAuthLevel(rs.getString("current_auth_level"));
	        etdrMaster.setCorporateId(rs.getString("corporate_id"));
	        etdrMaster.setAuthType(rs.getString("auth_type"));
	        etdrMaster.setAccountNickname(rs.getString("account_nickname"));
	        
	        etdrMaster.setBranchName(rs.getString("branch_name"));
	        etdrMaster.setAuthOption(rs.getString("auth_option"));
	        etdrMaster.setUserName(rs.getString("user_name"));
	        etdrMaster.setStatus(rs.getString("status"));
	        etdrMaster.setAuth1Name(rs.getString("auth1_name"));
	        
	        etdrMaster.setAuth2Name(rs.getString("auth2_name"));
	        etdrMaster.setScheduled(rs.getString("scheduled"));
	        etdrMaster.setScheduledDate(rs.getTimestamp("scheduled_date"));
	        etdrMaster.setDebitStatus(rs.getString("debit_status"));
	        etdrMaster.setProductType(rs.getString("product_type"));
	        
	        etdrMaster.setRateOfInterest(rs.getDouble("rate_of_interest"));
	        etdrMaster.setProductDesc(rs.getString("product_desc"));
	        etdrMaster.setProductCode(rs.getString("product_code"));
	        
	        etdrMaster.setFdType(rs.getString("fd_type"));
	        etdrMaster.setFdAccountNature(rs.getString("fd_account_nature"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityInstruction(rs.getString("auto_renew_type"));
	        etdrMaster.setAutoRenewType(rs.getString("auto_renew_type"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        
	        etdrMaster.setTenureMaturityDate(rs.getTimestamp("tenure_maturity_date"));
	        etdrMaster.setTenure(rs.getInt("tenure"));
	        etdrMaster.setTenureDay(rs.getInt("tenure_day"));
	        etdrMaster.setTenureMonth(rs.getInt("tenure_month"));
	        etdrMaster.setTenureYear(rs.getInt("tenure_year"));
	        
	         
	        etdrMaster.setAutoRenewDays(rs.getInt("auto_renew_tenure_day"));
	        etdrMaster.setAutoRenewMonths(rs.getInt("auto_renew_tenure_month"));
	        etdrMaster.setAutoRenewYears(rs.getInt("auto_renew_tenure_year"));
	        
	        if(etdrMaster.getTenureMaturityDate()!=null && !"".equals(etdrMaster.getTenureMaturityDate())){
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("maturitymode");
	        }
	        else if((etdrMaster.getTenureDay()>0 && !(etdrMaster.getTenure()>=0)) || etdrMaster.getTenureMonth()>0 || etdrMaster.getTenureYear()>0) {
	        	etdrMaster.setDtMonYr(true);
	        	etdrMaster.setTenureType("yearmode");
	        }
	        else{
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("daymode");
	        }
	        //if((etdrMaster.getAutoRenewDays()>0 || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) && !(etdrMaster.getAutoRenewTenureInDays()>=0)) {
	        if((etdrMaster.getAutoRenewDays()>0 && !(etdrMaster.getAutoRenewTenureInDays()>=0)) || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) {
	        	etdrMaster.setAutoRenewDtMonYr(true);
	        	etdrMaster.setAutoRenewTenureType("renewalyearmode");
        	}
	        else{
	        	etdrMaster.setAutoRenewDtMonYr(false);
	        	etdrMaster.setAutoRenewTenureType("renewaldaymode");
	        }  
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        etdrMaster.setInterestPayout(rs.getString("interest_payout"));
	        etdrMaster.setAutoRenewInterestPayout(rs.getString("auto_renew_interest_payout"));
	        
	        
	        return etdrMaster;
        }
	 }
 	public EtdrMaster getPreCloseEtdrDetails(String preCloseReferenceNo)
	{
		logger.info("getPreCloseEtdrDetails(String preCloseReferenceNo) method begins");
		logger.info("preCloseReferenceNo : " + preCloseReferenceNo);
		String sql=null;
		List etdDetailsList = null;
		EtdrMaster etdrMaster = null;
		if(preCloseReferenceNo != null)
		{
			Object[] parameters = new Object[]{preCloseReferenceNo};
			int sqlTypes[] ={Types.VARCHAR};
			sql= GET_PRECLOSE_ETDR_DETAILS;
			
			try{
				
				etdDetailsList = getJdbcTemplate().query(sql, parameters,sqlTypes, new EtdrMasterRowMapper());
				if(etdDetailsList!=null && etdDetailsList.size()>0)
					etdrMaster=(EtdrMaster)etdDetailsList.get(0);
				logger.info("Preclose Etdr details: "+etdrMaster);
				
			}catch (DataAccessException ex) {
	             ex.printStackTrace();
	             DAOException.throwException("CU0002",new Object [] {preCloseReferenceNo});
			}
		
		}else
		{
			DAOException.throwException("CU0001",new Object [] {preCloseReferenceNo});//Input values are null
		}
		logger.info("getPreCloseEtdrDetails(String preCloseReferenceNo) method ends");
		return etdrMaster;	
	}
 	class PreCloseEtdrMasterRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
	        EtdrMaster etdrMaster = new EtdrMaster();
	        
	        etdrMaster.setReferenceNo(rs.getString("reference_no"));
	        etdrMaster.setDebitAccountNo(rs.getString("debit_account_no"));
	        etdrMaster.setDebitBranchCode(rs.getString("debit_branch_code"));
	        etdrMaster.setCreationTime(rs.getTimestamp("creation_time"));
	        etdrMaster.setFdAmount(rs.getDouble("fd_amount"));
	        
	        etdrMaster.setMaker(rs.getString("user_name"));
	        etdrMaster.setCurrentAuthLevel(rs.getString("current_auth_level"));
	        etdrMaster.setCorporateId(rs.getString("corporate_id"));
	        etdrMaster.setAuthType(rs.getString("auth_type"));
	        
	        etdrMaster.setAuthOption(rs.getString("auth_option"));
	        etdrMaster.setUserName(rs.getString("user_name"));
	        etdrMaster.setStatus(rs.getString("status"));
	        etdrMaster.setAuth1Name(rs.getString("auth1_name"));
	        
	        etdrMaster.setAuth2Name(rs.getString("auth2_name"));
	        etdrMaster.setScheduled(rs.getString("scheduled"));
	        etdrMaster.setScheduledDate(rs.getTimestamp("scheduled_date"));
	        
	        etdrMaster.setRateOfInterest(rs.getDouble("interest_rate"));
	        
	        etdrMaster.setFdType(rs.getString("fd_type"));
	        etdrMaster.setFdAccountNature(rs.getString("fd_account_nature"));
	        etdrMaster.setMaturityValue(rs.getDouble("maturity_value"));
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setMaturityInstruction(rs.getString("auto_renew_type"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        etdrMaster.setProductCode(rs.getString("product_code"));
	        etdrMaster.setInterestPayout(rs.getString("interest_payout"));
	        
	        etdrMaster.setMaturityDate(rs.getTimestamp("maturity_date"));
	        etdrMaster.setTenureMaturityDate(rs.getTimestamp("tenure_maturity_date"));
	        etdrMaster.setTenure(rs.getInt("tenure"));
	        etdrMaster.setTenureDay(rs.getInt("tenure_day"));
	        etdrMaster.setTenureMonth(rs.getInt("tenure_month"));
	        etdrMaster.setTenureYear(rs.getInt("tenure_year"));
	        etdrMaster.setFdRateType(rs.getString("fd_rate_type"));
	        
	        etdrMaster.setAutoRenewType(rs.getString("auto_renew_type"));
	        etdrMaster.setAutoRenewTenureInDays(rs.getInt("auto_renew_tenure"));
	        etdrMaster.setAutoRenewDays(rs.getInt("auto_renew_tenure_day"));
	        etdrMaster.setAutoRenewMonths(rs.getInt("auto_renew_tenure_month"));
	        etdrMaster.setAutoRenewYears(rs.getInt("auto_renew_tenure_year"));
	        etdrMaster.setAutoRenewInterestPayout(rs.getString("auto_renew_interest_payout"));
	        
	        if(etdrMaster.getTenureMaturityDate()!=null && !"".equals(etdrMaster.getTenureMaturityDate())){
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("maturitymode");
	        }
	        else if((etdrMaster.getTenureDay()>0 && !(etdrMaster.getTenure()>=0)) || etdrMaster.getTenureMonth()>0 || etdrMaster.getTenureYear()>0) {
	        	etdrMaster.setDtMonYr(true);
	        	etdrMaster.setTenureType("yearmode");
	        }
	        else{
	        	etdrMaster.setDtMonYr(false);
	        	etdrMaster.setTenureType("daymode");
	        }
	        //if((etdrMaster.getAutoRenewDays()>0 || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) && !(etdrMaster.getAutoRenewTenureInDays()>=0)) {
	        if((etdrMaster.getAutoRenewDays()>0 && !(etdrMaster.getAutoRenewTenureInDays()>=0)) || etdrMaster.getAutoRenewMonths()>0 || etdrMaster.getAutoRenewYears()>0) {
	        	etdrMaster.setAutoRenewDtMonYr(true);
	        	etdrMaster.setAutoRenewTenureType("renewalyearmode");
        	}
	        else{
	        	etdrMaster.setAutoRenewDtMonYr(false);
	        	etdrMaster.setAutoRenewTenureType("renewaldaymode");
	        }
	        
	        return etdrMaster;
        }
	 }
 	public int sendForSecondLevelPreCloseAuthorize(Map inparams)
	{
		logger.info("sendForSecondLevelPreCloseAuthorize(Map inparams) method begins");
		String sql=null;
		int updateCount=0;
		EtdrMaster etdrMaster=(EtdrMaster)inparams.get("etdrMaster");
		String userName=(String)inparams.get("userName");
		String referenceNo=etdrMaster.getReferenceNo();
		
		Object[] parameters = new Object[]{userName,referenceNo};
		int sqlTypes[] ={Types.VARCHAR,Types.VARCHAR};
		sql= AUTHORIZE_PRECLOSE_ETDR_REQUEST;
		
		try{
			
			updateCount = getJdbcTemplate().update(sql, parameters,sqlTypes);
			logger.info("update for first level authorization: "+updateCount);
			
		}catch (DataAccessException ex) {
             ex.printStackTrace();
             DAOException.throwException("CU0002",new Object [] {etdrMaster.getReferenceNo()});
		}
		
		logger.info("sendForSecondLevelPreCloseAuthorize(Map inparams) method begins");
		return updateCount;	
	}
 	public void closeFixedDepositAccount(FixedDepositModel preclosureModel) {
		logger.info("closeFixedDepositAccount(..) Starts Here");
		try {
			if (preclosureModel != null) {

				logger.info("Closure Status -->"+ preclosureModel.getPreClosureStatus());
				logger.info("Closed Date -->"+ preclosureModel.getClosedDate());
				logger.info("Close Reference No -->"+ preclosureModel.getPreClosureReferenceNo());
				logger.info("FD Account No -->"+ preclosureModel.getFdAccountNo());
				logger.info("User Name -->" + preclosureModel.getUserName());
				logger.info("Debit Branch Code -->"+ preclosureModel.getDebitBranchCode());
				
				int count = 0 ;
				String currAuthNameVal="";
				String currAuthType="";
				
				if(preclosureModel.getAuth2Name()!=null && !"".equals(preclosureModel.getAuth2Name())) {
					currAuthNameVal=preclosureModel.getAuth2Name();
					currAuthType="preclosure_auth2_name=?,";
				}
				else {
					currAuthNameVal=preclosureModel.getAuth1Name();
					currAuthType="preclosure_auth1_name=?,";
				}
				
				
				final int sqlTypes[] = { OracleTypes.VARCHAR,OracleTypes.VARCHAR,Types.VARCHAR,OracleTypes.VARCHAR};
				final Object[] params = new Object[] {
						preclosureModel.getPreClosureStatus(),
						preclosureModel.getPreClosureReferenceNo(),
						currAuthNameVal,
						preclosureModel.getFdAccountNo() };
				
				String query =  UPDATE_PRE_CLOSURE_STATUS.replaceAll("#tobereplaced#", currAuthType);
				int rowsUpdated = getJdbcTemplate().update(query, params, sqlTypes);

				logger.info("No. of Rows Updated in sbicorp_fd_accosunt_map -->"+ rowsUpdated);

				if (rowsUpdated > 0) {
					final int sqlType[] = { OracleTypes.VARCHAR,
							OracleTypes.VARCHAR, OracleTypes.VARCHAR };
					Object[] obj = new Object[] {
							preclosureModel.getUserName(),
							preclosureModel.getFdAccountNo(),
							preclosureModel.getDebitBranchCode()};

					int updatedRows = getJdbcTemplate().update(UPDATE_FD_CLOSE_CUSTOMER_ACC_MAP_TABLE, obj,sqlType);
					logger.info("No. of Records Updated in customer Account Map--->"+ updatedRows);
				}
			}
		} catch (DAOException exp) {
			logger.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);

		} catch (DataAccessException e) {
			logger.error("ERROR: Unable to close the operation:: "+ e.getMessage(), e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("closeFixedDepositAccount(..) Ends Here");
	}
 	public int findUserAuthType(String accountNo, String branchCode, Double amount, String userName) {
		int authType=-1;
		List userAuthorizationRuleList;
		if(accountNo!=null && branchCode!=null && amount !=null && userName!=null)
		{
			logger.info("inside getAuthType ");
			logger.info(" accountNo : "+accountNo);
			logger.info(" branchCode : "+branchCode);
			logger.info(" amount : "+amount);
			logger.info(" userName : "+userName);
			logger.info(" ECHEQUEAUTHTYPE : "+ECHEQUEAUTHTYPE);
			Object params[]={userName,amount,amount,accountNo,branchCode};
			try
			{
				userAuthorizationRuleList=getJdbcTemplate().queryForList(ECHEQUEAUTHTYPE,params);
				logger.info(" userAuthorizationRuleList : "+userAuthorizationRuleList);
				if(userAuthorizationRuleList!=null && userAuthorizationRuleList.size()>0){
					Map authMap =(Map)userAuthorizationRuleList.get(0);
					authType = Integer.parseInt(authMap.get("AUTH_TYPE").toString());
					logger.info(" authType inside if : "+authType);
				}
				else
					authType=-1;
			}catch(IncorrectResultSizeDataAccessException re)
	        { 
	        	logger.info("IncorrectResultSizeDataAccessException ");
	        	authType= -1;
	        }catch(DataAccessException dataAccessException) {
	        	logger.info("dataAccessException ");
				dataAccessException.printStackTrace();
				  DAOException.throwException("CU0002",new Object [] {params});
			}catch(Exception exception) {
	        	logger.info("dataAccessException ");
	        	exception.printStackTrace();
				  DAOException.throwException("CU0002",new Object [] {params});
			}
			
		}
		else
			authType= -1;
		
		logger.info(" authType returned : "+authType);
		return authType;
		
	}
 	public int cancelPreCloseEtdrRequest(EtdrMaster etdrMaster)
	{
		logger.info("cancelPreCloseEtdrRequest(EtdrMaster etdrMaster) method begins");
		int updateCount=0;
		String currAuthNameVal="";
		String currAuthInfo="";
		
		if(etdrMaster.getAuth2Name()!=null && !"".equals(etdrMaster.getAuth2Name())) {
			currAuthNameVal=etdrMaster.getAuth2Name();
			currAuthInfo=",preclosure_auth2_name=?,preclosure_current_auth_level=-2 ";
		}
		else {
			currAuthNameVal=etdrMaster.getAuth1Name();
			currAuthInfo=",preclosure_auth1_name=?,preclosure_current_auth_level=-1 ";
		}
		
		
		Object[] parameters = new Object[]{currAuthNameVal,etdrMaster.getReferenceNo()};
		int sqlTypes[] ={Types.VARCHAR,Types.VARCHAR};
		String query =  CANCEL_PRECLOSE_ETDR_REQUEST.replaceAll("#tobereplaced#", currAuthInfo);
		
		try{
			
			updateCount = getJdbcTemplate().update(query, parameters,sqlTypes);
			logger.info("update for cancel preclose etdr request: "+updateCount);
			
		}catch (DataAccessException ex) {
             ex.printStackTrace();
             DAOException.throwException("CU0002",new Object [] {etdrMaster.getReferenceNo()});
		}
		
		logger.info("cancelPreCloseEtdrRequest(EtdrMaster etdrMaster) method begins");
		return updateCount;	
	}
}