package com.sbi.common.etdr.dao;

import java.sql.Types;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import wac.audit.FieldCollection;
import wac.audit.FieldsModel;

import com.sbi.common.dao.DAOConstants;
import com.sbi.common.exception.DAOException;

public class EchequeMasterDAOImpl  extends JdbcDaoSupport implements EchequeMasterDAO{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	private static final String UPDATE_ECHEQUE = "update SBICORP_ECHEQUE_MASTER set #tobereplaced# where echeque_no = ?";
	
	public int updateEcheque(FieldCollection fieldCollection , String echequeNumber)
			throws DAOException {
    	logger.info("updateEcheque(List echequeMasterParamList, String echequeNumber)Method Begin ");

    	logger.info("FieldCollection : " + fieldCollection + "," + "EchequeNumber : " + echequeNumber);
    	int rowAffected = 0;
        List echequeMasterParamList= null;
		
		if (fieldCollection == null && echequeNumber == null) {
			DAOException
					.throwException("CU0019", new Object [] {fieldCollection,echequeNumber});

		} else {
			echequeMasterParamList =fieldCollection.getFieldList();
			int listSize = echequeMasterParamList.size();
			
			logger.info("List Size is " + listSize);
			Object[] param = new Object[listSize + 1];
			int[] sqlType = new int[listSize + 1];
			int counter = 0;
			String queryString = DAOConstants.EMPTY;
			boolean flag = true;
			logger.info("Values of echequeNumber"+echequeNumber);
			//System.out.println("Values of echequeNumber " + echequeNumber);
			for (counter = 0; counter < listSize; counter++) {
				FieldsModel dataForUpdateQuery = (FieldsModel) echequeMasterParamList
						.get(counter);
				logger.info("Values in Field Object"+dataForUpdateQuery.getValue());
				//System.out.println("Values in Field Object " + dataForUpdateQuery.getValue());
				String fieldName = dataForUpdateQuery.getName();
				Object value = dataForUpdateQuery.getValue();
				int type = dataForUpdateQuery.getType();
				param[counter] = value;
				sqlType[counter] = type;
				if (flag) {
					queryString = queryString + DAOConstants.EMPTY + fieldName
							+ DAOConstants.EQUAL + DAOConstants.BIND_VARIABLE;
					flag = false;
				} else {
					queryString = queryString + DAOConstants.COMA
							+ DAOConstants.SPACE + fieldName
							+ DAOConstants.EQUAL + DAOConstants.BIND_VARIABLE;
				}
			}

			queryString = queryString + ",LAST_MOD_TIME=sysdate";
			//System.out.println("Query String is " + queryString);
			logger.info("Query String is"+queryString);
			param[counter] = echequeNumber;
			sqlType[counter] = Types.VARCHAR;
			String finalQuery = UPDATE_ECHEQUE.replaceAll(
					DAOConstants.TO_BE_REPLACED, queryString);
			logger.info("Final Query for Update is " + finalQuery);

			
		
			try {
				//String INSERT_AUDIT_QUERY = "insert into wac_audit_trail values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
				fieldCollection.addField(new FieldsModel(
						"echeque_no", Types.VARCHAR,
						echequeNumber, 2));
				//rowAffected=auditTrailDAOImpl.update(finalQuery,fieldCollection);
				
				rowAffected  =  getJdbcTemplate().update(finalQuery, fieldCollection.getUpdateParams(),fieldCollection.getUpdateParamsTypes());
				logger.info("No of rows updated succesfully in echeque master after authorization:  "+rowAffected +"for echequeNo:" + echequeNumber);
				// getJdbcTemplate().update(INSERT_AUDIT_QUERY, fieldCollection.getAuditParams());
				 }
			catch(Exception e)
			{
				logger.info("Exception in updating the audit trial");
			}
		}
		logger.info("updateEcheque(List echequeMasterParamList, String echequeNumber)Method ends ");
		return rowAffected;
    }
 
}