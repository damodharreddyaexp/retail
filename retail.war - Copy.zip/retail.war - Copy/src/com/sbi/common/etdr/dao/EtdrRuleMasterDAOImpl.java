/*     
 *RuleMasterDAOImpl.java
 * Created on Sep 22, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Sep, 2006 Aparna  - Initial Creation and Implementation
 
package com.sbi.common.etdr.dao;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.sql.Timestamp;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

/**
 * TODO This  class gets the branchlimit,corporate limit and unauditcount for the transactions
 * This is used by the validatorBP's to validate the transaction object.
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class EtdrRuleMasterDAOImpl extends JdbcDaoSupport implements EtdrRuleMasterDAO {

	private static final String BRANCH_LIMIT = "select branch_limit from sbicorp_rule_master where corporate_id =? and account_no =? and branch_code=? and from_limit <=? and to_limit >=? and limit_status =1 and status=1";

	private static final String CORPADMIN_TRANSFER_LIMIT = "select decode(limit,null,-1,limit)limit from sbicorp_ca_account_map where account_no=? and branch_code=? and status=1";

	private static final String ADMIN_UNAUDIT_COUNT = "select MAX_UNAUDITED_COUNT , MAX_UNAUDITED_AMOUNT from sbicorp_audit_account_map where account_no=? and branch_code=? and status=1 ";

    private static final String GET_BILL_DATE = "select DECODE (c.allow_after_due_date, 1, b.bill_due_date - NVL ((c.days_before_due_date-1),0), '') allow_no, DECODE (c.allow_after_due_date, 0, b.bill_due_date + NVL (c.bill_expiry_days, 0), '') allow_yes from sbi_bp_bill_master b, sbi_bp_biller_master c where b.bill_number=? and c.biller_id = b.biller_id";//shanta
	
    protected final Logger logger = Logger.getLogger(getClass());
    
	
    
    /**
     * TODO Gets accountNo,branchCode,amount and corporateId from CorpTransactionValidator.validateAuthorize
     * 2.Querries the branch_limit from  sbicorp_rule_master
     * 3.Returns branchLimit
	 * @param accountNo
	 * @param branchCode
	 * @param amount
	 * @param corporateId
	 * @return Double
	 * @throws DAOException
	 */
	public Double findBranchLimit(String accountNo, String branchCode,
			Double amount, Integer corporateId) throws DAOException {

		logger
				.info("findBranchLimit(String accountNo, String branchCode, Double amount, Integer corporateId) method begins");
		logger.info("accountNo" + accountNo + "," + "branchCode" + branchCode
				+ "," + "amount" + amount + "," + "corporateId" + corporateId);
		Double branchLimit = null;
		List result = null;
		Map outMap = null;

		if (accountNo == null || branchCode == null || amount == null
				|| corporateId == null) {

			DAOException.throwException("CU0030", new Object[] {});// input params null
																	 

		} else {
			try {
				int sqlTypes[] = { Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
						Types.DOUBLE, Types.DOUBLE };
				Object[] params = { corporateId, accountNo, branchCode, amount,
						amount };
				result = getJdbcTemplate().queryForList(BRANCH_LIMIT, params,
						sqlTypes);
				if (result != null && result.size() > 0) {
					outMap = (Map) result.get(0);
					logger.info("outMap ::::::: " + outMap);
					BigDecimal bigBranchLimit = (BigDecimal)outMap.get("BRANCH_LIMIT");
					branchLimit = new Double(bigBranchLimit.doubleValue()); 
				    logger.info("Branch limit" + branchLimit);
				}
			} catch (DataAccessException ex) {

				DAOException.throwException("CU0031", new Object[] { accountNo,
						branchCode, amount, corporateId });
			}catch (Exception exp) {
	        	logger.error(LoggingConstants.EXCEPTION, exp);
	            
	        }
		}

		logger
				.info("findBranchLimit(String accountNo, String branchCode, String amount, Integer corporateId) method ends");
		return branchLimit;
	}

	/**
	 * TODO Gets accountNo and branchCode from CorpTransactionValidator.validateCALimit
	 * 2.Querries limit from sbicorp_ca_account_map
	 * 3.Returns corpAdminTransferLimit.
	 * @param accountNo
	 * @param branchCode
	 * @return Double
	 * @throws DAOException
	 */
	public Double findCorpAdminTransferLimit(String accountNo, String branchCode)
			throws DAOException {
		logger
				.info("findCorpAdminTransferLimit(String accountNo,String branchCode) method ends");
		logger.info("accountNo" + accountNo + "," + "branchCode" + branchCode);
		
		Double corpAdminTransferLimit = null;
		List result = null;
		Map outMap = null;
		if (accountNo == null || branchCode == null) {

			DAOException.throwException("CU0030", new Object[] {}); // input params null
																	
		} else {

			try {

				int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR };
				Object[] params = { accountNo, branchCode };
				result = getJdbcTemplate().queryForList(
						CORPADMIN_TRANSFER_LIMIT, params, sqlTypes);
				if (result != null && result.size() > 0) {
					outMap = (Map) result.get(0);
					logger.info(" outMap :::: "+outMap);
					BigDecimal bigLimit = (BigDecimal)outMap.get("LIMIT");
					logger.info("limit" + corpAdminTransferLimit);
					corpAdminTransferLimit = new Double( bigLimit.doubleValue());
				}

			} catch (DataAccessException ex) {

				DAOException.throwException("CU0032", new Object[] { accountNo,
						branchCode });
			}catch (Exception exp) {
	        	logger.error(LoggingConstants.EXCEPTION, exp);
	            
	        }

		}
		logger
				.info("findCorpAdminTransferLimit(String accountNo,String branchCode) method ends");
		return corpAdminTransferLimit;
	}

	/**
	 * TODO Gets accountNo and branchCode from CorpTransactionValidator.validateAccountAudited
	 * 2.Querries MAX_UNAUDITED_COUNT , MAX_UNAUDITED_AMOUNT from sbicorp_audit_account_map
	 * 3.Returns array containing count and amount.
	 * @param accountNo
	 * @param branchCode
	 * @return Double[]
	 * @throws DAOException
	 */
	
	public Double[] getAdminUnauditCount(String accountNo, String branchCode)
			throws DAOException {
		logger
				.info("getAdminUnauditCount(String accountNo, String branchCode) method begins");
		logger.info("accountNo" + accountNo + "," + "branchCode" + branchCode);
		List result = null;
		Map outMap = null;
		Double[] adminUnauditCount = new Double[2];
		if (accountNo == null || branchCode == null) {

			DAOException.throwException("CU0030", new Object[] {}); // input params null
																	 
		} else {

			try {
				int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR };
				Object[] params = { accountNo, branchCode };
				result = getJdbcTemplate().queryForList(ADMIN_UNAUDIT_COUNT,
						params, sqlTypes);
				logger.info("result :"+result+" and result size :"+result.size());
				if (result != null && result.size() > 0) {
					outMap = (Map) result.get(0);
					BigDecimal bigMaxUnAuditedCount = (BigDecimal)outMap.get("MAX_UNAUDITED_COUNT");
					BigDecimal bigMaxUnAuditedAmount = (BigDecimal)outMap.get("MAX_UNAUDITED_AMOUNT");
					if(bigMaxUnAuditedCount!=null && bigMaxUnAuditedAmount!=null)
					{
					Double maxUnAuditedCount = new Double(bigMaxUnAuditedCount.doubleValue());				
					Double maxUnAuditedAmount = new Double(bigMaxUnAuditedAmount.doubleValue());
					adminUnauditCount[0] = maxUnAuditedCount;
					adminUnauditCount[1] = maxUnAuditedAmount;
					logger.info("Array values" + adminUnauditCount[0] + ","
							+ adminUnauditCount[1]);
				}
					else adminUnauditCount=null;
				}
				else adminUnauditCount=null;

			} catch (DataAccessException ex) {

				DAOException.throwException("CU0033", new Object[] { accountNo,
						branchCode });
			}catch (Exception exp) {
	        	logger.error(LoggingConstants.EXCEPTION, exp);
	            
	        }
		}
		logger
				.info("getAdminUnauditCount(String accountNo, String branchCode) method begins");
		return adminUnauditCount;
	}

		/* (non-Javadoc)
	 * @see com.sbi.common.etdr.dao.EtdrRuleMasterDAO#getBillDate(java.lang.String)
	 */
	
	public Timestamp getBillDate(String billNo) throws DAOException
	{	
		logger.info("getBillDate(String billNo) method begins.");
		logger.info("billNo  " + billNo);
		Object[] params = { billNo};
		List billDate  = getJdbcTemplate().queryForList(GET_BILL_DATE,	params);
		logger.info("billDate " + billDate);
		if (billDate != null ) {
			Map billMap = new HashMap();
			billMap = (Map)billDate.get(0);
			logger.info("billMap " + billMap);
			Timestamp billDateStr = null;
			if(billMap.get("ALLOW_YES") != null)
			{
				logger.info("allow_yes " + billMap.get("ALLOW_YES"));
				billDateStr = (Timestamp)billMap.get("ALLOW_YES");
				logger.info("allow_yes " + billDateStr);
			}
			else if(billMap.get("ALLOW_NO") != null)
			{
				logger.info("allow_no " + billMap.get("ALLOW_NO"));
				billDateStr = (Timestamp)billMap.get("ALLOW_NO");
				logger.info("allow_no " + billDateStr);
			}			
			return billDateStr;			
		}		
		logger.info("getBillDate(String billNo) method ends.");
		return null;
	}
	
}
