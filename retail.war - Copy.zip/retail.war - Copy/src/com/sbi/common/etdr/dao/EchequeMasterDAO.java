/**
 * @(#) EchequeMasterDAO.java
 */

package com.sbi.common.etdr.dao;

import wac.audit.FieldCollection;

import com.sbi.common.exception.DAOException;


public interface EchequeMasterDAO
{

	int updateEcheque(FieldCollection fieldCollection , String echequeNumber)throws DAOException;
	
}