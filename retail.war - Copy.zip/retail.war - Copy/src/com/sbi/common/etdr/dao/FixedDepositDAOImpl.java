package com.sbi.common.etdr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.etdr.model.FDProductCodeModel;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

public class FixedDepositDAOImpl extends JdbcDaoSupport implements FixedDepositDAO  {
	protected final Logger logger = Logger.getLogger(getClass());
	
	private static final String GET_FD_SEQ_NO ="SELECT 'CF'||LPAD(fd_seqno.NEXTVAL,8,0) FROM DUAL";
	private static final String GET_CFD_SEQ_NO ="SELECT 'CFD'||LPAD(cfd_seqno.NEXTVAL,7,0) FROM DUAL";
	
	private static final String GET_INT_CAT_DIGITS_ASSOCIATE = "select substr(sub_cat,2,2) From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? and FD_RATE_TYPE='fixedrate' and ? between min_bal and max_bal and (substr(product_type,0,2)=25 or (substr(product_type,0,2)=20 and nvl(product_description,' ') not like '%AGIF/AFGIS/NGIF%'))" ;//bank code added for associate bank by viswa
	
	private static final String GET_INT_CAT_DIGITS = "select substr(sub_cat,2,3) From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? and FD_RATE_TYPE=? and ? between min_bal and max_bal and (substr(product_type,0,2)=25 or (substr(product_type,0,2)=20 and nvl(product_description,' ') not like '%AGIF/AFGIS/NGIF%'))" ;
													 
	private static final String GET_SEGMENT_CODE = "select segment_code  From SBI_FD_SEGMENT_CODE_MAP where account_type = ? and  sub_type = ?  and ? between min_term and max_term";
	
	private static final String INSERT_FD_ACCOUNT_DETAILS = " INSERT INTO SBICORP_FD_ACCOUNT_MAP (FD_ACCOUNT_NO,FD_BRANCH_CODE,DEBIT_ACCOUNT_NO,DEBIT_BRANCH_CODE,FD_ACCOUNT_NATURE,FD_TYPE, "+
	" INTEREST_PAYOUT,TENURE,FD_AMOUNT,USER_NAME,SOC_CODE, "+
	" STATUS,CREATION_TIME,LAST_MOD_TIME,PRIMARY_CIF_NO,TENURE_DAY,TENURE_MONTH,TENURE_YEAR,FD_PRODUCT_CODE,FD_RATE_TYPE,AUTO_RENEW_TYPE,SENIOR_CITIZEN,CHANNEL_TYPE,SBH_DOUBLE,TENURE_MATURITY_DATE,REFERENCE_NO,AUTH_OPTION,CORPORATE_ID,AUTH_TYPE,CURRENT_AUTH_LEVEL,AUTH_STATUS,MATURITY_DATE,MATURITY_VALUE,INTEREST_RATE,AUTO_RENEW_INTEREST_PAYOUT, AUTO_RENEW_TENURE,AUTO_RENEW_TENURE_DAY,AUTO_RENEW_TENURE_MONTH, AUTO_RENEW_TENURE_YEAR,DEBIT_ACCOUNT_HOLDER_NAME,TYPE_OF_MODULE) "+
	" VALUES (?,?,?,?,?,?,?,?,?,?,?,'Pending',sysdate,sysdate,?,?,?,?,?,?,?,?,?,?,TO_DATE(?,'dd/mm/yyyy'),?,'1',?,'0','1','Pending',?,?,?,?,?,?,?,?,?,?)";
	
	private static final String UPDATE_FD_ACCOUNT_DETAILS = "UPDATE SBICORP_FD_ACCOUNT_MAP SET FD_ACCOUNT_NO=?,FD_BRANCH_CODE=?,SOC_CODE=?,FD_REFERENCE_NO=?,DEPOSIT_OPEN_DATE=sysdate,"+
		" #tobereplaced# LAST_MOD_TIME=sysdate WHERE REFERENCE_NO=?";
	
	private static final String GET_PRODUCT_DESC ="select product_description from SBI_FD_PRODUCT_CODE_MAP where product_type || sub_cat = ? and  bank_code=? and FD_RATE_TYPE=?" ;//bank code added for associate bank by viswa
	private static final String GET_PRODUCT_DESC_ASSOCIATE ="select product_description from SBI_FD_PRODUCT_CODE_MAP where product_type || sub_cat = ? and  bank_code=? and FD_RATE_TYPE='fixedrate' " ;//bank code added for associate bank by viswa
			
	private static final String SBI_CUSTOMER_ACCOUNT_MAP = "INSERT INTO sbi_customer_account_map (OID,USER_NAME,STORE_ID,CREATION_TIME,STATUS,DELETED,LAST_MOD_TIME,ACCOUNT_NO,BRANCH_CODE,OLD_USERNAME," +
	" ACCOUNT_NICKNAME,TRANSACTION_LIMIT,NAME_THIRD_PARTY,ACCOUNT_NATURE,ACCESS_LEVEL,VERIFY_FLAG,LOCK_FLAG,CORPORATE_ID,BRANCH_NAME,ACCOUNT_DESCRIPTION,PROCESSED,VERIFY_REQUEST_DATE, " +
	" PRODUCT_CODE,PRODUCT_TYPE,PRODUCT_DESC,CORE_MESSAGE_STATUS,CUSTOMER_ACCESS_LEVEL,BRANCH_ACCESS_LEVEL) " +
	" VALUES (oid_sequence.NEXTVAL,?,101,sysdate,1,0,sysdate,?,?,?,'','0','',0,5,?,1,?,'','',1,'',?,'A5',?,'','',5)";
	
	
	private static final String CHK_DEBIT_PRODUCT_CODE_EXISTS = " SELECT count(*) FROM SBI_FD_PRODUCT_CODE_MASTER WHERE DEBIT_PRODUCT_CODE = ? AND BANK_CODE= ? AND TYPE_OF_MODULE_NAME='CORPORATE' and segment_code=?";
	private static final String GET_PRODUCT_CODE_DETAILS = "SELECT DEBIT_PRODUCT_CODE,DEBIT_PRODUCT_TYPE_1_2,DEBIT_PRODUCT_TYPE_3_4,DEBIT_SUBCAT_5,DEBIT_SUBCAT_6_7,DEBIT_SUBCAT_8,PRODUCT_DESC,CUSTOMER_TYPE,CUSTOMER_CATEGORY,SEGMENT_CODE,BANK_CODE FROM SBI_FD_PRODUCT_CODE_MASTER WHERE DEBIT_PRODUCT_CODE = ? AND BANK_CODE= ? AND TYPE_OF_MODULE_NAME='CORPORATE' and segment_code=?";
	
	private static final String GET_FD_AMOUNT_DETAILS_ASSOCIATE="select min_bal, max_bal From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? and FD_RATE_TYPE='fixedrate' and ? between min_bal and max_bal ";//bank code added for associate bank by viswa
	private static final String GET_FD_TENURE_DETAILS_ASSOCIATE="select min(MIN_TERM) MIN_TERM ,MAX(MAX_TERM) MAX_TERM From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and bank_code=? and FD_RATE_TYPE='fixedrate' and ? between min_bal and max_bal";//bank code added for associate bank by viswa
	
//	private static final String GET_FD_AMOUNT_DETAILS="select min_bal, max_bal From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? AND FD_RATE_TYPE=? and ? between min_bal and max_bal ";
	//private static final String GET_FD_TENURE_DETAILS="select min(MIN_TERM) MIN_TERM ,MAX(MAX_TERM) MAX_TERM From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and bank_code=? AND FD_RATE_TYPE=? and ? between min_bal and max_bal ";
	
	private static final String GET_FD_AMOUNT_DETAILS="select min_bal, max_bal From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? AND FD_RATE_TYPE=?  and ? between min_bal and max_bal ";
	private static final String GET_FD_TENURE_DETAILS="select min(MIN_TERM) MIN_TERM ,MAX(MAX_TERM) MAX_TERM From SBI_FD_PRODUCT_CODE_MAP where product_type || substr(sub_cat,1,1) = ? and bank_code=? AND FD_RATE_TYPE=?  and ? between min_bal and max_bal  ";


	private static final String UPDATE_FD_CLOSE_CUST_TABLE="UPDATE SBI_CUSTOMER_ACCOUNT_MAP SET STATUS=0,LAST_MOD_TIME=SYSDATE WHERE ACCOUNT_NO=?";
	private static final String UPDATE_PRE_CLOSURE_STATUS ="UPDATE SBICORP_FD_ACCOUNT_MAP SET STATUS=?,CLOSED_DATE=TO_DATE(?,'dd/mm/yyyy hh:mi:ss'), LAST_MOD_TIME=SYSDATE WHERE FD_ACCOUNT_NO=?";
	private static final String GET_FD_DETAILS ="SELECT FD_ACCOUNT_NO,FD_BRANCH_CODE, DEBIT_ACCOUNT_NO, DEBIT_BRANCH_CODE,FD_AMOUNT,FD_REFERENCE_NO,FD_TYPE FROM SBICORP_FD_ACCOUNT_MAP "+ 
	"WHERE FD_ACCOUNT_NO=? AND STATUS='active'"; 
	
	
	private static final String GET_FD_ACC_NATURE = "select fd_account_nature From SBICORP_FD_ACCOUNT_MAP where fd_account_no=? and status='0'";
	
	private static final String UPDATE_MATURITY_DETAILS="UPDATE sbicorp_fd_account_map SET maturity_date = TO_DATE (?, 'dd/mm/yyyy'), interest_rate = ?,maturity_value=?,fd_account_nature=? WHERE fd_account_no = ?";
	
	private static final String GET_ECHEQUENO_FDTYPE="SELECT fd_type, echeque_no FROM sbicorp_fd_account_map f, sbicorp_echeque_master_view e WHERE fd_account_no = corp_ref_no AND e.corp_ref_no = ? and rownum=1";//corp_ref_no is fdaccountno.ie creditaccountno

	private static final String GET_FD_ACCOUNT_DETAILS = "SELECT * FROM SBICORP_FD_ACCOUNT_MAP WHERE FD_ACCOUNT_NO=?"; 
	
	private static final String GET_FD_TENURE_IN_DAYS = "SELECT TENURE FROM SBICORP_FD_ACCOUNT_MAP WHERE FD_ACCOUNT_NO=? ";
	
	private static final String UPDATE_AUTORENEW_INFO = "update sbicorp_fd_account_map set AUTO_RENEW_TENURE=?, AUTO_RENEW_TENURE_DAY=?, AUTO_RENEW_TENURE_MONTH=?, AUTO_RENEW_TENURE_YEAR=?,fd_type=?, AUTO_RENEW_INTEREST_PAYOUT=?, LAST_MOD_TIME=SYSDATE where fd_reference_no=?";
	
	private static final String GET_SBH_DOUBLE_INT_CAT_DIGITS = "select substr(sub_cat,2,2) From SBI_FD_SPECIAL_PRODUCT where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? and FD_RATE_TYPE='fixedrate'  and ? between min_bal and max_bal and (substr(product_type,0,2)=25 or (substr(product_type,0,2)=20 and nvl(product_description,' ') not like '%AGIF/AFGIS/NGIF%')) " ;
	private static final String GET_SBH_DOUBLE_PRODUCT_DESC = "select product_description from SBI_FD_SPECIAL_PRODUCT where product_type || sub_cat = ? and  bank_code=? and FD_RATE_TYPE='fixedrate' " ;
	private static final String GET_SBH_DOUBLE_FD_AMOUNT_DETAILS = "select min_bal, max_bal From SBI_FD_SPECIAL_PRODUCT where product_type || substr(sub_cat,1,1) = ? and ? between min_term and max_term and bank_code=? and FD_RATE_TYPE='fixedrate' ";
	private static final String GET_SBH_DOUBLE_FD_TENURE_DETAILS = "select min(MIN_TERM) MIN_TERM ,MAX(MAX_TERM) MAX_TERM From SBI_FD_SPECIAL_PRODUCT where product_type || substr(sub_cat,1,1) = ? and bank_code=? and FD_RATE_TYPE='fixedrate' ";
	
	private static final String GET_AUTH_OPTION ="SELECT distinct b.auth_option FROM SBICORP_RULE_DETAILS a,SBICORP_RULE_MASTER b WHERE a.user_name = ? "+
		" and a.status=1 and b.rule_id=a.rule_id and b.account_no =? and b.branch_code=? "+
		" and ? BETWEEN b.from_limit AND b.to_limit and b.limit_status = 1 and b.status=1 and b.auth_option is not null order by b.auth_option asc";

	private static final String UPDATE_FD_ACC_STATUS = "update sbicorp_fd_account_map set fd_reference_no=?,current_auth_level=0, auth_status='success', status='active',last_mod_time=sysdate where reference_no=?";
	
	private static final String UPDATE_ECHEQUE_AUTH_DETAILS ="update SBICORP_ECHEQUE_MASTER set auth1_name=?,auth2_name=?, last_mod_time=sysdate where echeque_no=?";
		
	private static final String GET_FIXED_DEPOSIT_STATUS = "select  reference_no,creation_time,debit_account_no,interest_rate,tenure,tenure_day,tenure_month,tenure_year,maturity_date,"+
  
		"fd_amount,maturity_value,auth_status,auth1_name,auth2_name,fd_account_no,tenure_maturity_date from sbicorp_fd_account_map  where user_name=? and debit_branch_code=? and debit_account_no=? and nvl(status,' ')!='Delete' order by creation_time desc";
	
	private static final String GET_FIXED_DEPOSIT_ACCOUNT_DTLS = "select  reference_no,creation_time,debit_account_no,interest_rate,tenure,tenure_day,tenure_month,tenure_year,maturity_date,"+
		"fd_amount,maturity_value,auth_status,auth1_name,auth2_name,fd_account_no,tenure_maturity_date from sbicorp_fd_account_map  where corporate_id=? and debit_account_no=? and fd_account_no is not null and nvl(preclosure_status,' ')!='closed' and fd_reference_no is not null and nvl(status,' ')!='Delete' order by fd_account_no desc";
	
	private TransactionTemplate transactionTemplate;
	
	public String getFdReferenceNo() {
		// TODO Auto-generated method stub
		String refNo = null;
		logger.debug("getFdReferenceNo - method begin.");
		try{
			refNo = (String) getJdbcTemplate().queryForObject(GET_FD_SEQ_NO, String.class);
		}
		catch (DataAccessException ex) {
			
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.debug("getFdReferenceNo - method end.");
		return refNo;
	}
	public String getReferenceNo() {
		// TODO Auto-generated method stub
		String refNo = null;
		logger.debug("getReferenceNo - method begin.");
		try{
			refNo = (String) getJdbcTemplate().queryForObject(GET_CFD_SEQ_NO, String.class);
		}
		catch (DataAccessException ex) {
			
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.debug("getReferenceNo - method end.");
		return refNo;
	}
	
	public String findIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) {	//bank code added for associate bank by viswa
		logger.info("findIntCategory - method begin.");
		Object[] param ={ subCat,tenure,bankCode ,fdRate,fdAmount};//bank code added for associate bank by viswa
		String digits = "";
		try{
			logger.info("tenure is"+tenure);
			logger.info("subcat is"+subCat);
			logger.info("bank code is"+ bankCode);
			logger.info("fdrate is"+fdRate);
			logger.info("fdamount is"+fdAmount);
			logger.info("params are"+param);
			digits = (String) getJdbcTemplate().queryForObject(GET_INT_CAT_DIGITS, param, String.class);
			logger.info("findIntCategory:::"+digits);
		}
		catch (DataAccessException ex) {
			logger.error("DAO Exception : " ,ex); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findIntCategory - method end.");
		return digits;
	}
	
	
	public String findIntCategoryForAssociate(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) {

		logger.info("findIntCategoryForAssociate(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) - method begin.");
		Object[] param ={subCat,tenure,bankCode,fdAmount};
		String digits = "";
		try{
			logger.info("tenure is"+tenure);
			logger.info("subcat is"+subCat);
			logger.info("bank code is"+ bankCode);
			logger.info("fdrate is"+fdRate);
			logger.info("fdamount is"+fdAmount);
			logger.info("params are"+param);
			digits = (String) getJdbcTemplate().queryForObject(GET_INT_CAT_DIGITS_ASSOCIATE, param, String.class);
			logger.info("findIntCategory:::"+digits);
		}
		catch (DataAccessException ex) {
			logger.error("DAO Execption : " ,ex); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.debug("findIntCategoryForAssociate(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) - method end.");
		return digits;
	}
	
	
	public String fdSegmentCodeFinder(String accountType , String subType ,int tenure){
		logger.info("fdSegmentCodeFinder(String interestPayout)method begins ");
		Object[] param = { accountType , subType , tenure};
		String segmentCode = "";
		try{
			segmentCode = (String) getJdbcTemplate().queryForObject(GET_SEGMENT_CODE, param, String.class);
		}
		catch (DataAccessException ex ) {
			logger.error("DAO Execption : " ,ex); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.debug("fdSegmentCodeFinder(String interestPayout) method ends ");
		return segmentCode;	
	}
	
	//Added by Siva for ETDR starts here
	
	public Map getFdAmountDetails(String productCode,int totalNoOfDays,String bankCode,String fdRate,String fdAmount) throws DAOException//bank code added for associate bank by viswa
	{
		logger.info("Inside getFdAmountDetails(...) Starts Here");
		Map outParams=new HashMap();
		List paramDetailList = null;
		List tenureDetailList = null;
		logger.info("productCode="+productCode+"  totalNoOfDays = "+totalNoOfDays+"  bankCode -->"+bankCode+" fdRate :"+fdRate+" Fd Amount -->"+fdAmount);
		//Object params [] = new Object[] {productCode,totalNoOfDays,bankCode,fdRate,fdAmount};//bank code added for associate bank by viswa
		//Object dayparams [] = new Object[] {productCode,bankCode,fdRate,fdAmount};
		
		Object params [] = new Object[] {productCode,totalNoOfDays,bankCode,fdRate,fdAmount};//bank code added for associate bank by viswa
		Object dayparams [] = new Object[] {productCode,bankCode,fdRate,fdAmount};
		try
		{
			paramDetailList = (List) getJdbcTemplate().query(GET_FD_AMOUNT_DETAILS, params, new FixedDepositRowMapper());
			
			if( paramDetailList==null || (paramDetailList != null && paramDetailList.size()==0)){
				tenureDetailList = (List) getJdbcTemplate().query(GET_FD_TENURE_DETAILS, dayparams, new FixedDepositTenureRowMapper());
			}
			
			outParams.put("amountList", paramDetailList);
			outParams.put("tenureList", tenureDetailList);
		}
		catch(DataAccessException dae)
		{
			logger.error("DAO Execption : " ,dae); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("Inside getFdAmountDetails(...) Ends Here");
		return outParams;
	}
	
	public Map getFdAmountDetailsForAssociate(String productCode,int totalNoOfDays,String bankCode,String fdRate,String fdAmount) throws DAOException//bank code added for associate bank by viswa
	{
		logger.info("getFdAmountDetailsForAssociate(String productCode,int totalNoOfDays,String bankCode,String fdRate,String fdAmount) - method begin");
		Map outParams=new HashMap();
		List paramDetailList = null;
		List tenureDetailList = null;
		logger.info("productCode="+productCode+"  totalNoOfDays = "+totalNoOfDays);
		Object params [] = new Object[] {productCode,totalNoOfDays,bankCode,fdAmount};
		Object dayparams [] = new Object[] {productCode,bankCode,fdAmount};
		try
		{
			paramDetailList = (List) getJdbcTemplate().query(GET_FD_AMOUNT_DETAILS_ASSOCIATE, params, new FixedDepositRowMapper());
			logger.info("ParamDetailList ->"+paramDetailList);
			if( paramDetailList==null || (paramDetailList != null && paramDetailList.size()==0)){
				tenureDetailList = (List) getJdbcTemplate().query(GET_FD_TENURE_DETAILS_ASSOCIATE, dayparams, new FixedDepositTenureRowMapper());
			}
			logger.info("ParamDetailList ->"+paramDetailList);
			logger.info("tenureDetailList ->"+tenureDetailList);
			outParams.put("amountList", paramDetailList);
			outParams.put("tenureList", tenureDetailList);
		}
		catch(DataAccessException dae)
		{
			logger.error("DAO Execption : " ,dae); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getFdAmountDetailsForAssociate(String productCode,int totalNoOfDays,String bankCode,String fdRate,String fdAmount) - method end");
		return outParams;
	}
	class FixedDepositRowMapper implements ResultSetExtractor {
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			
			ArrayList amountList=null;
			FixedDepositModel fixedDepositModel = null;
			while(rs.next()){
				amountList=new ArrayList();
				fixedDepositModel = new FixedDepositModel();
				fixedDepositModel.setFdMinAmount(new Double(rs.getDouble("MIN_BAL")));
				logger.info("MIN AMT:::"+fixedDepositModel.getFdMinAmount());
				fixedDepositModel.setFdMaxAmount(new Double(rs.getDouble("MAX_BAL")));
				logger.info("MAX AMT:::"+fixedDepositModel.getFdMaxAmount());
				amountList.add(fixedDepositModel);
			}
			return amountList;
		}
	}
	
	
	class FixedDepositTenureRowMapper implements ResultSetExtractor {
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			logger.info("inside FixedDepositTenureRowMapper");
			ArrayList tenureList=null;
			FixedDepositModel fixedDepositModel = null;
			while(rs.next()){
				
				fixedDepositModel = new FixedDepositModel();
				String minStr = rs.getString("MIN_TERM");
				String maxStr = rs.getString("MAX_TERM");
				logger.info("min term ::"+ minStr+"MAX Term:::"+maxStr);
				
				if(( minStr!=null && !minStr.trim().equals("")) && 
						( maxStr!=null && !maxStr.trim().equals("")) )
				{	
					tenureList=new ArrayList();
					fixedDepositModel.setMinTenureDays(new Integer(minStr));
					fixedDepositModel.setMaxTenureDays(new Integer(maxStr));
					logger.info("min term ::"+ fixedDepositModel.getMinTenureDays()+"MAX Term:::"+fixedDepositModel.getMaxTenureDays());
					tenureList.add(fixedDepositModel);
				}
			}
			return tenureList;
		}
	}
	
	
	
	public List getFixedDepositDetails(String fdAccNo) {
		
		logger.info(" getFixedDepositDetails(String fdAccNo)-- Begin");
		List fdList = new ArrayList();
		Object[] params;
		try
		{
			logger.info("Fixed Deposit Account to be closed :: "+fdAccNo);
			params = new Object[] {fdAccNo};
			fdList = (List)getJdbcTemplate().queryForList(GET_FD_DETAILS,params);
			logger.info("Here in DAO List is "+fdList);
		}
		catch (DataAccessException ex)
		{
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info(" getFixedDepositDetails(String fdAccNo) ends");
		return fdList;
	}
	
	public void closeFixedDepositAccount(Map p_fdClosureMap){
		
		if(logger.isDebugEnabled())
			logger.debug("createAddIBCommissionRequest() Begins");
		final Map  fdClosureMap = p_fdClosureMap;
		
		transactionTemplate.execute(new TransactionCallback(){
			public Object doInTransaction(TransactionStatus transactionStatus){
				try{
					int updaqtedRow = 0;
					updatePreClosureStatus(fdClosureMap);
					Object[] params = new Object[] {fdClosureMap.get("fdAccountNo")};
					if( ((String)fdClosureMap.get("status")).equalsIgnoreCase("F1"))
						updaqtedRow = getJdbcTemplate().update(UPDATE_FD_CLOSE_CUST_TABLE,params);
					
				}catch(DAOException e){
					transactionStatus.setRollbackOnly();
					logger.info("Transaction Roll Backed.");
				}
				catch(DataAccessException e){
					transactionStatus.setRollbackOnly();
					logger.info("Transaction Roll Backed.");
				}
				return null;
			}
		}
		);
		
		if(logger.isDebugEnabled())
			logger.debug("createAddIBCommissionRequest() Begins Ends");
	}
	
	private void updatePreClosureStatus(Map fdClosureMap) {
		
		Object[] params;
		try {
			params = new Object[] {fdClosureMap.get("status"),fdClosureMap.get("date"),fdClosureMap.get("fdAccountNo")};
			getJdbcTemplate().update(UPDATE_PRE_CLOSURE_STATUS,params);
			
		}catch (DataAccessException ex)
		{
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		
	}
	
	
//	Added by Megavannan for getting Accunt Nature creation	
	public List findFDAccountNature(String accountNumber){
		logger.debug("findFDAccountNature - " + LoggingConstants.METHODBEGIN); 
		List fdAccNatureList = null;
		try {               
			Object[] params = {accountNumber};
			fdAccNatureList = getJdbcTemplate().queryForList(GET_FD_ACC_NATURE,params);
			
			logger.info("fdAccNatureList :" + fdAccNatureList);
			logger.info("fdAccNatureList size is " + fdAccNatureList.size());                    
			
			return fdAccNatureList;                
		}
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  
		logger.debug("findFDAccountNature - " + LoggingConstants.METHODEND);
		return null;
	}	
	
	
	
	public int insertFdAccountDetails(FixedDepositModel fixedDepositModel) {
		logger.debug("insertFdAccountDetails - method begin.");
	  
		int totalTenure = 0;
		if(fixedDepositModel.isDtMonYr())
			totalTenure=0;
		else
			totalTenure = fixedDepositModel.getTenureInDays();
		
		int totalAutoRenewTenure = 0;
		if(fixedDepositModel.isAutoRenewDtMonYr()) {
			totalAutoRenewTenure=0;
		}else {
			totalAutoRenewTenure = fixedDepositModel.getAutoRenewTenureInDays();
		}
		int count = 0 ;
		
		String bankCode = fixedDepositModel.getDebitBranchCode().substring(0,1);
		logger.info("bankcode:::"+bankCode);
		String fdRateType="";
		//by uday
		//String panNumber=" ";
		//FD_REFERENCE_NO,SCHEDULED,PRIMARY_CIF_NO,TENURE_DAY,TENURE_MONTH,TENURE_YEAR
		if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode)  || "7".equals(bankCode)){
			fdRateType="fixedrate";
			//panNumber=" ";
		 }else {
			 fdRateType=fixedDepositModel.getTypeOfInterestRate();
			 //panNumber = fixedDepositModel.getPanNo().trim();
		 }
		String tenureMaturityDate = null;
		if(fixedDepositModel.getSelectedMaturityDate() ==null || fixedDepositModel.getSelectedMaturityDate().trim().length()<=0){
			tenureMaturityDate = null;
		}else if(fixedDepositModel.getSelectedMaturityDate() !=null && fixedDepositModel.getSelectedMaturityDate().trim().length()>0){
			tenureMaturityDate = fixedDepositModel.getSelectedMaturityDate().trim();
		}
		Timestamp maturityDate=null;
		if(fixedDepositModel.getMaturityDate()!=null)
			maturityDate=StringUtils.coreDateToTimestamp(fixedDepositModel.getMaturityDate());
		logger.info("fixedDepositModel.getMaturityAmount---->"+fixedDepositModel.getMaturityAmount());
		
		Double maturityValue=null;
		if(fixedDepositModel.getMaturityAmount()!=null && !"".equals(fixedDepositModel.getMaturityAmount()))
			maturityValue=new Double(fixedDepositModel.getMaturityAmount());
		
		String interestRate=null;
		if(fixedDepositModel.getInterestRate()!=null)
			interestRate=fixedDepositModel.getInterestRate().toString();
			
		Object[] param ={fixedDepositModel.getFdAccountNo(),fixedDepositModel.getFdBranchCode(),fixedDepositModel.getDebitAccountNo()
				 ,fixedDepositModel.getDebitBranchCode(),fixedDepositModel.getFdAccNature(),fixedDepositModel.getFdType(),fixedDepositModel.getInterestPayout()
				 ,totalTenure,((Double)fixedDepositModel.getFdAmount()).toString(),fixedDepositModel.getUserName(),fixedDepositModel.getSocCode()
				 ,fixedDepositModel.getCustomerNo(),fixedDepositModel.getDays()
				 ,fixedDepositModel.getMonths(),fixedDepositModel.getYears(),fixedDepositModel.getFdAccProductCode(),
				 fdRateType,fixedDepositModel.getAutoRenewDescription(),fixedDepositModel.getIsSeniorCitizen(),fixedDepositModel.getChannelType()
				,fixedDepositModel.getIsSbhDouble(),tenureMaturityDate,fixedDepositModel.getReferenceNo(),fixedDepositModel.getCorporateId()
				,maturityDate,maturityValue,interestRate
				,fixedDepositModel.getAutoRenewInterestPayout(),totalAutoRenewTenure
				,fixedDepositModel.getAutoRenewDays(),fixedDepositModel.getAutoRenewMonths(),fixedDepositModel.getAutoRenewYears(),fixedDepositModel.getDebitHolderName(),fixedDepositModel.getTypeOfModule()};

		int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
			       		 ,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
			    		 ,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
			    		 ,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC
			    		 ,Types.DATE,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR
			    		 ,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR};
                
		for(int i=0;i<param.length;i++)
			logger.info("param ::"+param[i]+" type ::"+sqlTypes[i]);
		
		try{
			count =  getJdbcTemplate().update(INSERT_FD_ACCOUNT_DETAILS, param,sqlTypes);
			if(count==0 )
			{
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		catch (DataAccessException ex) {
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		logger.debug("insertFdAccountDetails - method begin.");  
		// TODO Auto-generated method stub
		return count;
	}
	public int updateFdAccountDetails(FixedDepositModel fixedDepositModel) {
		logger.info("updateFdAccountDetails - method begin.");
		
		int count = 0 ;
		String currAuthNameVal="";
		String currAuthType="";
		if(fixedDepositModel.getAuth2Name()!=null && !"".equals(fixedDepositModel.getAuth2Name())){
			currAuthNameVal=fixedDepositModel.getAuth2Name();
			currAuthType="auth2_name=?,";
		}
		else{
			currAuthNameVal=fixedDepositModel.getAuth1Name();
			currAuthType="auth1_name=?,";
		}
		
		Object[] param ={fixedDepositModel.getFdAccountNo(),fixedDepositModel.getFdBranchCode(),fixedDepositModel.getSocCode(),
						 fixedDepositModel.getFdReferenceNo(),currAuthNameVal,
						 fixedDepositModel.getReferenceNo()};

		int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                
		try{
			String query =  UPDATE_FD_ACCOUNT_DETAILS.replaceAll("#tobereplaced#", currAuthType);
			count =  getJdbcTemplate().update(query, param,sqlTypes);
			logger.info("Update count----->"+count);
			if(count==0 )
			{
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		catch (DataAccessException ex) {
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		logger.debug("updateFdAccountDetails - method begin.");  
		// TODO Auto-generated method stub
		return count;
	}
	
	public String getProductDesc(String productCode,String bankCode,String fdRate) //bank code added for associate bank by viswa
	// TODO Auto-generated method stub
	{
		logger.info("getproductDesc for the product code:: " + productCode+" "+"Fixed/Float Type ::"+fdRate); 
		String productDesc = "";
		try {               
			Object[] params = {productCode,bankCode,fdRate};//bank code added for associate bank by viswa
			productDesc = (String) getJdbcTemplate().queryForObject(GET_PRODUCT_DESC,params, String.class);
			logger.info("productDescList :" + productDesc);
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			logger.error(""+ex);
		}  
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  
		
		logger.debug("getproductDesc - " + LoggingConstants.METHODEND);
		return productDesc;
	}
	
/*	public String geteTDRProductDesc(String productCode) throws DAOException

	{
		logger.info("geteTDRProductDesc for the product code:: " + productCode); 
		String productDesc = "";
		try {               
			Object[] params = {productCode};
			productDesc = (String) getJdbcTemplate().queryForObject(GET_FD_PRODUCT_DESC,params, String.class);
			logger.info("geteTDRProductDesc :" + productDesc);
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			logger.error(""+ex);
		}  
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  
		
		logger.debug("geteTDRProductDesc - " + LoggingConstants.METHODEND);
		return productDesc;
	}
*/	
	public void  customerAccountMapDetails(Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		int count = 0 ;
		logger.info("Param Map "+paramMap);
		String userName = (String) paramMap.get("userName") ;
		String creditAccNo =  (String) paramMap.get("creditAccNo") ;
		String crBranchCode =  (String) paramMap.get("crBranchCode") ;
		String productCode =   (String) paramMap.get("productCode");
		String productDesc =  (String) paramMap.get("productDesc") ;
		String verifyFlag =  (String) paramMap.get("verifyFlag") ;
		String corporateId =  (String) paramMap.get("corporateId") ;
		
		Object[] param ={userName,creditAccNo,crBranchCode,userName,verifyFlag,corporateId,productCode,productDesc};
		try{
			count =  getJdbcTemplate().update(SBI_CUSTOMER_ACCOUNT_MAP, param);
			if(count == 0)
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);	
		}
		catch (DataAccessException ex) {
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		// TODO Auto-generated method stub
	}
	
	
	/*code inserted by sneh for etdr*/ 
	public void updateMaturityDetails(Map maturityDetails) {
		logger.info("update begins maturityDetails:-"+maturityDetails);
		Object[] params;
		try {
			params = new Object[] {maturityDetails.get(DAOConstants.MATURITY_DATE),maturityDetails.get(DAOConstants.INTEREST_RATE),maturityDetails.get(DAOConstants.MATURITY_AMT),maturityDetails.get("fdAccNature"),maturityDetails.get("fdAccountNo")};
			int updatedRecords = getJdbcTemplate().update(UPDATE_MATURITY_DETAILS,params);
			logger.info("Updated Records : " + updatedRecords);
			if(updatedRecords == 0)
			{
				DAOException.throwException("FD003");
			}
			
		}catch (DataAccessException ex)
		{
			logger.error(ex,ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
	}
	
	public Map getINBRefNoFDType(String fdAccountNo){
		logger.info("getINBRefNo(String fdAccountNo="+fdAccountNo+" )method ends ");
		Object[] param = {fdAccountNo};
		Map details=null;
		try{
			details = (Map) getJdbcTemplate().queryForMap(GET_ECHEQUENO_FDTYPE, param);
			logger.info("getINBRefNoFDType ::"+details);
			logger.info("details :"+details.get("FD_TYPE")+","+details.get("ECHEQUE_NO"));
		}
		catch (DataAccessException daoex){
			logger.error("DAO Exception : Failed to fetch INBRefNo from echeque_master / FDType from sbicorp_fd_account_map fdaccountNo="+ fdAccountNo,daoex); 
			DAOException.throwException("FD003",daoex);
			
		}
		logger.debug("getINBRefNo(String fdAccountNo) method ends ");
		return details;	
	}
	
	
	public Map getFdAccountDetailsForChallan(String fdAccountNo) 
	// TODO Auto-generated method stub
	{
		logger.info("fdAccountNo :: " + fdAccountNo); 
		Map fdDetailMap = null;
		try {               
			Object[] params = {fdAccountNo};
			 fdDetailMap = (Map) getJdbcTemplate().queryForMap(GET_FD_ACCOUNT_DETAILS,params);
			logger.info("fdDetailMap :" + fdDetailMap);
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			logger.error("fdDetailMap ::"+ex);
		}  
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  
		
		logger.debug("getDebitAccount - " + LoggingConstants.METHODEND);
		return fdDetailMap;
	}
	
	
	public Integer getTenureInDays(String fdAccountNo) throws DAOException{
		
		logger.info("fdAccountNo :: " + fdAccountNo); 
		String strTenure = "";
		Integer tenureInDays = new Integer(0);
		try {               
			Object[] params = {fdAccountNo};
			strTenure = (String) getJdbcTemplate().queryForObject(GET_FD_TENURE_IN_DAYS,params, String.class);
			
			if(strTenure!=null)
				tenureInDays = new Integer(strTenure);
			
			logger.info("tenureInDays :" + tenureInDays);
		
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			logger.error(""+ex);
		}  
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  
		
		logger.debug("getTenureInDays - " + LoggingConstants.METHODEND);
		return tenureInDays;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	
/*Added by Srinivas for Floating Rate CR only to SBI and other banks to disable*/
	public String getProductDescAssociateBanks(String productCode,String bankCode) //bank code added for associate bank by viswa
	{
		logger.info("getProductDescAssociateBanks for the product code:: " + productCode+" "+"Bankcode :::"+bankCode); 
		String productDesc = "";
		try {               
			Object[] params = {productCode,bankCode};//bank code added for associate bank by viswa
			productDesc = (String) getJdbcTemplate().queryForObject(GET_PRODUCT_DESC_ASSOCIATE,params, String.class);
			logger.info("productDescList For Associate Banks :" + productDesc);
		}
		catch (IncorrectResultSizeDataAccessException ex) {
			logger.error(""+ex);
		}  
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}  

		logger.debug("getProductDescAssociateBanks - " + LoggingConstants.METHODEND);
		return productDesc;
	}
	
	/**
	 * Update Auto Renew Details under sbicorp_fd_account_map table for maturity Mandates Instructions CR.
	 */
	public void updateAutoRenewalInfo(FixedDepositModel fixedDepositModel){
		logger.info("updateAutoRenewalInfo(..) Starts Here");

		int totalAutoRenewTenure = 0;
		try {
			if (fixedDepositModel != null) {

				if(fixedDepositModel.isAutoRenewDtMonYr()) {
					totalAutoRenewTenure=0;
				}else {
					totalAutoRenewTenure = fixedDepositModel.getAutoRenewTenureInDays();
				}
				
				logger.info("Auto Renew Tenure in Days (int) -->"+totalAutoRenewTenure);
				logger.info("FD Reference No -->"+ fixedDepositModel.getFdReferenceNo());
				logger.info("Auto Renew Days -->" + fixedDepositModel.getAutoRenewDays());
				logger.info("Auto Renew Months -->" + fixedDepositModel.getAutoRenewMonths());
				logger.info("Auto Renew Years -->" + fixedDepositModel.getAutoRenewYears());
				logger.info("Auto Renew FD Type -->"+ fixedDepositModel.getFdType());
				logger.info("Auto Renew Interest Payout -->"+ fixedDepositModel.getAutoRenewInterestPayout());
				logger.info("Auto Renew Tenure in Days (model)-->"+fixedDepositModel.getAutoRenewTenureInDays());
				
				final int sqlTypes[] = { 
						Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,
						Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
				};
				final Object[] params = new Object[] {
						totalAutoRenewTenure,
						fixedDepositModel.getAutoRenewDays(),
						fixedDepositModel.getAutoRenewMonths(),
						fixedDepositModel.getAutoRenewYears(),
						fixedDepositModel.getFdType(),
						fixedDepositModel.getAutoRenewInterestPayout(),						
						fixedDepositModel.getFdReferenceNo()
						
				};
				int rowsUpdated = getJdbcTemplate().update(UPDATE_AUTORENEW_INFO, params, sqlTypes);
				logger.info("No. of Rows Updated in sbicorp_fd_account_map (Maturity Instruction Details) -->"+ rowsUpdated);
			}
		} catch (DAOException exp) {
			logger.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);

		} catch (DataAccessException e) {
			logger.error("ERROR: Unable to Update fd_account_map:: "+ e.getMessage(), e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("updateAutoRenewalInfo(..) Ends Here");
	}
	
	/* DEV - 262 Implementation for SBH Double Starts Here */
	public String getSBHDoubleIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) {
		logger.info("getSBHDoubleIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) - method begin.");
		String digits = "";
		try{			
			final Object[] param = new Object[] { subCat,tenure,bankCode,fdAmount };
			digits = (String) getJdbcTemplate().queryForObject(GET_SBH_DOUBLE_INT_CAT_DIGITS, param, String.class);
			logger.info("findSBHDouble IntCategory -->"+digits);
		} catch (DataAccessException ex) {
			logger.error("DAO Execption : " ,ex); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getSBHDoubleIntCategory(int tenure, String subCat,String bankCode,String fdRate,String fdAmount) - method end.");
		return digits;
	}

	public String getSBHDoubleProductDesc(String productCode,String bankCode) {
		logger.info("getSBHDoubleProductDesc(...) Starts Here"); 
		String productDesc = "";
		try {               
			Object[] params = {productCode,bankCode};
			productDesc = (String) getJdbcTemplate().queryForObject(GET_SBH_DOUBLE_PRODUCT_DESC,params, String.class);
			logger.info("productDesc List For SBH Double :" + productDesc);
		}catch (IncorrectResultSizeDataAccessException ex) {
			logger.error(""+ex);
		}catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("getSBHDoubleProductDesc(...) Starts Here");
	return productDesc;
	}
	public Map getSBHDoubleTenureDetails(String productCode,String bankCode) throws DAOException {
		logger.info("getSBHDoubleTenureDetails(..) Starts Here");
		Map outParams=new HashMap();		
		List tenureDetailList = null;
		try {
			final Object dayparams [] = new Object[] {productCode,bankCode};
			tenureDetailList = (List)getJdbcTemplate().query(GET_SBH_DOUBLE_FD_TENURE_DETAILS, dayparams, new FixedDepositTenureRowMapper());
			logger.info("tenureDetailList ->"+tenureDetailList);
			outParams.put("tenureList", tenureDetailList);
		} catch(DataAccessException dae) {
			logger.error("DAO Exception : " ,dae); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getSBHDoubleTenureDetails(..) Ends Here");
		return outParams;
	}
	public Map getSBHDoubleFdAmountDetails(String productCode,int totalNoOfDays,String bankCode) throws DAOException {
		logger.info("getSBHDoubleFdAmountDetails(..) Starts Here");
		Map outParams=new HashMap();		
		List amountDetailList = null;
		try {
			final Object params [] = new Object[] {productCode,totalNoOfDays,bankCode};
			amountDetailList = (List) getJdbcTemplate().query(GET_SBH_DOUBLE_FD_AMOUNT_DETAILS, params, new FixedDepositRowMapper());
			logger.info("amountDetailList ->"+amountDetailList);
			outParams.put("amountList", amountDetailList);
		} catch(DataAccessException dae) {
			logger.error("DAO Exception : " ,dae); 
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getSBHDoubleFdAmountDetails(..) Ends Here");
		return outParams;
	}
	/*DEV  - 262 Implementation for SBH Double Ends Here */
	public int getAuthOption(String userName,String accountNo,String branchCode,Double amount) {
		logger.info("getAuthOption method begins");
		List authOptionList;
		Map authOptionMap=new HashMap<String, Integer>();
		int authOption=0;
		try{
			final Object params [] = new Object[] {userName,accountNo,branchCode,amount};
			authOptionList = getJdbcTemplate().queryForList(GET_AUTH_OPTION,params);
			if(authOptionList!=null && authOptionList.size()>0)
			{
				authOptionMap=(Map)authOptionList.get(0);
				authOption=new Integer((String)authOptionMap.get("AUTH_OPTION"));
			}
		}
		catch (EmptyResultDataAccessException ex) {
			//DO Nothing
		}
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		
		logger.info("getAuthOption method ends");
		return authOption;
	}
	/*DEV  - 262 Implementation for SBH Double Ends Here */

	public int chkDebitProductCodeExists(String debitProductCode,String bankCode,String segmentCode) {
		logger.info("chkDebitProductCodeExists(..) Starts Here");
		int chkCount = 0;

		if (debitProductCode != null) {
			try {
				final int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR , Types.VARCHAR };
				final Object[] params = new Object[] { debitProductCode ,bankCode,segmentCode };
				chkCount = getJdbcTemplate().queryForInt(CHK_DEBIT_PRODUCT_CODE_EXISTS, params, sqlTypes);
				logger.info(" count : " + chkCount);

				/*if(chkCount==0 ) {
					logger.info("No Product Code available in the Master Product Code Table (sbi_fd_product_code_master)...>"+debitProductCode+"  "+" For the Bank Code -->"+bankCode);
					DAOException.throwException("FD011");
				}*/
			} catch (DataAccessException exp) {
				logger.error("Unable to execute  sbi_fd_product_code_master :: "+ exp.getMessage(), exp);
				DAOException.throwException("FD011", exp);
			}
		}
		logger.info("chkDebitProductCodeExists(..) Ends Here");
		return chkCount;
	}
	
	
	public List getProductCodeList(String debitProductCode,String bankCode,String segmentCode)  {
		logger.info("getProductCodeList(..) Starts Here");
		List productCodeList = new ArrayList();
		
		if (debitProductCode != null) {
			try {
				final int sqlTypes[] = { Types.VARCHAR,Types.VARCHAR ,Types.VARCHAR};
				final Object[] params = new Object[] { debitProductCode ,bankCode ,segmentCode};
				productCodeList = (List) getJdbcTemplate().query(GET_PRODUCT_CODE_DETAILS, params, new ProductCodeLogicRowMapper());

				logger.info("productCodeList.size() from sbi_fd_product_code_master :"+productCodeList.size());
				logger.info("productCodeList.isEmpty()::"+productCodeList.isEmpty());

				if (logger.isInfoEnabled()) {
					logger.info("Debit Product Code --->" + debitProductCode);
					logger.info("productCodeList -->"+ productCodeList);
				}
			} catch (DataAccessException e) {
				logger.error("ERROR: Unable to get the product Code List Details For the Account No:: "+ e.getMessage(), e);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		logger.info("getProductCodeList(..) Ends Here");
		return productCodeList;
	}

	private class ProductCodeLogicRowMapper implements RowMapper {
		public FDProductCodeModel mapRow(ResultSet rs, int index)throws SQLException {			
			FDProductCodeModel pModel = new FDProductCodeModel();
			pModel.setDebitProductCode(rs.getString("DEBIT_PRODUCT_CODE"));
			pModel.setDebit_prod_type12(rs.getString("DEBIT_PRODUCT_TYPE_1_2"));
			pModel.setDebit_prod_type34(rs.getString("DEBIT_PRODUCT_TYPE_3_4"));
			pModel.setDebit_subcat5(rs.getString("DEBIT_SUBCAT_5"));
			pModel.setDebit_subcat67(rs.getString("DEBIT_SUBCAT_6_7"));
			pModel.setDebit_subcat8(rs.getString("DEBIT_SUBCAT_8"));
			pModel.setProduct_desc(rs.getString("PRODUCT_DESC"));
			pModel.setCustomer_type(rs.getString("CUSTOMER_TYPE"));
			pModel.setCustomer_category(rs.getString("CUSTOMER_CATEGORY"));
			pModel.setSegmentCode(rs.getString("SEGMENT_CODE"));
			pModel.setBankCode(rs.getString("BANK_CODE"));
			return pModel;
		}
	}
	public void updateFdAccStatus(FixedDepositModel fixedDepositModel){
		logger.info("updateFdAccStatus(..) Starts Here");

		try {
			if (fixedDepositModel != null) {

				logger.info("Reference No -->"+ fixedDepositModel.getReferenceNo());
				logger.info("FD Reference No -->"+ fixedDepositModel.getFdReferenceNo());
				
				final int sqlTypes[] = { Types.VARCHAR,Types.VARCHAR };
				final int echequeSqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR };
				
				final Object[] params = new Object[] {fixedDepositModel.getFdReferenceNo(),fixedDepositModel.getReferenceNo()};
				final Object[] echqueParams = new Object[] {fixedDepositModel.getAuth1Name(),fixedDepositModel.getAuth2Name(),fixedDepositModel.getFdReferenceNo()};
				
				int rowsUpdated = getJdbcTemplate().update(UPDATE_FD_ACC_STATUS, params, sqlTypes);
				logger.info("No. of Rows Updated in sbicorp_fd_account_map -->"+ rowsUpdated);
				if(rowsUpdated == 1){
				int echequeRowsUpdated =	getJdbcTemplate().update(UPDATE_ECHEQUE_AUTH_DETAILS, echqueParams, echequeSqlTypes);
				logger.info("No. of Rows Updated in sbicorp_echeque_master -->"+ echequeRowsUpdated);
				}
			}
		} catch (DAOException exp) {
			logger.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);

		} catch (DataAccessException e) {
			logger.error("ERROR: Unable to Update fd_account_map:: "+ e.getMessage(), e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("updateFdAccStatus(..) Ends Here");
	}
	
	
	
	public List getFixedDepositStatus(String userName, String branchCode, String debitAccountNo)
	
	{
		logger.info("getFDstatus(..) Starts Here");
		List fdstatus=  new ArrayList();
		FixedDepositModel fModel = new FixedDepositModel();
			try {
				
				
				final int sqlTypes[] = { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
				final Object[] params = new Object[] { userName ,branchCode,debitAccountNo };
				fdstatus = (List) getJdbcTemplate().query(GET_FIXED_DEPOSIT_STATUS, params, new FixedDepositStatusMapper());
				
				logger.info("fd status list size is :"+fdstatus.size());
				
				
				logger.info("fd status list  is :"+fdstatus);
				

				if (logger.isInfoEnabled()) {
					
				}
			} catch (DataAccessException e) {
				logger.error("ERROR: Unable to get the status Details :: "+ e.getMessage(), e);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
					logger.info("getFDstatus(..) Ends Here");
			return fdstatus;
		
		}
	
	
	private class FixedDepositStatusMapper implements RowMapper {
		
			public FixedDepositModel mapRow(ResultSet rs, int index)throws SQLException {
				
			
			FixedDepositModel fModel = new FixedDepositModel();
			
			fModel.setReferenceNo(rs.getString("reference_no"));
			
			
			fModel.setFdCreationDate(rs.getDate("creation_time"));
			fModel.setInterestRate(rs.getDouble("interest_rate"));
			fModel.setTenureInDays(rs.getInt("tenure"));
			fModel.setDays(rs.getInt("tenure_day"));
			fModel.setMonths(rs.getInt("tenure_month"));
			fModel.setYears(rs.getInt("tenure_year"));
			String fmtMaturityDte = convertUIFormat(rs.getString("maturity_date"));
			fModel.setMaturityDate(fmtMaturityDte);
			fModel.setPrincipalAmount(rs.getDouble("fd_amount"));
			fModel.setMaturityAmount(rs.getString("maturity_value"));
			fModel.setAuthStatus(rs.getString("auth_status"));
			fModel.setAuth1Name(rs.getString("auth1_name"));
			fModel.setAuth2Name(rs.getString("auth2_name"));
			fModel.setDebitAccountNo(rs.getString("debit_account_no"));
			fModel.setFdAccountNo(rs.getString("fd_account_no"));
			fModel.setSelectedMaturityDate(rs.getString("tenure_maturity_date"));
			logger.info("FdReferenceNo :"+fModel.getFdReferenceNo());
			
			if(fModel.getSelectedMaturityDate()!=null && !"".equals(fModel.getSelectedMaturityDate())){
				fModel.setDtMonYr(false);
	        }
	        else if((fModel.getDays()>0 && fModel.getTenureInDays()==0) || fModel.getMonths()>0 || fModel.getYears()>0) {
	        	fModel.setDtMonYr(true);
	        }
	        else{
	        	fModel.setDtMonYr(false);
	        }
			
			return fModel;
		}
	}
	

	private String convertUIFormat(String date) {
		logger.info("convertUIFormat(..) starts here..");
		String returnDate = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yyyy");
			String reDate = sdf2.format(sdf1.parse(date.replaceFirst("\\.\\d", "")));
			returnDate = sdf2.format(sdf2.parse(reDate));
		} catch (ParseException parseExp) {	
			logger.info("Parse Error Exception...:"+parseExp);
		}
		logger.info("convertUIFormat(..) Ends  here..");
		return returnDate;
	}
	
	public List getFixedDepositAccountDtls(String corporateId, String debitAccountNo)
	
	{
		logger.info("getFixedDepositAccountDtls(..) Starts Here");
		List fdstatus=  new ArrayList();
		FixedDepositModel fModel = new FixedDepositModel();
		try {
			final int sqlTypes[] = { Types.VARCHAR,Types.VARCHAR};
			final Object[] params = new Object[] { corporateId , debitAccountNo };
			fdstatus = (List) getJdbcTemplate().query(GET_FIXED_DEPOSIT_ACCOUNT_DTLS, params, new FixedDepositStatusMapper());
			
			logger.info("fd status list  is :"+fdstatus);
			
		} catch (DataAccessException e) {
			logger.error("ERROR: Unable to get the Fixed Deposit Account Details :: "+ e.getMessage(), e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getFixedDepositAccountDtls(..) Ends Here");
		return fdstatus;
	
	}
}

