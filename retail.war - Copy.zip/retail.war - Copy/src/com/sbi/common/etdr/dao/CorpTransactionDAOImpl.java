/*   
 * CorpTransactionDAOImpl.java
 * Created on Oct 20, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 12, 2006 Aparna S - Initial Creation  and implementation.
//Oct 18, 2006 RAVIKUMAR KATHIRVEL - modified  for edit echeque.
package com.sbi.common.etdr.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.StoredProcedure;

import wac.audit.FieldCollection;
import wac.audit.FieldsModel;

import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.IBTransactionDAO;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;

public class CorpTransactionDAOImpl extends JdbcDaoSupport implements CorpTransactionDAO {

	private IBTransactionDAO ibTransactionDAOImpl; // Added for CR 2921

	protected final Logger logger = Logger.getLogger(getClass());
	
	public static final String JAVA_CORPORATE_TRANSACTION_PROCESS_TRANSACTION_PROCNAME = "java_corporate_transaction.processTransaction";
	
	public static final String JAVA_CORPORATE_TRANSACTION_EDIT_TRANSACTION_PROCNAME ="java_corporate_transaction.editTransaction";

	

	private EchequeMasterDAO echequeMasterDAOImpl;
	
	public String createTransaction(Transaction transaction) {

		logger.info("createTransaction(Transaction transaction) "
				+ LoggingConstants.METHODBEGIN);
		if (logger.isInfoEnabled()) {
			logger.info("transaction :" + transaction);
		}
		
		logger.info("transactionName() ---->"+transaction.getName());
		try {

			Object[] debit = null;
			List creditsList = new ArrayList();
			List multiList=new ArrayList();
			CorpTransactionLeg debitCorpTransactionLeg =( CorpTransactionLeg ) transaction.getDebit();
			if (debitCorpTransactionLeg!= null) {
				debit = debitCorpTransactionLeg.toObject();
				
				if (logger.isDebugEnabled()) {
					logger.debug(" Debit leg : " + debit);
				}

				for (int i = 0; i < debit.length; i++){
					
					if (logger.isDebugEnabled()) {
						logger.debug("Debit Leg value :" + debit[i]);
					}
					logger.info(" Debit leg : " + debit[i]);
				}
			}

			
			if (transaction.getCredit() != null) {

				if (logger.isDebugEnabled()) {
					logger.debug("Credit Length :"
							+ transaction.getCredit().length);
				}
				for (int i = 0; i < transaction.getCredit().length; i++) {
					if (transaction.getCredit()[i] != null) {
						CorpTransactionLeg  creditCorpTransactionLeg =  (CorpTransactionLeg)transaction.getCredit()[i];
							
						logger.info("CorpTransaction CreditLeg Leg:" + creditCorpTransactionLeg);
						logger.info("Nararrative1 : " + creditCorpTransactionLeg.getNarrative1());
						logger.info("Nararrative2 : " + creditCorpTransactionLeg.getNarrative2());
						logger.info("Nararrative3 : " + creditCorpTransactionLeg.getNarrative3());
						logger.info("MerchantCode : " + creditCorpTransactionLeg.getMerchantCode());
						logger.info("Amount : " + creditCorpTransactionLeg.getAmount());
						
						creditsList.add(creditCorpTransactionLeg.toObject());
						multiList.add(creditCorpTransactionLeg);
						if (logger.isDebugEnabled()) {
							logger.debug(" Credit leg:" + creditsList.get(i));
						} 
					}
				}
			}

			SumStoredProcedure sproc = new SumStoredProcedure(
					getJdbcTemplate(),
					JAVA_CORPORATE_TRANSACTION_PROCESS_TRANSACTION_PROCNAME);
			Map procResult = sproc.execute(debit, creditsList, transaction);
			///if (logger.isDebugEnabled()) {
			logger.info(" reference no : "
					+ (String) procResult.get("p_referenceno"));
			//}

			String error = (String) procResult.get(DAOConstants.P_ERROR);
			logger.info("Error in create transaction ::  " + error );
			if (error.equalsIgnoreCase(DAOConstants.ZERO)) {
				String merchantCode=transaction.getDebit().getMerchantCode();
				if ((merchantCode!=null && (merchantCode.equals(UtilsConstant.RTGS)|| merchantCode.equals(UtilsConstant.NEFT)
						|| merchantCode.equals(UtilsConstant.GRPT))) || transaction.getName().equals("CM")) //modified for Dealer finance payment
					try {
						//modified for Dealer finance payment by jothi
						String thirdPartyRef = ((CorpTransactionLeg)transaction.getDebit()).getCorpRefNo();
						String rateOfInterest = debitCorpTransactionLeg.getRateOfInterest();
						if(thirdPartyRef == null)
							thirdPartyRef = "";
						if (rateOfInterest == null)
							rateOfInterest = "0";
						logger.info("thirdPartyRef:" + thirdPartyRef);
						logger.info("RateOfInterest:" + rateOfInterest);
						// Object params[]=
						// {debitCorpTransactionLeg.getRateOfInterest(),(String)
						// procResult.get(DAOConstants.P_REFERENCE_NO)};
						String refType = procResult.get(DAOConstants.P_REFERENCE_NO).toString().substring(0, 2);
						String referenceNo = procResult.get(DAOConstants.P_REFERENCE_NO).toString();
						logger.info("ref typeaerarf:::" + refType);
						String thirdPartyRefNo = (String) thirdPartyRef;
						
						final String commissionType = ((CorpTransactionLeg) transaction.getDebit()).getCommissionType();
						FieldCollection updateEchequeDetails = new FieldCollection("CU002",this.getClass().getName(),"createTransaction");
						FieldsModel fieldsModel = new FieldsModel("RATE_OF_INTEREST",Types.VARCHAR,rateOfInterest,1);
						updateEchequeDetails.addField(fieldsModel);
						if(refType != null && "CR|CN|CZ".indexOf(refType)>=0){
							fieldsModel = new FieldsModel("CREDIT_STATUS_CODE",Types.VARCHAR,commissionType,3);
							updateEchequeDetails.addField(fieldsModel);
						}else if(refType != null && refType.equalsIgnoreCase("CM")){
							fieldsModel = new FieldsModel("THIRD_PARTY_REF",Types.VARCHAR,thirdPartyRefNo,2);
							updateEchequeDetails.addField(fieldsModel);
						}
					
						echequeMasterDAOImpl.updateEcheque(updateEchequeDetails, referenceNo);
						//Added for NEFT multiple credit commision
						if(multiList!=null && multiList.size()>1 && debitCorpTransactionLeg.getMerchantCode().equals("NEFT")){
							for (int i = 0; i < multiList.size(); i++)	{
								CorpTransactionLeg  creditLeg = (CorpTransactionLeg) multiList.get(i);
								ibTransactionDAOImpl.updateMultipleCreditsCommission(Double.valueOf(creditLeg.getRateOfInterest()),referenceNo,creditLeg.getAmount());
							}
						}
						else{
						ibTransactionDAOImpl.updateUTRNo(referenceNo, "", rateOfInterest);
						}
						
								
					} catch (DataAccessException accessException) {
						logger.error("Exception occured :" + accessException);
						// modified for Dealer finance payment by jothi
						// DAOException.throwException("RTGS001");
						DAOException.throwException("DLR001");
					}
				logger.info("Error in creation :  " + error);
				logger.info("createTransaction(Transaction transaction) " + LoggingConstants.METHODEND);
				logger.info("return value:::"+(String) procResult.get(DAOConstants.P_REFERENCE_NO));
				return (String) procResult.get(DAOConstants.P_REFERENCE_NO);
			} else {
				DAOException.throwException("CU002", new Object[] {});
			}

		}

		catch (DataAccessException ex) {
			ex.printStackTrace();
            logger.info("Exception occured while executing procedure::" + ex.getMessage());
			DAOException.throwException("EC013", new Object[] {}); // Ramanan M added the error code 'EC013' as per the Bug Track Id - CORP-70
		} 
		return null;
	}
	 
	/**
	 * TODO Method to execute java_corporate_transaction.editTransaction procedure for edit echeque.
	 * @param transaction object
	 * @return string
	 */

	public String editTransaction(Transaction transaction) {

		logger.info("editTransaction(Transaction transaction) "
				+ LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled()) {
			logger.debug("transaction :" + transaction);
		}
		try {

			Object[] debit = null; 
			List creditsList = new ArrayList();
			CorpTransactionLeg debitCorpTransactionLeg =( CorpTransactionLeg ) transaction.getDebit();
			if (debitCorpTransactionLeg!= null) {
				debit = debitCorpTransactionLeg.toObject();
                logger.info("DebitTransaction Leg : " + debitCorpTransactionLeg.getReferenceNo());
				
				if (logger.isDebugEnabled()) {
					logger.debug(" Debit leg : " + debit);
				}

				for (int i = 0; i < debit.length; i++){
					
					if (logger.isDebugEnabled()) {
						logger.debug("Debit Leg value :" + debit[i]);
					}
					logger.info(" Debit leg : " + debit[i]);
				}
			}

			
			if (transaction.getCredit() != null) {

				if (logger.isDebugEnabled()) {
					logger.debug("Credit Length :"
							+ transaction.getCredit().length);
				}
				for (int i = 0; i < transaction.getCredit().length; i++) {
					if (transaction.getCredit()[i] != null) {
						CorpTransactionLeg  creditCorpTransactionLeg =  (CorpTransactionLeg)transaction.getCredit()[i];
							
						logger.info("CorpTransaction CreditLeg Leg:" + creditCorpTransactionLeg);
						logger.info("Nararrative1 : " + creditCorpTransactionLeg.getNarrative1());
						logger.info("Nararrative2 : " + creditCorpTransactionLeg.getNarrative2());
						logger.info("Nararrative3 : " + creditCorpTransactionLeg.getNarrative3());
						logger.info("MerchantCode : " + creditCorpTransactionLeg.getMerchantCode());
						logger.info("MerchantCode : " + creditCorpTransactionLeg.getAmount());
						
						creditsList.add(creditCorpTransactionLeg.toObject());
						if (logger.isDebugEnabled()) {
							logger.debug(" Credit leg:" + creditsList.get(i));
						}
					}
				}
			}

			EditStoredProcedure sproc = new EditStoredProcedure(
					getJdbcTemplate(),
					JAVA_CORPORATE_TRANSACTION_EDIT_TRANSACTION_PROCNAME);
			Map procResult = sproc.execute(debit, creditsList, transaction);

			String error = (String) procResult.get(DAOConstants.P_ERROR);
			logger.info("Error in create transaction ::  " + error );
			if (error != null && error.equalsIgnoreCase(DAOConstants.ZERO)) {
				
				logger.info("Error in creation :  " + error );
				logger.info("editTransaction(Transaction transaction) "
						+ LoggingConstants.METHODEND);
                return  debitCorpTransactionLeg.getReferenceNo();
				//return (String) procResult.get(DAOConstants.P_ERROR);
			} else {
				DAOException.throwException("", new Object[] {});
			}

		}

		catch (DataAccessException ex) {
			ex.printStackTrace();
			DAOException.throwException("", new Object[] {});
		} catch (Exception ex) {
			logger.fatal(LoggingConstants.EXCEPTION, ex);
			//DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			ex.printStackTrace();
		}
		return null;
	}
	
	public boolean updateStatus(TransactionResponse transactionResponse,
			String refNo) {

		logger
				.info("updateStatus(TransactionResponse transactionResponse, String refNo) "
						+ LoggingConstants.METHODBEGIN);
		logger.info("transactionResponse :" + transactionResponse);
		logger.info("refNo :" + refNo);

		if (transactionResponse != null && refNo.trim() != DAOConstants.EMPTY
				&& refNo != null) {
			try {
				int[] types = new int[] { Types.VARCHAR, Types.VARCHAR,
						Types.VARCHAR, Types.VARCHAR };
				getJdbcTemplate().update(
						SQLConstants.UPDATE_IB_STATUS,
						new Object[] { transactionResponse.getStatusCode(),
								transactionResponse.getStatusDescription(),
								transactionResponse.getResponseReference(),
								refNo }, types);
				if (logger.isDebugEnabled()) {
					logger.debug("Return true");
				}
				return true;
			} catch (DataAccessException ex) {

				DAOException.throwException(
						ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
		} else {
			DAOException
					.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return false;
	}

	private class SumStoredProcedure extends StoredProcedure {
		protected final Logger logger = Logger.getLogger(getClass());
    
		public SumStoredProcedure(JdbcTemplate jdbcTemplate, String name) {
			super(jdbcTemplate, name);
			System.out.println("SumStoredProcedure>>>>>>>>>>");
			System.out.println("SumStoredProcedure>>>>name>>>>>>"+name);
			setSql(name);
			declareParameter(new SqlParameter(DAOConstants.P_DEBITLEG,
					OracleTypes.STRUCT, "OBJ_CORPORATE_LEG"));
			declareParameter(new SqlParameter(DAOConstants.P_CREDITLEG,
					OracleTypes.ARRAY, "COL_CORPORATE_LEG"));
			declareParameter(new SqlParameter(DAOConstants.P_TRANSACTIONNAME,
					OracleTypes.VARCHAR));
			declareParameter(new SqlParameter(DAOConstants.P_TRANSACTIONPATH,
					OracleTypes.VARCHAR));
			declareParameter(new SqlOutParameter(DAOConstants.P_REFERENCE_NO,
					OracleTypes.VARCHAR));
			declareParameter(new SqlOutParameter(DAOConstants.P_ERROR,
					OracleTypes.VARCHAR));
			compile();

		}

		public Map execute(final Object[] debit, final List creditsList,
				final Transaction transaction) {
			return execute(new ParameterMapper() {
				
				public Map createMap(Connection conn) throws SQLException {
System.out.println("In side Execute Method >>>>>>>>>>>>>"+transaction.getName().trim());
                    Map params = new HashMap();
                    try {
                    StructDescriptor sdesc1 = StructDescriptor
							.createDescriptor("OBJ_CORPORATE_LEG",conn);
					
						logger.info("Create STRUCT : " + debit.toString());
					
					




                    STRUCT param1 = new STRUCT(sdesc1, conn, debit);
                    
                	logger.info("param1:::::: : " + param1);
					if (logger.isDebugEnabled()) {
						logger.debug(" Begin Credit : " + debit);
					}

					STRUCT[] objStruct = new STRUCT[creditsList.size()];
					for (int i = 0; i < creditsList.size(); i++) {
						objStruct[i] = new STRUCT(sdesc1, conn,
								(Object[]) creditsList.get(i));
					}
					ArrayDescriptor objAd = ArrayDescriptor.createDescriptor(
							"COL_CORPORATE_LEG", conn);
					ARRAY array = new ARRAY(objAd, conn, objStruct);
					logger.info("transaction.getName().trim()>>>>>>>>>>>>>>>>>>>>"+transaction.getName().trim());
					//Map params = new HashMap();
					params.put(DAOConstants.P_DEBITLEG, param1);
					params.put(DAOConstants.P_CREDITLEG, array);
					params.put(DAOConstants.P_TRANSACTIONNAME, transaction
							.getName().trim());
					params.put(DAOConstants.P_TRANSACTIONPATH, transaction
							.getPath());
                    }
                    catch(Exception e )
                    {
                        e.printStackTrace();
                        logger.info("Exception occured::" + e.getMessage());
                    }
					return params;
				}
			});

		}

	}
	
	
	
	
	private class EditStoredProcedure extends StoredProcedure {
		protected final Logger logger = Logger.getLogger(getClass());

		public EditStoredProcedure(JdbcTemplate jdbcTemplate, String name) {
			super(jdbcTemplate, name);
			setSql(name);
			declareParameter(new SqlParameter(DAOConstants.P_DEBITLEG,
					OracleTypes.STRUCT, "OBJ_CORPORATE_LEG"));
			declareParameter(new SqlParameter(DAOConstants.P_CREDITLEG,
					OracleTypes.ARRAY, "COL_CORPORATE_LEG"));
			declareParameter(new SqlOutParameter(DAOConstants.P_ERROR,
					OracleTypes.VARCHAR));
			compile();

		}

		public Map execute(final Object[] debit, final List creditsList,
				final Transaction transaction) {
			return execute(new ParameterMapper() {
				public Map createMap(Connection conn) throws SQLException {

					StructDescriptor sdesc1 = StructDescriptor
							.createDescriptor("OBJ_CORPORATE_LEG",conn);
					
						logger.info("Create STRUCT : " + debit.toString());
					
					STRUCT param1 = new STRUCT(sdesc1, conn, debit);
					if (logger.isDebugEnabled()) {
						logger.debug(" Begin Credit : " + debit);
					}

					STRUCT[] objStruct = new STRUCT[creditsList.size()];
					for (int i = 0; i < creditsList.size(); i++) {
						objStruct[i] = new STRUCT(sdesc1, conn,
								(Object[]) creditsList.get(i));
					}
					ArrayDescriptor objAd = ArrayDescriptor.createDescriptor(
							"COL_CORPORATE_LEG", conn);
					ARRAY array = new ARRAY(objAd, conn, objStruct);

					Map params = new HashMap();
					params.put(DAOConstants.P_DEBITLEG, param1);
					params.put(DAOConstants.P_CREDITLEG, array);
					return params;
				}
			});

		}

	}

	public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl) {
		this.ibTransactionDAOImpl = ibTransactionDAOImpl;
	}

	public void setEchequeMasterDAOImpl(EchequeMasterDAO echequeMasterDAOImpl) {
		this.echequeMasterDAOImpl = echequeMasterDAOImpl;
	}	

}
