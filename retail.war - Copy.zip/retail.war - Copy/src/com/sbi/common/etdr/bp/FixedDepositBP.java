package com.sbi.common.etdr.bp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CoreDAOImpl;
import com.sbi.common.dao.CoreTransactionDAOImpl;
import com.sbi.common.etdr.dao.FixedDepositDAO;
import com.sbi.common.etdr.model.FDProductCodeModel;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

@SuppressWarnings(value="unchecked")
public class FixedDepositBP {

	protected final Logger logger = Logger.getLogger(getClass());
	
	private CoreDAOImpl coreDAOImpl;
	
	private FixedDepositDAO fixedDepositDAOImpl;
	
	private CoreTransactionDAOImpl coreTransactionDAOImpl;
	
	private FixedDepositUtils fixedDepositUtils;
	   
	public static final String FIXED_DEPOSIT_CREATION_TXN_NO = "002000";

	public Map<String, Object> getDepositRequestParams(Map<String, Object> inParam){
	    logger.info(" getDepositRequestParams method begins");
	    Map<String,Object> paramMap = null;
	    String bankCode=(String)inParam.get("bankCode");
	    FixedDepositModel fixedDepositModel = (FixedDepositModel) inParam.get("fixedDepositModel");
	    if (fixedDepositModel != null){
	        paramMap = new HashMap<String, Object>();
	        String fdReferenceNo = null;//fixedDepositDAOImpl.getFdReferenceNo();
	        
	        /*if(fixedDepositModel.getFdReferenceNo() != null && fixedDepositModel.getFdReferenceNo().startsWith("FD"))
	        {
	        	fdReferenceNo = fixedDepositModel.getFdReferenceNo(); //Scheduled Transactions
	        }
	        else
	        {	        
	        	fdReferenceNo = fixedDepositDAOImpl.getFdReferenceNo();//Online Transactions
	        }*/
	        
	        String referenceNo = null;
	        if(fixedDepositModel.getReferenceNo()==null)
	        	referenceNo=fixedDepositDAOImpl.getReferenceNo();
	        else
	        	referenceNo=fixedDepositModel.getReferenceNo();
	        
	        String accountType = "";
	        String interestCode = "";
	        String intFrequency = "";
	        String intCat ="";
	        String accSgmntCode  = fixedDepositModel.getSegmentCode();
            String subCat = "";
	        String productCode = fixedDepositModel.getDebitProductCode();
	        String autoRenewIntFrequency="";
	        
	        logger.info("Segment Code***********"+accSgmntCode);
	        
	        if (fixedDepositModel.getFdType()!= null){
	            if (fixedDepositModel.getFdType().equalsIgnoreCase("STDR")){
	                interestCode="R";
	                intFrequency ="M";
	                autoRenewIntFrequency="M";
	                paramMap.put("autoRenewIntFrequency",autoRenewIntFrequency);
	                //for testing STDR input_trf_acct_no is set to '00000000000000000'
	                paramMap.put("input_trf_acct_no", "00000000000000000");
	                paramMap.put("interest_trf_acct_no", "00000000000000000"); // 'A' autorenew type dded for 7007 request(Maturity Mandates CR)	                
	                
	            }
	            else if (fixedDepositModel.getFdType().equalsIgnoreCase("TDR")){
	                interestCode="T";
	                intFrequency = fdInterestFrequencyFinder(fixedDepositModel.getInterestPayout());	                
	                autoRenewIntFrequency = fdInterestFrequencyFinder(fixedDepositModel.getAutoRenewInterestPayout());
	                paramMap.put("autoRenewIntFrequency",autoRenewIntFrequency);
	                
	                paramMap.put("input_trf_acct_no", fixedDepositModel.getDebitAccountNo());
	                paramMap.put("interest_trf_acct_no",fixedDepositModel.getDebitAccountNo()); // Added for 7007 request(Maturity Mandates CR)	                
	            }
	        }
	        else
	        {
	            logger.info("Fd Type is NULL");
	            SBIApplicationException.throwException("SE002");
	        }
            
	        logger.info("input_trf_acct_no for 2000 req ::"+ paramMap.get("input_trf_acct_no") );
	        
	        if("0".equals(bankCode)){
	        	subCat = findAccountSubCategory(fixedDepositModel.getDebitProductCode(), fixedDepositModel.getFdType(),bankCode,fixedDepositModel.getSegmentCode());	
	        }else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || ("2".equals(bankCode) && !"Yes".equalsIgnoreCase(fixedDepositModel.getIsSbhDouble()))){
	        	subCat = findAccountSubCategoryForABs(fixedDepositModel.getDebitProductCode(), fixedDepositModel.getFdType(),bankCode,fixedDepositModel.getSegmentCode());
	        }
	        else if("2".equals(bankCode) && "Yes".equals(fixedDepositModel.getIsSbhDouble())){ //DEV - 262 is SBH Double Implementation
	        	logger.info("inside for sbh double.. subcat..");
	        	subCat = findAccountSubCategoryForABs(fixedDepositModel.getDebitProductCode(),"STDR",bankCode,fixedDepositModel.getSegmentCode());
	        }
            accountType = subCat.substring(0,4);
            
            //added for associate bank by viswa
            String fdAmt = String.valueOf(fixedDepositModel.getFdAmount());
            logger.info("Product Code Fd Amount:::"+fdAmt);
            logger.info("bankCode for associate banks:::"+bankCode);
            //added for associate bank by viswa
            
            /*Added for Floating Rate CR. available for only to SBI starts here*/
            if("0".equals(bankCode))            
            	  intCat = fdInterestCategoryFinder(fixedDepositModel.getDebitProductCode(),fixedDepositModel.getTenureInDays(),subCat,bankCode,fixedDepositModel.getTypeOfInterestRate(),String.valueOf(fixedDepositModel.getFdAmount()),fixedDepositModel.getSegmentCode());
            else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode))
            	intCat = fdInterestCategoryFinderForAssociate(fixedDepositModel.getDebitProductCode(),fixedDepositModel.getTenureInDays(),subCat,bankCode,fixedDepositModel.getTypeOfInterestRate(),String.valueOf(fixedDepositModel.getFdAmount()),fixedDepositModel.getSegmentCode(),fixedDepositModel.getIsSbhDouble());
            
	        String crProductCode = accountType + intCat;
	        String validEtdrProdCode =  crProductCode.substring(2,4);
	        
	        logger.info("accountType ::"+accountType+" intCat ::"+intCat+"== e-TDR Product Code ::"+crProductCode +" isEtdrProdCode(3,4) 11,13,14 :: "+validEtdrProdCode);
	        
	        if( !validEtdrProdCode.equalsIgnoreCase("11") /*&& !validEtdrProdCode.equalsIgnoreCase("13")
	            && !validEtdrProdCode.equalsIgnoreCase("14")*/ ){
	        	SBIApplicationException.throwException("FD022");
	        }
	        if(fixedDepositModel.isDtMonYr()){
	            paramMap.put("term_no_day",((Integer)fixedDepositModel.getDays()).toString());
	            paramMap.put("term_no_month",((Integer)fixedDepositModel.getMonths()).toString());
	            paramMap.put("term_no_years",((Integer)fixedDepositModel.getYears()).toString());
	        }
	        else{
	        	if(fixedDepositModel.getSelectedMaturityDate()!=null && fixedDepositModel.getSelectedMaturityDate().trim().length()>0) {
	        		paramMap.put("term_length","0000");
	        	}else {
	        		paramMap.put("term_length",((Integer)fixedDepositModel.getTenureInDays()).toString());
	        	}
	        }
	        
	        
	        
	       /* if("0".equals(bankCode)){
	        accSgmntCode = fdSegmentCodeFinder(productCode,crProductCode,bankCode) ;
	        }else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)) {
	        	accSgmntCode = fdSegmentCodeFinderForABs(productCode,crProductCode,bankCode);
	        }*/
	        	
	        /*if(accSgmntCode == null  || ( accSgmntCode != null && accSgmntCode.equalsIgnoreCase(""))){
	            logger.info("Account segment code unavailable");
	            SBIApplicationException.throwException("SE002");
	        }*/
	        
	        paramMap.put("reference_no", referenceNo);
	        paramMap.put("account_no", fixedDepositModel.getDebitAccountNo());
	        paramMap.put("customer_no", fixedDepositModel.getCustomerNo());
	        paramMap.put("account_type", accountType);
	        paramMap.put("crProductCode", crProductCode);
	        paramMap.put("int_cat", intCat);
	        //paramMap.put("input_trf_acct_no", fixedDepositModel.getDebitAccountNo());
	        paramMap.put("int_code", interestCode);
	        paramMap.put("term_basis","D");
	        //paramMap.put("term_value",(fixedDepositModel.getFdAmount()).toString());
            paramMap.put("term_value",StringUtils.getCoreAmount(fixedDepositModel.getFdAmount()));
	        paramMap.put("int_freq", intFrequency);
	        paramMap.put("acct_sgmt_code", accSgmntCode);
	        String branchCode = fixedDepositModel.getDebitBranchCode();
	        logger.info("Branch Code ---->"+branchCode);
	        paramMap.put("isSbhDouble"," ");
	        logger.info("isSbhDouble::"+paramMap.get("isSbhDouble"));
	        if(branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("A")){
	        	logger.info("branchCode before replace::"+ branchCode);
	        	branchCode = branchCode.replaceFirst("A", "1");
	    	}
	        logger.info("branchCode after replace::"+ branchCode);
	        paramMap.put("branch_code", branchCode);

			logger.info("Auto Renew Type ->"+fixedDepositModel.getAutoRenewType());
			paramMap.put("maturity_instruction",fixedDepositModel.getAutoRenewType());
			paramMap.put("pan_no"," ");
			if("0".equals(bankCode)){
				paramMap.put("currency_type","INR");
			} else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)) {
				paramMap.put("currency_type"," ");
			}
			//paramMap.put("nominee_indicator","0");//added for including nominee indicator in 2000 req
	        
	        logger.info(" getDepositRequestParams method ends");
	    }
	    
	    else
	    {
	        logger.info("Fixed Deposit Model is NULL");
	        SBIApplicationException.throwException("SE002");
	    }
	    
	    return paramMap;
	}
	 //bank code added for associate bank by viswa   
	public String fdInterestCategoryFinder(String productCode,int tenureDays,String subCat,String bankCode,String fdRate,String fdAmount,String segmentCode ){

		logger.info("productCode.substring(2, 5)"+productCode.substring(2, 5)+"productCode.substring(4,5)"+productCode.substring(4,5)+"productCode"+productCode+" tenureDays ::"+tenureDays+ " subCat ::"+subCat);
		String firstDigit = "";
		FDProductCodeModel productMap = null;		
		List productList = fixedDepositDAOImpl.getProductCodeList(productCode,bankCode,segmentCode);
		int productListSize = productList.size();
		for(int index=0;index<productListSize;index++){
			productMap = (FDProductCodeModel)productList.get(index);
			firstDigit = productMap.getCustomer_category();// 5th digit
		 }
		 
		  
		 
			//bank code added for associate bank by viswa
	  String secThirdFourthDigit = fixedDepositDAOImpl.findIntCategory(tenureDays, subCat,bankCode,fdRate,fdAmount);
	  /* Here after instead of hardcoding CurrencyValue '1' at 8thdigit we need to get through intcat 6th,7th and 8thdigit */
	  logger.info("secThirdFourthDigit***************>>"+secThirdFourthDigit); 
		  if(secThirdFourthDigit == null || secThirdFourthDigit.equalsIgnoreCase("")){
				logger.info("Interest Category Code Unavailable");
				SBIApplicationException.throwException("SE002");
			}
          
		  String intCat = firstDigit + secThirdFourthDigit;// +"1";
          
		  logger.info("Interest Category ::"+intCat);
          
		  logger.info("fdInterestCategoryFinder(Map<String, Object> debitMap ) method ends ");
		return intCat;
	}
	
	public String fdInterestCategoryFinderForAssociate(String productCode,int tenureDays,String subCat,String bankCode,String fdRate,String fdAmount,String segmentCode,String sbhDouble){
		logger.info("productCode.substring(2, 5)"+productCode.substring(2, 5)+"productCode.substring(4,5)"+productCode.substring(4,5)+"productCode"+productCode+" tenureDays ::"+tenureDays+ " subCat ::"+subCat+ " sbhDouble ::"+sbhDouble);
		
		String firstDigit = "";
		FDProductCodeModel productMap = null;
		
		List productList = fixedDepositDAOImpl.getProductCodeList(productCode,bankCode,segmentCode);
		int productListSize = productList.size();
		for(int index=0;index<productListSize;index++){
			productMap = (FDProductCodeModel)productList.get(index);
			firstDigit = productMap.getCustomer_category();// 5th digit
		}
		
		String secThirdDigit="";
	    secThirdDigit = fixedDepositDAOImpl.findIntCategoryForAssociate(tenureDays, subCat,bankCode,fdRate,fdAmount);
	    
	    if(secThirdDigit == null || secThirdDigit.equalsIgnoreCase("")){
			logger.info("Interest Category Code Unavailable");
			SBIApplicationException.throwException("SE002");
		}

		String intCat = firstDigit + secThirdDigit +"1";
        logger.info("Interest Category ::"+intCat);
        logger.info("String productCode,int tenureDays,String subCat,String bankCode,String fdRate,String fdAmount,String segmentCode,String sbhDouble) method ends ");
		return intCat;
	}
    public String fdInterestFrequencyFinder(String interestPayout){
		logger.debug("fdInterestFrequencyFinder(String interestPayout) method begins ");
		String intFreq = "";
		if (interestPayout.equalsIgnoreCase("Monthly")){
			intFreq = "1A";
		}
		else if (interestPayout.equalsIgnoreCase("Maturity")){
			intFreq = "M";
		}
		else if (interestPayout.equalsIgnoreCase("Yearly")){
			intFreq = "YA";
		}
		else if (interestPayout.equalsIgnoreCase("Half-Yearly")){
			intFreq = "6A";
		}
        else if (interestPayout.equalsIgnoreCase("Quarterly")){
			intFreq = "3A";
		}
		
		logger.info("interestPayout"+interestPayout);
		logger.debug("fdInterestFrequencyFinder(String interestPayout) method ends ");
		return intFreq;
	}
	
   /* private String fdSegmentCodeFinder(String debitProductCode,String fdProductCode, String bankCode){
        logger.info("fdSegmentCodeFinder(String interestPayout)method starts ");
        
        String segmentCode = "";
      	FDProductCodeModel productMap = null;
        
    	List productList = fixedDepositDAOImpl.getProductCodeList(debitProductCode,bankCode);
    	int productListSize = productList.size();
    	for(int index=0;index<productListSize;index++){
    		productMap = (FDProductCodeModel)productList.get(index);			
    		segmentCode = productMap.getSegmentCode();
        }
    	logger.info("segmentCode -->"+segmentCode);
    	if(segmentCode == null || "".equals(segmentCode)) {
	        	SBIApplicationException.throwException("FD011");
        }  
        logger.info("segmentCode"+segmentCode);
        
    return segmentCode; 
    }*/
    
    
    
    //added by siva for ETDR


    public Map getFDProductType(FixedDepositModel fdModel,String bankCode){//bank code added for associate bank by viswa
        logger.info("getFDProductType(...) method begins ");

        String accountSubCategory = "";
        List amountList = null;
        List tenureList = null;
        //snr citizen
        String productCode=fdModel.getDebitProductCode();
        String cumulativeType=fdModel.getFdType();        
        Double debitAmount=fdModel.getFdAmount();
        String fdAmt = String.valueOf(debitAmount);
        
        logger.info("Product Code Fd Amount:::"+fdAmt);

        Map outParams=new HashMap();
        if("0".equals(bankCode)){
            accountSubCategory = findAccountSubCategory(productCode, cumulativeType,bankCode, fdModel.getSegmentCode());
        }
        else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)) {
        	accountSubCategory = findAccountSubCategoryForABs(productCode,cumulativeType,bankCode, fdModel.getSegmentCode());
        }
      
        /* Added by Srinivas For Floating Rate CR only for SBI.*/
        Map fdProductParams = new HashMap();
        Integer totalNoOfdays = (Integer)fdModel.getTenureInDays();
        logger.info("Total No. of Days ->"+totalNoOfdays);
        if(bankCode!=null && ("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode))){
        	fdProductParams = fixedDepositDAOImpl.getFdAmountDetailsForAssociate(accountSubCategory, totalNoOfdays,bankCode,fdModel.getTypeOfInterestRate(),fdAmt) ;//bank code added for associate bank by viswa
        	logger.info("FD Product params ->"+fdProductParams);
        }else if(bankCode!=null && "0".equals(bankCode)){
        	fdProductParams = fixedDepositDAOImpl.getFdAmountDetails(accountSubCategory, totalNoOfdays,bankCode,fdModel.getTypeOfInterestRate(),fdAmt) ;//bank code added for associate bank by viswa
        }
        
        amountList=(List)fdProductParams.get("amountList");
        tenureList=(List)fdProductParams.get("tenureList");
        FixedDepositModel fixedDepositModel  = null;
        
        logger.info("amountList ::"+amountList+" tenureList ::"+tenureList);
        
        if(amountList == null && tenureList == null )
        	SBIApplicationException.throwException("FD022");
        
        if(amountList != null && amountList.size() > 0)
        {
            fixedDepositModel  = (FixedDepositModel)amountList.get(0);
            logger.info("amountList Max amt in BP "+fixedDepositModel.getFdMaxAmount() +" amountList Min amt in BP "+fixedDepositModel.getFdMinAmount());
            
            if((fixedDepositModel.getFdMinAmount()<=debitAmount)&&(debitAmount<=fixedDepositModel.getFdMaxAmount())){
                outParams.put("fdValidationStatus", "validationSuccess");
            }else{
                outParams.put("fdValidationStatus", "amountValidationFailed");
            }
        }
        	
        if(tenureList != null && tenureList.size() > 0)
        {
            fixedDepositModel  = (FixedDepositModel)tenureList.get(0);
            logger.info("Max days in BP "+fixedDepositModel.getMaxTenureDays());
            logger.info("Min days in BP "+fixedDepositModel.getMinTenureDays());
            outParams.put("fdValidationStatus", "tenureValidationFailed");
        }
        
        
        //amountList.add(debitAmount);
        outParams.put("amountList", amountList);
        outParams.put("tenureList", tenureList);
        if(!"C".equalsIgnoreCase(fdModel.getAutoRenewType()) && "validationSuccess".equalsIgnoreCase((String)outParams.get("fdValidationStatus")) && !"tenureValidationFailed".equalsIgnoreCase((String)outParams.get("fdValidationStatus"))){
        	logger.info("inside autorenew amount /tenure validation.."+fdModel.getTypeOfInterestRate());
        	outParams=getFDProductTypeForAutoRenew(fdModel,accountSubCategory,debitAmount,bankCode,fdModel.getTypeOfInterestRate());
        	logger.info("After Amount/tenure Validation :"+outParams);        	
        }
        logger.info("getFDProductType(..) method ends ");
        return outParams;
    }

    
     public String findAccountSubCategory(String productCode,String cumulativeType,String bankCode,String segmentCode){ //etdr snr citizen
        logger.info("findAccountSubCategory(..) method begins ");
        String accountType="";
        if(cumulativeType.equals("STDR")){
            accountType="25"; 
        }else if(cumulativeType.equals("TDR")){
            accountType="20";     
        }
        
        StringBuilder sbf = new StringBuilder();
    	List productList = new ArrayList();
    	String actType = "";
    	
    	
    	int chkCount = fixedDepositDAOImpl.chkDebitProductCodeExists(productCode,bankCode,segmentCode);
    	
    	// Product code taken from the DB
    	
    	if(chkCount>0){
			productList = fixedDepositDAOImpl.getProductCodeList(productCode,bankCode,segmentCode);
			int productListSize = productList.size();
			for(int index=0;index<productListSize;index++){
				FDProductCodeModel productMap = (FDProductCodeModel)productList.get(index);				
				accountType = String.valueOf(sbf.append(accountType).append(productMap.getCustomer_type()).append(productMap.getCustomer_category()));
				logger.info("Account type in daoimpl"+accountType);
           }
     	 }else{
     		 
     		SBIApplicationException.throwException("FD042");
     	 }
        
        logger.info("debit productCode ::"+productCode+"accountType : " + accountType +" findAccountSubCategory(...) method ends ");
        
        logger.info("account type is"+accountType);
        return accountType;
    }
	public List postEnquriyToCore(Map requestMap) throws DAOException,SBIApplicationException{
		
		List responseList = coreDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("responseMap for txnno="+requestMap.get("txnno")+" ::"+responseList);
          
        if(responseList!=null && responseList.size()>0) {
                Map resMap = (Map)responseList.get(0);
                String status = (String)resMap.get("status");
                String statement = (String)resMap.get("statement");
                String errorCode = (String) resMap.get("error_code");
                logger.info("status ::"+status +" errorCode ::"+errorCode+" statement ::"+statement);
                
               
                
              //for 400,0690290,60460 if status is null response had been recieved from core.
                if(status!=null && (status.equalsIgnoreCase("F1") || status.equalsIgnoreCase("F2")) )
                    SBIApplicationException.throwException("F1");
                
                logger.info("txn:::"+requestMap.get("txnno"));
               
                 if(status!=null && status.equalsIgnoreCase("ERR.") && !requestMap.get("txnno").equals("000408")){
                	 logger.info("inside status ERR...");
			if(errorCode!=null && "0399".equals(errorCode.trim())){
                		 SBIApplicationException.throwException("FD036");
                	 }
                	if(!requestMap.get("txnno").equals("000474")){
                	 if(requestMap.get("txnno").equals("007051")){//added for mode of operation error
                     	SBIApplicationException.throwException("FD030");
                	 }else if(errorCode!=null && errorCode.trim().equalsIgnoreCase("2861")){
                		SBIApplicationException.throwException("FD024");//specfic for 2000.
                	 }else if(errorCode!=null && "3457".equals(errorCode.trim())) {
                          	SBIApplicationException.throwException("FD039");
                	 }else {                 	 
                		SBIApplicationException.throwException(errorCode);
                	 }
                }
            }
            }
		return responseList;
	}


	/**
	 * This method is used to send 3045 fixed deposit pre closure request.
	 * @param reqDetailList
	 * @param bankCode
	 * @return
	 * @throws DAOException
	 */
	public List postFDPreClosureRequest(List reqDetailList,String bankCode) throws DAOException{
		
		Map fdDetailMap = (Map)reqDetailList.get(0);
		Map requestMap = new HashMap();
		String reference_no = fixedDepositDAOImpl.getFdReferenceNo();
		//FD_BRANCH_CODE, DEBIT_ACCOUNT_NO, DEBIT_BRANCH_CODE
		//fd_branch_code, debit_account_no, debit_branch_code
		requestMap.put("txnno","003045");
		requestMap.put("reference_no",reference_no);
		requestMap.put("tdr_acc_no",fdDetailMap.get("FD_ACCOUNT_NO"));
		requestMap.put("tdr_acc_currency","INR");
		requestMap.put("credit_acc_no",fdDetailMap.get("DEBIT_ACCOUNT_NO"));
		requestMap.put("trf_acc_currency","INR");
				
		requestMap.put("fd_branch_code",fdDetailMap.get("FD_BRANCH_CODE"));
		requestMap.put("credit_branch_code",fdDetailMap.get("DEBIT_BRANCH_CODE"));
		logger.info("Amount ::"+((BigDecimal)fdDetailMap.get("FD_AMOUNT")).toString());
		requestMap.put("fd_amount",new Double( ((BigDecimal)fdDetailMap.get("FD_AMOUNT")).toString() ));
		requestMap.put("bankCode",bankCode);
		
		logger.info("requestMap ::"+requestMap);
		List responseList = coreTransactionDAOImpl.getDataFromBankSystem(requestMap);
		
		return responseList;
		
	}

//Added By megavannan For getting the Account Nature of creation by INB or Branch
public List getFDAccountNatureOfCreation(String accountNumber) {
	logger.info("getFDAccountNatureOfCreation - "+LoggingConstants.METHODBEGIN);
		List fdAccountNatureList = null;
        if (accountNumber != null) {
            try {
            	fdAccountNatureList = fixedDepositDAOImpl.findFDAccountNature(accountNumber);
                if (fdAccountNatureList != null) {
                    return fdAccountNatureList;
                }
            }
            catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
    	logger.info("getFDAccountNatureOfCreation - "+LoggingConstants.METHODEND);
        return null;
    }

	public String getFDAccountType(String accountNumber,boolean isODAccount,String bankCode) throws SBIApplicationException{//bank code added for associate bank by viswa
	logger.info("getFDAccountType - "+LoggingConstants.METHODBEGIN);
		Map requestMap = new HashMap();
        String modeOfOperation = null;
        if (accountNumber != null) {
    		requestMap.put("txnno","069029");
    		requestMap.put("bankCode",bankCode);
    		requestMap.put("account_no",accountNumber);
    		List responseList = postEnquriyToCore(requestMap);
            if(responseList != null && responseList.size()>0){
    		    Map responseDataMap =(Map)responseList.get(0);
                modeOfOperation = (String)responseDataMap.get("mode_of_operation");
                logger.info("modeOfOperation :" + modeOfOperation);
                if(modeOfOperation==null || (modeOfOperation!=null && modeOfOperation.trim().equals("") )){
                	SBIApplicationException.throwException("FD026");
                }else{
	    		    if(modeOfOperation != null && "SINGLE".equalsIgnoreCase(modeOfOperation))
	    		    {
	    		        modeOfOperation = "Single";
	    		    }
	    		    else if(modeOfOperation != null && "EITHER OR SURVIVOR".equalsIgnoreCase(modeOfOperation))
	    		    {
	    		        modeOfOperation = "Either or Survivor";
	    		    }
					else if(modeOfOperation != null && "ANY A/C HOLD OR SURV".equalsIgnoreCase(modeOfOperation)){
						modeOfOperation = "Any A/c Hold or Surv";
					}
					else if(modeOfOperation != null && "POWER OF ATTORNEY".equalsIgnoreCase(modeOfOperation.trim())){
						modeOfOperation = "Power Of Attorney";
					}
					else if(modeOfOperation != null && "FORMER OR SURVIVOR".equalsIgnoreCase(modeOfOperation.trim())){
						modeOfOperation = "Former or Survivor";
					}
					else if(modeOfOperation != null && "LATTER OR SURVIVOR".equalsIgnoreCase(modeOfOperation.trim())){
						modeOfOperation = "Latter or Survivor";
					} 
					else if(modeOfOperation != null && "ALL A/C HOLD OR SURV".equalsIgnoreCase(modeOfOperation.trim())){
						modeOfOperation = "All A/c Hold or Surv";
					}
					else 
	                	SBIApplicationException.throwException("FD023");


                }
    		}
            
    		return modeOfOperation;
        }
    	logger.info("getFDAccountType - "+LoggingConstants.METHODEND);
        return null;
    }

   
      
/**
 * This method sends 400 request to get the CIF number and checks for insufficient funds.
 * @param enquiryMap
 * @param debitAmount
 * @return
 * @throws SBIApplicationException
 */
       public Map retrieveCIFNumberOnly(Map enquiryMap,Double debitAmount) throws SBIApplicationException{
    	   List accEnquiryList = null;
    	   Map outParams=new HashMap();
       	       if (enquiryMap != null) {
                   	accEnquiryList = postEnquriyToCore(enquiryMap);
                   	if(accEnquiryList!=null && accEnquiryList.size()>0) {
                   		Map accEnquiryMap = (Map)accEnquiryList.get(0);
	                   		try{
		                        Double availBalance = new Double((String)accEnquiryMap.get("avail_balance") );
		                   		logger.info("availBalance ::"+availBalance.doubleValue()+" debitAmount ::"+debitAmount.doubleValue());
		                   		if(availBalance.doubleValue()>=debitAmount.doubleValue()){
		                   			outParams.put("cif_no",(String)accEnquiryMap.get("cif_no"));
		                   			outParams.put("segment_code",(String)accEnquiryMap.get("segment_code"));
		                   			outParams.put("name",(String)accEnquiryMap.get("name"));
		                   		}
		                   		else
		                   		   SBIApplicationException.throwException("FD007");
	                   		}catch(NumberFormatException numExp){
	                   			logger.error("NumberFormatException ::"+numExp);
	                   			SBIApplicationException.throwException("FD010");
	                   		}
                        }
                   	}
       	    return outParams;
       }
       
       public String retrieveCIFNumber(Map enquiryMap,Double debitAmount) throws SBIApplicationException{
    	   List accEnquiryList = null;
       	       if (enquiryMap != null) {
                   	accEnquiryList = postEnquriyToCore(enquiryMap);
                   	if(accEnquiryList!=null && accEnquiryList.size()>0) {
                   		Map accEnquiryMap = (Map)accEnquiryList.get(0);
	                   		try{
	                   			
	                   		 //	accEnquiryMap.put("avail_balance","25000");
		                        Double availBalance = new Double((String)accEnquiryMap.get("avail_balance") );
		                        
		                   		logger.info("availBalance ::"+availBalance.doubleValue()+" debitAmount ::"+debitAmount.doubleValue());
		                   		if(availBalance.doubleValue()>=debitAmount.doubleValue())
		                   		{
		                   			logger.info("CIF no is"+accEnquiryMap.get("cif_no"));
		                   			return (String)accEnquiryMap.get("cif_no");
		                   		}
		                   		else
		                   		   SBIApplicationException.throwException("FD007");
	                   		}catch(NumberFormatException numExp){
	                   			logger.error("NumberFormatException ::"+numExp);
	                   			SBIApplicationException.throwException("FD010");
	                   		}
                        }
                   	}
       	    return null;
       }
       public Map retrieveSegmentCodeOnly(Map enquiryMap,Double debitAmount) throws SBIApplicationException{
    	   List accEnquiryList = null;
    	   Map outParams=new HashMap();
       	       if (enquiryMap != null) {
                   	accEnquiryList = postEnquriyToCore(enquiryMap);
                   	if(accEnquiryList!=null && accEnquiryList.size()>0) {
                   		Map accEnquiryMap = (Map)accEnquiryList.get(0);
	                   		try{
		                        outParams.put("cif_no",(String)accEnquiryMap.get("cif_no"));
	                   			outParams.put("segment_code",(String)accEnquiryMap.get("segment_code"));
	                   			outParams.put("name",(String)accEnquiryMap.get("name"));
		                   	}catch(NumberFormatException numExp){
	                   			logger.error("NumberFormatException ::"+numExp);
	                   			SBIApplicationException.throwException("FD010");
	                   		}
                        }
                   	}
       	    return outParams;
       }
       /*public String retrieveCIFNumber(Map enquiryMap,Double debitAmount) throws SBIApplicationException{
    	   String[] balance = new String[3];
       	       if (enquiryMap != null) {
       	    	   try{
       	    		   balance = getAvailableCoreBalance(enquiryMap);
       	    		   Double availableBalance = Double.valueOf(balance[0]).doubleValue();
       	    		   Double modBalance = Double.valueOf(balance[1]).doubleValue();
       	    		   Double totalBalance = availableBalance + modBalance;
       	    		   if(debitAmount.doubleValue()<=availableBalance){
       	    			   return "success#"+balance[2];
       	    		   }else if(debitAmount.doubleValue()>= availableBalance && debitAmount.doubleValue()<totalBalance) {
       	    			   logger.info("The Amount requested for e-RD, exceeds the balance available in your account.");
       	    			   return "yes#"+balance[2];
       	    		   }else if(debitAmount.doubleValue()>totalBalance) {
       	    			   SBIApplicationException.throwException("FD007");
       	    		   }
       	    	   }catch(NumberFormatException numExp){
       	    		   logger.error("NumberFormatException ::"+numExp);
       	    		   SBIApplicationException.throwException("FD010");
       	    	   }
       	       }
       	    return null;
       }*/

    public void insertFdAccountDetails(FixedDepositModel fdDetails){
		Map<String,Object> paramMap = new HashMap<String, Object>();
   		fixedDepositDAOImpl.insertFdAccountDetails(fdDetails);
    }
    
    public void mapFdAccountToUser(FixedDepositModel fdDetails,String bankCode)//bank code added for associate bank by viswa
    {
    	try
        {
    	Map paramMap = new HashMap();
        String creditAccNo = fdDetails.getFdAccountNo();
        String crBranchCode = fdDetails.getFdBranchCode();
        String productCode = fdDetails.getFdAccProductCode();
        String productDesc = "";
           if("0".equals(bankCode)){
        	   logger.info("mapFdAccountToUser (...) ::"+bankCode);
        	   productDesc=fixedDepositUtils.getProductDesc(productCode,bankCode,fdDetails.getTypeOfInterestRate());//bank code added for associate bank by viswa
           }else if("1".equals(bankCode)|| "4".equals(bankCode)||"5".equals(bankCode)||"7".equals(bankCode) || "2".equals(bankCode)){
        	   logger.info("mapFdAccountToUser (...) ::"+bankCode);
        	   productDesc=fixedDepositUtils.getProductDescAssociateBanks(productCode,bankCode);
           }
        String verifyFlag = "1";
        if (productDesc!=null && !productDesc.equalsIgnoreCase("")){
            verifyFlag = "0";
        }
        paramMap.put("userName",fdDetails.getUserName());
        paramMap.put("creditAccNo",creditAccNo );
        paramMap.put("crBranchCode",crBranchCode );
        paramMap.put("productCode",productCode );
        paramMap.put("productDesc",productDesc );
        paramMap.put("verifyFlag",verifyFlag );
        paramMap.put("corporateId",fdDetails.getCorporateId() );
        //insert into cam
        fixedDepositDAOImpl.customerAccountMapDetails(paramMap);
            //remove accounts from cache 
        fixedDepositUtils.clearAccounts(fdDetails.getUserName());
        }catch(Exception e)
        {
            logger.error(e,e);
        }
        
    }
    
/*    public FixedDepositModel createScheduledFixedDepositAccount(Map inputMap){
    	
    	return null;
    }*/
    
    public FixedDepositModel createFixedDepositAccount(Map inputMap)
    {
        String bankCode= (String) inputMap.get("bankCode");
        Map paramMap = getDepositRequestParams(inputMap);
    	FixedDepositModel fixedDepositModel = (FixedDepositModel) inputMap.get("fixedDepositModel");
    	Map responseMap = null;
    	paramMap.put("MODULE_NAME","ETDR");
    	paramMap.put("txnno", FIXED_DEPOSIT_CREATION_TXN_NO);
    	paramMap.put("bankCode", bankCode);
    	String fdReferenceNo = (String) paramMap.get("fdReferenceNo");
    	String referenceNo = (String) paramMap.get("reference_no");
    	String crProductCode = (String) paramMap.get("crProductCode");
    	String autoRenewType=(String)paramMap.get("maturity_instruction");
    	String panNumber = ((String)paramMap.get("pan_no"));
        /* Dev 323 starts here for all banks Maturity Date option */
        if(fixedDepositModel.getSelectedMaturityDate()!=null && fixedDepositModel.getSelectedMaturityDate().trim().length()>0){		        
        	StringTokenizer stk=new StringTokenizer(fixedDepositModel.getSelectedMaturityDate(),"/");
			String dDay = stk.nextToken();
			String dMonth = stk.nextToken();
			String dYear = stk.nextToken();
			String finalVal = String.valueOf(new StringBuilder().append(dDay).append(dMonth).append(dYear));
			logger.info("Maturity Date Chosen -->"+ finalVal);
        	paramMap.put("mat_dt",finalVal);
        }
        /* Dev 323 Ends here */
        
        /* Added for 2000 request parameter change */
        	paramMap.put("mod_indicator","N");
        	paramMap.put("modlinkacc_indicator"," ");        

        /* Added for 2000 request parameter change */
		logger.info("Request Map : " + paramMap);
	
    	 
    	List responseList = postEnquriyToCore(paramMap);
    		
        logger.info("Response List  For 2000 Request --> " + responseList);
        
        
        
        if(responseList!=null && responseList.size()>0){
            responseMap = (HashMap) responseList.get(0);
      
            	String status = (String)responseMap.get("etdr_status");
            	String errorCode = (String) responseMap.get("error_code");
        		//fixedDepositModel = (FixedDepositModel) inputMap.get("fixedDepositModel");
        		fixedDepositModel.setFdReferenceNo(fdReferenceNo);
        		fixedDepositModel.setReferenceNo(referenceNo);
        		
        		
            	if(status!=null && status.equalsIgnoreCase("O.K.")){
            		
    				
                    logger.info("BP fixedDepositModel username::"+fixedDepositModel.getUserName());
            		String statement = (String) responseMap.get("statement");
            		String creditAccNo = "";//"00000000010123456";
            		String creditBranchCode = "";//"03837";
            		String socCode = "";
            		if(statement!= null && statement.length()>0){
            			socCode = statement.substring(0, 3);
            			creditAccNo = statement.substring(3, 14);
            			creditAccNo =String.format("%0" + 17 + "d", new Long(creditAccNo));
            			creditBranchCode = statement.substring(14, 19);
            			
            			if((creditBranchCode!=null && creditBranchCode.substring(0,1).equalsIgnoreCase("1"))
            				&& bankCode!=null && bankCode.equalsIgnoreCase("0")	)
            				creditBranchCode = creditBranchCode.replaceFirst("1", "A");
            			
            			fixedDepositModel.setFdAccountNo(creditAccNo);
            			fixedDepositModel.setFdBranchCode(creditBranchCode);
            			logger.info("------ FD Branch Code ---->"+fixedDepositModel.getFdBranchCode());
            			fixedDepositModel.setFdAccProductCode(crProductCode);
            			fixedDepositModel.setSocCode(socCode);
            			logger.info("SOC CODE : " + socCode + " Credit Account NO : " + creditAccNo +  " Credit Branch Code : " + creditBranchCode);
            			
            			fixedDepositModel.setAutoRenewType(autoRenewType);
            			String autoRenewDescription = getAutoRenewDetails(autoRenewType);
            			logger.info("Auto Renew Type -->"+fixedDepositModel.getAutoRenewType());
            			fixedDepositModel.setAutoRenewDescription(autoRenewDescription);
            			logger.info("Auto Renew Description -->"+fixedDepositModel.getAutoRenewDescription());
            			//by uday
            			
            			/*if("0".equals(bankCode)){
            				fixedDepositModel.setPanNo(panNumber);
            			}else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)) {
            				fixedDepositModel.setPanNo(" ");
            			}*/
            			
            		}
            		
            		/*
            		if (bankCode!= null && bankCode.equals("0")&& creditBranchCode.substring(0).equals(1)){
            			
            			creditBranchCode = creditBranchCode.substring(0).replace("1", "A");
            		}*/
            		
            		fixedDepositDAOImpl.updateFdAccountDetails(fixedDepositModel);
            	}
            	
            	else if(errorCode!=null && !errorCode.equalsIgnoreCase(""))
            	{
            		SBIApplicationException.throwException(errorCode);
            	}
            	/*else {
            		SBIApplicationException.throwException("F1");
            	}*/
           
            
        	}
        else
        {
        	SBIApplicationException.throwException("SE002");
        }
        	
    	return fixedDepositModel;
    }
     
    public void enableModeOfOperation(FixedDepositModel fixedDepositModel,String bankCode)throws SBIApplicationException{
	logger.info("enableModeOfOperation ::"+fixedDepositModel.getFdAccountNo() +" :: "+fixedDepositModel.getFdAccNature());
		Map requestMap = new HashMap();
    	requestMap.put("txnno","007051");
        //requestMap.put("bankCode","0");
        requestMap.put("bankCode",bankCode);//bank code added for associate bank by viswa
		requestMap.put("account_no",fixedDepositModel.getFdAccountNo());
		requestMap.put("reference_no",fixedDepositModel.getReferenceNo());
		String modeOfOperation=fixedDepositModel.getFdAccNature();
		
		if(modeOfOperation==null || (modeOfOperation!=null && modeOfOperation.trim().equals("") )) {
			SBIApplicationException.throwException("FD026");
		}
		else if(modeOfOperation != null && "SINGLE".equalsIgnoreCase(modeOfOperation))
	    {
			requestMap.put("single","1");
	    }
		else if(modeOfOperation != null && "EITHER OR SURVIVOR".equalsIgnoreCase(modeOfOperation))
	    {
        	requestMap.put("either_or_survivor","1");
	    }
		else if(modeOfOperation != null && "ANY A/C HOLD OR SURV".equalsIgnoreCase(modeOfOperation)){
			requestMap.put("any_acc_holder","1");
		}
		else if(modeOfOperation != null && "POWER OF ATTORNEY".equalsIgnoreCase(modeOfOperation.trim())){
			requestMap.put("power_of_attorney","1");
		}
		else if(modeOfOperation != null && "FORMER OR SURVIVOR".equalsIgnoreCase(modeOfOperation.trim())){
			requestMap.put("former_or_survivor","1");
		}
		else if(modeOfOperation != null && "LATTER OR SURVIVOR".equalsIgnoreCase(modeOfOperation.trim())){
			requestMap.put("later_or_survivor","1");
		}
		else if(modeOfOperation != null && "ALL A/C HOLD OR SURV".equalsIgnoreCase(modeOfOperation.trim())){
			requestMap.put("all_acc_holder","1");
		}
		else
            SBIApplicationException.throwException("FD023");

		logger.info("mode of operation requestMap ::"+requestMap);
        postEnquriyToCore(requestMap);
            
}

public String findAccountSubCategoryForABs(String productCode,String cumulativeType,String bankCode,String segmentCode) {
	logger.info("findAccountSubCategoryForABs(String productCode,String cumulativeType,String bankCode,String segmentCode) method begins ");
    
    String accountType="";
    if(cumulativeType.equals("STDR")){
        accountType="25"; 
    }else if(cumulativeType.equals("TDR")){
        accountType="20";     
    }
    
    StringBuilder sbf = new StringBuilder();
	List productList = new ArrayList();
	String actType = "";
	
	// Product code taken from the DB
	int chkCount = fixedDepositDAOImpl.chkDebitProductCodeExists(productCode,bankCode,segmentCode);	
	if(chkCount>0){
		productList = fixedDepositDAOImpl.getProductCodeList(productCode,bankCode,segmentCode);
		int productListSize = productList.size();
		for(int index=0;index<productListSize;index++){
			FDProductCodeModel productMap = (FDProductCodeModel)productList.get(index);				
			accountType = String.valueOf(sbf.append(accountType).append(productMap.getCustomer_type()).append(productMap.getCustomer_category()));
			logger.info("Account type in daoimpl"+accountType);
		}
	} else {
		SBIApplicationException.throwException("FD042");
	}
    
	logger.info("debit productCode ::"+productCode+"accountType : " + accountType +" findAccountSubCategory(...) method ends ");
    
    logger.info("account type is"+accountType);   
    return accountType;
}
/*public String fdSegmentCodeFinderForABs(String debitProductCode,String fdProductCode,String bankCode){
    logger.info("fdSegmentCodeFinderForABs(..) Starts Here");
    
    String segmentCode = "";
  	FDProductCodeModel productMap = null;
    
	List productList = fixedDepositDAOImpl.getProductCodeList(debitProductCode,bankCode);
	int productListSize = productList.size();
	for(int index=0;index<productListSize;index++){
		productMap = (FDProductCodeModel)productList.get(index);			
		segmentCode = productMap.getSegmentCode();
    }
	logger.info("segmentCode -->"+segmentCode);
	if(segmentCode == null || "".equals(segmentCode)) {
        	SBIApplicationException.throwException("FD011");
    }  
    logger.info("segmentCode"+segmentCode);
    
    return segmentCode; 
    
}*/
    

	public Map construct7007Request(Map inParam){
		logger.info("construct7007Request Starts here...");
		
		FixedDepositModel fdModel =(FixedDepositModel)inParam.get("fixedDepositModel");
		Map requestMap = getDepositRequestParams(inParam);
		requestMap.put("txnno","007007");
		requestMap.put("bankCode",inParam.get("bankCode"));
		requestMap.put("int_freq",requestMap.get("autoRenewIntFrequency"));
		if(fdModel!=null){
			
	        if(fdModel.isAutoRenewDtMonYr()){
	        	requestMap.put("auto_term_no_day",((Integer)fdModel.getAutoRenewDays()).toString());
	        	requestMap.put("auto_term_no_month",((Integer)fdModel.getAutoRenewMonths()).toString());
	        	requestMap.put("auto_term_no_years",((Integer)fdModel.getAutoRenewYears()).toString());
	        }
	        else{
	        	requestMap.put("auto_term_length",((Integer)fdModel.getAutoRenewTenureInDays()).toString());
	        }			
			requestMap.put("etdr_account_no",fdModel.getFdAccountNo());
			
			if("STDR".equalsIgnoreCase(fdModel.getFdType()) && "B".equalsIgnoreCase(fdModel.getAutoRenewType())){
				requestMap.put("input_trf_acct_no", fdModel.getDebitAccountNo());
				requestMap.put("interest_trf_acct_no", "00000000000000000");
			}
			
			if("C".equalsIgnoreCase(fdModel.getAutoRenewType())){
				if("STDR".equalsIgnoreCase(fdModel.getFdType())){
					requestMap.put("input_trf_acct_no", fdModel.getDebitAccountNo());
				}
				requestMap.put("interest_trf_acct_no", "00000000000000000");				
				requestMap.put("int_code"," ");
				requestMap.put("term_basis"," ");
				requestMap.put("int_freq"," ");
				requestMap.put("auto_term_no_day","0000");
				requestMap.put("auto_term_no_month","0000");
				requestMap.put("auto_term_no_years","0000");
				requestMap.put("auto_term_length","0000");
			}
		}
	
		logger.info("construct7007Request(..) Ends here...");
		return requestMap;
	}
	

	public String getAutoRenewDetails(String autoRenewType){
		logger.info("getAutoRenewDetails(..) Starts here...");

		String description="";
		if("A".equals(autoRenewType)){
			description="Auto Renew with Principal and Interest";
		} else if("B".equals(autoRenewType)){
			description="Auto Renew Principal and repay Interest";
		} else if("C".equals(autoRenewType)){
			description="Repay Principal and Interest";
		}
		logger.info("getAutoRenewDetails(..) Ends here...");
		return description;
	}
	
	
	public String getAutoRenewCode(String autoRenewDesc){
		logger.info("getAutoRenewCode(..) Starts here...");

		String code="";
		if("Auto Renew with Principal and Interest".equalsIgnoreCase(autoRenewDesc)){
			code="A";
		} else if("Auto Renew Principal and repay Interest".equalsIgnoreCase(autoRenewDesc)){
			code="B";
		} else if("Repay Principal and Interest".equalsIgnoreCase(autoRenewDesc)){
			code="C";
		}
		logger.info("getAutoRenewCode(..) Ends here...");
		return code;
	}
	
	public void updateAutoRenewalInfo(FixedDepositModel fixedDepositModel){
		logger.info("updateAutoRenewalInfo(..) Starts here...");
		if(fixedDepositModel!=null){
			fixedDepositDAOImpl.updateAutoRenewalInfo(fixedDepositModel);
		}
		logger.info("updateAutoRenewalInfo(..) Ends here...");
	}

	public Map getFDProductTypeForAutoRenew(FixedDepositModel fixedDepositModel,String accountSubCategory,Double debitAmount,String bankCode,String fdRate) {
		logger.info("getFDProductTypeForAutoRenew(..) Starts here...");
		
		List amountList=null;
		List tenureList=null;
		Map outParams = new HashMap();
		Map fdProductParams = new HashMap();
		Integer autoRenewTotalNoOfDays = (Integer)fixedDepositModel.getAutoRenewTenureInDays();
		if(logger.isInfoEnabled()){
			logger.info("autoRenew Total No. of Days :"+autoRenewTotalNoOfDays);
			logger.info("bankCode :"+bankCode);
			logger.info("Type of Interest Rate:"+fdRate);
		}
	    if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)){
	      	fdProductParams = fixedDepositDAOImpl.getFdAmountDetailsForAssociate(accountSubCategory, autoRenewTotalNoOfDays,bankCode,fdRate,String.valueOf(fixedDepositModel.getFdAmount())) ;
	    }else if("0".equals(bankCode)){	 
	    	fdProductParams = fixedDepositDAOImpl.getFdAmountDetails(accountSubCategory, autoRenewTotalNoOfDays,bankCode,fdRate,String.valueOf(fixedDepositModel.getFdAmount()));
	    }
		amountList=(List)fdProductParams.get("amountList");
		tenureList=(List)fdProductParams.get("tenureList");
		
		logger.info("amountList -->"+amountList);
		logger.info("tenureList -->"+tenureList);

		if(amountList == null && tenureList == null ) {
			SBIApplicationException.throwException("FD022");
		}
		if(amountList != null && amountList.size() > 0){
			fixedDepositModel  = (FixedDepositModel)amountList.get(0);
			logger.info("amountList Max amt in BP -->"+fixedDepositModel.getFdMaxAmount() +" amountList Min amt in BP -->"+fixedDepositModel.getFdMinAmount());            
			if((fixedDepositModel.getFdMinAmount()<=debitAmount)&&(debitAmount<=fixedDepositModel.getFdMaxAmount())){
				outParams.put("fdValidationStatus", "validationSuccess");
			}else{
				outParams.put("fdValidationStatus", "amountValidationFailed");
			}
		}        	
		if(tenureList != null && tenureList.size() > 0) {
			fixedDepositModel  = (FixedDepositModel)tenureList.get(0);
			logger.info("Max days For Maturity Instruction in BP --> "+fixedDepositModel.getMaxTenureDays());
			logger.info("Min days For Maturity Instruction in BP --> "+fixedDepositModel.getMinTenureDays());
			outParams.put("fdValidationStatus", "tenureValidationFailed");
		}
        outParams.put("amountList", amountList);
        outParams.put("tenureList", tenureList);

		logger.info("getFDProductTypeForAutoRenew(..) Ends here...");
		return outParams;
	}
	
	public Map getFDProductTypeForEnquiryTab(String productCode,String cumulativeType,Integer totalNoOfDays,Double debitAmount,String bankCode,String fdRate,String segmentCode){
		logger.info("getFDProductTypeForEnquiryTab(...) Starts Here ..");

		String accountSubCategory = "";
		List amountList = null;
		List tenureList = null;
		Map outParams=new HashMap();
		
		
		
		if("0".equals(bankCode)){
			accountSubCategory = findAccountSubCategory(productCode, cumulativeType,bankCode,segmentCode);	
			logger.info("Account sub category is"+accountSubCategory);
		}else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)) {
			accountSubCategory = findAccountSubCategoryForABs(productCode, cumulativeType,bankCode,segmentCode);
		}
		
		Map fdProductParams = new HashMap();
		if(bankCode!=null && ("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode))){
			fdProductParams = fixedDepositDAOImpl.getFdAmountDetailsForAssociate(accountSubCategory, totalNoOfDays,bankCode,fdRate,String.valueOf(debitAmount)) ;
			logger.info("FD Product params ->"+fdProductParams);
		}else if(bankCode!=null && "0".equals(bankCode)){
			fdProductParams = fixedDepositDAOImpl.getFdAmountDetails(accountSubCategory, totalNoOfDays,bankCode,fdRate,String.valueOf(debitAmount)) ;
		}

		amountList=(List)fdProductParams.get("amountList");
		tenureList=(List)fdProductParams.get("tenureList");
		FixedDepositModel fixedDepositModel  = null;
		logger.info("amountList ::"+amountList+" tenureList ::"+tenureList);
		if(amountList == null && tenureList == null ) {
			SBIApplicationException.throwException("FD022");
		}	        
		if(amountList != null && amountList.size() > 0) {
			fixedDepositModel  = (FixedDepositModel)amountList.get(0);
			logger.info("amountList Max amt in BP "+fixedDepositModel.getFdMaxAmount() +" amountList Min amt in BP "+fixedDepositModel.getFdMinAmount());	            
			if((fixedDepositModel.getFdMinAmount()<=debitAmount)&&(debitAmount<=fixedDepositModel.getFdMaxAmount())){
				outParams.put("fdValidationStatus", "validationSuccess");
			}else{
				outParams.put("fdValidationStatus", "amountValidationFailed");
			}
		}	        	
		if(tenureList != null && tenureList.size() > 0){
			fixedDepositModel  = (FixedDepositModel)tenureList.get(0);
			logger.info("Max days in BP "+fixedDepositModel.getMaxTenureDays());
			logger.info("Min days in BP "+fixedDepositModel.getMinTenureDays());
			outParams.put("fdValidationStatus", "tenureValidationFailed");
		}
		outParams.put("amountList", amountList);
		outParams.put("tenureList", tenureList);

		logger.info("getFDProductTypeForEnquiryTab(...) Ends Here ..");
		return outParams;
	}

	public List construct67050Request(Map inputParams,FixedDepositModel fdModel){
		logger.info("construct67050Request(..) Starts Here");
		Map dobEnquiryMap = new HashMap();
		dobEnquiryMap.put("txnno", "067050");
		dobEnquiryMap.put("customer_number", fdModel.getCustomerNo());
		dobEnquiryMap.put("bankCode", (String)inputParams.get("bankCode"));
		List dobResponseList = postEnquriyToCore(dobEnquiryMap);
		logger.info("construct67050Request(..) Ends Here");
		return dobResponseList;
	}
	
	
	/*public Map validateSBHDoubleInfo(String debitProductCode,String isSBHDouble,String debitAmount,String bankCode) {
		logger.info("validateSBHDoubleInfo(...) - Begin");

		if(logger.isInfoEnabled()) {			
			logger.info("isSBH Double -->"+isSBHDouble);
			
			logger.info("DebitProductCode -->"+debitProductCode);
		}
        
		FixedDepositModel fdModel  = null;
		Map sbhMap = new HashMap();
		sbhMap.put("SbhDouble",isSBHDouble);
		sbhMap.put("cumulativeType","STDR");
		sbhMap.put("autoRenewType","C");
		sbhMap.put("tenureType","daymode");
		//sbhMap.put("isSeniorCitizen",isSeniorCitizen);
		sbhMap.put("debitProductCode", debitProductCode);
		sbhMap.put("amountTransfer", debitAmount);

		String accountSubCategory = findAccountSubCategoryForABs(debitProductCode,"STDR",bankCode);
		logger.info("isSBHDouble SubCat -->"+accountSubCategory);
		Integer totalNoOfdays=new Integer(0);
		Map tenureMap = fixedDepositDAOImpl.getSBHDoubleTenureDetails(accountSubCategory,bankCode);
        logger.info("SBH FD tenureMap -->"+tenureMap);
		List tenureSBHList= (List)tenureMap.get("tenureList");
		
		if(tenureSBHList==null || tenureSBHList.size()==0){
	        	SBIApplicationException.throwException("FD022");
		}
		if(tenureSBHList!=null && tenureSBHList.size()>0){
			fdModel  = (FixedDepositModel)tenureSBHList.get(0);
			sbhMap.put("days",String.valueOf(fdModel.getMinTenureDays()));
			sbhMap.put("fdValidationStatus", "tenureValidationFailed");
			
			logger.info("sbh double MIN_TERM -->"+fdModel.getMinTenureDays());
			logger.info("sbh double MAX_TERM -->"+fdModel.getMaxTenureDays());
		

		totalNoOfdays = (Integer)fdModel.getMinTenureDays();
        logger.info("SBH - Double Total No. of Days ->"+totalNoOfdays);
		}
        Map sbhfdProductParams = fixedDepositDAOImpl.getSBHDoubleFdAmountDetails(accountSubCategory, totalNoOfdays,bankCode);
        logger.info("Sbh double FD productParams -->"+sbhfdProductParams);
        
		List amountList = (List)sbhfdProductParams.get("amountList");
		if(amountList==null || amountList.size()==0){
        	SBIApplicationException.throwException("FD022");
		}

        if(amountList != null && amountList.size() > 0){
            fdModel  = (FixedDepositModel)amountList.get(0);
            
            logger.info("AmountList Max amt in BP :"+fdModel.getFdMaxAmount());
            logger.info("AmountList Min amt in BP :"+fdModel.getFdMinAmount());
            
            if((fdModel.getFdMinAmount()<=new Double(debitAmount))&& (new Double(debitAmount)<=fdModel.getFdMaxAmount())){
            	sbhMap.put("fdValidationStatus", "validationSuccess");
            }else{
            	sbhMap.put("fdValidationStatus", "amountValidationFailed");
            }
        }
        
		sbhMap.put("tenureList", tenureSBHList);
        sbhMap.put("amountList", amountList);
		

		logger.info("validateSBHDoubleInfo(...) - Ends");
		return sbhMap;
	}*/
	
	public String[] getAvailableCoreBalance(Map inputParams) {
		logger.info("getAvailableCoreBalance(...) Starts Here..");
		String[] data = new String[3];
		List response400List = postEnquriyToCore(inputParams);
		if(response400List!=null && response400List.size()>0) {
			Map accEnquiryMap = (Map)response400List.get(0);
			String availBalance =((String)accEnquiryMap.get("avail_balance"));
			String modBalance =  ((String)accEnquiryMap.get("mod_balance")); //DEV -356
			String cifNumber = ((String)accEnquiryMap.get("cif_no"));
			if(modBalance!=null) {
				if(modBalance.endsWith("+")) {
					modBalance = modBalance.substring(0, modBalance.length()-1);
				}
			}
			data[0] = availBalance;
			data[1] = modBalance;
			data[2] = cifNumber;
		}
		logger.info("getAvailableCoreBalance(...) Ends Here..");
		return data;
	}
	
	public int getAuthOption(String userName,String accountNo,String branchCode,Double amount)
	{
		logger.debug("getAuthOption method begins");
		int authOption = 0;

		authOption = fixedDepositDAOImpl.getAuthOption(userName,accountNo,branchCode,amount);		
		logger.info("authOption ::"+authOption);
		
		logger.debug("getAuthOption method ends");
		return authOption;
	}
	
	
	
	public Map getCustomerCifNo(String cifDetails) {
		String cifNo = cifDetails;
		Map outParams = new HashMap();
		if(cifDetails!=null && cifDetails.trim().length()>0) {
			Pattern matches = Pattern.compile("#");
			String[] token = matches.split(cifNo);
			if("success".equalsIgnoreCase(token[0])) {
				outParams.put("cif_no",token[1]);
				outParams.put("modBalFlag","NO");				
			}else if("yes".equalsIgnoreCase(token[0])) {
				outParams.put("cif_no",token[1]);
				outParams.put("modBalFlag","YES");
			}
		}
		return outParams;
	}
	
	public void updateFdAccStatus(FixedDepositModel fixedDepositModel){
		logger.info("updateFdAccStatus(..) Starts here...");
		if(fixedDepositModel!=null){
			fixedDepositDAOImpl.updateFdAccStatus(fixedDepositModel);
		}
		logger.info("updateFdAccStatus(..) Ends here...");
	}
	
	
	public void setCoreDAOImpl(CoreDAOImpl coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}

	public void setCoreTransactionDAOImpl(
			CoreTransactionDAOImpl coreTransactionDAOImpl) {
		this.coreTransactionDAOImpl = coreTransactionDAOImpl;
	}

	public void setFixedDepositDAOImpl(FixedDepositDAO fixedDepositDAOImpl) {
		this.fixedDepositDAOImpl = fixedDepositDAOImpl;
	}
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}


	
}
