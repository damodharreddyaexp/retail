package com.sbi.common.etdr.bp;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.SBIApplicationException;

public class FixedDepositEnquiryBP {
	protected static final Logger logger = Logger.getLogger(FixedDepositEnquiryBP.class);

	private FixedDepositBP fixedDepositBP;
	private FixedDepositUtils fixedDepositUtils;

	private static final String FIXED_DEPOSIT_ENQUIRY_TXN_NO = "000473";

	public Map<String, Object> fixedDepositEnquiryRequest(Map<String, Object> inParam) {
		logger.info("fixedDepositEnquiryRequest(...) Starts here");

		Map<String, Object> paramMap = null;

		FixedDepositModel fixedDepositModel = (FixedDepositModel) inParam.get("fixedDepositModel");

		if (fixedDepositModel != null) {
			
			paramMap = new HashMap<String, Object>();
			String accountType = "";
			String interestCode = "";
			String intFrequency = "";
			String intCat = "";
			String subCat = "";
			String productCode = fixedDepositModel.getDebitProductCode();
			String bankCode = (String) inParam.get("bankCode");
			if (fixedDepositModel.getFdType() != null) {
				if ("STDR".equalsIgnoreCase(fixedDepositModel.getFdType())){
					interestCode = "R";
					intFrequency = "M";
					paramMap.put("input_trf_acct_no", "00000000000000000");
				} else if ("TDR".equalsIgnoreCase(fixedDepositModel.getFdType())) {
					interestCode = "T";
					intFrequency = fixedDepositBP.fdInterestFrequencyFinder(fixedDepositModel.getInterestPayout());
					paramMap.put("input_trf_acct_no", fixedDepositModel.getDebitAccountNo());
					logger.info("the debit Account no is "+ fixedDepositModel.getDebitAccountNo());
				}
			} else {
				logger.info("Fd Type is NULL");
				SBIApplicationException.throwException("SE002");
			}
			logger.info("input_trf_acct_no for 473 req ::" + paramMap.get("input_trf_acct_no"));
			
			

			if("0".equals(bankCode)){
				subCat = fixedDepositBP.findAccountSubCategory(fixedDepositModel.getDebitProductCode(), fixedDepositModel.getFdType(),bankCode,fixedDepositModel.getSegmentCode());
				
			}else  if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)){
	        	subCat = fixedDepositBP.findAccountSubCategoryForABs(fixedDepositModel.getDebitProductCode(), fixedDepositModel.getFdType(),bankCode,fixedDepositModel.getSegmentCode());
	        }
			logger.info("subcat is"+subCat);
			accountType = subCat.substring(0, 4);

			

			if(logger.isInfoEnabled()){
				logger.info("Debit Product Code -->"+fixedDepositModel.getDebitProductCode());
				logger.info("Tenure In Days -->"+fixedDepositModel.getTenureInDays());
				logger.info("subCat -->"+subCat);
				logger.info("bankCode -->"+bankCode);
				logger.info("FixedorFloatType -->"+fixedDepositModel.getTypeOfInterestRate());	
			}

			if("0".equals(bankCode)){
				intCat = fixedDepositBP.fdInterestCategoryFinder(fixedDepositModel.getDebitProductCode(),fixedDepositModel.getTenureInDays(), subCat, bankCode,fixedDepositModel.getTypeOfInterestRate(),String.valueOf(fixedDepositModel.getFdAmount()),fixedDepositModel.getSegmentCode());
			}else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode)){
				intCat = fixedDepositBP.fdInterestCategoryFinderForAssociate(fixedDepositModel.getDebitProductCode(),fixedDepositModel.getTenureInDays(),subCat,bankCode,fixedDepositModel.getTypeOfInterestRate(),String.valueOf(fixedDepositModel.getFdAmount()),fixedDepositModel.getSegmentCode(),fixedDepositModel.getIsSbhDouble());
			}
			String crProductCode = accountType + intCat;
			String validEtdrProdCode = crProductCode.substring(2, 4);

			if(logger.isInfoEnabled()){
				logger.info("BankCode -->" + bankCode);
				logger.info("accountType -->"+accountType);
				logger.info("intCat -->"+ intCat);
				logger.info("e-TDR Product Code -->" + crProductCode);
				logger.info("isEtdrProdCode(3,4) 11,13,14 --> " + validEtdrProdCode);
			}

			if (!validEtdrProdCode.equalsIgnoreCase("11") /*&& !validEtdrProdCode.equalsIgnoreCase("13") && !validEtdrProdCode.equalsIgnoreCase("14")*/) {
				SBIApplicationException.throwException("FD022");
			}

			String dateFormatted = dateFormat(fixedDepositModel.getFdCreationDate(), "dd/MM/yyyy");

			StringTokenizer stkToken = new StringTokenizer(dateFormatted, "/");
			String day = stkToken.nextToken();
			String month = stkToken.nextToken();
			String year = stkToken.nextToken();

			String formattedDateRequest = day + month + year;

			paramMap.put("deposit_start_date", formattedDateRequest);
			logger.info("Deposit Start Date --->" + formattedDateRequest);
			/*
			 * product_type product_sub_category customer_category
			 * term_identifier
			 */
			paramMap.put("product_type", accountType.substring(0, 2));
			paramMap.put("product_sub_category", accountType.substring(2, 4));
			paramMap.put("customer_category", intCat.substring(0, 1));
			paramMap.put("term_identifier", intCat.substring(1, 3));
			paramMap.put("currency", intCat.substring(3, 4));
			paramMap.put("int_code", interestCode);

			if (fixedDepositModel.isDtMonYr()) {
				paramMap.put("term_no_day", ((Integer) fixedDepositModel.getDays()).toString());
				paramMap.put("term_no_month", ((Integer) fixedDepositModel.getMonths()).toString());
				paramMap.put("term_no_years", ((Integer) fixedDepositModel.getYears()).toString());
			} else {
				paramMap.put("term_length", ((Integer) fixedDepositModel.getTenureInDays()).toString());
			}
			paramMap.put("term_basis", "D");
			paramMap.put("term_value", getEnquiryCoreAmount(fixedDepositModel.getFdAmount()));
			paramMap.put("int_freq", intFrequency);
			if("0".equals(bankCode)){
				paramMap.put("currency_type","INR");
			}else if("1".equals(bankCode) || "2".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode)){
				paramMap.put("currency_type"," ");
			}

			logger.info("the request param -->" + paramMap);

		} else {
			logger.info("Fixed Deposit Model is NULL");
			SBIApplicationException.throwException("SE002");
		}
		logger.info("fixedDepositEnquiryRequest(...) Ends here");
		return paramMap;
	}


	public Map fixedDepositEnquiry(Map inputMap) {
		logger.info("fixedDepositEnquiry(..) Starts here");

		logger.info("the inputmap received by the service-------" + inputMap);

		String bankCode = (String) inputMap.get("bankCode");

		Map paramMap = fixedDepositEnquiryRequest(inputMap);

		Map outParams = new HashMap();
		Map responseMap = null;

		paramMap.put("txnno", FIXED_DEPOSIT_ENQUIRY_TXN_NO);
		paramMap.put("bankCode", bankCode);
		logger.info("param map before core request"+paramMap);

		try {
			List responseList = fixedDepositBP.postEnquriyToCore(paramMap);

			logger.info("Response From Core List --> " + responseList);

			if (responseList != null && responseList.size() > 0) {
				responseMap = (HashMap) responseList.get(0);
			} else {
				logger.info("SBIApplicationException Occured in FixedDepositEnquiryBP");
				SBIApplicationException.throwException("FD003");
			}
		} catch (SBIApplicationException e) {
			logger.info("SBIApplicationException Occured in FixedDepositEnquiryBP"+ e.getErrorCode());
			if ("F1".equalsIgnoreCase(e.getErrorCode()) || "F2".equalsIgnoreCase(e.getErrorCode())) {
				SBIApplicationException.throwException("FD003");
			}
		}
		logger.info("the responseMap form the response  --> " + responseMap);
		logger.info("fixedDepositEnquiry(..) Ends here");

		return responseMap;
	}

	public void validateProductCode(String debitProductCode) {
		logger.info("validateProductCode(..) Starts here");

		String oDProductCode = null;
		boolean isODAccount = false;
		

		if (debitProductCode != null) {

			oDProductCode = debitProductCode.substring(0, 2);
			String savecurrentCode = debitProductCode.substring(0, 1);
			

			if(logger.isInfoEnabled()){
				logger.info("debitProductCode -->" + debitProductCode);
				logger.info("is this product code saving/current 0,1 -->"+savecurrentCode);
				logger.info("is this OD prodCode-60 --> "+ oDProductCode);
			}

			if (!"60".equals(oDProductCode) && !"1".equals(savecurrentCode) && !"5".equals(savecurrentCode)) {
				isODAccount=false;
				SBIApplicationException.throwException("FD022");
			}
				
			if ("60".equals(oDProductCode)) {
				isODAccount = true;
			}
		} else{
			SBIApplicationException.throwException("FD003");
		}
		logger.info("validateProductCode(..) Ends here");
	}

	public Map setEnquiryDate( Map inputParams) {
		logger.info("setEnquiryDate(..) Starts here");

		String strMonth = (String) inputParams.get("month");
		String strDate = (String) inputParams.get("date");
		String strYear = (String) inputParams.get("year");
		String tenureType = (String) inputParams.get("tenureType");
		String fixedorfloatType = (String) inputParams.get("FixedorFloattype");
		
		if("floatrate".equalsIgnoreCase(fixedorfloatType)){
			strYear = (String) inputParams.get("floatYear");
			logger.info("Fixed/FloatType --->"+fixedorfloatType +" Float year's Selected -->"+strYear);
		
		}
		Integer totalNoOfDays = null;

		if (tenureType.equalsIgnoreCase("daymode")|| tenureType.equalsIgnoreCase("maturitymode")) {
			totalNoOfDays = new Integer(((String) inputParams.get("days")));
			logger.info("days in daymode" + totalNoOfDays);
		} else {

			if (strDate == null) {
				strDate = "00";
			}

			if (strMonth == null) {
				strMonth = "00";
			}

			if (strYear == null) {
				strYear = "00";
			}

			Integer year = new Integer(strYear);
			Integer month = new Integer(strMonth);
			Integer days = new Integer(strDate);

			inputParams.put("days", strDate);
			inputParams.put("month", strMonth);
			inputParams.put("year", strYear);

			totalNoOfDays = fixedDepositUtils.daysConvertor(year,month, days);

			String floatYr = (String) inputParams.get("year");
			logger.info("year for 5--->" + floatYr);

			if ("floatrate".equalsIgnoreCase(fixedorfloatType) && "5".equals(floatYr)) {
				totalNoOfDays = totalNoOfDays + 1;
				logger.info("Total No. of Days for 5 Years -->"+ totalNoOfDays);
			}

		} 
		inputParams.put("totalNoOfDays", totalNoOfDays);

		logger.info("setEnquiryDate(..) Ends here");
		return inputParams;
	}


	public FixedDepositModel construct473Enquiry(Map inputParams,Integer totalNoOfDays,String intpayout) {
		logger.info("construct473Enquiry(..) Starts here");

		String tenureType =  (String)inputParams.get("tenureType"); 
		//String openingDate = (String)inputParams.get("openingDate");

		FixedDepositModel fixedDeposit = new FixedDepositModel();

		fixedDeposit.setDebitAccountNo((String) inputParams.get("debitAccountNo"));
		fixedDeposit.setDebitBranchCode((String) inputParams.get("debitBranchCode"));
		fixedDeposit.setDebitProductCode((String) inputParams.get("debitProductCode"));
		fixedDeposit.setDebitProductType((String) inputParams.get("debitAccountType"));
		fixedDeposit.setFdAmount(new Double(((String) inputParams.get("amountTransfer"))));
		fixedDeposit.setDays(new Integer(((String) inputParams.get("days"))));
		// Commented since senior citizen is not required for corporate
		
		//fixedDeposit.setIsSeniorCitizen((String) inputParams.get("isSeniorCitizen"));
		logger.info("Deposit Start Date -->"+fixedDepositUtils.convertStringToDate(getSystemDateTime(), "dd/MM/yyyy"));
		/*
		if (openingDate != null) {
			logger.info("Opening Date inside if(..) --> "+ openingDate);
			fixedDeposit.setFdCreationDate(fixedDepositUtils.convertStringToDate(openingDate, "dd/MM/yyyy"));
		 */			
		fixedDeposit.setFdCreationDate(fixedDepositUtils.convertStringToDate(getSystemDateTime(), "dd/MM/yyyy"));
	//	} 
		/*
	 	else {	 
			SBIApplicationException.throwException("FD003");
		}
		 */
		if (tenureType.equalsIgnoreCase("yearmode")) {
			fixedDeposit.setDtMonYr(true);
			fixedDeposit.setYears(new Integer(((String) inputParams.get("year"))));
			fixedDeposit.setMonths(new Integer(((String) inputParams.get("month"))));
		} else {
			fixedDeposit.setDtMonYr(false);
		}
		fixedDeposit.setSelectedMaturityDate((String)inputParams.get("maturityDate"));
		fixedDeposit.setFdType((String) inputParams.get("cumulativeType"));
		fixedDeposit.setTypeOfInterestRate((String) inputParams.get("FixedorFloattype"));

		if (fixedDeposit.getTypeOfInterestRate() != null) {
			if ("floatrate".equalsIgnoreCase(fixedDeposit.getTypeOfInterestRate())) {
				fixedDeposit.setDtMonYr(true);
				fixedDeposit.setYears(new Integer(((String) inputParams.get("year"))));

				if(logger.isInfoEnabled()){
					logger.info("FixedOrFloatType -->"+ fixedDeposit.getTypeOfInterestRate());
					logger.info("Years for Float Rate--->:"+ fixedDeposit.getYears());
				}
			}
		}

		fixedDeposit.setInterestPayout(intpayout);
		fixedDeposit.setTenureInDays(totalNoOfDays);
		fixedDeposit.setTxnRemarks(null);
		logger.info("construct473Enquiry(..) Ends here"+fixedDeposit);
		return fixedDeposit;
	}


	public static String getEnquiryCoreAmount(Double amount) {
		logger.info("getEnquiryCoreAmount(..) Starts here");

		if (amount == null){
			amount = new Double(0.0);
		}
		DecimalFormat f = new DecimalFormat("00000000000000.000");
		String temp = f.format(amount);
		String formattedAmount = temp.replaceAll("\\.", "");

		logger.info("getEnquiryCoreAmount(..) Ends here");
		return formattedAmount;
	}

	public String dateFormat(Date dte,String dateFormat) {
		logger.info("dateFormat(..) Starts here");
		SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);
		String dteFormat=null;
		try {
			dteFormat=sdf.format(dte);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		logger.info("dateFormat(..) Ends here");
		return dteFormat;
	}

	public String getSystemDateTime(){
		Date currentDate = Calendar.getInstance().getTime();
	return new SimpleDateFormat("dd/MM/yyyy").format(currentDate);
	}
	
	public FixedDepositModel populate473Response(Map coreResponseMap){
		logger.info("populate473Response(..) Starts here...");
		FixedDepositModel fdEnquiryModel=new FixedDepositModel();

		String maturityDate = (String) coreResponseMap.get("maturity_date");
		String maturityAmount = (String) coreResponseMap.get("maturity_amount");
		String tdrPayOutAmount = (String) coreResponseMap.get("tdr_payout_amount");
		String interestRate = (String) coreResponseMap.get("interest_rate");
		
		
		if(logger.isInfoEnabled()){
			logger.info("maturity Date -->"+maturityDate);
			logger.info("maturity Amount -->"+maturityAmount);
			logger.info("tdrpayout Amount -->"+tdrPayOutAmount);
			logger.info("interestRate -->"+interestRate);
		}

		fdEnquiryModel.setMaturityDate(maturityDate);
		fdEnquiryModel.setMaturityAmount(maturityAmount);
		fdEnquiryModel.setTdrPayoutAmount(new Double(tdrPayOutAmount));
		fdEnquiryModel.setInterestRate(new Double(interestRate));

		logger.info("populate473Response(..) Ends here...");
		return fdEnquiryModel;
	}

	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}

}