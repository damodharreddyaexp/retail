package com.sbi.common.etdr.bp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CoreTransactionDAOImpl;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.etdr.dao.FixedDepositPreClosureDAO;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
public class FixedDepositPreClosureBP {
	private static final Logger LOGGER = Logger.getLogger(FixedDepositPreClosureBP.class);

	private FixedDepositBP fixeddepositBP;
	private FixedDepositUtils fixedDepositUtils;
	private FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl;
	private CoreTransactionDAOImpl coreTransactionDAOImpl;



	/*public List postPreclosureToCore(Map requestMap) throws DAOException,SBIApplicationException{
		LOGGER.info("postPreclosureToCore(..) Starts here...");

		List responseList = coreTransactionDAOImpl.getDataFromBankSystem(requestMap);
		LOGGER.info("Core Response For Txnno -->"+requestMap.get("txnno")+" --> "+responseList);

		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);

			String txnno=(String)requestMap.get("txnno");
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");

			if(LOGGER.isInfoEnabled()){
				LOGGER.info("Status -->"+status);
				LOGGER.info("ErrorCode -->"+errorCode);
				LOGGER.info("Statement -->"+statement);
			}

			//for 003045 if status is null response had been received from core.
			if(status!=null && status.equalsIgnoreCase("F1") && !"003045".equals(txnno)){
				SBIApplicationException.throwException("FP005");// unable to process the request please retry again.
			} else if(status!=null && "F1".equalsIgnoreCase(status) && "003045".equals(txnno)){
				SBIApplicationException.throwException("FP003"); 
				//ErrorMessage displays : Check your credit account for pre closure credit. If there is no such credit, then please retry pre closure
			}

			// Unable to Connect to Core
			if(status!=null && status.equalsIgnoreCase("F2")){
				SBIApplicationException.throwException("FP005"); // unable to process the request please retry again.
			}

			if(status!=null && status.equalsIgnoreCase("ERR.")){
				if(errorCode!=null && "0110".equals(errorCode.trim())){ 
					SBIApplicationException.throwException("FD004");//Fixed Deposit Account is already Closed
				}else{
					SBIApplicationException.throwException("FD027"); // Due to some technical
				}
			}
		}        
		LOGGER.info("postPreclosureToCore(..) Ends here...");

		return responseList;
	}*/

	/* Code From Jyothi Puram Starts here */

	public FixedDepositModel getPreClosureCreditDetails(Map requestMap)  throws DAOException, SBIApplicationException {
		LOGGER.info("getPreClosureCreditDetails(..) Starts here");

		String fdAccountNo=	(String)requestMap.get("fdAccountNo");
		String bankCode=	(String)requestMap.get("bankCode");

		if(LOGGER.isInfoEnabled()){
			LOGGER.info("Fd Account No -->" + fdAccountNo);
			LOGGER.info("Bank Code -->" + bankCode);
		}

		FixedDepositModel fixedDepositModel = null;		
		List<FixedDepositModel> preClosureDetails = new ArrayList<FixedDepositModel>();

		if (fdAccountNo != null) {
			
			preClosureDetails = fixedDepositPreClosureDAOImpl.getPreClosureDetails(fdAccountNo);
		}

		if (preClosureDetails != null && preClosureDetails.size()>0) {
			fixedDepositModel = preClosureDetails.get(0);

			fixedDepositModel = getFdDetailsFromDB(requestMap, fixedDepositModel);
 
			if(fixedDepositModel.getMaturityAmount()!=null && fixedDepositModel.getMaturityAmount().trim().length() > 0) 
		{

				double	maturityAmt=Double.parseDouble(fixedDepositModel.getMaturityAmount().trim());

				if(LOGGER.isInfoEnabled()){
					LOGGER.info("the maturity amount "+fixedDepositModel.getMaturityAmount());
					LOGGER.info("the maturity amount "+maturityAmt);
				}

				
				
				if(maturityAmt > 0) {  

					LOGGER.info("Maturity Amount inside if(maturityAmount>0) -->"+maturityAmt);

					/* Enquiry txnno 474 For getting the info about penality amount while preclosing Starts Here*/ 
					//if("0".equals(bankCode)){
						Map request474Map = construct474Request(fixedDepositModel, bankCode);
						List response474List = fixeddepositBP.postEnquriyToCore(request474Map);
						Map responseMap = (Map)response474List.get(0);
						if(!"ERR.".equals(responseMap.get("status"))){
							if (response474List != null && response474List.size() > 0) {
								fixedDepositModel = populate474Response(response474List, fixedDepositModel);
						}
					  }
					//}
				/* Enquiry txnno 474 For getting the info about penality amount while preclosing Ends Here */
		}else {
			LOGGER.error("Unable to retrieve the data Exception Occured...");
			SBIApplicationException.throwException("FD003");
		}
		
		}else {
			LOGGER.error("Unable to retrieve the data Exception Occured...");
			SBIApplicationException.throwException("FD003");
		}
	}else {
		LOGGER.error("Unable to retrieve the data Exception Occured...");
		SBIApplicationException.throwException("FD003");
	}
	LOGGER.info("getPreClosureCreditDetails(..) Ends here");
	return fixedDepositModel;
	}

	
	
	
	private FixedDepositModel getFdDetailsFromDB(Map requestMap,FixedDepositModel fixedDepositModel) {
		
		List FdDetails=null;
		String bankCode=(String) requestMap.get("bankCode");
		String userName=(String ) requestMap.get("userName");
		String fdaccountNo=(String) requestMap.get("fdAccountNo");
		String fdAccountNo= requestMap.get("fdAccountNo").toString();
		LOGGER.info("bankCode is" +bankCode+"userName is"+userName+"fdAccountNo is"+fdaccountNo);
		FdDetails=(List) fixedDepositPreClosureDAOImpl.getFddetails(userName, bankCode,fdAccountNo,fixedDepositModel.getCorporateId());
		if (FdDetails!=null && FdDetails.size()>0)
		
		{
			
				FixedDepositModel fdmodel= (FixedDepositModel) FdDetails.get(0);  
				
				fixedDepositModel.setInterestRate(fdmodel.getInterestRate());
				fixedDepositModel.setMaturityAmount(fdmodel.getMaturityAmount().toString());		
				fixedDepositModel.setDebitBranchCode(fdmodel.getDebitBranchCode());
				fixedDepositModel.setValueDate(fdmodel.getValueDate());
				fixedDepositModel.setFdCreationDate(fdmodel.getFdCreationDate());
				fixedDepositModel.setYears(fdmodel.getYears());
				fixedDepositModel.setMonths(fdmodel.getMonths());
				fixedDepositModel.setDays(fdmodel.getDays());
				fixedDepositModel.setTenureInDays(fdmodel.getTenureInDays());
				
					
				}
		
		
		
		
		return fixedDepositModel;		
	}
	
	// SR 87929 start
	private Integer emptyStringCheckForInteger(String responseString)
    {
        Integer intValue = new Integer(DAOConstants.ZERO);
        if (responseString != null && responseString.trim().length()>0)
        {
            try
            {
                intValue = new Integer(responseString);
            }
            catch (NumberFormatException nfx)
            {
            	LOGGER.fatal(LoggingConstants.EXCEPTION, nfx);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }
        if (LOGGER.isDebugEnabled())
        {
        	LOGGER.debug("intValue :" + intValue);
        }
        return intValue;
    }
	
	public Map construct474Request(FixedDepositModel fdPreClosureModel,String bankCode){
		LOGGER.info("construct474Request(..) Starts here...");		
		
		Calendar currentDate = Calendar.getInstance();
	

		
		String closing_date= new SimpleDateFormat("ddMMyyyy").format(currentDate.getTime());
		
		
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("BankCode -->"+bankCode);
			LOGGER.info("eTDR/eSTDR AccountNo -->"+fdPreClosureModel.getCreditAccountNo().trim());			
			LOGGER.info("Break Out Value -->"+StringUtils.getCoreAmount(0.00));
			LOGGER.info("Closing Date -->"+closing_date); // System Date
		}
		
		final Map<String,Object> requestMap = new LinkedHashMap<String,Object>();
		
		requestMap.put("txnno","000474");
		requestMap.put("bankCode",bankCode);
		requestMap.put("account_no",fdPreClosureModel.getCreditAccountNo().trim());
		requestMap.put("breakout_value",StringUtils.getCoreAmount(0.00));
		requestMap.put("closing_date",closing_date); 
				
		LOGGER.info("construct474Request(..) Ends here..."+requestMap);
		return requestMap;
			}

	public FixedDepositModel populate474Response(List coreResponseList, FixedDepositModel preModel){
		LOGGER.info("populate474Response(..) Starts here...");

		final Map coreResponse=(Map)coreResponseList.get(0);
		final String amount_payable=(String)coreResponse.get("amount_payable");
		final String rate=(String)coreResponse.get("rate");
		final String penality_amount=(String)coreResponse.get("penality_amount");

		preModel.setAmountPayable(StringUtils.convertCoreAmtFormatToAmount(amount_payable,"3decimalNoSign"));
		preModel.setRate(StringUtils.convertCoreAmtFormatToAmount(rate,"4decimalNoSign"));
		preModel.setPenalityAmount(StringUtils.convertCoreAmtFormatToAmount(penality_amount));
		
		if(LOGGER.isInfoEnabled()){
			LOGGER.info("Amount Payable -->"+preModel.getAmountPayable());
			LOGGER.info("Rate -->"+preModel.getRate());			
			LOGGER.info("Penality Amount -->"+preModel.getPenalityAmount());			
			}
	
		LOGGER.info("populate474Response(..) Ends here...");
		return preModel;
	}
	public void setFixedDepositPreClosureDAOImpl(
			FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl) {
		this.fixedDepositPreClosureDAOImpl = fixedDepositPreClosureDAOImpl;
	}
	public void setCoreTransactionDAOImpl(
			CoreTransactionDAOImpl coreTransactionDAOImpl) {
		this.coreTransactionDAOImpl = coreTransactionDAOImpl;
	}
	public void setFixeddepositBP(FixedDepositBP fixeddepositBP) {
		this.fixeddepositBP = fixeddepositBP;
	}
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}
}