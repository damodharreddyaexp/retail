/*     
 * Created on Aug 30, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $    
 */
//History
//Aug 30, 2006 MEENA K. - Initial Creation
package com.sbi.common.etdr.bp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CoreTransactionDAOImpl;
import com.sbi.common.etdr.dao.EtdrMasterDAO;
import com.sbi.common.etdr.model.EtdrMaster;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.StringUtils;

public class EtdrTransactionManageBP {
	
	protected final Logger logger = Logger.getLogger(getClass());

	private EtdrMasterDAO etdrMasterDAOImpl;

	public static final String NC_DEBIT_ACCOUNT_DATA = "010|011|016|017";

	private FixedDepositBP fixedDepositBP;
	
	private BaseService fixedDepositPaymentConfirmService;
	
	private FixedDepositUtils fixedDepositUtils;
	
	private CoreTransactionDAOImpl coreTransactionDAOImpl;

	public List getEtdrPendingRequests(String userName) {
		logger.info("getEtdrPendingRequests(String userName)method begins ");
		List etdrPendingList = null;
		
		if (userName != null) {
			try {
			
				etdrPendingList = etdrMasterDAOImpl.getEtdrPendingRequests(userName);
				
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("getEtdrPendingRequests(String userName)method ends  :");
		return etdrPendingList;

	}
	public EtdrMaster getEtdrDetails(String referenceNo) {
		logger.info("getEtdrDetails(String referenceNo)method begins ");
		EtdrMaster etdrMaster = null;
		if (referenceNo != null) {
			try {

				etdrMaster = etdrMasterDAOImpl.getEtdrDetails(referenceNo);

			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("getEtdrDetails(String referenceNo)method ends  :");
		return etdrMaster;

	}
	public Map authorizeEtdrTransaction(Map inparams) {
		logger.info("authorizeEtdrTransaction(Map inparams) method begins ");
		EtdrMaster etdrMaster = (EtdrMaster)inparams.get("etdrMaster");
		String userName = (String)inparams.get("userName");
		int authorizeCount;
		Map outParams=new HashMap();
			try {
				if(userName != null){
				etdrMaster=modifyAuthorizationParameter(etdrMaster, userName);
				
				if("0".equals(etdrMaster.getCurrentAuthLevel())){
					outParams=doEtdrTransactions(inparams);
				}
				else if ("2".equals(etdrMaster.getCurrentAuthLevel())){
					authorizeCount=etdrMasterDAOImpl.sendForSecondLevelAuthorize(inparams);
					SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
					outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
				}
			}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		logger.info("authorizeEtdrTransaction(Map inparams) method ends  :");
		return outParams;

	}
	
	private EtdrMaster modifyAuthorizationParameter(EtdrMaster etdrMaster,String userName)
	{
		logger.info("modifyAuthorizationParameter(EtdrMaster etdrMaster,String userName) method begins ");
		int currentAuthlevelint = new Integer (etdrMaster.getCurrentAuthLevel()).intValue();
		logger.info("Auth Type : "+etdrMaster.getAuthType());
		String userAuthType=etdrMaster.getAuthType();
		/*--- Auth Type should be checked for Single Authorization and First Level Authorization and Not for Second Level Authorization ---*/
		if(currentAuthlevelint!=2){
				 userAuthType=(
						 etdrMasterDAOImpl.findUserAuthType(etdrMaster.getDebitAccountNo(),etdrMaster.getDebitBranchCode(),etdrMaster.getFdAmount(),userName))+"";
				 etdrMaster.setAuthType(userAuthType);
		}
		
		if(etdrMaster.getAuthType().equals("0"))//single
		{
			String currentAuthLevel =etdrMaster.getCurrentAuthLevel();
			logger.info("Single ::::  Current Auth Level : "+currentAuthLevel);
			if(currentAuthLevel.equalsIgnoreCase("1"))
			{ 
				etdrMaster.setAuth1Name(userName);
			}
			// Auth level checking and set the auth type.
			if(currentAuthlevelint > 1)
		    {
				etdrMaster.setAuthType("1");
		    }
			else
			{
				etdrMaster.setAuthType("0");
			}			
			
			etdrMaster.setCurrentAuthLevel("0");
			

		}
		else // two level authorization
		{
			logger.info("Two level ::::  Current Auth Level : "+currentAuthlevelint);
			if(currentAuthlevelint==1) // first level authorization
			{
				etdrMaster.setAuth1Name(userName);
				etdrMaster.setCurrentAuthLevel("2");
			} 
			else
			{
				etdrMaster.setAuth2Name(userName);
				etdrMaster.setCurrentAuthLevel("0");
			}
		}
	  	
		logger.info("Authorization authorizeEcheques(AuthorizationBP) ****  modifyAuthorizationParameter for echequeNo " +etdrMaster.getReferenceNo()+ " ::: Auth type : "+etdrMaster.getAuthType());
	
		logger.info("modifyAuthorizationParameter(EtdrMaster etdrMaster,String userName) method END ");
		return  etdrMaster;
	}	
	
	public Map doEtdrTransactions(Map inparams) {
		logger.info("doEtdrTransactions(Map inparams)method begins ");
		EtdrMaster etdrMaster = (EtdrMaster)inparams.get("etdrMaster");
		FixedDepositModel fixedDepositModel = new FixedDepositModel(); 
		String userName = (String)inparams.get("userName");
		String bankCode = (String)inparams.get("bankCode");
		Integer smallFlag = (Integer)inparams.get("smallFlag");
		int authorizeCount;
		
		Map outParams=null;
			try {
				Map enquiryMap = new HashMap();
				enquiryMap.put("account_no", etdrMaster.getDebitAccountNo());
				enquiryMap.put("txnno", Constants.SHORT_ENQ_DEPOSITS_TXNNO);
				enquiryMap.put("bankCode", bankCode);
				//400 txn enquiry
				Map cifEnquiryMap = fixedDepositBP.retrieveCIFNumberOnly(enquiryMap, etdrMaster.getFdAmount());
				String cifNo=(String)cifEnquiryMap.get("cif_no");
				String segmentCode=(String)cifEnquiryMap.get("segment_code");
				logger.info("CIF Number ::" + cifNo);
				logger.info("segmentCode ::" + segmentCode);
				inparams.put("cifNo",cifNo);
				inparams.put("segment_code",segmentCode);
				if (cifNo != null)
				{
					fixedDepositModel=constructFdModel(etdrMaster,inparams);
					fixedDepositModel.setSmallFlag(smallFlag);
					inparams.put("fixedDepositModel", fixedDepositModel);
					outParams=fixedDepositPaymentConfirmService.execute(inparams);
				}
				else
				{
					SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
					applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
					applicationResponse.setErrorCode("FD003");
					outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
				}
				
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
			logger.info("doEtdrTransactions(Map inparams)method ends ");
		return outParams;

	}
	
	public FixedDepositModel constructFdModel(EtdrMaster etdrMaster,Map inparams)
	{
		logger.info(" constructFdModel method begins");
		FixedDepositModel fixedDeposit = new FixedDepositModel();
		fixedDeposit.setDebitAccountNo(etdrMaster.getDebitAccountNo());
		fixedDeposit.setDebitHolderName(etdrMaster.getDebitHolderName());
		fixedDeposit.setDebitBranchCode(etdrMaster.getDebitBranchCode());
		fixedDeposit.setUserName(etdrMaster.getUserName());
		fixedDeposit.setDebitProductCode(etdrMaster.getProductCode());
		fixedDeposit.setDebitProductType(etdrMaster.getProductType());
		fixedDeposit.setFdAmount(etdrMaster.getFdAmount());
		fixedDeposit.setPreClosureReferenceNo(etdrMaster.getPreCloseReferenceNo());
		fixedDeposit.setPreClosureRemarks(etdrMaster.getPreCloseRemarks());
		fixedDeposit.setFdAccountNo(etdrMaster.getFdAccountNo());
		fixedDeposit.setFdCreationDate(etdrMaster.getCreationTime());
		fixedDeposit.setCorporateId(etdrMaster.getCorporateId());
		
		int totalNoOfDays=0;
		String tenureType=etdrMaster.getTenureType();
		if (tenureType.equalsIgnoreCase("daymode") || tenureType.equalsIgnoreCase("maturitymode"))
		{
			totalNoOfDays = etdrMaster.getTenure();
			logger.info("days in daymode or maturity mode" + totalNoOfDays);
		}
		else
		{
			//for year mode
			int days = 0;
			int month =0; 
			int year = 0;
			
			if(etdrMaster.getTenureDay()>0)
				days=etdrMaster.getTenureDay();
			if(etdrMaster.getTenureMonth()>0)
				month=etdrMaster.getTenureMonth();
			if(etdrMaster.getTenureYear()>0)
				year=etdrMaster.getTenureYear();
			totalNoOfDays = fixedDepositUtils.daysConvertor(year,month,days);
			logger.info("total days in year mode" + totalNoOfDays);
		}
		
		fixedDeposit.setTenureInDays(totalNoOfDays);
		fixedDeposit.setDays(etdrMaster.getTenureDay());
		
		fixedDeposit.setScheduled(false);
		if(((String)inparams.get("cifNo")!=null) && ((String)inparams.get("segment_code")!=null))
		{
			fixedDeposit.setCustomerNo((String)inparams.get("cifNo"));
			fixedDeposit.setSegmentCode((String)inparams.get("segment_code"));
		}
		logger.info("etdrMaster.getTenureType()-------"+etdrMaster.getTenureType());
		if ("yearmode".equalsIgnoreCase(etdrMaster.getTenureType()))
		{
			fixedDeposit.setDtMonYr(true);
			fixedDeposit.setYears(etdrMaster.getTenureYear());
			fixedDeposit.setMonths(etdrMaster.getTenureMonth());
		}
		else
		{
			fixedDeposit.setDtMonYr(false);
		}
		logger.info("MaturityDate **********"+etdrMaster.getTenureMaturityDate());

		logger.info("MaturityDate **********"+etdrMaster.getTenureMaturityDate());
		if(etdrMaster.getTenureMaturityDate() != null)
			fixedDeposit.setSelectedMaturityDate(StringUtils.TimestamptoStringFormat(etdrMaster.getTenureMaturityDate()));

		fixedDeposit.setFdType(etdrMaster.getFdType());
		logger.info("etdrMaster.getFdRateType() --------->"+etdrMaster.getFdRateType());
		fixedDeposit.setTypeOfInterestRate(etdrMaster.getFdRateType());
		if(inparams.get("bankCode")!=null)
		{
			String bankCode=((String)inparams.get("bankCode"));
			fixedDeposit.setBankCode(bankCode);
		}
		
		
		if(fixedDeposit.getTypeOfInterestRate()!=null){
			if("floatrate".equalsIgnoreCase(fixedDeposit.getTypeOfInterestRate())){
				logger.info("inside constructFDModel(..) TypeOfInterestRate-->"+fixedDeposit.getTypeOfInterestRate());
				fixedDeposit.setDtMonYr(true);
				fixedDeposit.setYears(etdrMaster.getTenureYear());
				logger.info("Years for Float Rate--->:"+fixedDeposit.getYears());
			}
		}
		fixedDeposit.setInterestPayout(etdrMaster.getInterestPayout());//Quarterly or Maturity for TDR
		logger.info("etdrMaster.getTenureDay() --->"+etdrMaster.getTenureDay());
		fixedDeposit.setTxnRemarks(null);
		fixedDeposit.setCorporateId(fixedDeposit.getCorporateId());
		fixedDeposit.setReferenceNo(etdrMaster.getReferenceNo());
		fixedDeposit.setAuth1Name(etdrMaster.getAuth1Name());
		fixedDeposit.setAuth2Name(etdrMaster.getAuth2Name());
		fixedDeposit.setFdAccNature(etdrMaster.getFdAccountNature());
		fixedDeposit.setInterestRate(etdrMaster.getRateOfInterest());
		String maturityAmount="";
		if(etdrMaster.getMaturityValue()>0)
			maturityAmount=etdrMaster.getMaturityValue().toString();
		fixedDeposit.setMaturityAmount(maturityAmount);
		fixedDeposit.setMaturityDate(StringUtils.TimestamptoStringFormat(etdrMaster.getMaturityDate()));
				
		constructAutoRenewalFdModel(etdrMaster,fixedDeposit);

		logger.info(" constructFdModel method ends");
		return fixedDeposit;
	}
	private FixedDepositModel constructAutoRenewalFdModel(EtdrMaster etdrMaster,FixedDepositModel fixedDeposit){
		logger.info("constructAutoRenewalFdModel(..) Starts Here");
		
		
		String renewalCode = fixedDepositBP.getAutoRenewCode(etdrMaster.getAutoRenewType());
		logger.info("renewalCode***---->"+renewalCode);
		fixedDeposit.setAutoRenewType(renewalCode);
		fixedDeposit.setAutoRenewDescription(etdrMaster.getAutoRenewType());
		logger.info("AutoRenewDescription()****---->"+etdrMaster.getAutoRenewType());
		fixedDeposit.setAutoRenewDays(etdrMaster.getAutoRenewDays());
		fixedDeposit.setAutoRenewInterestPayout(etdrMaster.getAutoRenewInterestPayout());
		
		
		if ("renewalyearmode".equalsIgnoreCase(etdrMaster.getAutoRenewTenureType())){
			fixedDeposit.setAutoRenewDtMonYr(true);
			fixedDeposit.setAutoRenewYears(etdrMaster.getAutoRenewYears());
			fixedDeposit.setAutoRenewMonths(etdrMaster.getAutoRenewMonths());
		} else {
			fixedDeposit.setAutoRenewDtMonYr(false);
		}
		
		String autoRenewTenureType=etdrMaster.getAutoRenewTenureType();
		int autoRenewalTotalNoOfDays=0;
		int autoRenewDay=0;
		int autoRenewMonth=0;
		int autoRenewYear=0;
		
		if ("renewaldaymode".equalsIgnoreCase(autoRenewTenureType)) {
			autoRenewalTotalNoOfDays = etdrMaster.getAutoRenewDays();
			logger.info("days in renewal daymode" + autoRenewalTotalNoOfDays);
		} else {
			if(etdrMaster.getAutoRenewDays()>0)
				autoRenewDay=etdrMaster.getAutoRenewDays();
			if(etdrMaster.getAutoRenewMonths()>0)
				autoRenewMonth=etdrMaster.getAutoRenewMonths();
			if(etdrMaster.getAutoRenewYears()>0)
				autoRenewYear=etdrMaster.getAutoRenewYears();
			
			autoRenewalTotalNoOfDays = fixedDepositUtils.daysConvertor(autoRenewYear,autoRenewMonth,autoRenewDay);
		}	
		
		fixedDeposit.setAutoRenewTenureInDays(autoRenewalTotalNoOfDays);
		
		
		logger.info("FixedDepositModel Information for Maturity Instruction ...>"+fixedDeposit);
		logger.info("constructAutoRenewalFdModel(..) Ends Here");
		return fixedDeposit;
	}
	public int cancelEtdrRequest(Map inparams) {
		logger.info("getEtdrDetails(String referenceNo)method begins ");
		EtdrMaster etdrMaster = null;
		int updateCount=0;
		String referenceNo = (String) inparams.get("referenceNo");
		String userName = (String) inparams.get("userName");
		if (referenceNo != null) {
			try {
				etdrMaster = getEtdrDetails(referenceNo);
				etdrMaster=modifyAuthorizationParameter(etdrMaster, userName);
				updateCount=etdrMasterDAOImpl.cancelEtdrRequest(etdrMaster);
				
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("getEtdrDetails(String referenceNo)method ends  :");
		return updateCount;

	}
	
	public List getPreCloseEtdrPendingRequests(String userName) {
		logger.info("getPreCloseEtdrPendingRequests(String userName)method begins ");
		List etdrPendingList = null;
		EtdrMaster echequeMaster = null;
		if (userName != null) {
			try {

				etdrPendingList = etdrMasterDAOImpl.getPreCloseEtdrPendingRequests(userName);

			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("getPreCloseEtdrPendingRequests(String userName)method ends  :");
		return etdrPendingList;

	}
	
	public EtdrMaster getPreCloseEtdrDetails(String preCloseReferenceNo) {
		logger.info("getPreCloseEtdrDetails(String preCloseReferenceNo)method begins ");
		EtdrMaster etdrMaster = null;
		if (preCloseReferenceNo != null) {
			try {

				etdrMaster = etdrMasterDAOImpl.getPreCloseEtdrDetails(preCloseReferenceNo);

			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("getPreCloseEtdrDetails(String preCloseReferenceNo)method ends  :");
		return etdrMaster;

	}
	public EtdrMaster getPenaltyDetails(Map requestMap)  throws DAOException, SBIApplicationException {
		logger.info("getPenaltyDetails(Map requestMap) Starts here");

		String bankCode=	(String)requestMap.get("bankCode");

		EtdrMaster etdrMaster = (EtdrMaster)requestMap.get("etdrMaster");
		
		if(etdrMaster.getMaturityValue()!=null && etdrMaster.getMaturityValue() > 0) {

			logger.info("the maturity amount "+etdrMaster.getMaturityValue());
			
			if(etdrMaster.getMaturityValue() > 0) {  
				
				//if("0".equals(bankCode)){
					
					Map request474Map = construct474Request(etdrMaster, bankCode);
					
					//txnno 474 -penalty details
					List response474List = fixedDepositBP.postEnquriyToCore(request474Map);
					Map responseMap = (Map)response474List.get(0);
					if(!"ERR.".equals(responseMap.get("status"))){
						if (response474List != null && response474List.size() > 0) {
							etdrMaster = populate474Response(response474List, etdrMaster);
					}
				  }
				//}
		}else {
			logger.error("Unable to retrieve the data Exception Occured...");
			SBIApplicationException.throwException("FD003");
		}
		
		}else {
				logger.error("Unable to retrieve the data Exception Occured...");
				SBIApplicationException.throwException("FD003");
		}
		logger.info("getPenaltyDetails(Map requestMap) Ends here");
		return etdrMaster;
	}
	
	public Map construct474Request(EtdrMaster etdrMaster,String bankCode){
		logger.info("construct474Request(..) Starts here...");		
		
		Calendar currentDate = Calendar.getInstance();
		String closing_date= new SimpleDateFormat("ddMMyyyy").format(currentDate.getTime());
		
		logger.info("BankCode -->"+bankCode);
		logger.info("Fd AccountNo -->"+etdrMaster.getFdAccountNo());			
		logger.info("Break Out Value -->"+StringUtils.getCoreAmount(0.00));
		logger.info("Closing Date -->"+closing_date); // System Date
		
		final Map<String,Object> requestMap = new LinkedHashMap<String,Object>();
		
		requestMap.put("txnno","000474");
		requestMap.put("bankCode",bankCode);
		requestMap.put("account_no",etdrMaster.getFdAccountNo());
		requestMap.put("breakout_value",StringUtils.getCoreAmount(0.00));
		requestMap.put("closing_date",closing_date);
				
		logger.info("construct474Request(..) Ends here..."+requestMap);
		return requestMap;
	}
	
	public EtdrMaster populate474Response(List coreResponseList, EtdrMaster etdrMaster){
		logger.info("populate474Response(..) Starts here...");

		final Map coreResponse=(Map)coreResponseList.get(0);
		final String amount_payable=(String)coreResponse.get("amount_payable");
		final String rate=(String)coreResponse.get("rate");
		final String penality_amount=(String)coreResponse.get("penality_amount");
		
		etdrMaster.setPenaltyAmountPayable(StringUtils.convertCoreAmtFormatToAmount(amount_payable,"3decimalNoSign"));
		etdrMaster.setPenaltyRateOfInterest(StringUtils.convertCoreAmtFormatToAmount(rate,"4decimalNoSign"));
		etdrMaster.setPenaltyAmount(StringUtils.convertCoreAmtFormatToAmount(penality_amount));
		
		logger.info("Amount Payable -->"+etdrMaster.getPenaltyAmountPayable());
		logger.info("Rate -->"+etdrMaster.getPenaltyRateOfInterest());			
		logger.info("Penalty Amount -->"+etdrMaster.getPenaltyAmount());			
	
		logger.info("populate474Response(..) Ends here...");
		return etdrMaster;
	}
	public Map authorizePreCloseEtdrTransaction(Map inparams) {
		logger.info("authorizePreCloseEtdrTransaction(Map inparams)method begins ");
		EtdrMaster etdrMaster = (EtdrMaster)inparams.get("etdrMaster");
		String userName = (String)inparams.get("userName");
		int authorizeCount;
		Map outParams=new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		
			try {
				etdrMaster.setCurrentAuthLevel(etdrMaster.getPreCloseCurrentAuthLevel());
				etdrMaster=modifyAuthorizationParameter(etdrMaster, userName);
				
				if("0".equals(etdrMaster.getCurrentAuthLevel())){
					outParams=doPreCloseEtdrTransactions(inparams);
				}
				else if ("2".equals(etdrMaster.getCurrentAuthLevel())){
					authorizeCount=etdrMasterDAOImpl.sendForSecondLevelPreCloseAuthorize(inparams);
					SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
					outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
				}

			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		logger.info("authorizePreCloseEtdrTransaction(Map inparams)method ends  :");
		return outParams;

	}
	public Map doPreCloseEtdrTransactions(Map inparams) {
		logger.info("doEtdrTransactions(Map inparams)method begins ");
		EtdrMaster etdrMaster = (EtdrMaster)inparams.get("etdrMaster");
		FixedDepositModel fixedDepositModel = new FixedDepositModel(); 
		String userName = (String)inparams.get("userName");
		String bankCode = (String)inparams.get("bankCode");
		int authorizeCount;
		
		Map outParams=new HashMap();
		List response3045List=new ArrayList();
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		
			try {
					
				fixedDepositModel=constructFdModel(etdrMaster,inparams);
				
				 //If Mode Of Operation is matched then fire 3045 Request for FD PreClosure   
				Map request3045Map = construct3045Request(fixedDepositModel, bankCode);
				response3045List = postPreclosureToCore(request3045Map);

				if (response3045List != null && response3045List.size() > 0) {
					populate3045Response(response3045List, fixedDepositModel);
					fixedDepositModel.setAuthStatus("FinalAuthorization");
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
				
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
			logger.info("doPreCloseEtdrTransactions(Map inparams)method ends ");
			outParams.put("fixedDepositModel",fixedDepositModel);
			outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		return outParams;

	}
	public Map construct3045Request(FixedDepositModel fdPreClosureModel,String bankCode){
		logger.info("construct3045Request Starts here...");

		final Map<String,Object> requestMap = new LinkedHashMap<String,Object>();
		fdPreClosureModel.setCoreTxnTobeFired("003045");

		logger.info("Preclosure Reference No -->" + fdPreClosureModel.getPreClosureReferenceNo());
		logger.info("DebitAccountNo -->"+fdPreClosureModel.getFdAccountNo());			
		logger.info("CreditAccountNo -->"+fdPreClosureModel.getDebitAccountNo());
		logger.info("PreClosureRemarks -->"+fdPreClosureModel.getPreClosureRemarks());
		logger.info("DebitBranchCode -->"+fdPreClosureModel.getDebitBranchCode());
		logger.info("FdAmount -->"+fdPreClosureModel.getFdAmount());
		
		requestMap.put("txnno","003045");
		requestMap.put("bankCode",bankCode);		
		requestMap.put("reference_no",fdPreClosureModel.getPreClosureReferenceNo().trim());
		requestMap.put("from_account_number",fdPreClosureModel.getFdAccountNo().trim());		
		requestMap.put("to_account_number",fdPreClosureModel.getDebitAccountNo().trim());
		 requestMap.put("amount","0");
		//requestMap.put("amount",fdPreClosureModel.getFdAmount());
		requestMap.put("currency","INR");
		requestMap.put("usernarration",fdPreClosureModel.getPreClosureRemarks());
		requestMap.put("customer_ref_no"," ");		
		requestMap.put("sbi_ref_no"," ");

		/* Starts here for mapping in request used in TransactionLegs in (CoreMapToBankSystemComModelCOnverter.java) for txnno: 3045*/
		requestMap.put("fd_branch_code",fdPreClosureModel.getDebitBranchCode());

		requestMap.put("fd_amount",fdPreClosureModel.getFdAmount());
		/* Ends here for mapping in request used in TransactionLegs */


		logger.info("construct3045Request Ends here...");
		return requestMap;
	}

	public void populate3045Response(List coreResponseList, FixedDepositModel preModel){
		logger.info("populate3045Response(..) Starts here...");

		final Map coreResponse=(Map)coreResponseList.get(0);
		final String closedDate=(String)coreResponse.get("date");
		final String status = (String)coreResponse.get("status");
		final String errorCode = (String)coreResponse.get("error_code");

		String preClosedStatus="";

		if("O.K.".equalsIgnoreCase(status)) {
			preClosedStatus="closed";
		}

		if("0110".equals(errorCode)){
			//if error code is "account already closed" then update the status as 'closed'
			logger.info("Errorcode ------>"+errorCode);
			preClosedStatus="closed";
		}

		if("closed".equalsIgnoreCase(preClosedStatus)) {
			preModel.setPreClosureStatus(preClosedStatus);
			logger.info("Closed Date ->"+closedDate);
			preModel.setClosedDate(closedDate);  // in case of core gives exact format as 12/10/2010
			//preModel.setClosedDate(formattedClosedDate); // in case if core gives date as 12102010 in this format

			etdrMasterDAOImpl.closeFixedDepositAccount(preModel);
		}		
		logger.info("populate3045Response(..) Ends here...");
	}

	public List postPreclosureToCore(Map requestMap) throws DAOException,SBIApplicationException{
		logger.info("postPreclosureToCore(..) Starts here...");

		List responseList = coreTransactionDAOImpl.getDataFromBankSystem(requestMap);
		logger.info("Core Response For Txnno -->"+requestMap.get("txnno")+" --> "+responseList);

		if(responseList!=null && responseList.size()>0) {
			Map resMap = (Map)responseList.get(0);

			String txnno=(String)requestMap.get("txnno");
			String status = (String)resMap.get("status");
			String statement = (String)resMap.get("statement");
			String errorCode = (String) resMap.get("error_code");

			if(logger.isInfoEnabled()){
				logger.info("Status -->"+status);
				logger.info("ErrorCode -->"+errorCode);
				logger.info("Statement -->"+statement);
			}

			//for 003045 if status is null response had been received from core.
			if(status!=null && status.equalsIgnoreCase("F1") && !"003045".equals(txnno)){
				SBIApplicationException.throwException("FP005");// unable to process the request please retry again.
			} else if(status!=null && "F1".equalsIgnoreCase(status) && "003045".equals(txnno)){
				SBIApplicationException.throwException("FP003"); 
				//ErrorMessage displays : Check your credit account for pre closure credit. If there is no such credit, then please retry pre closure
			}

			// Unable to Connect to Core
			if(status!=null && status.equalsIgnoreCase("F2")){
				SBIApplicationException.throwException("FP005"); // unable to process the request please retry again.
			}

			if(status!=null && status.equalsIgnoreCase("ERR.")){
				if(errorCode!=null && "0110".equals(errorCode.trim())){ 
					SBIApplicationException.throwException("FD004");//Fixed Deposit Account is already Closed
				}else{
					SBIApplicationException.throwException("FD027"); // Due to some technical
				}
			}
		}        
		logger.info("postPreclosureToCore(..) Ends here...");

		return responseList;
	}
	
	public int cancelPrecloseEtdrRequest(Map inparams) {
		logger.info("cancelPrecloseEtdrRequest(String referenceNo)method begins ");
		EtdrMaster etdrMaster = null;
		int updateCount=0;
		String referenceNo = (String) inparams.get("referenceNo");
		String userName = (String) inparams.get("userName");
		if (referenceNo != null) {
			try {
				etdrMaster = getEtdrDetails(referenceNo);
				etdrMaster=modifyAuthorizationParameter(etdrMaster, userName);
				updateCount=etdrMasterDAOImpl.cancelPreCloseEtdrRequest(etdrMaster);
				
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("cancelPrecloseEtdrRequest(String referenceNo)method ends  :");
		return updateCount;

	}
	
	public void setetdrMasterDAOImpl(EtdrMasterDAO etdrMasterDAOImpl) {
		this.etdrMasterDAOImpl = etdrMasterDAOImpl;
	}

	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
	public void setFixedDepositPaymentConfirmService(
			BaseService fixedDepositPaymentConfirmService) {
		this.fixedDepositPaymentConfirmService = fixedDepositPaymentConfirmService;
	}
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}
	public void setCoreTransactionDAOImpl(
			CoreTransactionDAOImpl coreTransactionDAOImpl) {
		this.coreTransactionDAOImpl = coreTransactionDAOImpl;
	}
	
	
}
