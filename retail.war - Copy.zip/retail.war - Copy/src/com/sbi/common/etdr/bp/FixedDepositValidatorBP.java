package com.sbi.common.etdr.bp;

import java.util.Date;

import com.sbi.common.bp.TransactionValidatorBP;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Transaction;
import com.sbi.common.utils.Validator;

public class FixedDepositValidatorBP extends TransactionValidatorBP{

	
	
	 private Validator validator;
	public boolean validate(Transaction transaction) throws SBIApplicationException{
		// TODO Auto-generated method stub
		
		   this.transaction = transaction;
	        if (transaction != null)
	        {
	            
	        	Date scheduledDate = null; 
	            validator.validateAmount(transaction.getDebit().getAmount());
	            if(logger.isDebugEnabled()){
	            	logger.debug("validateAmount() return true");
	            }
	            
	            logger.info("validateAmount() return true");
	            
	           /* validator.validateFdAmount(transaction.getDebit().getAmount(),transaction.getBankCode());
	            if(logger.isDebugEnabled()){
	            	logger.debug("validateAmount() return true");
	            }*/
	            
	        
	            
	            //Adding New validation Method based on Category wise Limit Validation
	            scheduledDate = new Date();   
	            validator.validateCategoryGLimit(transaction.getDebit().getUserName(), transaction.getDebit().getAmount(), scheduledDate, transaction.getBankCode());
	            logger.info("validateCategoryGLimit Lmit validation returns true");
	            //Added for Etdr Defect fix to validate the debit account
	            validator.validateTxnRights(transaction.getDebit().getAccountNo(), transaction.getDebit().getBranchCode(),transaction.getDebit().getUserName() , 6,7,8,9);
	            logger.info("validateTxnRights() return true::::newly added Validation");
	            validator.validatefdLimit(transaction.getDebit().getAmount(),transaction.getDebit().getUserName(), transaction.getBankCode(),transaction.getSmallFlag());
	            logger.info("validatefdLimit() return true");
	        }
	        else
	        { 
	        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }
	        return true;
	}
	public void setValidator(Validator validator) {
		this.validator = validator;
	}

}
