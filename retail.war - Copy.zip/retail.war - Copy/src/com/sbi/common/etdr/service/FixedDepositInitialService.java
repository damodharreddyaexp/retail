/*
 * GetAccountService.java
 * Created on Nov 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 26, 2005 Sairam.T - Initial Creation
//Jan 31, 2006 Murugan K - Log changes
package com.sbi.common.etdr.service;

import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.bp.AccountInformationBP;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.CutoffTimeUtils;
import com.sbi.common.utils.StringUtils;



public class FixedDepositInitialService  extends BaseService {
	
	private Logger logger = Logger.getLogger(getClass());
	
	private CutoffTimeUtils cutOffTimeUtils;
	
	private AccountInformationBP accountInformationBp;
	
	/**CR:5562 22/10/2010 START */
    private AccountDAO accountDAOImpl;
    /**CR:5562 22/10/2010 END */
	
	public Map execute(Map inputParams) {
		Map outParams=new HashMap();
		Map paramMap = new HashMap();//added for etdr cutoff time on 27.01.09
		Timestamp payDate = StringUtils.currentTimeStamp();
		String bankCode=(String)inputParams.get("bankCode");
		String userName=(String)inputParams.get("userName");
		String merchantCode=(String)inputParams.get("transactionType");
		logger.info("  bankCode  "+bankCode+"  userName  "+userName +"  merchantCode "+merchantCode);
		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		try{
			logger.info("cutofftime e-TDR outisde::::");
			if (cutOffTimeUtils.isValidDateAndTime(payDate, "CORP_ETDR",bankCode)) {
				outParams.put("isScheduled", new Boolean(false));
			}else{
				outParams.put("isScheduled", new Boolean(true));//for Schedule
				logger.info("in service e-TDR::::");
				paramMap = cutOffTimeUtils.displayCutoffValues( "CORP_ETDR",bankCode);
				logger.info("cutofftime e-TDR::::"+paramMap);
				outParams.put("etdrMap",paramMap );
			}
				logger.info("scheduleDate after time validation:");				
				/** CR:5562 22/10/2010 START */
                List debitAccountList = accountDAOImpl.findAccountsByAccessLevel(userName, ServiceConstant.DEBIT_ACCOUNT, 6,7);
                /** CR:5562 22/10/2010 END */
				if (debitAccountList != null && debitAccountList.size() > 0 ){
					for (Iterator debitIterator = debitAccountList.iterator(); debitIterator.hasNext();) {  
						Account account = (Account) debitIterator.next();
						
						if (!account.getBankSystem().equalsIgnoreCase("Core")) {
							debitIterator.remove();
						}
						if("A3".equalsIgnoreCase(account.getProductType()) || "A4".equalsIgnoreCase(account.getProductType())){
							debitIterator.remove();
						}
					}
				}
				if (debitAccountList != null && debitAccountList.size() > 0 ){
					outParams.put(ServiceConstant.DEBIT_ACCOUNT, debitAccountList);
					outParams.put("monthsList",getMonthsList());
					//logger.info("outparams  Map contains: " + outParams);
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
				else {
				//	applicationResponse.setErrorCode(ServiceErrorConstants.SE067);  // Commented by Reddy Damodhar for SBT Money 
					applicationResponse.setErrorCode("SBTBID001");  // Added by Reddy Damodhar for SBT Money 
                }
				
				if (logger.isDebugEnabled()) {
					logger.debug("DebitAccountList is: " + debitAccountList);
				}
			/*}
			else
			{
				//set issheduled='y'
				
				//applicationResponse.setErrorCode("FD001");    
			}*/
		}catch(Exception e){
			logger.error("exception occured",e);
			applicationResponse.setErrorCode(ServiceErrorConstants.SE003);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		return outParams;
	}
	
	
	public void setCutOffTimeUtils(CutoffTimeUtils cutOffTimeUtils)
	{
		this.cutOffTimeUtils = cutOffTimeUtils;
	}
	
	
	public void setAccountInformationBp(AccountInformationBP accountInformationBp)
	{
		this.accountInformationBp = accountInformationBp;
	}
	
	/**CR:5562 22/10/2010 START */
	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}
	/**CR:5562 22/10/2010 END */
	
	public List getMonthsList(){
		final Locale locale=new Locale("en","IN");		
		return Arrays.asList(new DateFormatSymbols(locale).getShortMonths());
	}	
	
	
}



