package com.sbi.common.etdr.service;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.bp.FixedDepositPreClosureBP;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;

public class FixedDepositPreClosureInterimService extends BaseService 
{
	protected final Logger logger=Logger.getLogger(getClass());

	private FixedDepositPreClosureBP fixedDepositPreClosureBP;
	private FixedDepositBP fixedDepositBP;

	public Map execute(Map inputParams)
	{
		logger.info("the execute method "+LoggingConstants.METHODBEGIN);
		Map outParams=new HashMap();
		SBIApplicationResponse applicationResponse= new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		try{	
			FixedDepositModel fixedDepositModel =(FixedDepositModel)fixedDepositPreClosureBP.getPreClosureCreditDetails(inputParams);
			
			outParams.put("fdAccountNo",inputParams.get("fdAccountNo"));
			outParams.put("transactionPwd",inputParams.get("transactionPwd"));
			logger.info("transaction password in interim"+inputParams.get("transactionPwd"));
			outParams.put("preClosureDetails",fixedDepositModel);
			applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
		}
		catch(SBIApplicationException sbiApplicationException)
		{
			logger.info("sbiApplicationException...");
			sbiApplicationException.printStackTrace();
			applicationResponse.setErrorCode(sbiApplicationException.getErrorCode());
			
			logger.error("sbiApplicationException",sbiApplicationException);
		}
		catch (DAOException daoException) {
			logger.info("daoException...");
			daoException.printStackTrace();
			applicationResponse.setErrorCode(daoException.getErrorCode());
			logger.error("daoException",daoException);
		}
		catch(Exception e){
			logger.info("Exception...execute");
			e.printStackTrace();
			logger.error("exception occured",e);
			applicationResponse.setErrorCode("FD003");
		}

		logger.info(" Exception code "+  applicationResponse.getErrorCode() );
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		logger.info("the execute method "+LoggingConstants.METHODEND);
		logger.info("the returnd values from the service are "+outParams);
		return outParams;

	}

	public void setFixedDepositPreClosureBP(FixedDepositPreClosureBP fixedDepositPreClosureBP) {
		this.fixedDepositPreClosureBP = fixedDepositPreClosureBP;
	}
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
}
