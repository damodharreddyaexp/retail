package com.sbi.common.etdr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.model.FixedDepositModel;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionLeg;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;

@SuppressWarnings(value="unchecked")
public class FixedDepositPaymentConfirmService extends BaseService  {
	private FixedDepositBP fixedDepositBP;
	private BaseService corporateFundsTransferService;
	protected final Logger logger = Logger.getLogger(getClass());
	private final String INSUFFICIENT_FUNDS ="Insufficient funds";
	
	private static final String CREDIT_ACCOUNT_NO = "creditAccountNo";
	private static final String DEBIT_ACCOUNT_NO = "debitAccountNo";
	private static final String CREDIT_BRANCH_CODE = "creditBranchCode";
	private static final String DEBIT_BRANCH_CODE = "debitBranchCode";
	private static final String DEBIT_AMOUNT = "debitAmount";
	private static final String AMOUNT_TRANSFER = "amountTransfer";
	private static final String CREDIT_TXN_COUNT = "creditTxnCount";
	private static final String TRANSACTION_NAME = "transactionName";
	private static final String DEBIT_ACCOUNT_TYPE = "debitAccountType";
	private static final String CREDIT_ACCOUNT_TYPE = "creditAccountType";
	private static final String TRANSACTION_REMARKS = "transactionRemarks";
	private static final String CREDIT_AMOUNT_TRANSFER = "creditAmountTransfer";
	private static final String DEBIT_PRODUCT_CODE = "debitProductCode";
	private static final String CORP_MERCHANT_CODE = "merchantCode";
    
	public Map execute(Map inParams){
		
		logger.info(" FixedDepositPaymentConfirmService Execute(Map inParams) method begins");
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		Map<String,Object> outParam = new HashMap<String,Object>();
		//response.setErrorStatus(ServiceConstant.FAILURE);
		String bankCode= (String) inParams.get("bankCode");
		FixedDepositModel fixedDepositModel = (FixedDepositModel) inParams.get("fixedDepositModel");
		//boolean isScheduled = fixedDepositModel.isScheduled();
		//String userName = (String) inParams.get("userName");
		List response7007List=new ArrayList();
		
		try{
			logger.info(" before fixedDepositUtils isScheduled !!"+fixedDepositModel.isScheduled());
			if(!fixedDepositModel.isScheduled()){
				//the method returns a map containing params to be sent in request to core
				fixedDepositModel.setAuthStatus("FinalAuthorization");
				fixedDepositModel = fixedDepositBP.createFixedDepositAccount(inParams);//2000 txn
					if(("STDR".equalsIgnoreCase(fixedDepositModel.getFdType())) && 
							("A".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()) || 
									"B".equalsIgnoreCase(fixedDepositModel.getAutoRenewType())|| 
										"C".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()))){
						//fixedDepositBP.updateAutoRenewalInfo(fixedDepositModel);
						//7007 and 7051 and fundstranfer operation and 1045 txn 
						outParam=getMaturityDetailsList(inParams,response7007List,outParam,fixedDepositModel,bankCode,response);
						response = (SBIApplicationResponse)outParam.get(ServiceConstant.APPLICATION_RESPONSE) ;
						logger.info(" 'STDR' outParams -->"+outParam);
					}
					else if(("TDR".equalsIgnoreCase(fixedDepositModel.getFdType())) &&
								("B".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()) ||
										"C".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()))){
						//fixedDepositBP.updateAutoRenewalInfo(fixedDepositModel);
						outParam=getMaturityDetailsList(inParams,response7007List,outParam,fixedDepositModel,bankCode,response);
						response = (SBIApplicationResponse)outParam.get(ServiceConstant.APPLICATION_RESPONSE) ;
						logger.info(" 'TDR' outParams -->"+outParam);
					}				 

			}else{
				//if FD is scheduled
				Map fdParamMap = fixedDepositBP.getDepositRequestParams(inParams);
				
				fixedDepositModel=getSelectedMandatesInfo(bankCode,fixedDepositModel);
				
				logger.info("FixedDepositModel --->"+fixedDepositModel);
				
				//fixedDepositModel.setFdAccountNo("XXXXX");
				fixedDepositModel.setReferenceNo((String)fdParamMap.get("reference_no") );
				fixedDepositModel.setFdAccProductCode((String)fdParamMap.get("crProductCode"));
				fixedDepositModel.setStatus("scheduled");
				fixedDepositBP.insertFdAccountDetails(fixedDepositModel);
				logger.info("fd Account Details after Insertion in Scheduled Mode --->"+fixedDepositModel);
				
				//fixedDepositBP.updateAutoRenewalInfo(fixedDepositModel);
				//logger.info("(Auto Renew fd Account Details after Updation in Scheduled Mode--->"+fixedDepositModel);
				
				response.setErrorStatus(ServiceConstant.SUCCESS);
			}
			//response.setErrorStatus(ServiceConstant.SUCCESS);
			outParam.put("fixedDepositModel",fixedDepositModel);
		}
		catch (DAOException daoExp) 
		{
			response.setErrorCode(daoExp.getErrorCode());
		}
		catch(SBIApplicationException sbiExp){
			logger.error("FD payment service SBI Application Exception:", sbiExp);
			response.setErrorCode(sbiExp.getErrorCode());
		}
		catch(Exception exp){
			
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		
		outParam.put(ServiceConstant.APPLICATION_RESPONSE,response);
		
		logger.debug(" FixedDepositPaymentConfirmService Execute(Map inParams) method ends");
		return outParam;	
	}
	

	
	private Map postTransaction(FixedDepositModel fixedDepositModel,String bankCode,SBIApplicationResponse fdResponse)
	{
		Map inputParams = new HashMap();
		Map fundsOutParams = new HashMap();
		inputParams.put(ServiceConstant.USER_NAME, fixedDepositModel.getUserName());
		inputParams.put("bankCode", bankCode);
		inputParams.put(DEBIT_ACCOUNT_NO,  fixedDepositModel.getDebitAccountNo());
		inputParams.put(DEBIT_BRANCH_CODE, fixedDepositModel.getDebitBranchCode());
		inputParams.put(DEBIT_AMOUNT, ((Double)fixedDepositModel.getFdAmount()).toString());
		inputParams.put(CREDIT_ACCOUNT_NO, fixedDepositModel.getFdAccountNo()); 
		inputParams.put(CREDIT_BRANCH_CODE, fixedDepositModel.getFdBranchCode());
		inputParams.put(AMOUNT_TRANSFER, ((Double)fixedDepositModel.getFdAmount()).toString());
		
		inputParams.put(CREDIT_TXN_COUNT, "1");
		inputParams.put(TRANSACTION_NAME, "ETDR");
		inputParams.put(DEBIT_ACCOUNT_TYPE, fixedDepositModel.getDebitProductType());
		inputParams.put(CREDIT_ACCOUNT_TYPE, "A5");
		inputParams.put(TRANSACTION_REMARKS, fixedDepositModel.getTxnRemarks());//remarks need to be set in model
		inputParams.put(CREDIT_AMOUNT_TRANSFER, ((Double)fixedDepositModel.getFdAmount()).toString());
		inputParams.put(DEBIT_PRODUCT_CODE, fixedDepositModel.getDebitProductCode());
		inputParams.put(CORP_MERCHANT_CODE, "CORPETDR");
		inputParams.put("corporateId",fixedDepositModel.getCorporateId());
		//posts transaction 1045 to debit customer account
		String creditAccountNo=fixedDepositModel.getFdAccountNo();
		String creditAmount=((Double)fixedDepositModel.getFdAmount()).toString();
		int creditCount=0;
		List creditList = new ArrayList();
//		if(creditAccountNo!=null && !creditAccountNo.trim().equals("")
//				&& creditAmount!=null && !creditAmount.trim().equals("") )
//		{
			creditCount=creditCount+1;
			Account creditAccount = new Account();
			creditAccount.setAccountNo(creditAccountNo);
			creditAccount.setBranchCode(fixedDepositModel.getFdBranchCode());
			creditAccount.setBalance(new Double(creditAmount));
			creditAccount.setAccountNickName("");
			creditAccount.setAccountLockFlag(new Integer(0));
			creditList.add(creditAccount);
//		}
		inputParams.put("creditAccountList",creditList);
		inputParams.put("fundsTranferType","makeTransaction");
		fundsOutParams = corporateFundsTransferService.execute(inputParams);
		Transaction transactionObject = (Transaction)fundsOutParams.get(ServiceConstant.TRANSACTION);
		logger.info("Transaction Object ::" + transactionObject);

			if(transactionObject!=null){
				TransactionLeg debitTransactionLeg = transactionObject.getDebit();
				logger.info("debitTransactionLeg ..  " + debitTransactionLeg+" Transaction Status = " +debitTransactionLeg.getStatusCode() 
						+"desc ::"+debitTransactionLeg.getStatusDescription());
				
				String statusCode = debitTransactionLeg.getStatusCode();
				String statusDescription = debitTransactionLeg.getStatusDescription();
				
				if(statusCode.equalsIgnoreCase("00") ) {
					fixedDepositBP.mapFdAccountToUser(fixedDepositModel,bankCode);//bank code added for associate bank by viswa
					fixedDepositModel.setFdReferenceNo(debitTransactionLeg.getReferenceNo());
					fixedDepositBP.updateFdAccStatus(fixedDepositModel);
					
					fdResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}else if(statusCode.equalsIgnoreCase("F1")){
					fdResponse.setErrorStatus(ServiceConstant.FAILURE);
					fdResponse.setErrorCode("FD021");
				}else if(statusCode.equalsIgnoreCase("ERR.") && statusDescription.equalsIgnoreCase(INSUFFICIENT_FUNDS)){
					fdResponse.setErrorStatus(ServiceConstant.FAILURE);
					fdResponse.setErrorCode("FD007");
				}else if(statusCode.equalsIgnoreCase("ERR.")){
					fdResponse.setErrorStatus(ServiceConstant.FAILURE);
					fdResponse.setErrorCode("FD003");
				}
				
			}else{
				fdResponse = (SBIApplicationResponse)fundsOutParams.get(ServiceConstant.APPLICATION_RESPONSE);
			}
			
			fundsOutParams.put(ServiceConstant.APPLICATION_RESPONSE, fdResponse);
			
		return fundsOutParams;
	}
	
	public FixedDepositModel getSelectedMandatesInfo(String bankCode,FixedDepositModel fixedDepositModel){
		logger.info("getSelectedMandatesInfo(..) starts here");
		String autoRenewDescription="";
		if(("STDR".equalsIgnoreCase(fixedDepositModel.getFdType())) &&
				("A".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()) || "B".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()) 
						|| "C".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()))){
			logger.info("txnno : 7007 fired and 'A' or 'B' or 'C' is  selected..... ");
			autoRenewDescription=fixedDepositBP.getAutoRenewDetails(fixedDepositModel.getAutoRenewType());					
			fixedDepositModel.setAutoRenewDescription(autoRenewDescription);

			if(logger.isInfoEnabled()){
				logger.info("Auto Renew Type (A/B/C)-->"+fixedDepositModel.getAutoRenewType());
				logger.info("Auto Renew Description -->"+fixedDepositModel.getAutoRenewDescription());
			}			
		} else if(("TDR".equalsIgnoreCase(fixedDepositModel.getFdType())) &&
				("B".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()) 
						|| "C".equalsIgnoreCase(fixedDepositModel.getAutoRenewType()))){
			logger.info("txnno : 7007 fired and 'B' or 'C' is  selected..... ");
			autoRenewDescription=fixedDepositBP.getAutoRenewDetails(fixedDepositModel.getAutoRenewType());					
			fixedDepositModel.setAutoRenewDescription(autoRenewDescription);

			if(logger.isInfoEnabled()){
				logger.info("Auto Renew Type (B/C)-->"+fixedDepositModel.getAutoRenewType());
				logger.info("Auto Renew Description -->"+fixedDepositModel.getAutoRenewDescription());
			}
		}	 
		logger.info("getSelectedMandatesInfo(..) Ends here");
		return fixedDepositModel;
	}
	
	public Map getMaturityResponseList(List response7007List,Map<String,Object> outParam,FixedDepositModel fixedDepositModel,String bankCode,SBIApplicationResponse response){
		logger.info("getMaturityResponseList(..) Starts here");

		String date=""; String status=""; String statement="";String errorCode="";
		if (response7007List != null && response7007List.size() > 0) {
			Map coreResponse=(Map)response7007List.get(0);
			date=(String)coreResponse.get("date");
			status = (String)coreResponse.get("status");
			statement=(String)coreResponse.get("statement");
			errorCode = (String)coreResponse.get("error_code");

			logger.info("Date -->"+date);
			logger.info("Status -->"+status);
			logger.info("Statement -->"+statement);
			logger.info("errorCode -->"+errorCode);

			if(status!=null && "O.K.".equalsIgnoreCase(status)) {
				logger.info("TenureDays ::"+fixedDepositModel.getTenureInDays()+" "+"Auto-Renewal Type--->"+fixedDepositModel.getAutoRenewType());
                // 7051 txn
				fixedDepositBP.enableModeOfOperation(fixedDepositModel,bankCode);//bank code added for associate bank by viswa

				outParam = postTransaction(fixedDepositModel,bankCode,response);
				response = (SBIApplicationResponse)outParam.get(ServiceConstant.APPLICATION_RESPONSE) ;

			}else if("F1".equalsIgnoreCase(status) || "F2".equalsIgnoreCase(status)){   //For 7007 txnno
				logger.info("We are experiencing network delay, Please try later");
				response.setErrorStatus(ServiceConstant.FAILURE);
				SBIApplicationException.throwException("FD010");				
			}else if("ERR.".equalsIgnoreCase(status) && "0399".equals(errorCode.trim())){
				response.setErrorStatus(ServiceConstant.FAILURE);
				SBIApplicationException.throwException("FD036");				
			}else if("ERR.".equalsIgnoreCase(status) && !"0399".equals(errorCode.trim())){
				response.setErrorStatus(ServiceConstant.FAILURE);
				SBIApplicationException.throwException("FD003");
			}
		}
		logger.info("getMaturityResponseList(..) Ends here");
		return outParam;
	}
	
	public Map getMaturityDetailsList(Map inParams,List response7007List,Map<String,Object> outParam,FixedDepositModel fixedDepositModel,String bankCode,SBIApplicationResponse response){
		inParams.put("fixedDepositModel",fixedDepositModel);

		logger.info("FD Type --->"+fixedDepositModel.getFdType());
		logger.info("inparams.put(..) FD Type --->"+inParams.get("fixedDepositModel"));
		logger.info("txnno: 7007 is fired 'A' or 'B' or 'C' is selected ..... ");

		Map request7007Map = fixedDepositBP.construct7007Request(inParams);
		logger.info("request7007Map -->"+request7007Map);

		response7007List = fixedDepositBP.postEnquriyToCore(request7007Map);
		logger.info("Response7007List -->"+response7007List);

		outParam = getMaturityResponseList(response7007List,outParam,fixedDepositModel,bankCode,response);
		logger.info("getMaturityResponseList Outparams -->"+outParam);
		logger.info("<------FD Type will be same when 'A'or 'B' or 'C' is selected ---->"+fixedDepositModel.getFdType());
		return outParam;
	}
	
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP)
	{
		this.fixedDepositBP = fixedDepositBP;
	}

	public void setCorporateFundsTransferService(
			BaseService corporateFundsTransferService) {
		this.corporateFundsTransferService = corporateFundsTransferService;
	}

	
}
