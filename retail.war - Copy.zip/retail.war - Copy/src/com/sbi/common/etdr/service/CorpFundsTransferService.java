

/*    
 * CorpFundsTransferService .java
 * Created on Sep 23, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $    
 */
//History
//Sep 23, 2006 APARNA S - Initial Creation and Implementation
package com.sbi.common.etdr.service;



import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.common.bp.BPConstants;
import com.sbi.common.bp.TransactionValidatorBP;
import com.sbi.common.bp.TransactionValidatorFactory;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CorpTransaction;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.model.Transaction;
import com.sbi.common.service.BaseService;

import com.sbi.common.dao.IBTransactionDAO;
import com.sbi.common.utils.RequestMapperFactory;
import com.sbi.common.utils.TransactionRequestMapper;
import com.sbi.common.etdr.dao.CorpTransactionDAO;
import com.sbi.common.etdr.dao.CorpUserDAO;
import com.sbi.common.etdr.dao.IBCreditDAO;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.model.TransactionResponse;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.BankSystemDAO;
import com.sbi.common.utils.TxnFormatter;
import com.sbi.common.utils.TxnFormatterFactory;
import com.sbi.common.dao.BankSystemDAOFactory;


import org.springframework.dao.DataAccessException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
/**
 * TODO This  class is used make echeques for the corresponding credit accounts selected
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class CorpFundsTransferService extends BaseService {
	
	private RequestMapperFactory requestMapperFactory;

	private CorpUserDAO corpUserDAOImpl;

	private TransactionValidatorFactory transactionValidatorFactory;
	
	private CorpTransactionDAO corporateTransactionDAOImpl;
    
    private IBCreditDAO ibCreditDAOImpl;
    
    private IBTransactionDAO ibTransactionDAOImpl;
    
    private TransactionTemplate transactionTemplate; // Added for CR 2921
	
    private TxnFormatterFactory txnFormatterFactory;
    
    private BankSystemDAOFactory bankSystemTransactionDAOFactory;
    
	protected final Logger logger = Logger.getLogger(getClass());

	/**
     * TODO Retrieves username,corporateId,txnName from Hashmap 2. Calls
     * [RequestMapperFactory.getRequestMapper(txnName )] to return the specific request mapper
     * for the transactions ,TtransactionRequestMapper.getTransactionObject(inputParams)] to
     * set the input params from map to the beans and return transaction object,
     * [TransactionValidatorFactory.getValidator(txnName)] to get the specific validators for the transactions,
     * [TransactionValidatorBP.validate((Object)transaction)]to validate the transaction object from request mappers and
     * [CorpTransactionDAO.createTransaction(transaction)] to return the reference of the corresponding echeques entry in the table
     * 3.Uses the modifyTransactionName method to modify
     * the name of the transactions
     * 4.Returns Map
     * 
     * @param Map
     */
	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		logger.info("execute(Map inputParams) method begin " + inputParams);
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		//String userName = null;
		//userName = (String) inputParams.get(ServiceConstant.USER_NAME);
		//String corporateId = (String) inputParams.get(ServiceConstant.CORPORATE_ID);
		String txnName = (String) inputParams.get("transactionName");
        String transactionType = (String)inputParams.get("fundsTranferType");
        String commissionType = (String)inputParams.get("commissionType");
        logger.info("commm type::::"+commissionType);
        String referenceNo=null;
		
		try

		{

			if (inputParams != null ) {
			logger.info("Transaction Name::: " + txnName);
			inputParams.put("eftType",txnName);
			txnName = modifyTransactionName( txnName );
				TransactionRequestMapper transactionRequestMapper = requestMapperFactory
						.getRequestMapper(txnName );
				inputParams.put(UtilsConstant.TRANSACTION_NAME,txnName );
				Transaction transaction = transactionRequestMapper
						.getTransactionObject(inputParams);
				
				/*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
				String dproductCode=(String)inputParams.get("dproductCode");
				if(dproductCode != null)
					transaction.getDebit().setProductCode(dproductCode);
				/*	CR-5655 Ramanan M - END - NRE check through Product Code	*/
				transaction.setName(txnName);
				TransactionValidatorBP validator = transactionValidatorFactory.getValidator(txnName);// (transaction.getName());
				String specialErrorMsg = (String) validator.validate((Object)transaction);
				logger.info("TransactionType [edit/make] : " + transactionType+"specialErrorMsg.."+specialErrorMsg );
				/*CR-2734 checking Adress mandatory for NRE RTGS transactions*/
                  String merchantcode=transaction.getDebit().getMerchantCode();
                  /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
//                  String nrecheck="31|14";
                 // if(merchantcode!=null && merchantcode.equalsIgnoreCase("RTGS")&& dproductCode!=null && nrecheck.indexOf(dproductCode.substring(2,4))!=-1 )
				if (merchantcode != null
						&& merchantcode.equalsIgnoreCase("RTGS")
						&& dproductCode != null
						&& transaction.getDebit().isNreProductCode()) {
					/*	CR-5655 Ramanan M - END - NRE check through Product Code	*/
                    CorpTransactionLeg  creditCorpTransactionLeg =  (CorpTransactionLeg)transaction.getCredit()[0];
                    String narrative2=creditCorpTransactionLeg.getNarrative2();
                    String[] arrNarrative2 =  narrative2.split("\\|");
                    String receiverIFSCCode = arrNarrative2[1];
                    String corpId=(String)inputParams.get("corporateId");
                    CorpTransaction corptransaction=(CorpTransaction)transaction;
                    String corpState=null;
                    String corpAddress=null;
                    if(inputParams.get("corpState")!=null && inputParams.get("corpCity")!=null && inputParams.get("corpAddress1")!=null && inputParams.get("corpAddress2")!=null )
                    {
                        corpState=inputParams.get("corpState").toString()+inputParams.get("corpCity").toString();
                        corpAddress=inputParams.get("corpAddress1").toString()+inputParams.get("corpAddress2").toString();
                    }
                    if((corpState!=null) &&( corpAddress!=null)){
                        logger.info("Corporate profile Parameters comply for RTGS-NRE TXN");
                        List addressList = (List) ibCreditDAOImpl.findRTGSBenAddress(receiverIFSCCode,creditCorpTransactionLeg.getNarrative1(),corpId,creditCorpTransactionLeg.getNarrative3());
                        if(addressList !=null && addressList.size() >0) {
                        	Map addressLeg = (Map) addressList.get(0);
                        if(addressLeg != null && addressLeg.size()>0){
                            corptransaction.setAddress(addressLeg);
                        }
                    }
                    }
                    else
                    {
                        logger.info("Corporate profile Parameters Doesnt comply for RTGS-NRE TXN .State"+inputParams.get("corpState")+":City:"+inputParams.get("corpCity")+":CorpAddress1:"+inputParams.get("corpAddress1")+":CorpAddress2:"+inputParams.get("corpAddress2")+"dproductCode"+dproductCode );
                        SBIApplicationException.throwException("RTGSNRE01");
                    }
                   
                   
                    //if(inputParams.get("corpName")==null ||creditCorpTransactionLeg.getNarrative3()==null||corptransaction.getAddress().get("ADDRESS1")==null||corptransaction.getAddress().get("ADDRESS2")==null)
                    if(inputParams.get("corpName")==null ||creditCorpTransactionLeg.getNarrative3()==null) // modified for mandatory address condition removal
                    {
                        logger.info("Beneficiary Parameters Doesnt comply for RTGS-NRE TXN for Corpuser..."+":corpName:"+inputParams.get("corpName")+"dproductCode"+dproductCode );   
                       SBIApplicationException.throwException("RTGSNRE01");
                    }
                }
                         
                
                /*CR-2734 checking Adress mandatory for NRE RTGS transactions*/
                
                if ( specialErrorMsg == null ) // if there is no errorMsg from Validator.
				{
					if(transactionType != null && transactionType.equalsIgnoreCase("makeTransaction") )	
                    {
                    
						referenceNo = corporateTransactionDAOImpl.createTransaction(transaction);
                    
                    }
                   /* else if (transactionType != null && transactionType.equalsIgnoreCase("editTransaction"))
                    {
                        ref = corporateTransactionDAOImpl.editTransaction(transaction);
                        
                    }*/
						
							
						if (referenceNo != null) {
							
							transaction.getDebit().setReferenceNo(referenceNo);
							
							TransactionResponse transactionResponse = postTransactionToBankSystem(transaction);
				            logger.info("transactionResponse : " + transactionResponse);
				            
				            transaction.getDebit().setStatusCode(transactionResponse.getStatusCode());
				            transaction.getDebit().setStatusDescription(transactionResponse.getStatusDescription());
				            transaction.getDebit().setTransactionTime(transactionResponse.getResponseDate());
//				            if(transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)|| 
//			            	   transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT)
//				            		)
//				            	transaction.getDebit().setThirdPartyRef(transactionResponse.getResponseReference());
//				            
				            logger.info("transactionResponse :"+transactionResponse);
				            
				            updateTransactionStatus(referenceNo, transactionResponse);
				            logger.info("postTransaction(Transaction transaction) Ends transaction : " + transaction);
				            
				            
							CorpTransactionLeg corpTransactionLeg=(CorpTransactionLeg)transaction.getDebit();
							String makerName=corpUserDAOImpl.getAuthorizerName(corpTransactionLeg.getMaker());
							corpTransactionLeg.setMaker(makerName);
							if(txnName.equalsIgnoreCase(UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME)|| txnName.equalsIgnoreCase(UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME) || txnName.equalsIgnoreCase("CG")
										|| txnName.equalsIgnoreCase(UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME) || txnName.equalsIgnoreCase("CD")) {//Changed by marimuthu for DD Commision
								double echequeAmount=corpTransactionLeg.getAmount().doubleValue();
								double commAmount=0;
								if (corpTransactionLeg.getRateOfInterest()!=null && corpTransactionLeg.getRateOfInterest().trim().length()>0)
								 commAmount=new Double(corpTransactionLeg.getRateOfInterest()).doubleValue();
								double totalDebit=echequeAmount+commAmount;
								outParams.put("totalDebitAmount",new Double(totalDebit));
								outParams.put("commissionAmount",new Double(commAmount));
								//Changed by marimuthu for DD Commision
								outParams.put("merchantCode",(txnName.equalsIgnoreCase("CD"))?null:"EFT"); // Changed by marimuthu for DD Comnmsion
								//outParams.put("merchantCode","EFT"); 
								if(txnName.equalsIgnoreCase("CD")){
									String commRefNo = (String) inputParams.get("commRefNo");
									final String commAmt=corpTransactionLeg.getRateOfInterest().toString();
									final String commRef=commRefNo;
									final String refNo=referenceNo;
									final Double commissionAmount = commAmount;
									
									transactionTemplate.execute(new TransactionCallback() {
										public Object doInTransaction(
												TransactionStatus transactionStatus) {
											try {									
									
									boolean upd=false; // Added for CR 2921
									String utrNo ="";
									
									if(new Double(commAmt) != null && refNo != null )
										upd=ibTransactionDAOImpl.updateUTRNo(refNo, utrNo,commAmt);
									if(commRef != null && !commRef.equalsIgnoreCase(""))
									corpUserDAOImpl.updateDraftCommision(refNo,commissionAmount,commRef);
											}
											catch (DataAccessException e)
											{
												transactionStatus.setRollbackOnly();
												DAOException.throwException("SE001");
											}
											return null;
										}
									});
								}
								
							}else
								outParams.put("totalDebitAmount",new Double(corpTransactionLeg.getAmount().doubleValue()));
							transaction.setDebit(corpTransactionLeg);
							outParams.put(ServiceConstant.TRANSACTION,transaction);
							outParams.put(ServiceConstant.REFERENCE_NO,
									referenceNo);
							response.setErrorStatus("SUCCESS");
						}
						else {
							response.setErrorCode("HACK001");
						}
				 }
				else
				{
					logger.info("Special error message ::" + specialErrorMsg );
					response.setErrorMessage(specialErrorMsg);
					response.setErrorStatus(ServiceConstant.FAILURE);
					
				
				}
				
			} else {
				response.setErrorCode("CUS006");
			}
		} catch (SBIApplicationException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error("Exception occured:" + sbiExc);
		} catch (NumberFormatException nfexp) {
			logger.error(LoggingConstants.EXCEPTION, nfexp);
			response.setErrorStatus(ServiceConstant.FAILURE);
			response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
			response.setErrorCode("CUS004");
		}  catch (DAOException exception) {
			response.setErrorCode(exception.getErrorCode());
			logger.error("Exception occured:" + exception);
		}catch (Exception exp) {
			logger.error("Exception occured:" + exp);
			response.setErrorStatus(ServiceConstant.FAILURE);
			response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
			response.setErrorCode("CUS004");
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		
		if (logger.isDebugEnabled())
			logger.debug("output Map contains :" + outParams);
		logger.info("execute(Map inputParams) method end"
				+ LoggingConstants.METHODEND);
		return outParams;
	}
 
	 private String modifyTransactionName (String txnName)
	 {
		 String tname = "";
		 
		 if ( txnName.equalsIgnoreCase("DEMAND_DRAFT"))
		 {
			 tname="CD";
		 }else  if ( txnName.equalsIgnoreCase("FUNDS_TRANSFER"))
		 {
			 tname="CI";
		 }else  if ( txnName.equalsIgnoreCase("THIRD_PARTY"))
		 {
			 tname="CT";
		 }else  if ( txnName.equalsIgnoreCase(UtilsConstant.RTGS))
		 {
			 tname=UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME;
		 }else  if (txnName.equalsIgnoreCase(UtilsConstant.NEFT))
		 {
			 tname=UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME;
		 }else  if (txnName.equalsIgnoreCase(UtilsConstant.GRPT)) //added for GRPT
		 {
			 tname=UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME;
		 }
		 else  if (txnName.equalsIgnoreCase(UtilsConstant.EPFO)) //added for EPFO by siva
		 {
			 tname=UtilsConstant.EPFO_ECHEQUE_TXN_REF_NAME;
		 } else  if (txnName.equalsIgnoreCase("ETDR")) //added for ETDR  by Jeeva
		 {
			 tname="CW";
		 }
		 
		 
	logger.info("Modified Transactin Name : " + tname);	 
	 return tname;
	 }
	 private boolean updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse)
	    {
	        logger.debug("updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse) Begin");

	        if (transactionResponse != null && referenceNo != null && referenceNo.trim() != BPConstants.EMPTY)
	        {
	            try
	            {
	                return ibTransactionDAOImpl.updateStatus(transactionResponse, referenceNo);
	            }
	            catch (DAOException daoException)
	            {
	            	SBIApplicationException.throwException(daoException.getMessage(),daoException);
	            }
	        }
	        else
	        {
	        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	         }
	        return true;

	    }

	    /**
	     * Check the path . If it is core{ - call CoreFormatter.getTransactionFormat
	     * with Transaction Object as a input and get Map back. - Call
	     * CoreDaoImpl.getDataFromBankSystem with Map as a input and get List back. -
	     * Get the data from List at first position. - Update the
	     * TransactionResponse Object and return it }else{ - call
	     * SwitchFormatter.getTransactionFormat with Transaction Object as a input
	     * and get Map back. - Call SwitchDaoImpl.getDataFromBankSystem with Map as
	     * a input and get List back. - Get the data from List at first position. -
	     * Update the TransactionResponse Object and return it }
	     * 
	     * @param transaction
	     *            Transaction
	     * @return TransactionResponse
	     */
	    private TransactionResponse postTransactionToBankSystem(Transaction transaction)
	    {
	    	TransactionResponse transactionResponse=null;
	        if (transaction != null)
	        {
	            
	            if (logger.isDebugEnabled())
	            {
	                logger.debug("postTransactionToBankSystem(Transaction transaction) Begin -->transaction : " + transaction);
	            }

	            try
	            {
	                String txnPath = transaction.getPath();
	                if (logger.isDebugEnabled())
	                {
	                    logger.debug("txnPath : " + txnPath);
	                }
	                TxnFormatter txnFormatter = txnFormatterFactory.getTransactionFormatter(txnPath);
	                if (logger.isDebugEnabled())
	                {
	                    logger.debug("txnFormatter is :" + txnFormatter);
	                }
	                Map requestData = txnFormatter.getTransactionRequestFormat(transaction);
	                // CR-5553 changed on 28/7/2010 - Start 
	                String txnno = (String) requestData.get("txnno");
	                String bankcode=(String)requestData.get("bankCode");
	                String bankCodes="0|A|6";
	                String txnName = transaction.getName();
	                String txnNames = "001045|011045";
	                String refNo = (String)requestData.get("reference_no");
	                String narrative = (String)requestData.get("narrative");
	                String debitBranchCode = (String)requestData.get("debitBranchCode");
	                String creditBranchCode = (String)requestData.get("creditBranchCode");
	                String remitt_type = (String)requestData.get("remitt_type");
	            	if(txnNames.contains(txnno)){
	                	/*	if(narrative!=null && narrative.length()>46){
	                		narrative =narrative.substring(0,46);
	                	}*/
	                	requestData.put("narrative",narrative);
	            	}
	                
	                BankSystemDAO bankSystemDAO = bankSystemTransactionDAOFactory.getBankSystemDAO(txnPath);
	                List responseList = bankSystemDAO.getDataFromBankSystem(requestData);
	                logger.info("responseList :"+responseList);
	                if (logger.isDebugEnabled())
	                {
	                    logger.debug("List from bank system is :" + responseList);
	                }
	                HashMap bankSystemDataHash = (HashMap) responseList.get(BPConstants.ZERO_INT);
	                logger.info("bankSystemDataHash :"+bankSystemDataHash);
	                if (logger.isDebugEnabled())
	                {
	                    logger.debug("bankSystemDataHash is :" + bankSystemDataHash);
	                }
	                Map transactionResponseData = txnFormatter.getTransactionResponseFormat(bankSystemDataHash);
	                //logger.info("*****transactionResponseData :"+transactionResponseData);

	                //logger.info("transactionResponseData :"+transactionResponseData);
	                transactionResponse = new TransactionResponse();
	                transactionResponse.setResponseDate((Timestamp) transactionResponseData.get(BPConstants.RESPONSE_DATE));
	                transactionResponse.setResponseReference((String) transactionResponseData
	                        .get(BPConstants.RESPONSE_REFERENCE));
	                transactionResponse.setStatusCode((String) transactionResponseData.get(BPConstants.STATUS));
	                transactionResponse.setStatusDescription((String) transactionResponseData
	                        .get(BPConstants.RESPONSE_DESCRIPTION));
					//Added for RTGS/NEFT
	                
	                String transactionType="";
	                if(transaction.getDebit().getReferenceNo() != null && transaction.getDebit().getReferenceNo().length() >0){
	                	transactionType = transaction.getDebit().getReferenceNo().substring(0,2);
	                }
	                /*if(transactionType.equalsIgnoreCase(UtilsConstant.RTGS_CONSTANT)
							||transactionType.equalsIgnoreCase(UtilsConstant.GRPT_CONSTANT) 
							||transactionType.equalsIgnoreCase(UtilsConstant.DD_CONSTANT)
							||transactionType.equalsIgnoreCase("IU")) 
					{
	                	double commissionAmount=transaction.getDebit().getRateOfInterest().doubleValue();
	                	String utrNo="";
	                	String tempUTRNo="";
	                	if (transactionResponseData.get("utr_no")!=null && transactionResponseData.get("utr_no").toString().trim().length()>0 ) {
	                		utrNo=transactionResponseData.get("utr_no").toString();
	                		tempUTRNo = utrNo;
	                	}
	                	
	                	//Added this if condition by megavannan for DD commission
//	                	if(transaction.getDebit().getReferenceNo().substring(0,2).equalsIgnoreCase(UtilsConstant.DD_CONSTANT)){
//	                		utrNo = (String) transaction.getDebit().getAdditionalParams().get("outref1");
//	                		tempUTRNo = ((String) transactionResponseData.get(BPConstants.RESPONSE_REFERENCE));
//	                	}
	                	//DD commission end - by megavannan

	                	interBankBeneficiaryDAOImpl.updateEchequeMasterForInterBankOnline(transaction.getDebit().getReferenceNo(),new Double(commissionAmount),utrNo,transactionResponse.getStatusCode());
	                	transactionResponse.setResponseReference(tempUTRNo);
	                }*/	
					//Ended for RTGS/NEFT
	                if (logger.isDebugEnabled())
	                {
	                    logger.debug("transactionResponse is :" + transactionResponse);
	                }
	                //logger.info("transactionResponse :"+transactionResponse);
	                logger.debug("postTransactionToBankSystem(Transaction transaction) End" );
	            }
	            catch (DAOException daoException)
	            {
	            	SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
	            }
	        }
	        else
	        {
	        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
	        }
	        return transactionResponse;

	    }

	
	public void setRequestMapperFactory(RequestMapperFactory requestMapperFactory) {
		this.requestMapperFactory = requestMapperFactory;
	}

	

	public void setTransactionValidatorFactory(
			TransactionValidatorFactory transactionValidatorFactory) {
		this.transactionValidatorFactory = transactionValidatorFactory;
	}


	public void setCorporateTransactionDAOImpl(
			CorpTransactionDAO corporateTransactionDAOImpl) {
		this.corporateTransactionDAOImpl = corporateTransactionDAOImpl;
	}

	public CorpUserDAO getCorpUserDAOImpl() {
		return corpUserDAOImpl;
	}

	public void setCorpUserDAOImpl(CorpUserDAO corpUserDAOImpl) {
		this.corpUserDAOImpl = corpUserDAOImpl;
	}

	/**
	 * @param ibCreditDAOImpl the ibCreditDAOImpl to set
	 */
	public void setIbCreditDAOImpl(IBCreditDAO ibCreditDAOImpl) {
		this.ibCreditDAOImpl = ibCreditDAOImpl;
	}

	public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl) {
		this.ibTransactionDAOImpl = ibTransactionDAOImpl;
	}

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public void setTxnFormatterFactory(TxnFormatterFactory txnFormatterFactory) {
		this.txnFormatterFactory = txnFormatterFactory;
	}

	public void setBankSystemTransactionDAOFactory(
			BankSystemDAOFactory bankSystemTransactionDAOFactory) {
		this.bankSystemTransactionDAOFactory = bankSystemTransactionDAOFactory;
	}
	
	

}
