/*    
 * EchequesDisplayService .java
 * Created on Aug 30, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $    
 */
//History
//Aug 30, 2006 MEENA K. - Initial Creation

package com.sbi.common.etdr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.EtdrTransactionManageBP;
import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.bp.FixedDepositEnquiryBP;
import com.sbi.common.etdr.model.EtdrMaster;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.etdr.model.FixedDepositModel;


public class PreCloseEtdrDetailsDisplayService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private EtdrTransactionManageBP etdrTransactionManageBP;
	private FixedDepositEnquiryBP fixedDepositEnquiryBP;
	private FixedDepositModel fixedDepositModel;
	private FixedDepositBP fixedDepositBP;
	
	public Map execute(Map inparams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		EtdrMaster etdrMaster = null;
		Map outParams = new HashMap();

		try {
			String preCloseReferenceNo = (String) inparams.get("preCloseReferenceNo");
			
			if (preCloseReferenceNo != null) {
				
				etdrMaster = etdrTransactionManageBP.getPreCloseEtdrDetails(preCloseReferenceNo);
				inparams.put("etdrMaster", etdrMaster);
				
				if (etdrMaster != null) {
					
					etdrMaster=etdrTransactionManageBP.getPenaltyDetails(inparams);
					if (etdrMaster.getFdType().equals("TDR"))
					{
						logger.info("fd creatoin date is "+etdrMaster.getCreationTime());
						Map dummy = new HashMap();
						fixedDepositModel=etdrTransactionManageBP.constructFdModel(etdrMaster,dummy);
						Map requestmap473 = new HashMap();
						
						Map enquiryMap = new HashMap();
						enquiryMap.put("account_no", fixedDepositModel.getDebitAccountNo());
						enquiryMap.put("txnno", Constants.SHORT_ENQ_DEPOSITS_TXNNO);
						enquiryMap.put("bankCode", inparams.get("bankCode"));
						Map cifEnquiryMap = fixedDepositBP.retrieveSegmentCodeOnly(enquiryMap, fixedDepositModel.getFdAmount());
						logger.info("cifEnquiryMap ::" + cifEnquiryMap);
						String segmentCode=(String)cifEnquiryMap.get("segment_code");
						logger.info(segmentCode);
						fixedDepositModel.setSegmentCode(segmentCode);
						
						requestmap473.put("fixedDepositModel", fixedDepositModel);
						requestmap473.put("bankCode",inparams.get("bankCode"));
						Map responsemap473=fixedDepositEnquiryBP.fixedDepositEnquiry(requestmap473);
						logger.info("response for 473 is :: "+responsemap473);
						String tdr_payout_amount=(String)responsemap473.get("tdr_payout_amount");
						etdrMaster.setTDRpayoutamount(tdr_payout_amount);
					}
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
						outParams.put("etdrDetails", etdrMaster);
					
				} else {
					response.setErrorCode("FD040");//No eTDR/eSTDR request available
				}
			} else {
				response.setErrorCode("CUS006"); // input values are null.
			}

		} catch (SBIApplicationException appEx) {
			logger.error(LoggingConstants.EXCEPTION, appEx);
			response.setErrorCode(appEx.getErrorCode());

		} catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode("CUS004"); // Due to tech problem.

		}
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODEND);
		return outParams;
	}

	public void setEtdrTransactionManageBP(
			EtdrTransactionManageBP etdrTransactionManageBP) {
		this.etdrTransactionManageBP = etdrTransactionManageBP;
	}

	public FixedDepositEnquiryBP getFixedDepositEnquiryBP() {
		return fixedDepositEnquiryBP;
	}

	public void setFixedDepositEnquiryBP(FixedDepositEnquiryBP fixedDepositEnquiryBP) {
		this.fixedDepositEnquiryBP = fixedDepositEnquiryBP;
	}

	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
	
	
}
