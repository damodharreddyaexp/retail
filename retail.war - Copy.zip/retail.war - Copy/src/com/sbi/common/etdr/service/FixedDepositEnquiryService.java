package com.sbi.common.etdr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.bp.FixedDepositEnquiryBP;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.UtilsConstant;

public class FixedDepositEnquiryService extends BaseService{	
	protected final Logger logger = Logger.getLogger(FixedDepositEnquiryService.class);

	private FixedDepositUtils fixedDepositUtils;
	private FixedDepositBP fixedDepositBP;
	private FixedDepositEnquiryBP fixedDepositEnquiryBP;

	public Map execute(Map inputParams) {
		logger.info("execute(...) Starts here");

		FixedDepositModel fixedDepositModelEnquiry = new FixedDepositModel();
		Map outParams = new HashMap();

		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);

		logger.info("the inparam values are in the service ----------->"+ inputParams);

		String bankCode = (String) inputParams.get("bankCode");
		String userName = (String) inputParams.get("userName");
		String merchantCode = (String) inputParams.get("transactionType");
		String intPayout = (String) inputParams.get("intPayout");
		String cumulativeType = (String) inputParams.get("cumulativeType");
		String debitProductCode = (String) inputParams.get("debitProductCode");
		String fixedorfloatType = (String) inputParams.get("FixedorFloattype");
		String floatRate=(String) inputParams.get("floatYear");
		String fdValidationStatus = "";
	//	String isSeniorCitizen = ((String)inputParams.get("isSeniorCitizen"));

		try {

			fixedDepositEnquiryBP.validateProductCode(debitProductCode);

			Double debitAmount = new Double(((String) inputParams.get("amountTransfer")));
			Integer totalNoOfDays;

		
			if (userName != null && bankCode!=null) {
				inputParams = fixedDepositEnquiryBP.setEnquiryDate(inputParams);
				
			totalNoOfDays = (Integer)inputParams.get("totalNoOfDays");
			Map enquiryMap = new HashMap();
			enquiryMap.put("account_no", inputParams.get(UtilsConstant.DEBIT_ACCOUNT_NO));
			enquiryMap.put("txnno", Constants.SHORT_ENQ_DEPOSITS_TXNNO);
			enquiryMap.put("bankCode", bankCode);
			Map cifEnquiryMap = fixedDepositBP.retrieveSegmentCodeOnly(enquiryMap, debitAmount);
			logger.info("cifEnquiryMap ::" + cifEnquiryMap);
			String segmentCode=(String)cifEnquiryMap.get("segment_code");
			logger.info(segmentCode);
			fixedDepositModelEnquiry.setSegmentCode(segmentCode);
			
				if("0".equals(bankCode)){
					intPayout = fixedDepositUtils.getInterestPayout(fixedorfloatType, cumulativeType, totalNoOfDays,intPayout);
				}else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode)){
					intPayout=fixedDepositUtils.getInterestPayoutForAssociate(cumulativeType, totalNoOfDays, intPayout);
				}

				if(logger.isInfoEnabled()){
					logger.info("bankCode -->" + bankCode);
					logger.info("userName -->" + userName);
					logger.info("merchantCode -->" + merchantCode);
					logger.info("FixedorFloat Type -->"+ fixedorfloatType);
					logger.info("floatRate -->"+floatRate);
					logger.info("intPayout -->"+ intPayout);
					logger.info("debit Amount -->"+ debitAmount);
					logger.info("totalNoOfDays -->"+ totalNoOfDays);
				}

				FixedDepositModel fixedDepositModel = fixedDepositEnquiryBP.construct473Enquiry(inputParams,totalNoOfDays,intPayout);
				fixedDepositModel.setSegmentCode(segmentCode);
				inputParams.put("fixedDepositModel", fixedDepositModel);
				
				// Commented since transaction no 400 is not required -starts
				
				/*Map CitizenMap= new HashMap();
				CitizenMap.put("account_no", inputParams.get(UtilsConstant.DEBIT_ACCOUNT_NO));
				CitizenMap.put("txnno", "000400");
				CitizenMap.put("bankCode", bankCode);
				String customerNo = fixedDepositBP.retrieveCIFNumber(CitizenMap, debitAmount);
				logger.info("Customer no is"+customerNo);
				
				if (customerNo != null)
					
					{
						fixedDepositModel.setCustomerNo(customerNo);
					}
				*/
				
				// Commented since transaction no 400 is not required -ends
				
				outParams = fixedDepositBP.getFDProductTypeForEnquiryTab(debitProductCode, cumulativeType, totalNoOfDays,debitAmount, bankCode, fixedorfloatType,segmentCode);

				fdValidationStatus = (String) outParams.get("fdValidationStatus");
				logger.info("fdValidationStatus->"+fdValidationStatus);

				Map response473Map=new HashMap();

				if (fdValidationStatus != null && "validationSuccess".equalsIgnoreCase(fdValidationStatus)) {

					response473Map = fixedDepositEnquiryBP.fixedDepositEnquiry(inputParams);

					if (response473Map != null && response473Map.size() > 0) {
						logger.info("the outParams in the service" + response473Map);

						fixedDepositModelEnquiry=fixedDepositEnquiryBP.populate473Response(response473Map);

						outParams.put("fixedDepositModelEnquiry",fixedDepositModelEnquiry);
						outParams.put("cumulativeType",cumulativeType);
						outParams.put("debitAmount",debitAmount);
						outParams.put("interestPayout",intPayout);
						
						// Commented since senior citizen is not needed for ETDR CR of corporate 
						//outParams.put("isSeniorCitizen",fixedDepositModel.getIsSeniorCitizen());
						
						
						
						applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
					} else{
						SBIApplicationException.throwException("FD003");
					}
				}else 
				{
					logger.info("<---- fdValidation Failure --->");
					outParams.put("fdValidationStatus", fdValidationStatus);
					//outParams.put("isSeniorCitizen",fixedDepositModel.getIsSeniorCitizen());
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
			} else {
				logger.info("User Is Null");
				applicationResponse.setErrorCode("FD003");
			}
		} catch (SBIApplicationException e) {
			logger.info("SBIApplicationException -->"+e.getErrorCode());
			applicationResponse.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.info("Exception -->"+e.getMessage());
			applicationResponse.setErrorCode(ServiceErrorConstants.SE002);
		}
		logger.info("the outparams received from the BP are -->" + outParams);
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		logger.info("execute(...) Ends here");
		return outParams;
	}	

	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
	public void setFixedDepositEnquiryBP(FixedDepositEnquiryBP fixedDepositEnquiryBP) {
		this.fixedDepositEnquiryBP = fixedDepositEnquiryBP;
	}
}