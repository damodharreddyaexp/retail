/* 
 * FixedDepositStatusEnquiryService.java 
 * Created on March 20, 2012
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//March 20, 2010 Sairaj - Initial Creation

package com.sbi.common.etdr.service;

import java.sql.Timestamp;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.etdr.dao.FixedDepositDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.CutoffTimeUtils;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.model.FixedDepositModel;

public class FixedDepositStatusEnquiryService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());	

	private FixedDepositDAO fixedDepositDAOImpl;
	private CutoffTimeUtils cutOffTimeUtils;
	private FixedDepositBP fixedDepositBP;
	
	public Map execute(Map inputParams) 
	{
		logger.info("the execute(Map inputParams) method begins"+LoggingConstants.METHODBEGIN);
		Map outParams=new HashMap();
		Map paramMap = new HashMap();
		Map requestMap=new HashMap();
		
		Timestamp payDate = StringUtils.currentTimeStamp();
		String bankCode=(String)inputParams.get("bankCode");
		String branchCode=(String)inputParams.get("branchCode");
		String userName=(String)inputParams.get("userName");
		String corporateId=(String)inputParams.get("corporateId");
		String debitAccountNo= (String)inputParams.get("debitAccountNo");
		String reqType= (String)inputParams.get("reqType");
		String selFdAccountNo= (String)inputParams.get("selFdAccountNo");
		
		FixedDepositModel fixedDepositModel = null;
		
		logger.info("  bankCode  "+bankCode+"  userName  "+userName+"  reqType  "+reqType+"  corporateId  "+corporateId);

		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		List statuslist=null;
		try{
			
			if("requestStatus".equals(reqType)) {		
				statuslist = fixedDepositDAOImpl.getFixedDepositStatus(userName,branchCode,debitAccountNo);
				logger.info("statuslist :"+statuslist);
			}
			else if("accountInfo".equals(reqType)) {		
				statuslist = fixedDepositDAOImpl.getFixedDepositAccountDtls(corporateId,debitAccountNo);
				logger.info("Account details list :"+statuslist);
			}
			else if("accountBalanceDtls".equals(reqType)) {		
				
				requestMap.put("account_no", selFdAccountNo);
				requestMap.put("txnno",Constants.SHORT_ENQ_DEPOSITS_TXNNO);	
				requestMap.put("bankCode", inputParams.get("bankCode"));
				List responseList = fixedDepositBP.postEnquriyToCore(requestMap);
				logger.info("responseList from core for 400 :-"+responseList);
				HashMap coreDataHash = (HashMap) responseList.get(0);
				logger.info("coreDataHash ::" + coreDataHash);
				String cifNo = (String)coreDataHash.get("cif_no");
				
				if(cifNo!=null && !"".equals(cifNo)) {
					fixedDepositModel = new FixedDepositModel();
					fixedDepositModel.setFdAccountNo(selFdAccountNo);
					fixedDepositModel.setCustomerNo((String)coreDataHash.get("cif_no"));
					fixedDepositModel.setUserName((String)coreDataHash.get("name"));
					if(coreDataHash.get("term_value")!=null)
						fixedDepositModel.setFdAmount(Double.parseDouble((String)coreDataHash.get("term_value")));
					
					fixedDepositModel.setMaturityAmount((String)coreDataHash.get("maturity_amt"));
					if(coreDataHash.get("opening_date")!=null)
						fixedDepositModel.setFdCreationDate(coreDateToDate((String)coreDataHash.get("opening_date")));
					fixedDepositModel.setMaturityDate((String)coreDataHash.get("maturity_date"));
					fixedDepositModel.setAvailableBalance((String)coreDataHash.get("avail_balance"));
					
					if(coreDataHash.get("interest_rate")!=null)
						fixedDepositModel.setInterestRate(Double.parseDouble((String)coreDataHash.get("interest_rate")));
					
					String tenureInDays=(String)coreDataHash.get("tenureInDays");
					String tenureDays=(String)coreDataHash.get("tenor_days");
					String tenureMonths=(String)coreDataHash.get("tenor_month");
					String tenureYears=(String)coreDataHash.get("tenor_year");
					
					
					if(tenureInDays!=null && !"".equals(tenureInDays))
						fixedDepositModel.setTenureInDays(Integer.parseInt(tenureInDays));
					
					if(tenureDays!=null && !"".equals(tenureDays))
						fixedDepositModel.setDays(Integer.parseInt(tenureDays));
					
					if(tenureMonths!=null && !"".equals(tenureMonths))
						fixedDepositModel.setMonths(Integer.parseInt(tenureMonths));
					
					if(tenureYears!=null && !"".equals(tenureYears))
						fixedDepositModel.setYears(Integer.parseInt(tenureYears));
					
					if(fixedDepositModel.getDays()>0 || fixedDepositModel.getMonths()>0 || fixedDepositModel.getYears()>0) {
						fixedDepositModel.setDtMonYr(true);
			        }
			        else{
			        	fixedDepositModel.setDtMonYr(false);
			        }
					
				}
				
			}
			
			if("requestStatus".equals(reqType) || "accountInfo".equals(reqType)) {
				
				if(statuslist!=null && statuslist.size()>0) {
					outParams.put("FixedDepositStatus",statuslist);
					logger.info("FixedDepositStatus :"+outParams.get("FixedDepositStatus"));
					logger.info(statuslist);
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
				else {
					if("requestStatus".equals(reqType))
						applicationResponse.setErrorCode("FD044");
					else
						applicationResponse.setErrorCode("FD045");
				}

			}
			else {
				
				if(fixedDepositModel!=null) {
					outParams.put("fixedDepositModel",fixedDepositModel);
					logger.info("fixedDepositModel :"+fixedDepositModel);
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
				else {
					applicationResponse.setErrorCode("TXNSL001"); 
				}
			}
		}
		catch (SBIApplicationException sbiApplicationException) {
             applicationResponse.setErrorCode(sbiApplicationException.getErrorCode());
             logger.error("sbiApplicationException",sbiApplicationException);
        }
		catch (DAOException daoException) {
			   applicationResponse.setErrorCode(daoException.getErrorCode());
	           logger.error("daoException",daoException);
        }
		catch(Exception e){
			applicationResponse.setErrorCode(ServiceErrorConstants.SE002);
			logger.error("exception occured",e);
		}
		logger.info("the execute(Map inputParams) method ends"+LoggingConstants.METHODEND);
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);	
		return outParams;
	}
	
	private Date coreDateToDate(String coreDateString)
    {
    	if(logger.isDebugEnabled())
    		logger.debug("coreDateToDate(String coreDateString) " + LoggingConstants.METHODBEGIN);
    	Date sqlDate = null;
        try
        { 

            if (coreDateString != null)
            {
                SimpleDateFormat ts = new SimpleDateFormat(DAOConstants.DATA_FORMAT);
                sqlDate = new java.sql.Date(ts.parse(coreDateString).getTime());
                logger.debug("sqlToday :" + sqlDate);
                logger.debug("coreDateToDate(String coreDateString) " + LoggingConstants.METHODEND);
               
                return sqlDate;
            }

        }
        catch (ParseException e)
        {
            logger.info(LoggingConstants.EXCEPTION + e);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }

        return sqlDate;

    }
	
	
	public FixedDepositDAO getFixedDepositDAOImpl() {
		return fixedDepositDAOImpl;
	}


	public void setFixedDepositDAOImpl(FixedDepositDAO fixedDepositDAOImpl) {
		this.fixedDepositDAOImpl = fixedDepositDAOImpl;
	}


	public void setCutOffTimeUtils(CutoffTimeUtils cutOffTimeUtils)
	{
		this.cutOffTimeUtils = cutOffTimeUtils;
	}

	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}

}


