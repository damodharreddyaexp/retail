package com.sbi.common.etdr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.dao.FixedDepositDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;

public class FixedDepositPreClosureService extends BaseService{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	private FixedDepositDAO fixedDepositDAOImpl;
	
	private FixedDepositBP fixedDepositBP;
	
	List coreResList = new ArrayList();
	public Map execute(Map inputParams) {
		
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		Map outParam = new HashMap();
		logger.info("execute() input::"+inputParams);
		String errorcode="NoERROR";
		String dbstatus ="";
		try {
			
			String fdAccountNo = (String)inputParams.get("fdAccountNo");
			String bankCode = (String)inputParams.get("bankCode");
			
			List reqDetailList = fixedDepositDAOImpl.getFixedDepositDetails(fdAccountNo);
			
			logger.info("FD details for closure ::"+reqDetailList);
			if(reqDetailList!=null && reqDetailList.size()>0) {
				coreResList = fixedDepositBP.postFDPreClosureRequest(reqDetailList,bankCode);
				
				if(coreResList!=null && coreResList.size()>0) {
					Map  coreResMap = (Map)coreResList.get(0);
					String status = (String)coreResMap.get("status");
					String errorCode = (String)coreResMap.get("error_code");
					
					if(status.equalsIgnoreCase("O.K.")) {
						dbstatus="closed";
					}	
					else if(status.equalsIgnoreCase("F1")) {
						dbstatus="F1";
						errorcode="FD005";
					}	
					else if(status.equalsIgnoreCase("ERR."))
					{
						errorcode="FD005";
						
						if(errorCode.equalsIgnoreCase("0110")) 
						{
							//if error code is "account already closed" then update the status as 'closed'
							dbstatus="closed";
							errorcode="FD004";
						}
						
					}
					if(dbstatus.equalsIgnoreCase("closed") || dbstatus.equalsIgnoreCase("F1")) {
						coreResMap.put("fdAccountNo",fdAccountNo);
						coreResMap.put("status",dbstatus);
						fixedDepositDAOImpl.closeFixedDepositAccount(coreResMap);
					}
					response.setErrorCode(errorcode);
				}
			}else {
				response.setErrorCode("FD004");
			}
			
			if(errorcode!=null && errorcode.equalsIgnoreCase("NoERROR"))
				response.setErrorStatus(ServiceConstant.SUCCESS);
			
			logger.info("errorcode ::"+errorcode+" dbstatus ::"+dbstatus +" error status ::"+response.getErrorStatus());
			
		} catch (DAOException appexp) {
			response.setErrorCode(appexp.getErrorCode());
			response.setErrorStatus(ServiceConstant.FAILURE);
			
		} catch (Exception exp) {
			response.setErrorStatus(ServiceConstant.FAILURE);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParam.put("applicationResponse",response);
		return outParam;
	}
	
	public void setFixedDepositDAOImpl(FixedDepositDAO fixedDepositDAOImpl) {
		this.fixedDepositDAOImpl = fixedDepositDAOImpl;
	}
	
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
}
