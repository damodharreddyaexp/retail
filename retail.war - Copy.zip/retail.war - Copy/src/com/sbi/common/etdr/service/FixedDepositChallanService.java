/*
 * FixedDepositChallanService.java
 * Created on June  5, 2009
 * By Sneh ID 49745
 * Copyright (c) 2005 by SBI All Rights Reserved.
 */
package com.sbi.common.etdr.service;

import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.dao.FixedDepositDAO;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.StringUtils;


public class FixedDepositChallanService extends BaseService {
	
	private Logger logger = Logger.getLogger(getClass());
	
	private FixedDepositBP fixedDepositBP;
	
	private FixedDepositDAO fixedDepositDAOImpl;
	
	private FixedDepositUtils fixedDepositUtils;
	
	private ReferenceDataCache referenceDataCache; 
	
	
	public Map execute(Map inputParams) {
		
		Map outParams=new HashMap();
		Map requestMap=new HashMap();
		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		
		try{
			logger.info("inputParams ::"+inputParams);
			/*Core hit:-400 request being fired*/	
			String fixedDepositAccountNo=(String)inputParams.get("fdAccountNo");
			requestMap.put("account_no", fixedDepositAccountNo);
			requestMap.put("txnno",Constants.SHORT_ENQ_DEPOSITS_TXNNO);	
			requestMap.put("bankCode", inputParams.get("bankCode"));
			logger.info("requestMap sent to core for 400 :-"+requestMap);
			String bankCode = (String)inputParams.get("bankCode");
			List responseList = fixedDepositBP.postEnquriyToCore(requestMap);
			logger.info("responseList from core for 400 :-"+responseList);
			HashMap coreDataHash = (HashMap) responseList.get(0);
			
			
			
		
			
			/*Forming FixedDepositModel model,using data from 400 request. [as well as data from session in case of ETDR Creation link alone]*/				
			//FixedDepositModel fdAcc=new FixedDepositModel();
			FixedDepositModel fdAcc =(FixedDepositModel) inputParams.get("fdAcc");
			fdAcc.setFdAccountNo((fixedDepositAccountNo));
			
			String cifNo = (String) coreDataHash.get("cif_no");
			fdAcc.setCustomerNo(cifNo);
			
			String customerName = (String) coreDataHash.get("name");
			fdAcc.setDebitHolderName(customerName);
			
			String etdrchallanflag=(String)inputParams.get("etdrchallanflag");
			outParams.put("etdrchallanflag",etdrchallanflag);//added for nominee changes by viswa
			/*Setting FixedDepositModel with Joint Acc holders'list[only for AccountSummary and StatusEnquiry links]*/
			if(etdrchallanflag.equalsIgnoreCase("etdrAccSummaryChallan")||etdrchallanflag.equalsIgnoreCase("etdrStatusEnquiryChallan"))
			{
				Map fdDetailMap = fixedDepositDAOImpl.getFdAccountDetailsForChallan(fixedDepositAccountNo);
				String debitAccNo = (String)fdDetailMap.get("DEBIT_ACCOUNT_NO");
				String fdReferenceNo = (String)fdDetailMap.get("FD_REFERENCE_NO");
				logger.info("FD_RATE_TYPE:"+fdDetailMap.get("FD_RATE_TYPE"));
				fdAcc.setTypeOfInterestRate((String)fdDetailMap.get("FD_RATE_TYPE"));//defect fix
				String autoRenewType = (String)fdDetailMap.get("AUTO_RENEW_TYPE");
				if(autoRenewType==null || "".equals(autoRenewType)){
					fdAcc.setAutoRenewDescription(" ");
				}else {
					fdAcc.setAutoRenewDescription(autoRenewType);
				}
				logger.info("Auto Renewal Type -->"+fdAcc.getAutoRenewDescription());
				fdAcc = calculateAutoRenewalTenures(fdDetailMap,fdAcc);
				logger.info("AutoRenew FDModel -->"+fdAcc);
				
				
				//
				fdAcc.setDebitAccountNo(debitAccNo);
				fdAcc.setFdReferenceNo(fdReferenceNo);
				fdAcc.setIsSeniorCitizen((String)fdDetailMap.get("SENIOR_CITIZEN"));
				String isSbhdouble = ((String)fdDetailMap.get("SBH_DOUBLE"));
				if(isSbhdouble==null || "".equals(isSbhdouble)){
					fdAcc.setIsSbhDouble(" ");
				}else {
					fdAcc.setIsSbhDouble(isSbhdouble);
				}
				
				/*Core hit :-check for modeOfOpertaion [Joint/Single]*/
				String modeOfOperation = fixedDepositBP.getFDAccountType(debitAccNo,false,bankCode);//bank code added for associate bank by viswa
				logger.info("Mode Of Operation ::" + modeOfOperation);
				fdAcc.setFdAccNature(modeOfOperation);
				if(modeOfOperation != null)
				{
					fixedDepositBP.enableModeOfOperation(fdAcc,bankCode);//bank code added for associate bank by viswa
					
				}
				
			}
			/*if user enters days for FD creations, core will add a new field 'tenureInDays' 
			 * in 400 for tenure in days. 
			 */
			Integer totalNoOfDays = new Integer(0);
			String tenureInDays = (String)coreDataHash.get("tenureInDays");
			logger.info("tenureInDays :: "+tenureInDays);
			
			String tenor_year = (String)coreDataHash.get("tenor_year");
			String tenor_month = (String)coreDataHash.get("tenor_month");
			String tenor_days = (String)coreDataHash.get("tenor_days");
			logger.info("tenor_year :: "+tenor_year+"  tenor_month  ::"+tenor_month+"  tenor_days ::"+tenor_days);
			
			/*if(tenureInDays!=null && tenureInDays.trim().length()>0 && Integer.parseInt(tenureInDays.trim())>0 ){
				totalNoOfDays = new Integer(tenureInDays.trim());
				//totalNoOfDays = fixedDepositDAOImpl.getTenureInDays(fixedDepositAccountNo);
			}else {
				totalNoOfDays = calculateTenureDays(coreDataHash,fdAcc);
				fdAcc.setDtMonYr(true);
				logger.info("tenureIn year::Month::Days ::"+totalNoOfDays);
			}
			*/
			
			if (  ( tenor_year!=null && !tenor_year.trim().equals("")&& (Integer.parseInt(tenor_year))>0) 
				||( tenor_month!=null && !tenor_month.trim().equals("")&& (Integer.parseInt(tenor_month))>0)
				||( tenor_days!=null && !tenor_days.trim().equals("")&& (Integer.parseInt(tenor_days))>0 )){
				
				totalNoOfDays = calculateTenureDays(coreDataHash,fdAcc);
				fdAcc.setDtMonYr(true);
				logger.info("tenureIn year::Month::Days ::"+totalNoOfDays);
				
				
			}
			else{
				logger.info("tenureInDays to be displayed ::"+tenureInDays);
				totalNoOfDays = new Integer(tenureInDays.trim());
			}
				
			
			
			
			logger.info("totalNoOfDays ::"+totalNoOfDays);
			
			fdAcc.setTenureInDays(totalNoOfDays);
			fdAcc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.INTEREST_RATE)));
			
			
			
			fdAcc.setPrincipalAmount( new Double((String) coreDataHash.get(DAOConstants.TERM_VALUE)));
			//fdAcc.setValueDate((String) coreDataHash.get(DAOConstants.OPENING_DATE));
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			
			//DateFormat df = new SimpleDateFormat("ddMMyyyyHHmiss");
			fdAcc.setValueDate(df.parse((String)coreDataHash.get(DAOConstants.OPENING_DATE)));
			fdAcc.setMaturityDate((String) coreDataHash.get(DAOConstants.MATURITY_DATE));
			fdAcc.setMaturityAmount((String) coreDataHash.get(DAOConstants.MATURITY_AMT));
			//fdAcc.setFdBranchCode((String) coreDataHash.get(DAOConstants.BRANCH_CODE));
			/*Get Branch Name from INB cache*/
			Map branchMap = null; 
			if( bankCode!=null && bankCode.equalsIgnoreCase("0") )	
					branchMap = referenceDataCache.getReferenceData("allBranchDataKey");
			else if ( bankCode!=null && (bankCode.equalsIgnoreCase("1")||bankCode.equalsIgnoreCase("4")||bankCode.equalsIgnoreCase("5")||bankCode.equalsIgnoreCase("7") || "2".equals(bankCode)))	
					branchMap = referenceDataCache.getReferenceData("branchDataKey");
			
			String branchCode = (String) coreDataHash.get(DAOConstants.BRANCH_CODE);
			logger.info("banckCode ::"+ bankCode+" branchCode ::"+branchCode);
			if( (bankCode!=null && bankCode.equalsIgnoreCase("0") ) && 
					( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("1") ) ){
	        	logger.info("branchCode before replace::"+ branchCode);
	        	branchCode = branchCode.replaceFirst("1", "A");	        	
	    	}
			fdAcc.setFdBranchCode(branchCode);
			logger.info("------ FD Branch Code ---->"+fdAcc.getFdBranchCode());
			String branchName=(String) branchMap.get(branchCode);
			logger.info("Branch Code--->"+branchCode + " Branch Name here : "+branchName);
			outParams.put("branchName",branchName);
			
			/*Get INBRefNo,FDType from INB database based on fdAccNo(corp_ref_no)*/
			Map details=fixedDepositDAOImpl.getINBRefNoFDType(fixedDepositAccountNo);
			String inbRefNo=(String) details.get("ECHEQUE_NO");
			String fdType=(String) details.get("FD_TYPE");
			outParams.put("inbRefNo",inbRefNo);
			outParams.put("fdType",fdType);
			logger.info("inbRefNo="+inbRefNo+",fdType="+fdType);
			/*Get ProductDescription. from INB database based on product_code*/
			String productDescription="";
			
			if("0".equals(bankCode)){
				logger.info("For SBI bank .... "+bankCode+" "+" Fixed /Float Type -->"+fdAcc.getTypeOfInterestRate());
				productDescription=fixedDepositDAOImpl.getProductDesc((String)coreDataHash.get(DAOConstants.PRODUCT_CODE),bankCode,fdAcc.getTypeOfInterestRate());//bank code added for associate bank by viswa
			}
			else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode)){
				logger.info("For Associate banks .... "+bankCode);
				productDescription=fixedDepositDAOImpl.getProductDescAssociateBanks((String)coreDataHash.get(DAOConstants.PRODUCT_CODE),bankCode);				
			}
			/*else if("2".equals(bankCode) && "Yes".equalsIgnoreCase(fdAcc.getIsSbhDouble())){
				logger.info("For SBH Double .... "+bankCode);
				productDescription=fixedDepositDAOImpl.getSBHDoubleProductDesc((String)coreDataHash.get(DAOConstants.PRODUCT_CODE),bankCode);
			}*/
			
			//String productDescription=fixedDepositDAOImpl.geteTDRProductDesc((String)coreDataHash.get(DAOConstants.PRODUCT_CODE));
			logger.info("Prod Code ::"+(String)coreDataHash.get(DAOConstants.PRODUCT_CODE)+" Prod Desc ::"+productDescription);
			
			outParams.put("productDescription",productDescription);					
			
			outParams.put("fdAcc",fdAcc);
			/*Update table sbi_fd_account_map  with 400 response details  */
			Double maturity_amt=Math.floor(Double.parseDouble((String) coreDataHash.get(DAOConstants.MATURITY_AMT))*100)/100;
			Double interest_rate=Math.floor(Double.parseDouble((String) coreDataHash.get(DAOConstants.INTEREST_RATE))*100)/100;
			Map maturityDetails=new HashMap();
			maturityDetails.put(DAOConstants.MATURITY_AMT, maturity_amt.toString().trim());
			maturityDetails.put(DAOConstants.MATURITY_DATE, (String) coreDataHash.get(DAOConstants.MATURITY_DATE).toString().trim());
			maturityDetails.put(DAOConstants.INTEREST_RATE, interest_rate.toString().trim());
			maturityDetails.put("fdAccountNo",fixedDepositAccountNo);
			maturityDetails.put("fdAccNature", fdAcc.getFdAccNature());
			logger.info("maturityDetails to be inserted :-"+maturityDetails);
			
			fixedDepositDAOImpl.updateMaturityDetails(maturityDetails);
			applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
			
			
			
		}
		catch(DAOException dao)
		{
			logger.error("dao exception caught ",dao);
			applicationResponse.setErrorCode(dao.errorCode);
		}
		catch(Exception e){
			logger.error("exception occured",e);
			applicationResponse.setErrorCode("FD003");
		}
		
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		return outParams;
	}
	
	
	private Integer calculateTenureDays(Map coreDataHash,FixedDepositModel fixedModel)
	{
		String year=(String)coreDataHash.get("tenor_year");
		if(year==null || (year != null && year.equalsIgnoreCase("")))
		{year="00";}
		
		String month=(String)coreDataHash.get("tenor_month");
		if(month==null|| (month != null && month.equalsIgnoreCase("")))
		{
			month="00";}
		
		String days=(String)coreDataHash.get("tenor_days");
		if(days==null||(days != null && days.equalsIgnoreCase("")))
		{
			logger.info("days null:-"+days );
			days="00";}
		Integer yearInt = new Integer(year);
		Integer monthInt = new Integer(month);
		Integer daysInt = new Integer(days);
		
		fixedModel.setYears(yearInt.intValue());
		fixedModel.setMonths(monthInt.intValue());
		fixedModel.setDays(daysInt.intValue());

		Integer totalNoOfDays = fixedDepositUtils.daysConvertor(yearInt, monthInt, daysInt);
		
		return totalNoOfDays;
	}
	public FixedDepositModel calculateAutoRenewalTenures(Map fdDetailMap,FixedDepositModel fixedModel){
		logger.info("calculateAutoRenewalTenures(..) Starts Here...");

		Integer tenureInDays = new Integer(fdDetailMap.get("AUTO_RENEW_TENURE").toString());
		Integer tenor_days =  new Integer(fdDetailMap.get("AUTO_RENEW_TENURE_DAY").toString());
		Integer tenor_month = new Integer(fdDetailMap.get("AUTO_RENEW_TENURE_MONTH").toString());
		Integer tenor_year = new Integer(fdDetailMap.get("AUTO_RENEW_TENURE_YEAR").toString());
		Integer autoRenewTotalNoOfDays = new Integer(0);

		if (tenureInDays!=null && tenureInDays.intValue()==0) {
			
			fixedModel.setAutoRenewYears(tenor_year.intValue());
			fixedModel.setAutoRenewMonths(tenor_month.intValue());
			fixedModel.setAutoRenewDays(tenor_days.intValue());
			
			autoRenewTotalNoOfDays = fixedDepositUtils.daysConvertor(tenor_year.intValue(), tenor_month.intValue(), tenor_days.intValue());			
			fixedModel.setAutoRenewDtMonYr(true);
			
				logger.info("Auto Renew tenureIn year::Month::Days -->"+autoRenewTotalNoOfDays);
			} else{
				logger.info("Auto Renew tenureInDays to be displayed -->"+tenureInDays);
				autoRenewTotalNoOfDays = new Integer(tenureInDays);
				fixedModel.setAutoRenewDtMonYr(false);
			}			
			logger.info("Auto Renew TotalNoOfDays -->"+autoRenewTotalNoOfDays);			
			fixedModel.setAutoRenewTenureInDays(autoRenewTotalNoOfDays);
			
			logger.info("calculateAutoRenewalTenures(..) Ends Here...");
			return fixedModel;
	}
	
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}
	
	
	public void setFixedDepositDAOImpl(FixedDepositDAO fixedDepositDAOImpl) {
		this.fixedDepositDAOImpl = fixedDepositDAOImpl;
	}
	
	
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils) {
		this.fixedDepositUtils = fixedDepositUtils;
	}
	
	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	
	
	
	
}
