/*    
 * EchequesDisplayService .java
 * Created on Aug 30, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $    
 */
//History
//Aug 30, 2006 MEENA K. - Initial Creation

package com.sbi.common.etdr.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.EtdrTransactionManageBP;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;

public class PreCloseEtdrDisplayService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private EtdrTransactionManageBP etdrTransactionManageBP;

	public Map execute(Map inparams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		List etdrPendingList = null;
		Map outParams = new HashMap();

		try {
			String userName = (String) inparams.get("userName");
			
			if (userName != null) {
				
				etdrPendingList = etdrTransactionManageBP.getPreCloseEtdrPendingRequests(userName);
				
				if (etdrPendingList != null && etdrPendingList.size() > 0) {
					logger.info("etdr Pending List : " + etdrPendingList.size() );
					response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					outParams.put("etdrPendingList", etdrPendingList);
					
				} else {
					response.setErrorCode("FD043");//No preClose e-TDR/e-STDR(FD) pending requests available
				}
			} else {
				response.setErrorCode("CUS006"); // input values are null.
			}

		} catch (SBIApplicationException appEx) {
			logger.error(LoggingConstants.EXCEPTION, appEx);
			response.setErrorCode(appEx.getErrorCode());

		} catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode("CUS004"); // Due to tech problem.

		}
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODEND);
		return outParams;
	}

	public void setEtdrTransactionManageBP(
			EtdrTransactionManageBP etdrTransactionManageBP) {
		this.etdrTransactionManageBP = etdrTransactionManageBP;
	}

	
}
