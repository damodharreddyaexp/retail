package com.sbi.common.etdr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.bp.FixedDepositPreClosureBP;
import com.sbi.common.etdr.dao.FixedDepositPreClosureDAO;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;

/**
 * <code>FixedDepositPreClosureConfirmService.java</code>
 * @author sg68373 
 */

/**
 This class is intended to fire 3045 for pre-Closure of FD A/c 

 * */

public class FixedDepositPreClosureConfirmService extends BaseService {
	private static final Logger LOGGER = Logger.getLogger(FixedDepositPreClosureConfirmService.class);

	private FixedDepositBP fixedDepositBP;
	private FixedDepositPreClosureBP fixedDepositPreClosureBP;
	private FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl;

	public Map execute(Map inputParams) {
		LOGGER.info("execute(..) Starts here");

		String fdAccountNo = (String) inputParams.get("fdAccountNo");
		String debitAccountNo = (String) inputParams.get("debitAccountNo");
		String remarks = (String) inputParams.get("remarks");
		String bankCode = (String) inputParams.get("bankCode");
		
		String userName = (String) inputParams.get("userName");
		String branchCode = (String) inputParams.get("debitBranchCode");
		
		

		/*if((branchCode!=null && "1".equals(branchCode.substring(0,1))) && bankCode!=null && "0".equals(bankCode)) {
			LOGGER.info("branchCode before replace::"+ branchCode);
			branchCode = branchCode.replaceFirst("1", "A");
			LOGGER.info("branchCode After replace::"+ branchCode);
		}
		*/
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("FD Account No -->" + fdAccountNo);
			
			LOGGER.info("Remarks       -->" + remarks);
			LOGGER.info("userName      -->" + userName);
			LOGGER.info("Bank code     -->" + bankCode);
			LOGGER.info("BranchCode    -->" + branchCode);
			
		}
		
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		
		Map outParams = new HashMap();
		FixedDepositModel preClosureModel = new FixedDepositModel();
		// List response3045List=new ArrayList();

		try { 
		
					/* Getting the sequence value for preClosure Reference No */
					String fdReferenceNo = fixedDepositPreClosureDAOImpl.getPreclosureReferenceNo();
					outParams.put("fdReferenceNo", fdReferenceNo);
					outParams.put("fixedDepositAccountNo", fdAccountNo);
					outParams.put("debitAccountNo", debitAccountNo);
					preClosureModel.setCreditAccountNo(fdAccountNo);
					preClosureModel.setDebitAccountNo(debitAccountNo);
					preClosureModel.setPreClosureReferenceNo(fdReferenceNo);
					preClosureModel.setUserName(userName);
					preClosureModel.setDebitBranchCode(branchCode);
					preClosureModel.setPreClosureRemarks(remarks);
					preClosureModel.setPreclosureReqRaisedBy(userName);
					
					LOGGER.info("preclosure remarks in service: "+preClosureModel.getPreClosureRemarks());

					Map result=new HashMap();
					result=fixedDepositPreClosureDAOImpl.updatePreclosureDetails(preClosureModel);
					Integer pendingcount=0;
					Integer rowseffected=0;
					if(result.get("pendingCount")!=null)
						
					{
						pendingcount =(Integer) result.get("pendingCount");
					}
					if(result.get("rowsEffected")!=null)
						
					{
						rowseffected =(Integer) result.get("rowsEffected");
					}

						
					if(pendingcount.intValue() > 0)
					{
						applicationResponse.setErrorCode("PR001");
					}
					
					else if (pendingcount.intValue()==0 && rowseffected.intValue()>0)
					{
						
						applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
					}
			
		} catch (SBIApplicationException sbiExp) {
			LOGGER.error("SBI Application Exception Occured", sbiExp);
			
			LOGGER.info("ERROR: ErrorCode -->"+sbiExp.getErrorCode());
			applicationResponse.setErrorCode(sbiExp.getErrorCode());
			applicationResponse.setErrorStatus(ServiceErrorConstants.FAILURE);

		/*	if("0110".equals(sbiExp.getErrorCode())){   // When Account is already closed at Branch Level
				LOGGER.info("ERROR: ErrorCode -->"+sbiExp.getErrorCode());
				applicationResponse.setErrorCode(sbiExp.getErrorCode());
				applicationResponse.setErrorStatus(ServiceErrorConstants.FAILURE);
				fixedDepositPreClosureBP.populate3045Response(response3045List, preClosureModel);
			} 
			else{
				LOGGER.info("ERROR: ErrorCode -->"+sbiExp.getErrorCode());
				applicationResponse.setErrorCode(sbiExp.getErrorCode());
				applicationResponse.setErrorStatus(ServiceErrorConstants.FAILURE);
			} */

		} catch (Exception e) {
			LOGGER.error("Unable to retrieve the data...", e);
			applicationResponse.setErrorCode(ServiceErrorConstants.SE003);
			applicationResponse.setErrorStatus(ServiceErrorConstants.FAILURE);
		}

		outParams.put(ServiceConstant.APPLICATION_RESPONSE, applicationResponse);
		LOGGER.info("execute(..) Ends here");
		return outParams;
	}

	public void setFixedDepositBP(FixedDepositBP fixedDepositBP) {
		this.fixedDepositBP = fixedDepositBP;
	}

	public void setFixedDepositPreClosureBP(
			FixedDepositPreClosureBP fixedDepositPreClosureBP) {
		this.fixedDepositPreClosureBP = fixedDepositPreClosureBP;
	}

	public void setFixedDepositPreClosureDAOImpl(
			FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl) {
		this.fixedDepositPreClosureDAOImpl = fixedDepositPreClosureDAOImpl;
	}
}