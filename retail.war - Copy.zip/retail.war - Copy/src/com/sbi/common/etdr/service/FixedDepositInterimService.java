/*
 * Created on Nov 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 26, 2005 Sairam.T - Initial Creation
//Jan 31, 2006 Murugan K - Log changes
package com.sbi.common.etdr.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.etdr.bp.FixedDepositBP;
import com.sbi.common.etdr.bp.FixedDepositEnquiryBP;
import com.sbi.common.etdr.dao.EtdrRuleMasterDAO;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.etdr.utils.FixedDepositUtils;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.UtilsConstant;



public class FixedDepositInterimService  extends BaseService {
	
	private Logger logger = Logger.getLogger(getClass());
	
	private FixedDepositUtils fixedDepositUtils;
	
	private FixedDepositBP fixedDepositBP;
	
	private ReferenceDataCache referenceDataCache;
	
	private FixedDepositEnquiryBP fixedDepositEnquiryBP;
	
	private EtdrRuleMasterDAO etdrRuleMasterDAOImpl;
	
	public Map execute(Map inputParams) {
		Map outParams=new HashMap();
		
		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		
		String userName=(String)inputParams.get("userName");
		String corporateId=(String)inputParams.get("corporateId");
		String bankCode=(String)inputParams.get("bankCode");
		String merchantCode=(String)inputParams.get("transactionType");
		String tenureType=(String)inputParams.get("tenureType");
		String intPayout=(String)inputParams.get("intPayout");
		String cumulativeType=(String)inputParams.get("cumulativeType");
		String debitProductCode=(String)inputParams.get("debitProductCode");
		String fdValidationStatus="";
		String debitAccountNo=(String)inputParams.get("debitAccountNo");
		String fixedorfloatType=(String)inputParams.get("FixedorFloattype");
		String isSeniorCitizen=(String)inputParams.get("isSeniorCitizen"); //senior citizen
		
		String strMonth = (String) inputParams.get("month");
		String strDate = (String) inputParams.get("date");
		String strYear = (String) inputParams.get("year");
		String isSbhDouble = ((String)inputParams.get("sbhdouble"));
		String autoRenewTenureType = ((String)inputParams.get("autoRenewTenureType"));
		String autoRenewMonth = (String) inputParams.get("autoRenewMonth");
		String autoRenewDate = (String) inputParams.get("autoRenewDate");
		String autoRenewYear = (String) inputParams.get("autoRenewYear");
		String autoRenewIntPayout = (String)inputParams.get("autoRenewIntPayout");
		String branchCode = (String) inputParams.get(UtilsConstant.DEBIT_BRANCH_CODE);
		
		if("floatrate".equalsIgnoreCase(fixedorfloatType)){
			strYear = (String) inputParams.get("floatYear");
			logger.info("Fixed/FloatType --->"+fixedorfloatType +" year ::"+strYear);
		
		}
		
		FixedDepositModel fixedDepositModel= new FixedDepositModel();
		boolean isODAccount = false;
		try{
			if(debitProductCode!=null){
				String savecurrentCode = debitProductCode.substring(0,1);
		        if(!savecurrentCode.equalsIgnoreCase("1") && ! savecurrentCode.equalsIgnoreCase("5") ){//product code starts with 1 or 5 is allowed to open e-TDR
		        	SBIApplicationException.throwException("FD022");
		        }
			}else
				SBIApplicationException.throwException("FD003");
			
			Double debitAmount=new Double(((String)inputParams.get("amountTransfer")));
			Integer totalNoOfDays;
			Integer autoRenewalTotalNoOfDays=new Integer(0);
			logger.info("  bankCode  "+bankCode+"  userName  "+userName +"  merchantCode "+merchantCode);
			
			Integer corporateIdIntObj=null;
			if(corporateId!=null && corporateId.length()>0) {
				corporateIdIntObj=Integer.parseInt(corporateId);
			}
			
			Double branchLimit = etdrRuleMasterDAOImpl.findBranchLimit(debitAccountNo,branchCode,debitAmount,corporateIdIntObj);
			
			
			if (userName != null && debitAmount>=1000 && branchLimit!=null)
			{
				
				if (tenureType.equalsIgnoreCase("daymode") || tenureType.equalsIgnoreCase("maturitymode"))
				{
					// totalNoOfDays=Long.parseLong(days);
					
					totalNoOfDays = new Integer(((String) inputParams.get("days")));
					logger.info("days in daymode" + totalNoOfDays);
				}
				else
				{
					if (strDate == null){
						strDate = "00";
					}
					if (strMonth == null){
						strMonth = "00";
					}
					if (strYear == null){
						strYear = "00";
					}
					Integer year = new Integer(strYear);
					Integer month = new Integer(strMonth);
					Integer days = new Integer(strDate);
					inputParams.put("days", strDate);
					inputParams.put("month", strMonth);
					inputParams.put("year", strYear);
					totalNoOfDays = fixedDepositUtils.daysConvertor(year,month,days);
					String floatYr=(String)inputParams.get("year");
					logger.info("year for 5--->"+floatYr);
					/* If Float Rate and Yr == 5 then increment 1 day with totalNoOfdays*/
					if("floatrate".equalsIgnoreCase(fixedorfloatType) && "5".equals(floatYr)){
							totalNoOfDays=totalNoOfDays+1;
							logger.info("Total No. of Days for 5 Years -->"+totalNoOfDays);
					}
				}
				inputParams.put("totalNoOfDays",totalNoOfDays);
				
				if(cumulativeType!=null && cumulativeType.equalsIgnoreCase("TDR") && totalNoOfDays!=null && totalNoOfDays<7){
					SBIApplicationException.throwException("FD047");
				}else if(cumulativeType!=null && cumulativeType.equalsIgnoreCase("STDR") && totalNoOfDays!=null && totalNoOfDays<181){
					SBIApplicationException.throwException("FD048");
				}
				if ("renewaldaymode".equalsIgnoreCase(autoRenewTenureType)) {
					String autoRenewDays=(String)inputParams.get("autoRenewDays");
					if(autoRenewDays!=null && !"".equals(autoRenewDays))
							autoRenewalTotalNoOfDays = new Integer(autoRenewDays);
					logger.info("days in renewal daymode" + inputParams.get("autoRenewDays"));
				} else {
					if (autoRenewDate == null){
						autoRenewDate = "00";
					}			
					if (autoRenewMonth == null){
						autoRenewMonth = "00";
					}			
					if (autoRenewYear == null){
						autoRenewYear = "00";
					}
					Integer renewalYear = new Integer(autoRenewYear);
					Integer renewalMonth = new Integer(autoRenewMonth);
					Integer renewalDays = new Integer(autoRenewDate);

					inputParams.put("autoRenewDays", autoRenewDate);
					inputParams.put("autoRenewMonth", autoRenewMonth);
					inputParams.put("autoRenewYear", autoRenewYear);				   
					autoRenewalTotalNoOfDays = fixedDepositUtils.daysConvertor(renewalYear,renewalMonth,renewalDays);
				}		
			
			if(!"C".equalsIgnoreCase(((String)inputParams.get("autoRenewType")))){
			autoRenewIntPayout=fixedDepositUtils.getInterestPayout(fixedorfloatType,cumulativeType,autoRenewalTotalNoOfDays,autoRenewIntPayout);
			}else if("C".equalsIgnoreCase(((String)inputParams.get("autoRenewType")))) {
				autoRenewIntPayout=fixedDepositUtils.getInterestPayout(fixedorfloatType,cumulativeType,totalNoOfDays,intPayout);
			}
			logger.info("InterestPayout For Auto Renew -->"+autoRenewIntPayout);
			inputParams.put("autoRenewalIntPayout",autoRenewIntPayout);
			inputParams.put("autoRenewalTotalNoOfDays",autoRenewalTotalNoOfDays);
				
				// Added for Floating Rate CR. only for SBI. starts here
				if("0".equals(bankCode)){
					intPayout=fixedDepositUtils.getInterestPayout(fixedorfloatType,cumulativeType,totalNoOfDays,intPayout);
			}else if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode)){
					intPayout=fixedDepositUtils.getInterestPayoutForAssociate(cumulativeType, totalNoOfDays, intPayout);
				}
				// Added for Floating Rate CR. only for SBI. Ends here
				logger.info("FixedorFloat Type ::::"+fixedorfloatType+" intPayout:::;" + intPayout + " totalNoOfDays " + totalNoOfDays);
				 fixedDepositModel = constructFdModel(inputParams, tenureType,
						intPayout,fixedDepositModel);
				
				logger.info("isSBH Double -->"+fixedDepositModel.getIsSbhDouble());
				
				
				Map enquiryMap = new HashMap();
				enquiryMap.put("account_no", inputParams.get(UtilsConstant.DEBIT_ACCOUNT_NO));
				enquiryMap.put("txnno", Constants.SHORT_ENQ_DEPOSITS_TXNNO);
				enquiryMap.put("bankCode", bankCode);
				Map cifEnquiryMap = fixedDepositBP.retrieveCIFNumberOnly(enquiryMap, debitAmount);
				logger.info("cifEnquiryMap ::" + cifEnquiryMap);
				String segmentCode=(String)cifEnquiryMap.get("segment_code");
				logger.info(segmentCode);
				fixedDepositModel.setSegmentCode(segmentCode);
				
				//if("0".equals(bankCode) || "1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || ("2".equals(bankCode) && !"Yes".equalsIgnoreCase(fixedDepositModel.getIsSbhDouble()))) {
					outParams = fixedDepositBP.getFDProductType(fixedDepositModel,bankCode);
					fdValidationStatus = (String) outParams.get("fdValidationStatus");
				/*} else if("2".equals(bankCode) && "Yes".equalsIgnoreCase(fixedDepositModel.getIsSbhDouble())){
					fdValidationStatus = (String)outParams.get("fdValidationStatus");
				}*/
								
				if (fdValidationStatus != null && fdValidationStatus.equalsIgnoreCase("validationSuccess"))
				{
					
					
					if (cifEnquiryMap != null)
					{
						String cifNo=(String)cifEnquiryMap.get("cif_no");
						fixedDepositModel.setCustomerNo(cifNo);
						fixedDepositModel.setUserName(userName);
						fixedDepositModel.setDebitHolderName((String)cifEnquiryMap.get("name"));
						String modeOfOperation = fixedDepositBP.getFDAccountType((String) inputParams
								.get(UtilsConstant.DEBIT_ACCOUNT_NO),isODAccount,bankCode);//bank code added for associate bank by viswa
                        logger.info("Mode Of Operation" + modeOfOperation);
						if (modeOfOperation != null)
						{
							fixedDepositModel.setFdAccNature(modeOfOperation);

						}
						
						fixedDepositModel=getMaturityDetails(fixedDepositModel);//for txn 000473 maturity amount instruction

						if(fixedDepositModel.getMaturityAmount()==null || "".equals(fixedDepositModel.getMaturityAmount()))
						{
							applicationResponse.setErrorCode("FD003");
							SBIApplicationException.throwException("FD003");
						}
						Map branchMap = null; 
						if( bankCode!=null && bankCode.equalsIgnoreCase("0") )	
								branchMap = referenceDataCache.getReferenceData("allBranchDataKey");
						else if ( bankCode!=null && ("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode) || "7".equals(bankCode) || "2".equals(bankCode)))	
								branchMap = referenceDataCache.getReferenceData("branchDataKey");
						
						
						
						if( (bankCode!=null && bankCode.equalsIgnoreCase("0") ) && 
								( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("1") ) ){
				        	logger.info("branchCode before replace::"+ branchCode);
				        	branchCode = branchCode.replaceFirst("1", "A");
				    	}
						
						logger.info("bankCode ::"+ bankCode+" branchCode ::"+branchCode);
						String branchName=(String) branchMap.get(branchCode);
						logger.info("Branch Code -->"+branchCode+" "+"Branch Name --->"+branchName+" "+"BankCode --->"+bankCode);
						logger.info("after calling totalNoOfDays after daysConvertor: and createFixedDeposit model"
								+ totalNoOfDays);
						
						//int authOption=fixedDepositBP.getAuthOption(userName, debitAccountNo, branchCode, debitAmount);
						//fixedDepositModel.setAuthOption(authOption);
						outParams.put("fdValidationStatus", fdValidationStatus);
						outParams.put("fixedDepositModel", fixedDepositModel);
						outParams.put("totalNoOfDays", totalNoOfDays);
						outParams.put("debitAccountNo", inputParams.get(UtilsConstant.DEBIT_ACCOUNT_NO));
						outParams.put("debitBranchCode", inputParams.get(UtilsConstant.DEBIT_BRANCH_CODE));
						outParams.put("branchName",branchName);
						outParams.put("cumulativeType", cumulativeType);
						outParams.put("isSeniorCitizen",isSeniorCitizen);
						outParams.put("intPayout", intPayout);
						outParams.put("debitAmount", debitAmount);
						outParams.put("autoRenewalTotalNoOfDays", autoRenewalTotalNoOfDays);
						outParams.put("autoRenewIntPayout", autoRenewIntPayout);
						outParams.put("isSbhDouble",isSbhDouble);
						logger.info("outparams  Map contains: " + outParams);
						applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
					}else {
						applicationResponse.setErrorCode("FD003");
					}
				}else {	outParams.put("isSeniorCitizen",isSeniorCitizen);
				    outParams.put("isSbhDouble",isSbhDouble);
					outParams.put("fdValidationStatus", fdValidationStatus);
					applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
				}
				
			}else {
				if(userName == null) {
					applicationResponse.setErrorCode("FD003");
				}else if(debitAmount < 1000) {
					applicationResponse.setErrorCode("FD046");
				}else if(branchLimit == null) {
					String amount = StringUtils.formatAmount(debitAmount.toString());
					String errorMsg = "No authorizers for this account for a debit amount of " + amount;
					logger.info("Rule validation error message ::" + errorMsg );
					applicationResponse.setErrorCode("ETDRRULEVALFAILURE");
					applicationResponse.setErrorMessage(errorMsg);
					applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
				}
				
			}
		}
		catch(SBIApplicationException e){
			logger.error("SBI Application Exception Occured",e);
			applicationResponse.setErrorCode(e.getErrorCode());
		}
		catch(Exception e){
			logger.error("exception occured",e);
			applicationResponse.setErrorCode("FD003");
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);
		return outParams;
	}
	
	
	
	private FixedDepositModel constructFdModel(Map inputParams,String tenureType,String intPayout,FixedDepositModel fixedDeposit)
	{
		logger.info(" constructFdModel method begins");
		//FixedDepositModel fixedDeposit = new FixedDepositModel();
		fixedDeposit.setDebitAccountNo((String) inputParams.get("debitAccountNo"));
		fixedDeposit.setDebitBranchCode((String) inputParams.get("debitBranchCode"));
		fixedDeposit.setDebitProductCode((String) inputParams.get("debitProductCode"));
		fixedDeposit.setDebitProductType((String) inputParams.get("debitAccountType"));
		fixedDeposit.setFdAmount(new Double(((String) inputParams.get("amountTransfer"))));
		fixedDeposit.setDays(new Integer(((String) inputParams.get("days"))));
		fixedDeposit.setScheduled(true);
		
		if (tenureType.equalsIgnoreCase("yearmode"))
		{
			fixedDeposit.setDtMonYr(true);
			fixedDeposit.setYears(new Integer(((String) inputParams.get("year"))));
			fixedDeposit.setMonths(new Integer(((String) inputParams.get("month"))));
		}
		else
		{
			fixedDeposit.setDtMonYr(false);
		}
		fixedDeposit.setSelectedMaturityDate((String)inputParams.get("maturityDate"));
		fixedDeposit.setFdType((String) inputParams.get("cumulativeType"));
		// Added by Srinivas For Floating Rate CR. Starts here
		fixedDeposit.setTypeOfInterestRate((String)inputParams.get("FixedorFloattype"));
		String bankCode=((String)inputParams.get("bankCode"));
		logger.info("BankCode -->"+bankCode);
		fixedDeposit.setBankCode(bankCode);
		if(fixedDeposit.getTypeOfInterestRate()!=null){
			if("floatrate".equalsIgnoreCase(fixedDeposit.getTypeOfInterestRate())){
				logger.info("inside constructFDModel(..) TypeOfInterestRate-->"+fixedDeposit.getTypeOfInterestRate());
				fixedDeposit.setDtMonYr(true);
				fixedDeposit.setYears(new Integer(((String) inputParams.get("year"))));
				logger.info("Years for Float Rate--->:"+fixedDeposit.getYears());
			}
		}
		// Added by Srinivas For Floating Rate CR. Starts here
		fixedDeposit.setInterestPayout(intPayout);
		fixedDeposit.setTenureInDays((Integer)inputParams.get("totalNoOfDays"));
		fixedDeposit.setTxnRemarks(null);//TODO Requested by archana V
		fixedDeposit.setIsSeniorCitizen((String) inputParams.get("isSeniorCitizen"));	//senior citizen
		fixedDeposit.setChannelType((String) inputParams.get("channelType"));
		constructAutoRenewalFdModel(inputParams,fixedDeposit);
		if("2".equals(bankCode) && "Yes".equalsIgnoreCase((String)inputParams.get("sbhdouble"))){
			fixedDeposit.setIsSbhDouble("Yes");
		}else if("2".equals(bankCode) && "No".equalsIgnoreCase((String)inputParams.get("sbhdouble"))){
			fixedDeposit.setIsSbhDouble("No");
		}else if(!"2".equals(bankCode)){
			fixedDeposit.setIsSbhDouble(" ");
		}
		fixedDeposit.setCorporateId((String)inputParams.get("corporateId"));
		logger.info(" constructFdModel method ends");
		return fixedDeposit;
	}
	
	//Added by Manoj
	//This method is to enquire the Maturity Amount, Maturity Date and Interest Rate by firing
	//473 request to the core.
	private FixedDepositModel getMaturityDetails(FixedDepositModel fixedDepositModel){
		fixedDepositModel.setFdCreationDate(new Date());
		Map inParam=new HashMap(); 
		inParam.put("fixedDepositModel", fixedDepositModel);
		inParam.put("bankCode", fixedDepositModel.getBankCode());
		Map enquiryOutParams=new HashMap();
		enquiryOutParams = fixedDepositEnquiryBP.fixedDepositEnquiry(inParam);
		logger.info("enquiry outparams - "+enquiryOutParams);
		if(enquiryOutParams != null && enquiryOutParams.size()>0){
			FixedDepositModel fixedDepositModelEnquiry = fixedDepositEnquiryBP.populate473Response(enquiryOutParams);
			if(fixedDepositModelEnquiry != null){
				logger.info("Maturity amount - "+fixedDepositModelEnquiry.getMaturityAmount());
				logger.info("Maturity date - "+fixedDepositModelEnquiry.getMaturityDate());
				logger.info("ROI - "+fixedDepositModelEnquiry.getInterestRate());
				logger.info("TDR Payout Amount - "+fixedDepositModelEnquiry.getTdrPayoutAmount());
				
				fixedDepositModel.setMaturityAmount(fixedDepositModelEnquiry.getMaturityAmount());
				fixedDepositModel.setMaturityDate(fixedDepositModelEnquiry.getMaturityDate());
				fixedDepositModel.setInterestRate(fixedDepositModelEnquiry.getInterestRate());
				fixedDepositModel.setTdrPayoutAmount(fixedDepositModelEnquiry.getTdrPayoutAmount());
			}
		}
		return fixedDepositModel;
	}
	
	private FixedDepositModel constructAutoRenewalFdModel(Map inputParams,FixedDepositModel fixedDeposit){
		logger.info("constructAutoRenewalFdModel(..) Starts Here");
		logger.info("inputParams->"+inputParams);		
		fixedDeposit.setAutoRenewType(((String)inputParams.get("autoRenewType")));
		String renewalType = fixedDepositBP.getAutoRenewDetails(fixedDeposit.getAutoRenewType());
		fixedDeposit.setAutoRenewDescription(renewalType);
		fixedDeposit.setAutoRenewDays(new Integer(inputParams.get("autoRenewDays").toString()));
		fixedDeposit.setAutoRenewInterestPayout(((String)inputParams.get("autoRenewalIntPayout")));
		fixedDeposit.setAutoRenewTenureInDays((Integer)inputParams.get("autoRenewalTotalNoOfDays"));
		
		if ("renewalyearmode".equalsIgnoreCase(((String)inputParams.get("autoRenewTenureType")))){
			fixedDeposit.setAutoRenewDtMonYr(true);
			fixedDeposit.setAutoRenewYears(new Integer(((String) inputParams.get("autoRenewYear"))));
			fixedDeposit.setAutoRenewMonths(new Integer(((String) inputParams.get("autoRenewMonth"))));
		} else {
			fixedDeposit.setAutoRenewDtMonYr(false);
		}
		
		logger.info("FixedDepositModel Information for Maturity Instruction ...>"+fixedDeposit);
		
		logger.info("constructAutoRenewalFdModel(..) Ends Here");
		return fixedDeposit;
	}

	public String validatePANRequest(Map inputParams,FixedDepositModel fdModel){
		logger.info("validatePANRequest(...) Starts Here");
		String panNoFromCore ="";	
			logger.info("inside PAN Implementation .."+fdModel.getFdAmount());
			List panResponseList = fixedDepositBP.construct67050Request(inputParams,fdModel);
			if(panResponseList!=null && panResponseList.size()>0){
				panNoFromCore =((String)((Map)(panResponseList.get(0))).get("data2")).substring(405,424);
				logger.info("PAN Number From CORE ::" + panNoFromCore);
			}
		logger.info("validatePANRequest(...) Ends Here");
		return panNoFromCore;		
	}

	public boolean checkForNREProductCode(String nredebitProductCode){
		logger.info("checkForNREProductCode(...) Starts Here..");
		boolean isAvail=false;
		if("1031".equals(nredebitProductCode.substring(0,4))){
			isAvail=true;			
		}else if("14".equals(nredebitProductCode.substring(2,4))) {
			isAvail=true;
		}else {
			isAvail=false;
		}
		logger.info("checkForNREProductCode(...) Ends Here.."+isAvail);
		return isAvail;		
	}

	public void getSeniorCitizenDetails(Map inputParams,FixedDepositModel fixedDepositModel,SBIApplicationResponse applicationResponse) {
		logger.info("getSeniorCitizenDetails(..) Starts Here");
		Map seniorCitizenMap = new HashMap();
		seniorCitizenMap.put("account_no", inputParams.get(UtilsConstant.DEBIT_ACCOUNT_NO));
		seniorCitizenMap.put("txnno", "000400");
		seniorCitizenMap.put("bankCode", (String)inputParams.get("bankCode"));
		String customerNo = fixedDepositBP.retrieveCIFNumber(seniorCitizenMap, new Double(((String)inputParams.get("amountTransfer"))));
		logger.info("CIF Number -->" + customerNo);
		
		if (customerNo != null) {
			fixedDepositModel.setCustomerNo(customerNo);
			int age=0;
			List dobResponseList = fixedDepositBP.construct67050Request(inputParams,fixedDepositModel);					
			if(dobResponseList!=null && dobResponseList.size()>0){
				String dateOfBirth =((String)((Map)(dobResponseList.get(0))).get("data2")).substring(227,235);
				logger.info("Date Of Birth ::" + dateOfBirth);
				if(dateOfBirth!=null && dateOfBirth.trim().length()>0) {

					String day = dateOfBirth.substring(0,2);
					String month= dateOfBirth.substring(2,4);
					String year = dateOfBirth.substring(4,8);

					int dd=Integer.parseInt(day);
					int mm=Integer.parseInt(month);
					int yy=Integer.parseInt(year);
					age = fixedDepositUtils.calculateMyAge(yy,mm,dd);
					logger.info("Age as on :"+dd+"/"+mm+"/"+yy +" is -->"+age);
				}
				else  {
					applicationResponse.setErrorCode("FD035");
					SBIApplicationException.throwException("FD035");
				}								
				if(age<60 || age>110) {
					applicationResponse.setErrorCode("FD034");
					SBIApplicationException.throwException("FD034");
				}						
			}						
			else{
				applicationResponse.setErrorCode("FD003");
				SBIApplicationException.throwException("FD003");
			}				
		} else{
			applicationResponse.setErrorCode("FD003");
			SBIApplicationException.throwException("FD003");
		}
		logger.info("getSeniorCitizenDetails(..) Ends Here");
		//return fixedDepositModel;
	}
	
	public void setFixedDepositUtils(FixedDepositUtils fixedDepositUtils)
	{
		this.fixedDepositUtils = fixedDepositUtils;
	}
	
	
	public void setFixedDepositBP(FixedDepositBP fixedDepositBP)
	{
		this.fixedDepositBP = fixedDepositBP;
	}
	
	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	
	public void setFixedDepositEnquiryBP(FixedDepositEnquiryBP fixedDepositEnquiryBP) {
		this.fixedDepositEnquiryBP = fixedDepositEnquiryBP;
	}

	public void setEtdrRuleMasterDAOImpl(EtdrRuleMasterDAO etdrRuleMasterDAOImpl) {
		this.etdrRuleMasterDAOImpl = etdrRuleMasterDAOImpl;
	}
	
	
}
