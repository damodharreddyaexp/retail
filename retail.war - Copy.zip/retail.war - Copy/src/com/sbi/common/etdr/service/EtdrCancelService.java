/*    
 * EchequesDisplayService .java
 * Created on Aug 30, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $    
 */
//History
//Aug 30, 2006 MEENA K. - Initial Creation

package com.sbi.common.etdr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.bp.EtdrTransactionManageBP;
import com.sbi.common.etdr.model.EtdrMaster;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;

public class EtdrCancelService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private EtdrTransactionManageBP etdrTransactionManageBP;

	public Map execute(Map inparams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		Map outParams = new HashMap();
		int updateCount=0;
		EtdrMaster etdrMaster = null;
		try {
			String referenceNo = (String) inparams.get("referenceNo");
			
			if (referenceNo != null) {
				
				updateCount = etdrTransactionManageBP.cancelEtdrRequest(inparams);
				
				if (updateCount > 0) {
					response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					outParams.put("referenceNo", referenceNo);
					
				} else {
					response.setErrorCode("FP005");//Unable to process the request
				}
			} else {
				response.setErrorCode("CUS006"); // input values are null.
			}

		} catch (SBIApplicationException appEx) {
			logger.error(LoggingConstants.EXCEPTION, appEx);
			response.setErrorCode(appEx.getErrorCode());

		} catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode("CUS004"); // Due to tech problem.

		}
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODEND);
		return outParams;
	}

	public void setEtdrTransactionManageBP(
			EtdrTransactionManageBP etdrTransactionManageBP) {
		this.etdrTransactionManageBP = etdrTransactionManageBP;
	}

	
}
