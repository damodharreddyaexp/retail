package com.sbi.common.etdr.service;
/* 
 * FixedDepositPreClosureInitialService.java 
 * Created on october 25, 2010
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//october 25, 2010 jyothipuram - Initial Creation
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.etdr.dao.FixedDepositPreClosureDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.CutoffTimeUtils;
import com.sbi.common.utils.StringUtils;

public class FixedDepositPreClosureInitialService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());	

	private FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl;
	private CutoffTimeUtils cutOffTimeUtils;
	
	//added method execute(Map inputParams) starts for PreCloser CR by jyothi puram

	public Map execute(Map inputParams) {
		logger.info("the execute(Map inputParams) method begins"+LoggingConstants.METHODBEGIN);
		Map outParams=new HashMap();
		Map paramMap = new HashMap();
		Timestamp payDate = StringUtils.currentTimeStamp();
		String bankCode=(String)inputParams.get("bankCode");
		String userName=(String)inputParams.get("userName");
		String corporateId=(String)inputParams.get("corporateId");
		String merchantCode=(String)inputParams.get("transactionType");
		String debitAccountNo=(String)inputParams.get(UIConstant.DEBIT_ACCOUNT_NO);
		logger.info("  bankCode  "+bankCode+"  userName  "+userName);

		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
		try{
			
			logger.info("cutofftime e-TDR outisde::::");
			logger.info("Pay date is :"+payDate);
			logger.info("merchant code is :"+merchantCode);
			logger.info("bank code is"+bankCode);
			
			outParams.put(UIConstant.DEBIT_ACCOUNT_NO,debitAccountNo);
			logger.info("debit account no is 123: "+UIConstant.DEBIT_ACCOUNT_NO);
			
			List fdAccountList= (List)fixedDepositPreClosureDAOImpl.getFdAccounts(userName,bankCode,debitAccountNo,corporateId);
			logger.info("FDAccountList-->"+fdAccountList);		
			if(fdAccountList!=null && fdAccountList.size()>0){
				
				outParams.put("fixedDepositAccount",fdAccountList);
				
				applicationResponse.setErrorStatus(ServiceConstant.SUCCESS);
			}else
			{
				applicationResponse.setErrorCode("FD031"); 
			}
			if (logger.isDebugEnabled()) {
				logger.debug(" the ritreved detailes are : " + outParams);
			}
		}
		 catch (SBIApplicationException sbiApplicationException) {
             applicationResponse.setErrorCode(sbiApplicationException.getErrorCode());
             logger.error("sbiApplicationException",sbiApplicationException);
         }
		 catch (DAOException daoException) {
			   applicationResponse.setErrorCode(daoException.getErrorCode());
	           logger.error("daoException",daoException);
         }
		catch(Exception e){
			applicationResponse.setErrorCode(ServiceErrorConstants.SE002);
			logger.error("exception occured",e);
		}
		logger.info("the execute(Map inputParams) method ends"+LoggingConstants.METHODEND);
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,applicationResponse);	
		return outParams;
	}
	
	
	//added method execute(Map inputParams)ends 

	public void setFixedDepositPreClosureDAOImpl(
			FixedDepositPreClosureDAO fixedDepositPreClosureDAOImpl) {
		this.fixedDepositPreClosureDAOImpl = fixedDepositPreClosureDAOImpl;
	}	
	public void setCutOffTimeUtils(CutoffTimeUtils cutOffTimeUtils)
	{
		this.cutOffTimeUtils = cutOffTimeUtils;
	}

}
