/**
 * @(#) EchequeMaster.java
 */

package com.sbi.common.etdr.model;

import java.sql.Timestamp;
import java.util.Date;

import org.apache.log4j.Logger;

import com.sbi.common.model.BaseModel;


public class EchequeMaster implements BaseModel

{
	protected final Logger logger = Logger.getLogger(getClass());
	private String echequeNo;
	
	private String accountNo;
	
	private String branchCode;
	
	private Timestamp echequeDate;
	
	private Double echequeAmount;
	
	private String bankTtype;
	
	private String description;
	
	private String maker;
	
	private String accountName;
	
	private Integer read;
	
	private Integer systemEdited;
	
	private Integer displayFlag;
	
	private String systemEditedReason;
	
	private String corpRefNo;

	private String branchName;
	
	private String transactType;
	
	// for RTGS/NEFT - begin
    private String merchantCode;
    
    private Double rateOfInterest;
    
    private String cardNumber;
    
    private String cardReferenceNumber;
    
    private String narration;
    
    private String cardHolderName;
    
    //Providing Transaction status link for query by account and query by echeque links - 5057
    private String businessLineId;
    
    private String status;
    
    //Added for CR 2921
    
    private String creditStatusCode;
//CR 5321 begins
	private String currentAuthLevel; 
	//CR 5531
	private String firstauth;
	private String beneficiary;
	private String secondauth;
	private Date date;
	private String firstauthdate;
	private String secondauthdate;
	
	private String thirdPartyRef;//Added for EPFO
	
	public String getThirdPartyRef() {
		return thirdPartyRef;
	}
	public void setThirdPartyRef(String thirdPartyRef) {
		this.thirdPartyRef = thirdPartyRef;
	}
	public String getFirstauthdate() {
		return firstauthdate;
	}
	public void setFirstauthdate(String firstauthdate) {
		this.firstauthdate = firstauthdate;
	}
	public String getSecondauthdate() {
		return secondauthdate;
	}
	public void setSecondauthdate(String secondauthdate) {
		this.secondauthdate = secondauthdate;
	}

	
private Timestamp scheduledDate;
	
	
	public Timestamp getScheduledDate() {
		return scheduledDate;
	}
	public void setScheduledDate(Timestamp scheduledDate) {
		this.scheduledDate = scheduledDate;
	}
    
   
    
  
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getSecondauth() {
		return secondauth;
	}
	public void setSecondauth(String secondauth) {
		if(secondauth==null)
			secondauth="-";
		this.secondauth = secondauth;
	}
	public String getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}
	public String getFirstauth() {
		return firstauth;
	}
	public void setFirstauth(String firstauth) {
		if(firstauth==null)
			firstauth="-";
		this.firstauth = firstauth;
	}
	public String getCurrentAuthLevel() {
		return currentAuthLevel;
	}
	public void setCurrentAuthLevel(String currentAuthLevel) {
		this.currentAuthLevel = currentAuthLevel;
	}
    //CR 5321 ends
    /**
     * @return Returns the businessLineId.
     */
    public String getBusinessLineId()
    {
        return businessLineId;
    }

    /**
     * @param businessLineId The businessLineId to set.
     */
    public void setBusinessLineId(String businessLineId)
    {
        this.businessLineId = businessLineId;
    }
    
	
	public String getCardHolderName()
    {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName)
    {
        this.cardHolderName = cardHolderName;
    }

    public String getCardNumber()
    {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber)
    {
        this.cardNumber = cardNumber;
    }

 

    public String getCardReferenceNumber()
    {
        return cardReferenceNumber;
    }

    public void setCardReferenceNumber(String cardReferenceNumber)
    {
        this.cardReferenceNumber = cardReferenceNumber;
    }

    public String getNarration()
    {
        return narration;
    }

    public void setNarration(String narration)
    {
        this.narration = narration;
    }

    public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public Double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(Double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	// end
	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBankTtype() {
		return bankTtype;
	}

	public void setBankTtype(String bankTtype) {
		this.bankTtype = bankTtype;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	
	public Double getEchequeAmount() {
		return echequeAmount;
	}

	public void setEchequeAmount(Double echequeAmount) {
		this.echequeAmount = echequeAmount;
	}

	public Timestamp getEchequeDate() {
		return echequeDate;
	}

	public void setEchequeDate(Timestamp echequeDate) {
		this.echequeDate = echequeDate;
	}

	public String getEchequeNo() {
		return echequeNo;
	}

	public void setEchequeNo(String echequeNo) {
		this.echequeNo = echequeNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Integer getRead() {
		return read;
	}

	public void setRead(Integer read) {
		this.read = read;
	}

	public Integer getSystemEdited() {
		return systemEdited;
	}

	public void setSystemEdited(Integer systemEdited) {
		this.systemEdited = systemEdited;
	}

	public Integer getDisplayFlag() {
		return displayFlag;
	}

	public void setDisplayFlag(Integer displayFlag) {
		this.displayFlag = displayFlag;
	}

	public String getSystemEditedReason() {
		return systemEditedReason;
	}

	public void setSystemEditedReason(String systemEditedReason) {
		this.systemEditedReason = systemEditedReason;
	}

	public String getCorpRefNo() {
		return corpRefNo;
	}

	public void setCorpRefNo(String corpRefNo) {
		this.corpRefNo = corpRefNo;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getTransactType() {
		return transactType;
	}

	public void setTransactType(String transactType) {
		this.transactType = transactType;
	}
	
	public String getCreditStatusCode() {
		return creditStatusCode;
	}

	public void setCreditStatusCode(String creditStatusCode) {
		this.creditStatusCode = creditStatusCode;
	}

	public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        
        tempStringBuf.append(echequeNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(echequeDate);
        tempStringBuf.append(" | ");
        tempStringBuf.append(echequeAmount);
        tempStringBuf.append(" | ");
        tempStringBuf.append(bankTtype);
        tempStringBuf.append(" | ");
        tempStringBuf.append(description);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maker);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(description);
        tempStringBuf.append(" | ");
        tempStringBuf.append(read);
        tempStringBuf.append(" | ");
        tempStringBuf.append(systemEdited);
        tempStringBuf.append(" | ");
        tempStringBuf.append(displayFlag);
        tempStringBuf.append(" | ");
        tempStringBuf.append(systemEditedReason);
        tempStringBuf.append(" | ");
        tempStringBuf.append(corpRefNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(transactType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(merchantCode);//CR 5057 - starts
        tempStringBuf.append(" | ");
        tempStringBuf.append(rateOfInterest);
        tempStringBuf.append(" | ");
        tempStringBuf.append(cardNumber);
        tempStringBuf.append(" | ");
        tempStringBuf.append(cardReferenceNumber);
        tempStringBuf.append(" | ");
        tempStringBuf.append(narration);
        tempStringBuf.append(" | ");
        tempStringBuf.append(cardHolderName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(businessLineId);
        tempStringBuf.append(" | ");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        tempStringBuf.append(creditStatusCode);//Added for CR 2921
        //CR 5531 - starts
        tempStringBuf.append(firstauth);
        tempStringBuf.append(" | ");
        tempStringBuf.append(beneficiary);
        tempStringBuf.append(" | ");
        tempStringBuf.append(secondauth);
        tempStringBuf.append(" | ");
        
        return tempStringBuf.toString();
    }

    /**
     * @return Returns the status.
     */
    public String getStatus()
    {
        return status;
    }

    /**
     * @param status The status to set.
     */
    public void setStatus(String status)
    {
        this.status = status;
    }
	
}
