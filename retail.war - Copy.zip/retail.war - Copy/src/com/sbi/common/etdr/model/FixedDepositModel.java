package com.sbi.common.etdr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FixedDepositModel implements Serializable {

	private String debitAccountNo;
	private String debitBranchCode;
    private String customerNo;
	private String userName;
	private String fdType;
    private int tenureInDays;
	private boolean dtMonYr;
	private int days;
	private int months;
	private int years;
	private String fdAccountNo;
	private String fdBranchCode;
	private Double fdAmount;
	private String interestPayout;
	private String fdAccNature;
	private String debitProductCode;
	private String debitProductType;
	private String maturityDate;
	private String maturityAmount;
	private String status;
    private List jointAccList = new ArrayList() ;
    private Double fdMinAmount;
    private Double fdMaxAmount;
	private int minTenureDays;
    private int maxTenureDays;
	private Double interestRate;
    private Double principalAmount;
    private Date valueDate;
    private String socCode;
	private String txnRemarks;
	private String fdReferenceNo;
	private String referenceNo;
	private boolean isScheduled=false;
	private String fdAccProductCode;
	private Date scheduledDate;
	private String statusDescription;
	private String typeOfInterestRate;
	private String corporateId;
	private String preClosureSchedule;	
	private String preClosureReferenceNo;
	private String preClosureRemarks;	
	private String preClosureStatus;
    private String creditAccountNo;
    private String closedDate;
    private Date fdCreationDate;
    private String coreTxnTobeFired;
    private String autoRenewType;
	private String autoRenewDescription;
	private String autoRenewReqd;
    private int autoRenewTenureInDays;
	private boolean autoRenewDtMonYr;
	private int autoRenewDays;
	private int autoRenewMonths;
	private int autoRenewYears;
	private String autoRenewInterestPayout;
	private String isSeniorCitizen;
	private String selectedMaturityDate;
	private String channelType;
	private String amountPayable;
	private String rate;
	private String penalityAmount;
	private String bankCode;
	private int authOption;
	private String segmentCode;
	private String auth1Name;
	private String auth2Name;
	private String authStatus;
	private String debitHolderName;
	private Integer smallFlag;
	private String preclosureReqRaisedBy;
	private String typeOfModule;
	private String availableBalance;
	
	
	public String getTypeOfInterestRate() {
		return typeOfInterestRate;
	}
	public void setTypeOfInterestRate(String typeOfInterestRate) {
		this.typeOfInterestRate = typeOfInterestRate;
	}
	public String getFdReferenceNo() {
		return fdReferenceNo;
	}
	public void setFdReferenceNo(String fdReferenceNo) {
		this.fdReferenceNo = fdReferenceNo;
	}
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	public boolean isScheduled() {
		return isScheduled;
	}
	public void setScheduled(boolean isScheduled) {
		this.isScheduled = isScheduled;
	}


    public String toString()
    {
       StringBuffer stringBuffer=new StringBuffer();
       stringBuffer.append("fdMaxAmount: "+fdMaxAmount);
       stringBuffer.append("|");
       stringBuffer.append("fdType: "+fdType);
       stringBuffer.append("|");
       stringBuffer.append("isScheduled ::"+isScheduled);
       stringBuffer.append("|");
       stringBuffer.append("referenceNo ::"+referenceNo);
       
        return stringBuffer.toString();
    }
    public String getDebitAccountNo() {
		return debitAccountNo;
	}
	public void setDebitAccountNo(String debitAccountNo) {
		this.debitAccountNo = debitAccountNo;
	}
	public String getDebitBranchCode() {
		return debitBranchCode;
	}
	public void setDebitBranchCode(String debitBranchCode) {
		this.debitBranchCode = debitBranchCode;
	}
	public String getFdAccountNo() {
		return fdAccountNo;
	}
	public void setFdAccountNo(String fdAccountNo) {
		this.fdAccountNo = fdAccountNo;
	}
	public Double getFdAmount() {
		return fdAmount;
	}
	public void setFdAmount(Double fdAmount) {
		this.fdAmount = fdAmount;
	}
	public String getFdBranchCode() {
		return fdBranchCode;
	}
	public void setFdBranchCode(String fdBranchCode) {
		this.fdBranchCode = fdBranchCode;
	}
	public String getInterestPayout() {
		return interestPayout;
	}
	public void setInterestPayout(String interestPayout) {
		this.interestPayout = interestPayout;
	}
	
	
	public String getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public List getJointAccList() {
		return jointAccList;
	}
	public void setJointAccList(List jointAccList) {
		this.jointAccList = jointAccList;
	}
	public String getFdAccNature() {
		return fdAccNature;
	}
	public void setFdAccNature(String fdAccNature) {
		this.fdAccNature = fdAccNature;
	}
    public int getDays(){
        return days;
    }
    public void setDays(int days){
        this.days = days;
    }
    
    public int getTenureInDays() {
		return tenureInDays;
	}
	public void setTenureInDays(int tenureInDays) {
		this.tenureInDays = tenureInDays;
	}
	public String getFdType() {
		return fdType;
	}
	public void setFdType(String fdType) {
		this.fdType = fdType;
	}
	public int getMonths() {
		return months;
	}
	public void setMonths(int months) {
		this.months = months;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	public String getDebitProductCode() {
		return debitProductCode;
	}
	public void setDebitProductCode(String debitProductCode) {
		this.debitProductCode = debitProductCode;
	}
	public String getDebitProductType() {
		return debitProductType;
	}
	public void setDebitProductType(String debitProductType) {
		this.debitProductType = debitProductType;
	}
	public Double getFdMaxAmount(){
    	return fdMaxAmount;
    }
    public void setFdMaxAmount(Double fdMaxAmount){
        if(fdMaxAmount!=null)
        	this.fdMaxAmount = Math.floor(fdMaxAmount);
    }
    public Double getFdMinAmount(){
        return fdMinAmount;
    }
    public void setFdMinAmount(Double fdMinAmount){
        this.fdMinAmount = fdMinAmount;
    }
    public int getMaxTenureDays(){
        return maxTenureDays;
    }
    public void setMaxTenureDays(int maxTenureDays){
        this.maxTenureDays = maxTenureDays;
    }
    public int getMinTenureDays()
    {
        return minTenureDays;
    }
    public void setMinTenureDays(int minTenureDays)
    {
        this.minTenureDays = minTenureDays;
    }
  
    public String getTxnRemarks()
    {
        return txnRemarks;
    }
    public void setTxnRemarks(String txnRemarks)
    {
        this.txnRemarks = txnRemarks;
    }
    
    public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}
	
	public void setPrincipalAmount(Double principalAmount) {
		this.principalAmount = principalAmount;
	}
	public Double getInterestRate() {
		return interestRate;
	}
	public Double getPrincipalAmount() {
		return principalAmount;
	}
	public Date getValueDate() {
		return valueDate;
	}
	public String getCustomerNo()
    {
        return customerNo;
    }
    public void setCustomerNo(String customerNo)
    {
        this.customerNo = customerNo;
    }
    public String getFdAccProductCode()
    {
        return fdAccProductCode;
    }
    public void setFdAccProductCode(String fdAccProductCode)
    {
        this.fdAccProductCode = fdAccProductCode;
    }
	public String getSocCode() {
		return socCode;
	}
	public void setSocCode(String socCode) {
		this.socCode = socCode;
	}
	  public boolean isDtMonYr() {
			return dtMonYr;
	}
	public void setDtMonYr(boolean dtMonYr) {
			this.dtMonYr = dtMonYr;
	}
	
	public Date getScheduledDate() {
		return scheduledDate;
	}
	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
		
	    
	public String getPreClosureSchedule() {
		return preClosureSchedule;
	}
	public void setPreClosureSchedule(String preClosureSchedule) {
		this.preClosureSchedule = preClosureSchedule;
	}
	public String getPreClosureReferenceNo() {
		return preClosureReferenceNo;
	}
	public void setPreClosureReferenceNo(String preClosureReferenceNo) {
		this.preClosureReferenceNo = preClosureReferenceNo;
	}
	public String getPreClosureRemarks() {
		return preClosureRemarks;
	}
	public void setPreClosureRemarks(String preClosureRemarks) {
		this.preClosureRemarks = preClosureRemarks;
	}
	public String getPreClosureStatus() {
		return preClosureStatus;
	}
	public void setPreClosureStatus(String preClosureStatus) {
		this.preClosureStatus = preClosureStatus;
	}
	public String getCreditAccountNo() {
		return creditAccountNo;
	}
	public void setCreditAccountNo(String creditAccountNo) {
		this.creditAccountNo = creditAccountNo;
	}
	public String getClosedDate() {
		return closedDate;
	}
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}
	public Date getFdCreationDate() {
		return fdCreationDate;
	}
	public void setFdCreationDate(Date fdCreationDate) {
		this.fdCreationDate = fdCreationDate;
	}
	public String getCoreTxnTobeFired() {
		return coreTxnTobeFired;
	}
	public void setCoreTxnTobeFired(String coreTxnTobeFired) {
		this.coreTxnTobeFired = coreTxnTobeFired;
	}
	private Double tdrPayoutAmount;
	//Ended by sasi

	public Double getTdrPayoutAmount() {
		return tdrPayoutAmount;
	}
	public void setTdrPayoutAmount(Double tdrPayoutAmount) {
		this.tdrPayoutAmount = tdrPayoutAmount;
	}
	
	public String getAutoRenewType() {
		return autoRenewType;
	}
	public void setAutoRenewType(String autoRenewType) {
		this.autoRenewType = autoRenewType;
	}
	public String getAutoRenewDescription() {
		return autoRenewDescription;
	}
	public void setAutoRenewDescription(String autoRenewDescription) {
		this.autoRenewDescription = autoRenewDescription;
	}
	public String getAutoRenewReqd() {
		return autoRenewReqd;
	}
	public void setAutoRenewReqd(String autoRenewReqd) {
		this.autoRenewReqd = autoRenewReqd;
	}
	

	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public int getAutoRenewTenureInDays() {
		return autoRenewTenureInDays;
	}
	public void setAutoRenewTenureInDays(int autoRenewTenureInDays) {
		this.autoRenewTenureInDays = autoRenewTenureInDays;
	}
	public boolean isAutoRenewDtMonYr() {
		return autoRenewDtMonYr;
	}
	public void setAutoRenewDtMonYr(boolean autoRenewDtMonYr) {
		this.autoRenewDtMonYr = autoRenewDtMonYr;
	}
	public int getAutoRenewDays() {
		return autoRenewDays;
	}
	public void setAutoRenewDays(int autoRenewDays) {
		this.autoRenewDays = autoRenewDays;
	}
	public int getAutoRenewMonths() {
		return autoRenewMonths;
	}
	public void setAutoRenewMonths(int autoRenewMonths) {
		this.autoRenewMonths = autoRenewMonths;
	}
	public int getAutoRenewYears() {
		return autoRenewYears;
	}
	public void setAutoRenewYears(int autoRenewYears) {
		this.autoRenewYears = autoRenewYears;
	}
	public String getAutoRenewInterestPayout() {
		return autoRenewInterestPayout;
	}
	public void setAutoRenewInterestPayout(String autoRenewInterestPayout) {
		this.autoRenewInterestPayout = autoRenewInterestPayout;
	}
	public String getIsSeniorCitizen() {
		return isSeniorCitizen;
	}
	public void setIsSeniorCitizen(String isSeniorCitizen) {
		this.isSeniorCitizen = isSeniorCitizen;
	}				
	public String getAmountPayable() {
		return amountPayable;
	}
	public void setAmountPayable(String amountPayable) {
		this.amountPayable = amountPayable;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getPenalityAmount() {
		return penalityAmount;
	}
	public void setPenalityAmount(String penalityAmount) {
		this.penalityAmount = penalityAmount;
	}
	public String getChannelType() {
		return channelType;
	}
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}		
	private String isSbhDouble;

	public String getIsSbhDouble() {
		return isSbhDouble;
	}
	public void setIsSbhDouble(String isSbhDouble) {
		this.isSbhDouble = isSbhDouble;
	}
	public String getSelectedMaturityDate() {
		return selectedMaturityDate;
	}
	public void setSelectedMaturityDate(String selectedMaturityDate) {
		this.selectedMaturityDate = selectedMaturityDate;
	}
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public int getAuthOption() {
		return authOption;
	}
	public void setAuthOption(int authOption) {
		this.authOption = authOption;
	}
	public String getMaturityAmount() {
		return maturityAmount;
	}
	public void setMaturityAmount(String maturityAmount) {
		this.maturityAmount = maturityAmount;
	}
	public String getSegmentCode() {
		return segmentCode;
	}
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	public String getAuth1Name() {
		return auth1Name;
	}
	public void setAuth1Name(String auth1Name) {
		this.auth1Name = auth1Name;
	}
	public String getAuth2Name() {
		return auth2Name;
	}
	public void setAuth2Name(String auth2Name) {
		this.auth2Name = auth2Name;
	}
	public String getAuthStatus() {
		return authStatus;
	}
	public void setAuthStatus(String authStatus) {
		this.authStatus = authStatus;
	}
	public String getDebitHolderName() {
		return debitHolderName;
	}
	public void setDebitHolderName(String debitHolderName) {
		this.debitHolderName = debitHolderName;
	}
	public Integer getSmallFlag() {
		return smallFlag;
	}
	public void setSmallFlag(Integer smallFlag) {
		this.smallFlag = smallFlag;
	}
	public String getPreclosureReqRaisedBy() {
		return preclosureReqRaisedBy;
	}
	public void setPreclosureReqRaisedBy(String preclosureReqRaisedBy) {
		this.preclosureReqRaisedBy = preclosureReqRaisedBy;
	}
	public String getTypeOfModule() {
		return typeOfModule;
	}
	public void setTypeOfModule(String typeOfModule) {
		this.typeOfModule = typeOfModule;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

}
