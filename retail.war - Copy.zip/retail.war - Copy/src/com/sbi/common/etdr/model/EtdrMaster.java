/**
 * @(#) EchequeMaster.java
 */

package com.sbi.common.etdr.model;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.sbi.common.model.BaseModel;


public class EtdrMaster implements BaseModel

{
	protected Logger logger = Logger.getLogger(getClass());
	
	private String referenceNo;
	private String debitAccountNo;
	private String debitBranchCode;
	private String fdAccountNo;
	private Timestamp creationTime;
	private Double fdAmount;
	
	private String maker;
	private String currentAuthLevel;
	private String corporateId;
	private String authType;
	private String accountNickname;
	
	private String branchName;
	private String authOption;
	private String userName;
	private String status;
	private String auth1Name;

	private String auth2Name;
	private String scheduled;
	private Timestamp scheduledDate;
	private String debitStatus;
	private Double rateOfInterest;
	
	private String productType;
	private String productDesc;
	private String productCode;
	
	private String fdType;
	private String fdAccountNature;
	private Double maturityValue;
	private Timestamp maturityDate;
	private String maturityInstruction;
	private String fdRateType;
	
	private Timestamp tenureMaturityDate;
	private int tenureDay;
	private int tenureMonth;
	private int tenureYear;
	private int tenure;
	
	private boolean dtMonYr;
	private int autoRenewTenureInDays;
	private boolean autoRenewDtMonYr;
	private int autoRenewDays;
	private int autoRenewMonths;
	private int autoRenewYears;
	private String autoRenewInterestPayout;
	private String autoRenewDescription;
	private String autoRenewalTotalNoOfDays;
	private String autoRenewType;
	private String autoRenewTenureType;
	private String autoRenewTypeCode;
	private String interestPayout;
	private String tenureType;
	private String penaltyAmount;
	private String penaltyRateOfInterest;
	private String penaltyAmountPayable;
	private String preCloseReferenceNo;
	private String preCloseRemarks;
	private String preCloseReqRaisedBy;
	private String preCloseCurrentAuthLevel;
	
	private String TDRpayoutamount;
	public String getTDRpayoutamount() {
		return TDRpayoutamount;
	}

	public void setTDRpayoutamount(String TDRpayoutamount) {
		this.TDRpayoutamount = TDRpayoutamount;
	}

	private String debitHolderName;
	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getDebitAccountNo() {
		return debitAccountNo;
	}

	public void setDebitAccountNo(String debitAccountNo) {
		this.debitAccountNo = debitAccountNo;
	}

	public String getDebitBranchCode() {
		return debitBranchCode;
	}

	public void setDebitBranchCode(String debitBranchCode) {
		this.debitBranchCode = debitBranchCode;
	}

	public String getFdAccountNo() {
		return fdAccountNo;
	}

	public void setFdAccountNo(String fdAccountNo) {
		this.fdAccountNo = fdAccountNo;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public Double getFdAmount() {
		return fdAmount;
	}

	public void setFdAmount(Double fdAmount) {
		this.fdAmount = fdAmount;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getCurrentAuthLevel() {
		return currentAuthLevel;
	}

	public void setCurrentAuthLevel(String currentAuthLevel) {
		this.currentAuthLevel = currentAuthLevel;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getAccountNickname() {
		return accountNickname;
	}

	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getAuthOption() {
		return authOption;
	}

	public void setAuthOption(String authOption) {
		this.authOption = authOption;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAuth1Name() {
		return auth1Name;
	}

	public void setAuth1Name(String auth1Name) {
		this.auth1Name = auth1Name;
	}

	public String getAuth2Name() {
		return auth2Name;
	}

	public void setAuth2Name(String auth2Name) {
		this.auth2Name = auth2Name;
	}

	public String getScheduled() {
		return scheduled;
	}

	public void setScheduled(String scheduled) {
		this.scheduled = scheduled;
	}

	public Timestamp getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Timestamp scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getDebitStatus() {
		return debitStatus;
	}

	public void setDebitStatus(String debitStatus) {
		this.debitStatus = debitStatus;
	}

	public Double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(Double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	public String getFdType() {
		return fdType;
	}

	public void setFdType(String fdType) {
		this.fdType = fdType;
	}

	public String getFdAccountNature() {
		return fdAccountNature;
	}

	public void setFdAccountNature(String fdAccountNature) {
		this.fdAccountNature = fdAccountNature;
	}

	public String getMaturityInstruction() {
		return maturityInstruction;
	}

	public void setMaturityInstruction(String maturityInstruction) {
		this.maturityInstruction = maturityInstruction;
	}
	
	public String getFdRateType() {
		return fdRateType;
	}

	public void setFdRateType(String fdRateType) {
		this.fdRateType = fdRateType;
	}

	public boolean isDtMonYr() {
		return dtMonYr;
	}

	public void setDtMonYr(boolean dtMonYr) {
		this.dtMonYr = dtMonYr;
	}

	public int getAutoRenewTenureInDays() {
		return autoRenewTenureInDays;
	}

	public void setAutoRenewTenureInDays(int autoRenewTenureInDays) {
		this.autoRenewTenureInDays = autoRenewTenureInDays;
	}

	public boolean isAutoRenewDtMonYr() {
		return autoRenewDtMonYr;
	}

	public void setAutoRenewDtMonYr(boolean autoRenewDtMonYr) {
		this.autoRenewDtMonYr = autoRenewDtMonYr;
	}

	public int getAutoRenewDays() {
		return autoRenewDays;
	}

	public void setAutoRenewDays(int autoRenewDays) {
		this.autoRenewDays = autoRenewDays;
	}

	public int getAutoRenewMonths() {
		return autoRenewMonths;
	}

	public void setAutoRenewMonths(int autoRenewMonths) {
		this.autoRenewMonths = autoRenewMonths;
	}

	public int getAutoRenewYears() {
		return autoRenewYears;
	}

	public void setAutoRenewYears(int autoRenewYears) {
		this.autoRenewYears = autoRenewYears;
	}

	public String getAutoRenewInterestPayout() {
		return autoRenewInterestPayout;
	}

	public void setAutoRenewInterestPayout(String autoRenewInterestPayout) {
		this.autoRenewInterestPayout = autoRenewInterestPayout;
	}

	public String getAutoRenewDescription() {
		return autoRenewDescription;
	}

	public void setAutoRenewDescription(String autoRenewDescription) {
		this.autoRenewDescription = autoRenewDescription;
	}
	
	public String getAutoRenewalTotalNoOfDays() {
		return autoRenewalTotalNoOfDays;
	}

	public void setAutoRenewalTotalNoOfDays(String autoRenewalTotalNoOfDays) {
		this.autoRenewalTotalNoOfDays = autoRenewalTotalNoOfDays;
	}
	
	public Double getMaturityValue() {
		return maturityValue;
	}

	public void setMaturityValue(Double maturityValue) {
		this.maturityValue = maturityValue;
	}

	public Timestamp getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Timestamp maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Timestamp getTenureMaturityDate() {
		return tenureMaturityDate;
	}

	public void setTenureMaturityDate(Timestamp tenureMaturityDate) {
		this.tenureMaturityDate = tenureMaturityDate;
	}

	public int getTenureDay() {
		return tenureDay;
	}

	public void setTenureDay(int tenureDay) {
		this.tenureDay = tenureDay;
	}

	public int getTenureMonth() {
		return tenureMonth;
	}

	public void setTenureMonth(int tenureMonth) {
		this.tenureMonth = tenureMonth;
	}

	public int getTenureYear() {
		return tenureYear;
	}

	public void setTenureYear(int tenureYear) {
		this.tenureYear = tenureYear;
	}
	
	
	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public String getTenureType() {
		return tenureType;
	}

	public void setTenureType(String tenureType) {
		this.tenureType = tenureType;
	}
	
	public String getAutoRenewType() {
		return autoRenewType;
	}

	public void setAutoRenewType(String autoRenewType) {
		this.autoRenewType = autoRenewType;
	}

	public String getAutoRenewTenureType() {
		return autoRenewTenureType;
	}

	public void setAutoRenewTenureType(String autoRenewTenureType) {
		this.autoRenewTenureType = autoRenewTenureType;
	}

	public String getAutoRenewTypeCode() {
		return autoRenewTypeCode;
	}

	public void setAutoRenewTypeCode(String autoRenewTypeCode) {
		this.autoRenewTypeCode = autoRenewTypeCode;
	}

	
	public String getInterestPayout() {
		return interestPayout;
	}

	public void setInterestPayout(String interestPayout) {
		this.interestPayout = interestPayout;
	}

	public String getPreCloseReferenceNo() {
		return preCloseReferenceNo;
	}

	public void setPreCloseReferenceNo(String preCloseReferenceNo) {
		this.preCloseReferenceNo = preCloseReferenceNo;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setDebitHolderName(String debitHolderName) {
		this.debitHolderName = debitHolderName;
	}

	public String getDebitHolderName() {
		return debitHolderName;
	}

	public String getPenaltyAmount() {
		return penaltyAmount;
	}

	public void setPenaltyAmount(String penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}

	public String getPenaltyRateOfInterest() {
		return penaltyRateOfInterest;
	}

	public void setPenaltyRateOfInterest(String penaltyRateOfInterest) {
		this.penaltyRateOfInterest = penaltyRateOfInterest;
	}

	public String getPenaltyAmountPayable() {
		return penaltyAmountPayable;
	}

	public void setPenaltyAmountPayable(String penaltyAmountPayable) {
		this.penaltyAmountPayable = penaltyAmountPayable;
	}

	public String getPreCloseRemarks() {
		return preCloseRemarks;
	}

	public void setPreCloseRemarks(String preCloseRemarks) {
		this.preCloseRemarks = preCloseRemarks;
	}
	
	public String getPreCloseReqRaisedBy() {
		return preCloseReqRaisedBy;
	}

	public void setPreCloseReqRaisedBy(String preCloseReqRaisedBy) {
		this.preCloseReqRaisedBy = preCloseReqRaisedBy;
	}

	public String getPreCloseCurrentAuthLevel() {
		return preCloseCurrentAuthLevel;
	}

	public void setPreCloseCurrentAuthLevel(String preCloseCurrentAuthLevel) {
		this.preCloseCurrentAuthLevel = preCloseCurrentAuthLevel;
	}

	public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        
        tempStringBuf.append(referenceNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(debitAccountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(debitBranchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(creationTime);
        tempStringBuf.append(" | ");
        tempStringBuf.append(fdAmount);
        tempStringBuf.append(" | ");
        
        
        tempStringBuf.append(maker);
        tempStringBuf.append(" | ");
        tempStringBuf.append(currentAuthLevel);
        tempStringBuf.append(" | ");
        tempStringBuf.append(corporateId);
        tempStringBuf.append(" | ");
        tempStringBuf.append(authType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountNickname);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append(branchName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(authOption);
        tempStringBuf.append(" | ");
        tempStringBuf.append(userName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        tempStringBuf.append(auth1Name);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append(auth2Name);
        tempStringBuf.append(" | ");
        tempStringBuf.append(scheduled);
        tempStringBuf.append(" | ");
        tempStringBuf.append(scheduledDate);
        tempStringBuf.append(" | ");
        tempStringBuf.append(debitStatus);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productType);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append(rateOfInterest);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productDesc);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productCode);
        tempStringBuf.append(" | ");
        
        
        tempStringBuf.append(fdType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(fdAccountNature);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maturityValue);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maturityDate);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maturityInstruction);
        tempStringBuf.append(" | ");
        tempStringBuf.append(fdRateType);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append(tenureMaturityDate);
        tempStringBuf.append(" | ");
        tempStringBuf.append(tenureDay);
        tempStringBuf.append(" | ");
        tempStringBuf.append(tenureMonth);
        tempStringBuf.append(" | ");
        tempStringBuf.append(tenureYear);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append(dtMonYr);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewTenureInDays);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewDtMonYr);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewDays);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewMonths);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewYears);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewInterestPayout);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewDescription);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewalTotalNoOfDays);
        tempStringBuf.append(" | ");
        tempStringBuf.append(tenureType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewTenureType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(autoRenewTypeCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(interestPayout);
        tempStringBuf.append(" | ");
        tempStringBuf.append(tenure);
        tempStringBuf.append(" | ");
        tempStringBuf.append(fdAccountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(preCloseReferenceNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(debitHolderName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(penaltyAmount);
        tempStringBuf.append(" | ");
        tempStringBuf.append(penaltyRateOfInterest);
        tempStringBuf.append(" | ");
        tempStringBuf.append(penaltyAmountPayable);
        tempStringBuf.append(" | ");
        tempStringBuf.append(preCloseRemarks);
        tempStringBuf.append(" | ");
        tempStringBuf.append(preCloseReqRaisedBy);
        tempStringBuf.append(" | ");
        tempStringBuf.append(preCloseCurrentAuthLevel);
        
        return tempStringBuf.toString();
    }
	
}
