package com.sbi.common.etdr.model;

import java.io.Serializable;

/***
 * This Model is designed specifically for the table based product code logic architecture
 * @author SG68373  
 */


public class FDProductCodeModel implements Serializable {
	private static final long serialVersionUID = 1L;	

	private String debitProductCode;
	private String debit_prod_type12;
	private String debit_prod_type34;
	private String debit_subcat5;
	private String debit_subcat67;
	private String debit_subcat8;
	private String product_desc;
	private String customer_type;
	private String customer_category;
	private String segmentCode;
	private String bankCode;

	
	

	public String getDebitProductCode() {
		return debitProductCode;
	}
	public void setDebitProductCode(String debitProductCode) {
		this.debitProductCode = debitProductCode;
	}
	public String getDebit_prod_type12() {
		return debit_prod_type12;
	}
	public void setDebit_prod_type12(String debit_prod_type12) {
		this.debit_prod_type12 = debit_prod_type12;
	}
	public String getDebit_prod_type34() {
		return debit_prod_type34;
	}
	public void setDebit_prod_type34(String debit_prod_type34) {
		this.debit_prod_type34 = debit_prod_type34;
	}
	public String getDebit_subcat5() {
		return debit_subcat5;
	}
	public void setDebit_subcat5(String debit_subcat5) {
		this.debit_subcat5 = debit_subcat5;
	}
	public String getDebit_subcat67() {
		return debit_subcat67;
	}
	public void setDebit_subcat67(String debit_subcat67) {
		this.debit_subcat67 = debit_subcat67;
	}
	public String getDebit_subcat8() {
		return debit_subcat8;
	}
	public void setDebit_subcat8(String debit_subcat8) {
		this.debit_subcat8 = debit_subcat8;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public String getCustomer_type() {
		return customer_type;
	}
	public void setCustomer_type(String customer_type) {
		this.customer_type = customer_type;
	}
	public String getCustomer_category() {
		return customer_category;
	}
	public void setCustomer_category(String customer_category) {
		this.customer_category = customer_category;
	}
	public String getSegmentCode() {
		return segmentCode;
	}
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


}
