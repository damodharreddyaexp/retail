

/*   
 * CorpTransactionValidator.java
 * Created on sep 20, 2006
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//sep 20, 2006 Aparna S - Initial Creation  and implementation.

package com.sbi.common.etdr.utils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionLeg;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.UtilsConstant;

import com.sbi.common.dao.CorporateProfileDAO;
import com.sbi.common.etdr.dao.EtdrMasterDAO;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.etdr.dao.EtdrRuleMasterDAO;

import com.sbi.common.model.CorporateProfile;
import java.util.StringTokenizer;

/**
 * TODO This  class does the validations for the input transaction
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class EtdrCorpTransactionValidator {

	protected final Logger logger = Logger.getLogger(getClass());
	private CorporateProfileDAO corpProfDaoImpl;
	private EtdrRuleMasterDAO etdrRuleMasterDAOImpl;
	private EtdrMasterDAO etdrMasterDAOImpl;
	private AccountDAO accountDAOImpl;
	private String merchantCode;
	private double commissionAmount;
	
    private ReferenceDataCache referenceDataCache;


	/**
	 * TODO 1.Gets the accountNo,branchCode,debitAmount and corporateID
	 * 2.Calls [CorporateProfileDAOImpl.findCorporateProfileDetails(corporateID)]
	 * 3.Returns errorMessage based on the conditions
	 * @param accountNo
	 * @param branchCode
	 * @param debitAmount
	 * @param corporateID
	 * @return String
	 */
	public String validateAccountAudited(String accountNo,String branchCode,Double debitAmount,String corporateID){
		
		logger.info(" validateAccountAudited(String corporateID) method begin");
		logger.info(" accountNo :" +accountNo);
		logger.info(" branchCode :"+branchCode);
		logger.info(" debitAmount :"+debitAmount);
		logger.info(" corporateID :"+corporateID);
		//boolean flag=false;
		int echequeCount = 0;
		Double profileMaxUnauditedAmount = null;
		Integer profileUnauditedCount = null;
		String errorMessage = null;
		if(accountNo==null || branchCode == null || debitAmount==null|| corporateID==null){
			
			SBIApplicationException.throwException("CUV003",new Object[]{});
		}
		try{
			 
			CorporateProfile corporateProfile = (CorporateProfile)corpProfDaoImpl.findCorporateProfileDetails(corporateID);
			if(corporateProfile.getAuditUser().intValue()==1){
				return errorMessage;
			} else if(corporateProfile.getAuditUser().intValue()==0){
				
                profileMaxUnauditedAmount = (Double)corporateProfile.getMaxUnauditedAmount();
				profileUnauditedCount = (Integer)corporateProfile.getUnauditedCount();
				
                Double[] adminUnauditCount = (Double[])etdrRuleMasterDAOImpl.getAdminUnauditCount(accountNo,branchCode);
					
				Double tempAmount = profileMaxUnauditedAmount;
				int tempUnauditCount=profileUnauditedCount.intValue();				
				if(adminUnauditCount==null){
					logger.info("adminUnauditCount is null");
					 if(debitAmount.doubleValue() <= tempAmount.doubleValue())
					 {
						 logger.info("debitAmount is less than profileMaxUnauditedAmount");
						 return errorMessage;
					 }
	                	}								
				else if(adminUnauditCount[1].doubleValue() <= profileMaxUnauditedAmount.doubleValue()){
				 	tempAmount = adminUnauditCount[1];
				 	logger.info("least unaudit amount :"+tempAmount);
				 	if(adminUnauditCount[0].intValue() < profileUnauditedCount.intValue())
				 		tempUnauditCount= adminUnauditCount[0].intValue();
				 		logger.info("least Unaudit Count :"+tempUnauditCount);
				}

				if(debitAmount.doubleValue() > tempAmount.doubleValue()){
					//SR-97333 Included the corporate_id
					  echequeCount = (int)etdrMasterDAOImpl.getUnauditCount(accountNo,branchCode,tempAmount,corporateID);
					  logger.info("echequeCount based on least unaudit amount:"+echequeCount);
						//unaudit count validation for account
					  logger.info("temp amount:"+tempAmount.doubleValue());
				
					  if(profileUnauditedCount !=null && echequeCount>=tempUnauditCount){
					
							/*errorMessage = "This transaction cannot be processed, as the number of unaudited transactions on this account of value greater than "+tempAmount+" exceeds "+profileUnauditedCount.intValue()+".\nSolution: Contact your corporate auditer"
					 +" to authorize a few e-PayOrders immediately. Transactions may be put on hold, if there are any eCheques for this account. Contact your administrator to authorize or cancel these ePayOrders, through the appropriate " 
									+"personnel.Alternately, if this transaction must be processed on priority you may also request your administrator to temporarily relax the audit settings on this account.";*/

							errorMessage = "This transaction cannot be processed, as the number of unaudited transactions on this account of value greater than "+tempAmount+" exceeds "+profileUnauditedCount.intValue()+".\n "
							+" Solution: Contact your corporate auditor to audit and approve a few e-PayOrders immediately. "
							+" Alternately, if this transaction is on high priority you may also request your administrator/regulator to temporarily relax the audit settings on this account. "
							+" Please note that the count displayed above includes both authorized and unauthorized transactions, and transactions in unknown status(pending for processing). ";				
					
				}
			}
				
			}
			
		
		}catch(DAOException daoException){
			logger.info("validateAccountAudited :: "+daoException.getMessage());
		SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
		logger.info(" validateAccountAudited(String corporateID) method ends");
		return errorMessage;	
	}

	
	/**
	 * TODO 1.Gets the accountNo,branchCode,debitAmount and corporateID
	 * 2.Calls [RuleMasterDAOImpl.findBranchLimit(accountNo,branchCode,amount,corporateID)]
	 * 3.Based on the conditions satisfied,returns true or false.
	 * @param accountNo
	 * @param branchCode
	 * @param amount
	 * @param corporateID
	 * @return boolean
	 */
	public boolean validateAuthorize(String accountNo,String branchCode,Double amount,Integer corporateID){
		
		logger.info("validateAuthorize(String accountNo,String branchCode,Double amount,Integer corporateID)method begin");
		logger.info("accountNo****" + accountNo + "," + "branchCode" + branchCode + "," + "amount" + amount + "," + "corporateID"+corporateID);
		boolean flag=false;
		try{
		
			Double branchLimit = etdrRuleMasterDAOImpl.findBranchLimit(accountNo,branchCode,amount,corporateID);
			if (logger.isDebugEnabled()) {
				logger.debug("branchLimit: "+branchLimit);
			}
			
			if(branchLimit!=null){
				flag = true;
	        }
            else
            {
            	flag=false;
                //SBIApplicationException.throwException("CUV0001"); //No authorizers for this account for a debit amount.
            }
		}catch(DAOException daoException){
			
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
	
		logger.info("validateAuthorize(String accountNo,String branchCode,Double amount,Integer corporateID)method ends");
		return flag;
	}
	
	
	/**
	 * TODO 1.Gets the accountNo,branchCode and debitAmount  
	 * 2.Calls [RuleMasterDAOImpl.findCorpAdminTransferLimit(accountNo,branchCode)]
	 * 3.Based on the conditions satisfied,returns true or false.
	 * @param debitAmount
	 * @param accountNo
	 * @param branchCode
	 * @return boolean
	 */
	public boolean validateCALimit(Double debitAmount,String accountNo,String branchCode){
		logger.info("validateCALimit(Double debitAmount)method begin");
		logger.info("debitAmount" + debitAmount + "," + "accountNo" + accountNo + "," + "branchCode" + branchCode);
		boolean flag = false;
		Double limit=null;
		try{
			
			limit =(Double) etdrRuleMasterDAOImpl.findCorpAdminTransferLimit(accountNo,branchCode);
			if (logger.isDebugEnabled()) {
				logger.debug("limit: "+limit);
			}
			if(limit!=null){
				if(limit.doubleValue()==-1){
				
					logger.info("user doesnt have restriction to transfer fund");
					flag=true;
				}else if(limit.doubleValue()== 0 || debitAmount.doubleValue()>limit.doubleValue()){
				
					flag = false;
					SBIApplicationException.throwException("CU0035",new Object[]{debitAmount,accountNo,branchCode});
				}
			}else{
				
				limit = new Double("-1");
			}
		}catch(DAOException daoException){
			
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
		logger.info("validateCALimit(Double debitAmount)method End");
		return flag;
	}
	
	/**
	 * TODO 1.Gets the amount,fundsTransferType and corpID
	 * 2.Calls [CorporateProfileDAOImpl.findCorporateProfileDetails(corpID)]
	 * 3.checks if the amount is less than CorporateDDLimit,CorporateTPLimit for the transaction types CD and CT respectively
	 * 4.Returns true or false based on the condition
	 * @param amount
	 * @param fundsTransferType
	 * @param corpID
	 * @return boolean
	 */
	public boolean validateCorporateLimit(Double amount,String fundsTransferType,String corpID){
		logger.info("validateCorporateLimit(String amount,String fundsTransferType,String corpID)method begin");
		if (logger.isDebugEnabled()) {
			logger.debug("amount" + amount +","+ "fundsTransferType" + fundsTransferType+","+"corpID"+corpID);
		}
		
		boolean flag=false;
		try{
			CorporateProfile corporateProfile = (CorporateProfile)corpProfDaoImpl.findCorporateProfileDetails(corpID);
			
			if(fundsTransferType.equalsIgnoreCase("CD")){
				if (logger.isDebugEnabled()) {
					logger.debug("corporateProfile.getCorporateDDLimit(): "+corporateProfile.getCorporateDDLimit());
				}
				if(corporateProfile.getCorporateTPLimit().doubleValue()==0 ){
					
					flag = false;
					SBIApplicationException.throwException("CU0055",new Object[]{corporateProfile.getCorporateTPLimit().doubleValue()});
					
				}else 				
				if( corporateProfile.getCorporateDDLimit().doubleValue()==-1){
					return true;
				}else{
					if(!(amount.doubleValue()>corporateProfile.getCorporateDDLimit().doubleValue())){
			   
					flag=true;
				}else{
			   
					flag = false;
					SBIApplicationException.throwException("CU0036",new Object[]{amount});
			   
				}
				}
			}else if(fundsTransferType.equalsIgnoreCase("CT")|| fundsTransferType.equalsIgnoreCase(UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME)||
					fundsTransferType.equalsIgnoreCase(UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME) || fundsTransferType.equalsIgnoreCase(UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME) ||fundsTransferType.equalsIgnoreCase("CK")||fundsTransferType.equalsIgnoreCase("CH")){//Added for GRPT
				
				if (logger.isDebugEnabled()) {
					logger.debug("corporateProfile.getCorporateTPLimit(): "+corporateProfile.getCorporateTPLimit());
				}
				
				if(fundsTransferType.equalsIgnoreCase("CK"))
				{
					logger.info("inside vistar validation");
					if(!(amount.doubleValue()>corporateProfile.getCorporateGovtLimit().doubleValue())){
					
						flag=true;
					}else{
						flag=false;
						SBIApplicationException.throwException("CU0054",new Object[]{amount});
					}
				}
				else 
				{
					
					if(corporateProfile.getCorporateTPLimit().doubleValue()==0 ){
						
						flag = false;
						SBIApplicationException.throwException("CU0037",new Object[]{corporateProfile.getCorporateTPLimit().doubleValue()});
						
					}
					else if( corporateProfile.getCorporateTPLimit().doubleValue()==-1){
							
							return true;
					}
					else{
						if(!(amount.doubleValue()>corporateProfile.getCorporateTPLimit().doubleValue())){

							flag=true;  

						}else{

							flag = false;
							if (fundsTransferType.equalsIgnoreCase(UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME)|| fundsTransferType.equalsIgnoreCase(UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME) 
									|| fundsTransferType.equalsIgnoreCase(UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME))//Added for GRPT
								SBIApplicationException.throwException("RTGS045",new Object[]{amount});
							else
								SBIApplicationException.throwException("CU0037",new Object[]{amount});
						}
					}
				}
			}else if(fundsTransferType.equalsIgnoreCase("CI")||fundsTransferType.equalsIgnoreCase("CS")){
				
				flag = true;
				
			}else{
				
				SBIApplicationException.throwException("CU0051",new Object[]{});//if any other transaction type,gives invalid funds transfer for other types.
			}
		}catch(DAOException daoException){
			
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}
		logger.info("validateCorporateLimit(String amount,String fundsTransferType,String corpID)method End");
		return flag;
	}
	
	
	/**
	 * TODO 1.Gets the corpTransaction object.
	 * 2.Checks if the sum of credit amount is equal to debit amount.
	 * 3.If the condition is satisfied returns true
	 * @param corpTransaction
	 * @return boolean
	 */
	
	public boolean validateAmountCheck(Transaction corpTransaction) {
		logger.info("validateAmount(CorpTransaction corpTransaction) method begin");
		boolean flag = false;
		
			
			TransactionLeg debit = (TransactionLeg)corpTransaction.getDebit();
			TransactionLeg[] credit = (TransactionLeg[])corpTransaction.getCredit();
			double creditSum=0;
			double debitAmount = debit.getAmount().doubleValue();
			logger.info("debit Amount : "+debitAmount);
			logger.info("credit size : "+credit.length);
			for(int i=0;i<credit.length;i++){
				logger.info("credit leg ("+i+") amount: "+credit[i].getAmount());
				creditSum=creditSum+credit[i].getAmount().doubleValue();
			}
			if (logger.isDebugEnabled()) {
				logger.debug("credit sum"+creditSum);
			}
			logger.info("creditSum Amount : "+creditSum);
            
			if(creditSum!=0 && debitAmount!=0 && (debitAmount==creditSum)){
                flag = true;                 
			}else{
				flag = false;
				SBIApplicationException.throwException("CUV005",new Object[]{"debitAmount","creditSum"});
			}
			
		
		logger.info("validateAmount(CorpTransaction corpTransaction) method ends");
		return flag;
	}
	
	public boolean isAuthorizingTime() {
		boolean validDayTime=false;
		Timestamp today = StringUtils.currentTimeStamp();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("E/MM/yyyy/HH/mm");
		String strTxnDate = simpleDateFormat.format(today);
		String[] dateArray = strTxnDate.split("/");
		String strDay =dateArray[0];
		int intHour =Integer.parseInt(dateArray[3]);
		int intMinute =Integer.parseInt(dateArray[4]);
		logger.info("Day : "+ strDay);
		logger.info(" hour : "+ intHour);
		logger.info(" minute : "+ intMinute);

		if(strDay.equalsIgnoreCase("Sat"))
			validDayTime=false;
		else if(strDay.equalsIgnoreCase("Fri"))
		{
			if(intHour<10)
				validDayTime=true;
			else
			{
				if(intHour==11 && intMinute<30)
					validDayTime=true;
				else
					validDayTime=false;
			}
			
		}
		else
		{
			
			if(intHour<14 && intMinute <=59)
				validDayTime=true;
			else
				validDayTime=false;	
		}
		
		logger.info("Day : "+strDay+ " hour : "+intHour+ " minute : "+intMinute); 
		logger.info("isAuthorizingTime returns : "+validDayTime);
		return validDayTime;
	}
	
	/**
	 * @param echequeNo
	 * @param corpRefNo
	 * @return
	 */
	public boolean validateBillAuthorize(String echequeNo, String corpRefNo)
	{ 
		logger.info("validateBillAuthorize(String echequeNo) method begin ");
		logger.info("echequeNo === " + echequeNo);
		logger.info("corpRefNo === " + corpRefNo);
		boolean flag=true;
		Date date = new Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Timestamp sysDate = new Timestamp(sqlDate.getTime());
		StringTokenizer st = new StringTokenizer(corpRefNo,"|");
		String billNo = st.nextToken();
		try
		{
			Timestamp billDate = (Timestamp) etdrRuleMasterDAOImpl.getBillDate(billNo);
			if(billDate.before(sysDate))
			{
					flag = false;
			}			
			
		}
		catch(DAOException daoException)
		{			
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}		
		return flag;
	}
	

	public boolean validateBulkBillAuthorize(String echequeNo)
	{ 
		logger.info("validateBulkBillAuthorize(String echequeNo) method begins ");
		logger.info("echequeNo === " + echequeNo);
		boolean flag=true;
		Date date = new Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Timestamp sysDate = new Timestamp(sqlDate.getTime());	
		
		try
		{
			Timestamp payByDate = (Timestamp) etdrMasterDAOImpl.getPayByDate(echequeNo);
			if(payByDate.before(sysDate))
			{
					flag = false;
			}			
			
		}
		catch(DAOException daoException)
		{			
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}		
		logger.info("validateBulkBillAuthorize(String echequeNo) method ends ");
		return flag;
	}
	
	//added on 16-10-06 by Aparna for validations.
	
	/*DATE VALIDATION BEGIN*/
	/**
	 * TODO 1.Gets the days
	 * 2.Calculates 15 days in future from the system date
	 * 3.returns timestamp
	 * @param days
	 * @return Timestamp
	 */
	public static Timestamp futureDate(String days) {
		int count = (new Integer(days)).intValue();
		Calendar currDate = Calendar.getInstance();
		currDate.add(Calendar.DATE, (+count)); //go 15 days in future

		Date date = currDate.getTime();
		Date sqlToday = new java.sql.Date(date.getTime());
		Timestamp timestamp = new Timestamp(sqlToday.getTime());
		return timestamp;

	}
	
	
	/**
	 * TODO 1.Gets the scheduledDate
	 * 2.Checks if the scheduledDate is after the system date and equal to or before the future date
	 * 3.Returns true or false based on the condition.
	 * @param scheduledDate
	 * @return boolean
	 */
	public boolean validateScheduledDate(Timestamp scheduledDate,String duration)
	{ 
		logger.info("validateScheduledDate(Timestamp scheduledDate,String duration) method begin ");
		boolean flag=false;
		Date date = new Date();
		java.sql.Date sqlDate = new java.sql.Date(date.getTime());
		Timestamp sysDate = new Timestamp(sqlDate.getTime());
		Timestamp futureTime = (Timestamp)futureDate(duration);
		if (logger.isDebugEnabled()) {
			logger.debug("future date :" + futureTime);
		}
		if(scheduledDate!=null){
			if(scheduledDate.after(sysDate) && (scheduledDate.before(futureTime) || scheduledDate.equals(futureTime))){
				flag=true;
			
			}else{
				
				flag=false;
				SBIApplicationException.throwException("CUV004",new Object[]{scheduledDate});
				
			}	
		}else{
			
			SBIApplicationException.throwException("CUV006",new Object[]{scheduledDate});
		}
			
		
		return flag;
	}
	
	
	
	
	/*DATE VALIDATION END*/
	
	/*public boolean validateAcctLimit(String CreditAcctNo, String branchCode, String userName,Double amount){
    	logger.info("validateAcctLimit(String CreditAcctNo, String branchCode, String userName,Double amount) "+ LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled()) {
			logger.debug("CreditAcctNo :" + CreditAcctNo);
			logger.debug("branchCode :" + branchCode);
			logger.debug("userName :" + userName);
			logger.debug("amount :" + amount.doubleValue());
		}
		
		if(CreditAcctNo != null && CreditAcctNo.trim().length()>0 && userName != null && userName.trim().length() >0
				&& amount != null){
			Account account = (Account)accountDAOImpl.findAccountByNature(userName,CreditAcctNo,branchCode, new Integer(1));
			if(account != null){
				
				if( amount.doubleValue() <= account.getBalance().doubleValue()){
					return true;
				}else{
					SBIApplicationException.throwException("HACK001",new Object[]{});
				}
				
			}else{
				SBIApplicationException.throwException("CU0052",new Object[]{});
			}
			
			
		}
		
		logger.info("validateAcctLimit(String CreditAcctNo, String branchCode, String userName,Double amount) "+ LoggingConstants.METHODEND);
		return true;
    }*/
	
	/**
	 * TODO 1.Gets debitAmount and debitLimit.
	 * 2.Checks if debitAmount less than debitLimit
	 * 3.Based on the condition returns true or false.
	 * @param debitAmount
	 * @param debitLimit
	 * @return boolean
	 */
	public boolean validateAcctLimit(Double debitAmount,double debitLimit){
    	logger.info("validateAcctLimit(Double amount,Double limit) "+ LoggingConstants.METHODBEGIN);
		boolean flag=false;
    	if (logger.isDebugEnabled()) {
			
			logger.debug("amount :" + debitAmount.doubleValue());
			logger.debug("limit :" + debitLimit);
		}
		
		if( debitAmount != null ){
			if(debitLimit!=-1 && new Double(debitLimit)!=null){
			
				
				if( debitAmount.doubleValue() <= debitLimit){
					flag = true;
				}else{
					flag = false;
					if (merchantCode!=null && (merchantCode.equalsIgnoreCase(UtilsConstant.RTGS)|| merchantCode.equalsIgnoreCase(UtilsConstant.NEFT) || merchantCode.equalsIgnoreCase(UtilsConstant.GRPT) )){
						if ((debitAmount.doubleValue()-commissionAmount)>debitLimit) {
							SBIApplicationException.throwException("CUV0010",new Object[]{debitAmount,"debitLimit"});
						}else //if the total amount inclusive of commission is greater than the debit Limit
							SBIApplicationException.throwException("RTGS044",new Object[]{debitAmount,new Double(commissionAmount),new Double(debitLimit)}); 
					}else
						SBIApplicationException.throwException("CUV0010",new Object[]{debitAmount,"debitLimit"});
				}
			}
					
			
		}
		
		logger.info("validateAcctLimit(Double amount,Double limit) "+ LoggingConstants.METHODEND);
		return flag;
    }
	
	
	public void setCorpProfDaoImpl(CorporateProfileDAO corpProfDaoImpl) {
		this.corpProfDaoImpl = corpProfDaoImpl;
	}


	public void setEtdrRuleMasterDAOImpl(EtdrRuleMasterDAO etdrRuleMasterDAOImpl) {
		this.etdrRuleMasterDAOImpl = etdrRuleMasterDAOImpl;
	}


	public void setEtdrMasterDAOImpl(EtdrMasterDAO etdrMasterDAOImpl) {
		this.etdrMasterDAOImpl = etdrMasterDAOImpl;
	}


	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}


	public void setCommissionAmount(double commissionAmount) {
		this.commissionAmount = commissionAmount;
	}
	//RTGS Min debit limit validation
    /**   
     * Get the corresponding Transaction Limit from cache And check whether
     * limit is greater than the transaction limit amount. If it so throw
     * Exception with "ERROR_CODE" else return true
     * 
     * @param amount
     * @param type
     * @return boolean 
     */

    public boolean isValidRTGSMinLimit(Double amount) {

        logger.info("isValidRTGSMinLimit(Double amount) "
                + LoggingConstants.METHODBEGIN);

        if (amount != null) {
            logger.info("amount :" + amount.doubleValue());
            if (logger.isDebugEnabled()) {
                logger.debug("amount :" + amount.doubleValue());
            }

            Map data = referenceDataCache
                    .getReferenceData(UtilsConstant.TRANSACTION_LIMIT);
            if (logger.isDebugEnabled()) {
                logger.debug("data :" + data);
            }


            String limit = (String) data.get(com.sbi.common.utils.UtilsConstant.CORP_RTGS_MIN_TRANSACTION_LIMIT);
            double limitAmount = Double.parseDouble(limit);

            logger.info("limitAmount :" + limitAmount);
            if (amount.doubleValue() < limitAmount) {
                Object[] objects={amount};
                SBIApplicationException
                        .throwException(ErrorConstants.AMOUNT_LIMIT_EXCEEDS_RTGS_LIMIT_ERROR_CODE,objects);
            }
        } else {
            SBIApplicationException
                    .throwException(ErrorConstants.BLANK_MADATORY_FIELDS); 
        }

        logger.info("isValidRTGSMinLimit(Double amount)"+LoggingConstants.METHODEND);
        return true;
    }
//  RTGS credit account validation
    /**   
     * Get the corresponding Transaction Limit from cache And check whether
     * limit is greater than the transaction limit amount. If it so throw
     * Exception with "ERROR_CODE" else return true
     * 
     * @param amount
     * @param type
     * @return boolean 
     */

    public boolean isValidRTGSCreditAccountNumber(Transaction corpTransaction) {

        logger.info("isValidRTGSCreditAccountNumber(Transaction corpTransaction) "
                + LoggingConstants.METHODBEGIN);

        CorpTransactionLeg  creditCorpTransactionLeg =  (CorpTransactionLeg)corpTransaction.getCredit()[0];
        String creditActNo=creditCorpTransactionLeg.getNarrative1();
        String username=creditCorpTransactionLeg.getUserName();
        String actNickName=creditCorpTransactionLeg.getNarrative3();
        //String ifscCode=creditCorpTransactionLeg.getNarrative2().split("|");
        StringTokenizer tokens=new StringTokenizer(creditCorpTransactionLeg.getNarrative2(),"|");
        tokens.nextToken();
        String ifscCode=tokens.nextToken();
        logger.info("ifsc code"+ifscCode);
        String corpid=creditCorpTransactionLeg.getCorporateId();
        boolean isValidRTGSCreditAccountNumber=false;
        logger.info("creditActNo : "+creditActNo+"\tusername : "+username+"\tactNickName : "+actNickName+"\tifscCode : "+ifscCode+"\tcorpid : "+corpid);
        if(username != null && creditActNo != null && ifscCode != null && corpid != null){
            isValidRTGSCreditAccountNumber=accountDAOImpl.isValidRTGSCreditActNumber(username,corpid,creditActNo,ifscCode,actNickName);
        }else {
            SBIApplicationException
            .throwException(ErrorConstants.BLANK_MADATORY_FIELDS);
        }
        logger.info("isValidRTGSCreditAccountNumber : "+isValidRTGSCreditAccountNumber);
        
        if(!isValidRTGSCreditAccountNumber){
            SBIApplicationException.throwException(ErrorConstants.INVALID_ACCOUNT_NUMBER);           
        }

        logger.info("isValidRTGSCreditAccountNumber(Transaction corpTransaction)"+LoggingConstants.METHODEND);
        return isValidRTGSCreditAccountNumber;
    }
    
    /**
     * CR-5655 Ramanan M - BEGIN - NRE check through Product Code
	 * Get the corresponding NRE_PRODUCT_CODES from cache And check whether the
	 * map contains the product code. If it contains the product code return
	 * True else return False
	 * 
	 * @param productCode
	 * @return boolean
	 */
	public boolean isNREProductCode(String productCode){
    	logger.info("validateNREProductCode(String productCode) "+ LoggingConstants.METHODBEGIN);
		boolean flag = false;
    	if (logger.isDebugEnabled()) {
			logger.debug("Product Code :" + productCode);
		}
		
		if( productCode != null ){
			Map data = referenceDataCache
					.getReferenceData(UtilsConstant.NRE_PRODUCT_CODES);
			if (logger.isDebugEnabled()) {
				logger.debug("data :" + data);
			}
			if(data != null)
			flag = data.containsKey(productCode);
		} else {
            SBIApplicationException
            .throwException(ErrorConstants.BLANK_MADATORY_FIELDS); 
		}
		
		logger.info("validateAcctLimit(Double amount,Double limit) "+ LoggingConstants.METHODEND);
		return flag;
    }


    /**
     * @param referenceDataCache The referenceDataCache to set.
     */
    public void setReferenceDataCache(ReferenceDataCache referenceDataCache)
    {
        this.referenceDataCache = referenceDataCache;
    }
	
   
}
