/*   
 * CorpFundTransferRequestMapper.java
 * Created on Oct 20, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 9, 2006 Aparna S - Initial Creation  and implementation.

package com.sbi.common.etdr.utils;


import java.sql.Timestamp;
import java.util.Map;

import java.util.List;

import com.sbi.common.model.Account;
import com.sbi.common.model.Transaction;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.TransactionRequestMapper;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.model.CorpTransaction;
import com.sbi.common.model.CorpTransactionLeg;
/**
 * TODO This class is used to set the input values from map to Transaction model 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class CorpFundTransferRequestMapper extends TransactionRequestMapper{

	/**
     * TODO 1.Retrieves values from HashMap and sets them to the CorpTransactionLeg.
     * 2.Debit details from the map are set to corptransactionDebitLeg.
     * 3.List of credits are set to  creditLegs which  inturn are added to corptransactionLegArray.
     * 4.corptransactionDebitLeg,corptransactionLegArray are set to the credit and debit fields of the  
     * Transaction object.
     * 5. Calls [identifyTransactionPath(String debitbranchCode, String creditBranchCode, int txnCount)]
     * to get the transaction path
     * 6.sets the transaction path to the Transaction object.
     * 7.Returns Transaction object
     * 
     * @param Map
     * @return Transaction
     */
	
	public Transaction getTransactionObject(Map input){
		
		logger.info("getTransactionObject( Map input ) method begin" );
		if(logger.isDebugEnabled()){
			logger.debug("Map values ::"+input);
		}
		Transaction corpTransaction = new CorpTransaction();
		CorpTransactionLeg corptransactionDebitLeg = new CorpTransactionLeg();
        String beneficiary="";
		if(input!=null){
		List creditList = (List)input.get("creditAccountList");
		Timestamp sysdate = StringUtils.currentTimeStamp();
        
		
		int txnCount = creditList.size();
		Timestamp  scheduledDate=null;
		
		
        
		String debitAccountNo = (String) input.get(UtilsConstant.DEBIT_ACCOUNT_NO);
		String debitBranchCode = (String) input.get(UtilsConstant.DEBIT_BRANCH_CODE);
		String remarks = (String)input.get(UtilsConstant.TRANSACTION_REMARKS);
		Double debitAmount = new Double((String) input.get(UtilsConstant.AMOUNT_TRANSFER));
		String userName = (String) input.get(UtilsConstant.USER_NAME);
		Integer approverLevel = (Integer)input.get(UtilsConstant.APPROVER_LEVEL);
		String scheduledStatus = (String)input.get("scheduleStatus");
		String corpId = (String)input.get(UtilsConstant.CORPORATE_ID);
		String businessLineId = (String)input.get(UtilsConstant.BUSINESSLINE_ID);
		String merchantCode = (String)input.get(UtilsConstant.CORP_MERCHANT_CODE);
		String supplierId = (String)input.get(UtilsConstant.SUPPLIER_ID);
		//String debitBranchName = getBranchName(debitBranchCode);
		String accountNickName = (String)(input.get(UtilsConstant.ACCOUNT_NICK_NAME));
		String name = (String)input.get("name");
		String corpName = (String)input.get(UtilsConstant.CORP_NAME);
		String fundsTranferType = ( String )  input.get(UtilsConstant.FUNDS_TRANSFER_TYPE);
		String productType = (String)input.get(UtilsConstant.DEBIT_ACCOUNT_TYPE);
		String txnName = ((String) (input.get(UtilsConstant.TRANSACTION_NAME))).trim();
		String branchName = (String) input.get(UtilsConstant.DEBIT_BRANCH_CODE);
		String debitProductCode=(String) input.get("debitProductCode");
		
		logger.info("userName ***********"+userName);
		logger.info("debitAccountNo ***********"+debitAccountNo);
		logger.info("debitBranchCode ***********"+debitBranchCode);
		logger.info("debitAmount ***********"+debitAmount);
		logger.info("productType ***********"+productType);
		logger.info("branchName ***********"+branchName);
		logger.info("remarks ***********"+remarks);
		logger.info("creditAccountNo ***********"+(String) input.get("creditAccountNo"));
		logger.info("debitProductCode ***********"+debitProductCode);
		logger.info("userName ***********"+userName);
		logger.info("corpId ***********"+corpId);
		logger.info("businessLineId ***********"+businessLineId);
		logger.info("merchantCode ***********"+merchantCode);
		logger.info("supplierId ***********"+supplierId);
		
		double txnLimit=-1;
		
		if(input.get("transactionLimit") != null &&  input.get("transactionLimit") !="") {
			Double transactionLimit = new Double((String)input.get("transactionLimit"));
			txnLimit=transactionLimit.doubleValue();
		}
		corptransactionDebitLeg.setUserName(userName);
		corptransactionDebitLeg.setAccountNo(debitAccountNo);
		corptransactionDebitLeg.setBranchCode(debitBranchCode);
		corptransactionDebitLeg.setAmount(debitAmount);
		corptransactionDebitLeg.setProductType(productType);
		corptransactionDebitLeg.setBranchName(branchName);
		corptransactionDebitLeg.setRemarks(remarks);
		corptransactionDebitLeg.setMerchantCode("CORPETDR");
		corptransactionDebitLeg.setThirdPartyRef((String) input.get("creditAccountNo"));
		corptransactionDebitLeg.setRemarks("Corp e-TDR/e-STDR");
		corptransactionDebitLeg.setDebitProductCode(debitProductCode);
		corptransactionDebitLeg.setUserProfileName(userName);
		corptransactionDebitLeg.setCurrentAuthLevel("1");	
		corptransactionDebitLeg.setScheduled("1");
		corptransactionDebitLeg.setEchequeDate(sysdate);
		corptransactionDebitLeg.setScheduledDate(sysdate);//Added for Defect CR-3061

    	 
//		if(approverLevel.intValue()==2||approverLevel.intValue()==3){
//			corptransactionDebitLeg.setCurrentAuthLevel("-5");
//		}else{
	
//		}
//		if(scheduledStatus != null && scheduledStatus.equalsIgnoreCase("not immediately")){
//			corptransactionDebitLeg.setScheduled("0");
//			scheduledDate = StringUtils.dateTimeStringTimeStamp((String)input.get("scheduleDate"));
//			corptransactionDebitLeg.setEchequeDate(scheduledDate);
//		}else if ( scheduledStatus != null && scheduledStatus.equalsIgnoreCase("immediately")){
			
		
//		if(scheduledDate!=null)
//			corptransactionDebitLeg.setScheduledDate(scheduledDate);
		corptransactionDebitLeg.setCorporateId(corpId);
		corptransactionDebitLeg.setBusinessLineId(businessLineId);
		corptransactionDebitLeg.setMerchantCode(merchantCode);
		corptransactionDebitLeg.setSupplierName(supplierId);
		corptransactionDebitLeg.setTransactionLimit(txnLimit);
		corptransactionDebitLeg.setSupplierId("");
		corptransactionDebitLeg.setBusinessLineId("0");
//		if(fundsTranferType.equalsIgnoreCase(UtilsConstant.EDIT_TRANSACTION))
//		{
//		if(logger.isDebugEnabled()){
//			logger.debug("fundsTranferType : "+fundsTranferType);
//		}
//		String refNo =  ( String )  input.get("referenceNumber");
//		logger.info("Refere number ::: " + refNo);
//		corptransactionDebitLeg.setReferenceNo(refNo);
//		}
		
		corpTransaction.setDebit(corptransactionDebitLeg);//for debit
		CorpTransactionLeg corptransactionLegArray[] = new CorpTransactionLeg[txnCount];
	
		for(int i=0;i<txnCount;i++){
			
			corptransactionLegArray[i] = new CorpTransactionLeg();
			CorpTransactionLeg creditLeg = new CorpTransactionLeg();

			Account account = (Account) creditList.get(i);
			String creditAccountNo = account.getAccountNo();
			String creditBranchCode = account.getBranchCode();
			String creditBranchName = getBranchNameFromCache(creditBranchCode);
			
			logger.info("userName ***********"+userName);
			logger.info("corpName ***********"+corpName);
			logger.info("creditAccountNo ***********"+creditAccountNo);
			logger.info("creditBranchCode ***********"+creditBranchCode);
			logger.info("account.getBalance() ***********"+account.getBalance());
			logger.info("productType+creditAccountNo ***********"+productType+creditAccountNo);
			logger.info("creditBranchName ***********"+creditBranchName);
			logger.info("account.getAccountNo() ***********"+account.getAccountNo());
			logger.info("account.getBranchCode()+ creditBranchName ***********"+account.getBranchCode()+creditBranchName);
			logger.info("account.getAccountNickName() ***********"+account.getAccountNickName());
			logger.info("name***********"+name);
			logger.info("corpId***********"+corpId);
			creditLeg.setUserName(userName);
			//creditLeg.setCorpName(corpName);
			creditLeg.setUserProfileName(corpName);
			creditLeg.setAccountNo(creditAccountNo);
			creditLeg.setBranchCode(creditBranchCode);
			creditLeg.setAmount(account.getBalance());
			creditLeg.setProductType(productType+creditAccountNo);
			creditLeg.setBranchName(creditBranchName);
			creditLeg.setNarrative1(account.getAccountNo());
			//creditLeg.setNarrative2(debitBranchCode+ "," + debitBranchName);
			creditLeg.setNarrative2(account.getBranchCode()+","+creditBranchName);
			creditLeg.setNarrative3(account.getAccountNickName());
			creditLeg.setName(name);//user profile name
			creditLeg.setCorporateId(corpId);
			creditLeg.setScheduled("0");
			creditLeg.setCurrentAuthLevel("0");
			
			
			//logger.info("txnname " + txnName);
			corptransactionLegArray[i] = creditLeg;
			//logger.info("CorpTransaction CreditLeg Leg:" + creditLeg);
			
		}
       
		String transPath = identifyTransactionPath((String) input.get(UtilsConstant.DEBIT_BRANCH_CODE),
				corptransactionLegArray[0].getBranchCode(), txnCount);
		corpTransaction.setCredit(corptransactionLegArray); //for credit
		corpTransaction.setPath(transPath);
		if(txnName.equalsIgnoreCase("CI")){
			
			corpTransaction.setName(txnName.trim());
		}
        
        // Beneficiary name set into Debit leg. 
        if ( txnCount > 1 )
            {
                beneficiary ="Multiple Credits";
                
            }
            else
            {
                beneficiary = corptransactionLegArray[0].getNarrative3(); // Get the Beneficary name.
            }
        
            corptransactionDebitLeg.setBeneficiary(beneficiary);
		
		}
		logger.info("getTransactionObject( Map input )method  end"+corptransactionDebitLeg.getEchequeDate());
		
		
		return corpTransaction;
	}
}
