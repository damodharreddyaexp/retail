package com.sbi.common.etdr.utils;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.logging.Logger;

import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.PDFConverter;
import com.sun.java.util.jar.pack.Attribute.Layout.Element;


public class EtdrChallanPdf {
	private PDFConverter pdfFormat;
	protected final Logger logger = Logger.getLogger(getClass());

	public PdfPTable addChallanParaEtdr(String para, int columns,
			int widthPercentage, int[] headerWidths, int padding) {
		PdfPTable table = new PdfPTable(columns);
		try {
			pdfFormat.document.add(new Paragraph(para));
			table.getDefaultCell().setPadding(padding);
			table.setWidths(headerWidths);
			table.setWidthPercentage(widthPercentage); // percentage
			table.getDefaultCell().setBorder(0);
			// table.getDefaultCell().setBorderWidth(0.0f);
			table.getDefaultCell().setBorderColor(Color.WHITE);
			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		} catch (DocumentException de) {
			System.err.println(de.getMessage());
		}
		return table;
	}

	public void addChallanBorderLabelLeft(String txtDisplay, PdfPTable table,
			Boolean isWrap, Color borderColor, Color backgroundColor,
			float padding, Font font, boolean isBorder ) {

		Phrase phrase4 = new Phrase(txtDisplay, font);
		PdfPCell cell4 = new PdfPCell(phrase4);
		cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell4.setBorderColor(borderColor);
		if(isBorder)
		cell4.setBorderWidth(1);
		else
			cell4.setBorderWidth(0);//to get transparent border.
		cell4.setPadding(padding);
		// cell4.setBackgroundColor(backgroundColor);
		// System.out.println(" txtDisplay: "+txtDisplay);
		// System.out.println(" wrap status: "+isWrap.booleanValue());
		cell4.setNoWrap(isWrap.booleanValue());
		// cell4.setVerticalAlignment(1);
		table.addCell(cell4);
	}

	public void addTextEtdr(String para, Font font) {
		try {
			pdfFormat.document.add(new Paragraph(para, font));

		} catch (DocumentException de) {
			System.err.println(de.getMessage());
		}

	}

	public void addPdfImageEtdr(String pict) {
		try {
			logger.info("image path ::"+pict);
			Image logo = Image.getInstance(pict);
			logger.info(logo );//+ " iscontent() ::"+logo.isContent() +" is jpeg ::"+ logo.isJpeg());
			
			// logger.info("logo image size: "+logo);
			logo.scalePercent(75, 75);

			logo.setAbsolutePosition(375, 750);
			pdfFormat.document.add(logo);
		} catch (Exception de) {
			de.printStackTrace();
			System.err.println(de.getMessage());
		}
	}

	/**
	 * TODO Get the Challan parameters from Transaction object, and convert the
	 * values to String and add result string to PDFConverter which contains
	 * specified format to display the Challan in PDF file.
	 * 
	 * @param Transaction
	 * @return PDFConverter
	 */
	public PDFConverter EtdrChallanConverter(Map inputParams,
			OutputStream output) {
		
		logger.info(" EtdrChallanConverter(Map inputParams, OutputStream output) begin with inputparams "
						+ inputParams);

		
		FixedDepositModel fdAcc = (FixedDepositModel) inputParams.get("fdAcc");
		String valueDate = new SimpleDateFormat("dd-MMM-yyyy").format(fdAcc
				.getValueDate());
		
		String tableValueDate = new SimpleDateFormat("dd/MM/yyyy").format(fdAcc
				.getValueDate());
		
		String etdrchallanflag=(String)inputParams.get("etdrchallanflag");
		logger.info("etdrchallanflag::::::"+etdrchallanflag);
		
		pdfFormat.pdfCreateFile(output);
		int headerWidthsOuter[] = { 100 };
		//int headerwidthsInner[] = { 4, 45, 50, 1 };
		int headerwidthsInner[]={0,54,40,1};//CUG
		//int headerwidthsInner2[] = { 25, 10, 12, 15, 12, 12, 15 };
		int headerwidthsInner2[]={22,14,10,15,13,13,15};
		int terms[] = { 4, 90 };
		//int headerText[] = { 15, 50, 25 };
		int headerText[]={15,40,25};
		int headerwidthsInnerHeader[] = { 3, 75 };
		int message[] = { 75 };
		//int accountDetails[] = { 2, 12, 18, 8, 12, 3 };
		int accountDetails[] = { 0, 15, 18, 12, 10, 3 };//CUG
		int termsheading[]={75};//CUG
		int headerwidthsInner3[]={22,14,10,15,13,13,15};
		
		
		Font srCitizenHeading =new Font(Font.HELVETICA,12,Font.BOLD);
		Font headerFont = new Font(Font.HELVETICA, 10, Font.BOLD, new Color(
				54, 115, 144));
		Font textFont = new Font(Font.HELVETICA, 10, Font.NORMAL);
		Font heading = new Font(Font.HELVETICA, 10, Font.BOLD);
		Font bankName = new Font(Font.HELVETICA, 15, Font.BOLD, new Color(65,
				105, 225));
		Font text = new Font(Font.HELVETICA, 10, Font.NORMAL);
		Font footNote = new Font(Font.HELVETICA, 9, Font.ITALIC);

		PdfPTable outer = addChallanParaEtdr(" ", 1, 100, headerWidthsOuter, 1);
		PdfPTable header = addChallanParaEtdr("", 2, 85,
				headerwidthsInnerHeader, 0);

		PdfPTable firstBody = addChallanParaEtdr("", 4, 85, headerwidthsInner,
				0);
		PdfPTable secondBody = addChallanParaEtdr("", 7, 85,
				headerwidthsInner2, 0);
		PdfPTable thirdBody = addChallanParaEtdr("", 7, 85,headerwidthsInner3, 0);		
		PdfPTable termsBody = addChallanParaEtdr("", 2, 85, terms, 0);
		PdfPTable headerBody = addChallanParaEtdr("", 3, 85, headerText, 0);
		PdfPTable messageBody = addChallanParaEtdr("", 1, 85, message, 0);
		PdfPTable accountDetailsBody = addChallanParaEtdr("", 6, 85,accountDetails, 0);
		PdfPTable termsHeadingTable = pdfFormat.addChallanPara("",1,85,termsheading,0);//CUG
		
		PdfPTable table = new PdfPTable(6);
		table.getDefaultCell().setBorderColor(Color.red);

		Cell c1 = new Cell("header1");

		c1.setHeader(true);

		table.setHeaderRows(4);
		pdfFormat.addPdfPTable(table);
		String bankCode = fdAcc.getFdBranchCode().substring(0,1);
		
		if("A".equalsIgnoreCase(bankCode) || "3".equals(bankCode) || "6".equals(bankCode) ){//for branch code starting from A
			bankCode="0";			
		}
		logger.info("Branchcode in EtdrChallanPDF--->"+fdAcc.getFdBranchCode().substring(0,1)+"  "+"BankCode--->"+bankCode);

		try {

			addTextEtdr(
					"                                                           This is not a negotiable document",
					text);
			if(bankCode.equalsIgnoreCase("0") ){

			addTextEtdr(
					"                                   STATE BANK OF INDIA",
					bankName);
			addTextEtdr(
					"INB Ref No.                                               "
							+ inputParams.get("branchName") + "("
							+ getBankCode(fdAcc.getFdBranchCode()) + ")", heading);
			addTextEtdr(inputParams.get("inbRefNo").toString()
					+ "                     ", text);
			addPdfImageEtdr("/doc-root/sbijava/images/header_2_02.jpg");
			//addPdfImageEtdr("D:/jboss-4.0.5.GA/server/default/deploy/sbijava.war/images/header_2_02.jpg");//to remove
			}
			else if(bankCode.equalsIgnoreCase("7")){
				
				addTextEtdr(
						"                              STATE BANK OF TRAVANCORE",
						bankName);
				addTextEtdr(
						"INB Ref No.                                               "
								+ inputParams.get("branchName") + "("
								+ fdAcc.getFdBranchCode() + ")", heading);
				addTextEtdr(inputParams.get("inbRefNo").toString()
						+ "                     ", text);
				addPdfImageEtdr("/doc-root/sbijava/images/bank_logo_7.gif");

				
			}
			else if(bankCode.equalsIgnoreCase("1")){				
				addTextEtdr(
						"                              STATE BANK OF BIKANER AND JAIPUR",
						bankName);
				addTextEtdr(
						"INB Ref No.                                               "
								+ inputParams.get("branchName") + "("
								+ fdAcc.getFdBranchCode() + ")", heading);
				addTextEtdr(inputParams.get("inbRefNo").toString()
						+ "                     ", text);
				addPdfImageEtdr("/doc-root/sbijava/images/sbbj_logo_etdr_1.gif");
			}
			else if(bankCode.equalsIgnoreCase("4")){				
				addTextEtdr(
						"                              STATE BANK OF MYSORE",
						bankName);
				addTextEtdr(
						"INB Ref No.                                               "
								+ inputParams.get("branchName") + "("
								+ fdAcc.getFdBranchCode() + ")", heading);
				addTextEtdr(inputParams.get("inbRefNo").toString()
						+ "                     ", text);
				addPdfImageEtdr("/doc-root/sbijava/images/bank_logo_4.gif");				
			}
			else if(bankCode.equalsIgnoreCase("5")){				
				addTextEtdr(
						"                              STATE BANK OF PATIALA",
						bankName);
				addTextEtdr(
						"INB Ref No.                                               "
								+ inputParams.get("branchName") + "("
								+ fdAcc.getFdBranchCode() + ")", heading);
				addTextEtdr(inputParams.get("inbRefNo").toString()
						+ "                     ", text);
				addPdfImageEtdr("/doc-root/sbijava/images/bank_logo_5.gif");				
			}
			else if(bankCode.equalsIgnoreCase("2")){				
				addTextEtdr(
						"                              STATE BANK OF HYDERABAD",
						bankName);
				addTextEtdr(
						"INB Ref No.                                               "
								+ inputParams.get("branchName") + "("
								+ fdAcc.getFdBranchCode() + ")", heading);
				addTextEtdr(inputParams.get("inbRefNo").toString()
						+ "                     ", text);
				addPdfImageEtdr("/doc-root/sbijava/images/bank_logo_2.gif");				
			}
			if("yes".equalsIgnoreCase(fdAcc.getIsSeniorCitizen())){
				addTextEtdr("  					",text);
				addTextEtdr("( Senior Citizen Deposit )",srCitizenHeading);
			}

			if("2".equals(bankCode) && "Yes".equalsIgnoreCase(fdAcc.getIsSbhDouble().trim())){
				addTextEtdr("  					",text);
				addTextEtdr("( SBH Double Deposit )",srCitizenHeading);
			}
			addChallanBorderLabelLeft("", headerBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("  ", headerBody, Boolean.TRUE,
					Color.WHITE, Color.WHITE, 6.0f, headerFont,Boolean.FALSE);
			if(inputParams.get("fdType").equals("STDR")){
			addChallanBorderLabelLeft("e-Special Term Deposit Advice",
					headerBody, Boolean.FALSE, Color.white, Color.white, 6.0f,
					heading,Boolean.FALSE);
			}
			else if(inputParams.get("fdType").equals("TDR")){
				addChallanBorderLabelLeft("        e-Term Deposit Advice",
						headerBody, Boolean.FALSE, Color.white, Color.white, 6.0f,
						heading,Boolean.FALSE);
			}

			addChallanBorderLabelLeft("", headerBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(" ", headerBody, Boolean.TRUE,
					Color.WHITE, Color.WHITE, 6.0f, headerFont,Boolean.FALSE);
			addChallanBorderLabelLeft("     (In lieu of term deposit receipt)",
					headerBody, Boolean.FALSE, Color.white, Color.white, 0.20f,
					textFont,Boolean.FALSE);

			addChallanBorderLabelLeft("", headerBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(" ", headerBody, Boolean.TRUE,
					Color.WHITE, Color.WHITE, 6.0f, headerFont,Boolean.FALSE);
			addChallanBorderLabelLeft("             Date : " + valueDate,
					headerBody, Boolean.FALSE, Color.white, Color.white, 6.0f,
					textFont,Boolean.FALSE);

			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, headerBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(headerBody, 1);

			addChallanBorderLabelLeft("Dear Sir/Madam", messageBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(
							"We have pleasure in confirming details of the following amount held in deposit with us. Please quote the Account Number in all correspondence. Thank you for Banking with us.",
							messageBody, Boolean.FALSE, Color.WHITE,
							Color.WHITE, 6.0f, textFont,Boolean.FALSE);

			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, messageBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(messageBody, 1);

			addChallanBorderLabelLeft("", firstBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("Name", firstBody, Boolean.TRUE,
					Color.WHITE, Color.WHITE, 6.0f, heading,Boolean.FALSE);
			addChallanBorderLabelLeft("Customer Number", firstBody,
					Boolean.FALSE, Color.white, Color.white, 6.0f, heading,Boolean.FALSE);
			addChallanBorderLabelLeft("", firstBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);

				logger.info("customerName :::::"
						+ fdAcc.getDebitHolderName());

				addChallanBorderLabelLeft("", firstBody, Boolean.FALSE,
						Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
				addChallanBorderLabelLeft(fdAcc.getDebitHolderName(), firstBody, Boolean.TRUE,
						Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
				addChallanBorderLabelLeft(fdAcc.getCustomerNo(), firstBody, Boolean.FALSE,
						Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
				addChallanBorderLabelLeft("", firstBody, Boolean.FALSE,
						Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			
			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, firstBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(firstBody, 1);

			addChallanBorderLabelLeft("", accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("Debit Account Number : ",
					accountDetailsBody, Boolean.TRUE, Color.WHITE, Color.WHITE,
					6.0f, heading,Boolean.FALSE);
			addChallanBorderLabelLeft(fdAcc.getDebitAccountNo(),
					accountDetailsBody, Boolean.FALSE, Color.WHITE,
					Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("Mode of operation : ", accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			addChallanBorderLabelLeft(fdAcc.getFdAccNature(), accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("", accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);

			addChallanBorderLabelLeft("", accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("Scheme : ",
					accountDetailsBody, Boolean.TRUE, Color.WHITE, Color.WHITE,
					6.0f, heading,Boolean.FALSE);
			addChallanBorderLabelLeft(inputParams.get("productDescription")
					.toString(),
					accountDetailsBody, Boolean.FALSE, Color.WHITE,
					Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			
			
			
			
			
			
				logger.info("nominee mapping NOT required::::");
				addChallanBorderLabelLeft(" ", accountDetailsBody, Boolean.TRUE, Color.WHITE,
					Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			
				addChallanBorderLabelLeft(" ", accountDetailsBody, Boolean.TRUE, Color.WHITE,
					Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			
		if(fdAcc.getAutoRenewDescription()!=null && fdAcc.getAutoRenewDescription().trim().length()>0){
			logger.info("AutoRenewDescription -->"+fdAcc.getAutoRenewDescription());
			addChallanBorderLabelLeft("",accountDetailsBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("",accountDetailsBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("Maturity Instruction: ",accountDetailsBody,Boolean.TRUE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.FALSE);
			addChallanBorderLabelLeft(fdAcc.getAutoRenewDescription(),accountDetailsBody,Boolean.TRUE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("",accountDetailsBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("",accountDetailsBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.FALSE);
		}
			addChallanBorderLabelLeft("", accountDetailsBody,
					Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);

			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, accountDetailsBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(accountDetailsBody, 1);

			addChallanBorderLabelLeft("e-TDR/e-STDR Account No.", secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			addChallanBorderLabelLeft("Tenure", secondBody, Boolean.TRUE,
					Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			String fixedorfloatType="";
			if("0".equals(bankCode)){
				String fdRateType=fdAcc.getTypeOfInterestRate();
				if("fixedrate".equalsIgnoreCase(fdRateType)){
					fixedorfloatType="Fixed Rate";
				}else if("floatrate".equalsIgnoreCase(fdRateType)){
					fixedorfloatType="Floating Rate";
				}
			addChallanBorderLabelLeft(fixedorfloatType+"\nInterest @", secondBody, Boolean.FALSE,
					Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			}
			if("1".equals(bankCode) || "4".equals(bankCode) || "5".equals(bankCode)  || "7".equals(bankCode) || "2".equals(bankCode)){
			addChallanBorderLabelLeft("Interest @", secondBody, Boolean.FALSE,
					Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			}
			addChallanBorderLabelLeft("Principal Amt", secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			addChallanBorderLabelLeft("Value Date", secondBody, Boolean.FALSE,
					Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			addChallanBorderLabelLeft("Maturity Date  ", secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);
			addChallanBorderLabelLeft("Maturity Value   ", secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, heading,Boolean.TRUE);

			addChallanBorderLabelLeft(fdAcc.getFdAccountNo(), secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, textFont,Boolean.TRUE);

			if (!fdAcc.isDtMonYr()) {
				addChallanBorderLabelLeft(fdAcc.getTenureInDays() + " Days ",
						secondBody, Boolean.FALSE, Color.black, Color.WHITE,
						6.0f, textFont,Boolean.TRUE);
			} else {
				addChallanBorderLabelLeft(fdAcc.getYears() + " Year(s)\n"
						+ fdAcc.getMonths() + " Month(s)\n" + fdAcc.getDays()
						+ " Day(s) ", secondBody, Boolean.FALSE, Color.black,
						Color.WHITE, 6.0f, textFont,Boolean.TRUE);
			}
			
			
			addChallanBorderLabelLeft(fdAcc.getInterestRate().toString() + "%",
					secondBody, Boolean.FALSE, Color.black, Color.WHITE, 6.0f,
					textFont,Boolean.TRUE);
			
			Double dnum = fdAcc.getPrincipalAmount();
			DecimalFormat decimalFormat = new DecimalFormat("#0.00");
			String strPrincipalAmount = decimalFormat.format(dnum);
			
			
			
			
			addChallanBorderLabelLeft("INR "
					+ strPrincipalAmount, secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, textFont,Boolean.TRUE);
			addChallanBorderLabelLeft(tableValueDate, secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, textFont,Boolean.TRUE);
			addChallanBorderLabelLeft(fdAcc.getMaturityDate(), secondBody,
					Boolean.FALSE, Color.black, Color.WHITE, 6.0f, textFont,Boolean.TRUE);
			addChallanBorderLabelLeft("INR " + fdAcc.getMaturityAmount(),
					secondBody, Boolean.FALSE, Color.black, Color.WHITE, 6.0f,
					textFont,Boolean.TRUE);

			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, secondBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(secondBody, 1);
			if(fdAcc.getAutoRenewDescription()!=null && fdAcc.getAutoRenewDescription().trim().length()>0 && !"Repay Principal and Interest".equalsIgnoreCase(fdAcc.getAutoRenewDescription())){
			addChallanBorderLabelLeft("Maturity Instruction Tenure",thirdBody,Boolean.FALSE,Color.black,Color.WHITE,6.0f,heading,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.BLACK,Color.WHITE,3.0f,heading,Boolean.FALSE);		
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,heading,Boolean.TRUE);

			if (!fdAcc.isAutoRenewDtMonYr()) {
				addChallanBorderLabelLeft(fdAcc.getAutoRenewTenureInDays() + " Days ",
						thirdBody, Boolean.FALSE, Color.black, Color.WHITE,
						6.0f, textFont,Boolean.TRUE);
			} else {
				addChallanBorderLabelLeft(fdAcc.getAutoRenewYears() + " Year(s)\n"
						+ fdAcc.getAutoRenewMonths() + " Month(s)\n" + fdAcc.getAutoRenewDays()
						+ " Day(s) ", thirdBody, Boolean.FALSE, Color.black,
						Color.WHITE, 6.0f, textFont,Boolean.TRUE);
			}			
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.BLACK,Color.WHITE,0.0f,textFont,Boolean.FALSE);
			
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.TRUE);
			addChallanBorderLabelLeft("",thirdBody,Boolean.FALSE,Color.WHITE,Color.WHITE,6.0f,textFont,Boolean.TRUE);
			
        	
			pdfFormat.nestTable(outer,header);
			pdfFormat.nestTable(outer,thirdBody);
			pdfFormat.endChallanTableHeader(header,1);
			pdfFormat.endChallanTableHeader(thirdBody,1);		
			}
			addChallanBorderLabelLeft(" ", termsHeadingTable, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, heading,Boolean.FALSE);
			addChallanBorderLabelLeft("Terms and Conditions for e-TDR / e-STDR", termsHeadingTable, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, heading,Boolean.FALSE);
        	pdfFormat.nestTable(outer,header);
    		pdfFormat.nestTable(outer,termsHeadingTable);
    		pdfFormat.endChallanTableHeader(header,1);
        	pdfFormat.endChallanTableHeader(termsHeadingTable,1);
        	
			
			

			addChallanBorderLabelLeft("1.", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(
							"1.	The e-TDR/e-STDR in INR is generated in the same name(s) of the account holder(s) as in account from which it is funded.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("2.", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(
							"2.	The interest on the Term Deposit (e-TDR), and the proceeds of the Term Deposit (e-TDR) or Special Term Deposit (e-STDR) upon maturity, will be credited to the account from which the e-TDR/e-STDR was funded.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft("3.", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(
							"3.	Bank will deduct the income tax as per the law applicable and in case no tax is to be deducted, form 15H/G (wherever applicable) and other exemption certificates has to be submitted by the depositor to the branch just after opening the e-TDR/e-STDR and at the beginning the Financial Year in the subsequent Financial Years.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, textFont,Boolean.FALSE);
			
			addChallanBorderLabelLeft("4.", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(
							"e-TDR/e-STDR will be disposed of according to the Maturity Instruction given at the time of opening the deposit. In case  of auto renewal," +
							"the deposit will be renewed for the same duration for which it was originally kept, at the rate of interest prevailing on the date of renewal for that duration." +
							"If auto renewal instructions are given, the instructions will continue to executed till terminated by the account holder.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, textFont,Boolean.FALSE);
/*			if("0".equals(bankCode)){
			addChallanBorderLabelLeft("6.", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			// Line added for Fixed or Float Type for SBI  (Added by Srinivas Starts here)
			addChallanBorderLabelLeft(
							"Interest rate on floating rate term deposit would be linked to Bank's base rate and would be" +
							"reset every time the base rate changes, with an upper cap of 200 basis points above the" +
							"fixed term deposit rate. Maturity Value shown in the term deposit advice will vary accordingly as per interest rate applicable during its tenure.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, textFont,Boolean.FALSE);			
						//Added by Srinivas Ends here)
			}*/
			if("4".equals(bankCode)){
				addChallanBorderLabelLeft("6.", termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
				// Line added for SBM (Added by Srinivas Starts here)
				addChallanBorderLabelLeft("For availing loan against e-TDR/ e-STDR , please obtain a deposit Receipt from the HOME branch.",
								termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);			
							//Added by Srinivas Ends here)
				}
			addChallanBorderLabelLeft("", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
			addChallanBorderLabelLeft(" ", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);

			addChallanBorderLabelLeft("", termsBody, Boolean.FALSE,
					Color.WHITE, Color.WHITE, 6.0f, textFont,Boolean.FALSE);
/*			addChallanBorderLabelLeft(
							"                                 This is a system generated advice. It does not require any signature.",
							termsBody, Boolean.FALSE, Color.WHITE, Color.WHITE,
							6.0f, footNote,Boolean.FALSE);
*/
			pdfFormat.nestTable(outer, header);
			pdfFormat.nestTable(outer, termsBody);
			pdfFormat.endChallanTableHeader(header, 1);
			pdfFormat.endChallanTableHeader(termsBody, 1);

			pdfFormat.endChallanTableHeader(outer, 1);
			pdfFormat.addChallanPdfTableFromJSP(outer);
		} catch (Exception pdfexp) {
			// TODO Auto-generated catch block
			logger.error("Exception in pdfGeneration ::"+ pdfexp);
			SBIApplicationException.throwException("FD027");
		}

		pdfFormat.closeDocument();

		if (logger.isDebugEnabled())
			logger
					.debug(" EtdrChallanConverter(Map inputParams, OutputStream output) end, pdf generated object :"
							+ pdfFormat);

		return pdfFormat;
	}

	// added by viswalakshmy ends for cr2633

	private String timeStamptoString(Timestamp timestamp) {
		long millis = (timestamp.getTime() / 1000) * 1000
				+ timestamp.getNanos() / 1000000;
		java.util.Date date = new java.util.Date(millis);
		String toDatestr = new SimpleDateFormat("dd/MM/yy").format(date);
		return toDatestr;
	}
	
	public String getTimeStamp(String p_format){
	      
	      DateFormat dateFormat = new SimpleDateFormat ( p_format);
	      Date sysDate = new Date ();
	      String sysdate = dateFormat.format ( sysDate );
	      
	      return sysdate;
	   }

	public void setPdfFormat(PDFConverter pdfFormat) {
		this.pdfFormat = pdfFormat;
	}
	private String getBankCode(String branchCode) {

		if( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("A") ){
			logger.info("branchCode before replace::"+ branchCode);
			branchCode = branchCode.replaceFirst("A", "1");
		}		
		return branchCode;

	}

}