package com.sbi.common.etdr.utils;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.etdr.dao.FixedDepositDAO;
import com.sbi.common.etdr.model.FixedDepositModel;

public class FixedDepositUtils {
	
	private FixedDepositDAO fixedDepositDAOImpl;
	
	private UserSessionCache userSessionCache;
	
	private Logger logger = Logger.getLogger(getClass());
	
	public int daysConvertor(Integer year,Integer month,Integer days){
		logger.info("daysConvertor (..) year:" + year + "month:" + month + "days:" + days+ " Start here");
		long totaldays=0;
		try{
			Calendar currentCalendar = Calendar.getInstance();
			Calendar futurCalender = Calendar.getInstance();
			if (year != null) {
				futurCalender.add(Calendar.YEAR, year);
			}
			if (month != null) {
				futurCalender.add(Calendar.MONTH, month);
			}
			if (days != null) {
				futurCalender.add(Calendar.DATE, days);
			}
			totaldays = (futurCalender.getTime().getTime() - currentCalendar.getTime().getTime())/ (24 * 60 * 60 * 1000);
			logger.info("Total no of  days: " + totaldays);
		}
		catch(Exception e){
			logger.error(" Exception occured in isValidDateAndTime :", e);
			logger.error(e,e);
		}
		logger.info("daysConvertor (..) year:" + year + "month:" + month + "days:" + days+ " Ends here");
		return (int)totaldays;

	}
	
	
	public String getProductDesc(String productCode,String bankCode,String fdRate){
		if(logger.isDebugEnabled())
			logger.debug(" getProductDesc method begins");
		String productDesc = "";
		if(productCode!=null)
		{			
				
			productDesc = fixedDepositDAOImpl.getProductDesc(productCode,bankCode,fdRate);		
			return productDesc;
			
			
		}
		logger.info("productDesc"+productDesc);
		if(logger.isDebugEnabled())
			logger.debug("getProductDesc method ends");
		return productDesc;
		
	}
	public void clearAccounts(String userName) {
		try{
			userSessionCache.removeData(userName + DAOConstants.USER_ACCOUNTS);
		}
		catch(Exception e){
			logger.error(e,e);
		}
		
	}
	
	public String getInterestPayout(String fdRateType,String cumulativeType,Integer totalNoOfDays,String intPayout)
	{
		if(logger.isDebugEnabled())
			logger.debug(" getInterestPayout method begins");
		String actualIntPayout="";
		if("fixedrate".equalsIgnoreCase(fdRateType)){	
		if (cumulativeType!=null && cumulativeType.equalsIgnoreCase("STDR")){
			actualIntPayout = "Maturity"; 
		} 
		else if(cumulativeType!=null && cumulativeType.equalsIgnoreCase("TDR")){
			if (totalNoOfDays >= 181 && totalNoOfDays <= 365)
			{
				actualIntPayout = "Quarterly";
			}
			else if (totalNoOfDays <= 180)
			{
				actualIntPayout = "Maturity";
			}
			else 
				actualIntPayout = intPayout;
		}
		}else if("floatrate".equalsIgnoreCase(fdRateType)){
			if (cumulativeType!=null && cumulativeType.equalsIgnoreCase("STDR")){
				actualIntPayout = "Maturity";
			}else {
				actualIntPayout = intPayout;
			}
		}

		return actualIntPayout;
	}
	
	/**
	 * This method is intended for Associate Banks
	 * @param cumulativeType
	 * @param totalNoOfDays
	 * @param intPayout
	 * @return java.lang.String
	 */
	public String getInterestPayoutForAssociate(String cumulativeType,Integer totalNoOfDays,String intPayout)
	{
		if(logger.isDebugEnabled())
			logger.debug(" getInterestPayoutForAssociate method begins");
		String actualIntPayout="";
		
		if (cumulativeType!=null && cumulativeType.equalsIgnoreCase("STDR")){
			actualIntPayout = "Maturity"; 
		} 
		else if(cumulativeType!=null && cumulativeType.equalsIgnoreCase("TDR")){
			if (totalNoOfDays >= 181 && totalNoOfDays <= 365)
			{
				actualIntPayout = "Quarterly";
			}
			else if (totalNoOfDays <= 180)
			{
				actualIntPayout = "Maturity";
			}
			else 
				actualIntPayout = intPayout;
		}
		return actualIntPayout;
	}
	
	//	Added by srinivas for Associate Banks 
	public String getProductDescAssociateBanks(String productCode,String bankCode)//bank code added for associate bank by viswa
	{
		if(logger.isDebugEnabled())
			logger.debug(" getProductDescAssociateBanks method begins");
		String productDesc = "";
		
		if(productCode!=null){			
			productDesc = fixedDepositDAOImpl.getProductDescAssociateBanks(productCode,bankCode);		
			return productDesc;
		}
		logger.info("productDesc"+productDesc);
		
		if(logger.isDebugEnabled())
			logger.debug("getProductDescAssociateBanks method ends");
		return productDesc;
	}
	
	public Date convertStringToDate(String closedDate,String format){
		DateFormat formatter=new SimpleDateFormat(format);
		formatter.setLenient(false);
		Date formattedDate=null;
		try {
			logger.info("the date i received from the class"+closedDate+"the format which is given "+format);
			formattedDate = formatter.parse(closedDate);
			logger.info("the date i received from the class after "+closedDate+"the format which is given after "+format);
		}
		catch (ParseException e){
			e.printStackTrace();
		}
		return formattedDate;
	}


	public int calculateMyAge(int year, int month, int day) {
		logger.info("calculateMyAge(..) Starts here..");
		Calendar birthCal = new GregorianCalendar(year, month, day);
		Calendar nowCal = new GregorianCalendar();
		int age = nowCal.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);
		boolean isMonthGreater = birthCal.get(Calendar.MONTH) > (nowCal .get(Calendar.MONTH)+1);
		boolean isMonthSameButDayGreater = birthCal.get(Calendar.MONTH) == (nowCal .get(Calendar.MONTH)+1) && birthCal.get(Calendar.DAY_OF_MONTH) > nowCal .get(Calendar.DAY_OF_MONTH); 
		if (isMonthGreater || isMonthSameButDayGreater) { 
			age=age-1; 
		}
		logger.info("calculateMyAge(..) Ends here..");		
		return age; 
	} 
	
	public String formatMessage(FixedDepositModel fdModel){		
		return MessageFormat.format("Account number {0} and {1} are not in the same name / style, therefore, online closure of deposit account is not possible. Please request your home branch for closure.",formatMsgs(fdModel));
	}
	public String[] formatMsgs(FixedDepositModel fdModel){
		logger.info("formatMsgs(..) Starts here..");
		String[] keyVal=new String[2];
		keyVal[0]=fdModel.getDebitAccountNo();
		keyVal[1]=fdModel.getCreditAccountNo();
		logger.info("formatMsgs(..) Ends here..:"+keyVal[0]+" "+keyVal[1]);
		return keyVal;
	}	
	/* Added by Srinivas For Floating Rate CR available for SBI and other banks to disable*/
	public void setFixedDepositDAOImpl(FixedDepositDAO fixedDepositDAOImpl) {
		this.fixedDepositDAOImpl = fixedDepositDAOImpl;
	}
	
	
	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}
	
}
