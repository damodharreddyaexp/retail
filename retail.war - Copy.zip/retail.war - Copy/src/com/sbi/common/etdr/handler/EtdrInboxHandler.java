/*    
 * EtdrInboxHandler .java
 * Created on Jan 28, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $    
 */
//History

package com.sbi.common.etdr.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.etdr.model.EtdrMaster;

public class EtdrInboxHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    private BaseService etdrDisplayService;
    private BaseService etdrDetailsDisplayService;
    private BaseService etdrAuthorizeService;
    private BaseService etdrCancelService;
    
    private BaseService preCloseEtdrDisplayService;
    private BaseService preCloseEtdrDetailsDisplayService;
    private BaseService preCloseEtdrAuthorizeService;
    private BaseService preCloseEtdrCancelService;
    
    public ModelAndView etdrInboxDisplayHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("eTDRInboxDisplayHandler -- begins");
        String errorView="errorEtdrDisplay";
        Map inputParams = new HashMap();
        String txnPwd=null;
        HttpSession session = request.getSession(false);
        String view=null;
        String model= null;
        Map outParams=new HashMap();
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        txnPwd = userProfile.getTxnPassword();
        
        if (txnPwd == null || txnPwd.equals("")) {
		    getServletContext().getRequestDispatcher("/changetxnpassword.htm").forward(request,response);
		    return null;
        }
        else
        {
	        view="etdrDisplay";
	        model="EtdrMaster";
	        inputParams.put(ServiceConstant.USER_NAME, userProfile.getUserAlias());
	        outParams = etdrDisplayService.execute(inputParams);
	        outParams.put(UIConstant.ERROR_VIEW, errorView);
	        
	        logger.info("eTDRInboxDisplayHandler -- ends");
	   }
       return new ModelAndView(view, model, outParams);
       
    }
    
    public ModelAndView etdrDetailsDisplayHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("etdrDetailsDisplayHandler -- begins");
        Map inputParams = new HashMap();
        HttpSession session = request.getSession(false);
        Map outParams=new HashMap();
        String referenceNo=request.getParameter("referenceNo");
        logger.info("referenceNo  :  "+ referenceNo);
        String linkName ="";
        linkName = request.getServletPath().replaceAll("/", "");
        logger.info("linkName :"+linkName);
        inputParams.put("referenceNo", referenceNo);
        
        outParams = etdrDetailsDisplayService.execute(inputParams);
        outParams.put(UIConstant.ERROR_VIEW, "errorEtdrDetailsDisplay");
        outParams.put("linkName", linkName);  
		
        session.setAttribute("EtdrMaster", outParams);
        
        logger.info("etdrDetailsDisplayHandler -- ends");
	   return new ModelAndView("etdrDetailsDisplay", "EtdrMaster", outParams);
    }
    
    public ModelAndView etdrAuthorizeHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("etdrAuthorizeHandler -- begins");
       
        Map inputParams = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        String userName = userProfile.getUserAlias();

        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        logger.info("smallFlag :"+ corporateProfile.getSmallFlag());
        inputParams.put("smallFlag", corporateProfile.getSmallFlag());	
        			
        String view=null;
        String model= null;
        Map outParams=new HashMap();
        String referenceNo=request.getParameter("referenceNo");
        logger.info("referenceNo  ::::::  "+ referenceNo);
        
        view="etdrAuthorizeConfirm";
        model="EtdrMaster";
        
        inputParams.put("referenceNo", referenceNo);
        inputParams.put("userName", userName);
        inputParams.put("bankCode", userProfile.getBankCode());
        
        //Added for transaction password validation -Start
		String  txnPwdStatus = (String)request.getAttribute("txnPwdStatus");
		logger.info("txnPwdStatus :"+txnPwdStatus);
		if(txnPwdStatus != null && txnPwdStatus.equals("1")){
			
			logger.info("Invalid transaction pwd");
			session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
         	return new ModelAndView("etdrDetailsDisplay", UIConstant.TRANSACTION_MODEL, outParams);
			
		}
	    //Added for transaction password validation -End
		
		 String errorView="errorEtdrAuthorizeConfirm";
        
        outParams = etdrAuthorizeService.execute(inputParams);
        
        outParams.put(UIConstant.ERROR_VIEW, errorView);
        
        logger.info("etdrAuthorizeHandler -- ends");
        return new ModelAndView(view, UIConstant.TRANSACTION_MODEL, outParams);
    }
    
    
    
    
    public ModelAndView etdrCancelHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("etdrCancelHandler -- begins");
        String errorView="errorEtdrCancelSuccess";
        Map inputParams = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        String userName = userProfile.getUserAlias();
        
        String view="etdrCancelSuccess";
        Map outParams=new HashMap();
        String referenceNo=request.getParameter("referenceNo");
        logger.info("referenceNo  ::::::  "+ referenceNo);
        
        inputParams.put("referenceNo", referenceNo);
        inputParams.put("userName", userName);
        
        outParams = etdrCancelService.execute(inputParams);
        outParams.put("fdType", request.getParameter("fdType"));
        
        outParams.put(UIConstant.ERROR_VIEW, errorView);
        
        logger.info("etdrCancelHandler -- ends");
	   return new ModelAndView(view, "outParams", outParams);
    } 
    
    
    public ModelAndView preCloseEtdrInboxDisplayHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("preCloseEtdrInboxDisplayHandler -- begins");
      
        Map inputParams = new HashMap();
        String txnPwd=null;
        HttpSession session = request.getSession(false);
        String view=null;
        String model= null;
        Map outParams=new HashMap();
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        txnPwd = userProfile.getTxnPassword();
        logger.info("userProfile  ::::::  "+ userProfile );
        if (txnPwd == null || txnPwd.equals("")) {
		    getServletContext().getRequestDispatcher("/changetxnpassword.htm").forward(request,response);
		    return null;
        }
        else
        {
	        view="preCloseEtdrDisplay";
	        model="EtdrMaster";
	        String errorView="errorPreCloseEtdrDisplay";
	        
	        inputParams.put(ServiceConstant.USER_NAME, userProfile.getUserAlias());
	        outParams = preCloseEtdrDisplayService.execute(inputParams);
	        outParams.put(UIConstant.ERROR_VIEW, errorView);
	        
	        logger.info("preCloseEtdrInboxDisplayHandler -- ends");
	   }
       return new ModelAndView(view, model, outParams);
       
    }
    
    public ModelAndView preCloseEtdrDetailsDisplayHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("preCloseEtdrDetailsDisplayHandler -- begins");
        Map inputParams = new HashMap();
        Map outParams=new HashMap();
        
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        String preCloseReferenceNo=request.getParameter("preCloseReferenceNo");
        logger.info("preCloseReferenceNo  ::::::  "+ preCloseReferenceNo);
        String linkName ="";
        inputParams.put("preCloseReferenceNo", preCloseReferenceNo);
        inputParams.put("bankCode", userProfile.getBankCode());
        outParams = preCloseEtdrDetailsDisplayService.execute(inputParams);
        outParams.put(UIConstant.ERROR_VIEW, "errorPreCloseEtdrDetailsDisplay");
        linkName = request.getServletPath().replaceAll("/", "");
        logger.info("linkName ::"+linkName);
        outParams.put("linkName", linkName);  
		
        session.setAttribute("EtdrMaster", outParams);
        logger.info("outparams in etdrinboxhandler is:"+outParams);
        
        logger.info("preCloseEtdrDetailsDisplayHandler -- ends");
	   return new ModelAndView("preCloseEtdrDetailsDisplay", "EtdrMaster", outParams);
    }
    
    public ModelAndView preCloseEtdrAuthorizeHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("preCloseEtdrAuthorizeHandler -- begins");
        String errorView="errorPreCloseEtdrAuthorizeConfirm";
        Map inputParams = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        
        
        String view=null;
        String model= null;
        Map outParams=new HashMap();
        String referenceNo=request.getParameter("referenceNo");
        String preCloseReferenceNo=request.getParameter("preCloseReferenceNo");
        logger.info("referenceNo  ::::::  "+ referenceNo);
        logger.info("preCloseReferenceNo  ::::::  "+ preCloseReferenceNo);
        
        view="preCloseEtdrAuthorizeConfirm";
        model="EtdrMaster";
        
        inputParams.put("referenceNo", referenceNo);
        inputParams.put("userName", userProfile.getUserAlias());
        inputParams.put("bankCode", userProfile.getBankCode());
        
        //Added for transaction password validation -Start
		String  txnPwdStatus = (String)request.getAttribute("txnPwdStatus");
		logger.info("txnPwdStatus:::::::::::"+txnPwdStatus);
		if(txnPwdStatus != null && txnPwdStatus.equals("1")){
			
			logger.info("Invalid transaction pwd");
			session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
			return new ModelAndView("preCloseEtdrDetailsDisplay", UIConstant.TRANSACTION_MODEL, outParams);
			
		}
	    //Added for transaction password validation -End
		
		
		Map eTDRMap= (HashMap)session.getAttribute("EtdrMaster");
		EtdrMaster etdrMaster=(EtdrMaster)eTDRMap.get("etdrDetails");
		inputParams.put("fdAccountNo",etdrMaster.getFdAccountNo());
		inputParams.put("debitAccountNo",etdrMaster.getDebitAccountNo());
		inputParams.put("bankCode",userProfile.getBankCode());
		inputParams.put("debitBranchCode",etdrMaster.getDebitBranchCode());
		inputParams.put("isScheduled","false");
		inputParams.put("userName",userProfile.getUserAlias());
		inputParams.put("fdAmount", etdrMaster.getFdAmount());
		inputParams.put("referenceNo", etdrMaster.getReferenceNo());
		

		if(logger.isInfoEnabled()){
			logger.info("FD Account No -->"+inputParams.get("fdAccountNo"));
			logger.info("Debit Account No -->"+inputParams.get("debitAccountNo"));
			logger.info("Bank Code     -->"+inputParams.get("bankCode"));
			logger.info("Debit Branch Code -->"+inputParams.get("debitBranchCode"));
			logger.info("isScheduled   -->"+inputParams.get("isScheduled"));
			logger.info("user Name 	   -->"+inputParams.get("userName"));
			logger.info("FdAmount 	   -->"+inputParams.get("fdAmount"));
			logger.info("referenceNo   -->"+inputParams.get("referenceNo"));
		}
		Map outParam = new HashMap();
		String viewName="";
		
		SBIApplicationResponse res=new SBIApplicationResponse();
		
		//outParam = fixedDepositPreClosureConfirmService.execute(inputParams);
	
		outParams = preCloseEtdrAuthorizeService.execute(inputParams);
        
        outParams.put(UIConstant.ERROR_VIEW, errorView);
        
        logger.info("preCloseEtdrAuthorizeHandler -- ends");
        return new ModelAndView(view, UIConstant.TRANSACTION_MODEL, outParams);
    }
    
    public ModelAndView preCloseEtdrCancelHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("preCloseEtdrCancelHandler -- begins");
        String errorView="errorPreCloseEtdrCancelSuccess";
        Map inputParams = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        String userName = userProfile.getUserAlias();
        
        String view="preCloseEtdrCancelSuccess";
        Map outParams=new HashMap();
        String referenceNo=request.getParameter("referenceNo");
        String fdType=request.getParameter("fdType");
        String preCloseReferenceNo=request.getParameter("preCloseReferenceNo");
        logger.info("referenceNo  ::::::  "+ referenceNo);
        logger.info("preCloseReferenceNo  ::::::  "+ preCloseReferenceNo);
        inputParams.put("referenceNo", referenceNo);
        inputParams.put("userName", userName);
        
        outParams = preCloseEtdrCancelService.execute(inputParams);
        outParams.put("preCloseReferenceNo", preCloseReferenceNo);
        outParams.put("fdType", fdType);
        outParams.put(UIConstant.ERROR_VIEW, errorView);
        
        logger.info("preCloseEtdrCancelHandler -- ends");
	   return new ModelAndView(view, "outParams", outParams);
    } 
    
    public void setEtdrDisplayService(BaseService etdrDisplayService) {
		this.etdrDisplayService = etdrDisplayService;
	}
    
	public void setEtdrDetailsDisplayService(BaseService etdrDetailsDisplayService) {
		this.etdrDetailsDisplayService = etdrDetailsDisplayService;
	}
	
	public void setEtdrAuthorizeService(BaseService etdrAuthorizeService) {
		this.etdrAuthorizeService = etdrAuthorizeService;
	}

	public BaseService getEtdrCancelService() {
		return etdrCancelService;
	}

	public void setEtdrCancelService(BaseService etdrCancelService) {
		this.etdrCancelService = etdrCancelService;
	}

	public void setPreCloseEtdrDisplayService(BaseService preCloseEtdrDisplayService) {
		this.preCloseEtdrDisplayService = preCloseEtdrDisplayService;
	}

	public void setPreCloseEtdrDetailsDisplayService(
			BaseService preCloseEtdrDetailsDisplayService) {
		this.preCloseEtdrDetailsDisplayService = preCloseEtdrDetailsDisplayService;
	}

	public void setPreCloseEtdrAuthorizeService(
			BaseService preCloseEtdrAuthorizeService) {
		this.preCloseEtdrAuthorizeService = preCloseEtdrAuthorizeService;
	}

	public void setPreCloseEtdrCancelService(BaseService preCloseEtdrCancelService) {
		this.preCloseEtdrCancelService = preCloseEtdrCancelService;
	}
	
	
} 
