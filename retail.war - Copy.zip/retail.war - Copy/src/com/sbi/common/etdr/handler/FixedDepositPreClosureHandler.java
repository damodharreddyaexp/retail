/* 
 * FixedDepositPreClosureHandler.java 
 * Created on october 25, 2010
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//october 25, 2010 jyothipuram - Initial Creation
package com.sbi.common.etdr.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.Account;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;


public class FixedDepositPreClosureHandler  extends MultiActionController {

	private Logger logger =Logger.getLogger(getClass());

	private BaseService fixedDepositPreClosureInitialService;
	private BaseService fixedDepositPreClosureInterimService;
	

	private BaseService fixedDepositPreClosureConfirmService;
	private BaseService fixedDepositInitialService;
	private UserSessionCache userSessionCache;

	public ModelAndView preClosureInitialdebitHandler(HttpServletRequest request, HttpServletResponse response) 
	{
		
		logger.info("preClosureInitialdebitHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(UIConstant.USER);
		String[] productType = { UIConstant.ACCOUNT_TYPE1, UIConstant.ACCOUNT_TYPE2};
		
		session.removeAttribute("fixedDepositModel");
		
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());
		inParam.put("transactionType", "ETDR");
		inParam.put(UIConstant.PRODUCT_TYPE, productType);
		
		outParam = fixedDepositInitialService.execute(inParam);
		
		logger.info("preClosureInitialdebitHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixedDepositInitialdebitview", UIConstant.ACCOUNT_MODEL, outParam);

	}

	public ModelAndView preClosureInitialfdHandler(HttpServletRequest request, HttpServletResponse response) {
		logger.info("preClosureInitialfdHandler - Starts");

		User user = (User) request.getSession().getAttribute(UIConstant.USER);
		String debit_account_no=request.getParameter(UIConstant.DEBIT_ACCOUNT_NO);
		logger.info("debit acc no  in preClosureInitialHandler is :"+debit_account_no);

		Map inParam = new HashMap();
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());
		inParam.put("corporateId", (String) user.getCorporateId());
		inParam.put("transactionType","ETDR");
		inParam.put(UIConstant.DEBIT_ACCOUNT_NO,debit_account_no);

		Map outParam = new HashMap();	
		
		
		outParam=fixedDepositPreClosureInitialService.execute(inParam);

		logger.info("preClosureInitialfdHandler - Ends");

		return new ModelAndView("fixedDepositPreCloserfdview", UIConstant.ACCOUNT_MODEL, outParam);
	}


	public ModelAndView preClosureInterimHandler(HttpServletRequest request, HttpServletResponse response)	{
		logger.info("preClosureInterimHandler(..) Starts Here");

		User user = (User) request.getSession().getAttribute(UIConstant.USER);
		
		String transactionPwd= request.getParameter("transactionPwd");
		Map inParam = new HashMap();
		inParam.put("fdAccountNo", request.getParameter(UIConstant.FIXED_DEPOSIT_ACCOUNT_NO));
		inParam.put("bankCode", (String) user.getBankCode());
		inParam.put("userName",(String)user.getUserAlias());
		inParam.put("transactionPwd",transactionPwd);
		logger.info("user name in FixedDepositPreClosureHandler - preClosureInterimHandler"+user.getUserAlias());
		Map outParam = new HashMap();		
		outParam=fixedDepositPreClosureInterimService.execute(inParam);

		outParam.put("isScheduled",request.getParameter("isScheduled"));
		HttpSession session = request.getSession();
		session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
		logger.info("Refresh flag set in interim handler :" +session.getAttribute(UIConstant.REFRESH_FLAG));
		
		for(Object currKey:outParam.keySet())
        {
			logger.info("key  in interim handler:"+currKey);
			
        	Object currValue=outParam.get(currKey);
        	logger.info("value in interim handler:" +currValue);
        	logger.info("key ::::"+currKey+",value ::::"+currValue);
        	session.setAttribute((String)currKey, currValue);
        }
	
		if(logger.isInfoEnabled()){
			logger.info("FD Account No -->"+inParam.get("fdAccountNo"));			
			logger.info("Bank Code     -->"+inParam.get("bankCode"));			
			
		}

		logger.info("preClosureInterimHandler(..) Ends Here");

		return new ModelAndView("fixedDepositPreCloserInterimalview", "preclosureModel", outParam);
	}
	

	
	/**
	 * This method handles the FD preclosure function.
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	public ModelAndView preClosureFixedDepositConfirmHandler(HttpServletRequest request, HttpServletResponse response) {
		logger.info("preClosureFixedDepositConfirmHandler(..) Starts Here");

		User user = (User) request.getSession().getAttribute(UIConstant.USER);

		Map inParam = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession();
		
		FixedDepositModel fixedDepositModel= (FixedDepositModel)session.getAttribute("preClosureDetails");
		inParam.put("fdAccountNo",fixedDepositModel.getCreditAccountNo());
		// Modified by Sai for e-TDR/e-STDR change
		logger.info("fd account no is:"+inParam.get("fdAccountNo"));
		//inParam.put("fdAccountNo",request.getParameter("creditAccountNo"));
		inParam.put("debitAccountNo",fixedDepositModel.getDebitAccountNo());
		logger.info("debit account in confirm handler:"+inParam.get("debitAccountNo"));
		inParam.put("bankCode",fixedDepositModel.getBankCode());
		logger.info("bank code is:"+inParam.get("bankCode"));
		inParam.put("debitBranchCode",fixedDepositModel.getDebitBranchCode());
		logger.info("debitBranchCode code is:"+inParam.get("debitBranchCode"));
		/* IsScheduled commented by Sai since it is not needed for e-TDR/e-STDR change currently
		  false will be added by default */ 
		 
		//inParam.put("isScheduled",request.getParameter("isScheduled")); 
		inParam.put("isScheduled","false");
		inParam.put("userName",user.getUserAlias());
		inParam.put("remarks", request.getParameter("remarks"));
		inParam.put("fdAmount", request.getParameter("fdAmount"));

		if(logger.isInfoEnabled()){
			logger.info("FD Account No -->"+inParam.get("fdAccountNo"));
			logger.info("CR Account No -->"+inParam.get("creditAccountNo"));
			logger.info("Bank Code     -->"+inParam.get("bankCode"));
			logger.info("Debit Branch Code -->"+inParam.get("debitBranchCode"));
			logger.info("isScheduled   -->"+inParam.get("isScheduled"));
			logger.info("user Name 	   -->"+inParam.get("userName"));
			logger.info("Remarks 	   -->"+inParam.get("remarks"));
			logger.info("FdAmount 	   -->"+inParam.get("fdAmount"));
		}
		Map outParam = new HashMap();
		String viewName="";
		/* String userName = (String)user.getUserAlias();  
	    Object obj = userSessionCache.getData(userName + DAOConstants.USER_ACCOUNTS);
        if (logger.isDebugEnabled()) {
            logger.info("Acounts for " + userName + " : " + obj);
        }
    

        List accList = new ArrayList();
        if (obj != null) {
            accList = (List) obj;
            if (logger.isDebugEnabled()) {
                logger.info("List of Acounts for " + userName + " : " + accList.size());
            }
          } */
          
          // txn pwd New code validation begins
		String  txnPwdStatus = (String)request.getAttribute("txnPwdStatus");
		logger.info("txnPwdStatus:::::::::::"+txnPwdStatus);
		if(txnPwdStatus != null && txnPwdStatus.equals("1"))
		{
			logger.info("transaction password is invalid");
            session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
         	return new ModelAndView("fixedDepositPreCloserInterimalview", "outParam", outParam);
		}
		
		
        
		SBIApplicationResponse res=new SBIApplicationResponse();
		
					
			outParam = fixedDepositPreClosureConfirmService.execute(inParam);
	
			logger.info("Isscheduled is:"+ (String)outParam.get("isScheduled"));
			outParam.put("errorView","errorfdPreclosureConfirm");
		
		logger.info("preClosureFixedDepositConfirmHandler(..) Ends Here"); 
		return new ModelAndView("fdPreclosurefinal","outParam", outParam);
	}
	
	
	private boolean validateAccount(List debitAccList, String debitAccountNo) {
		// TODO Auto-generated method stub
		   boolean validAccount=false;
		   if(debitAccList!=null && debitAccList.size()>0 && debitAccountNo!=null && !debitAccountNo.trim().equals("")){
			   for(int i=0;i<debitAccList.size();i++){
				   Account acc = (Account) debitAccList.get(i);
				   logger.info("Account no is"+ acc.getAccountNo());
				   logger.info("debit account no is"+debitAccountNo);
				   logger.info("access level is"+acc.getAccessLevel());
				   // AccessLevel 5,6& 7 added by sai for e-TDR/e-STDR CR
				   if(acc.getAccountNo().equals(debitAccountNo) &&  (acc.getAccessLevel() == 6
							  || acc.getAccessLevel() == 7 || acc.getAccessLevel()==5))
				   {
					   validAccount=true;
					   break;
				   }
					   
			   }
			   
		   }
		return validAccount; 
}
	
	
	
	public void setFixedDepositPreClosureInitialService(
			BaseService fixedDepositPreClosureInitialService) {
		this.fixedDepositPreClosureInitialService = fixedDepositPreClosureInitialService;
	}

	public void setFixedDepositPreClosureInterimService(
			BaseService fixedDepositPreClosureInterimService) {
		this.fixedDepositPreClosureInterimService = fixedDepositPreClosureInterimService;
	}


	public void setFixedDepositPreClosureConfirmService(
			BaseService fixedDepositPreClosureConfirmService) {
		this.fixedDepositPreClosureConfirmService = fixedDepositPreClosureConfirmService;
	}

	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}
	
	public BaseService getFixedDepositInitialService() {
		return fixedDepositInitialService;
	}

	public void setFixedDepositInitialService(BaseService fixedDepositInitialService) {
		this.fixedDepositInitialService = fixedDepositInitialService;
	} 

}
