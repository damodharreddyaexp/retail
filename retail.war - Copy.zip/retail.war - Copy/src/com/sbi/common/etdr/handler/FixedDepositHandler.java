package com.sbi.common.etdr.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.Account;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.etdr.utils.EtdrChallanPdf;


public class FixedDepositHandler extends MultiActionController{
	
	private Logger logger = Logger.getLogger(getClass());
	
	private BaseService fixedDepositInitialService;
	
	private BaseService fixedDepositInterimService;
	
	private BaseService fixedDepositPaymentConfirmService;
	
	private BaseService fixedDepositChallanService;
	
	private UserSessionCache userSessionCache; // added for anti tampering protection
	
	private EtdrChallanPdf etdrChallanPdf;
	
	private String pdfSaveUrl;
	
	private String imageUrl;
	
	
	public ModelAndView fixedDepositInitialHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		logger.info("fixedDepositInitialHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		HttpSession session = request.getSession();
		UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
		
		String[] productType = { UIConstant.ACCOUNT_TYPE1, UIConstant.ACCOUNT_TYPE2, UIConstant.ACCOUNT_TYPE3,
				UIConstant.ACCOUNT_TYPE4 };
		
		session.removeAttribute("fixedDepositModel");
		
		inParam.put(UIConstant.USER_NAME, userProfile.getUserAlias());
		inParam.put("bankCode", (String) userProfile.getBankCode());
		inParam.put("transactionType", "ETDR");
		inParam.put(UIConstant.PRODUCT_TYPE, productType);
		
		String txnPwd=null;
        txnPwd=userProfile.getTxnPassword();
        //logger.info("TxnPassword:  "+ txnPwd );
        if (txnPwd == null || txnPwd.equals("")) {
	       	getServletContext().getRequestDispatcher("/changetxnpassword.htm").forward(request,response);
			return null;
        }
        
		outParam = fixedDepositInitialService.execute(inParam);
		
		logger.info("fixedDepositInitialHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixedDepositInitialview", UIConstant.ACCOUNT_MODEL, outParam);
	}
	
	
	
	public ModelAndView fixedDepositInterimHandler(HttpServletRequest request,HttpServletResponse response){
		logger.info("fixedDepositInterimHandler(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		Map<String, Object> inparam=new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession(false);
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		inparam.put(UIConstant.USER_NAME,user.getUserAlias());
		inparam.put("corporateId",user.getCorporateId());
		inparam.put("bankCode",(String)user.getBankCode());
		inparam.put("transactionType","ETDR");
		String creditAmountTransfer = request.getParameter(UIConstant.CREDIT_AMOUNT_TRANSFER);        
		inparam.put("debitAccountNo", request.getParameter(UIConstant.DEBIT_ACCOUNT_NO));
		inparam.put("debitBranchCode", request.getParameter(UIConstant.DEBIT_BRANCH_CODE));
		inparam.put("debitAmount", request.getParameter(UIConstant.AMOUNT_TRANSFER));
		inparam.put("amountTransfer", request.getParameter(UIConstant.AMOUNT_TRANSFER));
		inparam.put("transactionName", request.getParameter(UIConstant.TRANSACTION_NAME));
		inparam.put("debitAccountType", request.getParameter(UIConstant.DEBIT_ACCOUNT_TYPE));
		inparam.put("debitProductCode",  request.getParameter(UIConstant.DEBIT_PRODUCT_CODE));
		inparam.put("days", request.getParameter("days"));
		inparam.put("year", request.getParameter("year"));
		inparam.put("month", request.getParameter("month"));
		inparam.put("date", request.getParameter("date"));
		logger.info("tendute date---->"+request.getParameter("date"));
		logger.info("tendute Days---->"+request.getParameter("days"));
		logger.info("tendute month---->"+request.getParameter("month"));
		logger.info("tendute year---->"+request.getParameter("year"));
		inparam.put("tenureType", request.getParameter("tenure"));
		inparam.put("intPayout", request.getParameter("intpayout"));
		inparam.put("cumulativeType", request.getParameter("cumulativetype"));
		inparam.put("corporateId", user.getCorporateId());
		String contextPath = request.getContextPath().substring(1);
		if("mretail".equals(contextPath)){
		inparam.put("channelType","M_INB");
		}else if("retail".equals(contextPath)){
			inparam.put("channelType","INB");
		}
		
		/*Added by Srinivas For Floating Rate CR Starts Here*/
		inparam.put("FixedorFloattype", request.getParameter("FixedorFloattype"));
		inparam.put("floatYear", request.getParameter("floatYear"));
		/*Added by Srinivas For Floating Rate CR Ends Here*/
		
		/*Added For Maturity Mandates Instructions CR Starts Here*/
		
			inparam.put("autoRenewType",request.getParameter("autoRenewType"));
			inparam.put("autoRenewDays", request.getParameter("renewaldays"));
			inparam.put("autoRenewYear", request.getParameter("renewalyear"));
			inparam.put("autoRenewMonth", request.getParameter("renewalmonth"));
			inparam.put("autoRenewDate", request.getParameter("renewaldate"));
			inparam.put("autoRenewTenureType", request.getParameter("renewaltenure"));		
			inparam.put("autoRenewIntPayout", request.getParameter("changedIntPayout"));
		/*Added For Maturity Mandates Instructions CR ends Here*/	

			String sbhDouble = "";

			if(!"2".equals(user.getBankCode())){
			   inparam.put("sbhdouble",sbhDouble);
			}

			/*Added For SBH Double for State Bank of Hyderabad - DEV - 262 Starts Here*/
			if("2".equals(user.getBankCode())){
				sbhDouble = (String)request.getParameter("isSbhDouble");
				logger.info("isSbhDouble -->"+sbhDouble);
				inparam.put("sbhdouble",sbhDouble);
				if(sbhDouble!=null && "Yes".equalsIgnoreCase(sbhDouble)) {				
					inparam.put("cumulativeType", "STDR");
					inparam.put("autoRenewType", "C");		
					inparam.put("tenureType","daymode");				
				}
			}
			/*Added For SBH Double for State Bank of Hyderabad - DEV - 262 Ends Here*/
		if(logger.isInfoEnabled()){
			logger.info("<---- Auto Renew Type in request--->"+request.getParameter("autoRenewType"));
			}
		
		//senior citizen start
		String seniorCitizen = request.getParameter("isSeniorCitizen");
		inparam.put("isSeniorCitizen",seniorCitizen);
        //senior citizen end
		
		/* DEV -323 Maturity Date Option Starts Here */
		if("maturitymode".equals((String)inparam.get("tenureType"))) {
			inparam.put("dbDate", request.getParameter("dbDate"));
			inparam.put("dbMonth", request.getParameter("dbMonth"));
			inparam.put("dbYear", request.getParameter("dbYear"));
			inparam.put("maturityDate",((String)request.getParameter("maturityDate")));
			inparam.put("days", String.valueOf(tenureCalc(getSystemDate(),((String)inparam.get("maturityDate")))));
			logger.info("Maturity TenureDays Opted:::"+inparam.get("days"));
		}

		/* DEV  - 323 Maturity Date Option Ends Here */
		
		//Added for Tampering protection
		String userName = (String)user.getUserAlias();  
		Object obj = userSessionCache.getData(userName + DAOConstants.USER_ACCOUNTS);
        if (logger.isDebugEnabled()) {
            logger.debug("Acounts for " + userName + " : " + obj);
        }

        List accList = new ArrayList();
        if (obj != null) {
            accList = (List) obj;
            if (logger.isDebugEnabled()) {
                logger.debug("List of Acounts for " + userName + " : " + accList.size());
            }
          }
        String accountNo = request.getParameter(UIConstant.DEBIT_ACCOUNT_NO); 
        SBIApplicationResponse res=new SBIApplicationResponse();
        if(validateAccount(accList,accountNo)) {
			logger.info("inparam   "+inparam);
			outParam=fixedDepositInterimService.execute(inparam);
			session.setAttribute("fixedDepositModel",outParam.get("fixedDepositModel"));
			
			session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
			logger.info("fdmodel in session payment confirm::"+(FixedDepositModel) session.getAttribute("fixedDepositModel"));
			logger.info("outParam   "+outParam);
			logger.info("fixedDepositInterimHandler(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
        }else{
	    	  logger.info("phishing:::::::");
	    	  res.setErrorStatus("failure");
	    	  res.setErrorCode("phis100");
	    	  res.setErrorMessage("There are some serious irregularities in the transaction");
	    	  outParam.put(UIConstant.APPLICATION_RESPONSE,res);  
	    	  return new ModelAndView("etdrErrorView", "errorModel",outParam);
	      }
        
       
        session.setAttribute(UIConstant.TRANSACTION_MODEL, outParam);
        
		return new ModelAndView("fixedDepositInterimview",UIConstant.TRANSACTION_MODEL,outParam);
	}
	
	private boolean validateAccount(List debitAccList, String debitAccountNo) {
		// TODO Auto-generated method stub
		   boolean validAccount=false;
		   if(debitAccList!=null && debitAccList.size()>0 && debitAccountNo!=null && !debitAccountNo.trim().equals("")){
			   for(int i=0;i<debitAccList.size();i++){
				   Account acc = (Account) debitAccList.get(i);
				   if(acc.getAccountNo().equals(debitAccountNo) &&  (acc.getAccessLevel() == 6 || acc.getAccessLevel() == 7))
				   {
					   validAccount=true;
					   break;
				   }
					   
			   }
			   
		   }
		return validAccount;
	}
	
	public ModelAndView fdPaymentConfirmHandler(HttpServletRequest request, HttpServletResponse response) {
		logger.debug("paymentConfirmHandler(HttpServletRequest request, HttpServletResponse response)- begin");
		Map<String,Object> inParam = new HashMap<String,Object>();
		Map<String,Object> fdOutParam = new HashMap<String,Object>();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
		logger.info("small Flag::::"+corporateProfile.getSmallFlag());
		inParam.put("smallFlag", corporateProfile.getSmallFlag());	
					
		String view = "fdPaymentConfirmView";
		String errorView = "";
		String bankCode = user.getBankCode();
		String userName = user.getUserAlias();
		inParam.put("bankCode", bankCode);
		FixedDepositModel fixedDepositModel = (FixedDepositModel) session.getAttribute("fixedDepositModel");
		fixedDepositModel.setUserName(userName);
		fixedDepositModel.setSmallFlag(corporateProfile.getSmallFlag());
		fixedDepositModel.setTypeOfModule("corporate");
		String nomineeReqd=request.getParameter("nomineeReqd");
		logger.info("nomineeReqd::::"+nomineeReqd);
		
		
		//Added for transaction password validation -Start
		String  txnPwdStatus = (String)request.getAttribute("txnPwdStatus");
		logger.info("txnPwdStatus:::::::::::"+txnPwdStatus);
		if(txnPwdStatus != null && txnPwdStatus.equals("1")){
			
			logger.info("Invalid transaction pwd");
			session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
			return new ModelAndView("fixedDepositInterimview", UIConstant.TRANSACTION_MODEL, fdOutParam);
			
		}
	    //Added for transaction password validation -End		
		
		inParam.put("fixedDepositModel", fixedDepositModel);
		logger.info("FixedDepositModel ->"+inParam.get("fixedDepositModel"));
		fdOutParam = fixedDepositPaymentConfirmService.execute(inParam);
		SBIApplicationResponse appr = (SBIApplicationResponse)fdOutParam.get(UIConstant.APPLICATION_RESPONSE);
		
		if (appr != null && appr.getErrorStatus().equalsIgnoreCase(UIConstant.SUCCESS)){
			fixedDepositModel =  (FixedDepositModel) fdOutParam.get("fixedDepositModel");
			session.setAttribute("fixedDepositModel", fixedDepositModel);
		}
		
		fdOutParam.put("errorView","errorfdPaymentConfirm");
			
		fdOutParam.put(UIConstant.APPLICATION_RESPONSE,fdOutParam.get(UIConstant.APPLICATION_RESPONSE));
		logger.info("paymentConfirmHandler(HttpServletRequest request, HttpServletResponse response)- end ::"+view);
		return new ModelAndView(view, UIConstant.TRANSACTION_MODEL, fdOutParam);
	}
	
	public ModelAndView fixedDepositChallanHandler(HttpServletRequest request, HttpServletResponse response) 
	{
		logger.info("fixedDepositChallanHandler begins");
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		FixedDepositModel fdAcc=new FixedDepositModel();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		String fdAccountNo =(String)request.getParameter("fdAccountNo");
		String bankCode=(String)user.getBankCode();
		String userName=(String)user.getName();
		String etdrchallanflag=(String)request.getParameter("etdrchallanflag");
		inParam.put("fdAccountNo",fdAccountNo);
		inParam.put("bankCode",bankCode);
		inParam.put("userName",userName);
		inParam.put("etdrchallanflag",etdrchallanflag);
		
		logger.info("fdmodel in session ::"+(FixedDepositModel) session.getAttribute("fixedDepositModel"));
		if(etdrchallanflag.equalsIgnoreCase("fdcreationchallan"))
		{
			fdAcc=(FixedDepositModel) session.getAttribute("fixedDepositModel");
			
		}
		inParam.put("fdAcc", fdAcc);
		outParam = fixedDepositChallanService.execute(inParam);
		
		session.setAttribute("pdfChallanDetails", outParam);//added on 28.01.10 for ETDR PDF CHALLAN
		
		logger.info("outParam from handler :-"+outParam);
		
		logger.info("fixedDepositChallanHandler begins");
		return new ModelAndView("etdrchallantilesview", "challanModel", outParam);
		
		
	}

	private int tenureCalc(String currentDate, String endDate) {
		int tenuredays = 0;
		try {
			DateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date creditPeriod = simpleDateFormat.parse(endDate);
			Date sysdate = simpleDateFormat.parse(currentDate);			
			tenuredays = (int) ((creditPeriod.getTime() - sysdate.getTime()) / (24 * 60 * 60 * 1000));
			logger.info("Maturity Tenure Days -->"+tenuredays);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tenuredays;
	}

	private String getSystemDate(){		
		return new SimpleDateFormat("dd/MM/yyyy").format(new GregorianCalendar().getTime());		
	} 
	
	public ModelAndView fixedDepositPdfChallanHandler(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		HttpSession session = request.getSession(false);
		String fileType=request.getParameter("fileType");
		Map outparams = new HashMap();
		User user = (User) session.getAttribute(UIConstant.USER);

		SBIApplicationResponse sbiApplicationResponse = new SBIApplicationResponse();
		sbiApplicationResponse.setErrorStatus("failure");
		Map PdfOutParam = (Map) session.getAttribute("pdfChallanDetails");
		String pdfFileName=PdfOutParam.get("inbRefNo")+"_"+etdrChallanPdf.getTimeStamp("ddMMyyyyhhmmss")+".pdf";
            try
            {
	            //pdfSaveUrl = "D:/jboss-4.0.5.GA/server/default/deploy/sbijava.war/pdf/";//to remove
	            String pdfWithoutWaterMarkPath = pdfSaveUrl+pdfFileName;
	            logger.info("pdfWithoutWaterMarkPath ="+pdfWithoutWaterMarkPath);
	            etdrChallanPdf.EtdrChallanConverter(PdfOutParam,new FileOutputStream(new File(pdfWithoutWaterMarkPath)));
	            
				 	response.setContentType("application/OCTET-STREAM");
	            	/**TODO
	            	uncomment for pdf watermark.
					InputStream in = new FileInputStream(new File(pdfWaterMarkPath));
					*/
	            	InputStream in = new FileInputStream(new File(pdfWithoutWaterMarkPath));
					byte [] chars = new byte[in.available()];
			    	in.read(chars);
			    	in.close();
			    	response.setHeader("Content-disposition","attachment;filename="+pdfFileName);
			    	logger.info("response.getOutputStream()::"+response.getOutputStream());
			    	OutputStream outputStream = response.getOutputStream();
			    	outputStream.write(chars);
			    	outputStream.flush();
			    	outputStream.close();
			    	
		}catch(SBIApplicationException sbi){
			logger.error("SBIApplicationException occured:*******"+sbi.getMessage());
			sbiApplicationResponse.setErrorCode("FD003");
			outparams.put("applicationResponse", sbiApplicationResponse );
			return new ModelAndView("etdrchallantilesview", "errorModel", outparams);
		}
	    catch(Exception pdfExp){
	    	logger.error("SBIApplicationException occured:*******"+pdfExp.getMessage());
			sbiApplicationResponse.setErrorCode("FD003");
			outparams.put("applicationResponse", sbiApplicationResponse );
			return new ModelAndView("etdrchallantilesview", "errorModel", outparams);
		}
		session.removeAttribute("outParam");
		logger.info("consignReportDownload(request,response) method endsss");
		return null;
	}
	
	public void setFixedDepositPaymentConfirmService(BaseService fixedDepositPaymentConfirmService)
	{
		this.fixedDepositPaymentConfirmService = fixedDepositPaymentConfirmService;
	}
	
	public void setFixedDepositInitialService(BaseService fixedDepositInitialService)
	{
		this.fixedDepositInitialService = fixedDepositInitialService;
	}
	
	public void setFixedDepositInterimService(BaseService fixedDepositInterimService)
	{
		this.fixedDepositInterimService = fixedDepositInterimService;
	}
	
	public void setUserSessionCache(UserSessionCache userSessionCache) { //Added for anti tampering protection
		this.userSessionCache = userSessionCache;
	}
		
	public void setFixedDepositChallanService(BaseService fixedDepositChallanService) {
		this.fixedDepositChallanService = fixedDepositChallanService;
	}

	public void setEtdrChallanPdf(EtdrChallanPdf etdrChallanPdf) {
		this.etdrChallanPdf = etdrChallanPdf;
	}

	public void setPdfSaveUrl(String pdfSaveUrl) {
		this.pdfSaveUrl = pdfSaveUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	
}
