package com.sbi.common.etdr.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.etdr.model.FixedDepositModel;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.Account;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class FixedDepositStatusEnquiryHandler extends  MultiActionController
{

	
	private Logger logger =Logger.getLogger(getClass());
	private BaseService fixedDepositInitialService;
	private BaseService fixedDepositStatusEnquiryService;
	
	
	

	public ModelAndView StatusEnquirydebitHandler(HttpServletRequest request, HttpServletResponse response) 
	{
		
		logger.info("EnquirystatusdebitHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(UIConstant.USER);
		String[] productType = { UIConstant.ACCOUNT_TYPE1, UIConstant.ACCOUNT_TYPE2};
		
		session.removeAttribute("fixedDepositModel");
		
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());
		inParam.put("branchCode", (String) user.getBranchCode());
		inParam.put("transactionType", "ETDR");
		inParam.put(UIConstant.PRODUCT_TYPE, productType);
		
		outParam = fixedDepositInitialService.execute(inParam);
		
		logger.info("EnquirystatusdebitHandler(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixedDepositstatusenquiry", UIConstant.ACCOUNT_MODEL, outParam);

	}

	
	public ModelAndView StatusEnquiryfdHandler(HttpServletRequest request, HttpServletResponse response) {
		
		
		
		logger.info("EnquirystatusfdHandler - Starts");
		
		
	
		Map inParam = new HashMap();
			
	
		User user = (User) request.getSession().getAttribute(UIConstant.USER);
		String debit_account_no=request.getParameter(UIConstant.DEBIT_ACCOUNT_NO);
		String branchCode=request.getParameter(UIConstant.DEBIT_BRANCH_CODE);
		logger.info("debit acc no  in StatusEnquiryfdHandler is :"+debit_account_no);


		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());	
		inParam.put("branchCode", branchCode);
		inParam.put("transactionType","ETDR");
		inParam.put(UIConstant.DEBIT_ACCOUNT_NO,debit_account_no);
		inParam.put("reqType","requestStatus");
		
		Map outParam = new HashMap();	
		
		
		outParam=fixedDepositStatusEnquiryService.execute(inParam);

		outParam.put("reqType","requestStatus");
		logger.info("preClosureInitialfdHandler - Ends");
		
		return new ModelAndView("fixedDepositstatusenquiryfinal", UIConstant.ACCOUNT_MODEL, outParam);
	}
	
	public ModelAndView getFDAccountInfo(HttpServletRequest request, HttpServletResponse response) {
		
		logger.info("getFDAccountInfo(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(UIConstant.USER);
		String[] productType = { UIConstant.ACCOUNT_TYPE1, UIConstant.ACCOUNT_TYPE2};
		
		session.removeAttribute("fixedDepositModel");
		
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());
		inParam.put("branchCode", (String) user.getBranchCode());
		inParam.put("transactionType", "ETDR");
		inParam.put(UIConstant.PRODUCT_TYPE, productType);
		
		outParam = fixedDepositInitialService.execute(inParam);
		
		logger.info("getFDAccountInfo(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixeddepositaccountinfo", UIConstant.ACCOUNT_MODEL, outParam);

	}

	
	public ModelAndView getFDAccountInterimInfo(HttpServletRequest request, HttpServletResponse response) {
		
		logger.info("getFDAccountInterimInfo(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		
		User user = (User) request.getSession().getAttribute(UIConstant.USER);
		String debit_account_no=request.getParameter(UIConstant.DEBIT_ACCOUNT_NO);
		logger.info("debit acc no:"+debit_account_no);

		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		inParam.put("bankCode", (String) user.getBankCode());	
		inParam.put("branchCode", (String) user.getBranchCode());
		inParam.put("transactionType","ETDR");
		inParam.put(UIConstant.DEBIT_ACCOUNT_NO,debit_account_no);
		inParam.put("reqType","accountInfo");
		inParam.put("corporateId", user.getCorporateId());
		
		outParam=fixedDepositStatusEnquiryService.execute(inParam);

		outParam.put("reqType","accountInfo");
		logger.info("getFDAccountInterimInfo(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixeddepositaccountinteriminfo", UIConstant.ACCOUNT_MODEL, outParam);
	}
	
	public ModelAndView getFDAccountBalanceDtls(HttpServletRequest request, HttpServletResponse response) {
		
		logger.info("getFDAccountBalanceDtls(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam = new HashMap();
		
		User user = (User) request.getSession().getAttribute(UIConstant.USER);
		String selFdAccountNo=request.getParameter("selFdAccountNo");
		logger.info("FD Account No :"+selFdAccountNo);

		inParam.put("bankCode", (String) user.getBankCode());	
		inParam.put("selFdAccountNo",selFdAccountNo);
		inParam.put("reqType","accountBalanceDtls");
		
		outParam=fixedDepositStatusEnquiryService.execute(inParam);

		outParam.put("reqType","accountBalanceDtls");
		logger.info("getFDAccountBalanceDtls(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView("fixeddepositbalancedtls", "outParam", outParam);
		
	}
	public BaseService getFixedDepositInitialService() {
		return fixedDepositInitialService;
	}

	public void setFixedDepositInitialService(BaseService fixedDepositInitialService) {
		this.fixedDepositInitialService = fixedDepositInitialService;
	}
	
	public BaseService getFixedDepositStatusEnquiryService() {
		return fixedDepositStatusEnquiryService;
	}


	public void setFixedDepositStatusEnquiryService(
			BaseService fixedDepositStatusEnquiryService) {
		this.fixedDepositStatusEnquiryService = fixedDepositStatusEnquiryService;
	}
}
