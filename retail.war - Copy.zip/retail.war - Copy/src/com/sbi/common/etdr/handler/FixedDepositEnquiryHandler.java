package com.sbi.common.etdr.handler;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;

public class FixedDepositEnquiryHandler extends MultiActionController{
	private Logger logger = Logger.getLogger(FixedDepositEnquiryHandler.class);

	private BaseService fixedDepositInitialService;
	private BaseService fixedDepositEnquiryService;

	public ModelAndView fixedDepositEnquiryHandler(HttpServletRequest request, HttpServletResponse response){
		logger.info("fixedDepositEnquiryHandler(..) Starts Here");

		String[] productType = { "A1", "A2", "A3", "A4" };
		User user = (User)request.getSession().getAttribute("user");

		Map inParam = new HashMap();

		inParam.put("userName", user.getUserAlias());
		inParam.put("bankCode", user.getBankCode());
		inParam.put("transactionType", "ETDR");
		inParam.put("productType", productType);

		Map outParam = new HashMap();
		outParam = fixedDepositInitialService.execute(inParam);

		logger.info("fixedDepositEnquiryHandler(..) Ends Here");

		return new ModelAndView("fixeddepositenquiry", "accountModel", outParam);
	}

	public ModelAndView fixedDepositEnquiryConfirmHandler(HttpServletRequest request, HttpServletResponse response) {
		logger.info("fixedDepositEnquiryConfirmHandler(...) Starts Here");

		User user = (User)request.getSession(false).getAttribute("user");

		Map inparam = new HashMap();

		//String creditAmountTransfer = request.getParameter("creditAmountTransfer");

		inparam.put("userName", user.getUserAlias());
		inparam.put("bankCode", user.getBankCode());
		inparam.put("transactionType", "ETDR");
		inparam.put("debitAccountNo", request.getParameter("debitAccountNo"));
		inparam.put("debitBranchCode", request.getParameter("debitBranchCode"));
		//inparam.put("debitAmount", request.getParameter("amountTransfer"));
		inparam.put("amountTransfer", request.getParameter("amountTransfer"));
		inparam.put("transactionName", request.getParameter("transactionName"));
		inparam.put("debitAccountType", request.getParameter("debitAccountType"));
		inparam.put("debitProductCode", request.getParameter("debitProductCode"));
		inparam.put("days", request.getParameter("days"));
		inparam.put("year", request.getParameter("year"));
		inparam.put("month", request.getParameter("month"));
		inparam.put("date", request.getParameter("date"));
		inparam.put("tenureType", request.getParameter("tenure"));
		inparam.put("intPayout", request.getParameter("intpayout"));
		inparam.put("cumulativeType", request.getParameter("cumulativetype"));
		inparam.put("FixedorFloattype", request.getParameter("FixedorFloattype"));
		inparam.put("floatYear", request.getParameter("floatYear"));
		//inparam.put("openingDate", request.getParameter("openingDate"));
		inparam.put("isSeniorCitizen",request.getParameter("isSeniorCitizen"));

		/* DEV -323 Maturity Date Option Starts Here */
		if("maturitymode".equals((String)inparam.get("tenureType"))) {
			inparam.put("dbDate", request.getParameter("dbDate"));
			inparam.put("dbMonth", request.getParameter("dbMonth"));
			inparam.put("dbYear", request.getParameter("dbYear"));
			inparam.put("maturityDate",((String)request.getParameter("maturityDate")));
			inparam.put("days", String.valueOf(tenureCalc(getSystemDate(),((String)inparam.get("maturityDate")))));
			logger.info("Maturity TenureDays Opted:::"+inparam.get("days"));
		}

		/* DEV  - 323 Maturity Date Option Ends Here */

		logger.info("inparam --> " + inparam);

		Map outParam = new HashMap();
		outParam = fixedDepositEnquiryService.execute(inparam);

		logger.info("the outparams given as result to handler --> " + outParam);

		logger.info("fixedDepositEnquiryConfirmHandler(...) Ends Here");

		return new ModelAndView("fixeddepositenquiryconfirm", "enquiryModel", outParam);
	}

	private int tenureCalc(String currentDate, String endDate) {
		int tenuredays = 0;
		try {
			DateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date creditPeriod = simpleDateFormat.parse(endDate);
			Date sysdate = simpleDateFormat.parse(currentDate);			
			tenuredays = (int) ((creditPeriod.getTime() - sysdate.getTime()) / (24 * 60 * 60 * 1000));
			logger.info("Maturity Tenure Days -->"+tenuredays);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tenuredays;
	}

	private String getSystemDate(){		
		return new SimpleDateFormat("dd/MM/yyyy").format(new GregorianCalendar().getTime());		
	}

	public void setFixedDepositInitialService(BaseService fixedDepositInitialService){
		this.fixedDepositInitialService = fixedDepositInitialService;
	}

	public void setFixedDepositEnquiryService(BaseService fixedDepositEnquiryService){
		this.fixedDepositEnquiryService = fixedDepositEnquiryService;
	}	  
}