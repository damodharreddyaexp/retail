package com.sbi.common.advisor;

import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.log4j.Logger;

/*
 * AroundAdvice.java
 * Created on Mar 8, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 8, 2006 MURUGAN K - Initial Creation
public class AroundAdvice implements MethodInterceptor {

    protected final Logger logger = Logger.getLogger(getClass());

    public Object invoke(MethodInvocation invocation) throws Throwable {
    	logger.info("invoke(MethodInvocation invocation) method begins");
    	if (logger.isInfoEnabled()) {
    				logger.debug("method invocation"+invocation);
    				
    			}
    	long startTime = System.currentTimeMillis();

        Method method = invocation.getMethod();
        Object aruguments[] = invocation.getArguments();
        String argumentString = "";
        String className = method.getDeclaringClass().getName();
        
       
        if (aruguments != null && aruguments.length > 0)
         {
            int size = aruguments.length;
            for (int i = 0; i < size; i++) {
                if(aruguments[i] != null)
                    argumentString = argumentString + aruguments[i].getClass().toString();
                
                if (i != size - 1)
                    argumentString = argumentString + ",";
            }
         }  
        Object output = invocation.proceed();
        long endTime = System.currentTimeMillis();
        logger.info( className + ":" + method.getName() + "(" + argumentString + ")" 
              + "|" + (endTime - startTime));
        logger.info("invoke(MethodInvocation invocation) method ends");
        return output;
    }

}
