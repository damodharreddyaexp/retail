/**  
 * @(#) SBIApplicationException.java
 */

package com.sbi.common.exception;

import java.util.HashMap;

import org.apache.log4j.Logger;

import wac.logger.ErrorDictionary;
import wac.logger.ErrorModel;
import wac.logger.WACLogger;

import com.sbi.common.utils.LoggingConstants;

public class SBIApplicationException extends RuntimeException {
    
    protected final static Logger logger = Logger.getLogger("com.sbi.exception.SBIApplicationException");   

    public String errorCode;

    public String errorDescription;
    
    private Exception exception;
    
    public SBIApplicationException(String errorCode){
        this.errorCode = errorCode;
    }
    public SBIApplicationException(Exception exception,String errorCode){
        this.errorCode = errorCode;
        this.exception = exception;
    }
    public String getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
    public static void throwException(String errorCode) throws SBIApplicationException{
        SBIApplicationException exception = new SBIApplicationException (errorCode);
        logger.error(LoggingConstants.EXCEPTION + exception.getMessage(),exception);
        throw exception;  
    }
    public static void throwException(String errorCode, Exception exceptionCaught) throws SBIApplicationException{
        SBIApplicationException exception = new SBIApplicationException(errorCode);
        logger.error(LoggingConstants.EXCEPTION + exceptionCaught.getMessage(),exceptionCaught);
        throw exception;
    }
    public static void throwException(Exception exception, String errorCode,Object[] params) throws SBIApplicationException{
        ErrorDictionary records = ErrorDictionary.getExpInstance();
        HashMap map=records.getInstance();
        ErrorModel bean=(ErrorModel)map.get(errorCode);
        SBIApplicationException exp = new SBIApplicationException(errorCode);
        if(bean!=null){
            bean.setParametervalues(params);
	        //if params in bean and size of params match : log exception
	        int beanPrams = Integer.parseInt(bean.getErrorparameters());
	        if(beanPrams == params.length)
	            WACLogger.logException(exception,bean);
	        else
	            WACLogger.logIncorrectExceptionParams(exception,bean);
        }
        else{
            WACLogger.warn("Error code not loaded in to error dictionary "+"error_code = "+errorCode);
            for(int i=0;i<params.length;i++)
                WACLogger.warn("params "+" "+i+" "+params[i].toString());
        }    
        throw exp;
    }
    /**
     * creates new SBIAppException, throws and logs the exception.
     * @param exception
     * @param errorCode
     * @param params
     * @throws SBIException
     */
    public static void throwException(String errorCode,Object[] params) throws SBIApplicationException{
        ErrorDictionary records = ErrorDictionary.getExpInstance();
        HashMap map=records.getInstance();
        ErrorModel bean=(ErrorModel)map.get(errorCode);
        SBIApplicationException exp = new SBIApplicationException(errorCode);
        if(bean!=null){
            bean.setParametervalues(params);
            //if params in bean and size of params match : log exception
	        int beanPrams=0;
	       	beanPrams = Integer.parseInt(bean.getErrorparameters());
	        if(beanPrams == params.length)
	            WACLogger.logException(exp,bean);
	        else
	            WACLogger.logIncorrectExceptionParams(exp,bean);
        }
        else{
            WACLogger.warn("Error code not loaded in to error dictionary "+"error_code = "+errorCode);
            for(int i=0;i<params.length;i++)
                WACLogger.warn("params "+" "+i+" "+params[i].toString());
        }    
        throw exp;
    } 
}
