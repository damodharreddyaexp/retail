package com.sbi.common.exception;

public class SBIApplicationResponse extends CommonApplicationResponse{//Modify For 5287
	private String errorCode;
	private String errorMessage;
	private String errorStatus;
	
	public void setErrorCode(String errorCode){
	 this.errorCode = errorCode;
	}
	public void setErrorMessage(String errorMessage){
	     this.errorMessage=errorMessage;
	}
	public String getErrorCode(){
	    return errorCode;
	}
	public String getErrorMessage(){
	    return errorMessage;
	}
	public String getErrorStatus(){
	    return errorStatus;
	}
	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}
	public String toString() {
		
		 StringBuffer tempStringBuf = new StringBuffer();
	        tempStringBuf.append(errorCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(errorStatus);
	        tempStringBuf.append(" | ");
	        return tempStringBuf.toString();
	
	}
}
