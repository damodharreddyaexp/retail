/*
 * HighSecurityHandler.java
 * Created on May 18, 2006
 *
 * Copyright (c) 2011 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//May 18, 2011 SAIRAM - Initial Creation
package com.sbi.common.secure.handler;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;

public class HighSecurityHandler extends MultiActionController{
	
	 	protected final Logger logger = Logger.getLogger(getClass()); 
	 	private BaseService highSecurityService;
	 	private String PASSWORD = "password";
	 	private String HIGH_SEQUER_PASSWORD = "highSecurityPassword";
	 	private String SECURE_PASSWORD = "securityPassword";
	 	private String PARAMS_MAP = "paramsMap";
	 	private String PROCESS_URL = "processUrl";
	 	private String TRANSFER_NAME = "transactionName";
	 	private String ENABLE_HIGH_SECURITY = "enableHighSecurity";
	 	private String HIGH_SECURITY = "highSecurity";
	  
 public ModelAndView checkHighSecurity(HttpServletRequest request, HttpServletResponse response) { 

	    logger.info("checkHighSecurity (HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);	 
		   
		HttpSession session = request.getSession();
		Map inputParams = new HashMap();
		Map serviceOutParam = new HashMap();
		Map outParams = new HashMap();
		SBIApplicationResponse sbiAppResponse = new SBIApplicationResponse();
		UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
		
		String ehsEnable = request.getParameter("ehsEnable");
		String ehsType = request.getParameter("ehsType");
	      
		String oldMobileNo = userProfile.getMobileNumber();
		String countryCode = userProfile.getCountryCode();
		logger.info("oldMobileNo :"+userProfile.getCountryCode()+oldMobileNo);
		String userRole = ((Integer) userProfile.getRoles().get(0)).toString();
		String bankCode = userProfile.getBankCode();
		String userName= userProfile.getUserAlias();
		String transactionName =  request.getParameter("transactionName");
		logger.info("transactionName ::::"+transactionName);
		request.setAttribute(UIConstant.TRANSACTION_NAME,"ATP");
      
	  if(ehsEnable != null && ehsEnable.equalsIgnoreCase("0") && ehsType != null && ehsType.equalsIgnoreCase("Mobile")){
	  
		  if(oldMobileNo != null){
        	
        	logger.info("oldMobileNo :"+oldMobileNo);
        	logger.info("ehsEnable :"+ehsEnable);
        	logger.info("ehsType :"+ehsType);
        	logger.info("userRole :"+userRole);
        	logger.info("bankCode :"+bankCode);
        	logger.info("userName :"+userName);
        	inputParams.put("oldMobileNo",oldMobileNo);
        	inputParams.put("ehsEnable", ehsEnable);
        	inputParams.put("ehsType", ehsType);
        	inputParams.put("userRole", userRole);
        	inputParams.put("bankCode", bankCode);
        	inputParams.put("userName", userName);
        	inputParams.put("countryCode", countryCode);
        	inputParams.put("transactionName", transactionName);
        	String Status;
        	serviceOutParam = highSecurityService.execute(inputParams);

        	session.setAttribute(HIGH_SEQUER_PASSWORD, serviceOutParam.get(PASSWORD));
	      
	        Map paramsMap = new HashMap();
			Enumeration params = request.getParameterNames();
		
	        while (params.hasMoreElements()) {
	          String param = (String) params.nextElement();
	          logger.info("param ::"+param);
	          if (!param.trim().equalsIgnoreCase(SECURE_PASSWORD))
	          paramsMap.put(param, request.getParameterValues(param));
	        }
	          outParams.put(PARAMS_MAP, paramsMap);
	          outParams.put(UIConstant.APPLICATION_RESPONSE, serviceOutParam.get(UIConstant.APPLICATION_RESPONSE));	
        	} 
        	else{
           	   sbiAppResponse.setErrorCode("RM004");
           	   sbiAppResponse.setErrorStatus(com.sbi.common.handler.UIConstant.FAILURE);
           	   outParams.put(UIConstant.APPLICATION_RESPONSE, sbiAppResponse);
           } 
	       }
	  		logger.info("checkHighSecurity (HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODEND); 	
	        return new ModelAndView("enableHighSecurity", "outParams", outParams);
	 
	 
	 }
	 
	   
	 public ModelAndView checkHighSecurityConfirm(HttpServletRequest request, HttpServletResponse response) {
	        logger.info("checkHighSecurityConfirm(HttpServletRequest request,HttpServletResponse response) method begin");
	        Map outParam = new HashMap();
	        HttpSession session = request.getSession();
	        String transactionName = request.getParameter(TRANSFER_NAME);
	        String type = request.getParameter("type");
	        logger.info("transactionName  :"+transactionName);   
	        String  processUrl = null;
            
	        if (session.getAttribute(HIGH_SEQUER_PASSWORD).toString().trim().equals(
	                request.getParameter(SECURE_PASSWORD).trim())) {
	        	logger.info("transactionName  :"+transactionName); 
	         
	        	if( transactionName != null )
	        		transactionName=transactionName.trim();
	          if(transactionName.equals("AppBenFile")){
	            processUrl = "/approvebulkthirdpartiesconfirmadmin.htm";
	          }else if(transactionName.equals("AddTP")){
	            	processUrl ="/addthirdpartysubmitadmin.htm";	            	
	          }else if(transactionName.equals("AddDDBen")){
	            	processUrl = "/addbeneficiaryconfirmadmin.htm"; 	            	
	          }else if(transactionName.equals("MIBPayee")){
	            	processUrl = "/addexternalthirdpartyconfirm.htm";    	            	
	          }else if(transactionName.equals("AppoveBen")){
	            	processUrl =  "/approve"+type+"beneficiary.htm";    	            	
	          }else if(transactionName.equals("ManInterBkAppBenFile")){
	            	processUrl ="/approveexternalthirdpartiesconfirmadmin.htm";  	            	
	          }else if(transactionName.equals("ManagePrepaidCard")){
	            	processUrl ="/approveexternalthirdpartiesconfirmadmin.htm";	            	
	          }else if(transactionName.equals("ApproveBenFile")){
	            	processUrl ="/approvefileconfirm.htm";	            	
	          }else if(transactionName.equals("ManageTP")){
	            	processUrl ="/addthirdpartysubmitadmin.htm";	            	
	          }else if(transactionName.equals("ManageInterBKAdd")){
	            	processUrl ="/addexternalthirdpartyconfirm.htm";	            	
	          }else if(transactionName.equals("ApproveBenFile")){
	            	processUrl ="/approvefileconfirm.htm";	            	
	          }else if(transactionName.equals("ManageAddDD")){
	            	processUrl ="/approvethirdpartyfileconfirm.htm";	            	
	          }else if (transactionName.equals("RegManageTP")) {
				processUrl = "/addthirdpartysubmit.htm";
			} else if (transactionName.equals("RegManageInterBKAdd")) {
				processUrl = "/addexternalthirdpartyconfirm.htm";
			}else if (transactionName.equals("RegManageAddDD")) {
				processUrl = "/addbeneficiaryconfirm.htm";
			}else if (transactionName.equals("RegManageTPApprove")) {
				processUrl = "/approvebulkthirdpartiesconfirm.htm";
			}else if (transactionName.equals("RegManageTPApproveFile")) {
				processUrl = "/manageTPapprovefileconfirm.htm";				
			}else if (transactionName.equals("RegBulkExternalTPFileName")) {
				processUrl = "/approveexternalthirdpartiesconfirmadmin.htm";
			}else if (transactionName.equals("RegManageIBankPayeeApp")) {
				processUrl = "/manageTPapprovefileconfirm.htm";
			}else if (transactionName.equals("enableMerchantTxn")) {
				processUrl = "/merchanttxnhighsecurityconfirm.htm";
			}
	          
	          logger.info("processUrl :"+processUrl);
	           try {
	                getServletContext().getRequestDispatcher(processUrl).forward(request, response);
	            }
	            catch (Exception exception) {
	            	exception.printStackTrace();
	            }
	            return null;
	        }
		        Map paramsMap = new HashMap();
		        Enumeration params = request.getParameterNames();
		        
		      while (params.hasMoreElements()) {
	            String param = (String) params.nextElement();
	            logger.info("param :"+param);
	            if (!param.trim().equalsIgnoreCase(SECURE_PASSWORD))
	                paramsMap.put(param, request.getParameterValues(param));
	        }
		        outParam.put(PARAMS_MAP, paramsMap);
		        outParam.put("status", "Invalid Password");
		        SBIApplicationResponse appResponse = new SBIApplicationResponse();
		        appResponse.setErrorStatus(UIConstant.SUCCESS);
		        outParam.put(UIConstant.APPLICATION_RESPONSE, appResponse);
		        logger.info("checkHighSecurityConfirm(HttpServletRequest request,HttpServletResponse response) method end");
		 return new ModelAndView(transactionName + "_" + ENABLE_HIGH_SECURITY, "outParams", outParam);
	    }
	 
	 public void setHighSecurityService(BaseService highSecurityService) {
			this.highSecurityService = highSecurityService;
		}     
}
	 
	  
