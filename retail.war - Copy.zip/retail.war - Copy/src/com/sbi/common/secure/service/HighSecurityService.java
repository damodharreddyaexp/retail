/*
 * EnableHighSecurityService.java
 * Created on Jan 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 18, 2006 MANIKANDAN - Initial Creation
package com.sbi.common.secure.service; 

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import java.util.List;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;



public class HighSecurityService extends BaseService{
	
	private SMSGatewayClient smsGatewayClient;
	private String moduleName;//module name specified in configuration file  
	private String PASSWORD = "password";
	private String MOBILE_NO = "oldMobileNo";
	protected final Logger logger=Logger.getLogger(getClass());
	private SBIApplicationResponse response=new SBIApplicationResponse();
	
	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
		response.setErrorStatus(ServiceConstant.FAILURE);
		Map outParam=new HashMap();
		String countryCode = "";
		String mobileNumber ="";
		boolean isSMSMandatory = false;
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String password=StringUtils.randomNumber().toString();
			String message=null; 
			String messageTypeId= null;			
            String userName=(String)inputParams.get("userName");
            String userRole=(String)inputParams.get("userRole");
            String bankCode=(String)inputParams.get("bankCode"); 
            String ehsEnable = (String)inputParams.get("ehsEnable");
            String ehsType = (String)inputParams.get("ehsType");
            String serverHost = null;
            String transactionName =(String) inputParams.get("transactionName");
            logger.info("transactionName ::"+transactionName);
            if( transactionName != null)
			transactionName=transactionName.trim();
			else
			transactionName="";

            if(transactionName.equalsIgnoreCase("AddTP")){
              	messageTypeId = "MT000001";
            }else if(transactionName.equalsIgnoreCase("AddDDBen")){
            	messageTypeId = "MT000006";
            }else if(transactionName.equalsIgnoreCase("AppoveBen")){
            	messageTypeId = "MT000003";
            }else if(transactionName.equalsIgnoreCase("ManInterBkAppBenFile")){
            	messageTypeId = "MT000002";
            }else if(transactionName.equalsIgnoreCase("AppBenFile")){
            	messageTypeId = "MT000002";
            }else if(transactionName.equalsIgnoreCase("ManagePrepaidCard")){
            	messageTypeId = "MT000005";
            }else if(transactionName.equalsIgnoreCase("ApproveBenFile")){
            	messageTypeId = "MT000002";
            }else if(transactionName.equalsIgnoreCase("ManageAddDD")){
            	messageTypeId = "MT000002";
            }else if(transactionName.equalsIgnoreCase("MIBPayee")){
            	messageTypeId = "MT000004";
            }else if(transactionName.equalsIgnoreCase("enableMerchantTxn")){ //Merchant Enable High Security
            	messageTypeId = "MT000007";
            	isSMSMandatory = true;
            }
            
            
            if(ehsType != null && ehsType.equalsIgnoreCase("Mobile")&& ehsEnable != null && ehsEnable.equalsIgnoreCase("0")){
                 
		       String messageId=StringUtils.uniqueNumberUsingDateAndRandom("CA");
		       logger.info("messageId :"+messageId);
		       String [] countryCodeArray;
		       logger.info("MOBILE_NO :"+inputParams.get(MOBILE_NO));
		       countryCode = (String)inputParams.get("countryCode");
		       mobileNumber = (String)inputParams.get(MOBILE_NO);
		       logger.info("mobileNumber :"+mobileNumber);
		       logger.info("countryCode :"+countryCode);
		       List param= new ArrayList();
		       param.add(password);
		       SMSRequestParams request=new SMSRequestParams();
		       request.setBankCode(bankCode);
		       request.setCountryCode(countryCode);
		       request.setMessageId(messageId);//CA000001
		       request.setMessageTypeId(messageTypeId);//MT000001
		       request.setMobileNo(mobileNumber);
		       request.setModuleName(moduleName);
		       request.setParam(param);
		       request.setSendOrder("0");
		       request.setUserName(userName);
		       logger.info("bankCode :"+bankCode);
		       logger.info("userName :"+userName);
		       logger.info("userRole :"+userRole);
		       logger.info("msgTypeId :"+messageTypeId);
		       logger.info("countryCode :"+countryCode);
		       logger.info("messageId :"+messageId);
		       logger.info("messageTypeId :"+messageTypeId);
		       logger.info("mobileNumber :"+mobileNumber);
		       logger.info("moduleName :"+moduleName);
		       logger.info("param :"+param.size());
		       logger.info("userName :"+userName);
		       message=ConstructSMSRequest.constructSMSRequest(request);
		       serverHost= StringUtils.getServerHost();
		       logger.info("message :"+message);
		       logger.info("serverHost :"+serverHost);

		       if(isSMSMandatory ){
					 String sgateResponse = smsGatewayClient.sendMessageToSgate(message, serverHost, messageId);
					 if( sgateResponse != null && sgateResponse.trim().equalsIgnoreCase("00")){
							outParam.put(PASSWORD,password);
							response.setErrorStatus(ServiceConstant.SUCCESS);
						}else{
							SBIApplicationException.throwException("F1");
						}
				 }else{
					smsGatewayClient.sendMessageToSgate(message,serverHost);						
					outParam.put(PASSWORD,password);
					response.setErrorStatus(ServiceConstant.SUCCESS);
				 }	
				
			}else
				response.setErrorCode(ServiceErrorConstants.SE003);
		}
		catch(SBIApplicationException exception){
			response.setErrorCode(exception.getErrorCode());
		}
		catch(Exception exception){
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParam.put(ServiceConstant.APPLICATION_RESPONSE,response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParam; 
	}
	
	public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
		this.smsGatewayClient = smsGatewayClient;
	}
	
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
} 
