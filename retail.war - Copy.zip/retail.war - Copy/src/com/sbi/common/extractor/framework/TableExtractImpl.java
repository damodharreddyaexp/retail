package com.sbi.common.extractor.framework;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.extractor.dao.TableDataExtractorDao;
import com.sbi.common.extractor.model.FileConfiguration;
import com.sbi.common.extractor.utils.ExtractUtils;

/**
 * This class exposes the extractor().
 * @author aa26974
 *
 */
public class TableExtractImpl implements TableExtractor {
	protected final Logger logger=Logger.getLogger(getClass());
	TableDataExtractorDao tableDataExtractorDaoImpl;
	ExtractUtils extractUtils;
	public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
    public static final String FATAL_EXCEPTION_ERRORCODE = "F001";//Due to some technical problems we are unable to process your request. Please try later.
	
    /**
     * This method is invoked to write the data to file.
     */
	public boolean extract(String RefNo,String txnType,String corp_ID,String fileName,String userName,Map whereClausMap) {
		boolean writeFlag = false;
		String extractFileName = fileName;
		List dataStringList = new ArrayList();
		Map extractLogMap = new HashMap();
		extractLogMap.put("txnType",txnType);
		extractLogMap.put("userName",userName);
		
		logger.info("RefNo ::"+RefNo+"txnType ::"+txnType+" corp_ID::"+corp_ID+" fileName::"+fileName+" userName::"+userName+" whereClausMap::"+whereClausMap);
		try {
			
			List configList = tableDataExtractorDaoImpl.getFileConfiguration(txnType,corp_ID);
			//logger.debug("configList ::"+configList);
			if(configList!=null && configList.size()>0){
				
				FileConfiguration configuration = (FileConfiguration) configList.get(0);
				List extractDetailList = tableDataExtractorDaoImpl.retrieveExtractQuery(configuration.getOid());
				
				Map extractMap = (Map)extractDetailList.get(0);
				String extractQuery = (String)extractMap.get("EXTRACT_QUERY");
				String filePath = (String)extractMap.get("FILE_PATH");
				logger.info("filePath ::"+filePath+" extractQuery::"+extractQuery);
				String replacedQuery = extractUtils.replaceWhereClauseValues(extractQuery,whereClausMap);
				logger.info(" replacedQuery::"+replacedQuery);
				List dataList = tableDataExtractorDaoImpl.getDataList(replacedQuery);
				//logger.debug("dataList ::"+dataList);
				
				Map dataConfigMap = new HashMap();
				dataConfigMap.put("configList",configList);
				dataConfigMap.put("dataList",dataList);
				
				if(configuration.getFormat()==0)//delimited
					dataStringList = extractUtils.MapToDelimitedString(dataConfigMap,configuration.getFieldDelimiter());
				else if(configuration.getFormat()==1)//fixed
					dataStringList = extractUtils.MapToFixedString(dataConfigMap);
				if(dataStringList!=null && dataStringList.size()>0) {
					
					if(extractFileName==null || extractFileName.length()==0) {
						extractFileName = txnType+"_"+extractUtils.getTimeStamp("ddMMyyyyhhmmss")+".txt";
						
					}
					extractLogMap.put("oid",configuration.getOid());
					extractLogMap.put("filePath",(filePath+extractFileName));
					
					if(RefNo==null)
						RefNo="";
					extractLogMap.put("RefNo",RefNo);
					
					logger.info("filePath ::"+filePath+" extractFileName::"+extractFileName);
                  
					writeFlag = extractUtils.createFile(dataStringList,filePath,extractFileName);
					
					if(writeFlag==true) {
					extractLogMap.put("status","Success");
					}else {
						extractLogMap.put("status","Failure");
					}
					
					tableDataExtractorDaoImpl.insertExtractLogDetails(extractLogMap);
				}
			}
		} catch (DAOException dae) {
			SBIApplicationException.throwException(FATAL_EXCEPTION_ERRORCODE,dae);
		} catch (SBIApplicationException sbiexp) {
			logger.error("SBIApplicationException ::",sbiexp);
			sbiexp.throwException(FATAL_EXCEPTION_ERRORCODE,sbiexp);
		}catch (Exception exp) {
			//exp.printStackTrace();
			logger.error("Exception occured : "+ exp);
			SBIApplicationException.throwException(FATAL_EXCEPTION_ERRORCODE,exp);
		}
		logger.info("writeFlag ::"+writeFlag);
		return writeFlag;
	}
	
	

	public void setTableDataExtractorDaoImpl(
			TableDataExtractorDao tableDataExtractorDaoImpl) {
		this.tableDataExtractorDaoImpl = tableDataExtractorDaoImpl;
	}
	


	public void setExtractUtils(ExtractUtils extractUtils) {
		this.extractUtils = extractUtils;
	}
	
	
}
