package com.sbi.common.extractor.framework;

public class TableExtractorFactory {

	TableExtractor tableExtractImpl;
	public TableExtractor getExtractor() {
		return tableExtractImpl;
	}
	
	public void setTableExtractImpl(TableExtractor tableExtractImpl) {
		this.tableExtractImpl = tableExtractImpl;
	}
}
