/**
 * 
 */
package com.sbi.common.extractor.framework;

import java.util.Map;

/**
 * @author aa26974
 *
 */
public interface TableExtractor {

	public boolean extract(String RefNo,String txnType,String corp_ID,String fileName,String userName,Map whereClausMap);
}
