/**
 * @(#) FileConfiguration.java
 */

package com.sbi.common.extractor.model;

import java.io.Serializable;

/**
 * @author Praveen Kumar Sidda
 * @version 1.0
 * 
 * This class serves as the model for all the requests concerning
 * FileConfiguration
 */
public class FileConfiguration implements Serializable {
	/**
	 * To Read from SBICORP_FILE_CONFIG_MASTER
	 */
	private int corporateId;
	
	private int corporateId1;

	private String id;

	private String corporateType;

	private String stage;

	private String transactionType;

	private String modeConfig;

	private int format;

	private String header;

	private String footer;

	private String fieldDelimiter;

	private String recordDelimiter;

	private String fileName;

	private String businesslineId;

	private String debitIdentifier;

	private Long oid;

	/**
	 * To Read from SBICORP_DELIMITED_CONFIG
	 */
	private int orderNumber;

	private String fieldName;

	/**
	 * To Read from SBICORP_FIXED_CONFIG
	 */
	private String fldName;

	private int startIndex;

	private int endIndex;

	private String transactionCode;
	
	private String fieldAlias;
    
    private int constantValue;// added for IBTP
    
    private int defaultValue;// added for IBTP
    
    private String fieldValue;
    
	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	/**
	 * @return businesslineId
	 */
	public String getBusinesslineId() {
		return businesslineId;
	}

	/**
	 * @param businesslineId
	 */
	public void setBusinesslineId(String businesslineId) {
		this.businesslineId = businesslineId;
	}

	/**
	 * @return corporateType
	 */
	public String getCorporateType() {
		return corporateType;
	}

	/**
	 * @param corporateType
	 */
	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

	/**
	 * @return debitIdentifier
	 */
	public String getDebitIdentifier() {
		return debitIdentifier;
	}

	/**
	 * @param debitIdentifier
	 */
	public void setDebitIdentifier(String debitIdentifier) {
		this.debitIdentifier = debitIdentifier;
	}

	/**
	 * @return endIndex
	 */
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * @param endIndex
	 */
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	/**
	 * @return fieldDelimiter
	 */
	public String getFieldDelimiter() {
		return fieldDelimiter;
	}

	/**
	 * @param fieldDelimiter
	 */
	public void setFieldDelimiter(String fieldDelimiter) {
		this.fieldDelimiter = fieldDelimiter;
	}

	/**
	 * @return fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return fldName
	 */
	public String getFldName() {
		return fldName;
	}

	/**
	 * @param fldName
	 */
	public void setFldName(String fldName) {
		this.fldName = fldName;
	}

	/**
	 * @return footer
	 */
	public String getFooter() {
		return footer;
	}

	/**
	 * @param footer
	 */
	public void setFooter(String footer) {
		this.footer = footer;
	}

	/**
	 * @return format
	 */
	public int getFormat() {
		return format;
	}

	/**
	 * @param format
	 */
	public void setFormat(int format) {
		this.format = format;
	}

	/**
	 * @return header
	 */
	public String getHeader() {
		return header;
	}

	/**
	 * @param header
	 */
	public void setHeader(String header) {
		this.header = header;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return modeConfig
	 */
	public String getModeConfig() {
		return modeConfig;
	}

	/**
	 * @param modeConfig
	 */
	public void setModeConfig(String modeConfig) {
		this.modeConfig = modeConfig;
	}

	/**
	 * @return orderNumber
	 */

	public int getOrderNumber() {
		return orderNumber;
	}

	/**
	 * @param orderNumber
	 */
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @return recordDelimiter
	 */
	public String getRecordDelimiter() {
		return recordDelimiter;
	}

	/**
	 * @param recordDelimiter
	 */
	public void setRecordDelimiter(String recordDelimiter) {
		this.recordDelimiter = recordDelimiter;
	}

	/**
	 * @return stage
	 */
	public String getStage() {
		return stage;
	}

	/**
	 * @param stage
	 */
	public void setStage(String stage) {
		this.stage = stage;
	}

	/**
	 * @return startIndex
	 */
	public int getStartIndex() {
		return startIndex;
	}

	/**
	 * @param startIndex
	 */
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	/**
	 * @return transactionCode
	 */
	public String getTransactionCode() {
		return transactionCode;
	}

	/**
	 * @param transactionCode
	 */
	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	/**
	 * @return transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return corporateId
	 */
	public int getCorporateId() {
		return corporateId;
	}

	/**
	 * @param corporateId
	 */
	public void setCorporateId(int corporateId) {
		this.corporateId = corporateId;
	}

	public Long getOid() {
		return oid;
	}

	public void setOid(Long oid) {
		this.oid = oid;
	}

	public String toString(){
		StringBuffer temp = new StringBuffer();
		temp.append("fldName = ");
		temp.append(fieldName);
		temp.append("|");
		temp.append("orderNumber = ");
		temp.append(orderNumber);
		temp.append("|");
		temp.append("startIndex = ");
		temp.append(startIndex);
		temp.append("|");
		temp.append("endIndex = ");
		temp.append(endIndex);
		temp.append("|");
		temp.append("fieldAlias = ");
		temp.append(fieldAlias);		
        temp.append("|");//added for inter bank third party
        temp.append("constantValue = ");
        temp.append(constantValue);
        temp.append("|");
        temp.append("defaultValue = ");
        temp.append(defaultValue);//inter bank third party ends here        
		return temp.toString();
	}

	public String getFieldAlias() {
		return fieldAlias;
	}

	public void setFieldAlias(String fieldAlias) {
		this.fieldAlias = fieldAlias;
	}
  // Added for inter bank third party

    public int getConstantValue()
    {
        return constantValue;
    }

    public void setConstantValue(int constantValue)
    {
        this.constantValue = constantValue;
    }

    public int getDefaultValue()
    {
        return defaultValue;
    }

    public void setDefaultValue(int defaultValue)
    {
        this.defaultValue = defaultValue;
    }
   
  // inter bank third party ends here
}
