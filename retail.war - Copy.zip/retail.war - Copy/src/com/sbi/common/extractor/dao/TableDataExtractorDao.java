package com.sbi.common.extractor.dao;

import java.util.List;
import java.util.Map;


public interface TableDataExtractorDao {
	
	public List getFileConfiguration(String txnType,String corp_id);
	public List retrieveExtractQuery(Long oid);
	public List getDataList(String extractQuery);
	public void insertExtractLogDetails(Map extractLogMap);
}
