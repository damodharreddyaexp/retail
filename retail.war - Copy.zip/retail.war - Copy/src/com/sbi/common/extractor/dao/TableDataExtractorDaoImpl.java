package com.sbi.common.extractor.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.extractor.model.FileConfiguration;


	/**
	 * This is used to retrieve the file configuration
	 * retrieve the extract query,file path from SBI_EXTRACTOR_DETAILS 
	 * 
	 */
	public class TableDataExtractorDaoImpl extends JdbcDaoSupport implements TableDataExtractorDao {

		private Logger logger = Logger.getLogger(getClass());
		
		public static final String FATAL_EXCEPTION_ERRORCODE = "F001";//Due to some technical problems we are unable to process your request. Please try later.
		
		public final static String SELECT_FIXED_FILE_CONFIGURATION = "SELECT * FROM SBICORP_FIXED_CONFIG WHERE OID=? ORDER BY START_INDEX";                                                                                                                                                                                                                                                             
		
		public final static String SELECT_DELIMITED_FILE_CONFIGURATION = "SELECT * FROM SBICORP_DELIMITED_CONFIG WHERE OID=? ORDER BY ORDER_NO";                                                                                                                                                                                                                                                        
		
		public final static String RETRIEVE_EXTRACT_QUERY = "SELECT EXTRACT_QUERY,FILE_PATH FROM  SBI_EXTRACTOR_DETAILS WHERE OID=? ";                                                                                                                                                                                                                                                                                           
		
		public final static String INSERT_EXTRACT_LOG_QUERY ="INSERT INTO SBI_DB_FILE_EXTRACTOR_LOG ( OID, REFERENCE_NO, TXN_TYPE, FILE_PATH,STATUS,USER_NAME ) VALUES (?,?, ?, ?, ?, ? )";

		
	
		/**
		 * This method returns List of required file configuration.
		 */
		public List getFileConfiguration(String txnType,String corporateId) throws DAOException {
			logger.info("getFileConfiguration(String corporateId) - begin");
			List fileconfig = null;
			List configList = null;
			String query =null;
			Object[] params = new Object[] { corporateId };
			logger.info("Input param corporate Id ="+corporateId);
			try {
				//query alerted for default file configuration.
				if(txnType.equalsIgnoreCase("DIBTP")||txnType.equalsIgnoreCase("IBTP"))
				query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and txn_type = '" +txnType+ "' and status=1";
				else
					query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and txn_type like '%" + txnType + "%' and status=1";
				logger.info("QUERY::::"+query);
					
				fileconfig = getJdbcTemplate().query(query, params,new ConfigurationMapper());
				logger.info("Result : "+fileconfig);
				if ((fileconfig != null) && (fileconfig.size() > 0)) {
					FileConfiguration configuration = (FileConfiguration) fileconfig.get(0);
					int format = configuration.getFormat();
					if (configuration.getFormat() != 0) {
						Object[] paramsfixed = new Object[] { configuration
								.getOid() };
						configList = getJdbcTemplate().query(
								SELECT_FIXED_FILE_CONFIGURATION,
								paramsfixed, new FixedFileConfigurationMapper());
						logger.info("Fixed configuration :"+configList);
						if ((configList != null) && (configList.size() > 0)) {
							FileConfiguration fixedconfig = (FileConfiguration) configList
									.get(0);
							fixedconfig.setFormat(format);
							fixedconfig.setOid(configuration.getOid());
						}
					} else {
						Object[] paramsdelimited = new Object[] { configuration
								.getOid() };
						configList = getJdbcTemplate().query(
								SELECT_DELIMITED_FILE_CONFIGURATION,
								paramsdelimited,
								new DelimitedFileConfigurationMapper());
						logger.info("Delimited configuration ="+configList);
						if ((configList != null) && (configList.size() > 0)) {
							FileConfiguration delimconfig = (FileConfiguration) configList
									.get(0);
							delimconfig.setFieldDelimiter(configuration
									.getFieldDelimiter());
							delimconfig.setFormat(format);
							delimconfig.setOid(configuration.getOid());
						}
					}
					
					if(configList == null || configList.size()==0 )
						DAOException.throwException(FATAL_EXCEPTION_ERRORCODE);
				}
			} catch (DataAccessException e) {
				logger.error("Error occured :" , e);
				DAOException.throwException(
						FATAL_EXCEPTION_ERRORCODE, e);
			}
			logger.info("getFileConfiguration(String corporateId) - end");
			return configList;
		}
		
		/**
		 * retrieves the extract query for the given oid.
		 */
		public List retrieveExtractQuery(Long oid) {
			logger.info("retrieveExtractQuery ::"+oid);
			String extractQuery ="";
			List extractList = null;
			try {
				extractList = getJdbcTemplate().queryForList(RETRIEVE_EXTRACT_QUERY,new Object[] { oid });
				if(extractList==null || extractList.size()==0) 
					DAOException.throwException(FATAL_EXCEPTION_ERRORCODE);
				
			} catch (DataAccessException dae) {
				//dae.printStackTrace();
				logger.error("retrieveExtractQuery :" , dae);
				DAOException.throwException(FATAL_EXCEPTION_ERRORCODE, dae);
			}
			
			return extractList;
		}
		
		/**
		 * Executes the extract query to retrieve the data list
		 *  
		 */
		public List getDataList(String replacedExcuteQuery) {
			List datatList = null;
			try {
				  datatList = getJdbcTemplate().queryForList(replacedExcuteQuery,new Object[] {  });
				  if(datatList==null || datatList.size()==0) 
						DAOException.throwException(FATAL_EXCEPTION_ERRORCODE);
				  
				} catch (DataAccessException dae) {
					logger.error("Error occured :" , dae);
					DAOException.throwException(FATAL_EXCEPTION_ERRORCODE, dae);
				}
			return datatList;
		}
		
		/**
		 * logs the file creation time,status,path
		 */
		public void insertExtractLogDetails(Map extractLogMap) {
			try {
				
				//OID, TXN_TYPE, FILE_PATH,STATUS,USER_NAME 
				Object params[] = {extractLogMap.get("oid"),extractLogMap.get("RefNo"),extractLogMap.get("txnType"),
								   extractLogMap.get("filePath"),extractLogMap.get("status"),extractLogMap.get("userName")};
				int updateResult = getJdbcTemplate().update(INSERT_EXTRACT_LOG_QUERY,params);
				logger.info("Rows Inserted :"+ updateResult );
			}catch (DataAccessException dae) {
				//dae.printStackTrace();
				logger.error("Inside insertExtractLogDetails :"+ dae );
				DAOException.throwException(FATAL_EXCEPTION_ERRORCODE, dae);
			}
		}
		
		
		public class ConfigurationMapper implements RowMapper {

			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				FileConfiguration configuration = new FileConfiguration();
				configuration.setFormat(rs.getInt(DAOConstants.FORMAT));
				logger.info("Format : " + configuration.getFormat());
				configuration.setFieldDelimiter(rs
						.getString(DAOConstants.FIELD_DELIMITER));
				configuration.setOid(rs.getLong(DAOConstants.OID));
				configuration.setTransactionType(rs.getString("TXN_TYPE"));
				return configuration;
			}
		}

		/**
		 * 
		 * This class serves for mapping rows of FixedFileConfiguration
		 */
		public class FixedFileConfigurationMapper implements RowMapper {
			/**
			 * This method is used to map rows for FixedFileConfiguration
			 */
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				FileConfiguration fileConfiguration = new FileConfiguration();
				//fileConfiguration.setFormat(rs.getInt(DAOConstants.FORMAT));
				fileConfiguration.setFormat(1);			
				logger.info("Format : " + fileConfiguration.getFormat());
				if(rs.getString(DAOConstants.FLD_NAME).substring(0,3).equalsIgnoreCase("OUT"))
					fileConfiguration.setFldName("OUTREF");
				else
					fileConfiguration.setFieldName(rs.getString(DAOConstants.FLD_NAME));
				fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
				fileConfiguration.setStartIndex(rs.getInt(DAOConstants.START_INDEX));
				fileConfiguration.setEndIndex(rs.getInt(DAOConstants.END_INDEX));
				fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
	            fileConfiguration.setConstantValue(rs.getInt("CONST_VALUE"));//Added for inter Bank third Party
	            fileConfiguration.setDefaultValue(rs.getInt("DEFAULT_VALUE"));//Added for inter Bank third Party
	            
				return fileConfiguration;

			}

		}

		/**
		 * 
		 * This class serves for mapping rows of DelimitedFileConfiguration
		 */
		public class DelimitedFileConfigurationMapper implements RowMapper {

			/**
			 * This method is used to map rows for DelimitedFileConfiguration
			 */
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

				FileConfiguration fileConfiguration = new FileConfiguration();
				fileConfiguration.setFormat(0);	
				if(rs.getString(DAOConstants.FIELD_NAME).substring(0,3).equalsIgnoreCase("OUT"))
					fileConfiguration.setFieldName("OUTREF");
				else
					fileConfiguration.setFieldName(rs.getString(DAOConstants.FIELD_NAME));
				fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
				fileConfiguration.setOrderNumber(rs.getInt(DAOConstants.ORDER_NO));
				fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
				return fileConfiguration;

			}

		}
		
}
