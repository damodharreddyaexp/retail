/* 
 * DAOConstants.java
 * Created on Oct 19, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 10, 2005 SAIRAM - Initial Creation
package com.sbi.common.extractor.dao;



/**
 * * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public interface DAOConstants  { 

	
	 public static final String FLD_NAME = "fld_name";

		public static final String START_INDEX = "start_index";

		public static final String END_INDEX = "end_index";

		public static final String FIELD_NAME = "field_name";

		public static final String ORDER_NO = "order_no";

	    public static final String OID="oid";
	    
	    public static final String FORMAT="format";
	    
	    public static final String FIELD_DELIMITER="field_delimiter"; 
	    
	    public static final String CREATION_TIME="creation_time";
    
     
}
