package com.sbi.common.extractor.utils;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.util.FileCopyUtils;



import com.sbi.common.extractor.model.FileConfiguration;

public class ExtractUtils {
	
	protected final Logger logger=Logger.getLogger(getClass());
	public static final String FATAL_EXCEPTION_ERRORCODE = "F001";//Due to some technical problems we are unable to process your request. Please try later.
	
	/**
	 * This method replaces the value in the where clause.
	 * @param extractQuery
	 * @param whereClauseMap
	 * @return
	 */
	public String replaceWhereClauseValues(String extractQuery,Map whereClauseMap){
		String replacedQuery = extractQuery ;
		String key ="";
		String value="";
		Iterator iterate = whereClauseMap.entrySet().iterator();
		while (iterate.hasNext()) {
       	 
            Map.Entry pairs = (Map.Entry)iterate.next();
            key = ":"+(String)pairs.getKey();
            value = "'"+(String) pairs.getValue()+"'";
            logger.info("paramValue :"+key + " = " + value);
            if(replacedQuery.indexOf(key)>-1)
            	replacedQuery = replacedQuery.replaceAll(key,value);
            else if(replacedQuery.indexOf(key.toUpperCase())>-1)
            	replacedQuery = replacedQuery.replaceAll(key.toUpperCase(),value);
            else
            	replacedQuery = replacedQuery.replaceAll(key.toLowerCase(),value);
		}
		
		logger.info("replacedQuery ::"+replacedQuery);
		return replacedQuery;
	}
	
	/**
	 * Converts the data Map as data string and stores in List.Values are delimited.
	 * @param p_dataConfigMap
	 * @param delim
	 * @return
	 */
	public List MapToDelimitedString(Map p_dataConfigMap,String delim) {
		
		Map dataConfigMap = p_dataConfigMap;
		List configList = (List)dataConfigMap.get("configList");
		List dataList = (List)dataConfigMap.get("dataList");
		List mapStringList = new ArrayList();
		String datastring = "";
		for(int i=0;i<dataList.size();i++) {
			
			Map dataMap = (Map)dataList.get(i);
			StringBuffer strBuff = new StringBuffer();
			for(int j=0;j<configList.size();j++) {
				FileConfiguration configuration = (FileConfiguration) configList.get(j);
				
				if(configuration.getFieldName()!=null && dataMap.containsKey(configuration.getFieldName().toUpperCase()))
					strBuff.append(dataMap.get(configuration.getFieldName()));
				else if(configuration.getFieldAlias()!=null && dataMap.containsKey(configuration.getFieldAlias().toUpperCase()))
					strBuff.append(dataMap.get(configuration.getFieldAlias()));
				else //for null values space will be appended.
					strBuff.append(" ");
				
					strBuff.append(delim);
			}
			datastring = strBuff.toString();
			datastring = datastring.substring(0,datastring.length()-1);//to remove the last appended delim.
			mapStringList.add(datastring);
			//logger.info("mapStringList ::"+datastring);
		}
		
		return mapStringList;
	}
	
	/**
	 * Converts the data Map as data string and stores in List.Values are fixed length.
	 * @param p_dataConfigMap
	 * @return
	 */
	public List MapToFixedString(Map p_dataConfigMap) {
		
		Map dataConfigMap = p_dataConfigMap;
		List configList = (List)dataConfigMap.get("configList");
		List dataList = (List)dataConfigMap.get("dataList");
		List mapStringList = new ArrayList();
		String value = "";
		String emptyStr = "";
		int stringLength = ((FileConfiguration) configList.get(configList.size()-1 )).getEndIndex();
		for(int k=0;k<stringLength;k++)
			emptyStr = emptyStr + " ";
		
		for(int i=0;i<dataList.size();i++) {
			Map dataMap = (Map)dataList.get(i);
			StringBuffer strBuff = new StringBuffer(stringLength);
			strBuff.append(emptyStr);
			for(int j=0;j<configList.size();j++) {
				FileConfiguration configuration = (FileConfiguration) configList.get(j);
				int paramStartPos = configuration.getStartIndex();
				int paramEndPos = configuration.getEndIndex();
				//logger.info("Name ::"+configuration.getFieldName()+" Value ::"+(String)dataMap.get(configuration.getFieldName())+" paramStartPos ::"+paramStartPos +" paramEndPos ::"+paramEndPos );
				if(configuration.getFieldName()!=null && dataMap.containsKey(configuration.getFieldName().toUpperCase())) {
					value = (String)dataMap.get(configuration.getFieldName());
					if(value!=null && value.length()>0)
						strBuff.replace(paramStartPos,paramStartPos+value.length(),value);
				}
				else if(configuration.getFieldAlias()!=null && dataMap.containsKey(configuration.getFieldAlias().toUpperCase())) {
					value = (String)dataMap.get(configuration.getFieldAlias());
					if(value!=null && value.length()>0)
						strBuff.replace(paramStartPos,paramStartPos+value.length(),value);
				}
				
				//logger.info("after replace ::"+strBuff);
			}
			mapStringList.add(strBuff.toString());
			
			//logger.info("mapStringList ::"+strBuff);
		}
		
		return mapStringList;
		
	}
	/**
	 * Writes the data in txt format under the given path.
	 * @param dataList
	 * @param filePath
	 * @param fileName
	 * @return
	 */
/*	public boolean createFile(List<String> dataList, String filePath,String fileName) {
		
		String completePath = filePath + fileName;
		
		try{
			logger.info(" Writing Data File To :: " +completePath );
			FileWriter fileWriter = new FileWriter(completePath);
			
			for(int i=0;i<dataList.size();i++){
				fileWriter.write(dataList.get(i));
				fileWriter.write("\n");
			}
			fileWriter.flush();
			fileWriter.close();
		}catch(Exception exception){
			logger.error("Error Writing File ::"+exception);
			//exception.printStackTrace();
			return false;
		}
		return true;
	}
*/
    //added by siva for writing the file in temp path starts here
    
    
public boolean createFile(List<String> dataList, String filePath,String fileName) {

    //String completePath = filePath + fileName;
    boolean isTempfileRequired = false;
    try{
        String[] path=  filePath.split(":");
        String tempPath="";
        String destinationPath ="";
        String tempFilepfix = "temp";
        
        if(path.length > 1){
            tempPath=path[1] ;
            destinationPath = path[0];
            isTempfileRequired = true;
        }else{
            tempPath=path[0];
            destinationPath =tempPath;
          
        }
          
        logger.info("   tempPath   "+tempPath +"    destinationPath     "+ destinationPath+"  fileName  "+fileName);
        logger.info(" Writing Data File To  Path:: " +tempPath );
            File tempDirwithFile = new File(tempPath ,tempFilepfix+fileName+"."+tempFilepfix );
            logger.info(" Writing Data File  " +tempDirwithFile );
            FileWriter fileWriter = new FileWriter(tempDirwithFile);
            
            for(int i=0;i<dataList.size();i++){
                fileWriter.write(dataList.get(i));
                fileWriter.write("\n");
            }
            fileWriter.flush();
            fileWriter.close();
            logger.info("file created..."+tempDirwithFile);
            if(isTempfileRequired){
               FileCopyUtils.copy(tempDirwithFile,new File(tempPath,fileName+"_backup"));
               logger.info("took backup....");
               File destinationDirwithFile  = new File(destinationPath,fileName);
               logger.info("destination...."+destinationDirwithFile);
               boolean renameStatus = tempDirwithFile.renameTo(destinationDirwithFile);
               
               if(renameStatus){               
               logger.info("moved to destination....");
               }else{
                   logger.warn("Not able to rename..May be diffent file system (or) File with same name exist in target folder....");
                   return false;
               }
            }
   
            
        }catch(Exception exception){
            logger.error("Error Writing File ::"+exception);
            //exception.printStackTrace();
            return false;
        }
        return true;
    }


//added by siva for writing the file in temp path ends here
	/**
	    * This method return the system date.
	    * @param p_format
	    * @return sysdate
	    */
	   public String getTimeStamp(String p_format){
	      
	      DateFormat dateFormat = new SimpleDateFormat ( p_format);
	      Date sysDate = new Date ();
	      String sysdate = dateFormat.format ( sysDate );
	      
	      return sysdate;
	   }
	   

}
