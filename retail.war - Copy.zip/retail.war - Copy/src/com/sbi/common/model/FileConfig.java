package com.sbi.common.model;

public class FileConfig  implements BaseModel{

	/**  
	 * @(#) FileConfig.java
	 */
	        private String fieldName;
	        
	        private String startIndex;
	        
	        private String endIndex;

			public String getEndIndex() {
				return endIndex;
			}

			public void setEndIndex(String endIndex) {
				this.endIndex = endIndex;
			}

			public String getFieldName() {
				return fieldName;
			}

			public void setFieldName(String fieldName) {
				this.fieldName = fieldName;
			}

			public String getStartIndex() {
				return startIndex;
			}

			public void setStartIndex(String startIndex) {
				this.startIndex = startIndex;
			}
}
