package com.sbi.common.model;


import java.sql.Timestamp;

public class Ticket implements BaseModel {
	
	private String ticketNo;
	
	private String issueCode;
	
	private String userName;
	
	private String name;
	
	private String param1;
	
	private String param2;
	
	private String param3;
	
	private String param4;
	
	private String description;
	
	private Double assignedTo;
	
	private String raisedBy;
	
	private Integer bankCode;
	
	private Integer read;

	private int workFlowState;
	
	private Timestamp creationTime;
	
	private String claimant;
	
	private String comments;
	
	private String branchCode;
	
	private String labelId;
	
	private TicketThread ticketThread;
	
	private String userRole;
	
	private String ticketStatus;

	public String getTicketStatus() {
		return ticketStatus;
	}


	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}


	public String getUserRole() {
		return userRole;
	}


	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}


	public Double getAssignedTo() {
		return assignedTo;
	}

	
	public void setAssignedTo(Double assignedTo) {
		this.assignedTo = assignedTo;
	}

	
	public Integer getBankCode() {
		return bankCode;
	}

	public void setBankCode(Integer bankCode) {
		this.bankCode = bankCode;
	}

	
	public String getDescription() {
		return description;
	}

	
	public void setDescription(String description) {
		this.description = description;
	}

	
	public String getIssueCode() {
		return issueCode;
	}

	
	public void setIssueCode(String issueCode) {
		this.issueCode = issueCode;
	}

	
	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	
	public String getParam1() {
		return param1;
	}

	
	public void setParam1(String param1) {
		this.param1 = param1;
	}

	
	public String getParam2() {
		return param2;
	}
	
	public void setParam2(String param2) {
		this.param2 = param2;
	}

	public String getParam3() {
		return param3;
	}
	
	public void setParam3(String param3) {
		this.param3 = param3;
	}

	public String getParam4() {
		return param4;
	}

	public void setParam4(String param4) {
		this.param4 = param4;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public Integer getRead() {
		return read;
	}

	public void setRead(Integer read) {
		this.read = read;
	}

	public String getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public int getWorkFlowState() {
		return workFlowState;
	}

	public void setWorkFlowState(int workFlowState) {
		this.workFlowState = workFlowState;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getClaimant() {
		return claimant;
	}

	public void setClaimant(String claimant) {
		this.claimant = claimant;
	}
	
	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getBranchCode() {
		return branchCode;
	}


	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}


	public String getLabelId() {
		return labelId;
	}


	public void setLabelId(String labelId) {
		this.labelId = labelId;
	}


	public TicketThread getTicketThread() {
		return ticketThread;
	}


	public void setTicketThread(TicketThread ticketThread) {
		this.ticketThread = ticketThread;
	}

	public String toString()
	{
		StringBuffer tmp=new StringBuffer();
		
		tmp.append(ticketNo);
		tmp.append("|");
		tmp.append(issueCode);
		tmp.append("|");
		tmp.append(userName);
		tmp.append("|");
		tmp.append(name);
		tmp.append("|");
		tmp.append(param1);
		tmp.append("|");
		tmp.append(param2);
		tmp.append("|");
		tmp.append(param3);
		tmp.append("|");
		tmp.append(param4);
		tmp.append("|");
		tmp.append(description);
		tmp.append("|");
		tmp.append(assignedTo);
		tmp.append("|");
		tmp.append(raisedBy);
		tmp.append("|");
		tmp.append(bankCode);
		tmp.append("|");
		tmp.append(read);
		tmp.append("|");
		tmp.append(workFlowState);
		tmp.append("|");
		tmp.append(creationTime);
		tmp.append("|");
		tmp.append(claimant);
		tmp.append("|");
		tmp.append(comments);
		tmp.append("|");
		tmp.append(branchCode);
		tmp.append("|");
		tmp.append(labelId);
		tmp.append("|");
		tmp.append(ticketThread);
		tmp.append("|");
		tmp.append(ticketStatus);
		
		
		return tmp.toString();
		
	}


	

	

}
