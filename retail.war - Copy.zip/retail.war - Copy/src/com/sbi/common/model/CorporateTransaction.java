/**
 * @(#) CorporateTransaction.java
 */

package com.sbi.common.model;

public class CorporateTransaction  implements BaseModel 
{
        private CorporateDetails corporateDetails;
        
        public void setCorporateDetails( CorporateDetails corporateDetails )
        {
                this.corporateDetails=corporateDetails;
        }
        
        public CorporateDetails getCorporateDetails( )
        {
                return corporateDetails;
        }
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(corporateDetails);
        	tempStringBuf.append("|");
                   	
        	return tempStringBuf.toString();
        	
        }
          
}
