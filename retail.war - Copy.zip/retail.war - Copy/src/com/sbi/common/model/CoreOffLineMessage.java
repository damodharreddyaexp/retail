/*
 * CR-1884
 * SN27223
 */


package com.sbi.common.model;

import java.sql.Timestamp;

public class CoreOffLineMessage implements BaseModel
{

   
    private String role;

    private String message;
     
    private Timestamp displayFrom;

    private Timestamp displayTo;
    
    private String messageNature;

    private String bankCode;
    
    private String status; 
 
	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public Timestamp getDisplayFrom() {
		return displayFrom;
	}

	public void setDisplayFrom(Timestamp displayFrom) {
		this.displayFrom = displayFrom;
	}

	public Timestamp getDisplayTo() {
		return displayTo;
	}

	public void setDisplayTo(Timestamp displayTo) {
		this.displayTo = displayTo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageNature() {
		return messageNature;
	}

	public void setMessageNature(String messageNature) {
		this.messageNature = messageNature;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	} 
    
	 public String toString()
	    {
	        StringBuffer tempStringBuf = new StringBuffer();      
	        tempStringBuf.append("role:");
	        tempStringBuf.append(role);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("message:");
	        tempStringBuf.append(message);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("displayFrom:");
	        tempStringBuf.append(displayFrom);
	        tempStringBuf.append(" | ");	        
	        tempStringBuf.append("displayTo:");
	        tempStringBuf.append(displayTo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("messageNature:");
	        tempStringBuf.append(messageNature);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("bankCode:");
	        tempStringBuf.append(bankCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("status:");
	        tempStringBuf.append(status);   
	      
	       
	        return tempStringBuf.toString();
	    } 
    

   

    
    
     
    
}
    
    
  