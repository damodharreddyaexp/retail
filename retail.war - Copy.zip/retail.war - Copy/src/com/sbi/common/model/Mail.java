package com.sbi.common.model;

import java.sql.Timestamp;

public class Mail implements BaseModel {
	
	private String mailReference;
	
	private String fromId;
	
	private String mailSubject;
	
	private String message;
	
	private Timestamp creationTime;
	
	private int read;
	
	private int workFlowState;
	
	private int unReadCount;

	public int getWorkFlowState() {
		return workFlowState;
	}

	public void setWorkFlowState(int workFlowState) {
		this.workFlowState = workFlowState;
	}

	public String getMailReference() {
		return mailReference;
	}

	public void setMailReference(String mailReference) {
		this.mailReference = mailReference;
	}

	public String getFromId() {
		return fromId;
	}

	public void setFromId(String fromId) {
		this.fromId = fromId;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public int getRead() {
		return read;
	}

	public void setRead(int read) {
		this.read = read;
	}
	
	
	public String toString()
	{
		StringBuffer tmp=new StringBuffer();
		
		tmp.append(mailReference);
		tmp.append("|");
		tmp.append(fromId);
		tmp.append("|");
		tmp.append(mailSubject);
		tmp.append("|");
		tmp.append(message);
		tmp.append("|");
		tmp.append(creationTime);
		tmp.append("|");
		tmp.append(read);
				
		
		return tmp.toString();
		
	}

	public int getUnReadCount() {
		return unReadCount;
	}

	public void setUnReadCount(int unReadCount) {
		this.unReadCount = unReadCount;
	}
	


}
