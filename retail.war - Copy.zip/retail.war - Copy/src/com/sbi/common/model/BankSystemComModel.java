/**
 * @(#) Transaction.java
 */

package com.sbi.common.model;

import java.util.HashSet;
import java.util.Set;


public class BankSystemComModel implements BaseModel
{
	
	public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append("referenceNo :");
        tempStringBuf.append(referenceNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append("requestString :");
        tempStringBuf.append(requestString);
        tempStringBuf.append(" | ");
        tempStringBuf.append("status :");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        tempStringBuf.append("errorCode :");
        tempStringBuf.append(errorCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("statusDescription :");
        tempStringBuf.append(statusDescription);
        tempStringBuf.append(" | ");
        tempStringBuf.append("bankSystem :");
        tempStringBuf.append(bankSystem);
        tempStringBuf.append(" | ");
        tempStringBuf.append("bankCode :");
        tempStringBuf.append(bankCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("txnno :");
        tempStringBuf.append(txnNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append("stepId :");
        tempStringBuf.append(stepId);
        tempStringBuf.append(" | ");
        tempStringBuf.append("debitAcccountNo :");
        tempStringBuf.append(debitAcccountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append("debitBranchCode :");
        tempStringBuf.append(debitBranchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("creditAccountNo :");
        tempStringBuf.append(creditAccountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append("creditBranchCode :");
        tempStringBuf.append(creditBranchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("amount :");
        tempStringBuf.append(amount);
        tempStringBuf.append(" | ");
        tempStringBuf.append("responseString :");
        tempStringBuf.append(responseString);
        tempStringBuf.append(" | ");
        tempStringBuf.append("transactionLeg :");
        tempStringBuf.append(transactionLeg);
        tempStringBuf.append(" | ");
        tempStringBuf.append("originalDebitReferenceNo :");
        tempStringBuf.append(originalDebitReferenceNo);
        
        return tempStringBuf.toString();
    } 
	
	private String referenceNo;
	
	private String requestString;
	
	private String status;
	
	private String errorCode;
	
	private String statusDescription;
	
	private String bankSystem;
	
	private String bankCode;
	
	private String txnNo;
	
	private String stepId;
	
	private String debitAcccountNo;
	
	private String debitBranchCode;
	
	private String creditAccountNo;
	
	private String creditBranchCode;
	
	private Double amount;
	
	private String responseString;
	
	private String transactionLeg;
	
	private String originalDebitReferenceNo;
	
	public String getCreditAccountNo() {
		return creditAccountNo;
	}

	public void setCreditAccountNo(String creditAccountNo) {
		this.creditAccountNo = creditAccountNo;
	}

	public String getCreditBranchCode() {
		return creditBranchCode;
	}

	public void setCreditBranchCode(String creditBranchCode) {
		this.creditBranchCode = creditBranchCode;
	}

	public String getDebitAcccountNo() {
		return debitAcccountNo;
	}

	public void setDebitAcccountNo(String debitAcccountNo) {
		this.debitAcccountNo = debitAcccountNo;
	}

	public String getDebitBranchCode() {
		return debitBranchCode;
	}

	public void setDebitBranchCode(String debitBranchCode) {
		this.debitBranchCode = debitBranchCode;
	}

	public String getTransactionLeg() {
		return transactionLeg;
	}

	public void setTransactionLeg(String transactionLeg) {
		this.transactionLeg = transactionLeg;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankSystem() {
		return bankSystem;
	}

	public void setBankSystem(String bankSystem) {
		this.bankSystem = bankSystem;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getRequestString() {
		return requestString;
	}

	public void setRequestString(String requestString) {
		this.requestString = requestString;
	}

	public String getStatus() {
		//if the bank system is core and status = 'ERR.' and error_code 
		//in ('0155','0112','0160','a','b') status = 'REP.'
		Set set = new HashSet();
		set.add("0155");
		set.add("0112");
		set.add("0160");
		String statusString = status;
		if( this.status != null && status.equalsIgnoreCase( "ERR." ) && set.contains(this.errorCode))
			statusString="REP.";
		if( this.status.equalsIgnoreCase("U"))
			statusString="LOG.";
		else if(this.status.equalsIgnoreCase("P"))
			statusString="00";
		return statusString;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}

	public String getResponseString() {
		return responseString;
	}

	public void setResponseString(String responseString) {
		this.responseString = responseString;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getOriginalDebitReferenceNo() {
		return originalDebitReferenceNo;
	}

	public void setOriginalDebitReferenceNo(String originalDebitReferenceNo) {
		this.originalDebitReferenceNo = originalDebitReferenceNo;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTxnNo() {
		return txnNo;
	}

	public void setTxnNo(String txnNo) {
		this.txnNo = txnNo;
	}
}