/** 
 * @(#) LoanAccountDetails.java
 */

package com.sbi.common.model;

public class LoanAccountDetails extends AccountDetails
{
        private Double sanctionedLimit;
        
        private Double interestRate;
        
        private Double drawingPower;
        
        private Double amountOutStanding;
        
        private Double sanctionedAmount;
        
        
     // CR -147 start
    	private Double currentYearInterest;

    	private Double previousYearInterest;
    	
    	private String ifsCode;
        
        public String getIfsCode() {
			return ifsCode;
		}
        
        public void setIfsCode(String ifsCode) {
			this.ifsCode = ifsCode;
		}
    	
    	public Double getCurrentYearInterest() {
    		return currentYearInterest;
    	}

    	public Double getPreviousYearInterest() {
    		return previousYearInterest;
    	}
    	public void setCurrentYearInterest(Double currentYearInterest) {
    		this.currentYearInterest = currentYearInterest;
    	}

    	public void setPreviousYearInterest(Double previousYearInterest) {
    		this.previousYearInterest = previousYearInterest;
    	}
    	// CR - 147 end
        public void setSanctionedLimit( Double sanctionedLimit )
        {
                this.sanctionedLimit=sanctionedLimit;
        }
        
        public Double getSanctionedLimit( )
        {
                return sanctionedLimit;
        }
        
        public void setInterestRate( Double interestRate )
        {
                this.interestRate=interestRate;
        }
        
        public Double getInterestRate( )
        {
                return interestRate;
        }
        
        public void setDrawingPower( Double drawingPower )
        {
                this.drawingPower=drawingPower;
        }
        
        public Double getDrawingPower( )
        {
                return drawingPower;
        }
        
        public void setAmountOutStanding( Double amountOutStanding )
        {
                this.amountOutStanding=amountOutStanding;
        }
        
        public Double getAmountOutStanding( )
        {
                return amountOutStanding;
        }
        
        public void setSanctionedAmount( Double sanctionedAmount )
        {
                this.sanctionedAmount=sanctionedAmount;
        }
        
        public Double getSanctionedAmount( )
        {
                return sanctionedAmount;
        }
        
        public String toString()
        {
        	StringBuffer tempStringBuf =new StringBuffer();
        	
        	tempStringBuf.append(sanctionedLimit);
        	tempStringBuf.append("|");
        	tempStringBuf.append(interestRate);
        	tempStringBuf.append("|");
        	tempStringBuf.append(drawingPower);
        	tempStringBuf.append("|");
        	tempStringBuf.append(amountOutStanding);
        	tempStringBuf.append("|");
        	tempStringBuf.append(sanctionedAmount);
        	tempStringBuf.append("|");
        	
        	
        	return tempStringBuf.toString();
        }
        
        
}
