/*
 * Account.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
package com.sbi.common.model;

public class Branch implements BaseModel
{

   
    private String branchCode;

    private String branchName;

      /**
     * Field specifies whether account belongs to core or non core
     */
    private String bankSystem;

    private String userCount;
    
    private String bankCode;

    private String availability;

   

    public void setBranchCode(String branchCode)
    {
        this.branchCode= branchCode;
    }

    public String getBranchCode()
    {
        return branchCode;
    }
   
   
    public void setBranchName(String branchName)
    {
        this.branchName= branchName;
    }

    public String getBranchName()
    {
        return branchName;
    }
   
  
    public void setBankSystem(String bankSystem)
    {
        this.bankSystem = bankSystem;
    }

    public String getBankSystem()
    {
        return bankSystem;
    }

   
   
    public void setUserCount(String userCount)
    {
        this.userCount = userCount;
    }

    public String getUserCount()
    {
        return userCount;
    }
  
       
    
    public void setBankCode(String bankCode)
    {
        this.bankCode = bankCode;
    }

    public String getBankCode()
    {
        return bankCode;
    }

     
    
    public void setAvailability(String availability)
    {
        this.availability = availability;
    }

    public String getAvailability()
    {
        return availability;
    }
    
     
    
}
    
    
  