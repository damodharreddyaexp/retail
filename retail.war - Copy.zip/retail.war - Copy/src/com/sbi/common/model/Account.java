/* 
 * Account.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//Oct 25, 2005 Srinivas - added toString method.
//nov 24, 2005 BOOPATHI - added productType instead of accountType
package com.sbi.common.model;

import java.sql.Timestamp;
		
public class Account implements BaseModel
{
    private String userName;
         
    private String accountNo;

    private String branchCode;

    private String branchName;
    
    private String accountNature;

    private Double balance;
    
       /**
     * Field specifies whether account belongs to core or non core
     */
    private String bankSystem;

    private String currency;

    private String productType;

    private String accountType;
    private String accountNickName;

    private Boolean creditable;

    private Integer accessLevel;
    
    private String productDescription;
    
    private String coreMigrationDisplay;
    
    private String productCode;  // added by Ponnusamy G
    //Added for E-suvidha
    private String parentAccountNo;
    private String benMobileNo;
    private String benEmailId;
    private Integer customerAccessLevel;
    private Integer branchAccessLevel;
    private String rtgsCode;
    private String neftCode;
    private String grptCode;
    private String limitStatus;
    private String charityID;
    private String charityName;
    private String charityDesc;
    private String charityMaxLimit;
    private String charityEHSLimit;
    private String charityHelpLinkPath;
    private String tpStatus;
    private String refNo;
    
  //Added for E-suvidha end
    
    private Integer accountLockFlag;  // added by Murugan to find whether user locked or not for a account.
    
    private Double limit;
    
    //Added for RTGS
    
    private String rtgsIFSCCode;
    
    private String neftIFSCCode;
    
    private String userAlias;//pending statement
    private String anaklynFlag;//pending statement
    
   

	// supplier credit account for RTGS
  //Added / Modified by Manivannan on 17 Dec 2010 for GVF RTGS CR#5602,5594 STARTS
	private String ifscCode;
	private String bankNameRTGS;
	private String branchNameRTGS;
	private String bankCode;
	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	//Added for etdr
	private String preCloseStatus;
    
    public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getBankNameRTGS() {
		return bankNameRTGS;
	}

	public void setBankNameRTGS(String bankNameRTGS) {
		this.bankNameRTGS = bankNameRTGS;
	}

	public String getBranchNameRTGS() {
		return branchNameRTGS;
	}

	public void setBranchNameRTGS(String branchNameRTGS) {
		this.branchNameRTGS = branchNameRTGS;
	}
	
	//Added / Modified by Manivannan on 17 Dec 2010 for GVF RTGS CR#5602,5594 ENDS
    
    private String txnType;
    
    private String businessLineId;
    
    private String grptFlag;// If GRPT='Y' then GRPT is enabled for a branch. 
  //Added for CR 5507
    
    private Double interestRate;

	
	private Double maturityAmount;
    
    private Timestamp maturityDate;
    
    private Double principal;
    
    private Double accumulatedInterest;
    
	private Timestamp openingDate;
    
    private Integer tenorDays;
    
    private Integer tenorMonth;
    
    private Integer tenorYear;
    
    private String profileUserName;

	private Integer tenorINDays;
	//Ends

	//---5603
	
	private String employeeCode;
	
	private String mobileNo;
	
	private String emailId;

	//---5603

//	IR 71227
	
	private String brokerStmtFlag;
	
	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(Double maturityAmount) {
		this.maturityAmount = maturityAmount;
	}

	public Timestamp getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(Timestamp maturityDate) {
		this.maturityDate = maturityDate;
	}

	public Double getPrincipal() {
		return principal;
	}

	public void setPrincipal(Double principal) {
		this.principal = principal;
	}

	public Double getAccumulatedInterest() {
		return accumulatedInterest;
	}

	public void setAccumulatedInterest(Double accumulatedInterest) {
		this.accumulatedInterest = accumulatedInterest;
	}

	public Timestamp getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(Timestamp openingDate) {
		this.openingDate = openingDate;
	}

	public Integer getTenorDays() {
		return tenorDays;
	}

	public void setTenorDays(Integer tenorDays) {
		this.tenorDays = tenorDays;
	}

	public Integer getTenorMonth() {
		return tenorMonth;
	}

	public void setTenorMonth(Integer tenorMonth) {
		this.tenorMonth = tenorMonth;
	}

	public Integer getTenorYear() {
		return tenorYear;
	}

	public void setTenorYear(Integer tenorYear) {
		this.tenorYear = tenorYear;
	}

	public String getProfileUserName() {
		return profileUserName;
	}

	public void setProfileUserName(String profileUserName) {
		this.profileUserName = profileUserName;
	}

	public Integer getTenorINDays() {
		return tenorINDays;
	}

	public void setTenorINDays(Integer tenorINDays) {
		this.tenorINDays = tenorINDays;
	}

    
   
    public String getBusinessLineId() {
		return businessLineId;
	}

	public void setBusinessLineId(String businessLineId) {
		this.businessLineId = businessLineId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getCoreMigrationDisplay() {
        return coreMigrationDisplay;
    }

    public void setCoreMigrationDisplay(String coreMigrationDisplay) {
        this.coreMigrationDisplay = coreMigrationDisplay;
    }

    public String getProductDescription()
    {
        return this.productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

    public void setAccountNo(String accountNo)
    {
        this.accountNo = accountNo;
    }

    public String getAccountNo()
    {
        return this.accountNo;
    }

    public void setBranchCode(String branchCode)
    {
        this.branchCode = branchCode;
    }

    public String getBranchCode()
    {
        return this.branchCode;
    }

    public void setBranchName(String branchName)
    {
        this.branchName = branchName;
    }

    public String getBranchName()
    {
        return this.branchName;
    }

    public void setBalance(Double balance)
    {
        this.balance = balance;
    }

    public Double getBalance()
    {
        return this.balance;
    }

    public void setBankSystem(String bankSystem)
    {
        this.bankSystem = bankSystem;
    }

    public String getBankSystem()
    {
        return this.bankSystem;
    } 

    public void setCurrency(String currency)
    {
        this.currency = currency;
    }

    public String getCurrency()
    {
        return this.currency;
    }

    public void setProductType(String productType)
    {
        this.productType = productType;
    }

    public String getProductType()
    {
        return this.productType;
    }
    public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
    public void setAccountNickName(String accountNickName)
    {
        this.accountNickName = accountNickName;
    }

    public String getAccountNickName()
    {
        return this.accountNickName;
    }

    public void setCreditable(Boolean creditable)
    {
        this.creditable = creditable;
    }

    public Boolean isCreditable()
    {
        return this.creditable;
    }

    public void setAccessLevel(Integer accessLevel)
    {
        this.accessLevel = accessLevel;
    }

    public Integer getAccessLevel()
    {
        return this.accessLevel;
    }
    
    public String getAccountNature(){
        return this.accountNature;
    }
    
    public void setAccountNature(String accountNature){
        this.accountNature = accountNature;
    }

    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(accountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(balance);
        tempStringBuf.append(" | ");
        tempStringBuf.append(bankSystem);
        tempStringBuf.append(" | ");
        tempStringBuf.append(currency);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountNickName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(creditable);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accessLevel);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountNature);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productDescription); 
        tempStringBuf.append(" | ");
        tempStringBuf.append(productCode);
        tempStringBuf.append(" |LogFlag: ");
        tempStringBuf.append(accountLockFlag);
        tempStringBuf.append(" | ");
        tempStringBuf.append(" rtgsIFSCCode ");
        tempStringBuf.append(rtgsIFSCCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(" neftIFSCCode ");
        tempStringBuf.append(neftIFSCCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(" txnType ");
        tempStringBuf.append(txnType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(" gRPTFlag ");
        tempStringBuf.append(grptFlag);
        tempStringBuf.append(" | ");
        tempStringBuf.append(userAlias);
        tempStringBuf.append(" | ");//pending statement       
        tempStringBuf.append(anaklynFlag);
        tempStringBuf.append(" | ");//pending statement
        
        
        return tempStringBuf.toString();
    } 

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Double getLimit() {
		return limit;
	}

	public void setLimit(Double limit) {
		this.limit = limit;
	}

    public Integer getAccountLockFlag() {
        return accountLockFlag;
    }

    public void setAccountLockFlag(Integer accountLockFlag) {
        this.accountLockFlag = accountLockFlag;
    }


	public String getNeftIFSCCode() {
		return neftIFSCCode;
	}

	public void setNeftIFSCCode(String neftIFSCCode) {
		this.neftIFSCCode = neftIFSCCode;
	}

	public String getRtgsIFSCCode() {
		return rtgsIFSCCode;
	}

	public void setRtgsIFSCCode(String rtgsIFSCCode) {
		this.rtgsIFSCCode = rtgsIFSCCode;
	}

	public String getGrptFlag() {
		return grptFlag;
	}

	public void setGrptFlag(String grptFlag) {
		this.grptFlag = grptFlag;
	}
	
//---5603
	
	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	//---end of 5603
	
	public String getBrokerStmtFlag() {
		return brokerStmtFlag;
	}

	public void setBrokerStmtFlag(String brokerStmtFlag) {
		this.brokerStmtFlag = brokerStmtFlag;
	} 
	
	
		//---end of 5603
	
	//pending Statement
	
	 public String getUserAlias() {
			return userAlias;
		}

		public void setUserAlias(String userAlias) {
			this.userAlias = userAlias;
		}
	
	
	 public String getAnaklynFlag() {
			return anaklynFlag;
		}

		public void setAnaklynFlag(String anaklynFlag) {
			this.anaklynFlag = anaklynFlag;
		}

		public String getParentAccountNo() {
			return parentAccountNo;
		}

		public void setParentAccountNo(String parentAccountNo) {
			this.parentAccountNo = parentAccountNo;
		}

		public String getBenMobileNo() {
			return benMobileNo;
		}

		public void setBenMobileNo(String benMobileNo) {
			this.benMobileNo = benMobileNo;
		}

		public String getBenEmailId() {
			return benEmailId;
		}

		public void setBenEmailId(String benEmailId) {
			this.benEmailId = benEmailId;
		}

		public Integer getCustomerAccessLevel() {
			return customerAccessLevel;
		}

		public void setCustomerAccessLevel(Integer customerAccessLevel) {
			this.customerAccessLevel = customerAccessLevel;
		}

		public Integer getBranchAccessLevel() {
			return branchAccessLevel;
		}

		public void setBranchAccessLevel(Integer branchAccessLevel) {
			this.branchAccessLevel = branchAccessLevel;
		}

		public String getRtgsCode() {
			return rtgsCode;
		}

		public void setRtgsCode(String rtgsCode) {
			this.rtgsCode = rtgsCode;
		}

		public String getNeftCode() {
			return neftCode;
		}

		public void setNeftCode(String neftCode) {
			this.neftCode = neftCode;
		}

		public String getGrptCode() {
			return grptCode;
		}

		public void setGrptCode(String grptCode) {
			this.grptCode = grptCode;
		}

		/*public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}*/

		public String getCharityID() {
			return charityID;
		}

		public void setCharityID(String charityID) {
			this.charityID = charityID;
		}

		public String getCharityName() {
			return charityName;
		}

		public void setCharityName(String charityName) {
			this.charityName = charityName;
		}

		public String getCharityDesc() {
			return charityDesc;
		}

		public void setCharityDesc(String charityDesc) {
			this.charityDesc = charityDesc;
		}

		public String getCharityMaxLimit() {
			return charityMaxLimit;
		}

		public void setCharityMaxLimit(String charityMaxLimit) {
			this.charityMaxLimit = charityMaxLimit;
		}

		public String getCharityEHSLimit() {
			return charityEHSLimit;
		}

		public void setCharityEHSLimit(String charityEHSLimit) {
			this.charityEHSLimit = charityEHSLimit;
		}

		public String getCharityHelpLinkPath() {
			return charityHelpLinkPath;
		}

		public void setCharityHelpLinkPath(String charityHelpLinkPath) {
			this.charityHelpLinkPath = charityHelpLinkPath;
		}

		public Boolean getCreditable() {
			return creditable;
		}

		public String getTpStatus() {
			return tpStatus;
		}

		public void setTpStatus(String tpStatus) {
			this.tpStatus = tpStatus;
		}

		public String getRefNo() {
			return refNo;
		}

		public void setRefNo(String refNo) {
			this.refNo = refNo;
		}
		public String getLimitStatus() {
			return limitStatus;
		}

		public void setLimitStatus(String limitStatus) {
			this.limitStatus = limitStatus;
		}

		public String getPreCloseStatus() {
			return preCloseStatus;
		}

		public void setPreCloseStatus(String preCloseStatus) {
			this.preCloseStatus = preCloseStatus;
		}

} 
