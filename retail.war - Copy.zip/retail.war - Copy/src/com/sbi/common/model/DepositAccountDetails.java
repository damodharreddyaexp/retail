/** 
 * @(#) DepositAccountDetails.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class DepositAccountDetails extends AccountDetails
{
        private Timestamp maturityDate;
        
        private Double maturityAmount;
        
        private Double drawingPower;
        
        private Double creditInterestRate;
        
        private Double balanceAsDate;
        
        private Double principal;
        
        public void setMaturityDate( Timestamp maturityDate )
        {
                this.maturityDate=maturityDate;
        }
        
        public Timestamp getMaturityDate( )
        {
                return maturityDate;
        }
        
        public void setMaturityAmount( Double maturityAmount )
        {
                this.maturityAmount=maturityAmount;
        }
        
        public Double getMaturityAmount( )
        {
                return maturityAmount;
        }
        
        public void setDrawingPower( Double drawingPower )
        {
                this.drawingPower=drawingPower;
        }
        
        public Double getDrawingPower( )
        {
                return drawingPower;
        }
        
        public void setCreditInterestRate( Double creditInterestRate )
        {
                this.creditInterestRate=creditInterestRate;
        }
        
        public Double getCreditInterestRate( )
        {
                return creditInterestRate;
        }
        
        public void setBalanceAsDate( Double balanceAsDate )
        {
                this.balanceAsDate=balanceAsDate;
        }
        
        public Double getBalanceAsDate( )
        {
                return balanceAsDate;
        }
        
        public void setPrincipal( Double principal )
        {
                this.principal=principal;
        }
        
        public Double getPrincipal( )
        {
                return principal;
        }
        
        public String toString()
        {
        	StringBuffer tempStringBuf = new StringBuffer();
        	
        	tempStringBuf.append(maturityDate);
        	tempStringBuf.append("|");
        	tempStringBuf.append(drawingPower);
        	tempStringBuf.append("|");
        	tempStringBuf.append(creditInterestRate);
        	tempStringBuf.append("|");
        	tempStringBuf.append(balanceAsDate);
        	tempStringBuf.append("|");
        	tempStringBuf.append(principal);
        	tempStringBuf.append("|");
        	
        	
         return tempStringBuf.toString();
        	     	
        }
        
}
