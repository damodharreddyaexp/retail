package com.sbi.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CategoryPenalty implements Serializable{
 
	private Date fromDate;
	private Date toDate;  
	private int penaltyOrder;
	private int penaltyAmount;
	private String penaltyAmtType;
	private List penaltyList;
	String showLatefee;
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public int getPenaltyOrder() {
		return penaltyOrder;
	}
	public void setPenaltyOrder(int penaltyOrder) {
		this.penaltyOrder = penaltyOrder;
	}

	public int getPenaltyAmount() {
		return penaltyAmount;
	}
	public void setPenaltyAmount(int penaltyAmount) {
		this.penaltyAmount = penaltyAmount;
	}
	public String getPenaltyAmtType() {
		return penaltyAmtType;
	}
	public void setPenaltyAmtType(String penaltyAmtType) {
		this.penaltyAmtType = penaltyAmtType;
	}
	public List getPenaltyList() {
		return penaltyList;
	}
	public void setPenaltyList(List penaltyList) {
		this.penaltyList = penaltyList;
	}
	public String getShowLatefee() {
		return showLatefee;
	}
	public void setShowLatefee(String showLatefee) {
		this.showLatefee = showLatefee;
	}
	
	
	
}
