package com.sbi.common.model;
/**
 * 
 * @author LP49927
 * Query model for handling Previledged users link wise in Corp Dynamic Links
 */
public class Query {
	private String query;
	private String queryType;
	private String matchingValue;
	private String objectName;
	private String functionName;
	
	public String getMatchingValue() {
		return matchingValue;
	}
	public void setMatchingValue(String matchingValue) {
		this.matchingValue = matchingValue;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getQueryType() {
		return queryType;
	}
	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	
}
