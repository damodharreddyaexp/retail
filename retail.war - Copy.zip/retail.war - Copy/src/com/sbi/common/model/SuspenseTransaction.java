/**
 * @(#) SuspenseTransaction.java
 */

package com.sbi.common.model;

public class SuspenseTransaction implements BaseModel
{
        private String referenceNo;
        
        private String suspenseReferenceNo;
        
        private String debitBranch;
        
        private String creditBranch;
        
        private Float amount;
        
        private String tTypeCode;
        
        private String system;
        
        private String statusCode;
        
        public void setReferenceNo( String referenceNo )
        {
                this.referenceNo=referenceNo;
        }
        
        public String getReferenceNo( )
        {
                return referenceNo;
        }
        
        public void setSuspenseReferenceNo( String suspenseReferenceNo )
        {
                this.suspenseReferenceNo=suspenseReferenceNo;
        }
        
        public String getSuspenseReferenceNo( )
        {
                return suspenseReferenceNo;
        }
        
        public void setDebitBranch( String debitBranch )
        {
                this.debitBranch=debitBranch;
        }
        
        public String getDebitBranch( )
        {
                return debitBranch;
        }
        
        public void setCreditBranch( String creditBranch )
        {
                this.creditBranch=creditBranch;
        }
        
        public String getCreditBranch( )
        {
                return creditBranch;
        }
        
        public void setAmount( Float amount )
        {
                this.amount=amount;
        }
        
        public Float getAmount( )
        {
                return amount;
        }
        
        public void setTTypeCode( String tTypeCode )
        {
                this.tTypeCode=tTypeCode;
        }
        
        public String getTTypeCode( )
        {
                return tTypeCode;
        }
        
        public void setSystem( String system )
        {
                this.system=system;
        }
        
        public String getSystem( )
        {
                return system;
        }
        
        public void setStatusCode( String statusCode )
        {
                this.statusCode=statusCode;
        }
        
        public String getStatusCode( )
        {
                return statusCode;
        }
        
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(referenceNo);
        	tempStringBuf.append("|");
        	tempStringBuf.append(suspenseReferenceNo);
        	tempStringBuf.append("|");
        	tempStringBuf.append(debitBranch);
        	tempStringBuf.append("|");
        	tempStringBuf.append(creditBranch);
        	tempStringBuf.append("|");
        	tempStringBuf.append(amount);
        	tempStringBuf.append("|");
          	tempStringBuf.append(tTypeCode);
        	tempStringBuf.append("|");
        	tempStringBuf.append(system);
        	tempStringBuf.append("|");
        	tempStringBuf.append(statusCode);
        	tempStringBuf.append("|");
        	
        	return tempStringBuf.toString();
        	
        	
        }
        
}

