/** 
 * @(#) User.java
 */
  
package com.sbi.common.model;

import java.util.List;

public class User implements BaseModel
{
        private Integer userId;
        
        private String userAlias;
        
        private String password;
        
        private String userState;
        
        private String modifiedTime;
        
        private Double thirdPartyLimit;
        
        private Double PPFlimit;
        
        private Address address;
        
        private String bankCode;
        
        private List roles;
        
        private String userIPaddress;
        
        private Integer userType;
        
        private String corporateId;

        private String empNo;
        
        private String branchCode;
        
        private String name;
        
        private String passwordMode;    //Added for CR 5550 by Immanuel for Forced login
        
        private String createdBy;
        
        private String newsPreference1; //Added for CR-159 anaklynrevamp
        
        /**
         * @return Returns the name.
         */
        public String getName()
        {
            return name;
        } 

        /**
         * @param name The name to set.
         */
        public void setName(String name)
        {
            this.name = name;
        }

       public String getEmpNo() {
			return empNo;
		}

		public void setEmpNo(String empNo) {
			this.empNo = empNo;
		}

		

		public void setUserIPaddress(String userIPaddress) {
			this.userIPaddress = userIPaddress;
		}

		public void setUserId( Integer userId )
        {
                this.userId=userId;
        }
        
        public Integer getUserId( )
        {
                return userId;
        }
         
        public void setUserAlias( String userAlias )
        {
                this.userAlias=userAlias;
        }
        
        public String getUserAlias( )
        {
                return userAlias;
        }
        
        public void setPassword( String password )
        {
                this.password=password;
        }
        
        public String getPassword( )
        {
                return password;
        }
         
        public void setUserState( String userState )
        {
                this.userState=userState;
        }
        
        public String getUserState( )
        {
                return userState;
        }
        
        public void setModifiedTime( String modifiedTime )
        {
                this.modifiedTime=modifiedTime;
        }
        
        public String getModifiedTime( )
        {
                return modifiedTime;
        }
       
        /**
         * @return Returns the userType.
         */
        public Integer getUserType()
        {
            return userType;
        }

        /**
         * @param userType The userType to set.
         */
        public void setUserType(Integer userType)
        {
            this.userType = userType;
        }
        
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(userId);
        	tempStringBuf.append("|");
        	tempStringBuf.append(userAlias);
        	tempStringBuf.append("|");
        	tempStringBuf.append(password);
        	tempStringBuf.append("|");
          	tempStringBuf.append(userState);
        	tempStringBuf.append("|");
        	tempStringBuf.append(modifiedTime);
        	tempStringBuf.append("|");
            tempStringBuf.append(userType);
            tempStringBuf.append("|");
            tempStringBuf.append(branchCode);
 
            return tempStringBuf.toString();
        }

        public Address getAddress() {
            return address;
        }

        public void setAddress(Address address) {
            this.address = address;
        }

        public String getBankCode() {
            return bankCode;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public Double getPPFlimit() {
            return PPFlimit;
        }

        public void setPPFlimit(Double flimit) {
            PPFlimit = flimit;
        }

        public Double getThirdPartyLimit() {
            return thirdPartyLimit;
        }

        public void setThirdPartyLimit(Double thirdPartyLimit) {
            this.thirdPartyLimit = thirdPartyLimit;
        }

        public List getRoles() {
            return roles;
        }

        public void setRoles(List roles) {
            this.roles = roles;
        }

        public String getCorporateId() {
            return corporateId;
        }

        public void setCorporateId(String corporateId) {
            this.corporateId = corporateId;
        }

        /**
         * @return Returns the branchCode.
         */
        public String getBranchCode()
        {
            return branchCode;
        }

        /**
         * @param branchCode The branchCode to set.
         */
        public void setBranchCode(String branchCode)
        {
            this.branchCode = branchCode;
        }

        /**
         * @return Returns the userIPaddress.
         */
        public String getUserIPaddress()
        {
            return userIPaddress;
        }

		public String getPasswordMode() {
			return passwordMode;
		}

		public void setPasswordMode(String passwordMode) {
			this.passwordMode = passwordMode;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getNewsPreference1() {
			return newsPreference1;
		}

		public void setNewsPreference1(String newsPreference1) {
			this.newsPreference1 = newsPreference1;
		}

      

      
                   
}  
