/* 
 *  C9UserProfile.java  
 * Created on Mar 6, 2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */  
//History
//Feb 6, 2011 Amar - Initial Creation

package com.sbi.common.model;



/**
 * TODO This class is used to set and get the  UserProfile's properties
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class CertificateDetails
{
      

   private String referenceNo;
    private String commonName;
    private String issuerName;
    private String role;
    private String expDate;
    private String serialNo;
    
	public String toString() 
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
            tempStringBuf.append("commonName :");
            tempStringBuf.append(commonName);
            
            tempStringBuf.append("|");
            tempStringBuf.append("issuerName :");
            tempStringBuf.append(issuerName);
            
            tempStringBuf.append("|");
            tempStringBuf.append("role :");
            tempStringBuf.append(role);
            
            tempStringBuf.append("|");
            tempStringBuf.append("expDate :");
            tempStringBuf.append(expDate);
            
            tempStringBuf.append("|");
            
            tempStringBuf.append("referenceNo :");
            tempStringBuf.append(referenceNo);
            
            tempStringBuf.append("|");
            
        	return tempStringBuf.toString();
        	
        }

	

	public String getReferenceNo() {
		return referenceNo;
	}



	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}



	public String getCommonName() {
		return commonName;
	}



	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}



	public String getIssuerName() {
		return issuerName;
	}



	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public String getExpDate() {
		return expDate;
	}



	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}



	public String getSerialNo() {
		return serialNo;
	}



	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

       
       
   } 