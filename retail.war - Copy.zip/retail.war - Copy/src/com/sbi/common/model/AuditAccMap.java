/**
 * @(#) AuditAccMap.java
 */

package com.sbi.common.model;

import com.sbi.common.model.Account;
public class AuditAccMap extends Account
{
	
	private String caUser;
	
	private Integer  maxUnauditedCount;
	
	private Double maxUnauditedAmount;
	
	private String lockFlag;
	
	private String oldUserName;
	
	private String displayFlag;
    
   // private Integer oid;
	
	private Long  oid;

    
    /**
     * @return Returns the oid.
     */
   /* public Integer getOid()
    {
        return oid;
    }

    *//**
     * @param oid The oid to set.
     *//*
    public void setOid(Integer oid)
    {
        this.oid = oid;
    }*/

	
	public Long  getOid()
    {
        return oid;
    }

  
    public void setOid(Long oid)
    {
        this.oid = oid;
    }
	
    
    /**
     * @return Returns the caUser.
     */
    public String getCaUser()
    {
        return caUser;
    }

    /**
     * @param caUser The caUser to set.
     */
    public void setCaUser(String caUser)
    {
        this.caUser = caUser;
    }

    /**
     * @param displayFlag The displayFlag to set.
     */
    public void setDisplayFlag(String displayFlag)
    {
        this.displayFlag = displayFlag;
    }

    /**
     * @return Returns the maxUnauditedAmount.
     */
    public Double getMaxUnauditedAmount()
    {
        return maxUnauditedAmount;
    }

    /**
     * @param maxUnauditedAmount The maxUnauditedAmount to set.
     */
    public void setMaxUnauditedAmount(Double maxUnauditedAmount)
    {
        this.maxUnauditedAmount = maxUnauditedAmount;
    }

    

    /**
     * @return Returns the oldUserName.
     */
    public String getOldUserName()
    {
        return oldUserName;
    }

    /**
     * @param oldUserName The oldUserName to set.
     */
    public void setOldUserName(String oldUserName)
    {
        this.oldUserName = oldUserName;
    }

        /**
     * @return Returns the maxUnauditedCount.
     */
    public Integer getMaxUnauditedCount()
    {
        return maxUnauditedCount;
    }

    /**
     * @param maxUnauditedCount The maxUnauditedCount to set.
     */
    public void setMaxUnauditedCount(Integer maxUnauditedCount)
    {
        this.maxUnauditedCount = maxUnauditedCount;
    }

	public String getLockFlag() {
		return lockFlag;
	}

	public void setLockFlag(String lockFlag) {
		this.lockFlag = lockFlag;
	}

	public String getDisplayFlag() {
		return displayFlag;
	}

   
	
	
}
