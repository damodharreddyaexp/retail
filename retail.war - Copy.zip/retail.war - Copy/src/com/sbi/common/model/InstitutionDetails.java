package com.sbi.common.model;

import java.util.List;

import com.sbi.common.model.BaseModel;

public class InstitutionDetails implements BaseModel{

	private String state;
	private String institutionType;
	private String instituteId;
	private String institutionName;
	private String corpID;
	private String corpName;
	private String address;
	private String status;
	private String logoPath;
	private List categoryList;
	
	 public String getInstituteId() {
		return instituteId;
	}

	public void setInstituteId(String instituteId) {
		this.instituteId = instituteId;
	}

	public String getInstitutionType() {
		return institutionType;
	}
	public void setInstitutionType(String institutionType) {
		this.institutionType = institutionType;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public String toString(){
		 
        StringBuffer tempStringBuf = new StringBuffer();
        
        tempStringBuf.append("instituteId :");
        tempStringBuf.append(instituteId);
        tempStringBuf.append(" | ");
        tempStringBuf.append("institutionName :");
        tempStringBuf.append(institutionName);
        tempStringBuf.append(" | ");
        tempStringBuf.append("institutionType :");
        tempStringBuf.append(institutionType);
        tempStringBuf.append(" | ");
        tempStringBuf.append("state :");
        tempStringBuf.append(state);
        tempStringBuf.append(" | ");
        tempStringBuf.append("corpID :");
        tempStringBuf.append(corpID);
        tempStringBuf.append(" | ");
        tempStringBuf.append("corpName :");
        tempStringBuf.append(corpName);
        tempStringBuf.append(" | ");
        tempStringBuf.append("address :");
        tempStringBuf.append(address);
        tempStringBuf.append(" | ");
        tempStringBuf.append("status :");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        tempStringBuf.append("logoPath :");
        tempStringBuf.append(logoPath);
        tempStringBuf.append(" | ");
        tempStringBuf.append("categoryList :");
        tempStringBuf.append(categoryList);
        tempStringBuf.append(" | ");
        
        return tempStringBuf.toString();
    }

	public String getCorpID() {
		return corpID;
	}

	public void setCorpID(String corpID) {
		this.corpID = corpID;
	}

	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List categoryList) {
		this.categoryList = categoryList;
	}

	public String getLogoPath() {
		return logoPath;
	}

	public void setLogoPath(String logoPath) {
		this.logoPath = logoPath;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
