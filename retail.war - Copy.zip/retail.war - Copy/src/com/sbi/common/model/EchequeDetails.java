package com.sbi.common.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * 
 * This class holds the contents to be displayed as Echeque Details for the
 * Approve Test Transactions module
 * 
 * @author Easwar Prasad
 * @version 1.0
 */
public class EchequeDetails implements Serializable {

	//private Logger logger = Logger.getLogger(getClass());
	
	private String beneficiary;

	private String accountNo;

	private String maker;

	private Double echequeAmount;

	private String branchName;

	private String firstauth;

	

	private String secondauth;

	private String approver;

	private String echequeNo;

	private String status;

	private String corpRefNo;
	
	private String CorporateId;

	private String transactionType;

	private String creditAccountNo;

	private String creditBranchName;

	private String beneficiaryName;

	private Timestamp scheduledDate;
	
	private String dealerCode;

	private int authType;

	private String amountInWords;
	
	private String description;
	
	private boolean confApproved;
	
	// RTGS/NEFT - begin
	private String rateOfInterest;
	
	private String merchantCode;
	// RTGS/NEFT - End
	
	private String creditStatus; //changed for CR 3082
	
	//System.out.println("");
      
    //added by siva for CBEC starts here
        
    private String label;
    
    private String value;
    
    //added by siva for CBEC ends here
    
    //added by siva for prepaid card starts here
    private String cardNo;
    
    private String cardReferenceNo;
    
    private String cardHolderName;
    
    private String failureReason;
    //cr5531
    private String currentAuthLevel;
    
	private String branchCode;
    private Date date;
    //CR 5531III
    private String commission;
    private String debit_account;
    private String debit_branch;
    private String debit_ref_no;
    public String getCredit_status_description() {
		return credit_status_description;
	}

	private String credit_status_description;
    private String auth1_date;
    private String auth2_date;
    private String credit_ref_no;
    private String  utr_no;
    private String  debit_amount;
    
    //Added for Cr 5615
    private String  utr_posted_time;
    private String  utr_status;
    
    
    //Added by Sairam for CINB Reports
    private String creationtime;
   
    private String fileName;

    //Added for eTDR/eSTDR -Start
    private String reasonFailure;

    private String cancelledBy;

    private String postedDate;

    private String debitStatus;

    private double amount;
    
    private String displayFlag;
    
    private String referenceNo;
	//Added for eTDR/eSTDR -End

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getCreationtime() {
		return creationtime;
	}

	public void setCreationtime(String creationtime) {
		this.creationtime = creationtime;
	}

	public String getUtr_posted_time() {
		return utr_posted_time;
	}

	public void setUtr_posted_time(String utr_posted_time) {
		this.utr_posted_time = utr_posted_time;
	}

	public String getUtr_status() {
		return utr_status;
	}

	public void setUtr_status(String utr_status) {
		this.utr_status = utr_status;
	}

	//CR 5615 ends
    
    public String getCredit_ref_no() {
		return credit_ref_no;
	}

	public void setCredit_ref_no(String credit_ref_no) {
		this.credit_ref_no = credit_ref_no;
	}

	public String getUtr_no() {
		return utr_no;
	}

	public void setUtr_no(String utr_no) {
		this.utr_no = utr_no;
	}

	public String getDebit_amount() {
		return debit_amount;
	}

	public void setDebit_amount(String debit_amount) {
		this.debit_amount = debit_amount;
	}

	
    
    
    public void setCredit_status_description(String credit_status_description) {
		this.credit_status_description = credit_status_description;
	}

	public void setAuth1_date(String auth1_date) {
		this.auth1_date = auth1_date;
	}

	public void setAuth2_date(String auth2_date) {
		this.auth2_date = auth2_date;
	}

	
    
    public String getCommission() {
		return commission;
	}

	public void setCommission(String commission) {
		this.commission = commission;
	}

	public String getDebit_account() {
		return debit_account;
	}

	public void setDebit_account(String debit_account) {
		this.debit_account = debit_account;
	}

	public String getDebit_branch() {
		return debit_branch;
	}

	public void setDebit_branch(String debit_branch) {
		this.debit_branch = debit_branch;
	}

	public String getDebit_ref_no() {
		return debit_ref_no;
	}

	public void setDebit_ref_no(String debit_ref_no) {
		this.debit_ref_no = debit_ref_no;
	}

	
    public String getFirstauth() {
		return firstauth;
	}

	public void setFirstauth(String firstauth) {
		if(firstauth==null)
			firstauth="-";
		this.firstauth = firstauth;
	}

	public String getSecondauth() {
		return secondauth;
	}

	public void setSecondauth(String secondauth) {
		if(secondauth==null)
			secondauth="-";
		this.secondauth = secondauth;
	}
    
    public String getCurrentAuthLevel() {
		return currentAuthLevel;
	}

	public void setCurrentAuthLevel(String currentAuthLevel) {
		this.currentAuthLevel = currentAuthLevel;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

    
    //  added by siva for prepaid card ends here
    
	public String getFailureReason()
    {
        return failureReason;
    }

    public void setFailureReason(String failureReason)
    {
        this.failureReason = failureReason;
    }

    public String getCardNo()
    {
        return cardNo;
    }

    public void setCardNo(String cardNo)
    {
        this.cardNo = cardNo;
    }

    public String getLabel()
    {
        return label;
    }

    public void setLabel(String label)
    {
        this.label = label;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    public String getAmountInWords() {
		return amountInWords;
	}

	public void setAmountInWords(String amountInWords) {
		this.amountInWords = amountInWords;
	}

	public int getAuthType() {
		return authType;
	}

	public void setAuthType(int auhtType) {
		this.authType = auhtType;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCorpRefNo() {
		return corpRefNo;
	}

	public void setCorpRefNo(String corpRefNo) {
		this.corpRefNo = corpRefNo;
	}

	public String getCreditAccountNo() {
		return creditAccountNo;
	}

	public void setCreditAccountNo(String creditAccountNo) {
		this.creditAccountNo = creditAccountNo;
	}

	public String getCreditBranchName() {
		return creditBranchName;
	}

	public void setCreditBranchName(String creditBranchName) {
		this.creditBranchName = creditBranchName;
	}

	public String getEchequeNo() {
		return echequeNo;
	}

	public void setEchequeNo(String echequeNo) {
		this.echequeNo = echequeNo;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getCorporateId() {
		return CorporateId;
	}

	public void setCorporateId(String corporateId) {
		CorporateId = corporateId;
	}

	public boolean isConfApproved() {
		return confApproved;
	}

	public void setConfApproved(boolean confApproved) {
		this.confApproved = confApproved;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Timestamp scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public Double getEchequeAmount() {
		return echequeAmount;
	}

	public void setEchequeAmount(Double echequeAmount) {
		this.echequeAmount = echequeAmount;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public String getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(String rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
    //added for CR 3082
	public String getCreditStatus() {
		return creditStatus;
	}

	public void setCreditStatus(String creditStatus) {
		this.creditStatus = creditStatus;
	}


	public String getCardReferenceNo()
    {
        return cardReferenceNo;
    }

    public void setCardReferenceNo(String cardReferenceNo)
    {
        this.cardReferenceNo = cardReferenceNo;
    }

    public String getCardHolderName()
    {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName)
    {
        this.cardHolderName = cardHolderName;
    }

	public String getAuth1_date() {
		return auth1_date;
	}

	public String getAuth2_date() {
		return auth2_date;
	}

	public String getReasonFailure() {
		return reasonFailure;
	}

	public void setReasonFailure(String reasonFailure) {
		this.reasonFailure = reasonFailure;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public String getDebitStatus() {
		return debitStatus;
	}

	public void setDebitStatus(String debitStatus) {
		this.debitStatus = debitStatus;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDisplayFlag() {
		return displayFlag;
	}

	public void setDisplayFlag(String displayFlag) {
		this.displayFlag = displayFlag;
	}

	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}




}
