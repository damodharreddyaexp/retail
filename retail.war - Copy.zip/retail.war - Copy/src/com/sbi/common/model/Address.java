/*
 * Address.java
 * Created on Nov 2, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 2, 2005 MURUGAN K - Initial Creation

package com.sbi.common.model;

public class Address implements BaseModel{
    
    private String address1=null;
    private String address2 =null;
    private String city = null;
    private String state =null;
    private String country =null;
    private String pin = null;
    private String deliveryMode = null;
    private String deliveryAddress = null;
    
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    
    public String getCity(){
        return city;
    }
    
    public void setCity(String city){
        this.city = city;
    }
    
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    
    public String getPin() {
        return pin;
    }
    public void setPin(String pin) {
        this.pin = pin;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    
    public String getDeliveryMode(){
        return deliveryMode;
    }
    public void setDeliveryMode(String deliveryMode){
        this.deliveryMode = deliveryMode; 
    }
    public String getDeliveryAddress(){
        return deliveryAddress;
    }
    public void setDeliveryAddress(String delivaryAddress){
        this.deliveryAddress = delivaryAddress;
    }
    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append("address1:");
        tempStringBuf.append(address1);
        tempStringBuf.append(" | ");
        tempStringBuf.append("address2:");
        tempStringBuf.append(address2);
        tempStringBuf.append(" | ");
        tempStringBuf.append("city:");
        tempStringBuf.append(city);
        tempStringBuf.append(" | ");
        
        tempStringBuf.append("state:");
        tempStringBuf.append(state);
        tempStringBuf.append(" | ");
        tempStringBuf.append("country:");
        tempStringBuf.append(country);
        tempStringBuf.append(" | ");
        tempStringBuf.append("pin:");
        tempStringBuf.append(pin);
        tempStringBuf.append(" | ");
        tempStringBuf.append("deliveryMode:");
        tempStringBuf.append(deliveryMode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("deliveryAddress:");
        tempStringBuf.append(deliveryAddress);
      
       
        return tempStringBuf.toString();
    } 
     
    public String toString2()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(address1);
        tempStringBuf.append(" | ");
        tempStringBuf.append(address2);
        tempStringBuf.append(" | ");
        tempStringBuf.append(city);
        tempStringBuf.append(" | ");
        tempStringBuf.append(state);
        tempStringBuf.append(" | ");
        tempStringBuf.append(country);
        tempStringBuf.append(" | ");
        tempStringBuf.append(pin);
        tempStringBuf.append(" | ");
        tempStringBuf.append(deliveryMode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(deliveryAddress);
        return tempStringBuf.toString();
    } 
	
    
}
