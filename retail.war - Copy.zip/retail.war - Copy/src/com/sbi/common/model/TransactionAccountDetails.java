/** 
 * @(#) TransactionAccountDetails.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class TransactionAccountDetails extends AccountDetails
{
        private Double clearBalance;
        
        private Double bookBalance;
        
        private Double drawingPower;
        
        private Double amountOutStanding;
        
        private Double sanctionedLimit;
        
        private Timestamp sanctionedDate;
        
        private Double interestRate;
        
        private Double creditInterestRate;
        
        private Double balanceAsDate;
        
        private Double maturityAmount;
        
        private Timestamp maturityDate;
        
        private Double availableBalance;
        
        private Double principal;
        
        private Double accumulatedInterest;
        
        private Timestamp openingDate;
        
        private Integer tenorDays;
        
        private Integer tenorMonth;
        
        private Integer tenorYear;
        
        private Integer tenorINDays;//Added for eTDR/eSTDR
                
        private boolean passwordFlag;
        
        private boolean dormantFlag;
        
        private boolean safHoldings;
        
		//Added for CR-5171        
        private Double holdValue;
        
      //Added by Aruna for IR72454 start
        private Double unClearBalance;
        
        private String ifsCode;
        
        public String getIfsCode() {
			return ifsCode;
		}

		public void setIfsCode(String ifsCode) {
			this.ifsCode = ifsCode;
		}
      
        public Double getUnClearBalance() {
			return unClearBalance;
		}

		public void setUnClearBalance(Double unClearBalance) {
			this.unClearBalance = unClearBalance;
		}

		//Added by Aruna for IR72454 end
        private Double modBalance; //CLTD/MOD
        
		public Double getModBalance() {
			return modBalance;
		}

		public void setModBalance(Double modBalance) {
			this.modBalance = modBalance; //CLTD/MOD
		}
        
        /**
		 * @return the holdValue
		 */
		public Double getHoldValue() {
			return holdValue;
		}

		/**
		 * @param holdValue the holdValue to set
		 */
		public void setHoldValue(Double holdValue) {
			this.holdValue = holdValue;
		}
        public void setClearBalance( Double clearBalance )
        {
                this.clearBalance=clearBalance;
        }
        
        public Double getClearBalance( )
        {
                return clearBalance;
        }
        
        public void setBookBalance( Double bookBalance )
        {
                this.bookBalance=bookBalance;
        }
        
        public Double getBookBalance( )
        {
                return bookBalance;
        }
        
        public void setDrawingPower( Double drawingPower )
        {
                this.drawingPower=drawingPower;
        }
        
        public Double getDrawingPower( )
        {
                return drawingPower;
        }
        
        public void setAmountOutStanding( Double amountOutStanding )
        {
                this.amountOutStanding=amountOutStanding;
        }
        
        public Double getAmountOutStanding( )
        {
                return amountOutStanding;
        }
        
        public void setSanctionedLimit( Double sanctionedLimit )
        {
                this.sanctionedLimit=sanctionedLimit;
        }
        
        public Double getSanctionedLimit( )
        {
                return sanctionedLimit;
        }
        
        public void setSanctionedDate( Timestamp sanctionedDate )
        {
                this.sanctionedDate=sanctionedDate;
        }
        
        public Timestamp getSanctionedDate( )
        {
                return sanctionedDate;
        }
        
        public void setInterestRate( Double interestRate )
        {
                this.interestRate=interestRate;
        }
        
        public Double getInterestRate( )
        {
                return interestRate;
        }
        
        public void setCreditInterestRate( Double creditInterestRate )
        {
                this.creditInterestRate=creditInterestRate;
        }
        
        public Double getCreditInterestRate( )
        {
                return creditInterestRate;
        }
        
        public void setBalanceAsDate( Double balanceAsDate )
        {
                this.balanceAsDate=balanceAsDate;
        }
        
        public Double getBalanceAsDate( )
        {
                return balanceAsDate;
        }
        
        public void setMaturityAmount( Double maturityAmount )
        {
                this.maturityAmount=maturityAmount;
        }
        
        public Double getMaturityAmount( )
        {
                return maturityAmount;
        }
        
        public void setMaturityDate( Timestamp maturityDate )
        {
                this.maturityDate=maturityDate;
        }
        
        public Timestamp getMaturityDate( )
        {
                return maturityDate;
        }
        
        public void setAvailableBalance( Double availableBalance )
        {
                this.availableBalance=availableBalance;
        }
        
        public Double getAvailableBalance( )
        {
                return availableBalance;
        }
        
        public void setPrincipal( Double principal )
        {
                this.principal=principal;
        }
        
        public Double getPrincipal( )
        {
                return principal;
        }
        
        public void setAccumulatedInterest( Double accumulatedInterest )
        {
                this.accumulatedInterest=accumulatedInterest;
        }
        
        public Double getAccumulatedInterest( )
        {
                return accumulatedInterest;
        }
        
        public void setOpeningDate( Timestamp openingDate )
        {
                this.openingDate=openingDate;
        }
        
        public Timestamp getOpeningDate( )
        {
                return openingDate;
        }
        
        public void setTenorDays( Integer tenorDays )
        {
                this.tenorDays=tenorDays;
        }
        
        public Integer getTenorDays( )
        {
                return tenorDays;
        }
        
        public void setTenorMonth( Integer tenorMonth )
        {
                this.tenorMonth=tenorMonth;
        }
        
        public Integer getTenorMonth( )
        {
                return tenorMonth;
        }
        
        public void setTenorYear( Integer tenorYear )
        {
                this.tenorYear=tenorYear;
        }
        
        public Integer getTenorYear( )
        {
                return tenorYear;
        }
        
        public Integer getTenorINDays() {
			return tenorINDays;
		}

		public void setTenorINDays(Integer tenorINDays) {
			this.tenorINDays = tenorINDays;
		}

		public void setPasswordFlag( boolean passwordFlag )
        {
                this.passwordFlag=passwordFlag;
        }
        
        public boolean isPasswordFlag( )
        {
                return passwordFlag;
        }
        
        public void setDormantFlag( boolean dormantFlag )
        {
                this.dormantFlag=dormantFlag;
        }
        
        public boolean isDormantFlag( )
        {
                return dormantFlag;
        }
        
        public void setSafHoldings( boolean safHoldings )
        {
                this.safHoldings=safHoldings;
        }
        
        public boolean isSafHoldings( )
        {
                return safHoldings;
        }
        
        public String toString()
        
        {
            StringBuffer tempStringBuf = new StringBuffer();
            tempStringBuf.append(clearBalance);
            tempStringBuf.append(" | ");
            tempStringBuf.append(bookBalance);
            tempStringBuf.append(" | ");
            tempStringBuf.append(drawingPower);
            tempStringBuf.append(" | ");
            tempStringBuf.append(amountOutStanding);
            tempStringBuf.append(" | ");
            tempStringBuf.append(sanctionedLimit);
            tempStringBuf.append(" | ");
            tempStringBuf.append(sanctionedDate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(interestRate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(creditInterestRate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(balanceAsDate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(maturityAmount);
            tempStringBuf.append(" | ");
            tempStringBuf.append(maturityDate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(availableBalance);
            tempStringBuf.append(" | ");
            tempStringBuf.append(principal);
            tempStringBuf.append(" | ");
            tempStringBuf.append(accumulatedInterest);
            tempStringBuf.append(" | ");
            tempStringBuf.append(openingDate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(interestRate);
            tempStringBuf.append(" | ");
            tempStringBuf.append(tenorDays);
            tempStringBuf.append(" | ");
            tempStringBuf.append(tenorMonth);
            tempStringBuf.append(" | ");
            tempStringBuf.append(tenorYear);
            tempStringBuf.append(" | ");
            tempStringBuf.append(tenorINDays);
            tempStringBuf.append(" | ");
            tempStringBuf.append(passwordFlag);
            tempStringBuf.append(" | ");
            tempStringBuf.append(dormantFlag);
            tempStringBuf.append(" | ");
            tempStringBuf.append(safHoldings);
            tempStringBuf.append("|");
           

            return tempStringBuf.toString();
            
        }
        
        
}
