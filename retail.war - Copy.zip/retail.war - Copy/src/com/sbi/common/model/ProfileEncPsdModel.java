package com.sbi.common.model;

import java.util.HashMap;
import java.util.Map;
 

public class ProfileEncPsdModel {
	
	private String encString = null;
	private String decString = null;
	private String ImageString = null;
	private String nonImageString = null;
	private int ImageCount = 0;
	private int nonImageCount = 0;
	
	private String key = null;
	private boolean firstRowChanged = false;

	//verify Profilepassword parameters
	private boolean isPasswordEnc = false;
	private String profilePasswordenc = null;
	private String profilePassword = null;
	
	
	//change profilepassword parameters
	private boolean oldPasswordEncFlag = false;
	private boolean newPasswordEncFlag = false;
	private String profpassword = null;
	private String oldProfilePassword = null;
	private String newPassword = null;
	private String confirmPassword = null;
	private String oldProfilePasswordenc = null;	
	private String newPasswordenc = null;
	private String confirmPasswordenc = null;
 
	private String lang = null;
	private RegionalKeyBoardModel rkbModel = null;
	private Map regionalMap = null;
	
	
	private  int columns = 13;
	private  int firstColumn = 10;
	private  int noObjects = 3;
	
	
	private boolean imageService = false; 
	
	
	
	
	
	
 
	public Map getRegionalMap() {
		return regionalMap;
	}
	public void setRegionalMap(Map regionalMap) {
		this.regionalMap = regionalMap;
	}
	public RegionalKeyBoardModel getRkbModel() {
		return rkbModel;
	}
	public void setRkbModel(RegionalKeyBoardModel rkbModel) {
		this.rkbModel = rkbModel;
	}
	public boolean isOldPasswordEncFlag() {
		return oldPasswordEncFlag;
	}
	public void setOldPasswordEncFlag(boolean oldPasswordEncFlag) {
		this.oldPasswordEncFlag = oldPasswordEncFlag;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
 
	public String getEncString() {
		return encString;
	}
	public void setEncString(String encString) {
		this.encString = encString;
	}
	public String getDecString() {
		return decString;
	}
	public void setDecString(String decString) {
		this.decString = decString;
	}
	public String getImageString() {
		return ImageString;
	}
	public void setImageString(String imageString) {
		ImageString = imageString;
	}
	public String getNonImageString() {
		return nonImageString;
	}
	public void setNonImageString(String nonImageString) {
		this.nonImageString = nonImageString;
	}
	public int getImageCount() {
		return ImageCount;
	}
	public void setImageCount(int imageCount) {
		ImageCount = imageCount;
	}
	public int getNonImageCount() {
		return nonImageCount;
	}
	public void setNonImageCount(int nonImageCount) {
		this.nonImageCount = nonImageCount;
	}
	/**
	 * @return the isPasswordEnc
	 */
	public boolean isPasswordEnc() {
		return isPasswordEnc;
	}
	/**
	 * @param isPasswordEnc the isPasswordEnc to set
	 */
	public void setPasswordEnc(boolean isPasswordEnc) {
		this.isPasswordEnc = isPasswordEnc;
	}
	/**
	 * @return the profilePasswordenc
	 */
	public String getProfilePasswordenc() {
		return profilePasswordenc;
	}
	/**
	 * @param profilePasswordenc the profilePasswordenc to set
	 */
	public void setProfilePasswordenc(String profilePasswordenc) {
		this.profilePasswordenc = profilePasswordenc;
	}
	/**
	 * @return the profilePassword
	 */
	public String getProfilePassword() {
		return profilePassword;
	}
	/**
	 * @param profilePassword the profilePassword to set
	 */
	public void setProfilePassword(String profilePassword) {
		this.profilePassword = profilePassword;
	}
	/**
	 * @return the isOldPasswordEnc
	 */
	public boolean isOldPasswordEnc() {
		return oldPasswordEncFlag;
	}
	/**
	 * @param isOldPasswordEnc the isOldPasswordEnc to set
	 */
	public void setOldPasswordEnc(boolean oldPasswordEncFlag) {
		this.oldPasswordEncFlag = oldPasswordEncFlag;
	}
	/**
	 * @return the isNewPasswordEncFlag
	 */
	public boolean isNewPasswordEncFlag() {
		return newPasswordEncFlag;
	}
	/**
	 * @param isNewPasswordEncFlag the isNewPasswordEncFlag to set
	 */
	public void setNewPasswordEncFlag(boolean newPasswordEncFlag) {
		this.newPasswordEncFlag = newPasswordEncFlag;
	}
	/**
	 * @return the profpassword
	 */
	public String getProfpassword() {
		return profpassword;
	}
	/**
	 * @param profpassword the profpassword to set
	 */
	public void setProfpassword(String profpassword) {
		this.profpassword = profpassword;
	}
	/**
	 * @return the oldProfilePassword
	 */
	public String getOldProfilePassword() {
		return oldProfilePassword;
	}
	/**
	 * @param oldProfilePassword the oldProfilePassword to set
	 */
	public void setOldProfilePassword(String oldProfilePassword) {
		this.oldProfilePassword = oldProfilePassword;
	}
	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}
	/**
	 * @param newPassword the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	/**
	 * @return the confirmPassword
	 */
	public String getConfirmPassword() {
		return confirmPassword;
	}
	/**
	 * @param confirmPassword the confirmPassword to set
	 */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	/**
	 * @return the oldProfilePasswordenc
	 */
	public String getOldProfilePasswordenc() {
		return oldProfilePasswordenc;
	}
	/**
	 * @param oldProfilePasswordenc the oldProfilePasswordenc to set
	 */
	public void setOldProfilePasswordenc(String oldProfilePasswordenc) {
		this.oldProfilePasswordenc = oldProfilePasswordenc;
	}
	/**
	 * @return the newPasswordenc
	 */
	public String getNewPasswordenc() {
		return newPasswordenc;
	}
	/**
	 * @param newPasswordenc the newPasswordenc to set
	 */
	public void setNewPasswordenc(String newPasswordenc) {
		this.newPasswordenc = newPasswordenc;
	}
	/**
	 * @return the confirmPasswordenc
	 */
	public String getConfirmPasswordenc() {
		return confirmPasswordenc;
	}
	/**
	 * @param confirmPasswordenc the confirmPasswordenc to set
	 */
	public void setConfirmPasswordenc(String confirmPasswordenc) {
		this.confirmPasswordenc = confirmPasswordenc;
	}
	 
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}
	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**
	 * @return the isFirstRowChanged
	 */
	public boolean isFirstRowChanged() {
		return firstRowChanged;
	}
	/**
	 * @param isFirstRowChanged the isFirstRowChanged to set
	 */
	public void setFirstRowChanged(boolean firstRowChanged) {
		this.firstRowChanged = firstRowChanged;
	}
	public int getColumns() {
		return columns;
	}
	public void setColumns(int columns) {
		this.columns = columns;
	}
	public int getFirstColumn() {
		return firstColumn;
	}
	public void setFirstColumn(int firstColumn) {
		this.firstColumn = firstColumn;
	}
	public int getNoObjects() {
		return noObjects;
	}
	public void setNoObjects(int noObjects) {
		this.noObjects = noObjects;
	}
	public boolean isImageService() {
		return imageService;
	}
	public void setImageService(boolean imageService) {
		this.imageService = imageService;
	}
	
	
	
	
	
	 
	
	
	
	
	
	
	

}
