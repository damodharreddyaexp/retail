
/*
 * BaseModel.java
 * Created on Apr 9, 2009
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Apr 9, 2009 IM42510 � Initial Creation

package com.sbi.common.model;

import java.io.Serializable;

/**
 * Base Interface for all the models used 
 * 
 * @version 1.0
 * @Indira Satyam Computer Services Ltd.,
 */

public interface BaseModel extends Serializable{

}
