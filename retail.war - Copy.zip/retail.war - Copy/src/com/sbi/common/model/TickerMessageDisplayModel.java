/*
 * CR-1884
 * SN27223
 */


package com.sbi.common.model;

import java.sql.Timestamp;

public class TickerMessageDisplayModel implements BaseModel
{

   
    private String roleType;

    private String fontColor;
     
    private Timestamp startTime;

    private Timestamp endTime;
    
    private String message;

    private String bankCode;
    
    private String status; 
    
    private String application;
	
    
	 public String toString()
	    {
	        StringBuffer tempStringBuf = new StringBuffer();      
	        tempStringBuf.append("role:");
	        tempStringBuf.append(roleType);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("message:");
	        tempStringBuf.append(message);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("startTime:");
	        tempStringBuf.append(startTime);
	        tempStringBuf.append(" | ");	        
	        tempStringBuf.append("endTime:");
	        tempStringBuf.append(endTime);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("fontColor:");
	        tempStringBuf.append(fontColor);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("bankCode:");
	        tempStringBuf.append(bankCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("status:");
	        tempStringBuf.append(status);   
	      
	       
	        return tempStringBuf.toString();
	    }


	public String getRoleType() {
		return roleType;
	}


	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}


	public String getFontColor() {
		return fontColor;
	}


	public void setFontColor(String fontColor) {
		this.fontColor = fontColor;
	}


	public Timestamp getStartTime() {
		return startTime;
	}


	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}


	public Timestamp getEndTime() {
		return endTime;
	}


	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getBankCode() {
		return bankCode;
	}


	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getApplication() {
		return application;
	}


	public void setApplication(String application) {
		this.application = application;
	} 
    

   

    
    
     
    
}
    
    
  