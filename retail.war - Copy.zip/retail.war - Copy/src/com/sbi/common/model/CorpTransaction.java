/**
 * @(#) CorpTransaction.java
 */

package com.sbi.common.model;

import java.util.Map;

import com.sbi.common.model.Transaction;

public class CorpTransaction extends Transaction
{
	 private String userName;
	 private String corporateId;
	 private String corporateName;
	 //added for rtgs/neft
	 private String corpAddress;
	 private String corpCity;
	 private String corpState;
	 private String corpZip;
	 //For RTGS/NEFT Transactions
	 private Map address;
	//Added for DD IOI
	   private String ioiEnabled;
	   
	   public String getIoiEnabled() {
			return ioiEnabled;
		}

		public void setIoiEnabled(String ioiEnabled) {
			this.ioiEnabled = ioiEnabled;
		}
	//End
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public String getCorporateName() {
		return corporateName;
	}
	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Map getAddress() {
		return address;
	}
	public void setAddress(Map address) {
		this.address = address;
	}
	public String getCorpAddress() {
		return corpAddress;
	}
	public void setCorpAddress(String corpAddress) {
		this.corpAddress = corpAddress;
	}
	public String getCorpCity() {
		return corpCity;
	}
	public void setCorpCity(String corpCity) {
		this.corpCity = corpCity;
	}
	public String getCorpState() {
		return corpState;
	}
	public void setCorpState(String corpState) {
		this.corpState = corpState;
	}
	public String getCorpZip() {
		return corpZip;
	}
	public void setCorpZip(String corpZip) {
		this.corpZip = corpZip;
	}
}
