/**  
 * @(#) TransactionLeg.java
 * //nov 24, 2005 BOOPATHI - added productType instead of accountType
 */

package com.sbi.common.model;

import java.sql.Timestamp;
import java.util.Map;
 
public class TransactionLeg implements BaseModel
{    
    
        private String productType;//new change
        
        private String productDesc;// for CR 2452
        
        private String productCode; //Added for CR-2473
        
        /**
         * SBI Unique Reference No
         */
        private String referenceNo;
        
        /**
         * Specifies type of the object - Debit or Credit (D or C)
         */
        private String type;
        
        /**
         * Debit/Credit Account No
         */
        private String accountNo;
        
        /**
         * Debit/Credit Branch Code
         */
        private String branchCode;
        
        /**
         * Transaction status code as returned by Switch/Core
         */
        
        private String accountNature;
        
       private String statusCode;
        
        private String statusDescription;
        
        private String thirdPartyRef;
        
        private Map additionalParams;
        
       private Double amount;
          
        private String currency;
        
        private String userName;
        
        private String merchantCode;
        
        private String remarks;
        
        private String branchName;
        
        private Timestamp transactionTime;
        
        private String userProfileName;
        
        private String narrative1;
        
        private String narrative2;
        
        private String narrative3;
        
        private String errorCode;
        
        private boolean nreProductCode; 
        
        //Added for eTDR/eSTDR -Start
        private String debitProductCode;
        
      //Added by Karthik
    	private String utrCreditStatus;
    	
    	
        public String getUtrCreditStatus() {
			return utrCreditStatus;
		}

		public void setUtrCreditStatus(String utrCreditStatus) {
			this.utrCreditStatus = utrCreditStatus;
		}

		public boolean isNreProductCode() {
			return nreProductCode;
		}

		public void setNreProductCode(boolean nreProductCode) {
			this.nreProductCode = nreProductCode;
		}

		public String getUserProfileName() {
			return userProfileName;
		}

		public void setUserProfileName(String userProfileName) {
			this.userProfileName = userProfileName;
		}
        
        public void setProductType(String productType)
        {
            this.productType = productType;
        } 
        
        public String getProductType()
        {
            return productType;
        }

        
        public void setReferenceNo( String referenceNo )
        {
                this.referenceNo=referenceNo;
        }
        
        public String getReferenceNo( )
        {
                return referenceNo;
        }
        
        public void setType( String type )
        {
                this.type=type;
        }
        
        public String getType( )
        {
                return type;
        }
        
        public void setAccountNo( String accountNo )
        {
                this.accountNo=accountNo;
        }
        
        public String getAccountNo( )
        {
                return accountNo;
        }
        
        public void setBranchCode( String branchCode )
        {
                this.branchCode=branchCode;
        }
        
        public String getBranchCode( )
        {
                return branchCode;
        }
        
        public void setStatusCode( String statusCode )
        {
                this.statusCode=statusCode;
        }
        
        public String getStatusCode( )
        {
                return statusCode;
        }
        
        public void setStatusDescription( String statusDescription )
        {
                this.statusDescription=statusDescription;
        }
        
        public String getStatusDescription( )
        {
                return statusDescription;
        }
        
        public void setThirdPartyRef( String thirdPartyRef )
        {
                this.thirdPartyRef=thirdPartyRef;
        }
        
        public String getThirdPartyRef( )
        {
                return thirdPartyRef;
        }
        
      
       
        
        
        public void setCurrency( String currency )
        {
                this.currency=currency;
        }
        
        public String getCurrency( )
        {
                return currency;
        }
        
        public Map getAdditionalParams() {
			return additionalParams;
		}

		public void setAdditionalParams(Map additionalParams) {
			this.additionalParams = additionalParams;
		}

		public void setUserName( String userName )
        {
                this.userName=userName;
        }
        
        public String getUserName( )
        {
                return userName;
        }
        
        public void setMerchantCode( String merchantCode )
        {
                this.merchantCode=merchantCode;
        }
        
        public String getMerchantCode( )
        {
                return merchantCode;
        }
        
        public void setRemarks( String remarks )
        {
                this.remarks=remarks;
        }
        
        public String getRemarks( )
        {
                return remarks;
        }
        
        public String getAccountNature(){
            return accountNature;
        }
        
        public void setAccountature(String accountNature){
            this.accountNature = accountNature;
        }
        
        public  Object[] toObject(){
            StringBuffer additionalParamsString = new StringBuffer("|");
            if( getAdditionalParams() != null)
            {
                for(int i = 0; i < getAdditionalParams().size() ; i++){
                    String key = "outref"+(i+1);
                    additionalParamsString.append(additionalParams.get(key)).append("|");
                }
            }
            Object[] obj = {
               this.getNarrative1(),
               this.getNarrative2(),
               this.getNarrative3(),
               this.getReferenceNo(),
               this.getType(),
               this.getAccountNo(),
               this.getBranchCode(),
               this.getStatusCode(),
               this.getStatusDescription(),
               this.getThirdPartyRef(),
               additionalParamsString.toString(),
               this.getAmount(),
               this.getCurrency(),
               this.getUserName(),           
               this.getMerchantCode(),
               this.getRemarks()
            };
            return obj;
        }
        
        public String toString()
        {
            StringBuffer tempStringBuf= new StringBuffer();
            tempStringBuf.append("referenceNo:");            
            tempStringBuf.append(referenceNo);
            tempStringBuf.append("|");
            tempStringBuf.append("type:");            
            tempStringBuf.append(type);
            tempStringBuf.append("|");
            tempStringBuf.append("accountNo:");
            tempStringBuf.append(accountNo);
            tempStringBuf.append("|");
            tempStringBuf.append("branchCode:");
            tempStringBuf.append(branchCode);           
            tempStringBuf.append("|");
            tempStringBuf.append("statusCode:");            
            tempStringBuf.append(statusCode);
            tempStringBuf.append("|");
            tempStringBuf.append("statusDescription:");
            tempStringBuf.append(statusDescription);
            tempStringBuf.append("|");
            tempStringBuf.append("thirdPartyRef:");
            tempStringBuf.append(thirdPartyRef);
            tempStringBuf.append("|");
            tempStringBuf.append("additionalParams:");      
            tempStringBuf.append(additionalParams);
            tempStringBuf.append("|");
            tempStringBuf.append("amount:");
            tempStringBuf.append(amount);
            tempStringBuf.append("|");
            tempStringBuf.append("currency:");
            tempStringBuf.append(currency);
            tempStringBuf.append("|");
            tempStringBuf.append("merchantCode:");            
            tempStringBuf.append(merchantCode);
            tempStringBuf.append("|");
            tempStringBuf.append("remarks:");
            tempStringBuf.append(remarks);
            tempStringBuf.append("|");
            tempStringBuf.append("accountNature:");
            tempStringBuf.append(accountNature);
            tempStringBuf.append("|");
            tempStringBuf.append("userName:");
            tempStringBuf.append(userName);
            tempStringBuf.append("|");  
            
            tempStringBuf.append("utrCreditStatus:");
            tempStringBuf.append(utrCreditStatus);
            tempStringBuf.append("|");    
         
            return tempStringBuf.toString();
                    
        }

        public String getBranchName()
        {
            return branchName;
        }

        public void setBranchName(String branchName)
        {
            this.branchName = branchName;
        }

        public Double getAmount() {
            return amount;
        }

        public void setAmount(Double amount) {
            this.amount = amount;
        }

        public void setAccountNature(String accountNature) {
            this.accountNature = accountNature;
        }

        public Timestamp getTransactionTime() {
            return transactionTime;
        }

        public void setTransactionTime(Timestamp transactionTime) {
            this.transactionTime = transactionTime;
        }

		public String getNarrative1() {
			return narrative1;
		}

		public void setNarrative1(String narrative1) {
			this.narrative1 = narrative1;
		}

		public String getNarrative2() {
			return narrative2;
		}

		public void setNarrative2(String narrative2) {
			this.narrative2 = narrative2;
		}

		public String getNarrative3() {
			return narrative3;
		}

		public void setNarrative3(String narrative3) {
			this.narrative3 = narrative3;
		}

		public String getProductDesc() {
			return productDesc;
		}

		public void setProductDesc(String productDesc) {
			this.productDesc = productDesc;
		}

        public String getProductCode()
        {
            return productCode;
        }

        public void setProductCode(String productCode)
        {
            this.productCode = productCode;
        }

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}

		//added for E-suvidha corporate
		private Double icolletRateOfInterest;

		

		
		private String isNewlyAddedTp;


		public String getIsNewlyAddedTp() {
			return isNewlyAddedTp;
		}

		public void setIsNewlyAddedTp(String isNewlyAddedTp) {
			this.isNewlyAddedTp = isNewlyAddedTp;
		}
		

		private Map addressParams;


		public Map getAddressParams() {
			return addressParams;
		}

		public void setAddressParams(Map addressParams) {
			this.addressParams = addressParams;
		}

		public Double getIcolletRateOfInterest() {
			return icolletRateOfInterest;
		}

		public void setIcolletRateOfInterest(Double icolletRateOfInterest) {
			this.icolletRateOfInterest = icolletRateOfInterest;
		}
     
		public String getDebitProductCode() {
			return debitProductCode;
		}

		public void setDebitProductCode(String debitProductCode) {
			this.debitProductCode = debitProductCode;
		}

        
}
