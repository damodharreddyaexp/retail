package com.sbi.common.model;

import java.sql.Timestamp;

public class BrokerAccountDetails extends AccountDetails {

	private Timestamp transactionDate;
	
	private Timestamp clearingDate;
	
	private String transactingBranch;
	
	private String transactionAmount;
	
	private String chequeNo;
	
	private String narration;
	
	private String clientCode;
	
	private String clientName;
	
	private String draweeBank;
	
	private String draweeAccount;
	
	private String depositSlipNo;
	
	private String transactionDesc;
	
	private String filename;

	public Timestamp getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Timestamp getClearingDate() {
		return clearingDate;
	}

	public void setClearingDate(Timestamp clearingDate) {
		this.clearingDate = clearingDate;
	}

	public String getTransactingBranch() {
		return transactingBranch;
	}

	public void setTransactingBranch(String transactingBranch) {
		this.transactingBranch = transactingBranch;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getDraweeBank() {
		return draweeBank;
	}

	public void setDraweeBank(String draweeBank) {
		this.draweeBank = draweeBank;
	}

	public String getDraweeAccount() {
		return draweeAccount;
	}

	public void setDraweeAccount(String draweeAccount) {
		this.draweeAccount = draweeAccount;
	}

	public String getDepositSlipNo() {
		return depositSlipNo;
	}

	public void setDepositSlipNo(String depositSlipNo) {
		this.depositSlipNo = depositSlipNo;
	}

	public String getTransactionDesc() {
		return transactionDesc;
	}

	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	
	
}
