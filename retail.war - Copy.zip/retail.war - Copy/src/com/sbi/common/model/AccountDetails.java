/**  
 * @(#) AccountDetails.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class AccountDetails implements BaseModel
{
        private String accountDescription;
        
        private String accountShortName;
        
        private String nomination;
        
        private Account account;
        
        private String currencyCode;
        
        private Timestamp lastUpdatedDate;
        
        public void setAccountDescription( String accountDescription )
        {
                this.accountDescription=accountDescription;
        }
        
        public String getAccountDescription( )
        {
                return this.accountDescription;
        }
        public String getCurrencycode( )
        {
                return this.currencyCode;
        }
        
        public void setAccountShortName( String accountShortName )
        {
                this.accountShortName=accountShortName;
        }
        
        public String getAccountShortName( )
        {
                return this.accountShortName;
        }
        
        public void setNomination( String nomination )
        {
                this.nomination=nomination;
        }
        
        public String getNomination( )
        {
                return this.nomination;
        }
        
        public void setAccount( Account account )
        {
                this.account=account;
        }
        public void setCurrencyCode( String currency)
        {
                this.currencyCode=currency;
        }
        
        public Account getAccount( )
        {
                return this.account;
        }
        
        
        
        
        private Double creditInterestRate;
        
        private Double unClearBalance;
        
        private String ifsCode;
        
        private Double holdValue;
        
        private Double interestRate;
        
        private Double clearBalance;
        
        private Double bookBalance;
        
        private Double availableBalance;
        
        private Double drawingPower;
        
        private Double sanctionedLimit;
        
        private Double principal;
        
        private Double maturityAmount;
        
        private Timestamp maturityDate;
        
        private Timestamp openingDate;
        
        private Integer tenorDays;
        
        private Integer tenorMonth;
        
        private Integer tenorYear;
        
        private Integer tenorINDays;
        
        private Double accumulatedInterest;
        
        private Double modBalance;
        
        private Double amountOutStanding;
        
        private Double currentYearInterest;

    	private Double previousYearInterest;
    	
        public Double getCreditInterestRate() {
    		return creditInterestRate;
    	}

    	public void setCreditInterestRate(Double creditInterestRate) {
    		this.creditInterestRate = creditInterestRate;
    	}
    	
        public String getIfsCode() {
    		return ifsCode;
    	}

    	public void setIfsCode(String ifsCode) {
    		this.ifsCode = ifsCode;
    	}
      
        public Double getUnClearBalance() {
    		return unClearBalance;
    	}

    	public void setUnClearBalance(Double unClearBalance) {
    		this.unClearBalance = unClearBalance;
    	}
    	public Double getHoldValue() {
    		return holdValue;
    	}
    		
    	public void setHoldValue(Double holdValue) {
    		this.holdValue = holdValue;
    	}
    	
    	public Double getInterestRate() {
    		return interestRate;
    	}

    	public void setInterestRate(Double interestRate) {
    		this.interestRate = interestRate;
    	}
       
    	public void setClearBalance( Double clearBalance )
        {
                this.clearBalance=clearBalance;
        }
        
        public Double getClearBalance( )
        {
                return clearBalance;
        }
        
        public void setBookBalance( Double bookBalance )
        {
                this.bookBalance=bookBalance;
        }
        
        public Double getBookBalance( )
        {
                return bookBalance;
        }
        
        public void setAvailableBalance( Double availableBalance )
        {
                this.availableBalance=availableBalance;
        }
        
        public Double getAvailableBalance( )
        {
                return availableBalance;
        }
        
        public void setDrawingPower( Double drawingPower )
        {
                this.drawingPower=drawingPower;
        }
        
        public Double getDrawingPower( )
        {
                return drawingPower;
        }
        
        public void setSanctionedLimit( Double sanctionedLimit )
        {
                this.sanctionedLimit=sanctionedLimit;
        }
        
        public Double getSanctionedLimit( )
        {
                return sanctionedLimit;
        }
        
        public void setPrincipal( Double principal )
        {
                this.principal=principal;
        }
        
        public Double getPrincipal( )
        {
                return principal;
        }
        
        public void setMaturityAmount( Double maturityAmount )
        {
                this.maturityAmount=maturityAmount;
        }
        
        public Double getMaturityAmount( )
        {
                return maturityAmount;
        }
        
        public void setMaturityDate( Timestamp maturityDate )
        {
                this.maturityDate=maturityDate;
        }
        
        public Timestamp getMaturityDate( )
        {
                return maturityDate;
        }
        
        public void setOpeningDate( Timestamp openingDate )
        {
                this.openingDate=openingDate;
        }
        
        public Timestamp getOpeningDate( )
        {
                return openingDate;
        }
        
        public void setTenorDays( Integer tenorDays )
        {
                this.tenorDays=tenorDays;
        }
        
        public Integer getTenorDays( )
        {
                return tenorDays;
        }
        
        public void setTenorMonth( Integer tenorMonth )
        {
                this.tenorMonth=tenorMonth;
        }
        
        public Integer getTenorMonth( )
        {
                return tenorMonth;
        }
        
        public void setTenorYear( Integer tenorYear )
        {
                this.tenorYear=tenorYear;
        }
        
        public Integer getTenorYear( )
        {
                return tenorYear;
        }
        
        public Integer getTenorINDays() {
				return tenorINDays;
		}

		public void setTenorINDays(Integer tenorINDays) {
				this.tenorINDays = tenorINDays;
		}
        
		public void setAccumulatedInterest( Double accumulatedInterest )
        {
                this.accumulatedInterest=accumulatedInterest;
        }
        
        public Double getAccumulatedInterest( )
        {
                return accumulatedInterest;
        }
        
        public Double getModBalance() {
			return modBalance;
		}

		public void setModBalance(Double modBalance) {
			this.modBalance = modBalance; 
		}
		
		public void setAmountOutStanding( Double amountOutStanding )
        {
                this.amountOutStanding=amountOutStanding;
        }
        
        public Double getAmountOutStanding( )
        {
                return amountOutStanding;
        }
        
        public Double getCurrentYearInterest() {
    		return currentYearInterest;
    	}

    	public Double getPreviousYearInterest() {
    		return previousYearInterest;
    	}
    	public void setCurrentYearInterest(Double currentYearInterest) {
    		this.currentYearInterest = currentYearInterest;
    	}

    	public void setPreviousYearInterest(Double previousYearInterest) {
    		this.previousYearInterest = previousYearInterest;
    	}
    		
    		
    		
    		
    		
		
		
		
		
		
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf = new StringBuffer();
        	
        	tempStringBuf.append(accountDescription);
        	tempStringBuf.append("|");
        	tempStringBuf.append(accountShortName);
        	tempStringBuf.append("|");
            tempStringBuf.append(nomination);
            tempStringBuf.append("|");
            tempStringBuf.append(account);
            tempStringBuf.append("|");
            tempStringBuf.append("lastUpdatedDate:");
            tempStringBuf.append(lastUpdatedDate);
            tempStringBuf.append("|");
            
            return tempStringBuf.toString();
          
        }

        public Timestamp getLastUpdatedDate() {
            return lastUpdatedDate;
        }

        public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
            this.lastUpdatedDate = lastUpdatedDate;
        }


        
        private String branchCode;
        
        public String getBranchCode() {
			return branchCode;
		}

		public void setBranchCode(String branchCode) {
			this.branchCode = branchCode;
		}
		
		private String branchName;
		
		public String getBranchName() {
			return branchName;
		}

		public void setBranchName(String branchName) {
			this.branchName = branchName;
		}

          
}
                  
        

