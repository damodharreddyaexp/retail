/* 
 *  DSCDetails.java  
 * Created on Mar 6, 2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */  

package com.sbi.common.model;

import java.sql.Timestamp;

/**
 * TODO This class is used to set and get the  UserProfile's properties
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class DSCDetails
{
      
	private String corporateId;
	private String corporateName;
	private String userName;
	private String auth1Name;
	private String auth2Name;
	private String branchCode;
	private String branchName;
    private String referenceNo;
    private String commonName;
    private String issuerName;
    private String role;
    private Timestamp expDate;
    private String serialNo;
    private String branchStatus;
    private String dscStatus;
    private String mobileNo;
    private String sfaProviderMode;
    private String requestType;
    
	public String toString() 
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	tempStringBuf.append("corporateId :");
          	tempStringBuf.append(corporateId);
        	tempStringBuf.append("|");
        	tempStringBuf.append("corporateName :");
        	tempStringBuf.append(corporateName);
        	tempStringBuf.append("|");
        	tempStringBuf.append("userName :");
        	tempStringBuf.append(userName);
        	tempStringBuf.append("|");
        	tempStringBuf.append("auth1Name :");
        	tempStringBuf.append(auth1Name);
        	tempStringBuf.append("|");
        	tempStringBuf.append("auth2Name :");
            tempStringBuf.append(auth2Name);
            tempStringBuf.append("|");
        	tempStringBuf.append("branchCode :");
            tempStringBuf.append(branchCode);
            tempStringBuf.append("|");
        	tempStringBuf.append("branchName :");
            tempStringBuf.append(branchName);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("commonName :");
            tempStringBuf.append(commonName);
            
            tempStringBuf.append("|");
            tempStringBuf.append("issuerName :");
            tempStringBuf.append(issuerName);
            
            tempStringBuf.append("|");
            tempStringBuf.append("role :");
            tempStringBuf.append(role);
            
            tempStringBuf.append("|");
            tempStringBuf.append("expDate :");
            tempStringBuf.append(expDate);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("referenceNo :");
            tempStringBuf.append(referenceNo);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("serialNo :");
            tempStringBuf.append(serialNo);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("mobileNo :");
            tempStringBuf.append(mobileNo);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("sfaProviderMode :");
            tempStringBuf.append(sfaProviderMode);            
            tempStringBuf.append("|");
            
            tempStringBuf.append("requestType :");
            tempStringBuf.append(requestType);            
            tempStringBuf.append("|");
            
        	return tempStringBuf.toString();
        	
        }

	

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getCorporateName() {
		return corporateName;
	}

	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAuth1Name() {
		return auth1Name;
	}

	public void setAuth1Name(String auth1Name) {
		this.auth1Name = auth1Name;
	}

	public String getAuth2Name() {
		return auth2Name;
	}

	public void setAuth2Name(String auth2Name) {
		this.auth2Name = auth2Name;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}



	public String getReferenceNo() {
		return referenceNo;
	}



	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}



	public String getCommonName() {
		return commonName;
	}



	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}



	public String getIssuerName() {
		return issuerName;
	}



	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public Timestamp getExpDate() {
		return expDate;
	}



	public void setExpDate(Timestamp expDate) {
		this.expDate = expDate;
	}



	public String getSerialNo() {
		return serialNo;
	}



	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}



	public String getBranchStatus() {
		return branchStatus;
	}



	public void setBranchStatus(String branchStatus) {
		this.branchStatus = branchStatus;
	}



	public String getDscStatus() {
		return dscStatus;
	}



	public void setDscStatus(String dscStatus) {
		this.dscStatus = dscStatus;
	}



	public String getMobileNo() {
		return mobileNo;
	}



	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}



	public String getSfaProviderMode() {
		return sfaProviderMode;
	}



	public void setSfaProviderMode(String sfaProviderMode) {
		this.sfaProviderMode = sfaProviderMode;
	}



	public String getRequestType() {
		return requestType;
	}



	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

       
       
   } 