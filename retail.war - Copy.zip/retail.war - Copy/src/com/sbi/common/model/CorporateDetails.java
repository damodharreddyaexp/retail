/**
 * @(#) CorporateDetails.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class CorporateDetails implements BaseModel
{
        private String referenceNo;
        
        private Integer audited;
        
        private Integer currentAuthLevel;
        
        private String auditedBy;
        
        private String corporateId;
        
        private String authType;
        
        private Timestamp scheduledDate;
        
        private String fileName;
        
        private String supplierId;
        
        private Integer suspenseProcessed;
        
        private String auth1Name;
        
        private String auth2Name;
        
        private String beneficiary;
        
        private String businessLineId;
        
        private String scheduledDateString;
        
        private String approver;
        
        public void setReferenceNo( String referenceNo )
        {
                this.referenceNo=referenceNo;
        }
        
        public String getReferenceNo( )
        {
                return referenceNo;
        }
        
        public void setAudited( Integer audited )
        {
                this.audited=audited;
        }
        
        public Integer getAudited( )
        {
                return audited;
        }
        
        public void setCurrentAuthLevel( Integer currentAuthLevel )
        {
                this.currentAuthLevel=currentAuthLevel;
        }
        
        public Integer getCurrentAuthLevel( )
        {
                return currentAuthLevel;
        }
        
        public void setAuditedBy( String auditedBy )
        {
                this.auditedBy=auditedBy;
        }
        
        public String getAuditedBy( )
        {
                return auditedBy;
        }
        
        public void setCorporateId( String corporateId )
        {
                this.corporateId=corporateId;
        }
        
        public String getCorporateId( )
        {
                return corporateId;
        }
        
        public void setAuthType( String authType )
        {
                this.authType=authType;
        }
        
        public String getAuthType( )
        {
                return authType;
        }
        
        public void setScheduledDate( Timestamp scheduledDate )
        {
                this.scheduledDate=scheduledDate;
        }
        
        public Timestamp getScheduledDate( )
        {
                return scheduledDate;
        }
        
        public void setFileName( String fileName )
        {
                this.fileName=fileName;
        }
        
        public String getFileName( )
        {
                return fileName;
        }
        
        public void setSupplierId( String supplierId )
        {
                this.supplierId=supplierId;
        }
        
        public String getSupplierId( )
        {
                return supplierId;
        }
        
        public void setSuspenseProcessed( Integer suspenseProcessed )
        {
                this.suspenseProcessed=suspenseProcessed;
        }
        
        public Integer getSuspenseProcessed( )
        {
                return suspenseProcessed;
        }
        
        public void setAuth1Name( String auth1Name )
        {
                this.auth1Name=auth1Name;
        }
        
        public String getAuth1Name( )
        {
                return auth1Name;
        }
        
        public void setAuth2Name( String auth2Name )
        {
                this.auth2Name=auth2Name;
        }
        
        public String getAuth2Name( )
        {
                return auth2Name;
        }
        
        public void setBeneficiary( String beneficiary )
        {
                this.beneficiary=beneficiary;
        }
        
        public String getBeneficiary( )
        {
                return beneficiary;
        }
        
        public void setBusinessLineId( String businessLineId )
        {
                this.businessLineId=businessLineId;
        }
        
        public String getBusinessLineId( )
        {
                return businessLineId;
        }
        
        public void setScheduledDateString( String scheduledDateString )
        {
                this.scheduledDateString=scheduledDateString;
        }
        
        public String getScheduledDateString( )
        {
                return scheduledDateString;
        }
        
        public void setApprover( String approver )
        {
                this.approver=approver;
        }
        
        public String getApprover( )
        {
                return approver;
        }
        
        public String toString()
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	        
        		tempStringBuf.append(referenceNo);
        		tempStringBuf.append("|");
        		tempStringBuf.append(audited);
        		tempStringBuf.append("|");
        		tempStringBuf.append(currentAuthLevel);
        		tempStringBuf.append("|");
        		tempStringBuf.append(auditedBy);
        		tempStringBuf.append("|");
        		tempStringBuf.append(corporateId);
        		tempStringBuf.append("|");
        		tempStringBuf.append(authType);
           		tempStringBuf.append("|");
           		tempStringBuf.append(scheduledDate);
           		tempStringBuf.append("|");
           		tempStringBuf.append(fileName);
        		tempStringBuf.append("|");
        		tempStringBuf.append(supplierId);
        		tempStringBuf.append("|");
        		tempStringBuf.append(suspenseProcessed);
        		tempStringBuf.append("|");
        		tempStringBuf.append(auth1Name);
        		tempStringBuf.append("|");
        		tempStringBuf.append(auth2Name);
        		tempStringBuf.append("|");
        		tempStringBuf.append(beneficiary);
           		tempStringBuf.append("|");
           		tempStringBuf.append(businessLineId);
           		tempStringBuf.append("|");
          		tempStringBuf.append(scheduledDateString);
        		tempStringBuf.append("|");
        		tempStringBuf.append(approver);
        		tempStringBuf.append("|");
        		
        		
        		return tempStringBuf.toString();
        		
        		       		
        	}
        	
        }
        
        

