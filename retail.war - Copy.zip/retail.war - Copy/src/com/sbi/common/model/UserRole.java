/**
 * @(#) UserRole.java
 */

package com.sbi.common.model;

public class UserRole  implements BaseModel{
        private int userid;
        
        private int userRole;
        
        private int currFlag;
        
        public void setUserid( int userid )
        {
                this.userid=userid;
        }
        
        public int getUserid( )
        {
                return userid;
        }
        
        public void setUserRole( int userRole )
        {
                this.userRole=userRole;
        }
        
        public int getUserRole( )
        {
                return userRole;
        }
        
        public void setCurrFlag( int currFlag )
        {
                this.currFlag=currFlag;
        }
        
        public int getCurrFlag( )
        {
                return currFlag;
        }
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(userid);
        	tempStringBuf.append("|");
        	tempStringBuf.append(userRole);
        	tempStringBuf.append("|");
        	tempStringBuf.append(currFlag);
        	tempStringBuf.append("|");
        	
        	
        	return tempStringBuf.toString();
             	
        }
}
