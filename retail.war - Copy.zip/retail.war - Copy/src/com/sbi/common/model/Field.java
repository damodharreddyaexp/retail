/*
 * Field.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 Naveen Kumar - Initial Creation

package com.sbi.common.model;

public class Field implements BaseModel
{

    private String fieldName;
    
    private Object value;
    
    private int type;

    private String key;

    public String getFieldName()
    {
        return fieldName;
    }

    public void setFieldName(String fieldName)
    {
        this.fieldName = fieldName;
    }

    public String getKey()
    {
        return key;
    }

    public void setKey(String key)
    {
        this.key = key;
    }

    public int getType()
    {
        return type;
    }

    public void setType(int type)
    {
        this.type = type;
    }

    public Object getValue()
    {
        return value;
    }

    public void setValue(Object value)
    {
        this.value = value;
    }
    
    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(fieldName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(key);
        tempStringBuf.append(" | ");
        tempStringBuf.append(type);
        tempStringBuf.append(" | ");
        tempStringBuf.append(value);
        
        return tempStringBuf.toString();
    }
}
