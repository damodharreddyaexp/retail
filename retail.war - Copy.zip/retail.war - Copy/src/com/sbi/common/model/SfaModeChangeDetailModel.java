/*SFAModeChangeDetailModel.java
 *      
 * 
 * 
 * Copyright (c) 2007 by SBI All Rights Reserved.
 * $Header: $ 
 */


package com.sbi.common.model;

public class SfaModeChangeDetailModel {
private String userName;
private String auth1Name;
public String getAuth1Name() {
	return auth1Name;
}
public void setAuth1Name(String auth1Name) {
	this.auth1Name = auth1Name;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}	


}
