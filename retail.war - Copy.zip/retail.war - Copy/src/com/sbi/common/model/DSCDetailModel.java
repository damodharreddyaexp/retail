/*ConfirmPayeeDetailModel.java
 *      
 * Created on May 24, 2007
 * 
 * Copyright (c) 2007 by SBI All Rights Reserved.
 * $Header: $ 
 */
//History
//May 24, 2007 MADHAN KUMAR.B - Initial Creation

package com.sbi.common.model;

public class DSCDetailModel {

private String userName;
private String auth1Name;
private String moduleName;

public String getAuth1Name() {
	return auth1Name;
}
public void setAuth1Name(String auth1Name) {
	this.auth1Name = auth1Name;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getModuleName() {
	return moduleName;
}
public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}	


}
