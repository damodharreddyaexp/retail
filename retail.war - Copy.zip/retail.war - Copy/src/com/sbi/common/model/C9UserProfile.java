/* 
 *  C9UserProfile.java  
 * Created on Mar 6, 2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */  
//History
//Feb 6, 2011 Amar - Initial Creation

package com.sbi.common.model;

import java.sql.Timestamp;

/**
 * TODO This class is used to set and get the  UserProfile's properties
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class C9UserProfile
{
      
    private String email;
    
    private String homePhone;
    
    private String mobileNumber;
    
    private String friendlyName;
    
    private String countryCode;
    
    private String designation;//c
    
    private String department;//c
 
    private String district;//c
    
    private String name; // 
    
    private String createdBy;//c
    
    private String mobileRegNo;
    
    private String empNo;
    

	public String toString() 
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	tempStringBuf.append("email :");
          	tempStringBuf.append(email);
        	tempStringBuf.append("|");
        	tempStringBuf.append("homePhone :");
        	tempStringBuf.append(homePhone);
        	tempStringBuf.append("|");
        	tempStringBuf.append("mobileNumber :");
        	tempStringBuf.append(mobileNumber);
        	tempStringBuf.append("|");
        	tempStringBuf.append("homePhone :");
        	tempStringBuf.append(homePhone);
        	tempStringBuf.append("|");
        	tempStringBuf.append("friendlyName :");
            tempStringBuf.append(friendlyName);
            tempStringBuf.append("|");
        	tempStringBuf.append("countryCode :");
            tempStringBuf.append(countryCode);
            tempStringBuf.append("|");
        	tempStringBuf.append("designation :");
            tempStringBuf.append(designation);
            tempStringBuf.append("|");
        	tempStringBuf.append("department :");
            tempStringBuf.append(department);
            tempStringBuf.append("|");
        	tempStringBuf.append("district :");
            tempStringBuf.append(district);
            tempStringBuf.append("|");
            tempStringBuf.append("name :");
            tempStringBuf.append(name);
            tempStringBuf.append("|");
        	tempStringBuf.append("createdBy :");
            tempStringBuf.append(createdBy);
            tempStringBuf.append("|");
        	tempStringBuf.append("mobileRegNo :");
            tempStringBuf.append(mobileRegNo);
            tempStringBuf.append("|");
        	tempStringBuf.append("empNo :");
            tempStringBuf.append(empNo);
            tempStringBuf.append("|");
            
        	return tempStringBuf.toString();
        	
        }

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFriendlyName() {
		return friendlyName;
	}

	public void setFriendlyName(String friendlyName) {
		this.friendlyName = friendlyName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getMobileRegNo() {
		return mobileRegNo;
	}

	public void setMobileRegNo(String mobileRegNo) {
		this.mobileRegNo = mobileRegNo;
	} 
    public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

       
       
   } 