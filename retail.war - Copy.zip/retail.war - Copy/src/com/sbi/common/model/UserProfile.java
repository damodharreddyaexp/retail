/* 
 *  UserProfile.java  
 * Created on Oct 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */  
//History
//Nov 07, 2005 MURUGAN K - Initial Creation
//Nov 09,2005 MURUGAN K - toString() methd implementation

package com.sbi.common.model;

import java.sql.Timestamp;

/**
 * TODO This class is used to set and get the  UserProfile's properties
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class UserProfile extends User
{
	
	private String otpOption; // added for Voice OTP
      
    private String email;
    
    private String homePhone;
    
    private String businessPhone;
     
    private Timestamp lastLoginDate;  
    
    private String  lastTnameInternet;
    
    private Timestamp lastTDateInternet;
    
    private Double  transactioLimit;
    
    private Double taxTxnLimit; //added for CR 2899
    
    private Integer loginCount;
    
    private String hintQuestion;
    
    private String hintAnswer;
    
    private String mobileNumber;
    
    private Integer smsSecurity;
     
    private String profilepassword;
    
    private String friendlyName;
    
    private String countryCode;
    private String newCountryCode; //swarupa
    
    private String businessPhoneCode;
     public String getNewCountryCode() {
		return newCountryCode;
	}
	public void setNewCountryCode(String newCountryCode) {
		this.newCountryCode = newCountryCode;
	}
private Integer userType; //Krishna
    
    
	public Integer getUserType() {
		return userType;
	}
	public void setUserType(Integer userType) {
		this.userType = userType;
	}

    private String designation;//c
    
    private Timestamp passwordChangeDate;
 
    private String department;//c
 
    private String district;//c
    
    private String userName; // APPROVER USER ALIAS //c
    
    private String createdBy;//c
    
    private  String txnPassword; // Added for Corp User to fetch the TxnPwd from bv_user_profile table 23Aug2006
    
    private String typeOfUser;
    
    private String accRights;    
    
    private String fieldOfWork;

    private String currencyTrade;//Added for NOW
    
   
	private String source=null; //source will be Corp Admin if its created by admin for others null
 
 /* Sairam Added here for VASCO project -Start */
   private String newspreference5; // Sairam Added here for VASCO project

   private String sfAuthProvider;
   
   //Added for pending statement
   private String address;
   
   private String city;
   
   private String state;
   
   private String zip;
   
   private String country;
  
    private String merchantOTP ; // added for DEV-224 Waiver of OTP
   
    public String getNewspreference5() {
	return newspreference5;
}
public void setNewspreference5(String newspreference5) {
	this.newspreference5 = newspreference5;
}

/* Sairam Added here for VASCO project -End */
    private String authcount;
    
    private String mobileRegNo;
    
    private int loginPwdChangedDayCount=0;
    
    private String newMobileNumber;
    
    private String requestStatus;
    
    private String userCreationType;
    
    //Added for SHA encryption algorithm -Start
	private String loginHashing;
	private String profileHashing;
	private String transactionHashing;
	//Added for SHA encryption algorithm -End
    
	//Added for IRCTC OTP Starts
		private String irctcEnable;
		
		public String getIrctcEnable() {
			return irctcEnable;
		}
		public void setIrctcEnable(String irctcEnable) {
			this.irctcEnable = irctcEnable;
		}
	//Added for IRCTC OTP Ends
		
   	public String getMobileRegNo() {
		return mobileRegNo;
	}

	public void setMobileRegNo(String mobileRegNo) {
		this.mobileRegNo = mobileRegNo;
	}

	public String getAuthcount() {
		return authcount;
	}

	public void setAuthcount(String authcount) {
		this.authcount = authcount;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	/**
     * @return Returns the createdBy.
    */
    public String getCreatedBy()
    {
        return createdBy;
    }

    /**
     * @param createdBy The createdBy to set.
     */
    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }
    
    public String getBusinessPhone() {
        return businessPhone;
    }

    public void setBusinessPhone(String businessPhone) {
        this.businessPhone = businessPhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHintAnswer() {
        return hintAnswer;
    }

    public void setHintAnswer(String hintAnswer) {
        this.hintAnswer = hintAnswer;
    }

    public String getHindQuestion() {
        return hintQuestion;
    }

    public void setHintQuestion(String hintQuestion) {
        this.hintQuestion = hintQuestion;
    }

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public Timestamp getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Timestamp lastLoginInternet) {
        this.lastLoginDate = lastLoginInternet;
    }

    public Timestamp getLastTDateInternet() {
        return lastTDateInternet;
    }

    public void setLastTDateInternet(Timestamp lastTDateInternet) {
        this.lastTDateInternet = lastTDateInternet;
    }

    public String getLastTnameInternet() {
        return lastTnameInternet;
    }

    public void setLastTnameInternet(String lastTnameInternet) {
        this.lastTnameInternet = lastTnameInternet;
    }

    public Integer getLoginCount() {
        return loginCount;
    }

    public void setLoginCount(Integer loginCount) {
        this.loginCount = loginCount;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Integer getSmsSecurity() {
        return smsSecurity;
    }

    public void setSmsSecurity(Integer smsSecurity) {
        this.smsSecurity = smsSecurity;
    }

    public Double getTransactioLimit() {
        return transactioLimit;
    }

    public void setTransactioLimit(Double transactioLimit) {
        this.transactioLimit = transactioLimit;
    }


   
        public String toString() 
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	tempStringBuf.append("userAlias :");
            tempStringBuf.append(getUserAlias()); 
            tempStringBuf.append("|");
            tempStringBuf.append("email :");
          	tempStringBuf.append(email);
        	tempStringBuf.append("|");
        	tempStringBuf.append("homePhone :");
        	tempStringBuf.append(homePhone);
        	tempStringBuf.append("|");
        	tempStringBuf.append("mobileNumber :");
        	tempStringBuf.append(mobileNumber);
        	tempStringBuf.append("|");
        	tempStringBuf.append("transactionLimit :");
        	tempStringBuf.append(transactioLimit);
        	tempStringBuf.append("|");
        	tempStringBuf.append("loginCount :");
        	tempStringBuf.append(loginCount);
        	tempStringBuf.append("|");
        	tempStringBuf.append("lastTnameInternet :");
        	tempStringBuf.append(lastTnameInternet);
        	tempStringBuf.append("|");
        	tempStringBuf.append("lastTDateInternet :");
        	tempStringBuf.append(lastTDateInternet);
        	tempStringBuf.append("|");
        	tempStringBuf.append("hintQuestion :");
        	tempStringBuf.append(hintQuestion);
        	tempStringBuf.append("|");
        	tempStringBuf.append("hintAnswer :");
           	tempStringBuf.append(hintAnswer);
        	tempStringBuf.append("|");
        	tempStringBuf.append("homePhone :");
        	tempStringBuf.append(homePhone);
        	tempStringBuf.append("|");
        	tempStringBuf.append("friendlyName :");
            tempStringBuf.append(friendlyName);
            tempStringBuf.append("|");
            tempStringBuf.append("");
            tempStringBuf.append("businessPhoneCode :");
            tempStringBuf.append(businessPhoneCode);
            tempStringBuf.append("|");
            tempStringBuf.append("passwordChangeDate :");
            tempStringBuf.append(passwordChangeDate);
            tempStringBuf.append("|");
            tempStringBuf.append("fieldOfWork :");
            tempStringBuf.append(fieldOfWork);
            tempStringBuf.append("|");
            tempStringBuf.append("city :");
            tempStringBuf.append(city);
            tempStringBuf.append("|");
            tempStringBuf.append("state :");
            tempStringBuf.append(state);
            tempStringBuf.append("|");
            tempStringBuf.append("zip :");
            tempStringBuf.append(zip);
            tempStringBuf.append("|");
            tempStringBuf.append("country :");
            tempStringBuf.append(country);
			
			//Added for SHA encryption algorithm -Start
            tempStringBuf.append("|");
            tempStringBuf.append("loginHashing :");
            tempStringBuf.append(loginHashing);
            
            tempStringBuf.append("|");
            tempStringBuf.append("profileHashing :");
            tempStringBuf.append(profileHashing);
            
            tempStringBuf.append("|");
            tempStringBuf.append("transactionHashing :");
            tempStringBuf.append(transactionHashing);           
			//Added for SHA encryption algorithm -End

        	return tempStringBuf.toString();
        	
        } 

        public String getProfilepassword() {
            return profilepassword;
        }

        public void setProfilepassword(String profilepassword) {
            this.profilepassword = profilepassword;
        }

        public String getHintQuestion() {
            return hintQuestion;
        }

        public String getFriendlyName() {
            return friendlyName;
        }

        public void setFriendlyName(String friendlyName) {
            this.friendlyName = friendlyName;
        }

        public String getCountryCode() {
            return countryCode;
        }

        public void setCountryCode(String countryCode) {
            this.countryCode = countryCode;
        }

        public String getBusinessPhoneCode() {
            return businessPhoneCode;
        }

        public void setBusinessPhoneCode(String businessPhoneCode) {
            this.businessPhoneCode = businessPhoneCode;
        }

        /**
         * @return Returns the district.
         */
        public String getDistrict()
        {
            return district;
        }
        /**
         * @param district The district to set.
         */
        public void setDistrict(String district)
        {
            this.district = district;
        }
        public Timestamp getPasswordChangeDate() {
			return passwordChangeDate;
		}
      /**
         * @param designation The designation to set.
         */
        public void setDesignation(String designation)
        {
            this.designation = designation;
        }

        /**
         * @return Returns the department.
         */
        public String getDepartment()
        {
            return department;
        }

        /**
         * @param department The department to set.
         */
        public void setDepartment(String department)
        {
            this.department = department;
        }

		public void setPasswordChangeDate(Timestamp passwordChangeDate) {
			this.passwordChangeDate = passwordChangeDate;
		}

        /**
         * @return Returns the userName.
         */
        public String getUserName()
        {
            return userName;
        }

        /**
         * @param userName The userName to set.
         */
        public void setUserName(String userName)
        {
            this.userName = userName;
        } 


		/**
		 * @return Returns the designation.
		 */
		public String getDesignation() {
			return designation;
		}

        public String getTxnPassword() {
            return txnPassword;
        }

        public void setTxnPassword(String txnPassword) {
            this.txnPassword = txnPassword;
        }

		public String getAccRights() {
			return accRights;
		}

		public void setAccRights(String accRights) {
			this.accRights = accRights;
		}

		public String getTypeOfUser() {
			return typeOfUser;
		}

		public void setTypeOfUser(String typeOfUser) {
			this.typeOfUser = typeOfUser;
		}

		/**
		 * @return the taxTxnLimit
		 */
		public Double getTaxTxnLimit() {
			return taxTxnLimit;
		}

		/**
		 * @param taxTxnLimit the taxTxnLimit to set
		 */
		public void setTaxTxnLimit(Double taxTxnLimit) {
			this.taxTxnLimit = taxTxnLimit;
		}

		/**
		 * @return the fieldOfWork
		 */
		public String getFieldOfWork() {
			return fieldOfWork;
		}

		/**
		 * @param fieldOfWork the fieldOfWork to set
		 */
		public void setFieldOfWork(String fieldOfWork) {
			this.fieldOfWork = fieldOfWork;
		}

		public int getLoginPwdChangedDayCount() {
			return loginPwdChangedDayCount;
		}

		public void setLoginPwdChangedDayCount(int loginPwdChangedDayCount) {
			this.loginPwdChangedDayCount = loginPwdChangedDayCount;
		}
		
		 public String getCurrencyTrade() {
				return currencyTrade;
			}
		public void setCurrencyTrade(String currencyTrade) {
				this.currencyTrade = currencyTrade;
		}
		public String getSfAuthProvider() {
			return sfAuthProvider;
		}
		public void setSfAuthProvider(String sfAuthProvider) {
			this.sfAuthProvider = sfAuthProvider;
		}
		
        	public void setAddress(String address) {
			this.address = address;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getZip() {
			return zip;
		}
		public void setZip(String zip) {
			this.zip = zip;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getNewMobileNumber() {
			return newMobileNumber;
		}
		public void setNewMobileNumber(String newMobileNumber) {
			this.newMobileNumber = newMobileNumber;
		}
		public String getRequestStatus() {
			return requestStatus;
		}
		public void setRequestStatus(String requestStatus) {
			this.requestStatus = requestStatus;
		}
		public String getUserCreationType() {
			return userCreationType;
		}
		public void setUserCreationType(String userCreationType) {
			this.userCreationType = userCreationType;
		}
		public String getMerchantOTP() {
			return merchantOTP;
		}
		public void setMerchantOTP(String merchantOTP) {
			this.merchantOTP = merchantOTP;
		}
		//Added for SHA encryption algorithm -Start
		public String getLoginHashing() {
			return loginHashing;
		}
		public void setLoginHashing(String loginHashing) {
			this.loginHashing = loginHashing;
		}
		public String getProfileHashing() {
			return profileHashing;
		}
		public void setProfileHashing(String profileHashing) {
			this.profileHashing = profileHashing;
		}
		public String getTransactionHashing() {
			return transactionHashing;
		}
		public void setTransactionHashing(String transactionHashing) {
			this.transactionHashing = transactionHashing;
		}	
		//Added for SHA encryption algorithm -End
		
		//Added for Voice OTP
		public String getOtpOption() {
			return otpOption;
		}
		public void setOtpOption(String otpOption) {
			this.otpOption = otpOption;
		}		
		//Added for Voice OTP	
		
		private Timestamp lastLoginfailureDate;
		public Timestamp getLastLoginfailureDate() {
			return lastLoginfailureDate;
		}
		public void setLastLoginfailureDate(Timestamp lastLoginfailureDate) {
			this.lastLoginfailureDate = lastLoginfailureDate;
		}
	
   } 