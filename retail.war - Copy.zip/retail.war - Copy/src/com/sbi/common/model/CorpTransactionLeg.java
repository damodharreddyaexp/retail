/**
 * @(#) CorpTransactionLeg.java
 */

package com.sbi.common.model;

import com.sbi.common.model.TransactionLeg;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.sql.Timestamp;

public class CorpTransactionLeg extends TransactionLeg {

	private Integer scheduleStatus;

	private Timestamp scheduledDate;

	private String description;

	private String status;

	private String auth1Name;

	private String auth2Name;

	private String authType;

	private String transactionType;

	private String approver;

	private String branchName;

	private String echequeNo;

	private String maker;

	private String beneficiary;

	private String currentAuthLevel;

	private String statusCode;

	private String scheduled;

	private String processed;

	private String debitReferenceNo;

	private String creditReferenceNo;

	private String originalDebitBranch;

	private String debitStatus;

	private String creditStatus;

	private String creditDescription;

	private String creditNarrative1;

	private String creditNarrative2;

	private String creditNarrative3;

	private String recoRequired;

	private String creationTime;

	private Timestamp lastModTime;

	private String fileName;

	private String creditsCreated;

	private String errorCode;

	private String name;

	private String userName;

	private String businessLineId;

	private String authFlag;

	private String editFlag;

	private String cancelFlag;

	private String bankTType;

	private String corpRefNo;

	private int txnCount;

	private double oid;

	private String reason;

	private String authorisationLevel;

	private String supplierName;

	private String responseStatus;

	private String creditStatusCode;

	private String makerUserName;

	private String corporateId;

	private String corpName;

	private Date echequeDate;

	private String supplierId;

	private String auth1UserName;

	private String auth2UserName;
    
    private Double corporateAdminLimit;
	
	//Added for DDebit
	private String creditBranchCode;

	private String dealerCode;
	
	private String cancelDescription;
	
	private double transactionLimit;
	
	private String paymentID;
	
	private String corpMerchantString;
	//for RTGS/NEFT - begin
	private String rateOfInterest;
	
	private String utrNo;
	//<!-- CR5603 Phase3 Bulk Inbox Pagination-->
	private String beneficiaryCode;
	
	/*Added by Padma for Lien Unmarking*/
	private String lienType;
	
	//Added by Karthik
	private String utrCreditStatus;
	
	public String getUtrCreditStatus() {
		return utrCreditStatus;
	}

	public void setUtrCreditStatus(String utrCreditStatus) {
		this.utrCreditStatus = utrCreditStatus;
	}

	public String getLienType() {
			return lienType;
		}
	
		public void setLienType(String lienType) {
			this.lienType = lienType;
		}
	/*End*/

//added for saral
 public List getRoles() {
			return Roles;
		}

		public void setRoles(List roles) {
			Roles = roles;
		}

		private List Roles;//added for saral
	// end 
	
	// Added for CR 2921
	private String commissionType;
	//5577
	private String makerEmail;
	
	//added for NOW
	private String eborkingId;
	
	private String tempCreditStatus;

	
	public String getTempCreditStatus() {
		return tempCreditStatus;
	}

	public void setTempCreditStatus(String tempCreditStatus) {
		this.tempCreditStatus = tempCreditStatus;
	}

	public String getEborkingId() {
		return eborkingId;
	}

	public void setEborkingId(String eborkingId) {
		this.eborkingId = eborkingId;
	}
	public String getMakerEmail() {
		return makerEmail;
	}

	public void setMakerEmail(String makerEmail) {
		this.makerEmail = makerEmail;
	}
	//5577 ends
	public String getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(String rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	
	
	public String getCorpMerchantString() {
        return corpMerchantString;
    }

    public void setCorpMerchantString(String corpMerchantString) {
        this.corpMerchantString = corpMerchantString;
    }
    public String getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(String paymentID) {
		this.paymentID = paymentID;
	}

	public String getAuth1UserName() {
		return auth1UserName;
	}

	public void setAuth1UserName(String auth1UserName) {
		this.auth1UserName = auth1UserName;
	}

	public String getAuth2UserName() {
		return auth2UserName;
	}

	public void setAuth2UserName(String auth2UserName) {
		this.auth2UserName = auth2UserName;
	}

	public String getMakerUserName() {
		return makerUserName;
	}

	public void setMakerUserName(String makerUserName) {
		this.makerUserName = makerUserName;
	}

	public String getAuthorisationLevel() {
		return authorisationLevel;
	}

	public void setAuthorisationLevel(String authorisationLevel) {
		this.authorisationLevel = authorisationLevel;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getBankTType() {
		return bankTType;
	}

	public void setBankTType(String bankTType) {
		this.bankTType = bankTType;
	}

	public Integer getScheduleStatus() {
		return scheduleStatus;
	}

	public void setScheduleStatus(Integer scheduleStatus) {
		this.scheduleStatus = scheduleStatus;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getScheduledDate() {
		return scheduledDate;
	}

	public void setScheduledDate(Timestamp scheduledDate) {
		this.scheduledDate = scheduledDate;
	}

	public String getAuth1Name() {
		return auth1Name;
	}

	public void setAuth1Name(String auth1Name) {
		this.auth1Name = auth1Name;
	}

	public String getAuth2Name() {
		return auth2Name;
	}

	public void setAuth2Name(String auth2Name) {
		this.auth2Name = auth2Name;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getEchequeNo() {
		return echequeNo;
	}

	public void setEchequeNo(String echequeNo) {
		this.echequeNo = echequeNo;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}

	public String getCurrentAuthLevel() {
		return currentAuthLevel;
	}

	public void setCurrentAuthLevel(String currentAuthLevel) {
		this.currentAuthLevel = currentAuthLevel;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getScheduled() {
		return scheduled;
	}

	public void setScheduled(String scheduled) {
		this.scheduled = scheduled;
	}

	public String getProcessed() {
		return processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getCreditDescription() {
		return creditDescription;
	}

	public void setCreditDescription(String creditDescription) {
		this.creditDescription = creditDescription;
	}

	public String getCreditNarrative1() {
		return creditNarrative1;
	}

	public void setCreditNarrative1(String creditNarrative1) {
		this.creditNarrative1 = creditNarrative1;
	}

	public String getCreditNarrative2() {
		return creditNarrative2;
	}

	public void setCreditNarrative2(String creditNarrative2) {
		this.creditNarrative2 = creditNarrative2;
	}

	public String getCreditNarrative3() {
		return creditNarrative3;
	}

	public void setCreditNarrative3(String creditNarrative3) {
		this.creditNarrative3 = creditNarrative3;
	}

	public String getCreditReferenceNo() {
		return creditReferenceNo;
	}

	public void setCreditReferenceNo(String creditReferenceNo) {
		this.creditReferenceNo = creditReferenceNo;
	}

	public String getCreditsCreated() {
		return creditsCreated;
	}

	public void setCreditsCreated(String creditsCreated) {
		this.creditsCreated = creditsCreated;
	}

	public String getCreditStatus() {
		return creditStatus;
	}

	public void setCreditStatus(String creditStatus) {
		this.creditStatus = creditStatus;
	}

	public String getDebitReferenceNo() {
		return debitReferenceNo;
	}

	public void setDebitReferenceNo(String debitReferenceNo) {
		this.debitReferenceNo = debitReferenceNo;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOriginalDebitBranch() {
		return originalDebitBranch;
	}

	public void setOriginalDebitBranch(String originalDebitBranch) {
		this.originalDebitBranch = originalDebitBranch;
	}

	public String getRecoRequired() {
		return recoRequired;
	}

	public void setRecoRequired(String recoRequired) {
		this.recoRequired = recoRequired;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getBusinessLineId() {
		return businessLineId;
	}

	public void setBusinessLineId(String businessLineId) {
		this.businessLineId = businessLineId;
	}

	public String getAuthFlag() {
		return authFlag;
	}

	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}

	public String getCancelFlag() {
		return cancelFlag;
	}

	public void setCancelFlag(String cancelFlag) {
		this.cancelFlag = cancelFlag;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getCorpRefNo() {
		return corpRefNo;
	}

	public void setCorpRefNo(String corpRefNo) {
		this.corpRefNo = corpRefNo;
	}

	public String getDebitStatus() {
		return debitStatus;
	}

	public void setDebitStatus(String debitStatus) {
		this.debitStatus = debitStatus;
	}

	public double getOid() {
		return oid;
	}

	public void setOid(double oid) {
		this.oid = oid;
	}

	public int getTxnCount() {
		return txnCount;
	}

	public void setTxnCount(int txnCount) {
		this.txnCount = txnCount;
	}

	public Timestamp getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Timestamp lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getCreditStatusCode() {
		return creditStatusCode;
	}

	public void setCreditStatusCode(String creditStatusCode) {
		this.creditStatusCode = creditStatusCode;
	}

	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}

	public String getCorporateId() {
		return corporateId;
	}

	public void setCorpName(String corpName) {

		this.corpName = corpName;
	}

	public String getCorpName() {
		return corpName;
	}

	public Date getEchequeDate() {
		return echequeDate;
	}

	public void setEchequeDate(java.util.Date echequeDate) {
		this.echequeDate = echequeDate;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public Object[] toObject() {
		StringBuffer additionalParamsString = new StringBuffer("#|#");
		
		if (getAdditionalParams() != null) {
			
			Map outrefParams=getAdditionalParams();
			Iterator iterator = outrefParams.keySet().iterator();
			/*for (int i = 0; i < getAdditionalParams().size(); i++) {
				String key = "outref" + (i + 1);

				additionalParamsString.append(getAdditionalParams().get(key))
						.append("|");
			}*/
			while (iterator.hasNext()) {
				
				String key = (String) iterator.next();
				System.out.println(" *********** key ************** "+key);
				System.out.println(" *********** outrefParams.get(key) ************** "+outrefParams.get(key));
				additionalParamsString.append(key+"`~`"+outrefParams.get(key))
				.append("#|#");
			}
		}

		System.out.println("this.getNarrative1() ::: " + this.getNarrative1());
		Object[] obj = { this.getNarrative1(), this.getNarrative2(),
				this.getNarrative3(), this.getReferenceNo(), this.getType(),
				this.getAccountNo(), this.getBranchCode(),
				this.getStatusCode(), this.getStatusDescription(),
				this.getThirdPartyRef(), additionalParamsString.toString(),
				this.getAmount(), this.getCurrency(), this.getUserName(),
				this.getMerchantCode(), this.getRemarks(),
				new Integer(this.getScheduled()), this.getScheduledDate(),
				this.getBeneficiary(), this.getCorporateId(),
				this.getCorpName(),this.getSupplierId(),new Integer(this.getCurrentAuthLevel()) ,
				this.getBusinessLineId()};
		return obj;
	}

	public String getCreditBranchCode() {
		return creditBranchCode;
	}

	public void setCreditBranchCode(String creditBranchCode) {
		this.creditBranchCode = creditBranchCode;
	}

	public String getDealerCode() {
		return dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getCancelDescription() {
		return cancelDescription;
	}

	public void setCancelDescription(String cancelDescription) {
		this.cancelDescription = cancelDescription;
	}

	public double getTransactionLimit() {
		return transactionLimit;
	}

	public void setTransactionLimit(double transactionLimit) {
		this.transactionLimit = transactionLimit;
	}

    public Double getCorporateAdminLimit() {
        return corporateAdminLimit;
    }

    public void setCorporateAdminLimit(Double corporateAdminLimit) {
        this.corporateAdminLimit = corporateAdminLimit;
    }
    public String toString() {
    	
		StringBuffer stringBuffer = new StringBuffer();
		
		stringBuffer.append("echequeNo : "+echequeNo);
		stringBuffer.append("|");
		stringBuffer.append("currentAuthLevel : "+currentAuthLevel);
		stringBuffer.append("|");
		stringBuffer.append("txnCount : "+txnCount);
		stringBuffer.append("|");
		stringBuffer.append("corpRefNo : "+corpRefNo);
		stringBuffer.append("|");
		stringBuffer.append("corporateId : "+corporateId);
		stringBuffer.append("|");
		stringBuffer.append("auth1Name : "+auth1Name);
		stringBuffer.append("|");
		stringBuffer.append("auth2Name : "+auth2Name);
		stringBuffer.append("|");
		stringBuffer.append("transactionLimit : "+transactionLimit);
		stringBuffer.append("|");
		stringBuffer.append("maker : "+maker);
		stringBuffer.append("|");
		stringBuffer.append("makerUserName : "+makerUserName);
		stringBuffer.append("|");
		stringBuffer.append("bankTType : "+bankTType);
		stringBuffer.append("|");
		stringBuffer.append("branchName : "+branchName);
		stringBuffer.append("|");
		stringBuffer.append("status : "+status);
		stringBuffer.append("|");
		stringBuffer.append("statusCode : "+statusCode);
		stringBuffer.append("|");
		stringBuffer.append("scheduled : "+scheduled);
		stringBuffer.append("|");
		stringBuffer.append("scheduleStatus : "+scheduleStatus);
		stringBuffer.append("|");
		stringBuffer.append("scheduledDate : "+scheduledDate);
		stringBuffer.append("|");
		stringBuffer.append("description : "+description);
		stringBuffer.append("|");
		stringBuffer.append("approver : "+approver);
		stringBuffer.append("|");
		stringBuffer.append("beneficiary : "+beneficiary);
		stringBuffer.append("|");
		stringBuffer.append("debitReferenceNo : "+debitReferenceNo);
		stringBuffer.append("|");
		stringBuffer.append("creditReferenceNo : "+creditReferenceNo);
		stringBuffer.append("|");
		stringBuffer.append("debitStatus : "+debitStatus);
		stringBuffer.append("|");
		stringBuffer.append("creditStatus : "+creditStatus);
		stringBuffer.append("|");
		stringBuffer.append("originalDebitBranch : "+originalDebitBranch);
		stringBuffer.append("|");
		stringBuffer.append("fileName : "+fileName);
		stringBuffer.append("|");
		stringBuffer.append("creditDescription : "+creditDescription);
		stringBuffer.append("|");
		stringBuffer.append("creditNarrative1 : "+creditNarrative1);
		stringBuffer.append("|");
		stringBuffer.append("creditNarrative2 : "+creditNarrative2);
		stringBuffer.append("|");
		stringBuffer.append("creditNarrative3 : "+creditNarrative3);
		stringBuffer.append("|");
		stringBuffer.append("recoRequired : "+recoRequired);
		stringBuffer.append("|");
		stringBuffer.append("creationTime : "+creationTime);
		stringBuffer.append("|");
		stringBuffer.append("lastModTime : "+lastModTime);
		stringBuffer.append("|");
		stringBuffer.append("creditsCreated : "+creditsCreated);
		stringBuffer.append("|");
		stringBuffer.append("errorCode : "+errorCode);
		stringBuffer.append("|");
		stringBuffer.append("name : "+name);
		stringBuffer.append("|");
		stringBuffer.append("userName : "+userName);
		stringBuffer.append("|");
		stringBuffer.append("businessLineId : "+businessLineId);
		stringBuffer.append("|");
		stringBuffer.append("authFlag : "+authFlag);
		stringBuffer.append("|");
		stringBuffer.append("editFlag : "+editFlag);
		stringBuffer.append("|");
		stringBuffer.append("cancelFlag : "+cancelFlag);
		stringBuffer.append("|");
		stringBuffer.append("reason : "+reason);
		stringBuffer.append("|");
		stringBuffer.append("oid : "+oid);
		stringBuffer.append("|");
		stringBuffer.append("authorisationLevel : "+authorisationLevel);
		stringBuffer.append("|");
		stringBuffer.append("supplierName : "+supplierName);
		stringBuffer.append("|");
		stringBuffer.append("responseStatus : "+responseStatus);
		stringBuffer.append("|");
		stringBuffer.append("creditStatusCode : "+creditStatusCode);
		stringBuffer.append("|");
		stringBuffer.append("corporateId : "+corporateId);
		stringBuffer.append("|");
		stringBuffer.append("corpName : "+corpName);
		stringBuffer.append("|");
		stringBuffer.append("echequeDate : "+echequeDate);
		stringBuffer.append("|");
		stringBuffer.append("supplierId : "+supplierId);
		stringBuffer.append("|");
		stringBuffer.append("auth1UserName : "+auth1UserName);
		stringBuffer.append("|");
		stringBuffer.append("auth2UserName : "+auth2UserName);
		stringBuffer.append("|");
		stringBuffer.append("creditBranchCode : "+creditBranchCode);
		stringBuffer.append("|");
		stringBuffer.append("dealerCode : "+dealerCode);
		stringBuffer.append("|");
		stringBuffer.append("cancelDescription : "+cancelDescription);
		stringBuffer.append("|");
		stringBuffer.append("paymentID : "+paymentID);
		stringBuffer.append("|");
		//Added for CR 2921
		stringBuffer.append("commissiontype : "+commissionType);
		stringBuffer.append("|");
		//5577
		stringBuffer.append("makeremail : "+makerEmail);
		stringBuffer.append("|");
		
		
		return super.toString();
	}

	public String getUtrNo() {
		return utrNo;
	}

	public void setUtrNo(String utrNo) {
		this.utrNo = utrNo; 
		
	}

	public String getCommissionType() {
		return commissionType;
	}

	public void setCommissionType(String commissionType) {
		this.commissionType = commissionType;
	}

	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}

	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}
	
	
}