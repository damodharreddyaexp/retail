package com.sbi.common.model;

import com.sbi.common.model.BaseModel;

public class CategoryDetails implements BaseModel{

	private String instituteId;
	private String categoryID;
	private String categoryName;
	private String accountNo;
	private String branchCode;
	private String docPath; 
	private String fileMode; //  iCollect
	private String paramName; //  iCollect
	private String optionString;
	public String toString(){
		 
        StringBuffer tempStringBuf = new StringBuffer();
        
        tempStringBuf.append("instituteId :");
        tempStringBuf.append(instituteId);
        tempStringBuf.append(" | ");
        tempStringBuf.append("categoryID :");
        tempStringBuf.append(categoryID);
        tempStringBuf.append(" | ");
        tempStringBuf.append("categoryName :");
        tempStringBuf.append(categoryName);
        tempStringBuf.append(" | ");
        tempStringBuf.append("accountNo :");
        tempStringBuf.append(accountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append("branchCode :");
        tempStringBuf.append(branchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append("docPath :");
        tempStringBuf.append(docPath);
        tempStringBuf.append(" | ");
        
        return tempStringBuf.toString();
    }
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getCategoryID() {
		return categoryID;
	}
	public void setCategoryID(String categoryID) {
		this.categoryID = categoryID;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getInstituteId() {
		return instituteId;
	}
	public void setInstituteId(String instituteId) {
		this.instituteId = instituteId;
	}

	public String getDocPath() {
		return docPath;
	}

	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	public String getFileMode() {
		return fileMode;
	}

	public void setFileMode(String fileMode) {
		this.fileMode = fileMode;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getOptionString() {
		return optionString;
	}

	public void setOptionString(String optionString) {
		this.optionString = optionString;
	}
	
	
	
	
	
}
