package com.sbi.common.model;

import java.util.Map;

public class RegionalKeyBoardModel {
	
	private Map symbolMap;
	private String encValuesAry;
	private String symbolAry;
	private String keyId;
	private String temp = null;
	
	
	
	
	
	public String getKeyId() {
		return keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public Map getSymbolMap() {
		return symbolMap;
	}
	
	public void setSymbolMap(Map symbolMap) {
		this.symbolMap = symbolMap;
	}
	
	
	public String getEncValuesAry() {
		return encValuesAry;
	}
	
	
	
	public void setEncValuesAry(String encValuesAry) {
		this.encValuesAry = encValuesAry;
	}
	
	
	
	public String getSymbolAry() {
		return symbolAry;
	}
	
	
	
	public void setSymbolAry(String symbolAry) {
		this.symbolAry = symbolAry;
	}
	
	
	

}
  