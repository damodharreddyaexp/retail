package com.sbi.common.model;

import java.util.Date;

public class HardwareTokenDetails implements BaseModel{

	
	private String userId;
	private String mobileNo;
	private String oldMobileNo;
	private String modifyUser;
	private String branchCode;
	private String userRole;
	private String status;
	private String referenceNo;
	private String contryCode;
	private Date requestDate;
	
	 public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
	
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getOldMobileNo() {
		return oldMobileNo;
	}
	public void setOldMobileNo(String oldMobileNo) {
		this.oldMobileNo = oldMobileNo;
	}
	public String getModifyUser() {
		return modifyUser;
	}
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	
	public String getContryCode() {
		return contryCode;
	}
	public void setContryCode(String contryCode) {
		this.contryCode = contryCode;
	}
		
	public Date getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	public String toString()
	    {
	        StringBuffer tempStringBuf = new StringBuffer();
	        tempStringBuf.append(userId);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(mobileNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(oldMobileNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(modifyUser);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(branchCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(userRole);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(status);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(referenceNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(contryCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(requestDate);
	        tempStringBuf.append(" | ");
	        
	        return tempStringBuf.toString();
	    } 
}
