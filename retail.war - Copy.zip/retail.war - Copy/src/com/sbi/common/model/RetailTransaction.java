/**
 * @(#) RetailTransaction.java
 */

package com.sbi.common.model;



public class RetailTransaction extends Transaction
{
     
    
    
    
}
