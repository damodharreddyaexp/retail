/* 
 * CoreAccountStatement.java 
 * Created on May 09, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * may 09, 2006 RAMACHANDRAN - Initial Creation
 */
  

package com.sbi.common.model;

import java.sql.Timestamp;

public class CoreAccountStatement implements BaseModel
{
	private String request_Id;
         
    private String param1;
    
    private String param2;
          
    private String param4;

    private Timestamp creation_time;
    
    private String status;

    private String productType;
    
    private String branchCode;
    
    private String param5;
    
    private String param7;
    
    public String getParam7() {
		return param7;
	}

	public void setParam7(String param7) {
		this.param7 = param7;
	}

    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(request_Id);
        tempStringBuf.append(" | ");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        tempStringBuf.append(param1);
        tempStringBuf.append(" | ");
        tempStringBuf.append(param2);
        tempStringBuf.append(" | ");
        tempStringBuf.append(param4);
        tempStringBuf.append(" | ");
        tempStringBuf.append(creation_time);
        tempStringBuf.append(" | ");
        tempStringBuf.append(productType);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(param5);
        tempStringBuf.append(" | ");
        tempStringBuf.append(param7);
               
        return tempStringBuf.toString();
    }

	public Timestamp getCreation_time() {
		return creation_time;
	}

	public void setCreation_time(Timestamp creation_time) {
		this.creation_time = creation_time;
	}

	public String getParam1() {
		return param1;
	}

	public void setParam1(String param1) {
		this.param1 = param1;
	}

	public String getParam2() {
		return param2;
	}

	public void setParam2(String param2) {
		this.param2 = param2;
	}

	public String getParam4() {
		return param4;
	}

	public void setParam4(String param4) {
		this.param4 = param4;
	}

	public String getParam5() {
		return param5;
	}

	public void setParam5(String param5) {
		this.param5 = param5;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getRequest_Id() {
		return request_Id;
	}

	public void setRequest_Id(String request_Id) {
		this.request_Id = request_Id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	 
} 
