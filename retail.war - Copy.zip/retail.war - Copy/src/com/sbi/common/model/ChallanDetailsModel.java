package com.sbi.common.model;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * 
 * This class holds the contents to be displayed as challan Details for the
 * Non Agency Bank module
 * 
 * @author Siva
 * @version 1.0
 */
public class ChallanDetailsModel implements Serializable {
	  private String referenceNumber;
	  
	  private String fileName;
	  
	  private String corporateId;
	  
	  private String accountNumber;
	  
	  private String status;
	  
	  private String modifiedFileName;
	  
	  public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModifiedFileName() {
		return modifiedFileName;
	}
	public void setModifiedFileName(String modifiedFileName) {
		this.modifiedFileName = modifiedFileName;
	}
	
}
