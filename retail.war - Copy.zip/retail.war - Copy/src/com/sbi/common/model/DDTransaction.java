/*
 * DDTransaction.java
 * Created on Nov 2, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 2, 2005 MURUGAN K - Initial Creation

package com.sbi.common.model;

public class DDTransaction extends Transaction {

  private Address address = null;

   public void setAddress(Address address)
   {
       this.address = address;
   }
   public Address getAddress()
   {
       return address;
   } 
   //Added for DD IOI
   private String ioiEnabled;
   
   public String getIoiEnabled() {
		return ioiEnabled;
	}

	public void setIoiEnabled(String ioiEnabled) {
		this.ioiEnabled = ioiEnabled;
	}
	//End
   public String toString()
   
   {
   	StringBuffer tempStringBuf= new StringBuffer();
   	tempStringBuf.append("address:"); 
 	tempStringBuf.append(address); 
   	
   return tempStringBuf.toString();
}
}