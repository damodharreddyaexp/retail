
/*
 * SMSAlertSpec.java
 * Created on Dec 31, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 31, 2005 KRISHNA KUMAR - Initial Creation

/**
 * @(#) SMSAlertSpec.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class SMSAlertSpec implements BaseModel
{
    private Integer userId;
    
    private String alertName;
    
    private Integer alertId;
    
    private String deliveryType;
    
    private Long jobId;
    
    private Timestamp creationDate;
    
    private Integer notifyFrequency;
    
    private String stringCol1;
    
    private String stringCol2;
    
    private String stringCol3;
    
    private String stringCol4;
    
    private Integer intCol1;
    
    private Integer intCol2;
    
    private Integer intCol3;
    
    private Double floatCol1;
    
    private Double floatCol2;
    
    private Double floatCol3;
    
    private Timestamp dateCol1;
    
    private Timestamp dateCol2;
    
    private Timestamp dateCol3;
    
    private String description;
    
    private String scheduleName;

    /**
     * @return Returns the scheduleName.
     */
    public String getScheduleName()
    {
        return scheduleName;
    }

    /**
     * @param scheduleName The scheduleName to set.
     */
    public void setScheduleName(String scheduleName)
    {
        this.scheduleName = scheduleName;
    }

    /**
     * @return Returns the description.
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description The description to set.
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return Returns the alertId.
     */
    public Integer getAlertId()
    {
        return alertId;
    }

    /**
     * @param alertId The alertId to set.
     */
    public void setAlertId(Integer alertId)
    {
        this.alertId = alertId;
    }

    /**
     * @return Returns the alertName.
     */
    public String getAlertName()
    {
        return alertName;
    }

    /**
     * @param alertName The alertName to set.
     */
    public void setAlertName(String alertName)
    {
        this.alertName = alertName;
    }

    /**
     * @return Returns the creationDate.
     */
    public Timestamp getCreationDate()
    {
        return creationDate;
    }

    /**
     * @param creationDate The creationDate to set.
     */
    public void setCreationDate(Timestamp creationDate)
    {
        this.creationDate = creationDate;
    }

    /**
     * @return Returns the dateCol1.
     */
    public Timestamp getDateCol1()
    {
        return dateCol1;
    }

    /**
     * @param dateCol1 The dateCol1 to set.
     */
    public void setDateCol1(Timestamp dateCol1)
    {
        this.dateCol1 = dateCol1;
    }

    /**
     * @return Returns the dateCol2.
     */
    public Timestamp getDateCol2()
    {
        return dateCol2;
    }

    /**
     * @param dateCol2 The dateCol2 to set.
     */
    public void setDateCol2(Timestamp dateCol2)
    {
        this.dateCol2 = dateCol2;
    }

    /**
     * @return Returns the dateCol3.
     */
    public Timestamp getDateCol3()
    {
        return dateCol3;
    }

    /**
     * @param dateCol3 The dateCol3 to set.
     */
    public void setDateCol3(Timestamp dateCol3)
    {
        this.dateCol3 = dateCol3;
    }

    /**
     * @return Returns the deliveryType.
     */
    public String getDeliveryType()
    {
        return deliveryType;
    }

    /**
     * @param deliveryType The deliveryType to set.
     */
    public void setDeliveryType(String deliveryType)
    {
        this.deliveryType = deliveryType;
    }

    /**
     * @return Returns the floatCol1.
     */
    public Double getFloatCol1()
    {
        return floatCol1;
    }

    /**
     * @param floatCol1 The floatCol1 to set.
     */
    public void setFloatCol1(Double floatCol1)
    {
        this.floatCol1 = floatCol1;
    }

    /**
     * @return Returns the floatCol2.
     */
    public Double getFloatCol2()
    {
        return floatCol2;
    }

    /**
     * @param floatCol2 The floatCol2 to set.
     */
    public void setFloatCol2(Double floatCol2)
    {
        this.floatCol2 = floatCol2;
    }

    /**
     * @return Returns the floatCol3.
     */
    public Double getFloatCol3()
    {
        return floatCol3;
    }

    /**
     * @param floatCol3 The floatCol3 to set.
     */
    public void setFloatCol3(Double floatCol3)
    {
        this.floatCol3 = floatCol3;
    }

    /**
     * @return Returns the intCol1.
     */
    public Integer getIntCol1()
    {
        return intCol1;
    }

    /**
     * @param intCol1 The intCol1 to set.
     */
    public void setIntCol1(Integer intCol1)
    {
        this.intCol1 = intCol1;
    }

    /**
     * @return Returns the intCol2.
     */
    public Integer getIntCol2()
    {
        return intCol2;
    }

    /**
     * @param intCol2 The intCol2 to set.
     */
    public void setIntCol2(Integer intCol2)
    {
        this.intCol2 = intCol2;
    }

    /**
     * @return Returns the intCol3.
     */
    public Integer getIntCol3()
    {
        return intCol3;
    }

    /**
     * @param intCol3 The intCol3 to set.
     */
    public void setIntCol3(Integer intCol3)
    {
        this.intCol3 = intCol3;
    }


    /**
     * @return Returns the notifyFrequency.
     */
    public Integer getNotifyFrequency()
    {
        return notifyFrequency;
    }

    /**
     * @param notifyFrequency The notifyFrequency to set.
     */
    public void setNotifyFrequency(Integer notifyFrequency)
    {
        this.notifyFrequency = notifyFrequency;
    }

    /**
     * @return Returns the stringCol1.
     */
    public String getStringCol1()
    {
        return stringCol1;
    }

    /**
     * @param stringCol1 The stringCol1 to set.
     */
    public void setStringCol1(String stringCol1)
    {
        this.stringCol1 = stringCol1;
    }

    /**
     * @return Returns the stringCol2.
     */
    public String getStringCol2()
    {
        return stringCol2;
    }

    /**
     * @param stringCol2 The stringCol2 to set.
     */
    public void setStringCol2(String stringCol2)
    {
        this.stringCol2 = stringCol2;
    }

    /**
     * @return Returns the stringCol3.
     */
    public String getStringCol3()
    {
        return stringCol3;
    }

    /**
     * @param stringCol3 The stringCol3 to set.
     */
    public void setStringCol3(String stringCol3)
    {
        this.stringCol3 = stringCol3;
    }

    /**
     * @return Returns the stringCol4.
     */
    public String getStringCol4()
    {
        return stringCol4;
    }

    /**
     * @param stringCol4 The stringCol4 to set.
     */
    public void setStringCol4(String stringCol4)
    {
        this.stringCol4 = stringCol4;
    }

    /**
     * @return Returns the userId.
     */
    public Integer getUserId()
    {
        return userId;
    }

    /**
     * @param userId The userId to set.
     */
    public void setUserId(Integer userId)
    {
        this.userId = userId;
    }
    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append("userId = ");
        tempStringBuf.append(userId);
        tempStringBuf.append("|");
        tempStringBuf.append("alertName = ");
        tempStringBuf.append(alertName);
        tempStringBuf.append("|");
        tempStringBuf.append("alertId = ");
        tempStringBuf.append(alertId);
        tempStringBuf.append("|");
        tempStringBuf.append("deliveryType = ");
        tempStringBuf.append(deliveryType);
        tempStringBuf.append("|");
        tempStringBuf.append("jobId = ");
        tempStringBuf.append(jobId);
        tempStringBuf.append("|");
        tempStringBuf.append("creationDate = ");
        tempStringBuf.append(creationDate);
        tempStringBuf.append("|");
        tempStringBuf.append("notifyFrequency = ");
        tempStringBuf.append(notifyFrequency);
        tempStringBuf.append("|");
        tempStringBuf.append("stringCol1 = ");
        tempStringBuf.append(stringCol1);
        tempStringBuf.append("|");
        tempStringBuf.append("stringCol2 = ");
        tempStringBuf.append(stringCol2);
        tempStringBuf.append("|");
        tempStringBuf.append("stringCol3 = ");
        tempStringBuf.append(stringCol3);
        tempStringBuf.append("|");
        tempStringBuf.append("stringCol4 = ");
        tempStringBuf.append(stringCol4);
        tempStringBuf.append("|");
        tempStringBuf.append("intCol1 = ");
        tempStringBuf.append(intCol1);
        tempStringBuf.append("|");
        tempStringBuf.append("intCol2 = ");
        tempStringBuf.append(intCol2);
        tempStringBuf.append("|");
        tempStringBuf.append("intCol3 = ");
        tempStringBuf.append(intCol3);
        tempStringBuf.append("|");
        tempStringBuf.append("floatCol1 = ");
        tempStringBuf.append(floatCol1);
        tempStringBuf.append("|");
        tempStringBuf.append("floatCol2 = ");
        tempStringBuf.append(floatCol2);
        tempStringBuf.append("|");
        tempStringBuf.append("floatCol3 = ");
        tempStringBuf.append(floatCol3);
        tempStringBuf.append("|");
        tempStringBuf.append("dateCol1 = ");
        tempStringBuf.append(dateCol1);
        tempStringBuf.append("|");
        tempStringBuf.append("dateCol2 = ");
        tempStringBuf.append(dateCol2);
        tempStringBuf.append("|");
        tempStringBuf.append("dateCol3 = ");
        tempStringBuf.append(dateCol3);
        tempStringBuf.append("|");
        tempStringBuf.append("description = ");
        tempStringBuf.append(description);
        tempStringBuf.append("|");
        tempStringBuf.append("scheduleName = ");
        tempStringBuf.append(scheduleName);
        tempStringBuf.append("|");
        return tempStringBuf.toString();
    }

	public Long getJobId() {
		return jobId;
	}
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}
    
}

