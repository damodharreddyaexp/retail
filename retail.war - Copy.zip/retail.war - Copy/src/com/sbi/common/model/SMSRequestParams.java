/*
 * SMSRequestParams.java
 * Created on Feb 09, 2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 09, 2011 PONNUSAMY - Initial Creation
package com.sbi.common.model;

import java.util.List;


public class SMSRequestParams{
	private String messageId;// Unique message id for each message retreived from StringUtils method uniqueNumberUsingDateAndRandom(String moduleType)
private String bankCode;//bank code
private String userName;// sender user name
private String moduleName;//module name of the application avaialable in /WEB-INF/conf/configuration.properties
private String messageTypeId; //unique ID for message type. to be assigned in each application
private String mobileNo; // message to be sent
private String countryCode; // country code of the mobile number
private String sendOrder; // order number of sending SMS. defualt is 0
private List<String> param; /*
 List of values to incorporate into message_content of sms_config_master table.
  List order should be same as in table. Ex: {"Merchant Name","high security pwd"}
  param1=Merchant Name
  param2=high security pwd
  message_content value=Your High security password for #param1# transaction is #param2#. SBI will never call to disclose this password.
 */ 

private String deliveryFlag;// whether to send message through SMS or Voice
/*
private String voiceOTP;

public String getVoiceOTP() {
	return voiceOTP;
}
public void setVoiceOTP(String voiceOTP) {
	this.voiceOTP = voiceOTP;
}*/

private String emailId; 
/**** Starts Added For SCFU  USER Credentials and forgot password by SMS CR#2720 & #2747****/
private String emailSubject; 
private String reqType;
/**** Ends Added For SCFU USER Credentials and forgot password by SMS CR#2720 & #2747****/

public String getMessageId() {
	return messageId;
}
public void setMessageId(String messageId) {
	this.messageId = messageId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getBankCode() {
	return bankCode;
}
public void setBankCode(String bankCode) {
	this.bankCode = bankCode;
}
public String getModuleName() {
	return moduleName;
}
public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}
public String getMessageTypeId() {
	return messageTypeId;
}
public void setMessageTypeId(String messageTypeId) {
	this.messageTypeId = messageTypeId;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getCountryCode() {
	return countryCode;
}
public void setCountryCode(String countryCode) {
	this.countryCode = countryCode;
}
public String getSendOrder() {
	return sendOrder;
}
public void setSendOrder(String sendOrder) {
	this.sendOrder = sendOrder;
}
public List<String> getParam() {
	return param;
}
public void setParam(List<String> param) {
	this.param = param;
}

public String getDeliveryFlag() {
	return deliveryFlag;
}
public void setDeliveryFlag(String deliveryFlag) {
	this.deliveryFlag = deliveryFlag;
}

public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getEmailSubject() {
	return emailSubject;
}
public void setEmailSubject(String emailSubject) {
	this.emailSubject = emailSubject;
}
public String getReqType() {
	return reqType;
}
public void setReqType(String reqType) {
	this.reqType = reqType;
}

}
