/*
 * CorporateTP.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 SG33414 - Initial Creation
package com.sbi.common.model;

import java.sql.Timestamp;

import com.sbi.common.model.BaseModel;

public class CpsmsBeneficiary implements BaseModel {
	
	private String corporateId;
	private String beneficiaryName;
	private String accountNo;
	private String beneficiaryCode;
	private String ifscCode;
	private String branchCode;
	private String bankName;
	private String oid;
	private String status;
	private String outref7;
	private String aadharId;
	private String bankIIN;
	
	public String getAadharId() {
		return aadharId;
	}
	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}
	public String getBankIIN() {
		return bankIIN;
	}
	public void setBankIIN(String bankIIN) {
		this.bankIIN = bankIIN;
	}
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}
	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOutref7() {
		return outref7;
	}
	public void setOutref7(String outref7) {
		this.outref7 = outref7;
	}
	

}
