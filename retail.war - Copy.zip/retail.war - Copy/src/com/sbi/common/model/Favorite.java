/** 
 * @(#) Favorite.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;


public class Favorite implements BaseModel
{
    /**
     * Stores login name of the user
     */
    private String userName;
    
    /**
     * Stores nick name of the favorite
     */
    private String nickName;
    
    /**
     * Stores account no incase of QuickLook, Current Balance and Account Statement. Stores debit account no for Funds Transfer, Third Party Transfer, Bill Payment.
     */
    private String debitAccountNo;
    
    /**
     * Stores branch code incase of QuickLook, Current Balance and Account Statement. Stores debit branch code for Funds Transfer, Third Party Transfer, Bill Payment.
     */
    private String debitBranchCode;
    
    /**
     *  Stores debit account type for Funds Transfer, Third Party Transfer, Bill Payment.
     */
    private String debitAccountType;
    
    /**
     * Stores credit account no for Funds Transfer and Third Party Transfer
     */
    private String creditAccountNo;
    
    /**
     * Stores credit branch codefor Funds Transfer, Third Party Transfer
     */
    private String creditBranchCode;
    
    /**
     * Stores credit account type for Funds Transfer, Third Party Transfer
     */
    private String creditAccountType;
    
    /**
     * If true editing of favorite at the time of execution is allowed. If false editing not allowed.
     */
    private String allowEdit;
    
    /**
     * Stores account statment duration in days or amount for Funds Transfer, Third Party Transfer and Bill Payment
     */
    private String param1;
    
    /**
     * Stores remarks for Funds Transfer, Third Party Transfer and Bill Payment
     */
    private String param2;
    
    /**
     * Stores biller nickname for bill payment or third party name  for Third party transfer
     */
    private String param3;
    
    /**
     *  Stores Amount for transfer to credit account
     */
    private String param4;
    
    /**
     * Additional Param
     */
    private String param5;
    
    /** Store type of Favorite *
     *
     **/
    private String favoriteType;
    /**
     * Creation Time
     */
    
    private String  description;
    
    private Timestamp creationTime;
    
    public String getAllowEdit() {
        return allowEdit;
    }
    public Timestamp getCreationTime() {
        return creationTime;
    }
    public String getCreditAccountNo() {
        return creditAccountNo;
    }
    public String getCreditAccountType() {
        return creditAccountType;
    }
    public String getCreditBranchCode() {
        return creditBranchCode;
    }
    public String getDebitAccountNo() {
        return debitAccountNo;
    }
    public String getDebitAccountType() {
        return debitAccountType;
    }
    public String getDebitBranchCode() {
        return debitBranchCode;
    }
    public String getFavoriteType() {
        return favoriteType;
    }
    public String getNickName() {
        return nickName;
    }
    public String getParam1() {
        return param1;
    }
    public String getParam2() {
        return param2;
    }
    public String getParam3() {
        return param3;
    }
    public String getParam4() {
        return param4;
    }
    public String getParam5() {
        return param5;
    }
    public String getUserName() {
        return userName;
    }
    public void setAllowEdit(String allowEdit) {
        this.allowEdit = allowEdit;
    }
    public void setCreationTime(Timestamp creationTime) {
        this.creationTime = creationTime;
    }
    public void setCreditAccountNo(String creditAccountNo) {
        this.creditAccountNo = creditAccountNo;
    }
    public void setCreditAccountType(String creditAccountType) {
        this.creditAccountType = creditAccountType;
    }
    public void setCreditBranchCode(String creditBranchCode) {
        this.creditBranchCode = creditBranchCode;
    }
    public void setDebitAccountNo(String debitAccountNo) {
        this.debitAccountNo = debitAccountNo;
    }
    public void setDebitAccountType(String debitAccountType) {
        this.debitAccountType = debitAccountType;
    }
    public void setDebitBranchCode(String debitBranchCode) {
        this.debitBranchCode = debitBranchCode;
    }
    public void setFavoriteType(String favoriteType) {
        this.favoriteType = favoriteType;
    }
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    public void setParam1(String param1) {
        this.param1 = param1;
    }
    public void setParam2(String param2) {
        this.param2 = param2;
    }
    public void setParam3(String param3) {
        this.param3 = param3;
    }
    public void setParam4(String param4) {
        this.param4 = param4;
    }
    public void setParam5(String param5) {
        this.param5 = param5;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String toString(){
        StringBuffer sbuff = new StringBuffer();
        sbuff.append("favoriteType = " + favoriteType + " | ");
        sbuff.append("username = " + userName + " | ");
        sbuff.append("nickName = " + nickName + " | ");
        sbuff.append("debitAccountNo = " + debitAccountNo + " | ");
        sbuff.append("debitBranchCode= " + debitBranchCode + " | ");
        sbuff.append("debitAccountType = " + debitAccountType + " | ");
        sbuff.append("creditAccountNo = " + creditAccountNo + " | ");
        sbuff.append("creditBranchCode = " + creditBranchCode + " | ");
        sbuff.append("creditAccountType = " + creditAccountType + " | ");
        sbuff.append("allowEdit = " + allowEdit + " | ");
        sbuff.append("param1 = " + param1 + " | ");
        sbuff.append("param1 = " + param2 + " | ");
        sbuff.append("param1 = " + param3 + " | ");
        sbuff.append("param1 = " + param4 + " | ");
        sbuff.append("param1 = " + param5);     
        return sbuff.toString();
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
