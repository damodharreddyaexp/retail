package com.sbi.common.model;

import java.sql.Timestamp;

public class TicketThread implements BaseModel {
	
	private String ticketNo;
	
	private String thread_originator;
	
	private Timestamp thread_date;
	
	private String thread;

	

	public String getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	
	public String getThread() {
		return thread;
	}

	
	public void setThread(String thread) {
		this.thread = thread;
	}

	
	public Timestamp getThread_date() {
		return thread_date;
	}

	public void setThread_date(Timestamp thread_date) {
		this.thread_date = thread_date;
	}

	
	public String getThread_originator() {
		return thread_originator;
	}

	
	public void setThread_originator(String thread_originator) {
		this.thread_originator = thread_originator;
	}

	public String toString()
	{
		StringBuffer tmp=new StringBuffer();
		tmp.append(ticketNo);
		tmp.append("|");
		tmp.append(thread_originator);
		tmp.append("|");
		tmp.append(thread_date);
		tmp.append("|");
		tmp.append(thread);
		
		return tmp.toString();
	}
	
}
