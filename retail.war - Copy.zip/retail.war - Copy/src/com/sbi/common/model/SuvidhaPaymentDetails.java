/* 
 * SuvidhaPaymentDetails.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Apr 18, 2008 ARTHI - Initial Creation

package com.sbi.common.model;

import java.sql.Timestamp;

import com.sbi.common.model.BaseModel;

public class SuvidhaPaymentDetails implements BaseModel
{
    private String refenceNo;
         
    private Double amount;

    private Timestamp transactionDate;

    private String status;
    
    private String instituteName;    
   

	/**
	 * @return Returns the amount.
	 */
	public Double getAmount() {
		return amount;
	}

	/**
	 * @param amount The amount to set.
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}

	/**
	 * @return Returns the instituteName.
	 */
	public String getInstituteName() {
		return instituteName;
	}

	/**
	 * @param instituteName The instituteName to set.
	 */
	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	/**
	 * @return Returns the refenceNo.
	 */
	public String getRefenceNo() {
		return refenceNo;
	}

	/**
	 * @param refenceNo The refenceNo to set.
	 */
	public void setRefenceNo(String refenceNo) {
		this.refenceNo = refenceNo;
	}

	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return Returns the transactionDate.
	 */
	public Timestamp getTransactionDate() {
		return transactionDate;
	}

	/**
	 * @param transactionDate The transactionDate to set.
	 */
	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}
 
} 
