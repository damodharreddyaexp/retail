/*
 * CR-1848
 * SN27223
 */


package com.sbi.common.model;

import java.sql.Timestamp;

public class DematLienEnquiry implements BaseModel
{

	String lienRefNo;
	
	String moslRefNo;
	
	String isinCode;
	
	Double amount;
	
	Timestamp creationTime;
	
	String lienMarkStatus;
	
	String lienReleaseStatus;
	
	String dmatAcctNo;
   
	String inbStatus;
	
	String qty;
	
	String statusDescription;
      
	String merchantCode; //added by uthir
	
	public String getQty() {
		return qty;
	}





	public void setQty(String qty) {
		this.qty = qty;
	}





	public Double getAmount() {
		return amount;
	}





	public void setAmount(Double amount) {
		this.amount = amount;
	}





	public Timestamp getCreationTime() {
		return creationTime;
	}





	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}





	public String getLienMarkStatus() {
		return lienMarkStatus;
	}





	public void setLienMarkStatus(String lienMarkStatus) {
		this.lienMarkStatus = lienMarkStatus;
	}





	public String getLienRefNo() {
		return lienRefNo;
	}





	public void setLienRefNo(String lienRefNo) {
		this.lienRefNo = lienRefNo;
	}

	public String getLienReleaseStatus() {
		return lienReleaseStatus;
	}

	public void setLienReleaseStatus(String lienReleaseStatus) {
		this.lienReleaseStatus = lienReleaseStatus;
	}


	public String getMoslRefNo() {
		return moslRefNo;
	}

	public void setMoslRefNo(String moslRefNo) {
		this.moslRefNo = moslRefNo;
	} 
    
	public String getDmatAcctNo() {
		return dmatAcctNo;
	}





	public void setDmatAcctNo(String dmatAcctNo) {
		this.dmatAcctNo = dmatAcctNo;
	}
   

	 public String toString()
	    {
	        StringBuffer tempStringBuf = new StringBuffer();      
	        tempStringBuf.append("lienRefNo:");
	        tempStringBuf.append(lienRefNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("moslRefNo:");
	        tempStringBuf.append(moslRefNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("isinCode:");
	        tempStringBuf.append(isinCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("amount:");
	        tempStringBuf.append(amount);
	        tempStringBuf.append(" | ");	
	        tempStringBuf.append("creationTime:");
	        tempStringBuf.append(creationTime);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("lienMarkStatus:");
	        tempStringBuf.append(lienMarkStatus);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("statusDescription:");
	        tempStringBuf.append(statusDescription);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append("lienReleaseStatus:");
	        tempStringBuf.append(lienReleaseStatus);
	        tempStringBuf.append(" | ");         
	        tempStringBuf.append("dmatAcctNo:");
	        tempStringBuf.append(dmatAcctNo);
	        tempStringBuf.append(" | ");  
	        tempStringBuf.append("inbStatus:");
	        tempStringBuf.append(inbStatus);
	        tempStringBuf.append(" | ");   
	        tempStringBuf.append("qty:");
	        tempStringBuf.append(qty);
	        tempStringBuf.append(" | "); 
	        tempStringBuf.append("merchantCode:");
	        tempStringBuf.append(merchantCode);
	        return tempStringBuf.toString();
	    }





	public String getInbStatus() {
		return inbStatus;
	}





	public void setInbStatus(String inbStatus) {
		this.inbStatus = inbStatus;
	}





	public String getStatusDescription() {
		return statusDescription;
	}





	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}





	public String getIsinCode() {
		return isinCode;
	}





	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}





	public String getMerchantCode() {
		return merchantCode;
	}





	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}





	


    
     
    
}
    
    
  