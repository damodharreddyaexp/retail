package com.sbi.common.model;

public class ApproveDelTPModelStatus implements BaseModel{
    
    private String beneficiaryName;

    private String beneficiaryCode;

    private String accountNo;

    private String branchCode;
    
    //private Integer rowID;
    private Long rowID;
    
    private String status;
    
   
    
    public String getAccountNo()
    {
        return accountNo;
    }



    public void setAccountNo(String accountNo)
    {
        this.accountNo = accountNo;
    }



    public String getBeneficiaryCode()
    {
        return beneficiaryCode;
    }



    public void setBeneficiaryCode(String beneficiaryCode)
    {
        this.beneficiaryCode = beneficiaryCode;
    }



    public String getBeneficiaryName()
    {
        return beneficiaryName;
    }



    public void setBeneficiaryName(String beneficiaryName)
    {
        this.beneficiaryName = beneficiaryName;
    }



    public String getBranchCode()
    {
        return branchCode;
    }



    public void setBranchCode(String branchCode)
    {
        this.branchCode = branchCode;
    }



    /*public Integer getRowID()
    {
        return rowID;
    }



    public void setRowID(Integer rowID)
    {
        this.rowID = rowID;
    }*/



    public String getStatus()
    {
        return status;
    }



    public Long getRowID() {
		return rowID;
	}



	public void setRowID(Long rowID) {
		this.rowID = rowID;
	}



	public void setStatus(String status)
    {
        this.status = status;
    }



    public String toString() {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(beneficiaryName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(beneficiaryCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(accountNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(branchCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(rowID);
        tempStringBuf.append(" | ");
        tempStringBuf.append(status);
        tempStringBuf.append(" | ");
        
        return tempStringBuf.toString();
    }

}