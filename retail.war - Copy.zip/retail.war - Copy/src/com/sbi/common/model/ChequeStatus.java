/* 
 * ChequeStatus.java
 * Created on Dec 2, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 2, 2005 MURUGAN K - Initial Creation
package com.sbi.common.model;

import java.sql.Timestamp;

public class ChequeStatus  implements BaseModel {
    
    private String chequeno;

    private String status;

    private Timestamp stopdate;

    private String accountno;

    private String branchcode;

    private String referenceno;

    private Float amount;

    private String reasonStoppage;

    private String username;
    
    private String branchName;
    
  //  private Timestamp transactionTime;

    public String getAccountno() {
        return accountno;
    }

    public void setAccountno(String accountno) {
        this.accountno = accountno;
    }

    public Float getAmount() {
        return amount;
    }

    public void setAmount(Float amount) {
        this.amount = amount;
    }

    public String getBranchcode() {
        return branchcode;
    }

    public void setBranchcode(String branchcode) {
        this.branchcode = branchcode;
    }

    public String getChequeno() {
        return chequeno;
    }

    public void setChequeno(String chequeno) {
        this.chequeno = chequeno;
    }

    public String getReasonStoppage() {
        return reasonStoppage;
    }

    public void setReasonStoppage(String reasonStoppage) {
        this.reasonStoppage = reasonStoppage;
    }

    public String getReferenceno() {
        return referenceno;
    }

    public void setReferenceno(String referenceno) {
        this.referenceno = referenceno;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStopdate() {
        return stopdate;
    }

    public void setStopdate(Timestamp stopdate) {
        this.stopdate = stopdate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }
}
