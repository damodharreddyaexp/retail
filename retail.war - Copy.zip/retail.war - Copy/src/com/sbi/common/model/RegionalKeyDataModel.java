package com.sbi.common.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.sbi.common.utils.CiperUtility;
 

public class RegionalKeyDataModel {
	
	private Map<String, RegionalKeyBoardModel> engVirtualKeyBoardDefault = null;
	private Map<String, RegionalKeyBoardModel> hindiVirtualKeyBoardDefault = null;
	private Map<String, RegionalKeyBoardModel> tamilVirtualKeyBoardDefault = null;	
	private Map<String, RegionalKeyBoardModel> marathiVirtualKeyBoardDefault = null; // Marathi Keyboard - Martin
	private Map<String, RegionalKeyBoardModel> teluguVirtualKeyBoardDefault = null; // Telugu Keyboard - Martin
	private Map<String, RegionalKeyBoardModel> gujaratiVirtualKeyBoardDefault = null; // Gujarati Keyboard - Martin
	private Map<String, RegionalKeyBoardModel> punjabiVirtualKeyBoardDefault = null; // Punjabi Keyboard - Martin
	private Map<String, RegionalKeyBoardModel> bengaliVirtualKeyBoardDefault = null; // Bengali Keyboard - Karthik Raju
	private Map<String, RegionalKeyBoardModel> kannadaVirtualKeyBoardDefault = null; // Kannada Keyboard - Karthik Raju
	private Map<String, RegionalKeyBoardModel> malayalamVirtualKeyBoardDefault = null; // Malayalam Keyboard - Karthik Raju
	private Map<String, RegionalKeyBoardModel> assamiVirtualKeyBoardDefault = null;  //Assami Keyborad-Sathya Manoharan
	private Map<String, RegionalKeyBoardModel> oriyaVirtualKeyBoardDefault = null;  //Oriya Keyborad-Sathya Manoharan
	private Map<String, RegionalKeyBoardModel> urduVirtualKeyBoardDefault = null;  //Urdu Keyborad-Sathya Manoharan
	
	private Map<String, String> englishImageValues  = null;
	private Map<String, String> hindiImiageValues  = null;
	private Map<String, String> tamilImageValues  = null;
	private Map<String, String> marathiImageValues  = null; // Marathi Keyboard - Martin
	private Map<String, String> teluguImageValues  = null; // Telugu Keyboard - Martin
	private Map<String, String> gujaratiImageValues  = null; // Gujarati Keyboard - Martin
	private Map<String, String> punjabiImageValues  = null; // Punjabi Keyboard - Martin
	private Map<String, String> bengaliImageValues  = null; // Bengali Keyboard - Karthik Raju
	private Map<String, String> kannadaImageValues  = null; // Kannada Keyboard - Karthik Raju
	private Map<String, String> malayalamImageValues  = null; // Malayalam Keyboard - Karthik Raju
	private Map<String, String> assamiImageValues  = null;   //Assami Keyborad-Sathya Manoharan
	private Map<String, String> oriyaImageValues  = null;   //Oriya Keyborad-Sathya Manoharan
	private Map<String, String> urduImageValues  = null;   //Urdu Keyborad-Sathya Manoharan

	private String nonKeyBoardCharacter ="";
	private Set<String> randomSet = null;
	private int columns = 13;
	private int firstColumn = 10;
	private CiperUtility cyutil = null;
	
	
	
	
	public List<RegionalKeyBoardModel> getRegionalKeyBoardList(String key){
		List<RegionalKeyBoardModel> list = new ArrayList();
		list.add(engVirtualKeyBoardDefault.get(key));
		list.add(hindiVirtualKeyBoardDefault.get(key));
		list.add(tamilVirtualKeyBoardDefault.get(key));
		list.add(marathiVirtualKeyBoardDefault.get(key)); // Marathi Keyboard - Martin
		list.add(teluguVirtualKeyBoardDefault.get(key)); // Telugu Keyboard - Martin
		list.add(gujaratiVirtualKeyBoardDefault.get(key)); // Gujarati Keyboard - Martin
		list.add(punjabiVirtualKeyBoardDefault.get(key)); // Punjabi Keyboard - Martin
		list.add(bengaliVirtualKeyBoardDefault.get(key)); // Bengali Keyboard - Karthik Raju
		list.add(kannadaVirtualKeyBoardDefault.get(key)); // Kannada Keyboard - Karthik Raju
		list.add(malayalamVirtualKeyBoardDefault.get(key)); // Malayalam Keyboard - Karthik Raju
		list.add(assamiVirtualKeyBoardDefault.get(key));    //Assami Keyborad-Sathya Manoharan
		list.add(oriyaVirtualKeyBoardDefault.get(key));    //Oriya Keyborad-Sathya Manoharan
		list.add(urduVirtualKeyBoardDefault.get(key));    //Urdu Keyborad-Sathya Manoharan
		return list;
	}
	
	
	public void append(String keyId, RegionalKeyBoardModel model, String lang){
		
		if(lang.equals("eng")){
			engVirtualKeyBoardDefault.put(keyId, model);
		}else if(lang.equals("hindi")){
			hindiVirtualKeyBoardDefault.put(keyId, model);
		}else if(lang.equals("tamil")){
			tamilVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("marathi")){ // Marathi Keyboard - Martin
			marathiVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("telugu")){ // Telugu Keyboard - Martin
			teluguVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("gujarati")){ // Gujarati Keyboard - Martin
			gujaratiVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("punjabi")){ // Punjabi Keyboard - Martin
			punjabiVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("bengali")){ // Bengali Keyboard - Karthik Raju
			bengaliVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("kannada")){ // Kannada Keyboard - Karthik Raju
			kannadaVirtualKeyBoardDefault.put(keyId, model);
		}else if (lang.equals("malayalam")){ // Malayalam Keyboard - Karthik Raju
			malayalamVirtualKeyBoardDefault.put(keyId, model);
		}
		else if (lang.equals("assami")){  //Assami Keyborad-Sathya Manoharan
			assamiVirtualKeyBoardDefault.put(keyId, model);
		}
		else if (lang.equals("oriya")){  //Oriya Keyborad-Sathya Manoharan
			oriyaVirtualKeyBoardDefault.put(keyId, model);
		}
		else if (lang.equals("urdu")){  //Urdu Keyborad-Sathya Manoharan
			urduVirtualKeyBoardDefault.put(keyId, model);
		}
		else{
			;
		}
	}
	
	
	
	public void append(ProfileEncPsdModel model){
		String lang = model.getLang();
		String keyId = model.getKey();
		if(lang.equals("eng")){
			engVirtualKeyBoardDefault.put(keyId, model.getRkbModel());
		}else if(lang.equals("hindi")){
			hindiVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("tamil")){
			tamilVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("marathi")){ // Marathi Keyboard - Martin
			marathiVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("telugu")){ // Telugu Keyboard - Martin
			teluguVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("gujarati")){ // Gujarati Keyboard - Martin
			gujaratiVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("punjabi")){ // Punjabi Keyboard - Martin
			punjabiVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("bengali")){ // Bengali Keyboard - Karthik Raju
			bengaliVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("kannada")){ // Kannada Keyboard - Karthik Raju
			kannadaVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}else if(lang.equals("malayalam")){ // Malayalam Keyboard - Karthik Raju
			malayalamVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}
		else if(lang.equals("assami")){ //Assami Keyborad-Sathya Manoharan
			assamiVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}
		else if(lang.equals("oriya")){ //Oriya Keyborad-Sathya Manoharan
			oriyaVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}
		else if(lang.equals("urdu")){ //Urdu Keyborad-Sathya Manoharan
			urduVirtualKeyBoardDefault.put(keyId,  model.getRkbModel());
		}
		else{
			;
		}
	}
	
	
	
	public void build() throws Exception{
		setEngVirtualKeyBoardDefault(encryptKeyboard(getEnglishImageValues(),getRandomSet()));
		setHindiVirtualKeyBoardDefault(encryptKeyboard(getHindiImiageValues(),getRandomSet()));
		setTamilVirtualKeyBoardDefault(encryptKeyboard(getTamilImageValues(),getRandomSet()));
		setMarathiVirtualKeyBoardDefault(encryptKeyboard(getMarathiImageValues(),getRandomSet())); // Marathi Keyboard - Martin
		setTeluguVirtualKeyBoardDefault(encryptKeyboard(getTeluguImageValues(),getRandomSet())); // Telugu Keyboard - Martin
		setGujaratiVirtualKeyBoardDefault(encryptKeyboard(getGujaratiImageValues(),getRandomSet())); // Gujarati Keyboard - Martin
		setPunjabiVirtualKeyBoardDefault(encryptKeyboard(getPunjabiImageValues(), getRandomSet())); // Punjabi Keyboard - Martin
		setBengaliVirtualKeyBoardDefault(encryptKeyboard(getBengaliImageValues(), getRandomSet())); // Bengali Keyboard - Karthik Raju
		setKannadaVirtualKeyBoardDefault(encryptKeyboard(getKannadaImageValues(), getRandomSet())); // Kannada Keyboard - Karthik Raju
		setMalayalamVirtualKeyBoardDefault(encryptKeyboard(getMalayalamImageValues(), getRandomSet())); // Malayalam Keyboard - Karthik Raju
		setAssamiVirtualKeyBoardDefault(encryptKeyboard(getAssamiImageValues(), getRandomSet())); //Assami Keyboard - Sathya Manoharan
		setOriyaVirtualKeyBoardDefault(encryptKeyboard(getOriyaImageValues(), getRandomSet())); // Oriya Keyboard - Sathya Manoharan
		setUrduVirtualKeyBoardDefault(encryptKeyboard(getUrduImageValues(), getRandomSet())); //Urdu Keyboard -Sathya Manoharan
	}

	private Map<String, RegionalKeyBoardModel> encryptKeyboard(Map<String, String> mapValues, Set<String> randomSet) throws Exception{
		Iterator<String> itr = randomSet.iterator();
		String key = null;
		String[][] symbolArray= getSymbolKeyBArray(mapValues,true);
		String[][] valueArray= getValueKeyBArray(mapValues,true);
		String[][] encValueArray = null;
		RegionalKeyBoardModel rkbModel = null;
		Map<String, RegionalKeyBoardModel> regionalKeyMap = new HashMap<String, RegionalKeyBoardModel>();
		while(itr.hasNext()){
			key = itr.next();
			encValueArray = getEncryptedVirtualEngKeyBArray(valueArray,key);
			rkbModel = new RegionalKeyBoardModel();
			rkbModel.setKeyId(key);
			rkbModel.setSymbolAry(getJavascriptArray(symbolArray));
			rkbModel.setEncValuesAry(getJavascriptArray(encValueArray));
			regionalKeyMap.put(key,rkbModel);
		}
		
		return regionalKeyMap;
	}
		
	
	public String[][] getSymbolKeyBArray(Map<String, String> map,boolean imageService){
		int rows  = calculateRows(map.size(), firstColumn, columns);
			String[][] engArray = new String[rows][columns];
			Iterator<String> itr = map.keySet().iterator();
			for(int i=0; i<rows;i++){
				// First row contains only 10 images.
				if(i==0 && imageService){
					for(int j=0;j<firstColumn && itr.hasNext();j++){
						engArray[i][j+(columns - firstColumn)] = map.get((String)itr.next());					 
					}
					i++;
				}
				for(int j=0;j<columns && itr.hasNext();j++){
						engArray[i][j] = map.get((String)itr.next());					 
				}
			}
			return engArray;
		}
		
	public String[][] getValueKeyBArray(Map<String, String> map, boolean imageService){
		int rows  = calculateRows(map.size(), firstColumn,columns);
		String[][] engArray = new String[rows][columns];
		Iterator<String> itr = map.keySet().iterator();
		for(int i=0; i<rows;i++){
			// First row contains only 10 images.
			if(i==0 && imageService){
				for(int j=0;j<firstColumn && itr.hasNext();j++){
					engArray[i][j+(columns - firstColumn)] = itr.next();					 
				}
				i++;
			}
			
			
			for(int j=0;j<columns && itr.hasNext();j++){
					engArray[i][j] = itr.next();					 
			}
		}
		
		return engArray;
	}
	
	
	
	
	

	public String[][] getEncryptedVirtualEngKeyBArray(String[][] ary,String keyId)throws Exception{
		String[][] encary =  new String[ary.length][ary[0].length];
		 for(int i=0; i<ary.length;i++){
			 for(int j=0; j<ary[i].length; j++){
				 if(ary[i][j] == null){
					 encary[i][j] = null;
				 }else{
					 encary[i][j] =  getNonKeyBoardCharacter() + cyutil.aescbcEncrypt(ary[i][j], keyId);
				 }
			 }
		 }
		 return encary;
	}
	
	
	private int calculateRows(int size, int firstCol, int col){
		int rows = (size- firstCol)/columns;
		int mod = (size- firstCol)%columns;
		if(mod > 0) ++rows;
		return ++rows;
	}
		
	
	public String getJavascriptArray(String[][] ary){
		String str =  "" ; // "[";
		String tmp = "";
		 for(int i=0; i<ary.length;i++){
			 str += "[";
			 for(int j=0; j<ary[i].length; j++){
				 tmp = ary[i][j];
				 if(tmp !=null && !tmp.equalsIgnoreCase("null")){
					 str+="\'"+ ary[i][j] +"\',";	
				 }
							 
			 }
			 str = str.substring(0, str.length()-1);
			 str +="],";
		 }	 		 
		 str = str.substring(0, str.length()-1);
		 //str+="]";
		 
		// System.out.println(str);
		return str;
	}
	
	
	
	public Map getStringAsMap(String str){
		 String[] ary = str.split(",");
        Map symbolMap = new LinkedHashMap(20);       
        for(String s : ary){
     	   symbolMap.put(s,s+".jpg");
        }
		return symbolMap;
	}
	
	
	
	
	
	public RegionalKeyBoardModel getVirtualKeyBoardModel(String keyId, Map<String, String> englishImageValues, boolean imageService)throws Exception {
		String[][] engSymKBAry = getSymbolKeyBArray(englishImageValues, imageService);
		String[][] engValueKBAry = getValueKeyBArray(englishImageValues,imageService);
		String[][] engEncValueKBAry = getEncryptedVirtualEngKeyBArray(engValueKBAry, keyId);
		RegionalKeyBoardModel rkbModel = new RegionalKeyBoardModel();
		rkbModel.setKeyId(keyId);
		rkbModel.setSymbolAry(getJavascriptArray(engSymKBAry));
		rkbModel.setEncValuesAry(getJavascriptArray(engEncValueKBAry));
		return rkbModel;
	}

	

	
	
	public RegionalKeyBoardModel concat(RegionalKeyBoardModel userModel, RegionalKeyBoardModel defaultModel){
		String encValueAry = "["+ userModel.getEncValuesAry() + "," + defaultModel.getEncValuesAry() + "]";
		String symValueAry = "[" + userModel.getSymbolAry() + "," + defaultModel.getSymbolAry() + "]";	
		userModel.setEncValuesAry(encValueAry);
		userModel.setSymbolAry(symValueAry);
		return userModel;
	}


	
	public String getDecryptedString(String encString, String delimter,String keyId,String escapeChar)throws Exception{
		String[] ary = encString.split(delimter);
		String decrypted = "";
		boolean caps = false;
		for(String s: ary){
			if(s!= null){				
				caps = (s.indexOf("@")== -1)? false:true;
				s = s.replaceAll("@", "");
				s = s.replaceAll(escapeChar, "");
				if(!caps)
					decrypted += cyutil.aescbcDecrypt(s, keyId);
				else
					decrypted += cyutil.aescbcDecrypt(s, keyId).toUpperCase();
			}
		}
		return decrypted;
	}
	
	
	
	
	public ProfileEncPsdModel getDecryptedObject(String encString, String delimter,String keyId,String escapeChar)throws Exception{
		ProfileEncPsdModel model = new ProfileEncPsdModel();
		model.setEncString(encString);
		String[] ary = encString.split(delimter);
		String decrypted = "";
		String imageStr = "";
		int imgCount = 0;
		String nonImageStr = "";
		int nonImageCount = 0;
		String temp = "";
		boolean caps = false;
		int index = -1;
		for(String s: ary){
			if(s!= null){
				index = s.indexOf("?");
				caps = (s.indexOf("@")== -1)? false:true;
				s = s.replaceAll(escapeChar, "");
				s = s.replaceAll("@", "");
				if(!caps)
					temp = cyutil.aescbcDecrypt(s, keyId);
				else
					temp = cyutil.aescbcDecrypt(s, keyId).toUpperCase();
				if(index == -1){					
					nonImageStr = nonImageStr + temp + ",";
					nonImageCount++;
				}else{
					imageStr = imageStr + temp + ",";
					imgCount++;
				}
				decrypted += temp; 
			}
		}
		
		model.setDecString(decrypted);
		model.setImageCount(imgCount);
		model.setNonImageCount(nonImageCount);
		model.setNonImageString(nonImageStr);
		model.setImageString(imageStr);
		return model;
	}
	

	
	
	
	
	/**
	 * @return the engVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getEngVirtualKeyBoardDefault() {
		return engVirtualKeyBoardDefault;
	}
	/**
	 * @param engVirtualKeyBoardDefault the engVirtualKeyBoardDefault to set
	 */
	public void setEngVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> engVirtualKeyBoardDefault) {
		this.engVirtualKeyBoardDefault = engVirtualKeyBoardDefault;
	}
	/**
	 * @return the hindiVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getHindiVirtualKeyBoardDefault() {
		return hindiVirtualKeyBoardDefault;
	}
	/**
	 * @param hindiVirtualKeyBoardDefault the hindiVirtualKeyBoardDefault to set
	 */
	public void setHindiVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> hindiVirtualKeyBoardDefault) {
		this.hindiVirtualKeyBoardDefault = hindiVirtualKeyBoardDefault;
	}
	/**
	 * @return the tamilVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getTamilVirtualKeyBoardDefault() {
		return tamilVirtualKeyBoardDefault;
	}
	/**
	 * @param tamilVirtualKeyBoardDefault the tamilVirtualKeyBoardDefault to set
	 */
	public void setTamilVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> tamilVirtualKeyBoardDefault) {
		this.tamilVirtualKeyBoardDefault = tamilVirtualKeyBoardDefault;
	}

	/**
	 * @return the marathiVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getMarathiVirtualKeyBoardDefault() {
		return marathiVirtualKeyBoardDefault;
	}

	/**
	 * @param marathiVirtualKeyBoardDefault the marathiVirtualKeyBoardDefault to set
	 */
	public void setMarathiVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> marathiVirtualKeyBoardDefault) {
		this.marathiVirtualKeyBoardDefault = marathiVirtualKeyBoardDefault;
	}
	
	/**
	 * @return the teluguVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getTeluguVirtualKeyBoardDefault() {
		return teluguVirtualKeyBoardDefault;
	}

	/**
	 * @param teluguVirtualKeyBoardDefault the teluguVirtualKeyBoardDefault to set
	 */
	public void setTeluguVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> teluguVirtualKeyBoardDefault) {
		this.teluguVirtualKeyBoardDefault = teluguVirtualKeyBoardDefault;
	}


	public void setBasicDataMap(Map<String, Map<String, String>> regionalDataMap) {
		englishImageValues = regionalDataMap.get("eng");
		hindiImiageValues =  regionalDataMap.get("hindi");
		tamilImageValues =   regionalDataMap.get("tamil");	
		marathiImageValues =   regionalDataMap.get("marathi");	// Marathi Keyboard - Martin
		teluguImageValues =   regionalDataMap.get("telugu");	// Telugu Keyboard - Martin
		gujaratiImageValues =   regionalDataMap.get("gujarati");	// Gujarati Keyboard - Martin
		punjabiImageValues =   regionalDataMap.get("punjabi");	// Punjabi Keyboard - Martin
		bengaliImageValues =   regionalDataMap.get("bengali");	// Bengali Keyboard - Karthik Raju
		kannadaImageValues =   regionalDataMap.get("kannada");	// Kannada Keyboard - Karthik Raju
		malayalamImageValues =   regionalDataMap.get("malayalam");	// Malayalam Keyboard - Karthik Raju
		assamiImageValues	=	regionalDataMap.get("assami");   //Assami Keyborad-Sathya Manoharan
		oriyaImageValues	=	regionalDataMap.get("oriya");   //Oriya Keyborad-Sathya Manoharan
		urduImageValues	=	regionalDataMap.get("urdu");   //Urdu Keyborad-Sathya Manoharan
		
		// TODO Auto-generated method stub
		
	}
	
	
	
	public String getNonKeyBoardCharacter() {
		return nonKeyBoardCharacter;
	}


	public void setNonKeyBoardCharacter(String nonKeyBoardCharacter) {
		this.nonKeyBoardCharacter = nonKeyBoardCharacter;
	}


	public void createEncVirtualKeyBoard() {
		// TODO Auto-generated method stub
		
	}

	public void setKeySet(Set<String> randomSet) {
		this.randomSet = randomSet;
		
	}

	public void createEncVirtualKeyBoard(Set<String> parentRandomSet) {
		randomSet = parentRandomSet;
		createEncVirtualKeyBoard();		
	}

	public Map<String, String> getEnglishImageValues() {
		return englishImageValues;
	}


	public void setEnglishImageValues(Map<String, String> englishImageValues) {
		this.englishImageValues = englishImageValues;
	}


	public Map<String, String> getHindiImiageValues() {
		return hindiImiageValues;
	}


	public void setHindiImiageValues(Map<String, String> hindiImiageValues) {
		this.hindiImiageValues = hindiImiageValues;
	}


	public Map<String, String> getTamilImageValues() {
		return tamilImageValues;
	}


	public void setTamilImageValues(Map<String, String> tamilImageValues) {
		this.tamilImageValues = tamilImageValues;
	}

	public Map<String, String> getMarathiImageValues() {
		return marathiImageValues;
	}


	public void setMarathiImageValues(Map<String, String> marathiImageValues) {
		this.marathiImageValues = marathiImageValues;
	}
	
	
	public Map<String, String> getTeluguImageValues() {
		return teluguImageValues;
	}


	public void setTeluguImageValues(Map<String, String> teluguImageValues) {
		this.teluguImageValues = teluguImageValues;
	}

	public Map<String, String> getAssamiImageValues() {
		return assamiImageValues;
	}


	public void setAssamiImageValues(Map<String, String> assamiImageValues) {
		this.assamiImageValues = assamiImageValues;
	}


	public int getColumns() {
		return columns;
	}


	public void setColumns(int columns) {
		this.columns = columns;
	}


	public int getFirstColumn() {
		return firstColumn;
	}


	public void setFirstColumn(int firstColumn) {
		this.firstColumn = firstColumn;
	}


	public Set<String> getRandomSet() {
		return randomSet;
	}


	public void setRandomSet(Set<String> randomSet) {
		this.randomSet = randomSet;
	}


	public CiperUtility getCyutil() {
		return cyutil;
	}


	public void setCyutil(CiperUtility cyutil) {
		this.cyutil = cyutil;
	}

	/**
	 * @return the gujaratiVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getGujaratiVirtualKeyBoardDefault() {
		return gujaratiVirtualKeyBoardDefault;
	}


	/**
	 * @param gujaratiVirtualKeyBoardDefault the gujaratiVirtualKeyBoardDefault to set
	 */
	public void setGujaratiVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> gujaratiVirtualKeyBoardDefault) {
		this.gujaratiVirtualKeyBoardDefault = gujaratiVirtualKeyBoardDefault;
	}


	/**
	 * @return the gujaratiImageValues
	 */
	public Map<String, String> getGujaratiImageValues() {
		return gujaratiImageValues;
	}


	/**
	 * @param gujaratiImageValues the gujaratiImageValues to set
	 */
	public void setGujaratiImageValues(Map<String, String> gujaratiImageValues) {
		this.gujaratiImageValues = gujaratiImageValues;
	}


	/**
	 * @return the punjabiVirtualKeyBoardDefault
	 */
	public Map<String, RegionalKeyBoardModel> getPunjabiVirtualKeyBoardDefault() {
		return punjabiVirtualKeyBoardDefault;
	}


	/**
	 * @param punjabiVirtualKeyBoardDefault the punjabiVirtualKeyBoardDefault to set
	 */
	public void setPunjabiVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> punjabiVirtualKeyBoardDefault) {
		this.punjabiVirtualKeyBoardDefault = punjabiVirtualKeyBoardDefault;
	}


	/**
	 * @return the punjabiImageValues
	 */
	public Map<String, String> getPunjabiImageValues() {
		return punjabiImageValues;
	}


	/**
	 * @param punjabiImageValues the punjabiImageValues to set
	 */
	public void setPunjabiImageValues(Map<String, String> punjabiImageValues) {
		this.punjabiImageValues = punjabiImageValues;
	}

	public Map<String, RegionalKeyBoardModel> getBengaliVirtualKeyBoardDefault() {
		return bengaliVirtualKeyBoardDefault;
	}


	public void setBengaliVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> bengaliVirtualKeyBoardDefault) {
		this.bengaliVirtualKeyBoardDefault = bengaliVirtualKeyBoardDefault;
	}


	public Map<String, String> getBengaliImageValues() {
		return bengaliImageValues;
	}


	public void setBengaliImageValues(Map<String, String> bengaliImageValues) {
		this.bengaliImageValues = bengaliImageValues;
	}


	public Map<String, RegionalKeyBoardModel> getKannadaVirtualKeyBoardDefault() {
		return kannadaVirtualKeyBoardDefault;
	}


	public void setKannadaVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> kannadaVirtualKeyBoardDefault) {
		this.kannadaVirtualKeyBoardDefault = kannadaVirtualKeyBoardDefault;
	}


	public Map<String, RegionalKeyBoardModel> getMalayalamVirtualKeyBoardDefault() {
		return malayalamVirtualKeyBoardDefault;
	}


	public void setMalayalamVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> malayalamVirtualKeyBoardDefault) {
		this.malayalamVirtualKeyBoardDefault = malayalamVirtualKeyBoardDefault;
	}


	public Map<String, String> getKannadaImageValues() {
		return kannadaImageValues;
	}


	public void setKannadaImageValues(Map<String, String> kannadaImageValues) {
		this.kannadaImageValues = kannadaImageValues;
	}


	public Map<String, String> getMalayalamImageValues() {
		return malayalamImageValues;
	}


	public void setMalayalamImageValues(Map<String, String> malayalamImageValues) {
		this.malayalamImageValues = malayalamImageValues;
	}


	public Map<String, RegionalKeyBoardModel> getAssamiVirtualKeyBoardDefault() {
		return assamiVirtualKeyBoardDefault;
	}

	public void setAssamiVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> assamiVirtualKeyBoardDefault) {
		this.assamiVirtualKeyBoardDefault = assamiVirtualKeyBoardDefault;
	}


	public Map<String, RegionalKeyBoardModel> getOriyaVirtualKeyBoardDefault() {
		return oriyaVirtualKeyBoardDefault;
	}


	public void setOriyaVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> oriyaVirtualKeyBoardDefault) {
		this.oriyaVirtualKeyBoardDefault = oriyaVirtualKeyBoardDefault;
	}


	public Map<String, RegionalKeyBoardModel> getUrduVirtualKeyBoardDefault() {
		return urduVirtualKeyBoardDefault;
	}


	public void setUrduVirtualKeyBoardDefault(
			Map<String, RegionalKeyBoardModel> urduVirtualKeyBoardDefault) {
		this.urduVirtualKeyBoardDefault = urduVirtualKeyBoardDefault;
	}


	public Map<String, String> getOriyaImageValues() {
		return oriyaImageValues;
	}


	public void setOriyaImageValues(Map<String, String> oriyaImageValues) {
		this.oriyaImageValues = oriyaImageValues;
	}


	public Map<String, String> getUrduImageValues() {
		return urduImageValues;
	}


	public void setUrduImageValues(Map<String, String> urduImageValues) {
		this.urduImageValues = urduImageValues;
	}
	
}
