/*
 * CorporateFile.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 SG33414 - Initial Creation
package com.sbi.common.model;

import java.sql.Date;
import java.sql.Timestamp;

public class CorporateFile  implements BaseModel{
    private String fileName;

    private String sno;

    private String uploaderName;

    private Timestamp uploadedDate;
    
    private String fileType;
    
    private String bankType;
    
    private String functionType;
    
	private String fileStat;
	
	private String tpStatus;
 
 	private String benFileViewStatus;
 	
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
   


    public String getUploaderName() {
        return uploaderName;
    }

    public void setUploaderName(String uploaderName) {
        this.uploaderName = uploaderName;
    }

    public String getSno() {
        return sno;
    }

    public void setSno(String sno) {
        this.sno = sno;
    }

    public Timestamp getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(Timestamp uploadedDate) {
        this.uploadedDate = uploadedDate;
    }
    
    
    private String fileStatus;
   /* private String bankType;
    public String getBankType()
    {
        return bankType;
    }

    public void setBankType(String bankType)
    {
        this.bankType = bankType;
    }*/
    public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	
	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getFunctionType() {
		return functionType;
	}

	public void setFunctionType(String functionType) {
		this.functionType = functionType;
	}

	public String getFileStat() {
		return fileStat;
	}

	public void setFileStat(String fileStat) {
		this.fileStat = fileStat;
	}

	public String getTpStatus() {
		return tpStatus;
	}

	public void setTpStatus(String tpStatus) {
		this.tpStatus = tpStatus;
	}

	public String getBenFileViewStatus() {
		return benFileViewStatus;
	}

	public void setBenFileViewStatus(String benFileViewStatus) {
		this.benFileViewStatus = benFileViewStatus;
	}

	public String toString() {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(fileName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(sno);
        tempStringBuf.append(" | ");
        tempStringBuf.append(uploaderName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(uploadedDate);
        tempStringBuf.append(" | ");
        tempStringBuf.append(fileType);
        tempStringBuf.append(" | ");
      return tempStringBuf.toString();
    }

	
  
}
