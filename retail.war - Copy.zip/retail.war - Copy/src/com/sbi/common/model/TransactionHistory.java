/*
 * TransactionHistory.java
 * Created on Oct 17, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 17, 2005 MURUGAN - Initial Creation


package com.sbi.common.model;

import java.sql.Timestamp;

public class TransactionHistory implements BaseModel
{
    private Timestamp valueDate;
    
    private String tTypeCode;
    
    private Timestamp transactionDate;
    
    private Integer transactionCount;
    
    private String referenceNo;
    
    private String narrative3;
    
    private String narrative2;
    
    private String narrative1;
    
    private Timestamp creationTime;
    
    private String branchCode;
    
    private Double amount;
    
    private String accountNo;
    
    private Double balance;
    
    /* fiedl added for CoreAccountStatement - Copr User */
    private String startdate;
    
    private String enddate;
    
    private String description;
    
    //Added for CR 2765
    
    private String branchCodeFromCore;
    
    private String posttime;
    

	public String getBranchCodeFromCore()
    {
        return branchCodeFromCore;
    }

    public void setBranchCodeFromCore(String branchCodeFromCore)
    {
        this.branchCodeFromCore = branchCodeFromCore;
    }

    public void setValueDate( Timestamp valueDate )
    {
        this.valueDate=valueDate;
    }
    
    public Timestamp getValueDate( )
    {
        return valueDate;
    }
    
    public void setTTypeCode( String tTypeCode )
    {
        this.tTypeCode=tTypeCode;
    }
    
    public String getTTypeCode( )
    {
        return tTypeCode;
    }
    
    public void setTransactionDate( Timestamp transactionDate )
    {
        this.transactionDate=transactionDate;
    }
    
    public Timestamp getTransactionDate( )
    {
        return transactionDate;
    }
    
    public void setTransactionCount( Integer transactionCount )
    {
        this.transactionCount=transactionCount;
    }
    
    public Integer getTransactionCount( )
    {
        return transactionCount;
    }
    
    public void setReferenceNo( String referenceNo )
    {
        this.referenceNo=referenceNo;
    }
    
    public String getReferenceNo( )
    {
        return referenceNo;
    }
    
    public void setNarrative3( String narrative3 )
    {
        this.narrative3=narrative3;
    }
    
    public String getNarrative3( )
    {
        return narrative3;
    }
    
    public void setNarrative2( String narrative2 )
    {
        this.narrative2=narrative2;
    }
    
    public String getNarrative2( )
    {
        return narrative2;
    }
    
    public void setNarrative1( String narrative1 )
    {
        this.narrative1=narrative1;
    }
    
    public String getNarrative1( )
    {
        return narrative1;
    }
    
    public void setCreationTime( Timestamp creationTime )
    {
        this.creationTime=creationTime;
    }
    
    public Timestamp getCreationTime( )
    {
        return creationTime;
    }
    
    public void setBranchCode( String branchCode )
    {
        this.branchCode=branchCode;
    }
    
    public String getBranchCode( )
    {
        return branchCode;
    }
    
    public void setAccountNo( String accountNo )
    {
        this.accountNo=accountNo;
    }
    
    public String getAccountNo( )
    {
        return accountNo;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	} 

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getPosttime() {
		return posttime;
	}

	public void setPosttime(String posttime) {
		this.posttime = posttime;
	}
   
}
