/**
 * @(#) CustomerAccountMap.java
 */

package com.sbi.common.model;

import java.sql.Timestamp;

public class CustomerAccountMap extends User
{
        private String userName;
        
        private String accountNo;
        
        private String branchCode;
        
        private String oldUserName;
        
        private String accountNickName;
        
        private float transactionLimit;
        
        private String thirdPartyName;
        
        private String accountNature;
        
        private int accessLevel;
        
        private int verifyFlag;
        
        private int lockFlag;
        
        private String corporateId;
        
        private String branchName;
        
        private String accountDescription;
        
        private int processFlag;
        
        private Timestamp verifyRequestDate;
        
        private String productCode;
        
        private String productType;
        
        private String productDescription;
        
        private int coreMessageStatus;
        
        private String bankSystem;
        
        public void setUserName( String userName )
        {
                this.userName=userName;
        }
        
        public String getUserName( )
        {
                return userName;
        }
        
        public void setAccountNo( String accountNo )
        {
                this.accountNo=accountNo;
        }
        
        public String getAccountNo( )
        {
                return accountNo;
        }
        
        public void setBranchCode( String branchCode )
        {
                this.branchCode=branchCode;
        }
        
        public String getBranchCode( )
        {
                return branchCode;
        }
        
        public void setOldUserName( String oldUserName )
        {
                this.oldUserName=oldUserName;
        }
        
        public String getOldUserName( )
        {
                return oldUserName;
        }
        
        public void setAccountNickName( String accountNickName )
        {
                this.accountNickName=accountNickName;
        }
        
        public String getAccountNickName( )
        {
                return accountNickName;
        }
        
        public void setTransactionLimit( float transactionLimit )
        {
                this.transactionLimit=transactionLimit;
        }
        
        public float getTransactionLimit( )
        {
                return transactionLimit;
        }
        
        public void setThirdPartyName( String thirdPartyName )
        {
                this.thirdPartyName=thirdPartyName;
        }
        
        public String getThirdPartyName( )
        {
                return thirdPartyName;
        }
        
        public void setAccountNature( String accountNature )
        {
                this.accountNature=accountNature;
        }
        
        public String getAccountNature( )
        {
                return accountNature;
        }
        
        public void setAccessLevel( int accessLevel )
        {
                this.accessLevel=accessLevel;
        }
        
        public int getAccessLevel( )
        {
                return accessLevel;
        }
        
        public void setVerifyFlag( int verifyFlag )
        {
                this.verifyFlag=verifyFlag;
        }
        
        public int getVerifyFlag( )
        {
                return verifyFlag;
        }
        
        public void setLockFlag( int lockFlag )
        {
                this.lockFlag=lockFlag;
        }
        
        public int getLockFlag( )
        {
                return lockFlag;
        }
        
        public void setCorporateId( String corporateId )
        {
                this.corporateId=corporateId;
        }
        
        public String getCorporateId( )
        {
                return corporateId;
        }
        
        public void setBranchName( String branchName )
        {
                this.branchName=branchName;
        }
        
        public String getBranchName( )
        {
                return branchName;
        }
        
        public void setAccountDescription( String accountDescription )
        {
                this.accountDescription=accountDescription;
        }
        
        public String getAccountDescription( )
        {
                return accountDescription;
        }
        
        public void setProcessFlag( int processFlag )
        {
                this.processFlag=processFlag;
        }
        
        public int getProcessFlag( )
        {
                return processFlag;
        }
        
        public void setVerifyRequestDate( Timestamp verifyRequestDate )
        {
                this.verifyRequestDate=verifyRequestDate;
        }
        
        public Timestamp getVerifyRequestDate( )
        {
                return verifyRequestDate;
        }
        
        public void setProductCode( String productCode )
        {
                this.productCode=productCode;
        }
        
        public String getProductCode( )
        {
                return productCode;
        }
        
        public void setProductType( String productType )
        {
                this.productType=productType;
        }
        
        public String getProductType( )
        {
                return productType;
        }
        
        public void setProductDescription( String productDescription )
        {
                this.productDescription=productDescription;
        }
        
        public String getProductDescription( )
        {
                return productDescription;
        }
        
        public void setCoreMessageStatus( int coreMessageStatus )
        {
                this.coreMessageStatus=coreMessageStatus;
        }
        
        public int getCoreMessageStatus( )
        {
                return coreMessageStatus;
        }
        
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(userName);
        	tempStringBuf.append("|");
        	tempStringBuf.append(accountNo);
        	tempStringBuf.append("|");
        	tempStringBuf.append(branchCode);
        	tempStringBuf.append("|");
        	tempStringBuf.append(oldUserName);
        	tempStringBuf.append("|");
          	tempStringBuf.append(accountNickName);
        	tempStringBuf.append("|");
        	tempStringBuf.append(transactionLimit);
        	tempStringBuf.append("|");
        	tempStringBuf.append(thirdPartyName);
        	tempStringBuf.append("|");
        	tempStringBuf.append(accountNature);
        	tempStringBuf.append("|");
           	tempStringBuf.append(accessLevel);
        	tempStringBuf.append("|");
        	tempStringBuf.append(verifyFlag);
        	tempStringBuf.append("|");
        	tempStringBuf.append(lockFlag);
        	tempStringBuf.append("|");
        	tempStringBuf.append(corporateId);
        	tempStringBuf.append("|");
           	tempStringBuf.append(branchName);
        	tempStringBuf.append("|");
        	tempStringBuf.append(accountDescription);
        	tempStringBuf.append("|");
        	tempStringBuf.append(processFlag);
        	tempStringBuf.append("|");
        	tempStringBuf.append(verifyRequestDate);
        	tempStringBuf.append("|");
           	tempStringBuf.append(productCode);
        	tempStringBuf.append("|");
        	tempStringBuf.append(productType);
        	tempStringBuf.append("|");
        	tempStringBuf.append(productDescription);
        	tempStringBuf.append("|");
        	tempStringBuf.append(coreMessageStatus);
        	tempStringBuf.append("|");
        	
            
        	return tempStringBuf.toString();
        	        	
        }

		public String getBankSystem() {
			return bankSystem;
		}

		public void setBankSystem(String bankSystem) {
			this.bankSystem = bankSystem;
		}
       
}
