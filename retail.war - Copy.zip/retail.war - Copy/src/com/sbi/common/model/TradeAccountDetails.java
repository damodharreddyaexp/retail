package com.sbi.common.model;

import java.sql.Timestamp;

public class TradeAccountDetails extends AccountDetails{
	
	private Double drawingPower;
    
    private Double amountOutStanding;
    
    private Double sanctionedAmount;
    
    private Double sanctionedLimit; // Added for CR 5088

    private Timestamp lastUpdatedDate;
    
    private String currency;
    
    private Double interestRate; //Added for CR 5088
    
    private Double holdValue;
    
    private String ifsCode;
    
    public String getIfsCode() {
		return ifsCode;
	}

	public void setIfsCode(String ifsCode) {
		this.ifsCode = ifsCode;
	}
	
	public Double getHoldValue() {
		return holdValue;
	}
	
	public void setHoldValue(Double holdValue) {
		this.holdValue = holdValue;
	}
    
    public Double getSanctionedLimit() {
		return sanctionedLimit;
	}

	public void setSanctionedLimit(Double sanctionedLimit) {
		this.sanctionedLimit = sanctionedLimit;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	

	public Double getAmountOutStanding() {
		return amountOutStanding;
	}

	public void setAmountOutStanding(Double amountOutStanding) {
		this.amountOutStanding = amountOutStanding;
	}

	public Double getDrawingPower() {
		return drawingPower;
	}

	public void setDrawingPower(Double drawingPower) {
		this.drawingPower = drawingPower;
	}

	public Double getSanctionedAmount() {
		return sanctionedAmount;
	}

	public void setSanctionedAmount(Double sanctionedAmount) {
		this.sanctionedAmount = sanctionedAmount;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
    
    

}
