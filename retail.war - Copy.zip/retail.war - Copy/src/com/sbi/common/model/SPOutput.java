
/*
 * SPOutput.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 KRISHNA KUMAR - Initial Creation

package com.sbi.common.model;

public class SPOutput implements BaseModel
{

    private String errorCode;
    
    private String errorMessage;

    /**
     * @return Returns the errorCode.
     */
    public String getErrorCode()
    {
        return errorCode;
    }

    /**
     * @param errorCode The errorCode to set.
     */
    public void setErrorCode(String errorCode)
    {
        this.errorCode = errorCode;
    }

    /**
     * @return Returns the errorMessage.
     */
    public String getErrorMessage()
    {
        return errorMessage;
    }

    /**
     * @param errorMessage The errorMessage to set.
     */
    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }
    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(errorCode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(errorMessage);
        tempStringBuf.append(" | ");        
      
        return tempStringBuf.toString();
    }
    
    
}
