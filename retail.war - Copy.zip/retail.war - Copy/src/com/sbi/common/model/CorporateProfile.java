/*
 *
 * CorportaeProfile.java 
 * Created on Dec 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 21, 2005 SARAVANAN N - Initial Creation
package com.sbi.common.model;

public class CorporateProfile implements BaseModel{
    private String corporateID;

    private String corporateName; 

    private Double corporateDDLimit;

    private Double corporateTPLimit;

    private Integer auditUser;

    private String nextEchequeNo;

    private Integer unauditedCount;

    private Double maxUnauditedAmount;

    private String createdByBranch;

    private Integer makerAuthPreference;

    private Integer smallFlag;

    private Integer userAddThirdParty;

    private Integer ignoreTransaction;

    private Integer adminAddThirdParty;

    private Integer transactionMode;

    private Integer approverLevel;

    private String sbiMaxDDLimit;

    private String sbiMaxTPLimit;

    private String maxLimitValue;
    
    private Integer bulkAuthNeeded;

    private String ddebitRequired;
    
    private String ddebitEchequeApprovel;
    
    private String ddebitDealerVerification;
    
	private String fileAuth;	//	Added for CR 2108
	
	//Added for RTGS/NEFT
	
	private String address1;
	
	private String address2;
	
	private String city;
	
	private String pincode;
	
	private String state;
	
	private String zip;
	
	private String corporateType;//added for nab

   
   private String approverLevel3p;// Added for CR2435

	private String validateCreditAccount;//Added for 2302
	
	private String commissionType;// Added for CR 2921

	private Double corporateGovtLimit; //added for CR5269

   private String reconFlag; //Added For CR 5588

   /* Added by Sairam Mobile Registration Phase2 - Start */
   private String ehsEnable;
     
   private String ehsType;
   
   private String mcaEnable;

	
   private String crnValidationStatus; //added by archana for CRN 
   
   private String beneficiaryFlag;  //added for Beneficiary form based revamp
   
  /* Added by Sairam Mobile Registration Phase2 - End */
	public Integer getApproverLevel() {
        return approverLevel;
    }

    public void setApproverLevel(Integer approverLevel) {
        this.approverLevel = approverLevel;
    }

    public Double getCorporateDDLimit() {
        return corporateDDLimit;
    }

    public void setCorporateDDLimit(Double corporateDDLimit) {
        this.corporateDDLimit = corporateDDLimit;
    }

    public String getCorporateID() {
        return corporateID;
    }

    public void setCorporateID(String corporateID) {
        this.corporateID = corporateID;
    }

    public String getCorporateName() {
        return corporateName;
    }

    public void setCorporateName(String corporateName) {
        this.corporateName = corporateName;
    }

    public Double getCorporateTPLimit() {
        return corporateTPLimit;
    }

    public void setCorporateTPLimit(Double corporateTPLimit) {
        this.corporateTPLimit = corporateTPLimit;
    }

    public String getCreatedByBranch() {
        return createdByBranch;
    }

    public void setCreatedByBranch(String createdByBranch) {
        this.createdByBranch = createdByBranch;
    }

    public Integer getIgnoreTransaction() {
        return ignoreTransaction;
    }

    public void setIgnoreTransaction(Integer ignoreTransaction) {
        this.ignoreTransaction = ignoreTransaction;
    }

    public Double getMaxUnauditedAmount() {
        return maxUnauditedAmount;
    }

    public void setMaxUnauditedAmount(Double maxUnauditedAmount) {
        this.maxUnauditedAmount = maxUnauditedAmount;
    }

    public String getNextEchequeNo() {
        return nextEchequeNo;
    }

    public void setNextEchequeNo(String nextEchequeNo) {
        this.nextEchequeNo = nextEchequeNo;
    }

    public Integer getSmallFlag() {
        return smallFlag;
    }

    public void setSmallFlag(Integer smallFlag) {
        this.smallFlag = smallFlag;
    }

    public Integer getTransactionMode() {
        return transactionMode;
    }

    public void setTransactionMode(Integer transactionMode) {
        this.transactionMode = transactionMode;
    }

    

    public Integer getAuditUser() {
        return auditUser;
    }

    public void setAuditUser(Integer auditUser) {
        this.auditUser = auditUser;
    }

    public Integer getAdminAddThirdParty() {
        return adminAddThirdParty;
    }

    public void setAdminAddThirdParty(Integer adminAddThirdParty) {
        this.adminAddThirdParty = adminAddThirdParty;
    }

    public Integer getMakerAuthPreference() {
        return makerAuthPreference;
    }

    public void setMakerAuthPreference(Integer makerAuthPreference) {
        this.makerAuthPreference = makerAuthPreference;
    }

    public Integer getUserAddThirdParty() {
        return userAddThirdParty;
    }

    public void setUserAddThirdParty(Integer userAddThirdParty) {
        this.userAddThirdParty = userAddThirdParty;
    }

    public String getSbiMaxDDLimit() {
        return sbiMaxDDLimit;
    }

    public void setSbiMaxDDLimit(String sbiMaxDDLimit) {
        this.sbiMaxDDLimit = sbiMaxDDLimit;
    }

    public String getSbiMaxTPLimit() {
        return sbiMaxTPLimit;
    }

    public void setSbiMaxTPLimit(String sbiMaxTPLimit) {
        this.sbiMaxTPLimit = sbiMaxTPLimit;
    }

	 public String getCorporateType() {
		return corporateType;
	}

	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

    public String toString() {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append(corporateID);
        tempStringBuf.append(" | ");
        tempStringBuf.append(corporateName);
        tempStringBuf.append(" | ");
        tempStringBuf.append(corporateDDLimit);
        tempStringBuf.append(" | ");
        tempStringBuf.append(corporateTPLimit);
        tempStringBuf.append(" | ");
        tempStringBuf.append(auditUser);
        tempStringBuf.append(" | ");
        tempStringBuf.append(nextEchequeNo);
        tempStringBuf.append(" | ");
        tempStringBuf.append(unauditedCount);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maxUnauditedAmount);
        tempStringBuf.append(" | ");
        tempStringBuf.append(createdByBranch);
        tempStringBuf.append(" | ");
        tempStringBuf.append(makerAuthPreference);
        tempStringBuf.append(" | ");
        tempStringBuf.append(smallFlag);
        tempStringBuf.append(" | ");
        tempStringBuf.append(userAddThirdParty);
        tempStringBuf.append(" | ");
        tempStringBuf.append(ignoreTransaction);
        tempStringBuf.append(" | ");
        tempStringBuf.append(adminAddThirdParty);
        tempStringBuf.append(" | ");
        tempStringBuf.append(transactionMode);
        tempStringBuf.append(" | ");
        tempStringBuf.append(approverLevel);
        tempStringBuf.append(" | ");
        tempStringBuf.append(sbiMaxDDLimit);
        tempStringBuf.append(" | ");
        tempStringBuf.append(sbiMaxTPLimit);
        tempStringBuf.append(" | ");
        tempStringBuf.append(maxLimitValue);
        tempStringBuf.append(" | ");
        tempStringBuf.append(bulkAuthNeeded);
        tempStringBuf.append(" | ");
        tempStringBuf.append(ddebitRequired);
        tempStringBuf.append(" | ");
        tempStringBuf.append(ddebitEchequeApprovel);
        tempStringBuf.append(" | ");
        tempStringBuf.append(ddebitDealerVerification);
		//	Added for CR 2108
		tempStringBuf.append(" || ");
        tempStringBuf.append(fileAuth);
		//	End of CR 2108
        // CR 2435
	tempStringBuf.append(" || ");
        tempStringBuf.append(approverLevel3p);
		//Added for CR 2302
        tempStringBuf.append(" || ");
        tempStringBuf.append(validateCreditAccount);
        //End of CR 2302
        //Added for CR 2921
        tempStringBuf.append(" | ");
        tempStringBuf.append(commissionType);
  		tempStringBuf.append(" || ");
        tempStringBuf.append(corporateGovtLimit); 

	tempStringBuf.append(" || ");

        tempStringBuf.append(crnValidationStatus); 
       
        return tempStringBuf.toString();
    }

    public String getMaxLimitValue() {
        return maxLimitValue;
    }

    public void setMaxLimitValue(String maxLimitValue) {
        this.maxLimitValue = maxLimitValue;
    }

    /**
     * @return Returns the unauditedCount.
     */
    public Integer getUnauditedCount()
    {
        return unauditedCount;
    }

    /**
     * @param unauditedCount The unauditedCount to set.
     */
    public void setUnauditedCount(Integer unauditedCount)
    {
        this.unauditedCount = unauditedCount;
    }

	public Integer getBulkAuthNeeded() {
		return bulkAuthNeeded;
	}

	public void setBulkAuthNeeded(Integer bulkAuthNeeded) {
		this.bulkAuthNeeded = bulkAuthNeeded;
	}

	public String getDdebitDealerVerification() {
		return ddebitDealerVerification;
	}

	public void setDdebitDealerVerification(String ddebitDealerVerification) {
		this.ddebitDealerVerification = ddebitDealerVerification;
	}

	public String getDdebitEchequeApprovel() {
		return ddebitEchequeApprovel;
	}

	public void setDdebitEchequeApprovel(String ddebitEchequeApprovel) {
		this.ddebitEchequeApprovel = ddebitEchequeApprovel;
	}

	public String getDdebitRequired() {
		return ddebitRequired;
	}

	public void setDdebitRequired(String ddebitRequired) {
		this.ddebitRequired = ddebitRequired;
	}
	//	Added for CR 2108
	public String getFileAuth() {
		return fileAuth;
	}

	public void setFileAuth(String fileAuth) {
		this.fileAuth = fileAuth;
	}
	//	End of CR 2108

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getApproverLevel3p() {
		return approverLevel3p;
	}

	public void setApproverLevel3p(String approverLevel3p) {
		this.approverLevel3p = approverLevel3p;
	}
	//Added for CR 2302
    public void setValidateCreditAccount(String validateCreditAccount)
    {
        this.validateCreditAccount = validateCreditAccount;
    }

    public String getValidateCreditAccount()
    {
        return validateCreditAccount;
    }
    
    //End of CR 2302
	//Added for CR 2921

	public String getCommissionType() {
		return commissionType;
	}

	public void setCommissionType(String commissionType) {
		this.commissionType = commissionType;
	}
        

    public Double getCorporateGovtLimit() {
		return corporateGovtLimit;
	}

	public void setCorporateGovtLimit(Double corporateGovtLimit) {
		this.corporateGovtLimit = corporateGovtLimit;
	}
	public String getReconFlag() {
		return reconFlag;
	}
	public void setReconFlag(String reconFlag) {
		this.reconFlag = reconFlag;
	}
	
	 public String getEhsEnable() {
			return ehsEnable;
		}

		public void setEhsEnable(String ehsEnable) {
			this.ehsEnable = ehsEnable;
		}

		public String getEhsType() {
			return ehsType;
		}

		public void setEhsType(String ehsType) {
			this.ehsType = ehsType;
		}

		public String getMcaEnable() {
			return mcaEnable;
		}

		public void setMcaEnable(String mcaEnable) {
			this.mcaEnable = mcaEnable;
		}

		//added by archana for CRN 
		public String getcrnValidationStatus() {
		    return crnValidationStatus;
		}

		public void setcrnValidationStatus(String crnValidationStatus) {
		    this.crnValidationStatus = crnValidationStatus;
		}
		//added for Beneficiary form based revamp 
		public String getBeneficiaryFlag() {
	        return beneficiaryFlag;
	    }

	    public void setBeneficiaryFlag(String beneficiaryFlag) {
	        this.beneficiaryFlag = beneficiaryFlag;
	    }
}
