package com.sbi.common.model;

public class Control  implements BaseModel{
	private String label;
	private String format;
	private Integer fieldSize;
	private Integer mandatory;
	private String requestVariable;
	private String displayOrder;
	private String errorMessage;
	private String value;
	private String controlType;
	
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Integer getMandatory() {
		return mandatory;
	}
	public void setMandatory(Integer mandatory) {
		this.mandatory = mandatory;
	}
	public String getRequestVariable() {
		return requestVariable;
	}
	public void setRequestVariable(String requestVariable) {
		this.requestVariable = requestVariable;
	}
	public Integer getFieldSize() {
		return fieldSize;
	}
	public void setFieldSize(Integer fieldSize) {
		this.fieldSize = fieldSize;
	}
	public String getControlType() {
		return controlType;
	}
	public void setControlType(String controlType) {
		this.controlType = controlType;
	}
    
    public String toString()
    {
        StringBuffer tempStringBuf = new StringBuffer();
        tempStringBuf.append("label=");
        tempStringBuf.append(label);
        tempStringBuf.append(" | ");
        tempStringBuf.append("format=");
        tempStringBuf.append(format);
        tempStringBuf.append(" | ");
        tempStringBuf.append("fieldSize=");
        tempStringBuf.append(fieldSize);
        tempStringBuf.append(" | ");
        tempStringBuf.append("mandatory =");
        tempStringBuf.append(mandatory);
        tempStringBuf.append(" | ");
        tempStringBuf.append("requestVariable =");
        tempStringBuf.append(requestVariable);
        tempStringBuf.append(" | ");
        tempStringBuf.append("displayOrder =");
        tempStringBuf.append(displayOrder);
        tempStringBuf.append(" | ");
        tempStringBuf.append("errorMessage =");
        tempStringBuf.append(errorMessage);
        tempStringBuf.append(" | ");
        tempStringBuf.append("value =");
        tempStringBuf.append(value);
        tempStringBuf.append(" | ");
        tempStringBuf.append("controlType =");
        tempStringBuf.append(controlType);
        tempStringBuf.append(" | ");
        
        return tempStringBuf.toString();
    }
}
