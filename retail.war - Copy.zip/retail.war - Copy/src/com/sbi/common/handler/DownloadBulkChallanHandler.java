package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;

public class DownloadBulkChallanHandler extends MultiActionController {


	private BaseService downloadChallanByDateService;
	
	private Logger logger = Logger.getLogger(getClass());

	public ModelAndView displayBulkChallan(HttpServletRequest request,HttpServletResponse response)  {
	    logger.info("displayBulkChallan(HttpServletRequest request,HttpServletResponse response)-begins");
	    Map outputParams = new HashMap();
	    HttpSession session=request.getSession();
        outputParams.put("errorView","errordisplayBulkChallan");
	    logger.info("displayBulkChallan(HttpServletRequest request,HttpServletResponse response)-ends");
	    return new ModelAndView("displayBulkChallan","outputParams",outputParams);
	}

	public ModelAndView displayChallanDetailsHandler(HttpServletRequest request, HttpServletResponse response) {
		logger.info("displayChallanDetailsHandler(HttpServletRequest request, HttpServletResponse response)-begin");
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String fromDate = request.getParameter("fromDate");
		logger.info("fromDate.."+fromDate + " corporateId="+corporateId);
		String url = request.getServletPath().substring(1);
		inputParams.put("corporateId", corporateId);
		inputParams.put("start_date", fromDate);
		logger.info("Input to service="+inputParams);
		outputParams = downloadChallanByDateService.execute(inputParams);
		outputParams.put("corporateId", corporateId);
		logger.info("Object returned from service="+outputParams);
		outputParams.put(UIConstant.ERROR_VIEW, "commonerror");
		logger.info("displayChallanDetailsHandler(HttpServletRequest request, HttpServletResponse response)-end");
		return new ModelAndView("diplayChallanDetails","outputParams", outputParams);
	}
	

	public void setDownloadChallanByDateService(
			BaseService downloadChallanByDateService) {
		this.downloadChallanByDateService = downloadChallanByDateService;
	}
	
    


}

