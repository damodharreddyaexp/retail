
/*
 * RefreshErrorHandler.java
 * Created on Jan 19, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 19, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;
 
import com.sbi.common.exception.SBIApplicationResponse;

public class RefreshErrorHandler implements Controller
{   private ResourceBundleMessageSource refreshProperties;
    protected final Logger logger = Logger.getLogger(getClass());
    
    public static final String ERROR_REFRESH = "REF010";
    
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        logger.info("Inside the refresh error handler");
        Map outparam = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorCode(ERROR_REFRESH);
        applicationResponse.setErrorMessage("You cannot refresh this page.");
        applicationResponse.setErrorStatus(UIConstant.FAILURE);
        outparam.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
          
        String error_view = refreshProperties.getMessage((String) request.getAttribute(UIConstant.REFRESH_URL),null,null);
        logger.info("error_view"+error_view);
        outparam.put(UIConstant.ERROR_VIEW,error_view);
       /* String txnName = request.getParameter(UIConstant.TRANSACTION_NAME);
        if(txnName != null)
            request.setAttribute(UIConstant.TRANSACTION_NAME,txnName.trim()); 
        else
            request.setAttribute(UIConstant.TRANSACTION_NAME,"");
        logger.info("trans name"+request.getParameter(UIConstant.TRANSACTION_NAME));    */    
        return new ModelAndView("",UIConstant.REFRESH_MODEL,outparam); 
    }
    /**
     * @param refreshProperties The refreshProperties to set.
     */
    public void setRefreshProperties(ResourceBundleMessageSource refreshProperties)
    {
        this.refreshProperties = refreshProperties;
    }
   
    
}
