package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.User;
import com.sbi.common.service.RetrieveIssueService;

public class ComposeIssueHandler extends MultiActionController{
	
	private Logger logger = Logger.getLogger(getClass());
	
	RetrieveIssueService retrieveIssueService;
	
	
	public ModelAndView displayIssues(HttpServletRequest request,HttpServletResponse response){
		logger.info("displayIssues(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inparam=new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession();
		
		User user=(User)session.getAttribute(UIConstant.USER);
		inparam.put(UIConstant.USER_TYPE,user.getUserType());
		inparam.put(UIConstant.BANK_CODE,user.getBankCode());
		inparam.put(UIConstant.USER_ROLE,user.getRoles().get(0));
		
		
		outParam=retrieveIssueService.execute(inparam);
		
		
		
		logger.info("displayIssues(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.COMPOSE_ISSUE,UIConstant.OUTPARAM,outParam);
	}

	
	public void setRetrieveIssueService(RetrieveIssueService retrieveIssueService) {
		this.retrieveIssueService = retrieveIssueService;
	}

}
