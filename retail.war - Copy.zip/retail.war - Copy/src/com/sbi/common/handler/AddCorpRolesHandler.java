/*This Handler supports the additon of Corpuser(including Ddebituser),Approver,Uploader,SuperEnquirer
 * except Audituser
 */
package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.C9UserProfile;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;

public class AddCorpRolesHandler extends MultiActionController{
	private BaseService addCorpRolesConfirmService;
	private Map addRolesMap;
	private final Logger logger=Logger.getLogger(getClass());
	private BaseService getUserProfileService;
	
	public ModelAndView addCorpRolesDisplayHandler(HttpServletRequest request, HttpServletResponse response){
		logger.info("addCorpRolesDisplayHandler(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		
        SBIApplicationResponse appResponse = new SBIApplicationResponse();
        appResponse.setErrorStatus(UIConstant.SUCCESS);
        
        String roleType=(String)addRolesMap.get(request.getServletPath());
        outParams.put("roleType", roleType);
        String nextAction="add"+roleType.toLowerCase()+"interim.htm";
        outParams.put("action", nextAction);
        //added for CRN by archana
        HttpSession session = request.getSession(true);
        String requestedURL = request.getServletPath().trim();
        if (requestedURL!=null && requestedURL.equalsIgnoreCase("/addsuperuploader.htm")) {
        CorporateProfile corporateProfile = (CorporateProfile)   session.getAttribute("corp_profile");
        logger.info("CRN VAL STATUS"+corporateProfile.getcrnValidationStatus()+""+corporateProfile.getCorporateID());
        if(corporateProfile.getcrnValidationStatus()==null || corporateProfile.getcrnValidationStatus() == "" || !corporateProfile.getcrnValidationStatus().equalsIgnoreCase("yes"))
        {
        	 appResponse.setErrorStatus(UIConstant.FAILURE);
        	 appResponse.setErrorCode("CRN001");
        	 
        }
        else{
        	boolean crnValidFlag = true;
        }
        }
        //added for CRN by archana
      
        outParams.put(UIConstant.APPLICATION_RESPONSE, appResponse);
        	logger.info("Messages :"+outParams);
        logger.info("addCorpRolesDisplayHandler(HttpServletRequest request, HttpServletResponse response) ends");
		return new ModelAndView("addCorpRoles","outParams",outParams);
	}
	public ModelAndView addCorpRolesInterimConfirmHandler(HttpServletRequest request, HttpServletResponse response){
		logger.info("addCorpRolesInterimConfirmHandler(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		String nextAction="add"+request.getParameter("roleType").toLowerCase()+"confirm.htm";
		String returnAction="add"+request.getParameter("roleType").toLowerCase()+".htm";
        outParams.put("action", nextAction);
        outParams.put("returnAction", returnAction);
		SBIApplicationResponse appResponse = new SBIApplicationResponse();
        appResponse.setErrorStatus(UIConstant.SUCCESS);
        outParams.put(UIConstant.APPLICATION_RESPONSE, appResponse);
        logger.info("addCorpRolesInterimConfirmHandler(HttpServletRequest request, HttpServletResponse response) ends");
		return new ModelAndView("addCorpRolesInterim","outParams",outParams);
	}
	public ModelAndView addCorpRolesConfirmHandler(HttpServletRequest request, HttpServletResponse response){
		logger.info("addCorpRolesConfirmHandler(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inParams = new HashMap();
		HttpSession session = request.getSession(false);
		User user=(User) session.getAttribute(UIConstant.USER);
		session.removeAttribute("corpUserProfile");
		String createdBy=user.getUserAlias();
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");		
		String address1=request.getParameter(UIConstant.ADDRESS1);
		String address2=request.getParameter(UIConstant.ADDRESS2);
		String address=address1+" , "+address2;
		 //Added By Amar for Mobile Number Registeration
		String countryCode=null;
		countryCode=request.getParameter(UIConstant.COUNTRY_CODE);
		String mobNo=null;
		mobNo = request.getParameter(UIConstant.MOBILE_NO);
		boolean flag;
		String mobileNumber="";
		
		
		if(mobNo !=null ||!mobNo.equalsIgnoreCase(" ")){
		flag = mobNo.contains("|");
		if(flag){
			mobileNumber=mobNo;
		}else{
			if(countryCode != null){
				mobileNumber=countryCode+"|"+mobNo;
			}else{
				mobileNumber=mobNo;
		}
		
		}
		}
		
		inParams.put(UIConstant.NAME,request.getParameter("name"));		
		inParams.put(UIConstant.ADDRESS,address);
		inParams.put(UIConstant.ADDRESS1,request.getParameter("address1"));
		inParams.put(UIConstant.ADDRESS2,request.getParameter("address2"));
		inParams.put(UIConstant.CITY,request.getParameter("city"));
		inParams.put(UIConstant.DISTRICT,request.getParameter("district"));
		inParams.put(UIConstant.STATE,request.getParameter("state"));
		inParams.put(UIConstant.COUNTRY,request.getParameter("country"));
		inParams.put(UIConstant.ZIP,request.getParameter("zip"));
		inParams.put(UIConstant.EMAIL,request.getParameter("email"));
		inParams.put(UIConstant.HOME_PHONE,request.getParameter("phone"));
		inParams.put(UIConstant.CREATED_BY,request.getParameter("created_by"));
		inParams.put("ppkits",request.getParameter("ppkits")); 
		inParams.put(UIConstant.DESIGNATION,request.getParameter(UIConstant.DESIGNATION)); 
        inParams.put(UIConstant.DEPARTMENT,request.getParameter(UIConstant.DEPARTMENT));
        
        //Added By Amar for Mobile Number Registeration
        inParams.put(UIConstant.MOBILE_NO,mobileNumber);
        
        
        inParams.put("source",getSource(request));
        inParams.put("roleType",request.getParameter("roleType"));
		inParams.put("empno",request.getParameter("empno"));
		inParams.put(UIConstant.CREATED_BY,createdBy);
		inParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
		inParams.put("branchCode",user.getBranchCode());
        inParams.put("bankCode",user.getBankCode());
        //Only For CorpUSer Starts
        inParams.put("smallFlag", corporateProfile.getSmallFlag());
        inParams.put("corporateType", corporateProfile.getCorporateType());
        inParams.put("oldempno", request.getParameter("old_empno"));
        inParams.put("userName",request.getParameter("userName"));
        String[] userType = request.getParameterValues("userType");
        inParams.put("userType",userType);
        inParams.put("accRights",request.getParameter("accRights"));
        //Only For CorpUSer Ends
        inParams.put("smsSecurity",request.getParameter("smsSecurity"));//Added for Mobile Regis Phase2
        logger.info("SMS_Security"+request.getParameter("smsSecurity"));
        logger.info("Name======="+UIConstant.NAME);
        logger.info("Message :"+inParams);
      //Only For CorpUSer Ends
		Map outParams=addCorpRolesConfirmService.execute(inParams);
		
		UserProfile userProfile1 = new UserProfile();//userDetails
		C9UserProfile c9Profile=new C9UserProfile();
		
		userProfile1 = (UserProfile) outParams.get("c9userProfile");
		logger.info("User profile in handler"+userProfile1);
		if(userProfile1!=null){
		c9Profile.setEmpNo(userProfile1.getEmpNo());
		c9Profile.setMobileRegNo(userProfile1.getMobileRegNo());
		c9Profile.setName(userProfile1.getName());
		c9Profile.setMobileNumber(userProfile1.getMobileNumber());
		}
		
		
		UserProfile userProfile = new UserProfile();//userDetails
        userProfile = (UserProfile) outParams.get("userProfile");
        String view="addCorpRolesConfirm";
        String ppkits=request.getParameter("ppkits");
        if(ppkits != null && ppkits.equalsIgnoreCase("Yes") && userProfile!=null)
        {
        	view="addCorpRolesPrePrintKit";
        	String pp_id=(String) outParams.get("pp_id");
            session.setAttribute("pp_id",pp_id);
            session.setAttribute("corpUserProfile",userProfile);
            session.setAttribute("C9UserProfile",c9Profile);
            outParams.put("addedRole", request.getParameter("roleType")); //added for CRN
        }
        else{
        	if(userType != null && userType.length == 1 && userType[0].equalsIgnoreCase("ddebituser"))
        		outParams.put("addedRole", "Direct Debit User");
        	else
            	outParams.put("addedRole", request.getParameter("roleType"));
        	session.setAttribute("C9UserProfile",c9Profile);
        	outParams.put("userDetails",outParams.get(UIConstant.USER_DETAILS));
        }
		logger.info("addCorpRolesConfirmHandler(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODEND);
		  
		   
		return new ModelAndView(view,UIConstant.USER_DETAILS,outParams);
	}
	
	public ModelAndView showPrePrintKitForm(HttpServletRequest request, HttpServletResponse response) {
        logger.info("showPrePrintKitForm(HttpServletRequest request, HttpServletResponse response) begins");
        Map outParams = new HashMap();
        HttpSession session = request.getSession(false);
        String requestedURL = request.getServletPath().trim();    
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        UserProfile userProfile = (UserProfile) session.getAttribute("corpUserProfile");
        C9UserProfile c9Profile =(C9UserProfile)session.getAttribute("C9UserProfile");
        logger.info("userProfile"+userProfile);
        logger.info("c9Profile"+c9Profile);
        String view="";
        String corpID = corporateProfile.getCorporateID();
        String name = corporateProfile.getCorporateName();
        char nameArray[] = name.toCharArray();
        char corpIDArray[] = corpID.toCharArray();
        outParams.put("nameArray",nameArray);
        outParams.put("corpIDArray",corpIDArray);
        outParams.put("corpName",name);
        outParams.put("corpID",corpID);
        outParams.put("userRole",request.getParameter("roleType"));  
        String mobileNo="";
        if (userProfile!= null){
        	mobileNo=userProfile.getMobileNumber();        	
        }
        else if(c9Profile!= null){
        	mobileNo=c9Profile.getMobileNumber();         	
        }
        	
        outParams.put("mobileNo",mobileNo);        
        outParams.put(request.getParameter("roleType").toLowerCase(),"checked");        
        logger.info("roleType >>>"+request.getParameter("roleType"));
        //Modified for Mobile Number Number Registeration - 06-03-2011
        if(requestedURL!=null && requestedURL.equalsIgnoreCase("/showppkitform.htm"))
        {
	        logger.info("Generating C7 Form");
	        view="addCorpRolesPPKit";
	                    
        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/showPPKitC9Form.htm")) 
        {
	        logger.info("Generating C9 Form");
	        view="addCorpRolesC9Form";
        }        	
        
        logger.info("showPrePrintKitForm(HttpServletRequest request, HttpServletResponse response) ends");
        return new ModelAndView(view,"model",outParams);
    }
	public static String getSource(HttpServletRequest request)
    {
         String contextpath=request.getContextPath().substring(1);
         String source=null;
         if(contextpath.equalsIgnoreCase("corpadmin")||contextpath.equalsIgnoreCase("corpadmincug"))
        	 source="Corp Admin";
         else if(contextpath.equalsIgnoreCase("corpreg")||contextpath.equalsIgnoreCase("corpregcug"))
        	 source="Corp Reg";
        return source;
    }
	
	
	//	Added for Transaction Password form -Start
	public ModelAndView showTransactionPwdForm(HttpServletRequest request, HttpServletResponse response) {
              logger.info("showTransactionPwdForm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		HttpSession session = request.getSession(false);
		String referenceNo =(String)request.getParameter("referenceNo");
		UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
		String corporateId = profile.getCorporateId();
		String corporateName = corporateProfile.getCorporateName();
		Map inParams = new HashMap();
		Map outParams = new HashMap();
		
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		String userAlias=(String)request.getParameter("userName");
		
		inParams.put(ServiceConstant.USER_NAME,userAlias);
		outParams=getUserProfileService.execute(inParams);
		
		outParams.put("referenceNo",referenceNo);
		outParams.put("corporateId",corporateId);
		outParams.put("corporateName",corporateName);
		outParams.put("role",request.getParameter("role"));
		logger.info("role >>>"+request.getParameter("role"));
		
		
		
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);
		applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);
		logger.info("showTransactionPwdForm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("showCINB7bForm", "outParams",outParams);
    }
	//	Added for Transaction Password form -End
	
	
	public void setAddCorpRolesConfirmService(BaseService addCorpRolesConfirmService) {
		this.addCorpRolesConfirmService = addCorpRolesConfirmService;
	}
	public void setAddRolesMap(Map addRolesMap) {
		this.addRolesMap = addRolesMap;
	}
	public void setGetUserProfileService(BaseService getUserProfileService) {
		this.getUserProfileService = getUserProfileService;
	}
		
	
}
