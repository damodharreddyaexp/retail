
/*
 * UIConstant.java
 * Created on Mar 6, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 6, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.handler;




public interface UIConstant
{ 
    public static final String KATHA_BV_PAGE ="kathaBVPage";
    
    public static final String MODEL ="model";
    
    public static final String ALL_BRANCH_DATA_KEY = "allBranchDataKey";

    public static final String ALL_BRANCH_NAME_CODE_MAP = "allBranchNameCodeMap";
    
    public static final String SESSION_ID = "sessionId";
    
    public final static String FAVORITES_NAME = "favoritesName";
    
    public static final String FAVORITE_NAMES = "favoriteNames";
    
    public static final String OUTPARAM = "outParam";
    
    
    
    public static final String LOGIN_PAGE = "loginLayout";
    
    public static final String SESSION_PAGE = "sessionLayout";
    
    public static final String constants = "constants";
    
    public static final String PRODUCT_DESCRIPTION = "productDescription";
    
    public static final String ACCOUNTNAME_KEY = "accountNameKey";
    
    public static final String COUNTRY_NAME = "countryName";
    
    public static final String COUNTRY_NAME_CODE = "countryNameCode";
    
    public static final String TRANSACTION_LIMIT_MAP = "transactionLimitMap";
    
    public static final String TRANSACTION_LIMIT = "TRANSACTION_LIMIT";
    
    public static final String BRANCH_NAME_CODE_MAP = "branchNameCodeMap";
    
    public static final String BRANCH_DATA_KEY = "branchDataKey";
    
    public static final String USER_NAME = "userName";
    
    public static final String PASSWORD = "password";
    
    public static final String IP_ADDRESS = "ip_address";
    
    public static final String APPLICATION_RESPONSE = "applicationResponse";
    
    public static final String USER = "user";
    
    public static final String DISPLAY_NAME = "displayName";
    
    public static final String LAST_TXN = "lastTransaction";
    
    public static final String LAST_LOGIN_DATE = "lastLoginDate";
    
    public static final String LAST_TXN_DATE = "lastTransactionDate";
    
    public static final String LOGIN_COUNT ="loginCount";
    
    public static final String SUCCESS = "success";

    public static final String FAILURE = "failure";
    
    public static final String LOGOUT_PAGE="logoutLayout";
    
    public static final String CHANGE_USER_NAME = "changeUserName";
    
    public static final String OLD_USER_NAME="oldUserName";
    
    public static final String CHANGE_PASSWORD = "changePassword";
    
    public static final String ERROR_MODEL = "errorModel";
    
    public static final String NEW_USER_NAME ="newUserName";
    
    public static final String USER_PROFILE = "_Profile";
    
    public static final String ACCOUNT_MODEL = "accountModel";
    
    // Added by Sairaj for CRN Uploader
    
    public static final String CRN_MODEL = "crnModel";
    
    public static final String ERROR_VIEW = "errorView";
    
    public static final String ERROR_CODE = "errorCode";
    
    public static final String ERROR_STATUS = "errorStatus";

    public static final String ERROR_MESSAGE = "errorMessage";
     
    public static final String SESSION_ERROR_MESSAGE = "Your session expired.Please re-login.";
    
    public static final String SESSION_ERROR = "sessionError";
    
    public static final String CORPORATE_PROFILE_DETAILS = "corporateProfileDetails";
    
    public static final String CORPORATE_ID = "coporateID";
    
 public static final String NAME = "name";
    
    public static final String CHANGE_LOG_PWD_VIEW = "changeLoginPassword";
    
    public static final String CHANGE_LOG_PWD_CONFIRM_VIEW = "loginChangePasswordConfirm";
    
    public static final String OLD_LOGIN_PASSWORD = "oldLoginPassword";
    
    public static final String NEW_PASSWORD = "newPassword";

    public static final String CONFIRM_PASSWORD = "confirmPassword";
    
    public static final String USER_DETAILS = "userDetails";
    
    public static final String VERIFY_STATUS = "viewName";
    
    public static final String ERROR_CHANGE_LOGIN_PWD = "errorloginChangePasswordConfirm";

    public static final String ACCOUNT_TYPE = "accountType";    
    
    public static final String ACCOUNT_TYPE1 = "A1";

    public static final String ACCOUNT_TYPE2 = "A2";

    public static final String ACCOUNT_TYPE3 = "A3";

    public static final String ACCOUNT_TYPE4 = "A4";

    public static final String ACCOUNT_TYPE5 = "A5";

    public static final String ACCOUNT_TYPE6 = "A6";
    //Added for CR 5088
    public static final String ACCOUNT_TYPE8 = "A8"; // Added for Trade Accounts

    public static final String ACCOUNT_TYPEB1 = "B1";
    
  	public static final String ACCOUNT_NO = "accountNo";

    public static final String BRANCH_CODE = "branchCode";    
    
    public static final String PRODUCT_TYPE = "productType";
    
    public static final String ACCESS_LEVEL = "AccessLevel";
    
    public static final String BANK_SYSTEM = "bankSystem";

    public static final String ALL = "all";

    public static final String SBBJ_LOGIN_PAGE ="sbbjLogin";
    
    public static final String SBH_LOGIN_PAGE="sbhLogin";
    
    public static final String SBINDORE_LOGIN_PAGE="sbindoreLogin";
    
    public static final String SBM_LOGIN_PAGE="sbmLogin";
    
    public static final String SBP_LOGIN_PAGE="sbpLogin";
    
    public static final String SBS_LOGIN_PAGE="sbsLogin";
    
    public static final String SBT_LOGIN_PAGE="sbtLogin";
    
    public static final String BANK_CODE = "bankCode";
    
    public static final String REFRESH_FLAG = "refreshFlag";

    public static final String REFRESH_URL = "refreshUrl";
    
    public static final String REFRESH_MODEL = "refreshModel";
    
    //Added by Sunjay S Galen
    
    public static final String TP_FILE_NAME = "tpFileName";
    
    public static final String APPROVE_IDS = "approveIds";
    
    public static final String UN_APPROVE_IDS = "unApproveIds";
    
  //Added For CR 5287 starts
    public static final String ACCOUNT_VIEW="dematservices";
    
    public static final String HOLDING_VIEW="holdingdetails";
    
    public static final String STAT_TRANS_VIEW = "statementoftransaction";
    
    public static final String BILLING_STAT_VIEW = "billingstatement";
    
    public static final String DEMAT_REQUST="dematRequest";
    
    public static final String DEMAT_ACCT_RESPONSE_VIEW="dematacctdetailsresponse";

    public static final String DEMAT_HOLD_RESPONSE_VIEW = "dematholdingdetailsresponse";

    public static final String DEMAT_STAT_TRANS_VIEW = "dematstatementtransactionsresponse";

    public static final String DEMAT_BILLING_STATEMENT_VIEW="dematbillingstatementsresponse";

    public static final String DEMAT_BILLING_STATEMENT_DETAILS_VIEW="dematbillingstatementdetailsresponse";

    public static final String END_DATE= "enddate";

    public static final String START_DATE="startdate";

    public static final String HOLD_STATEMENT = "holdingStatement";

    public static final String BANK_DETAILS = "bankDetails";
    
    public static final String DP_ID="dpId";
    //Added by thanga for GDF dop changes
    public static final String FLAG = "flag";
    public static final String ADD = "ADD";
    //Added by thanga for GDF dop changes
    //Added For CR 5287 ends
   //5472 starts
    public static final String CA_USER="caUser";
    public static final String USER_ROLE="userRole";
    public static final String SUPER_ENQR_ROLE = "13";
    public static final String UPLOADER_ROLE = "21";
    public static final String SUPER_UPLOADER_ROLE = "54"; //added for CRN by archana
    public static final String CORP_USER_ROLE = "8";
    public static final String AUDIT_USER_ROLE = "9";
    public static final String APPROVER_USER_ROLE = "42";
    public static final String CORP_ADMIN_ROLE = "7";
    
    public static final String RESET_SUPER_ENQR_PWD = "resetLoginPasswordDisplay";
    public static final String DISPATCH_RESET_PWD_CONFIRM = "dispatchResetPWDConfirm";
    public static final String ISSUE_KIT_RESET_PWD_CONFIRM = "issueKitResetPWDConfirm";

    public static final String ADDRESS1 = "address1";	
    public static final String ADDRESS2 = "address2";
	public static final String CITY = "city";	
	public static final String DISTRICT = "district";
	public static final String STATE = "state";	
	public static final String COUNTRY="country";
	public static final String ZIP = "zip";	
	public static final String DESIGNATION="designation";	
	public static final String DEPARTMENT="department";
	public static final String EMPLOYEE_NO = "employee_no";
	public static final String ROLE = "role";	
	public static final String EMAIL="email";
	public static final String CREATED_BY ="created_by";
	public static final String ADDRESS = "address"; 	
	public static final String HOME_PHONE="home_phone";
    //5472 ends
	
	//Added By Amar for Mobile Number Registeration
	public static final String MOBILE_NO="mobileno";
	public static final String COUNTRY_CODE="countrycode";
	
	
	//Added for customer support -Starts
	
	public static final String COMPOSE_ISSUE="composeIssue";
	
	public static final String USER_TYPE="userType";
	
	public static final String ISSUE_CODE="issueCode";
	
	public static final String DESCRIPTION="description";
	
	public static final String COMPOSE_ISSUE_CONFIRM="composeIssueConfirm";

	public static final String VIEW_TICKETS="viewTickets";
	
	public static final String VIEW_TICKETS_DETAILS="viewTicketDetails";
	
	public static final String UPDATE_TICKET_CONFIRM="updateTicketConfirm";
	
	public static final String VIEW_MAILS="viewmails";
	
	public static final String VIEW_MAIL_DETAILS="viewMailDetails";
	
	public static final String VIEW_CLOSED_TICKETS="viewClosedTickets";
	
	public static final String VIEW_CLOSED_TICKETS_DETAILS="viewClosedTicketDetails";
	
	
	
	//Added for customer support -Ends
	//Added for CR 5550

	 public static final String PASSWORD_MODE = "passwordMode";
	 
	 public static final String CHANGE_KLOGIN_PWD = "changeKLoginPwd";
	 
	 public static final String UPDATE_KLOGIN_PWD = "updateKLoginPwd";
	 public static final String MY_PAGE = "myPage";
	//  End of CR 5550 
	// Added for Mobile Registration -Start -->

	 public static final String TRANSACTION_NAME = "transactionName";
	 
	 public static final String USER_PROFILE_PASSWORD = "profilePassword";
	 public static final String USER_PROFILE_SHA_PASSWORD = "profileSHAPassword"; // Added for SHA - 512
	 
	 public static final String PROFILE_PWD_ERRORVIEW = "errorProfilePWDVerifyConfirm";
	
    // Dev 129 - # Popup Mail Alert
    public static final String JSON_DATA_ROOT_KEY = "data";
	public static final String JSON_SUCCESS_KEY = "success";
	public static final String JSON_TOTAL_COUNT = "totalCount";
	//pending statements
	    public static final String PARAM5 = "param5";
	    public static final String REQUEST_ID = "request_Id";
	    public static final String PARAM1 = "param1";
	    public static final String PARAM2 = "param2";
	    public static final String PARAM4 = "param4";
	    public static final String BRANCH_NAME = "branchName";
	    public static final String CREATION_TIME = "creation_time";
	    public static final String FROM_DATE = "fromDate";
	    public static final String TO_DATE = "toDate";
	    public static final String SORTING_ORDER = "order";
	    public static final String NO_OF_ROWS = "noOfRows";
	    public static final String FILE_FORMAT = "fileFormat";
	    public static final String ACCOUNT_DETAILS = "AccountDetails";
	    public static final String TRANSACTION_HISTORY = "TransactionHistory";
	    public static final String REQUEST_PARAMETER = "RequestParameter";
	    public static final String TOTAL_TRANSACTIONS = "TotalTransactions";
	    public static final String PAGE_NUMBER = "pageNumber";
	    public static final String MAX_PAGE = "max";
	    public static final String COUNT = "count";
        public static final String HINT_QUESTION = "hintQuestion";
        public static final String HINT_ANSWER = "hintAnswer";
    
 // Added for FCNB Loan for corporate - Start -->
	 public static final String FCNB_ERRORVIEW = "errorFCNBDetails";
		//Added for SHA encryption algorithm
	public static final String SHA2_PASSWORD = "sha2password";

	 	//Added for Raksha-IRCTC Corporate
		public static final String RAKSHA_CORPORATE="raksha";
		
		
		//Added E-suvidha
		 public static final String CREDIT_ACCOUNT_NO = "creditAccountNo";
		 public static final String CREDIT_BRANCH_CODE = "creditBranchCode";
		 public static final String TRANSACTION = "transaction";
		 public static final String DEBIT_ACCOUNT_NO = "debitAccountNo";
		 public static final String DEBIT_ACCOUNT_TYPE = "debitAccountType";
		 public static final String DEBIT_BRANCH_CODE = "debitBranchCode";
	     public static final String DEBIT_AMOUNT_TRANSFER = "debitAmountTransfer";
	     
	     public static final String CREDIT_AMOUNT_TRANSFER = "creditAmountTransfer";
	     public static final String LINK_FT = "linkFundsTransfer";
	     public static final String AMOUNT ="amount";
	     public static final Object TRANSACTION_REMARKS = "transactionRemarks";
	     public static final String REMARKS = "transactionRemarks";
		 public static final String MERCHANT = "merchant";

		//Added for eTDR/eSTDR -Start
		public static final String AMOUNT_TRANSFER = "amountTransfer";
		public static final String FIXED_ACCOUNT_TYPE = "fixedAccountType";
		public static final String DEBIT_PRODUCT_CODE = "debitProductCode";
		public static final String TRANSACTION_MODEL = "transactionModel";
		public static final String DEBIT_ACCOUNT = "debitAccount";
		public static final String FIXED_DEPOSIT_ACCOUNT = "fixedDepositAccount";
		public static final String FIXED_DEPOSIT_ACCOUNT_NO = "fixedDepositAccountNo";
		public static final String ACTION_PAGE = "actionPage";
		public static final String TRANSACTION_ENQUIRY = "transactionEnquiry";
		public static final String TRANSACTION_STATUS_CODE0 = "00";
		//Added for eTDR/eSTDR -End
	    public static final String LAST_LOGIN_PWD_CHANGE_DATE = "lastPwdChangeDate";
	    
	    public static final String LAST_LOGIN_FAILURE_DATE = "lastLoginFailureDate";
	    
	    


}

