
/*
 * UserBasedDisplay.java
 * Created on Feb 27, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 27, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.handler;

import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.tiles.ComponentContext;
import org.apache.struts.tiles.Controller;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.sbi.common.model.UserProfile;

public class UserBasedDisplay implements Controller
{
    private ResourceBundleMessageSource userProperty;
        
    public void perform(ComponentContext ctx, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext) throws ServletException, IOException
    {
        userProperty =(ResourceBundleMessageSource) WebApplicationContextUtils.getWebApplicationContext(servletContext).getBean("userProperty");
        System.out.println("from request = "+RequestContextUtils.getWebApplicationContext(request).getBean("userProperty"));
        Iterator definition = ctx.getAttributeNames();
        
        while(definition.hasNext())
        {
            try{//
        String attributeName = (String) definition.next();
        System.out.println(" value of tost "+ ctx.getAttribute(attributeName));
        
        if( (ctx.getAttribute(attributeName) instanceof java.lang.String) )
        {
        /*    System.out.println(" it is arraylist "+ctx.getAttribute(attributeName).getClass());
            for (int i=0;i<attributeName.length();i++)
            {
                ArrayList a = new ArrayList();
                System.out.println(" the class inside "+ctx.getAttribute(attributeName).getClass());
                a = (ArrayList) ctx.getAttribute(attributeName);
                System.out.println("the value at "+i+" = "+a.get(i));
            }
        }else{
            System.out.println(" not arraylist "+ctx.getAttribute(attributeName).getClass());
            
            System.out.println("----------"+ctx.getAttribute(attributeName));
            
            
            System.out.println(";;;;;;;;;;;;;;;");
        
        System.out.println("attribute name ==="+attributeName);
        System.out.println("value ==="+value);*/
        String value =(String)ctx.getAttribute(attributeName);
        String regex1 = "\\{*\\}";            
        String regex = "([^{]*)\\.([^}]*)";
        Pattern pattern = Pattern.compile(regex);
        Pattern pattern1 = Pattern.compile(regex1);
        Matcher matcher = pattern.matcher(value);
        Matcher matcher1 = pattern1.matcher(value);
        if(value!=null && matcher1.find())
        {  System.out.println("inside if"); 
            System.out.println("value 1= "+matcher.find());
           System.out.println("value 1= "+matcher.group(1));
           System.out.println("value 2= "+matcher.group(2));
           if(matcher.group(1)!=null && matcher.group(1).equalsIgnoreCase("session"))
           {
               HttpSession session = request.getSession(false);
               UserProfile user = new UserProfile();
               String  role =null;
               if(session!=null)
               {
                  user =(UserProfile) session.getAttribute(UIConstant.USER);
               }
               String  bankCode =null;
               if(user.getBankCode()!=null)
                   bankCode =  user.getBankCode();
               if(user.getRoles()!=null)
                   role =  user.getUserType().toString();
               if(matcher.group(2)!=null && matcher.group(2).equalsIgnoreCase("role"))
               {
                      if(role != null)
                        {
                            System.out.println("userprop "+userProperty);
                            String user_view = userProperty.getMessage(UIConstant.USER+"."+role,null,null);
                            System.out.println("role = "+role);
                            System.out.println("user_view = "+user_view);
                            ctx.putAttribute(attributeName,user_view);
                        }
    
                   
               }else if(matcher.group(2)!=null && matcher.group(2).equalsIgnoreCase("header"))
               {
                   if(bankCode != null)
                        {
                            System.out.println("userprop "+userProperty);
                            String user_view = userProperty.getMessage(UIConstant.USER+"."+bankCode+"."+"header",null,null);
                            System.out.println("role = "+bankCode);
                            System.out.println("user_view = "+user_view);
                            System.out.println("attributeName"+attributeName);
                            ctx.putAttribute(attributeName,user_view);
                        }
                }else if(matcher.group(2)!=null && matcher.group(2).equalsIgnoreCase("footer"))
                {
                    if(bankCode != null)
                         {
                             System.out.println("userprop "+userProperty);
                             String user_view = userProperty.getMessage(UIConstant.USER+"."+bankCode+"."+"footer",null,null);
                             System.out.println("role = "+bankCode);
                             System.out.println("user_view = "+user_view);
                             System.out.println("attributeName"+attributeName);
                             ctx.putAttribute(attributeName,user_view);
                         }
                 }
           }
           
        }
        }
            }catch(Exception ex)
            {
                ex.printStackTrace();
            } 
       }
    }

   public void execute(ComponentContext arg0, HttpServletRequest arg1, HttpServletResponse arg2, ServletContext arg3) throws Exception
    {
        // TODO Auto-generated method stub
        
    }
    /**
     * @param userProperty The userProperty to set.
     */
    public void setUserProperty(ResourceBundleMessageSource userProperty)
    {
        this.userProperty = userProperty;
        System.out.println("userProperty  "+userProperty);
    }

    
    
}
