
/*
 * DigitalCertificateHandler.java
 * Created on March 29, 2013
 *  
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History

package com.sbi.common.handler;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.DSCDetails;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;


public class DigitalCertificateHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService registerCertificateConfirmService;
    
    private BaseService digitalCertificateC11FormService;

    private BaseService deactivationDSCService;
    
    private BaseService deactivationDSCConfirmService;
    private BaseService generateDSCFormService;
    private BaseService digitalCertificateAuthenticateService;
    private BaseService reRegisterDSCConfirmService;
    
    private BaseService sfaModeChangeConfirmService;
    
    private BaseService registerDSCPendingListService;
    
    private ResourceBundleMessageSource logonProperty;
    
    public ModelAndView initRegisterSFAuthDSCDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("initRegisterSFAuthDSCDisplay -- begins");
        HttpSession session = request.getSession(false);
 	    Map outParams=new HashMap();
 	    outParams.put("profileTabFlag", "No");
 	    logger.info("initRegisterSFAuthDSCDisplay -- ends");
        return new ModelAndView("initRegisterSFAuthDSCDisplay", "dscModel", outParams);
       
    }
    public ModelAndView registerSFAuthDSCDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("registerSFAuthDSCDisplay -- begins");
        HttpSession session = request.getSession(false);
 	    Map outParams=new HashMap();
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	     logger.info("corporateProfile -->"+corporateProfile.getAddress1()+"address2 "+corporateProfile.getAddress2());
        String userName = user.getUserAlias();
        String name = user.getName();
        String corporateId = user.getCorporateId();
        String isTermsAlreadyAgreed=(String)session.getAttribute("isTermsAlreadyAgreed");
        String view = "initProfileRegisterSFAuthDSCDisplay";
        String isTermsAgreed=(String)request.getParameter("istermsagreed");
        
        if("Yes".equalsIgnoreCase(isTermsAlreadyAgreed) || "Yes".equalsIgnoreCase(isTermsAgreed)) {
        	logger.info("corporateId >>>"+corporateId);
            logger.info("branchCode >>>"+user.getBranchCode());
            logger.info("bankCode >>>"+user.getBankCode());
            outParams.put("userName",userName);
            outParams.put("corpName",corporateProfile.getCorporateName());
            outParams.put("corporateId",corporateId);
            outParams.put("branchCode",user.getBranchCode());
            outParams.put("address1",corporateProfile.getAddress1());
            outParams.put("address2",corporateProfile.getAddress2());
            outParams.put("city",corporateProfile.getCity());
            outParams.put("pincode",corporateProfile.getPincode());
            
            view="registersfauthdscdisplay";
            session.removeAttribute("isTermsAlreadyAgreed");
        }
                
        logger.info("registerSFAuthDSCDisplay -- ends");
        return new ModelAndView(view, "dscModel", outParams);
       
    }
    
    
    public ModelAndView getVerifiedSignedData(HttpServletRequest request, HttpServletResponse response) throws RemoteException 
    {        
        logger.info("getVerifiedSignedData(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        Map inParam = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        String userName =user.getUserAlias();
        String branchCode = user.getBranchCode();
       // String corporateId= corporateProfile.getCorporateID();
       // String corpName = corporateProfile.getCorporateName();
        String corporateId= request.getParameter("corporateId");
        String corpName = request.getParameter("corpName");
        String corpAddress = request.getParameter("corpAddress");
        logger.info("corporateId :::"+corporateId);
        logger.info("corpName :::"+corpName);
        logger.info("corpAddress :::"+corpAddress);
        logger.info("userName :::"+userName);
        logger.info("branchCode :::"+branchCode);
        //inParam.put("userName", user.getUserAlias());        
       // inParam.put("signedData",request.getParameter("signedData"));
       // inParam.put(UIConstant.BANK_CODE,user.getBankCode());   
       // outParam.put("signedData",request.getParameter("signedData"));
        String signedData = request.getParameter("signedData");
        String referenceNo ="";
      String moduleName="";
        Integer userRole = (Integer) user.getRoles().get(0);
		logger.info("userRole ===>"+userRole);
		if(userRole == 7)
			moduleName = "Administrator";
		
		if(userRole == 10)
			moduleName = "Regulator";		
		
		if(userRole == 8)
			moduleName = "User";
		else if(userRole == 42)
			moduleName = "Approver";
		
        /*DSVerifyWS  dSVerifyWS= new DSVerifyWSProxy().getDSVerifyWS();
        
        String verifymsg=dSVerifyWS.verify("pkcs7", request.getParameter("signedData"), "plain");
        String serialNo = "";
        if(verifymsg.equalsIgnoreCase("success"))
        {
        	serialNo = getSNFromPKCS7(request.getParameter("signedData"));	
        }
       
        
        logger.info("verifyyy=======>"+verifymsg);
        logger.info("serialNo=======>"+serialNo);
        */
       
        inParam.put("userName", userName);        
        inParam.put("branchCode", branchCode);        
        inParam.put("corporateId", corporateId);        
        inParam.put("corpName", corpName);        
        inParam.put("corpAddress", corpAddress);        
        //inParam.put("serialNo",serialNo);
        inParam.put("signedData",signedData);
        //inParam.put(UIConstant.BANK_CODE,user.getBankCode());
        inParam.put("sfAuthProvider", user.getSfAuthProvider());        
        inParam.put("profileDscSerialno",user.getNewspreference5());
        inParam.put("moduleName",moduleName);
        outParam = registerCertificateConfirmService.execute(inParam);
        referenceNo = (String) outParam.get("referenceNo");
    
        session.setAttribute("referenceNo", referenceNo);
        logger.info("referenceNo>>>>>>>>>>>>>"+session.getAttribute("referenceNo"));
        logger.info("referenceNo>>>>>>>>>>>>>"+session.getAttribute("referenceNo"));
        logger.info("referenceNo>>>>>>>>>>>>>"+session.getAttribute("referenceNo"));
     
        outParam.put(UIConstant.ERROR_VIEW, "digitalSignatureErrorDisplay");
        logger.info("getVerifiedSignedData(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODEND);
        return new ModelAndView("registerCertificateConfirm","outParam",outParam);
    }


    
    public ModelAndView showDSCC11Form(HttpServletRequest request,HttpServletResponse response) {
		logger.info("showDSCC11Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);

		DSCDetails dscDetails=null;
		HttpSession session = request.getSession(false);
		Map outParams = new HashMap();
		UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
		 Map outParam = new HashMap();
	      Map inputParams = new HashMap();
	      
		String reffNo =(String) session.getAttribute("referenceNo");
		  logger.info("referenceNo :"+reffNo);
		  inputParams.put("referenceNo", reffNo);
		  
		String dscFunction =(String) request.getParameter("dscFunction");
		logger.info("dscFunction :"+dscFunction);
		inputParams.put("dscFunction", dscFunction);
		
		outParams = digitalCertificateC11FormService.execute(inputParams);
		String friendlyName = profile.getFriendlyName();
		Integer userRole = (Integer) profile.getRoles().get(0);
		logger.info("userRole ===>"+userRole);
		logger.info("getEmpNo ===>"+profile.getEmpNo());
		outParams.put("userRole",userRole);
		outParams.put("empNo",profile.getEmpNo());
	
		outParam.put(UIConstant.ERROR_VIEW, "digitalSignatureErrorDisplay");
		logger.info("showDSCC11Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("showRegisterDSCc11Form", "outParams",outParams);

	}
    
    
    public ModelAndView deactivateDSCDisplay(HttpServletRequest request,HttpServletResponse response) {
		logger.info("deactivateDSCDisplay(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		
		RegMobileNoDetails regMobileNoDetails = null ;
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	    //String oldMobileNo = profile.getMobileNumber();
	    //String countryCode = profile.getCountryCode();
	    String userName = profile.getUserAlias();
	    String serialNo = profile.getNewspreference5();
	    String securityOption = profile.getSfAuthProvider();
	    String viewName ="";
	    Integer userRole = (Integer) profile.getRoles().get(0);
	    
	    Map inParams = new HashMap();
	    Map outParams = new HashMap();
	    inParams.put("userName", userName);
	    inParams.put("serialNo", serialNo);
	    inParams.put("securityOption", securityOption);
	  
	    request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "DC");
	    outParams = deactivationDSCService.execute(inParams); 
	    
	    SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
	    applicationResponse=(SBIApplicationResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
	    logger.info("applicationResponse --->"+applicationResponse.getErrorStatus());
	    logger.info("applicationResponse --->"+applicationResponse);
	    outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
	    
	    outParams.put("userRole", userRole);
	    outParams.put("mobileNo", profile.getMobileNumber());
	    
	    outParams.put(UIConstant.ERROR_VIEW, "deactiveerrorview");
	    logger.info("outParams >dscDetails >>"+outParams.get("dscDetails"));
		//applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);
		
		logger.info("deactivateDSCDisplay(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("deactivationDSCform", "outParams",outParams);

	}
    
    
    public ModelAndView deactivateDSCConfirm(HttpServletRequest request,HttpServletResponse response) {
		logger.info("deactivateDSCConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		
		RegMobileNoDetails regMobileNoDetails = null ;
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	    //String oldMobileNo = profile.getMobileNumber();
	    //String countryCode = profile.getCountryCode();
	    String userName = profile.getUserAlias();
	    String referenceNo = request.getParameter("referenceNo");
	    
	    logger.info("userName -:"+userName);
	    logger.info("referenceNo -:"+referenceNo);
	    //String serialNo = profile.getNewspreference5();
	    //String securityOption = profile.getSfAuthProvider();
	    
	    Map inParams = new HashMap();
	    Map outParams = new HashMap();
	    inParams.put("userName", userName);
	    inParams.put("referenceNo", referenceNo);
	    inParams.put("mobileNo", profile.getMobileNumber());
	    logger.info("mobileNo:"+profile.getMobileNumber());
	   // inParams.put("securityOption", securityOption);
	    outParams = deactivationDSCConfirmService.execute(inParams);
	    
	    
		
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
	    applicationResponse=(SBIApplicationResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
	    logger.info("applicationResponse --->"+applicationResponse);
	    outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
	    
		  outParams.put(UIConstant.ERROR_VIEW, "deactiveerrorview");
		logger.info("deactivateDSCConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("deactivationConfirm", "outParams",outParams);

	}
   // deactivateDSCDetailsDisplay
    
    public ModelAndView digitalCertificateAuthDisplay(HttpServletRequest request, HttpServletResponse response)  throws Exception
    {
        logger.info("digitalCertificateAuthDisplay(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        HttpSession session = request.getSession(false);
        
        String dscLoginCount=(String)session.getAttribute("dscLoginCount");
		if(dscLoginCount==null) {
			session.setAttribute("dscLoginCount", "1");
		}else {
			Integer dscLoginCountValue=Integer.parseInt(dscLoginCount)+1;
			session.setAttribute("dscLoginCount",dscLoginCountValue.toString());
		}
        
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus(UIConstant.SUCCESS);
        outParam.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("digitalCertificateAuthDisplay(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);              
        return new ModelAndView("digitalCertificateAuthDisplay","registerModel",outParam);
    }
  
	
	 public ModelAndView digitalCertificateAuthConfirm(
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("digitalCertificateAuthConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		Map inParam = new HashMap();
		HttpSession session = request.getSession(false);
		UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
		String signedData = request.getParameter("signedData");
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		String redirectionString = "";
		String viewName = "digitalCertificateAuthDisplay";
		Integer userRole = 0;
        if(session.getAttribute("userRole") != null) {
        	userRole = (Integer) session.getAttribute("userRole");
		}
        
		Boolean isValid = false;
		
		inParam.put("userName", userProfile.getUserAlias());
		inParam.put("profileSerialNo", userProfile.getNewspreference5());
		inParam.put("signedData", signedData);
		
		outParams=digitalCertificateAuthenticateService.execute(inParam);
		if(outParams.get("isValid")!=null)
			isValid=(Boolean)outParams.get("isValid");
		
		applicationResponse=(SBIApplicationResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
		
		if (ServiceErrorConstants.SUCCESS.equals(applicationResponse.getErrorStatus()) && isValid) {
	    	redirectionString = getPropertyVal("role"+userRole.toString());
        	logger.info("redirectionString : " + redirectionString);
        	getMailAlert(request);
        	getServletContext().getRequestDispatcher(redirectionString).forward(request,response);
        	applicationResponse.setErrorStatus("SUCCESS");
		} else {
		/*	applicationResponse.setErrorStatus(ServiceConstant.FAILURE);
			applicationResponse.setErrorCode("DSC001");*/
			viewName="errorDigitalCertificateAuthDisplay";
		}
		outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
		logger.info("digitalCertificateAuthConfirm(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
		return new ModelAndView(viewName,"outParams",outParams);
	}
    
      private String getPropertyVal(String key) {
		String value = "";
		try {
			logger.info("key val :" + key);
			value = logonProperty.getMessage(key, null, null);
		} catch (NoSuchMessageException ex) {
			logger.error("NoSuchMessageException occured", ex);
		}
		return value;
	}
	
	public void getMailAlert(HttpServletRequest request){
    	logger.info("getMailAlert(HttpServletRequest request)"+ LoggingConstants.METHODBEGIN);
    	HttpSession session = request.getSession(false);   	    
        if(session!=null){
        	session.setAttribute("mailAlertFlag",true);
        }
        logger.info("=====getMailAlert() end vasco and mobile OTP===== " );
	}
	
	public ModelAndView getC11FormListDetails(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("getC11FormListDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		String errorView=null;
		
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);    
		
		inputParams.put("userName", user.getUserAlias());
		inputParams.put("corporateId",user.getCorporateId());
		inputParams.put("functionType","listView");
		
		outParams=generateDSCFormService.execute(inputParams);
		outParams.put("userName", user.getUserAlias());
		outParams.put(UIConstant.ERROR_VIEW,errorView);
	    logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    
	    logger.info("getC11FormListDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("dscc11formlist","model",outParams);
	}
	
	public ModelAndView getC11FormDetails(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("getC11FormDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		String errorView=null;
		HttpSession session = request.getSession(false);
		String referenceNo = (String)request.getParameter("referenceNo");
		String requestType = (String)request.getParameter("requestType");
		
		inputParams.put("referenceNo", referenceNo);
		inputParams.put("requestType", requestType);
		
		outParams=generateDSCFormService.execute(inputParams);
		
		session.setAttribute("referenceNo",outParams.get("referenceNo"));
        
        logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    outParams.put(UIConstant.ERROR_VIEW,errorView);
	    
	    logger.info("getC11FormDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("viewC11FormDetails","model",outParams);
	}
	
	public ModelAndView reprintC11Form(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("reprintC11Form(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		String errorView=null;
		HttpSession session = request.getSession(false);
		String referenceNo = (String)request.getParameter("referenceNo");
		inputParams.put("referenceNo", referenceNo);
		
		if(session.getAttribute("dscDetails")!=null)
			outParams.put("dscDetails", session.getAttribute("dscDetails"));
		else 
			outParams=generateDSCFormService.execute(inputParams);
		
		logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    outParams.put(UIConstant.ERROR_VIEW,errorView);
	    
	    logger.info("reprintC11Form(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("reprintC11Form","model",outParams);
	}
	
	public ModelAndView reRegisterDSCDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
		logger.info("reRegisterDSCDisplay(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
        HttpSession session = request.getSession(false);
        Map inparams=new HashMap();
 	    Map outParams=new HashMap();
 	   User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
 	   String userName = user.getUserAlias();
 	   inparams.put("userName",userName);
 	    String reRegisterMode = (String)request.getParameter("reRegisterMode");
 	    String dscReRegistration = (String)request.getAttribute("dscReRegistration");
 	    String viewName="";
 	   outParams = registerDSCPendingListService.execute(inparams);
 	    if("loginmode".equalsIgnoreCase(reRegisterMode) || "dscReRegister".equalsIgnoreCase(dscReRegistration)) 
 	    	viewName="reregisterdscdisplayloginmode";
 	    else
 	    	viewName="reregisterdscdisplay";
 	   logger.info("outParams>>>>>>"+outParams.get("pendingCount"));
 	    outParams.put("reRegisterMode", reRegisterMode);
 	    outParams.put("dscReRegistration", dscReRegistration);
 	    
        logger.info("reRegisterDSCDisplay(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
        return new ModelAndView(viewName, "outParams", outParams);
       
    }
	
	public ModelAndView reRegisterDSCConfirm(HttpServletRequest request, HttpServletResponse response) throws RemoteException 
    {        
        logger.info("reRegisterDSCConfirm(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        Map inParam = new HashMap();
        HttpSession session = request.getSession(false);
        UserProfile userProfile = (UserProfile) session.getAttribute(UIConstant.USER);
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        String userName =userProfile.getUserAlias();
        String branchCode = userProfile.getBranchCode();
        String corporateId= corporateProfile.getCorporateID();
        String corpName = corporateProfile.getCorporateName();
        String signedData = request.getParameter("signedData");
        String referenceNo ="";
        String viewName="";
        String reRegisterMode = (String)request.getParameter("reRegisterMode");
        String dscReRegistration = (String)request.getParameter("dscReRegistration");
        
        logger.info("userName :::"+userName);
        logger.info("branchCode :::"+branchCode);
        String moduleName="";
        Integer userRole = (Integer) userProfile.getRoles().get(0);
		logger.info("userRole ===>"+userRole);
		if(userRole == 7)
			moduleName = "Administrator";
		
		if(userRole == 10)
			moduleName = "Regulator";		
		
		if(userRole == 8)
			moduleName = "User";
		else if(userRole == 42)
			moduleName = "Approver";
		
		
        inParam.put("userName", userName);        
        inParam.put("branchCode", branchCode);        
        inParam.put("corporateId", corporateId);        
        inParam.put("corpName", corpName);        
        inParam.put("signedData",signedData);
        inParam.put("sfAuthProvider", userProfile.getSfAuthProvider());        
        inParam.put("profileDscSerialno",userProfile.getNewspreference5());
        inParam.put("moduleName",moduleName);
        
        outParam = reRegisterDSCConfirmService.execute(inParam);
        
        SBIApplicationResponse applicationResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
		
		if(applicationResponse.getErrorStatus().equalsIgnoreCase("success")) {
			 if("loginmode".equalsIgnoreCase(reRegisterMode) || "dscReRegister".equalsIgnoreCase(dscReRegistration)) {
	 	    	viewName="reregisterdscconfirmloginmode";
			 }
			 else {
	 	    	viewName="reregisterdscconfirm";
	 	    }
		}
		else {
			if("loginmode".equalsIgnoreCase(reRegisterMode) || "dscReRegister".equalsIgnoreCase(dscReRegistration)) {
	 	    	viewName="digitalSignatureErrorDisplayloginmode";
	        }
	 	    else {
	 	    	viewName="digitalSignatureErrorDisplay";
	 	    }
		}
        
 	    
        referenceNo = (String) outParam.get("referenceNo");
    
        session.setAttribute("referenceNo", referenceNo);
        logger.info("referenceNo :"+session.getAttribute("referenceNo"));
        
        logger.info("reRegisterDSCConfirm(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"outParam",outParam);
    }
	public ModelAndView sfaModeDisplay(HttpServletRequest request,HttpServletResponse response) {
			logger.info("sfaModeDisplay(HttpServletRequest request, HttpServletResponse response)"
							+ LoggingConstants.METHODBEGIN);
			
			
			RegMobileNoDetails regMobileNoDetails = null ;
			HttpSession session = request.getSession(false);
			SBIApplicationResponse sbiAppResponse = new SBIApplicationResponse();
			DSCDetails dscDetails = new DSCDetails();
		    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		    //String oldMobileNo = profile.getMobileNumber();
		    //String countryCode = profile.getCountryCode();
			Map inParams = new HashMap();
			Map outParams = new HashMap();
		    String userName = null;
		    userName = profile.getUserAlias();
		     String modeFlag ="getProviderDetails";
		     inParams.put("userName",userName); 
		     inParams.put("modeFlag",modeFlag);
		     outParams = sfaModeChangeConfirmService.execute(inParams);
		    String viewName ="";
		    logger.info("userName --->"+outParams.get("dscDetails"));
		    dscDetails =(DSCDetails)outParams.get("dscDetails");
		    String typeOfMode = dscDetails.getSfaProviderMode();
		    
	        if(typeOfMode != null && !typeOfMode.trim().equalsIgnoreCase("")&& typeOfMode.trim().equalsIgnoreCase("Mobile")){
		    	  sbiAppResponse.setErrorCode("DSC007");
	           	   sbiAppResponse.setErrorStatus("failure");
	           	   outParams.put(UIConstant.APPLICATION_RESPONSE, sbiAppResponse);
		    }else{
		    	   sbiAppResponse=(SBIApplicationResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
				    logger.info("applicationResponse --->"+sbiAppResponse);
				    outParams.put(UIConstant.APPLICATION_RESPONSE,sbiAppResponse);
		    }
		    
		    logger.info("userName -:"+userName);
			
			
		 
		    
		  /*  outParams.put("userName", userName);
		    outParams.put("securityMode", securityMode);
		    outParams.put("mobileNo", mobileNo);*/
		    outParams.put(UIConstant.ERROR_VIEW, "sfamodeerrorview");
		 	logger.info("sfaModeDisplay(HttpServletRequest request, HttpServletResponse response)"
							+ LoggingConstants.METHODEND);
			return new ModelAndView("sfaModeDisplayForm", "outParams",outParams);

		}
	 
	 
	 
	 public ModelAndView sfaModeChangeConfirm(HttpServletRequest request,HttpServletResponse response) {
			logger.info("sfaModeChangeConfirm(HttpServletRequest request, HttpServletResponse response)"
							+ LoggingConstants.METHODBEGIN);
			
			
			RegMobileNoDetails regMobileNoDetails = null ;
			HttpSession session = request.getSession(false);
			SBIApplicationResponse sbiAppResponse = new SBIApplicationResponse();
		    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		    //String oldMobileNo = profile.getMobileNumber();
		    String countryCode = profile.getCountryCode();
		    String userName = profile.getUserAlias();
		    String selectedMode = request.getParameter("Mode");
		    String mobileNo = request.getParameter("mobileNo");
		    
			logger.info("userName :"+userName);
			logger.info("selectedMode :"+selectedMode);
			logger.info("mobileNo :"+mobileNo);
			
			Map inParams = new HashMap();
		    Map outParams = new HashMap();
		    inParams.put("userName", userName);
		    inParams.put("sfaMode", selectedMode);
		    
		    if(mobileNo != null && !mobileNo.trim().equalsIgnoreCase("")){
		    	 outParams = sfaModeChangeConfirmService.execute(inParams);
		    }else{
		    	
		    	UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
		    	Integer userRole = (Integer) user.getRoles().get(0);
    			logger.info("userRole ===>"+userRole);
    			if(userRole == 7 || userRole == 10) {
    				sbiAppResponse.setErrorCode("DSC006");
				}
    			else {
    			   sbiAppResponse.setErrorCode("DSC009");
    			}
    			
           	   sbiAppResponse.setErrorStatus(com.sbi.common.handler.UIConstant.FAILURE);
           	   outParams.put(UIConstant.APPLICATION_RESPONSE, sbiAppResponse);
            } 
		    
		    logger.info("userName -:"+userName);
			
			
		    sbiAppResponse=(SBIApplicationResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
		    logger.info("applicationResponse --->"+sbiAppResponse);
		    outParams.put(UIConstant.APPLICATION_RESPONSE,sbiAppResponse);
		    
			  outParams.put(UIConstant.ERROR_VIEW, "deactiveerrorview");
			logger.info("sfaModeChangeConfirm(HttpServletRequest request, HttpServletResponse response)"
							+ LoggingConstants.METHODEND);
			return new ModelAndView("sfaModeChangeCondirm", "outParams",outParams);

		}
	 
	public void setLogonProperty(ResourceBundleMessageSource logonProperty) {
		this.logonProperty = logonProperty;
	}


	public void setDeactivationDSCConfirmService(
			BaseService deactivationDSCConfirmService) {
		this.deactivationDSCConfirmService = deactivationDSCConfirmService;
	}


	public void setDeactivationDSCService(BaseService deactivationDSCService) {
		this.deactivationDSCService = deactivationDSCService;
	}


	public void setDigitalCertificateAuthenticateService(
			BaseService digitalCertificateAuthenticateService) {
		this.digitalCertificateAuthenticateService = digitalCertificateAuthenticateService;
	}


	public void setDigitalCertificateC11FormService(
			BaseService digitalCertificateC11FormService) {
		this.digitalCertificateC11FormService = digitalCertificateC11FormService;
	}


	public void setGenerateDSCFormService(BaseService generateDSCFormService) {
		this.generateDSCFormService = generateDSCFormService;
	}


	public void setRegisterCertificateConfirmService(
			BaseService registerCertificateConfirmService) {
		this.registerCertificateConfirmService = registerCertificateConfirmService;
	}


	public void setReRegisterDSCConfirmService(
			BaseService reRegisterDSCConfirmService) {
		this.reRegisterDSCConfirmService = reRegisterDSCConfirmService;
	}
	
	public void setSfaModeChangeConfirmService(
			BaseService sfaModeChangeConfirmService) {
		this.sfaModeChangeConfirmService = sfaModeChangeConfirmService;
	}


	public void setRegisterDSCPendingListService(
			BaseService registerDSCPendingListService) {
		this.registerDSCPendingListService = registerDSCPendingListService;
	}

    	
} 
