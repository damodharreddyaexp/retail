/* *
 * ApproveThirdPartyHandler.java
 * Created on Jan '08 by Treesa for RTGS 3P Upload
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 */

package com.sbi.common.handler;
  

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
public class ApproveCpsmsBeneficiaryHandler extends MultiActionController {

    

	protected final Logger logger = Logger.getLogger(getClass());

    BaseService approveCpsmsBeneficiaryService;

    BaseService approveCpsmsBenConfirmService;
    
    BaseService corpApproveAccountDisplayService;

/**
 * This Method is executed to display the files pending to approve or delete the Thirdparty 
 * It calls ApproveTPService by
 * passing Map as a inparam which has startdate,enddate,username,banktype,functiontype
 * depends on the function Type view name will get change for DIBTP
 * 
 * @param request
 * @param response
 * */
    
	
    public ModelAndView manageCpsmsBeneficiaryDisplay(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("manageCpsmsBeneficiaryDisplay() method begins");
		Map inparam = new HashMap();
		Map outputParams = new HashMap();
        HttpSession session = request.getSession();
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String corporateId = user.getCorporateId();
        inparam.put(UIConstant.USER_NAME, userName);
        inparam.put("corporateId",corporateId);
          String viewType=null;
		  String actionURL=null;
          String Url=request.getServletPath().substring(1);
          logger.info("URL:"+Url);
          if (Url.equals("approvecpsmsbeneficiary.htm"))
        	  viewType="approve";
          else
              viewType="view";
        outputParams = corpApproveAccountDisplayService.execute(inparam);
        outputParams.put("viewType", viewType);
		logger.info("manageCpsmsBeneficiaryDisplay() method end");
		return new ModelAndView("selectDateRange",UIConstant.ACCOUNT_MODEL,outputParams);
    }
    public ModelAndView approveBenDisplayHandler(HttpServletRequest request,
            HttpServletResponse responce) {
        logger.info("approveBenDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map outputParam1 = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String corporateId = user.getCorporateId();
        // CR-CPSMS Beneficiary details display
        String adminAccNo = request.getParameter("accountNo");
        String startDate=null;
        String endDate=null;
        String viewName=null;
        String originalFileName=null;
        String bankCode=user.getBankCode(); //Added for CPSMS associate banks
        String errorView = "approvebulkexternalthirdpartieserrorView";
        String urlSelected = request.getServletPath().substring(1);
        String viewType=request.getParameter("viewType");
        inputParam.put("viewType", viewType);
        startDate = request.getParameter("startDate");
        endDate = request.getParameter("endDate");
        if(startDate!=null && endDate!=null){
        	session.setAttribute("startDate",startDate);
        	session.setAttribute("endDate",endDate);
        }else{
        	startDate=(String)session.getAttribute("startDate");
        	endDate=(String)session.getAttribute("endDate");
        }
        if (urlSelected.equals("approvecpsmsbeneficiaryview.htm")){
        logger.info("start date :" + startDate + "," + "End Date :" + endDate+","+"viewType"+viewType);
        inputParam.put("startDate", startDate);
        inputParam.put("endDate", endDate);
        viewName = "approveCpsmsBenFileView";
            
        }   
        if(urlSelected.equals("approvebenfilenameview.htm")){
    	  
    	  String fileName=request.getParameter("fileName");
    	  originalFileName=request.getParameter("originalFileName");
    	  logger.info("fileName "+fileName);
    	  String count="true";
    	  inputParam.put("fileName", fileName);
    	  inputParam.put("count", count);
    	  viewName="cpsmsBenFileDetailedView";
      }

        inputParam.put("userName", userName);
        inputParam.put("corporateId",corporateId);
        inputParam.put("bankCode",bankCode);
        
        // CR-CPSMS Beneficiary details display
        inputParam.put("accountNo", adminAccNo);
        
        logger.info("corporateID :" + corporateId);
        outputParam = approveCpsmsBeneficiaryService.execute(inputParam);
        session.setAttribute("approveTPFileDetails",outputParam.get("approveTPFileDetails"));
        outputParam.put("applicationResponse", outputParam.get("applicationResponse"));
        outputParam.put("errorView",errorView);
        outputParam.put("originalFileName",originalFileName);
        outputParam.put("viewType",viewType);
        outputParam.put("startDate",startDate);
        outputParam.put("endDate",endDate);
        outputParam.put("accountNo", adminAccNo);
        logger.info("viewName :"+viewName);
        logger.info("approveBenDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"approveTPDisplayDetails", outputParam);
    }
    public ModelAndView approveBenFileRecordsDisplayHandler(HttpServletRequest request,
            HttpServletResponse responce) {
        logger.info("approveBenFileRecordsDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userName = user.getUserAlias();
        String corporateId = user.getCorporateId();
        String beneficiaryType=request.getParameter("beneficiaryType");
        String requestType=request.getParameter("requestType");
        String fileName=request.getParameter("fileName");
        String originalFileName=request.getParameter("originalFileName");
        
        //added by Damodar
        String selectAll = "no";
        	selectAll = request.getParameter("SELECT_ALL");
        	String resetAll = "no";
        	resetAll = request.getParameter("reset_all");
        	String selectAll1 = "no";
        	selectAll1 = request.getParameter("SELECT_ALL1");
        	String clearAll = "no";
        	clearAll = request.getParameter("clear_all");
        	/*String clearAll1 = "no";
        	clearAll1 = request.getParameter("CLEAR_ALL1");*/
        	
        String recordcount =request.getParameter("recordcount");
        logger.info("Beneficiary record count"+recordcount);
        
        logger.info("selectall flag"+selectAll);
        logger.info("selectall flag1"+selectAll1);
        logger.info("reset all flag"+resetAll);
        logger.info("clear all flag"+resetAll);
        
        String categorycount =request.getParameter("catcount");
        
       if ((selectAll != null) || (resetAll != null) )
       {
        if(selectAll.equalsIgnoreCase("YES") || resetAll.equalsIgnoreCase("YES") || clearAll.equalsIgnoreCase("YES") )
    	   
        {
    	   categorycount =request.getParameter("categorycount");
    	   logger.info("Category wise  count"+categorycount);
        }
       }
    
        logger.info("Category wise  count"+categorycount);
       
        String recordsflag="true";
        String viewName="approveRejectTpFileDisplay";
        String errorView = "approvebulkexternalthirdpartieserrorView";
        String viewType=request.getParameter("viewType");
        // CR-CPSMS Beneficiary details display
        String adminAccNo = request.getParameter("accountNo");
        inputParam.put("accountNo", adminAccNo);
        inputParam.put("viewType", viewType);
        inputParam.put("userName", userName);
        inputParam.put("corporateId",corporateId);
        inputParam.put("beneficiaryType",beneficiaryType);
        inputParam.put("requestType",requestType);
        inputParam.put("fileName",fileName);
        inputParam.put("recordsflag",recordsflag);
        logger.info("corporateID :" + corporateId);
        outputParam = approveCpsmsBeneficiaryService.execute(inputParam);
        //added by damodar..for cpsms ben approve
        outputParam.put("beneficiarycount",recordcount);
        outputParam.put("categorycount",categorycount);
        outputParam.put("SELECT_ALL_FLAG",selectAll);
        outputParam.put("RESET_ALL_FLAG",resetAll);
        outputParam.put("CLEAR_ALL_FLAG",resetAll);
        outputParam.put("SELECT_ALL_FLAG1",selectAll1);
        session.setAttribute("approveTPFileDetails",outputParam.get("approveTPFileDetails"));


        outputParam.put("applicationResponse", outputParam.get("applicationResponse"));
        outputParam.put("errorView",errorView);
        outputParam.put("fileName",fileName);
        outputParam.put("originalFileName",originalFileName);
        outputParam.put("beneficiaryType",beneficiaryType);
        outputParam.put("requestType",requestType);
        outputParam.put("viewType",viewType);
        
        
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        String ehsEnable =null;
        String ehsType =null;
        String transactionName = "ApproveBenFile";;  
	 
        if(corporateProfile != null){
        	ehsEnable = corporateProfile.getEhsEnable();
        	ehsType = corporateProfile.getEhsType();
        	
        }
        logger.info("ehsEnable :"+ehsEnable);
        logger.info("ehsType :"+ehsType);
        outputParam.put("ehsEnable", ehsEnable);
        outputParam.put("ehsType", ehsType);
        outputParam.put("transactionName", transactionName);
        
        outputParam.put("corporateId", corporateId);
        outputParam.put("accountNo", adminAccNo);
       
        logger.info("beneficiarycount :"+outputParam.get("beneficiarycount"));
        logger.info("categorycount :"+outputParam.get("categorycount"));
        logger.info("viewName :"+viewName);
        logger.info("reset all :"+outputParam.get("RESET_ALL_FLAG"));
        logger.info("clear all :"+outputParam.get("CLEAR_ALL_FLAG"));
        logger.info("approveBenFileRecordsDisplayHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODEND);
        return new ModelAndView(viewName,"approveTPFileDetails", outputParam);
    }
    
    public ModelAndView approveBeneficiaryConfirmationHandler(
            HttpServletRequest request, HttpServletResponse response) {
        logger.info("approveTPConfirmationHandler(HttpServletRequest request,HttpServletResponse responce)"+ LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveDetailsConfirm = new HashMap();
        String approveIds;
        String unApproveIds;
        String approvedIds; //Added by Sairam Mobile Registration Phase2 
        String unApprovedIds; //Added by Sairam Mobile Registration Phase2 
        String fileName;
        String approveall;
        String viewName;
        String errorView;
        //added by Damodar
        String selectall ="no";
        selectall = request.getParameter("selectedallcatflag");
        String adminAccNo = request.getParameter("accountNo");
        String categorycount =request.getParameter("categorycount");
        
        
        approveIds = request.getParameter("approveIds");//Change by Sairam Mobile Registration Phase2
        unApproveIds = request.getParameter("unApproveIds");//Change by Sairam Mobile Registration Phase2
        unApprovedIds = request.getParameter("unApprovedIds");//Added by Sairam Mobile Registration Phase2 
        approvedIds = request.getParameter("approvedIds");//Added by Sairam Mobile Registration Phase2 
        fileName = request.getParameter("tpFileName");
        String originalFileName=request.getParameter("originalFileName");;
        approveall=request.getParameter("Approveflag");
        String bankType = request.getParameter("bankType");//added for default file config 
        String functionType = request.getParameter("functionType");
        String actionType=null; //Change by Sairam Mobile Registration Phase2
        actionType = request.getParameter("actionType");
        logger.info("actionType:::: "+actionType);
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String corporateId = user.getCorporateId();
        String userName = user.getUserAlias();
        Integer userRole = (Integer) user.getRoles().get(0);
        inputParam.put("userRole", userRole);
        inputParam.put("tpFileName", fileName);
        inputParam.put("coporateID", corporateId);
        inputParam.put("userName", userName);
        inputParam.put("corporateId", user.getCorporateId());//shanta
        inputParam.put("approveIds", approveIds);
        inputParam.put("unApproveIds", unApproveIds);
        inputParam.put("Approveflag",approveall);
        inputParam.put("bankType",bankType);
        inputParam.put("functionType",functionType);
        inputParam.put("actionType",actionType);
        inputParam.put("unApprovedIds",unApprovedIds);//Added by Sairam Mobile Registration Phase2 
        inputParam.put("approvedIds",approvedIds);
        inputParam.put("accountNo", adminAccNo);
        
        logger.info("approveIds:::: "+approveIds);
        logger.info("unApproveIds:::: "+unApproveIds);
        logger.info("approvedIds:::: "+approvedIds);
        logger.info("unApprovedIds:::: "+unApprovedIds);
        //added by Damodar
        if (selectall != null )
        {
         if(selectall.equalsIgnoreCase("YES"))
     	   
         {
        	 inputParam.put("selectedall",selectall);
     	   
     	   logger.info("select all seleted "+selectall);
     	  logger.info("adminAccNo"+adminAccNo);
         }
        }
         
        outputParam = approveCpsmsBenConfirmService.execute(inputParam);
        
            viewName = "approvebeneficiaryconfirm";//approvebeneficiaryconfirm
            errorView = "bulkexternalthirdpartiesconfirmerrorAdmin";
        
        approveDetailsConfirm.put("tpFileName", fileName);
        approveDetailsConfirm.put("approveFileConfirmDetails", outputParam.get("approveTPFileConfirmDetails"));
        session.removeAttribute("startDate");
        session.removeAttribute("endDate");
		// Added for Reject Benificiary File
        approveDetailsConfirm.put("bankType",bankType);
        
        //added by Damodar for cpsms
        approveDetailsConfirm.put("selectall",selectall);
        approveDetailsConfirm.put("categorycount",categorycount);
        logger.info("selectall:::: "+selectall);
        logger.info("categorycount:::: "+categorycount);
        
        
        approveDetailsConfirm.put("functionType",functionType);
        approveDetailsConfirm.put("originalFileName",originalFileName);
        if(actionType != null && actionType.trim().length()>0)
        	approveDetailsConfirm.put("actionType","rejected");
        else
        	approveDetailsConfirm.put("actionType","approved");
        approveDetailsConfirm.put("applicationResponse", outputParam.get("applicationResponse"));
        approveDetailsConfirm.put("errorView",errorView);
        return new ModelAndView(viewName,"approveDetailsConfirm", approveDetailsConfirm);
    }

   public void setApproveCpsmsBeneficiaryService(BaseService approveCpsmsBeneficiaryService)
   	{
	   this.approveCpsmsBeneficiaryService = approveCpsmsBeneficiaryService;
   	}
   public void setApproveCpsmsBenConfirmService(BaseService approveCpsmsBenConfirmService)
  	{
	   this.approveCpsmsBenConfirmService = approveCpsmsBenConfirmService;
  	}

   public void setCorpApproveAccountDisplayService(BaseService corpApproveAccountDisplayService) 
   {
	   this.corpApproveAccountDisplayService = corpApproveAccountDisplayService;
   }


}
