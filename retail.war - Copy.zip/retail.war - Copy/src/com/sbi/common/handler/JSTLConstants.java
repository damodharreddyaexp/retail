/*
 * JSTLConstants.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 KRISHNA KUMAR - Initial Creation
package com.sbi.common.handler;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public class JSTLConstants extends HashMap{

	private static final long serialVersionUID = 1L;

	private boolean initialised = false;

    private static final Class adaptee = UIConstant.class;

    public JSTLConstants()
    {
        Class c = adaptee;
        Field[] fields = c.getDeclaredFields();
        for (int i = 0; i < fields.length; i++)
        {

            Field field = fields[i];
            int modifier = field.getModifiers();
            if (Modifier.isFinal(modifier) && !Modifier.isPrivate(modifier))
                try
                {
                    this.put(field.getName(), field.get(this));
                }
                catch (IllegalAccessException e)
                {
                }
        }
        initialised = true;
    }

    public void clear()
    {
        if (!initialised)
            super.clear();
        else
            throw new UnsupportedOperationException("Cannot modify this map");
    }

    public Object put(Object key, Object value)
    {
        if (!initialised)
            return super.put(key, value);
        else
            throw new UnsupportedOperationException("Cannot modify this map");
    }

    public void putAll(Map m)
    {
        if (!initialised)
            super.putAll(m);
        else
            throw new UnsupportedOperationException("Cannot modify this map");
    }

    public Object remove(Object key)
    {
        if (!initialised)
            return super.remove(key);
        else
            throw new UnsupportedOperationException("Cannot modify this map");
    }

}