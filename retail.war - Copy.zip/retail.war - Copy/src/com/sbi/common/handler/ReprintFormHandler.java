/**
 * 
 */
package com.sbi.common.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;

/**
 * @author IG68125
 *
 */
public class ReprintFormHandler  extends MultiActionController {

protected final Logger logger = Logger.getLogger(getClass());
	
	private BaseService generatePPKITService;
	
	/*
	 * Method Added for Generating C7 form for Admin to take print - 5552
	 * 
	 */
		
		public ModelAndView generatePPKITC7(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("generatePPKITC7(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			 String errorView=null;
			 String ppKIT="listView";
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put("corporateID",user.getCorporateId());
			inputParams.put("flag",ppKIT);
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
			logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("generatePPKITC7(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("formlist","model",outParams);
		}
		public ModelAndView viewPPKITC7(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("viewPPKITC7(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			 String errorView=null;
			 String ppKIT="ppidDetails";
			HttpSession session = request.getSession(false);
			String ppID=request.getParameter("referenceNo");
			String flagFromListPwdC7a=request.getParameter("fromlistreissuepwd");
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
			inputParams.put("flag",ppKIT);
			inputParams.put("ppID",ppID);
			if(flagFromListPwdC7a!=null) {
			inputParams.put("flag",flagFromListPwdC7a);
			}
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
			if(flagFromListPwdC7a!=null) {
				outParams.put("checkC7a","c7a");
				}
			outParams.put("userAlias",ppID);
			UserProfile userProfile = new UserProfile();
	        userProfile = (UserProfile) outParams.get("userProfile");
	        session.setAttribute("pp_id",ppID);
	        session.setAttribute("corpUserProfile",userProfile);
	        logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("viewPPKITC7(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("ppidview","model",outParams);
		}
		public ModelAndView showRePrintC7Form(HttpServletRequest request, HttpServletResponse response) {
	        logger.info("showRePrintC7Form(HttpServletRequest request, HttpServletResponse response) begins");
	        Map inputParams=new HashMap();
	        Map outParams = new HashMap();
	   	 	String ppKIT="ppidDetails";
	        HttpSession session = request.getSession(false);
	        User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
	        String ppID=request.getParameter("referenceNo");
	        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	        //UserProfile userProfile = (UserProfile) session.getAttribute("corpUserProfile");
	        //logger.info("userProfile"+userProfile);
	        inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
	        inputParams.put("flag",ppKIT);
			inputParams.put("ppID",ppID);
			logger.info("Value going to service::"+inputParams);
			outParams=generatePPKITService.execute(inputParams);
			UserProfile userProfile = (UserProfile)((List)outParams.get("ppkitList")).get(0);
			
			String flag=userProfile.getCreatedBy();
			logger.info("flag in handler is ::"+flag);
	        String corpID = corporateProfile.getCorporateID();
	        String name = corporateProfile.getCorporateName();
	        Integer role=userProfile.getLoginCount();
	        char nameArray[] = name.toCharArray();
	        char corpIDArray[] = corpID.toCharArray();
	        outParams.put("nameArray",nameArray);
	        outParams.put("corpIDArray",corpIDArray);
	        outParams.put("corpID",corpID);
	        outParams.put("corpName",name);	        
	        // Admin Added Auditor Unable to Print C7 Form - Begin
	        if(flag != null){
	        	outParams.put(flag.toLowerCase(),"checked");
	        } else {
	        	Integer userRole=userProfile.getLoginCount();
				switch(userRole) {
				case 8:
					outParams.put("corpuser","checked");
					break;
				case 42:
					outParams.put("approver","checked");
					break;
				case 13:
					outParams.put("superenquirer","checked");
					break;
				case 9:
					outParams.put("auditor","checked");
					break;
				case 21:
					outParams.put("uploader","checked");
					break;	
				case 54: //Added for CRN
					outParams.put("superuploader","checked");
					break;	
				case 7:
					outParams.put("corpadmin","checked");
					break;
				case 10:
					outParams.put("corpreg","checked");
					break;
				}
	        }
	     // Admin Added Auditor Unable to Print C7 Form - End
	        outParams.put("userRole",role);
	        logger.info("showRePrintC7Form(HttpServletRequest request, HttpServletResponse response) ends");
	        return new ModelAndView("rePrintPPKit","model",outParams);
	    }
		
		//5552 c7a imman
		public ModelAndView showPendingReissuePwd(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("showPendingReissuePwd(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			 String errorView=null;
			 String reissuepwd="listpendingreissuepwd";
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
			inputParams.put("flag",reissuepwd);
			
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
			
			logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("showPendingReissuePwd(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("listpendingreissuepwd","model",outParams);
		}
		public ModelAndView showRePrintC7aForm(HttpServletRequest request, HttpServletResponse response) {
	        logger.info("showRePrintC7aForm(HttpServletRequest request, HttpServletResponse response) begins");
	        Map inputParams=new HashMap();
	        Map outParams = new HashMap();
	        String flagFromListPwdC7a= "fromlistreissuepwdc7a";
	        HttpSession session = request.getSession(false);
	        User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
	        String ppID=request.getParameter("referenceNo");
	        String userAlias=request.getParameter("userAlias");
	        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	        
	        inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
	        inputParams.put("flag",flagFromListPwdC7a);
			inputParams.put("ppID",userAlias);
			
			outParams=generatePPKITService.execute(inputParams);
			UserProfile userProfile = (UserProfile)((List)outParams.get("ppkitList")).get(0);
			logger.info("userProfile"+userProfile);
			Integer userRole=userProfile.getLoginCount();
			switch(userRole) {
			case 8:
				outParams.put("corpuser","checked");
				break;
			case 42:
				outParams.put("approver","checked");
				break;
			case 13:
				outParams.put("superenquirer","checked");
				break;
			case 9:
				outParams.put("auditor","checked");
				break;
			case 21:
				outParams.put("uploader","checked");
				break;	
			case 54: //Added for CRN
				outParams.put("superuploader","checked");
				break;	
			case 7:
				outParams.put("corpadmin","checked");
				break;
			case 10:
				outParams.put("corpreg","checked");
				break;
			}
	        String corpID = corporateProfile.getCorporateID();
	        String name = corporateProfile.getCorporateName();
	        char nameArray[] = name.toCharArray();
	        char corpIDArray[] = corpID.toCharArray();
	        outParams.put("nameArray",nameArray);
	        outParams.put("corpIDArray",corpIDArray);
	        
	        outParams.put("userRole",userRole);
	        outParams.put("corpID",corpID);
	        outParams.put("corpName",name);
	        
	        
	        logger.info("showRePrintC7aForm(HttpServletRequest request, HttpServletResponse response) ends");
	        return new ModelAndView("rePrintreissueKit","model",outParams);
	    }
		
		/*
		 * Method Added for Generating c9 form for Regulator to take print
		 * 
		 */
		public ModelAndView listPPKITC9(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("listPPKITC9(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			 String errorView=null;
			 String ppKIT="listViewC9";
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put("corporateID",user.getCorporateId());
			inputParams.put("flag",ppKIT);
			inputParams.put("ppID",user.getUserId().toString());			
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
			logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("listPPKITC9(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("listc9","model",outParams);
		}
		
		public ModelAndView viewInterimC9(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("viewInterimC9(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			 String errorView=null;
			 String ppKIT="c9UserDetails";
			HttpSession session = request.getSession(false);
			String ppID=request.getParameter("referenceNo");
			String flagFromListC9=request.getParameter("fromlistc9");
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
			inputParams.put("flag",ppKIT);
			inputParams.put("ppID",ppID);
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
		/*	if(flagFromListPwdC7a!=null) {
				outParams.put("checkC7a","c7a");
				}*/
			outParams.put("userAlias",ppID);
			UserProfile userProfile = new UserProfile();
	        userProfile = (UserProfile) outParams.get("userProfile");
	        session.setAttribute("pp_id",ppID);
	        session.setAttribute("corpUserProfile",userProfile);
	        logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("viewInterimC9(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("c9interimreprint","model",outParams);
		}
		
		public ModelAndView showRePrintC9Form(HttpServletRequest request, HttpServletResponse response) {
	        logger.info("showRePrintC9Form(HttpServletRequest request, HttpServletResponse response) begins");
	        Map inputParams=new HashMap();
	        Map outParams = new HashMap();
	        String flagFromListPwdC7a= "c9UserDetails";
	        HttpSession session = request.getSession(false);
	        User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
	        String ppID=request.getParameter("referenceNo");
	        String userAlias=request.getParameter("userAlias");
	        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	        
	        inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
	        inputParams.put("flag",flagFromListPwdC7a);
			inputParams.put("ppID",ppID);
			
			outParams=generatePPKITService.execute(inputParams);
			UserProfile userProfile = (UserProfile)((List)outParams.get("ppkitList")).get(0);
			logger.info("userProfile"+userProfile);
			Integer userRole=userProfile.getLoginCount();
			switch(userRole) {
			case 8:
				outParams.put("corpuser","checked");
				break;
			case 42:
				outParams.put("approver","checked");
				break;
			case 13:
				outParams.put("superenquirer","checked");
				break;
			case 9:
				outParams.put("auditor","checked");
				break;
			case 21:
				outParams.put("uploader","checked");
				break;	
			case 54:
				outParams.put("superuploader","checked");
				break;	
			case 7:
				outParams.put("corpadmin","checked");
				break;
			case 10:
				outParams.put("corpreg","checked");
				break;
			}
	        String corpID = corporateProfile.getCorporateID();
	        String name = corporateProfile.getCorporateName();
	        char nameArray[] = name.toCharArray();
	        char corpIDArray[] = corpID.toCharArray();
	        outParams.put("nameArray",name);
	        outParams.put("corpIDArray",corpID);
	        outParams.put("createdUserRole", userRole);
	        
	        logger.info("showRePrintC9Form(HttpServletRequest request, HttpServletResponse response) ends");
	        return new ModelAndView("rePrintc9Kit","model",outParams);
	    }
		/***
		 * Added for VASCO Implementation
		 * @param request
		 * @param response
		 * @return
		 */
		public ModelAndView showC10Form(HttpServletRequest request, HttpServletResponse response) {
			logger.info("showC10Form(HttpServletRequest request, HttpServletResponse response) begins");
			Map inputParams=new HashMap();
			Map outParams = new HashMap(); 
			String flagFromListPwdC7a= "c10UserDetails";
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER);//CR 5552    
			String ppID=Integer.toString(user.getUserId());
			String userAlias=request.getParameter("userAlias");
			CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
			
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
			inputParams.put("flag",flagFromListPwdC7a);
			inputParams.put("ppID",ppID);
			
			outParams=generatePPKITService.execute(inputParams);
			UserProfile userProfile = (UserProfile)((List)outParams.get("ppkitList")).get(0);
			logger.info("userProfile"+userProfile);
			Integer userRole=userProfile.getLoginCount();
			switch(userRole) {
			case 8:
				outParams.put("corpuser","checked");
				break;
			case 42:
				outParams.put("approver","checked");
				break;
			case 13:
				outParams.put("superenquirer","checked");
				break;
			case 9:
				outParams.put("auditor","checked");
				break;
			case 21:
				outParams.put("uploader","checked");
				break;	
			case 54:
				outParams.put("superuploader","checked");
				break;	
			case 7:
				outParams.put("corpadmin","checked");
				break;
			case 10:
				outParams.put("corpreg","checked");
				break;
			}
			String corpID = corporateProfile.getCorporateID();
			String name = corporateProfile.getCorporateName();
			char nameArray[] = name.toCharArray();
			char corpIDArray[] = corpID.toCharArray();
			outParams.put("nameArray",name);
			outParams.put("corpIDArray",corpID);
			
			
			logger.info("showC10Form(HttpServletRequest request, HttpServletResponse response) ends");
			return new ModelAndView("rePrintc10Kit","model",outParams);
		}

		public BaseService getGeneratePPKITService() {
			return generatePPKITService;
		}

		public void setGeneratePPKITService(BaseService generatePPKITService) {
			this.generatePPKITService = generatePPKITService;
		}

		//5552 ends
		
		//Added for C7b form start
		public ModelAndView showC7bForm(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("showC7bForm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			String errorView=null;
			String c7bFlag="c7bView";
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER); 
	      	inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put("corporateID",user.getCorporateId());
			inputParams.put("flag",c7bFlag);
			outParams=generatePPKITService.execute(inputParams);
			outParams.put("userName", user.getUserAlias());
			logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("showC7bForm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("showc7blist","model",outParams);
		}
		
		
		
		public ModelAndView showC7bInterimForm(HttpServletRequest request,HttpServletResponse response)
		{
			logger.info("showC7bInterimForm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			String errorView=null;
			SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		    applicationResponse.setErrorStatus("SUCCESS");
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER); 
		    String empNo=request.getParameter("empNo");
	        request.setAttribute("empNo",empNo);
	        String name=request.getParameter("name");
	        String department=request.getParameter("department");
	        String designation=request.getParameter("designation");
	        String state=request.getParameter("state");
	        String city=request.getParameter("city");
	        String country=request.getParameter("country");
	        String ZIP=request.getParameter("ZIP");
	        String email=request.getParameter("email");
	        String address=request.getParameter("address");
	        String HOME_PHONE=request.getParameter("HOME_PHONE");
	        String referenceNo=request.getParameter("referenceNo");
			outParams.put("empNo", empNo);
			outParams.put("name", name);
			outParams.put("department", department);
			outParams.put("designation",designation);
			outParams.put("state", state);
			outParams.put("city", city);
			outParams.put("country",country);
			outParams.put("ZIP", ZIP);
			outParams.put("email", email);
			outParams.put("address", address);
			outParams.put("HOME_PHONE", HOME_PHONE);			
			outParams.put("referenceNo", referenceNo);			
			logger.info("Application response" +applicationResponse );
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
		    logger.info("showC7bInterimForm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
			return new ModelAndView("showc7binterim","model",outParams);
		}
		
		public ModelAndView printC7bForm(HttpServletRequest request, HttpServletResponse response) {
			logger.info("printC7bForm(HttpServletRequest request, HttpServletResponse response) begins");
			Map inputParams=new HashMap();
			Map outParams=new HashMap();
			String errorView=null;
			String referenceNo=request.getParameter("referenceNo");
			String formFlag="c7bPrint";
			SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		    applicationResponse.setErrorStatus("SUCCESS");
			HttpSession session = request.getSession(false);
			User user = (User) session.getAttribute(UIConstant.USER); 
			CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
			inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
			inputParams.put("corporateID",user.getCorporateId());
			inputParams.put("flag",formFlag);
			inputParams.put("ppID",referenceNo);
	       
			outParams=generatePPKITService.execute(inputParams);
			String corpID =corporateProfile.getCorporateID();
			String name =corporateProfile.getCorporateName();
			logger.info("corporateProfile" +corporateProfile);
			char nameArray[] = name.toCharArray();
			char corpIDArray[] = corpID.toCharArray();
//			outParams.put("nameArray",name);
//			outParams.put("corpIDArray",corpID);
//			outParams.put("ppID",ppID);
			
			outParams.put("referenceNo",referenceNo);
			outParams.put("corporateId",corpID);
			outParams.put("corporateName",name);
			
			logger.info("Application response" +applicationResponse );
		    outParams.put(UIConstant.ERROR_VIEW,errorView);
			
			logger.info("printC7bForm(HttpServletRequest request, HttpServletResponse response) ends");
			return new ModelAndView("printC7bForm","outParams",outParams);
		}
}
