
package com.sbi.common.handler;


import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.model.CompBenDataModel;


/**
 * TODO This class is used to display the datas into CSV format. 
 * @version 1.0
 * @author Tech Mahindra Ltd.,
 */
public class CompBenReverseFileConverter
{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	  public StringBuffer csvCompBenFileConverter(Map inputParams)
	    {
	logger.info("csvCompBenFileConverter(Map inputParams) begin with inputParams - Start"+inputParams);
	        
	        StringBuffer outBuffer = new StringBuffer();
	        String fileType = (String)inputParams.get("fileType");
	        CompBenDataModel[] compBenDataModel = null;
	        	StringBuffer detailsBuf = new StringBuffer();
	        	    detailsBuf.append("Beneficiary Name" + "\t");
	        		detailsBuf.append("Beneficiary Code" + "\t");
	        		detailsBuf.append("Status" + "\t");
	        		if(!"ABTP".equalsIgnoreCase(fileType)){
	        			detailsBuf.append("Account No." + "\t");	
	        		}
	        		if("ABTP".equalsIgnoreCase(fileType)){
	        			detailsBuf.append("AADDAR ID" + "\t");	
	        			detailsBuf.append("BANK IIN" + "\t");
	        		}
	        		if("IBTP".equalsIgnoreCase(fileType) || "DIBTP".equalsIgnoreCase(fileType) || "COMPOSITE_BEN".equalsIgnoreCase(fileType) ){
	        			detailsBuf.append("IFS Code" + "\t");	
	        		}
	        		if("COMPOSITE_BEN".equalsIgnoreCase(fileType) || "ABTP".equalsIgnoreCase(fileType)){
	        			detailsBuf.append("Beneficiary Type " + "\t");	
	        			detailsBuf.append("Beneficiary Action Type " + "\t");
	        			detailsBuf.append("Validation Status" + "\t");
	        			detailsBuf.append("Error Description" + "\t");	
	        		}
	        		outBuffer.append(detailsBuf + "\n");
			if(inputParams.get("approveBenRecordDetails") != null){
				compBenDataModel = (CompBenDataModel[]) inputParams.get("approveBenRecordDetails");
				logger.info("length of compBenDataModel   :::"+compBenDataModel.length);
	    		if(compBenDataModel != null && compBenDataModel.length >= 1){
	        		for (int i = 0; i < compBenDataModel.length; i++) {
	        			CompBenDataModel beneficiaryDetails = compBenDataModel[i];
	        			if(beneficiaryDetails != null){
	        				String name =beneficiaryDetails.getName() == null ? "-" : beneficiaryDetails.getName();
	        				String benCode = beneficiaryDetails.getOutRef7() == null ? "-" : beneficiaryDetails.getOutRef7();
	        				String AccountNo = beneficiaryDetails.getAccountNo()== null ? "-" : beneficiaryDetails.getAccountNo();
	        				String aadharId = beneficiaryDetails.getAadharId()== null ? "-" : beneficiaryDetails.getAadharId();
	        				Integer benStatusVal = beneficiaryDetails.getStatus();
	        				String status = null;
	        				if(benStatusVal == 0){
	        					status = "Pending for Approval";
	        				}else if(benStatusVal == 1){
	        					status = "Approved";
	        				}else if(benStatusVal == 2){
	        					status = "Rejected";
	        				}else {
	        					status = "-";
	        				}
	        				outBuffer.append(name+ "\t");
	        				outBuffer.append("'"+ benCode+ "\t");
	        				outBuffer.append(status+ "\t");
	        				if("IBTP".equalsIgnoreCase(fileType) || "DIBTP".equalsIgnoreCase(fileType)){
	        					outBuffer.append("'"+ AccountNo+ "\t");
			        			String ifsCode = beneficiaryDetails.getOutRef2() == null ? "-" : beneficiaryDetails.getOutRef2();
			        			outBuffer.append(ifsCode+ "\n");
	        				}else if("COMPOSITE_BEN".equalsIgnoreCase(fileType)){ 
			        			String ifsCode = beneficiaryDetails.getOutRef2() == null ? "-" : beneficiaryDetails.getOutRef2();
			        			String bankType = beneficiaryDetails.getBankType() == null ? "-" : beneficiaryDetails.getBankType();
	        					String actionType = beneficiaryDetails.getActionType() == null ? "-" : beneficiaryDetails.getActionType();
			        			String errorDesc = beneficiaryDetails.getOutRef1() == null ? "-" : beneficiaryDetails.getOutRef1();
			        			String valStatus = beneficiaryDetails.getValStatus() == null ? "-" : beneficiaryDetails.getValStatus();
	        					outBuffer.append("'"+ AccountNo+ "\t");
			        			outBuffer.append(ifsCode+ "\t");
            					outBuffer.append(bankType+ "\t");
		        				outBuffer.append(actionType+ "\t");
		        				outBuffer.append(valStatus+ "\t");
			        			outBuffer.append(errorDesc+ "\n");
	        				}else if("ABTP".equalsIgnoreCase(fileType)){ 
			        			String bankiin = beneficiaryDetails.getBankIIN() == null ? "-" : beneficiaryDetails.getBankIIN();
			        			String bankType = beneficiaryDetails.getBankType() == null ? "-" : beneficiaryDetails.getBankType();
	        					String actionType = beneficiaryDetails.getActionType() == null ? "-" : beneficiaryDetails.getActionType();
			        			String errorDesc = beneficiaryDetails.getOutRef1() == null ? "-" : beneficiaryDetails.getOutRef1();
			        			String valStatus = beneficiaryDetails.getValStatus() == null ? "-" : beneficiaryDetails.getValStatus();
	        					outBuffer.append("'"+ aadharId+ "\t");
			        			outBuffer.append(bankiin+ "\t");
            					outBuffer.append(bankType+ "\t");
		        				outBuffer.append(actionType+ "\t");
		        				outBuffer.append(valStatus+ "\t");
			        			outBuffer.append(errorDesc+ "\n");
	        				}
	        				else{
	        					outBuffer.append("'"+ AccountNo+ "\n");
	        				}
	        			}
					}
	        		
	        	} else {
	        		outBuffer.append("\t\t"+ "There are no Inter bank beneficiaries  for the selected file.");
	        	}
	        } else {
	    		outBuffer.append("\t\t"+ "There are no Inter bank beneficiaries for the selected file.");
	    	}
			outBuffer.append("\n");
			outBuffer.append("\n");
			outBuffer.append("\n");
		    logger.info("csvCompBenFileConverter(Map inputParams end, inputParams - end");
	        return outBuffer;
	    }
}