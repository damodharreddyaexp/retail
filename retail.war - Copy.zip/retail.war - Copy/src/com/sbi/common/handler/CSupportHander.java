
/*
 * CSupportHander.java
 * Created on Nov 15, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 15, 2006 MURUGAN K - Initial Creation

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.LinkDetails;
import com.sbi.common.model.Query;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LinkUtil;

public class CSupportHander extends MultiActionController{
  

	protected final Logger logger = Logger.getLogger(getClass());

    private BaseService supportlogonService;
    
    private JSTLConstants constants;

    private ReferenceDataCache referenceDataCache;
    
    private ResourceBundleMessageSource logonProperty;
    
    private BaseService corpProfileService;
    
    private String changeUserNameUrl;
    
    
    static Map<String,String> view;//CorpDynamicLink
    
    static Map<String,String> returnbankUrl;//CorpDynamicLink optimisation

	private LinkUtil linkUtil;// CorpDynamicLink

	private String corpRoles;// CorpDynamicLink optimisation

	private String moduleName;//CorpDynamicLink optimisation - added by Pons
	
	private Map<String, String> roleTypeMap;// CorpDynamicLink
  //CorpDynamicLink optimisation
    static{
		view = new HashMap<String, String>();
		view.put("supportsbbjlogin.htm",UIConstant.SBBJ_LOGIN_PAGE);
		view.put("supportsbhlogin.htm",UIConstant.SBH_LOGIN_PAGE);
		view.put("supportsbindorelogin.htm",UIConstant.SBINDORE_LOGIN_PAGE);
		view.put("supportsbmlogin.htm",UIConstant.SBM_LOGIN_PAGE);
		view.put("supportsbplogin.htm",UIConstant.SBP_LOGIN_PAGE);
		view.put("supportsbslogin.htm",UIConstant.SBS_LOGIN_PAGE);
		view.put("supportsbtlogin.htm",UIConstant.SBT_LOGIN_PAGE);
		view.put("0",UIConstant.LOGIN_PAGE);
		view.put("1",UIConstant.SBBJ_LOGIN_PAGE);
		view.put("2",UIConstant.SBH_LOGIN_PAGE);
		view.put("3",UIConstant.LOGIN_PAGE);//SBIInd Megrer
		view.put("4",UIConstant.SBM_LOGIN_PAGE);
		view.put("5",UIConstant.SBP_LOGIN_PAGE);
		view.put("6",UIConstant.LOGIN_PAGE);
		view.put("7",UIConstant.SBT_LOGIN_PAGE);
		
		returnbankUrl = new HashMap<String, String>();
		returnbankUrl.put("0","https://www.onlinesbi.com/");
		returnbankUrl.put("1","https://www.sbbjonline.com/");
		returnbankUrl.put("2","https://www.onlinesbh.com/");
		returnbankUrl.put("3","https://www.onlinesbi.com/");//SBIInd Megrer
		returnbankUrl.put("4","https://www.onlinesbm.com/");
		returnbankUrl.put("5","https://www.onlinesbp.com/");
		returnbankUrl.put("6","https://www.onlinesbi.com/");
		returnbankUrl.put("7","https://www.sbtonline.in/");
    }
   
    public ModelAndView logInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("Login page display");
       String merchant_code =  request.getParameter("merchant_code");
       String cbecredirect =  request.getParameter("cbecredirect");
       logger.info("cbecredirect  ::" + request.getParameter("merchant_code") );
       logger.info("merchant_code ::" + request.getParameter("merchant_code"));
       Map loginData = new HashMap();
       loginData.put("merchant_code", merchant_code);
       loginData.put("cbecredirect", cbecredirect);
       loginData.put("support",new String("CSLogin"));
       
       String url = request.getServletPath().substring(1);
        String returnView =view.get(url);
        if(returnView == null){
        	returnView= UIConstant.LOGIN_PAGE;
        }
        logger.info("return view in CSUpportHander  :"+view);
        logger.info("Login Data model " + loginData);
        return new ModelAndView(returnView,"loginModel",loginData);
    }

    public ModelAndView sessionTimeOut(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("Session time out");
        return new ModelAndView(UIConstant.SESSION_PAGE);

    }
    
    /**
     * Login page to mypage
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     *             ModelAndView
     */
    public ModelAndView logInSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("logInSubmit(HttpServletRequest request, HttpServletResponse response) in CSupportHandler method begin");
        ServletContext ctx = getServletContext();
        String bankCodeJsp = request.getHeader("BankCode");//(String)request.getParameter("bankCode");
        if(bankCodeJsp == null)
        	bankCodeJsp = "0";
    	if (ctx.getAttribute("objectsLoaded")==null) {
            /*ErrorDictionary records = ErrorDictionary.getExpInstance();
            HashMap wacErrorDictionary=records.getInstance();*/
            ctx.setAttribute(UIConstant.constants, constants);
            ctx.setAttribute(UIConstant.PRODUCT_DESCRIPTION, referenceDataCache
                    .getReferenceData(UIConstant.ACCOUNTNAME_KEY));
            ctx.setAttribute(UIConstant.COUNTRY_NAME, referenceDataCache
                      .getReferenceData(UIConstant.COUNTRY_NAME_CODE));
            ctx.setAttribute(UIConstant.TRANSACTION_LIMIT_MAP, referenceDataCache
                     .getReferenceData(UIConstant.TRANSACTION_LIMIT));
            ctx.setAttribute(UIConstant.BRANCH_NAME_CODE_MAP, referenceDataCache
                    .getReferenceData(UIConstant.BRANCH_DATA_KEY));
           // ctx.setAttribute("wacErrorDictionary", wacErrorDictionary );
            ctx.setAttribute("objectsLoaded", "YES");
        }
    	//String moduleName=getModuleName(request);
	    String contextRoles[] = corpRoles.split("\\|");
	    if (ctx.getAttribute("linksLoaded" + bankCodeJsp) == null) {
	    	for (int i = 0; i < contextRoles.length; i++) {
				logger.info(contextRoles.length);
				logger.info("contextRoles[" + i + "]" + contextRoles[i]);
				logger.info("roleTypeMap :" + roleTypeMap);
				String contextType = roleTypeMap.get(contextRoles[i]);
				logger.info("contextType :"+contextType);
				String contextTypes[] = contextType.split("\\|");
				for (int j = 0; j < contextTypes.length; j++) {
					Map<String, Object> links = linkUtil.getLinkDetails(contextRoles[i], contextTypes[j], bankCodeJsp,moduleName);
					List<LinkDetails> tabs = (List<LinkDetails>) links.get("tabs");
					List<String> queryIds = (List<String>) links.get("queryIds");
					links.remove("tabs");
					links.remove("queryIds");
					ctx.setAttribute("links" + bankCodeJsp + contextRoles[i]+ contextTypes[j], links);
					ctx.setAttribute("tabs" + bankCodeJsp + contextRoles[i]+ contextTypes[j], tabs);
					ctx.setAttribute("queryIds" + bankCodeJsp + contextRoles[i]+ contextTypes[j], queryIds);
				}
			}
	    	ctx.setAttribute("queries", linkUtil.getQueries());
	    	ctx.setAttribute("linksLoaded" + bankCodeJsp, "YES");
		}
    	
        /*String userIPaddress = request.getHeader("ClientIPAddress");
        logger.info("IP " + userIPaddress);*/
    	//String userIPaddress = request.getRemoteAddr();
	  //Shanta
        String userIPaddress = request.getHeader("ClientIP"); 
        logger.info("Client IP from header : " + userIPaddress); 
       
        //shanta
        logger.info("IP " + userIPaddress);
        Map outParams = new HashMap();
        logger.info("handleRequest(HttpServletRequest req, HttpServletResponse res) begin");
        String userName = request.getParameter(UIConstant.USER_NAME);
        String password = request.getParameter(UIConstant.PASSWORD);
        String firstTimeLoign = (String) request.getParameter("firstTimeLogin"); 
        Map inputParams = new HashMap();
        inputParams.put(UIConstant.BANK_CODE,bankCodeJsp);
        inputParams.put(UIConstant.USER_NAME, userName);
        inputParams.put(UIConstant.PASSWORD, password);
        inputParams.put(UIConstant.IP_ADDRESS, userIPaddress);
        inputParams.put("keyid",request.getParameter("keyid"));
        inputParams.put("firstTimeLoginStatus", firstTimeLoign);
        logger.info("Map details  :" + "userName:"+userName+"password :"+password+"userIPaddress : "+userIPaddress+"key id :"+request.getParameter("keyid"));
        
        String return_view = view.get(bankCodeJsp);
        logger.info("return view"+return_view);
        if (userName != null && userName.trim() != "" && password != null && password.trim() != "") {
            outParams = (Map) supportlogonService.execute(inputParams);
            Map inParam = new HashMap();
            logger.info("Object from service = " + outParams);
            SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams
                    .get(UIConstant.APPLICATION_RESPONSE);
            logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
            logger.info("Error status" + errorResponse.getErrorStatus());
            logger.info("Error code" + errorResponse.getErrorCode());
            logger.info("Error message" + errorResponse.getErrorMessage());
           
            if (outParams.get("profile") != null) {
                logger.info("Returned to UIConstant.MY_PAGE with UserName");
                logger.info("handleRequest(HttpServletRequest req, HttpServletResponse res) end");
                UserProfile userProfile = (UserProfile) outParams.get("profile");
                String displayName = (String) outParams.get(UIConstant.DISPLAY_NAME);
                int loginCount =userProfile.getLoginCount().intValue();
                HttpSession session = request.getSession(true);
                session.setAttribute(UIConstant.USER, userProfile);
                session.setAttribute(UIConstant.DISPLAY_NAME, displayName);
                session.setAttribute(UIConstant.LAST_TXN,userProfile.getLastTnameInternet());
                session.setAttribute(UIConstant.LAST_LOGIN_DATE,userProfile.getLastLoginDate());
                session.setAttribute(UIConstant.LAST_TXN_DATE,userProfile.getLastTDateInternet());
				inParam.put(UIConstant.USER,userProfile);;
                if(loginCount <=0 ){
                    logger.info("First time user login:");
                    response.sendRedirect(returnbankUrl.get(bankCodeJsp) + changeUserNameUrl);
                }
                else{
                	Map outParam  = corpProfileService.execute(inParam);
                	CorporateProfile corporateProfile = (CorporateProfile) outParam.get("corp_profile");
                	session.setAttribute("corp_profile",corporateProfile);
                    session.setAttribute("merchant_code", request.getParameter("merchant_code"));
                    session.setAttribute("cbecredirect", request.getParameter("cbecredirect"));
                    logger.info("cbecredirect  ::" + request.getParameter("merchant_code") );
                    logger.info("merchant_code ::" + request.getParameter("merchant_code"));
                    logger.info("Corp Profile object in Session:   "  + session.getAttribute("corp_profile"));
                    Integer userRole = (Integer) userProfile.getRoles().get(0);
                    String urlName = "role"+ userRole.toString();
                    if(userRole.intValue()==8)
                    	urlName = "role" + userRole.toString() + "." + userProfile.getUserType();
                    
                    List<String> queryIds = (List<String>)ctx.getAttribute("queryIds"+ bankCodeJsp + 
                    		userProfile.getRoles().get(0)+ userProfile.getUserType());
                    Map<String, Query> queries = (Map<String, Query>)ctx.getAttribute("queries");
                    if(queryIds != null && queryIds.size()>0){
                    	Map<String, String> queryValues = linkUtil.getQueryValues(queryIds, queries,userProfile,corporateProfile);
                    	session.removeAttribute("queryValues");
                    	session.setAttribute("queryValues", queryValues);
                    }
				    String url = logonProperty.getMessage(urlName,null,null);
                    response.sendRedirect(returnbankUrl.get(bankCodeJsp) + url);
                    return null;
                }
                outParams.put(UIConstant.ERROR_VIEW, return_view);
                outParams.put("bankCode",bankCodeJsp);
            }
            else {
                logger.info("Returned to Login Page with Error");
                logger.info("handleRequest(HttpServletRequest req, HttpServletResponse res) end");
                return new ModelAndView(return_view,UIConstant.ERROR_MODEL, outParams);
            }

        }
        logger.info("logInSubmit(HttpServletRequest request, HttpServletResponse response) in CSupportHandler method End");
        return new ModelAndView(UIConstant.LOGIN_PAGE, UIConstant.SUCCESS, outParams);
    }
    /**
     * Logout page
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     *             ModelAndView
     */
    public ModelAndView logOutHandler(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("Logout Page begins ");
        HttpSession session = request.getSession(false);
        if(session != null)
            session.invalidate();
        logger.info("Logout Page ends ");
        return new ModelAndView("logoutLayout");

    }
    /**
     * 
     * @param logonService
     *            void
     */
    

    /**
     * @param jstlConstants
     *            The jstlConstants to set.
     */
    public void setConstants(JSTLConstants constants) {
        this.constants = constants;
    } 

    /**
     * @param referenceDataCache
     *            The referenceDataCache to set.
     */
    public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
        this.referenceDataCache = referenceDataCache;
    }
    /**
     * @param logonProperty The logonProperty to set.
     */
    public void setLogonProperty(ResourceBundleMessageSource logonProperty)
    {
        this.logonProperty = logonProperty;
    }

	public void setChangeUserNameUrl(String changeUserNameUrl) {
        this.changeUserNameUrl = changeUserNameUrl;
    }

	public void setCorpProfileService(BaseService corpProfileService) {
		this.corpProfileService = corpProfileService;
	}

	public void setSupportlogonService(BaseService supportlogonService) {
		this.supportlogonService = supportlogonService;
	} 
	
	 public static String getModuleName(HttpServletRequest request) {
		String contextpath = request.getContextPath().substring(1);
		return contextpath;
	}

	public void setLinkUtil(LinkUtil linkUtil) {
		this.linkUtil = linkUtil;
	}

	public void setCorpRoles(String corpRoles) {
		this.corpRoles = corpRoles;
	}

	public void setRoleTypeMap(Map<String, String> roleTypeMap) {
		this.roleTypeMap = roleTypeMap;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
    
}
