package com.sbi.common.handler;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;

public class LockAccountHandler extends MultiActionController{
	private final Logger logger=Logger.getLogger(getClass());
	private BaseService lockAccountDisplayService;
	private BaseService lockAccountConfirmService;



	public ModelAndView lockAccountInputDetails(HttpServletRequest request,HttpServletResponse response){
		Map outParam=new HashMap();
		Map inParam=new HashMap();
		SBIApplicationResponse appResopnse=new SBIApplicationResponse();
		outParam = lockAccountDisplayService.execute(inParam);
		appResopnse.setErrorStatus(UIConstant.SUCCESS);
		outParam.put(UIConstant.BANK_CODE,request.getParameter(UIConstant.BANK_CODE));
		outParam.put(UIConstant.APPLICATION_RESPONSE,appResopnse);
		logger.info("bank code"+request.getParameter(UIConstant.BANK_CODE));
		return new ModelAndView("lockAccountDisplay",UIConstant.OUTPARAM,outParam);
	}
	
	/**
	 * @param request
	 * @param response
	 * @return null
	 */
	public ModelAndView lockAccountCaptcha(HttpServletRequest request, HttpServletResponse response) {
		logger.info("lockAccountCaptcha - method begins");
		int width = 100;
		int height = 35;
		Random rdm = new Random();
		int rl = rdm.nextInt();
		String hash1 = Integer.toHexString(rl);
		String capstr = hash1.substring(0, 5);
		capstr = capstr.toUpperCase();

		HttpSession session = request.getSession(true);
		session.setAttribute("captchaImage", capstr);
		Color background = new Color(215, 255, 245);
		Color fbl = new Color(0, 0, 0);
		Font fnt = new Font("Lucida Calligraphy", 1, 18);
		BufferedImage cpimg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics g = cpimg.createGraphics();
		g.setColor(background);
		g.fillRect(1,1,width-2,height-2);
		g.setColor(fbl);
		g.setFont(fnt);
		g.drawString(capstr,10,25);
		g.setColor(background);
		//g.drawLine(10,17,80,17);
		//g.drawLine(10,22,80,22);
		try {
			response.setContentType("image/jpeg");
			OutputStream strm = response.getOutputStream();
			ImageIO.write(cpimg,"jpeg",strm);
			strm.close();
		} catch (Exception e) {
			logger.error("Unable to load captcha image", e);
		}
		logger.info("lockAccountCaptcha - method ends");
		return null;
	}
	
	
	public ModelAndView lockAccountConfirmDetails(HttpServletRequest request,HttpServletResponse response){
		
		Map outParam=new HashMap();
		Map inParam=new HashMap();
		SBIApplicationResponse appResopnse=new SBIApplicationResponse();
		
		String mobileNo=null;
		String corporateID =request.getParameter("corporateID");
		String userName =request.getParameter("name");
		String countryCode =request.getParameter("country_Code1");
		String txtMobileNumber =request.getParameter("txtMobileNumber");
		String bankCode =request.getParameter("bankCode");
		
		String view = null;
		
		String captchaValue = request.getParameter("captchaValue");
		HttpSession session = request.getSession(false);
		String captchaImage = (String)session.getAttribute("captchaImage");
		logger.info("captchaValueFromJsp : " + captchaValue + " captchaImage : " + captchaImage);
		if (captchaValue.equals(captchaImage)) {
		session.removeAttribute("captchaImage");
		logger.info("userName::"+userName+"corporateID::"+corporateID+"countryCode::"+countryCode+"txtMobileNumber::"+txtMobileNumber);
		if(countryCode.length()>0 && !countryCode.equals("")&& txtMobileNumber.length()>0 && !txtMobileNumber.equals(""))
		{
			mobileNo=countryCode+"|"+txtMobileNumber;
			logger.info("mobileNo::::"+mobileNo);
		}
		
		inParam.put("corporateID",corporateID);
		inParam.put("userName",userName);
		inParam.put("mobileNo",mobileNo);
		inParam.put("bankCode",bankCode);
		outParam = lockAccountConfirmService.execute(inParam);
		logger.info("lockAccountConfirmService::::"+outParam.get("lockAccountConfirmCount"));
		
		Map lock = (Map) outParam.get("lockAccountCount");
		Integer lockAccountConfirmCount =(Integer)lock.get("lockAccountConfirmCount");
		String errorCode =(String)lock.get("errorCode");
		String reference =(String)lock.get("reference_no");
		if(lockAccountConfirmCount!=null && lockAccountConfirmCount == 1){
			view = "lockAccountConfirmDisplay";
			outParam.put("reference",reference);
				
		}
		else
			view ="lockAccountError";
		//outParam.put("reference_no",outParam.get("reference_no"));
		logger.info("reference:"+reference);
		outParam.put("view",view);
		outParam.put("bankCode",bankCode);
		logger.info("outParam in handler"+outParam);
		return new ModelAndView(view,UIConstant.OUTPARAM,outParam);
		} else {
			session.removeAttribute("captchaImage");
			view ="lockAccountError";
			outParam.put("view",view);
			outParam.put("bankCode",bankCode);
			
			appResopnse.setErrorStatus(ServiceConstant.FAILURE);
			appResopnse.setErrorCode(ServiceConstant.LA001);
			outParam.put(ServiceConstant.APPLICATION_RESPONSE,appResopnse);
			return new ModelAndView(view,UIConstant.OUTPARAM,outParam);
		}
		
		
		
	}
	
	/**
	 * @param lockAccountDisplayService the lockAccountDisplayService to set
	 */
	public void setLockAccountDisplayService(BaseService lockAccountDisplayService) {
		this.lockAccountDisplayService = lockAccountDisplayService;
	}
	
	/**
	 * @param lockAccountConfirmService the lockAccountConfirmService to set
	 */
	public void setLockAccountConfirmService(BaseService lockAccountConfirmService) {
		this.lockAccountConfirmService = lockAccountConfirmService;
	}
	

}
