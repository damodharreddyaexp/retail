package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Address;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;

public class RegisterMobileNoHandler extends MultiActionController {
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	private BaseService registerMobileNoService;
	
	


	public ModelAndView registerMobileNoDisplay(HttpServletRequest request,HttpServletResponse response) {
		logger.info("registerMobileNoDisplay(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		
		RegMobileNoDetails regMobileNoDetails = null ;
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	    String oldMobileNo = profile.getMobileNumber();
	    String countryCode = profile.getCountryCode();
	    int userId = profile.getUserId();
	    String splitMobileNo="";
	    
		if(oldMobileNo != null){
			int length= oldMobileNo.length() - 3;
	    	splitMobileNo = oldMobileNo.substring(length);
	    	
	    }
	  
	    Map outParams = new HashMap();
		outParams.put("userId", userId);
		outParams.put("oldMobileNo", splitMobileNo);
		outParams.put("mobileNumber", oldMobileNo);
		outParams.put("countryCode", countryCode);
		request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "RMN");
		outParams.put("regMobileNoDetails", regMobileNoDetails);
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);		
		applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);
		logger.info("Error Status " + applicationResponse.getErrorStatus());

		logger.info("registerMobileNoDisplay(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("registerMobileNo", "outParams",outParams);

	}
	                
	
	public ModelAndView registerMobileConfirm(HttpServletRequest request,HttpServletResponse response) {
		logger.info("registerMobileConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		 HttpSession session = request.getSession(false);
	     UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	     RegMobileNoDetails   regMobileNoDetails = new RegMobileNoDetails();
	     Integer userId = profile.getUserId();
	     String contryCode = request.getParameter("countryCode");
	     String mobileNo = request.getParameter("mobileNo");
	     String oldMobileNo =profile.getMobileNumber();
	     String modifyUser =profile.getUserName();
	     String branchCode=profile.getBranchCode();
	     Integer userRole = (Integer) profile.getRoles().get(0);
	     //String friendlyName = profile.getFriendlyName();
	     String friendlyName = profile.getName();
	     String cororateId = profile.getCorporateId();
	     String userAlias = profile.getUserAlias();
	     String empNo=profile.getEmpNo();
	     logger.info("userId :"+userId+"contryCode :"+contryCode+"mobileNo :"+mobileNo+"oldMobileNo :"+oldMobileNo+"userRole :"+userRole);
		logger.info("Mobile No lenth:"+mobileNo.length());
			Map inParams = new HashMap();
			inParams.put("contryCode", contryCode);
			inParams.put("mobileNo", mobileNo);
			inParams.put("userId", userId);
			inParams.put("oldMobileNo",oldMobileNo);;
			inParams.put("modifyUser",modifyUser);
			inParams.put("branchCode",branchCode);
			inParams.put("userRole",userRole);
			inParams.put("cororateId", cororateId);
			inParams.put("userAlias", userAlias);
			inParams.put("friendlyName", friendlyName);
		
		Map outParams = new HashMap();
		
		outParams = registerMobileNoService.execute(inParams);
		SBIApplicationResponse applicationResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		
		if(applicationResponse.getErrorStatus().equalsIgnoreCase("success"))
		{
		regMobileNoDetails =(RegMobileNoDetails)outParams.get("regMobileNoDetails");
		session.setAttribute("referenceNo", regMobileNoDetails.getReferenceNo());
		session.setAttribute("newMobileNo", mobileNo);
		session.setAttribute("contryCode", contryCode);
		session.setAttribute("empNo", empNo);
 		session.setAttribute("friendlyName", friendlyName);
 		session.setAttribute("createdUserRole",regMobileNoDetails.getUserRole());
		}
		logger.info("#################"+session.getAttribute("createdUserRole"));
		logger.info("Error Status " + applicationResponse.getErrorStatus());
		
		logger.info("registerMobileConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("registerMobileNoConfirm", "outParams",outParams);

	}

	
	public ModelAndView showregisterMobileNoForm(HttpServletRequest request,HttpServletResponse response) {
		logger.info("showregisterMobileNoForm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
	
		 RegMobileNoDetails regMobileNoDetails = null ;
		 HttpSession session = request.getSession(false);
	     UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	     CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	     	String mobileNo =(String) session.getAttribute("newMobileNo");
			String corporateId = profile.getCorporateId();
			String corporateName = corporateProfile.getCorporateName();
			//char mobileNoArray[] = mobileNo.toCharArray();
			String reffNo =(String) session.getAttribute("referenceNo");
			String contryCode =(String)session.getAttribute("contryCode");
	 	String friendlyName = (String) session.getAttribute("friendlyName");
		String empNo = (String) session.getAttribute("empNo");
		String createdUserRole = (String) session.getAttribute("createdUserRole");
		logger.info("friendlyName :::"+friendlyName);
		logger.info("empNo :::"+empNo);
		logger.info("createdUserRole :::"+createdUserRole);
		logger.info("NAME  :::"+profile.getName());
	      logger.info("corporateId>>"+corporateId);
	      logger.info("corporateName>>>"+corporateName);
	      logger.info("reffNo >>>"+reffNo);
	      logger.info("friendlyName >>>"+friendlyName);
	      logger.info("profile.getName() >>>"+profile.getName());
	     
		Map outParams = new HashMap();
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);	
		outParams.put("mobileNo",contryCode+"|"+mobileNo);
		outParams.put("referenceNo",reffNo);
		outParams.put("corporateId",corporateId);
		outParams.put("corporateName",corporateName);
		
		
		if(createdUserRole.equalsIgnoreCase("10") ||createdUserRole.equalsIgnoreCase("7") || createdUserRole.equalsIgnoreCase("21")){
		outParams.put("friendlyName",profile.getName());
		}else{
			outParams.put("friendlyName",friendlyName);
		}
		outParams.put("empNo", empNo);
		outParams.put("createdUserRole", createdUserRole);
	
		applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);

		logger.info("showregisterMobileNoForm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("showRegisterMobileNoForm", "outParams",outParams);

	}
	
	//Added for show cinb c9 form -Start
	public ModelAndView showCINBC9Form(HttpServletRequest request,HttpServletResponse response) {
		logger.info("showCINBC9Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);

		RegMobileNoDetails regMobileNoDetails = null ;
		HttpSession session = request.getSession(false);
		UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
 
		String mobileNo =(String) request.getParameter("newMobileNo");
		String corporateId = profile.getCorporateId();
		String corporateName = corporateProfile.getCorporateName();
		String reffNo =(String) request.getParameter("referenceNo");
		String friendlyName = profile.getFriendlyName();
		Integer userRole = (Integer) profile.getRoles().get(0);
		
		Map outParams = new HashMap();
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);	
		outParams.put("mobileNo",mobileNo);
		outParams.put("referenceNo",reffNo);
		outParams.put("corporateId",corporateId);
		outParams.put("corporateName",corporateName);
		outParams.put("friendlyName",friendlyName);
		outParams.put("empNo",profile.getEmpNo());
		outParams.put("createdUserRole", userRole);
		
		applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);
		
		logger.info("showCINBC9Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("showRegisterMobileNoForm", "outParams",outParams);

	}
	//Added for show cinb c9 form -End
	
	public void setRegisterMobileNoService(BaseService registerMobileNoService) {
		this.registerMobileNoService = registerMobileNoService;
	}
}
