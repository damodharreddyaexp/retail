package com.sbi.common.handler;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.FilesDownloadUtils;

public class IcollectHandler extends MultiActionController{
	protected static Logger logger = Logger.getLogger(IcollectHandler.class);
	
	BaseService getIcollectCategoryService;
	
	BaseService downloadIcollectReportsService;
	
	BaseService getIcollectReportService;
	
	FilesDownloadUtils fileDownloadutils;


	public ModelAndView icollectReportDisplay(HttpServletRequest request,HttpServletResponse response){
		logger.info("icollectReportDisplay(request,response) method begins");
		Map inParams = new HashMap();
	    Map outParams = new HashMap();
	    HttpSession session = request.getSession(false);
	    User user = (User) session.getAttribute(UIConstant.USER);
	    inParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
	    inParams.put(UIConstant.USER_NAME , user.getUserAlias());
	    outParams = getIcollectCategoryService.execute(inParams);
	    outParams.put(UIConstant.ERROR_VIEW, "commonerror");
	    logger.info("icollectReportDisplay(request,response) method ends");
		return new ModelAndView("icollectReportDisplay","outParams",outParams);
	}
	
	public ModelAndView icollectReportsDownload(HttpServletRequest request, HttpServletResponse response) {
		logger.info("icollectReportsDownload(HttpServletRequest request, HttpServletResponse response)-begin");
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		outputParams.put(UIConstant.ERROR_VIEW, "commonerror");
		HttpSession session=request.getSession(false);
		User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String userName = user.getUserAlias();
		String categoryID = request.getParameter("categoryID");
		String startDate = request.getParameter("fromDate");
		String endDate = request.getParameter("toDate");
		String fileType = request.getParameter("fileType");
		//added for payment mode
		String paymentmode = request.getParameter("paymentMode");
		//added for reconreport 
		String accountNo = request.getParameter("accountNO");
		String reportType = request.getParameter("reportType");
		String singleDate	=	request.getParameter("sdate");
		if(startDate == null || startDate.equals(""))
			startDate = singleDate;
		
		logger.info("startDate.."+startDate +"endDate.."+endDate + " categoryID="+categoryID+ "paymentmode" +paymentmode+" ; accpuntNo :"+accountNo+" ;reportType :"+reportType);
		inputParams.put("categoryID", categoryID);
		inputParams.put("startDate", startDate);
		inputParams.put("endDate", endDate);
		inputParams.put("fileType",fileType);
		inputParams.put("userName", userName);
		//added for payment mode
		inputParams.put("paymentmode", paymentmode);
		inputParams.put("corporateId", corporateId); // All category report
		
		inputParams.put("accountNo", accountNo);
		inputParams.put("reportType", reportType);
		
		String fileName = categoryID+"_"+startDate+"_"+endDate+"_"+paymentmode+"."+fileType;
		outputParams = downloadIcollectReportsService.execute(inputParams);
		/*StringBuffer filecontent = (StringBuffer) outputParams.get("filecontent");
		try{
				if("xls".equalsIgnoreCase(fileType)){
          			fileDownloadutils.downloadMsExcel(fileName, response, filecontent);
          		}else if("csv".equalsIgnoreCase(fileType)){
          			fileDownloadutils.downloadCsv(fileName, response, filecontent);
          		}else{
          			fileDownloadutils.downloadTextPlain(fileName, response, filecontent);

          		}
			}catch(Exception e){
				logger.error("Unable to generate File");
			}*/
		logger.info("icollectReportsDownload(HttpServletRequest request, HttpServletResponse response)-end");
		return new ModelAndView("icollectReportConfirm","outParams",outputParams);
	}
	
	public ModelAndView icollectReportsDownloadconfirm(HttpServletRequest request,HttpServletResponse response){
		logger.info("icollectReportDisplay(request,response) method begins");
		Map inputParams = new HashMap();
	    Map outParams = new HashMap();
	    HttpSession session = request.getSession(false);
	    User user = (User) session.getAttribute(UIConstant.USER);
	    String userName = user.getUserAlias();
	    inputParams.put("userName", userName);
	    outParams = getIcollectReportService.execute(inputParams);
	    outParams.put(UIConstant.ERROR_VIEW, "commonerror");
	    logger.info("icollectReportDisplay(request,response) method ends");
		return new ModelAndView("icollectReportDownload","outParams",outParams);
	}
	
	public ModelAndView icollectfildownload(HttpServletRequest request, HttpServletResponse response) throws ParseException{
		ModelAndView  modelView = null;
		boolean fileExists = false;
		Map inParams = new HashMap();
		Map outParams = new HashMap();
        logger.info("icollectfildownload(HttpServletRequest request,HttpServletResponse response) method begin");
        String fileType = (String) request.getParameter("fileType");
        String fileName = (String) request.getParameter("requestId");
        try{
				String fullfileName = fileName +"."+ fileType;
				logger.info("fileName::" + fullfileName);
				/*String downloadPath="D:/";*/
				String downloadPath="/data/reports/reconreport/";
				String filePath = downloadPath+ fullfileName;
				logger.info("filePath :" + filePath);
				response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
				byte[] chars = new byte[in.available()];
				in.read(chars);
				in.close();
				response.setHeader("Content-disposition",
						"attachment;filename=" + fullfileName);
				logger.info("response.getOutputStream()::"
						+ response.getOutputStream());
				OutputStream outputStream = response.getOutputStream();
				outputStream.write(chars);
				outputStream.flush();
				outputStream.close();
			} catch (Exception e) {				
				e.printStackTrace();

			}
       	return null;
    }
	public void setGetIcollectCategoryService(BaseService getIcollectCategoryService) {
		this.getIcollectCategoryService = getIcollectCategoryService;
	}
	public void setDownloadIcollectReportsService(
			BaseService downloadIcollectReportsService) {
		this.downloadIcollectReportsService = downloadIcollectReportsService;
	}
	public void setFileDownloadutils(FilesDownloadUtils fileDownloadutils) {
		this.fileDownloadutils = fileDownloadutils;
	}
	public void setGetIcollectReportService(BaseService getIcollectReportService) {
		this.getIcollectReportService = getIcollectReportService;
	}
}
