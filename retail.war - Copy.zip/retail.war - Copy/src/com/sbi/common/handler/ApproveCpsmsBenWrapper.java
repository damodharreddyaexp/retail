/**ApproveCpsmsBenWrapper.java
 * Created on Jan '08 by Treesa for RTGS 3P Upload
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */
package com.sbi.common.handler;

import org.displaytag.decorator.TableDecorator;

import com.sbi.common.model.CorporateFile;
import com.sbi.common.model.CpsmsBeneficiary;
import com.sbi.common.rtgs.model.CorporateTP;

public class ApproveCpsmsBenWrapper extends TableDecorator
{       
    /**
     * 
     * TODO This method is used to provide the hyperlink for the file name displayed.
     * @return String
     */
public String getFileName()
{
    CorporateFile corporateFile=  (CorporateFile) super.getCurrentRowObject();          
    String fileName="&nbsp;";    
    if(corporateFile!= null)
    {
        //fileName="<a href=\"javaScript:submitApproveBulkThirdPartisForm('"+ corporateFile.getFileName() +"','"+ corporateFile.getBankType() +"','"+corporateFile.getFunctionType()+"');\" onMouseOver=\"statusChange();return true;\">" + corporateFile.getFileName()+" </a>";
    	fileName="<a href=\"javaScript:submitApproveBenFilenameForm('"+ corporateFile.getSno()+ "','"+corporateFile.getFileName()+"');\" onMouseOver=\"statusChange();return true;\">" + corporateFile.getFileName()+" </a>";
    }
    return fileName;
} 

public String getOutRef7()
{
    
	CpsmsBeneficiary corporateFile=  (CpsmsBeneficiary)super.getCurrentRowObject();          
	String outRef7="&nbsp;";    

    outRef7="<input id='check'  name='check' type='checkbox' value=\"'" +corporateFile.getOid() +"',\">";
    outRef7=  outRef7+"<input type='hidden' name='rec_selected' id='rec_selected' value='True'>";

    return outRef7;
}   
//added for default file config to show the status of the file
public String getStatus()
{
    
	CpsmsBeneficiary corporateFile=  (CpsmsBeneficiary)super.getCurrentRowObject();          

String status=corporateFile.getStatus().toString();

if(status.equalsIgnoreCase("0"))
{
    
    
    
	status=  "Pending for Approval";
   
    
}
else if(status.equalsIgnoreCase("1"))
{
    
	status=  "Active";
}
else if(status.equalsIgnoreCase("2"))
{
    
	status=  "Rejected";
}

return status;
}
 
public String getAccountNo(){
	CpsmsBeneficiary corporateFile=  (CpsmsBeneficiary)super.getCurrentRowObject();
	String accountNo=corporateFile.getAccountNo().toString();
	System.out.print("Account No Wrappper : " +accountNo);
	if(accountNo!=null){
		accountNo.trim();
		if(accountNo.equals("0")){
			accountNo="-";
			System.out.print(" Inside if accountNo : " +accountNo);
	}
	}
	return accountNo;
}

public String getBranchCode(){
	

	CpsmsBeneficiary corporateFile=  (CpsmsBeneficiary)super.getCurrentRowObject();
	String branchCode="";
	if(corporateFile.getBranchCode()!=null){
	 branchCode=corporateFile.getBranchCode().toString();
	branchCode.trim();
	System.out.print("BranchCodeWrappper : "+branchCode);
		if(branchCode.equals("0")){
			branchCode="-";
			System.out.print(" Inside if branchCode : "+ branchCode);
		}
	}
	return branchCode;
}

public String getIfscCode(){
	CpsmsBeneficiary corporateFile=  (CpsmsBeneficiary)super.getCurrentRowObject();
	String ifscCode="";
	if(corporateFile.getIfscCode()!=null){
	 ifscCode=corporateFile.getIfscCode().toString();
	 System.out.print("IfscCodeWrapper : "+ifscCode);
	ifscCode.trim();
		if(ifscCode.equals("0")){
			ifscCode="-";
			System.out.print(" Inside if ifscCode : " +ifscCode);
		}
	}
	return ifscCode;
}


}
    