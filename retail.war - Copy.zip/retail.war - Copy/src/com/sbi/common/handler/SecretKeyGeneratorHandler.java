package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.sbi.common.service.BaseService;


public class SecretKeyGeneratorHandler implements Controller {
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	private BaseService secretKeyGeneratorService;	
	

	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
        logger.info("generateKey"+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inParams = new HashMap();        
        
        outParams = secretKeyGeneratorService.execute(inParams);        
        
        //outParams.put(UIConstant.ERROR_VIEW, "errorLoginView");
        return new ModelAndView("secretLoginView", "secretKeyModel", outParams);
	}

	public void setSecretKeyGeneratorService(BaseService secretKeyGeneratorService) {
		this.secretKeyGeneratorService = secretKeyGeneratorService;
	} 

}
