package com.sbi.common.handler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.model.EchequeDetails;

public class MISTransactionReportHandler extends MultiActionController{
	
	

	private BaseService viewReportInExcelService;
	
	private BaseService viewPendingTransactionService;
	 private String reportFilePath;


	private BaseService transactionReportService;
	
	//added by Damodar for Account Based MIS Report
	private BaseService misTransactionReportService;
	
	
	public void setMisTransactionReportService(
			BaseService misTransactionReportService) {
		this.misTransactionReportService = misTransactionReportService;
	}
	
	public void setViewPendingTransactionService(
			BaseService viewPendingTransactionService) {
		this.viewPendingTransactionService = viewPendingTransactionService;
	}
	public void setViewReportInExcelService(BaseService viewReportInExcelService) {
		this.viewReportInExcelService = viewReportInExcelService;
	}

	private BaseService failureTxnService;	
	
	private ReferenceDataCache referenceDataCache;
	 public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}

	
	
	private Logger logger = Logger.getLogger(getClass());
	   
    //added by Damodar for Account based MIS with starts

    public ModelAndView MISreportExcelDisplay(HttpServletRequest request,HttpServletResponse response) {
		logger.info("MISreportExcelDisplay() method begins");
		
		Map inParam = new HashMap();
        Map outParam = new HashMap();
        HttpSession session = request.getSession(false);
        String url= request.getServletPath().substring(1);
        String tilesView = "";
        String errorView = "";
        String type = "";
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        String bankCode 	= user.getBankCode();
        ServletContext context = getServletContext();
        String[] productType = null;
        
        tilesView="accountStatementNew";
		//errorView = UIConstant.errorQuerybyeCheque;
        //outParam.put(UIConstant.ERROR_VIEW, "errorQuerybyeCheque");
        
        inParam.put(UIConstant.PRODUCT_TYPE,productType);
        inParam.put(UIConstant.ACCESS_LEVEL,"5"); // Change access level  6 to 7.
        inParam.put(UIConstant.USER_NAME, user.getUserAlias());
        inParam.put(UIConstant.BANK_SYSTEM,UIConstant.ALL);
        inParam.put(UIConstant.BANK_CODE,bankCode);
        inParam.put(UIConstant.CORPORATE_ID,user.getCorporateId());
        inParam.put("type", "acct");
        inParam.put("loginUserRole",((Integer)user.getRoles().get(0)));
        logger.info("Inparam :  " + inParam);
        /*if(!url.equalsIgnoreCase("accountstatementnew.htm"))
        	outParam = getAccountService.execute(inParam);
        else*/
        	
        outParam = misTransactionReportService.execute(inParam);
        
        outParam.put(UIConstant.ERROR_VIEW, "errorQuerybyeCheque");
        outParam.put(UIConstant.CORPORATE_ID,user.getCorporateId());
        outParam.put("type",type);
        // Added by Damodhar for Account Based MIS Refresh page with starts
        session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
        // Added by Damodhar for Account Based MIS Refresh page with ends
		logger.info("MISreportExcelDisplay() method end");
		return new ModelAndView("misreportExcel", UIConstant.ACCOUNT_MODEL,outParam);
		
    }
    
    
    public ModelAndView insertLPRandRequestID(HttpServletRequest request,
    		HttpServletResponse response) {
    	        logger.info("InsertLPRandRequestID() method begins");
    	        SBIApplicationResponse applnresponse=new SBIApplicationResponse();
    	        String context=request.getContextPath();
    	        String userRole;
    	        userRole=(context.equalsIgnoreCase("corpuser")?"8":"21");
    	        Map inparam = new HashMap();
    	        Map outputParams = new HashMap();
    	        HttpSession session = request.getSession(false);
    	        String viewName="displayEchequesfile";
    	        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
    	        String accountNo = request.getParameter(UIConstant.ACCOUNT_NO);
    	        String TxnType = request.getParameter("noOfTxnTypes");
 				String formatType = request.getParameter("formatType");
    	        String fromDate = null;
    	       // String toDate = request.getParameter("toDate");
    	        //String corporateId=  user.getCorporateId();
    	        String branchCode = request.getParameter("branchCode");
                 inparam.put("accountNo", accountNo);
                 inparam.put("TxnType", TxnType);
                 inparam.put("branchCode", branchCode);
                 inparam.put("loginUserRole",((Integer)user.getRoles().get(0)));           
    	        //inparam.put("toDate", toDate);
                 //inparam.put("toDate", "26/12/2014");
                 inparam.put(UIConstant.ACCESS_LEVEL,"5"); // Change access level  6 to 7.
                 if (inparam.get("TxnType")!=null  && (inparam.get("TxnType").equals("success_txn") ||
                		 									inparam.get("TxnType").equals("failure_txn") ))
                 {
                	 logger.info("inside the first condition");		
                	 fromDate =  request.getParameter("fromDate");
                 }
                 else if(inparam.get("TxnType")!=null  && (inparam.get("TxnType").equals("val_failure_txn") ||
							inparam.get("TxnType").equals("unknow_txn") || inparam.get("TxnType").equals("adjusted_credits")))
			      {
			              	 fromDate =  request.getParameter("creationDate");
			      } 
                 else if(inparam.get("TxnType")!=null  && (inparam.get("TxnType").equals("scheduled_txn") ||
							inparam.get("TxnType").equals("auth_pending") ))
				 {
						     fromDate =  "-";
				 } 
                 inparam.put("type", "file");
                 inparam.put("userRole", userRole);
     			  inparam.put("corpRole", "corpuser");
     			 inparam.put("fromDate", fromDate);
    	        inparam.put("userName", user.getUserAlias());
    	        //inparam.put("formatType", formatType);
    	        inparam.put("formatType", formatType);
    	        inparam.put(UIConstant.CORPORATE_ID,user.getCorporateId());
    	         logger.info(" fromDate:" + inparam);
    	         logger.info(" TxnType:" + TxnType);
    	         logger.info(" FORMAT TYPE:" + request.getParameter("formatType"));
    	  
    	        outputParams = misTransactionReportService.execute(inparam);
    	        String requestId=(String)outputParams.get("requestId");
    	        logger.info("requestId :" +requestId);
    	        if(requestId!=null)
    	        	viewName="displayRequestIdforMIS";
    	        outputParams.put(UIConstant.ERROR_VIEW, "errorbyQueryAccChequeDownload");
    	        logger.info("outputParams at echequesDisplay is " + outputParams);
    	        List echequeMap=(List)outputParams.get("echequeMap");
    	        if(echequeMap != null){ 
    	            formatEchequeMap(echequeMap,request);
    	            Map tempObj=new HashMap();
    	            tempObj.put("reportInExcelQryByFile",echequeMap);
    	            referenceDataCache.setReferenceData("reportInExcelQryByFile",tempObj);
    	        }else{
    	            applnresponse.setErrorStatus(UIConstant.FAILURE);
    	        }
    	     
    	        logger.info("InsertLPRandRequestID() method ends");
    	        return new ModelAndView(viewName, "echequesFileBased", outputParams);
    }
        
    public ModelAndView MISviewRequestDisplay(HttpServletRequest request,HttpServletResponse response) {
    			logger.info("MISviewRequestDisplay method begins");
    			   Map inparam = new HashMap();
    			Map outputParams = new HashMap();
    			   HttpSession session = request.getSession(false);
    			UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
    			  inparam.put("userName", user.getUserAlias());
    			  inparam.put("type", "view");
    			  inparam.put(UIConstant.ACCESS_LEVEL,"5");
                  inparam.put("loginUserRole",((Integer)user.getRoles().get(0)));           
    			  logger.info(" type:" + inparam);
    			    logger.info(" user.getUserAlias():" + user.getUserAlias());
    			    outputParams = misTransactionReportService.execute(inparam);
    			outputParams.put(UIConstant.ERROR_VIEW, "errorQuerybyeCheque");
    			logger.info("MISviewRequestDisplay method ends");
    			return new ModelAndView("misviewRequest", "accountDisplay" ,outputParams);
    		}
    
    public ModelAndView misdisplayDownloadTransactionFiles(HttpServletRequest request,
    		HttpServletResponse response) {
    		logger.info("misdisplayDownloadTransactionFiles method begins");
    		    Map inparam = new HashMap();
    			Map outputParams = new HashMap();
    			List txnFileMap = null;
    		    HttpSession session = request.getSession(false);
    			UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
    			String requestId = request.getParameter("requestId");
    			inparam.put("userName", user.getUserAlias());
    			inparam.put("type", "MISdownloadtxnfiles");
    			inparam.put("requestId", requestId);
    			inparam.put(UIConstant.ACCESS_LEVEL,"5");
                inparam.put("loginUserRole",((Integer)user.getRoles().get(0)));           
    			logger.info(" type:" + inparam);
    			logger.info(" user.getUserAlias():" + user.getUserAlias());
    		    outputParams = misTransactionReportService.execute(inparam);
    			
    		    txnFileMap = (List)outputParams.get("echequeMap");
    			logger.info("txnFileMap size :"+txnFileMap);
			    String  requestFileName="";
			    String txnfile="";
			    String valfile="";
			    String invalCreditsfile="";
			    String creationTime="";
			    String fileType="";
			  //  String fileName[];
    			    
			    Map txnfilenamemap = new HashMap();
    			
    			   
    			   	if(txnFileMap!=null){
    			   		txnfilenamemap=(Map)txnFileMap.get(0);
    			    	requestFileName=(String)txnfilenamemap.get("PARAM6");
    			    	creationTime= (String)txnfilenamemap.get("CREATION_TIME");
    			    	logger.info("requestFileName :"+requestFileName);
    			    	logger.info("creationTime :"+creationTime);
    			    if(requestFileName!=null){
    			    	//fileName=	requestFileName.split("|");
    			    	StringTokenizer tokens = new StringTokenizer(requestFileName, ",");
    			    	logger.info("tokens :"+tokens);
    			    	while(tokens.hasMoreTokens()){
    			    		fileType = tokens.nextToken();
    			    		logger.info("fileType :"+fileType);
    			    		
    			    		if(fileType.contains("_ADJ_MIS")){
    			    				valfile =fileType;
    			    			}else if(fileType.contains("_SUC_MIS")){
    			    				//invalCreditsfile = fileType;
    			    				txnfile= fileType;
    			    			}else{
    			    				txnfile = fileType;
    			    			}
    			    			
    			    		}
    			    		
    			    	}
    			    	outputParams.put("requestFileName", requestFileName);
    			    	outputParams.put("txnfile", txnfile);
    			    	outputParams.put("valfile", valfile);
    			    	outputParams.put("invalCreditsfile", invalCreditsfile);
    			    	outputParams.put("creationTime", creationTime);
    			    }
    			    
    			    outputParams.put(UIConstant.ERROR_VIEW, "downloadfileerror"); 
    			//outputParams.put(UIConstant.ERROR_VIEW, "errorQuerybyeCheque");
    			logger.info("misdisplayDownloadTransactionFiles method ends");
    			return new ModelAndView("MISdisplaydownloadtxnfiles", "viewEchequeDisplay" ,outputParams);
    		}
    
    public ModelAndView misdownloadFileBasedReport(HttpServletRequest request,
    		HttpServletResponse response) {
    			logger.info("misdownloadFileBasedReport method begins");
    			   Map inparam = new HashMap();
    			Map outputParams = new HashMap();
    			 SBIApplicationResponse applnresponse=new SBIApplicationResponse();
    			   HttpSession session = request.getSession(false);
    			UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
    			 try
    	    		{
    	    			String fileName=request.getParameter("requestId");
    	    			String filepath=reportFilePath;  
						InputStream bis=null;
    	    			logger.info(filepath);
    	    	//	InputStream bis = new FileInputStream(reportFilePath+fileName);
    	    		
    	    		
    	    		
    	    		response.reset();
    	    		response.setContentType("application/excel");
    	    		//response.setHeader("Content-disposition","attachment; filename=" +fileName);
    	    		if(fileName.contains(".xls") || fileName.contains(".XLS")){
       	    		 bis = new FileInputStream(filepath+fileName);
       	    		response.setHeader("Content-disposition","attachment; filename=" +fileName);
       	    		}else if(fileName.contains(".txt") ||fileName.contains(".TXT")){
       	    		 bis = new FileInputStream(filepath+fileName);
        	    		response.setHeader("Content-disposition","attachment; filename=" +fileName);
       	    		}else{
       	    		 //bis = new FileInputStream(filepath+fileName+".xls");
       	    		bis = new FileInputStream(filepath+fileName);
       	    		//response.setHeader("Content-disposition","attachment; filename=" +fileName+".xls");
       	    		response.setHeader("Content-disposition","attachment; filename=" +fileName);
       	    		}
    	    		
    	    		//response.setHeader("Content-disposition","attachment; filename=" +fileName);
    	    		byte[] buf = new byte[1024];
    	    		int len;
    	    		while ((len = bis.read(buf)) > 0){
    	    		response.getOutputStream().write(buf, 0, len);
    	    		}
    	    		bis.close();
    	    		response.getOutputStream().flush();
    	    		}
    			 catch(FileNotFoundException ex)
    	    	      {
    				 logger.info("test failed no file found:"+ex);
    	                applnresponse.setErrorStatus(UIConstant.FAILURE);
    	                applnresponse.setErrorCode("ECS009");
    	                outputParams.put(UIConstant.APPLICATION_RESPONSE,applnresponse);
        	    		return new ModelAndView("errorQuerybyeCheque", "errorQuerybyeCheque" ,outputParams);
    	                
    	         }
    			
    			  
    	    		catch(Exception e){
    	    		e.printStackTrace();
    	    		}
    	    		logger.info("downloadFileBasedReport method ends");
    	    		
    	    		return null;
    		}
    
    
    public ModelAndView viewRequestDisplay(HttpServletRequest request,
    		HttpServletResponse response) {
    			logger.info("viewRequestDisplay method begins");
    			   Map inparam = new HashMap();
    			Map outputParams = new HashMap();
    			   HttpSession session = request.getSession(false);
    			UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
    			  inparam.put("userName", user.getUserAlias());
    			  inparam.put("type", "view");
    			  logger.info(" type:" + inparam);
    			    logger.info(" user.getUserAlias():" + user.getUserAlias());
    			    outputParams = transactionReportService.execute(inparam);
    			outputParams.put(UIConstant.ERROR_VIEW, "errorQuerybyeCheque");
    			logger.info("viewRequestDisplay method ends");
    			return new ModelAndView("viewRequest", "viewEchequeDisplay" ,outputParams);
    		}
    
 
    
 
   
    private void formatEchequeMap(List  echequeMap, HttpServletRequest request){
        logger.info("formatEchequeMap() method starts");
        HttpSession session=request.getSession(false);
        Map branchMap=(Map)session.getServletContext().getAttribute(UIConstant.BRANCH_NAME_CODE_MAP);
        EchequeDetails echequeDetails=null;
        if(echequeMap != null){
            for(int count=0;count<echequeMap.size();count++){
                echequeDetails=(EchequeDetails)echequeMap.get(count);
                echequeDetails.setDebit_branch((String)branchMap.get(echequeDetails.getDebit_branch()));
                StringBuffer retrieveField=new StringBuffer(""+echequeDetails.getDebit_branch());
                if(retrieveField.charAt(0) == '0'){
                    retrieveField.replace(0,1,"'0");
                    echequeDetails.setDebit_branch(retrieveField.toString().trim());
                }else if(retrieveField.charAt(0) == 'A'){
                    retrieveField.replace(0,1,"'1");
                    echequeDetails.setDebit_branch(retrieveField.toString().trim());
                }
                retrieveField=new StringBuffer(""+echequeDetails.getCreditBranchName());
                if(retrieveField.charAt(0) == '0'){
                    retrieveField.replace(0,1,"'0");
                    echequeDetails.setCreditBranchName(retrieveField.toString().trim());
                }else if(retrieveField.charAt(0) == 'A'){
                    retrieveField.replace(0,1,"'1");
                    echequeDetails.setCreditBranchName(retrieveField.toString().trim());
                }
                retrieveField=new StringBuffer(""+echequeDetails.getDebit_account());
                if(retrieveField.charAt(0) == '0'){
                    retrieveField.replace(0,1,"'0");
                    echequeDetails.setDebit_account(retrieveField.toString().trim());
                }
                retrieveField=new StringBuffer(""+echequeDetails.getCreditAccountNo());
                if(retrieveField.charAt(0) == '0'){
                    retrieveField.replace(0,1,"'0");
                    echequeDetails.setCreditAccountNo(retrieveField.toString().trim());
                }
                retrieveField=new StringBuffer(""+echequeDetails.getCreditStatus());
                if(retrieveField.charAt(0) == '0'){
                    retrieveField.replace(0,1,"'0");
                    echequeDetails.setCreditStatus(retrieveField.toString().trim());
                }
                retrieveField=new StringBuffer(""+echequeDetails.getCorpRefNo());
                if((Character.isDigit(retrieveField.charAt(0)))){
                    retrieveField.insert(0,"'");
                    echequeDetails.setCorpRefNo(retrieveField.toString().trim());
                }
                if(echequeDetails.getDebit_ref_no().indexOf("CK") != -1 || echequeDetails.getDebit_ref_no().indexOf("CC") != -1){
                    echequeDetails.setCreditAccountNo("Credit Account");
                }
            }
        }
        logger.info("formatEchequeMap() method ends");
    }
    //added by Damodar for Account based MIS with ends    
    
    public ModelAndView requestFailureTxn(HttpServletRequest request, HttpServletResponse response) {       	
    	logger.info("requestFailureTxn(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
    	
		Map outputParams = new HashMap();
		HttpSession session = request.getSession(false);
		session.setAttribute(UIConstant.REFRESH_FLAG,new Boolean(false));
		logger.info("requestFailureTxn(HttpServletRequest request, HttpServletResponse response)"+LoggingConstants.METHODEND );
		return new ModelAndView("requestFailureTxn","",outputParams);
    }    
    
    public ModelAndView requestFailureTxnConfirm(HttpServletRequest request,HttpServletResponse response) {
        logger.info("requestFailureTxnConfirm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
        
        Map inparam = new HashMap();
        Map outputParams = new HashMap();
        
        HttpSession session = request.getSession(false);
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        
        String startDate = request.getParameter("startDate");
      //  String endDate = request.getParameter("endDate");
        String endDate = request.getParameter("startDate");
        
        inparam.put("userName", user.getUserAlias());
        inparam.put("corporateId", user.getCorporateId());
        inparam.put("startDate", startDate);
        inparam.put("endDate", endDate);
        inparam.put("funcType", "requestFailureTxn");
        
        outputParams = failureTxnService.execute(inparam);
        
        logger.info("requestFailureTxnConfirm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
        return new ModelAndView("requestFailureTxnSuccess", "outputParams", outputParams);
    }  

    public ModelAndView downloadFailureTxn(HttpServletRequest request,HttpServletResponse response) {
    	logger.info("downloadFailureTxn(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
    	
    	Map inparam = new HashMap();
    	Map outputParams = new HashMap();
    	HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inparam.put("userName",user.getUserAlias());
		inparam.put("funcType", "downloadStatusFailureTxn");
		
		outputParams = failureTxnService.execute(inparam);
		
		outputParams.put(UIConstant.ERROR_VIEW, "downloadfileerror"); 
		logger.info("downloadFailureTxn(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("downloadFailureTxn", "outputParams" ,outputParams);
	}
    
    public ModelAndView downloadFailureTxnFile(HttpServletRequest request,HttpServletResponse response) {
    	logger.info("downloadFailureTxnFile(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
    	Map inparam = new HashMap();
    	Map outputParams = new HashMap();
    	SBIApplicationResponse applnresponse=new SBIApplicationResponse();
    	HttpSession session = request.getSession(false);
    	User user = (User) session.getAttribute(UIConstant.USER);
		String userName = (String) user.getUserAlias();
    	
		try {
	    	
			String fileName=request.getParameter("filename");	
			logger.info("fileName to download:::"+fileName);
    		String filepath=reportFilePath;  
    		logger.info(filepath);
    		//InputStream bis = new FileInputStream(reportFilePath+fileName+".xls");
    		//reportFilePath="D:\\data\\downloads\\corporate\\report\\";//TOBE REMOVED
    		InputStream bis = new FileInputStream(reportFilePath+fileName);
    		
    		response.reset();
    		response.setContentType("text/csv");
    		response.setHeader("Content-disposition","attachment; filename=" +fileName);
    		byte[] buf = new byte[1024];
    		int len;
    		while ((len = bis.read(buf)) > 0){
    		response.getOutputStream().write(buf, 0, len);	
    		}
    		bis.close();
    		response.getOutputStream().flush();
    		
		} catch(FileNotFoundException ex) {
			logger.info("FileNotFoundException:"+ex);
            applnresponse.setErrorStatus(UIConstant.FAILURE);
            applnresponse.setErrorCode("SE002");
            outputParams.put(UIConstant.APPLICATION_RESPONSE,applnresponse);
            logger.info("downloadFailureTxnFile(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
            return new ModelAndView("errorDownloadFailureTxn", "outputParams" ,outputParams);
		}
		catch(Exception e){
    		e.printStackTrace();
    	}
		logger.info("downloadFailureTxnFile(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return null;
	}
    
	public void setTransactionReportService(BaseService transactionReportService) {
		this.transactionReportService = transactionReportService;
	}
	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	public void setReportFilePath(String reportFilePath) {
		this.reportFilePath = reportFilePath;
	}

	public void setFailureTxnService(BaseService failureTxnService) {
		this.failureTxnService = failureTxnService;
	}
	
}
