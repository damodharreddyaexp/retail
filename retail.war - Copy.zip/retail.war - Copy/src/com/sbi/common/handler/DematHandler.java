/*
 * DematHandler.java
 * Created on 09 Aug, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//09 Aug, 2006 Saravanan - Initial Creation
package com.sbi.common.handler;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class DematHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());

	private BaseService displayDpIdService;

	private BaseService submitDematDetailService;

	String requestType;
	//landing page added by Pons
	public ModelAndView displayLandingPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	if(logger.isDebugEnabled()) 
			logger.debug("displayLandingPage(HttpServletRequest request, HttpServletResponse response)- begin");
    	logger.info("displayLandingPage method");
        Map outParams=new HashMap();
    	SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
    	applicationResponse.setErrorStatus(UIConstant.SUCCESS);
    	logger.info("success");
    	outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
    	outParams.put(UIConstant.ERROR_VIEW, "commonerror");
    	if(logger.isDebugEnabled()) 
			logger.debug("displayLandingPage(HttpServletRequest request, HttpServletResponse response)- end");
        return new ModelAndView("dematlanding","model",outParams);
    }
    
	public ModelAndView displayDpIds(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("displayDpIds(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		String view = "displaydematid";		
		String  errorView ="errordematdetails";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession(false);
		if (session.getAttribute("DMAT_RESPONSE") != null){
			session.removeAttribute("DMAT_RESPONSE");
		}
		User user = (User) session.getAttribute(UIConstant.USER);
		logger.info("Requst= " + request.getParameter("request"));
		requestType = request.getParameter("request");
		// added for defect-wrong mapping in breadcrumb
		String url = request.getServletPath().replaceAll("/", "");
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
		outParams = displayDpIdService.execute(inputParams);
		 if (url.equalsIgnoreCase("billingdisplaydpid.htm")) {
				requestType = "DP_BILLING_STATEMENT";				
	        }
		 else if (url.equalsIgnoreCase("holdingdisplaydpid.htm")) {
				requestType = "DP_HOLDING";
	        }
		
		 else if (url.equalsIgnoreCase("statementdisplaydpid.htm")) {
				requestType = "DP_STATEMENT_TRANS";
	        }
		 else if (url.equalsIgnoreCase("displaydpid.htm")) {
				requestType = "DP_ACCOUNT";
	        }	
		outParams.put(UIConstant.DEMAT_REQUST,requestType);
		outParams.put(UIConstant.ERROR_VIEW, errorView);
		logger.info("Output returned to handler = " + outParams.toString());
		logger.info("displayDpIds(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);
		return new ModelAndView(view, UIConstant.MODEL, outParams);
	}

	public ModelAndView displayAccountDetails(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("displayAccountDetails(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		requestType = "DP_ACCOUNT";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
		logger.info("requestType " + requestType);
		inputParams.put(UIConstant.DEMAT_REQUST, requestType);
		inputParams.put(UIConstant.DP_ID, request.getParameter(UIConstant.DP_ID));
		inputParams.put("channel", request.getParameter("channel"));
		outParams = submitDematDetailService.execute(inputParams);
		SBIApplicationResponse res = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Error status" + res.getErrorStatus());
		logger.info("Error code" + res.getErrorCode());
		outParams.put(UIConstant.ERROR_VIEW, "errordematdetails");
		logger.info("displayAccountDetails(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.DEMAT_ACCT_RESPONSE_VIEW,UIConstant.MODEL, outParams);
	}

	public ModelAndView displayHoldingDetails(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("displayHoldingDetails(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		requestType = "DP_HOLDING";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
		logger.info("requestType " + requestType);
		inputParams.put(UIConstant.DEMAT_REQUST, requestType);
		inputParams.put(UIConstant.DP_ID, request.getParameter(UIConstant.DP_ID));
		inputParams.put("channel", request.getParameter("channel"));
		outParams = submitDematDetailService.execute(inputParams);
		outParams.put(UIConstant.ERROR_VIEW, "errordematdetails");
		logger.info("displayHoldingDetails(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.DEMAT_HOLD_RESPONSE_VIEW,UIConstant.MODEL, outParams);
	}

	public ModelAndView displayTransactionStatement(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("displayTransactionStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		requestType = "DP_STATEMENT_TRANS";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		Timestamp stDate = null;
		Timestamp enDate = null;
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
		logger.info("requestType " + requestType);
		String startDate = request.getParameter("startdate");
		String endDate = request.getParameter("enddate");
		startDate = startDate.replaceAll("/", "-");
		endDate = endDate.replaceAll("/", "-");
		logger.info("Start date:" + startDate);
		logger.info("End date:" + endDate);
		logger.info("holdingstat " + request.getParameter("holdingstat"));
		logger.info("bankdetails " + request.getParameter("bankdetails"));
		inputParams.put(UIConstant.START_DATE, startDate);
		inputParams.put(UIConstant.END_DATE, endDate);
		inputParams.put(UIConstant.HOLD_STATEMENT, request.getParameter("holdingstat"));
		inputParams.put(UIConstant.BANK_DETAILS, request.getParameter("bankdetails"));
		inputParams.put(UIConstant.DEMAT_REQUST, requestType);
		inputParams.put(UIConstant.DP_ID, request
				.getParameter(UIConstant.DP_ID));
		inputParams.put("channel", request.getParameter("channel"));
		outParams = submitDematDetailService.execute(inputParams);
		outParams.put(UIConstant.ERROR_VIEW, "errordematdetails");
		logger
				.info("displayTransactionStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.DEMAT_STAT_TRANS_VIEW,
				UIConstant.MODEL, outParams);
	}

	public ModelAndView displayBillingStatement(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("displayBillingStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		requestType = "DP_BILLING_STATEMENT";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
		logger.info("requestType " + requestType);
		String dpId = request.getParameter(UIConstant.DP_ID);
		String channel = request.getParameter("channel");
		inputParams.put(UIConstant.DEMAT_REQUST, requestType);
		inputParams.put(UIConstant.DP_ID, dpId);
		inputParams.put("channel", request.getParameter("channel"));
		outParams = submitDematDetailService.execute(inputParams);
		outParams.put(UIConstant.ERROR_VIEW, "errordematdetails");
		outParams.put(UIConstant.DP_ID, dpId);
		outParams.put("channel", channel);
		logger.info("displayBillingStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.DEMAT_BILLING_STATEMENT_VIEW,UIConstant.MODEL, outParams);
	}

	public ModelAndView submitBillStatement(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("submitBillStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODBEGIN);
		requestType = "";
		Map inputParams = new HashMap();
		Map outParams = new HashMap();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);
		inputParams.put(UIConstant.USER_NAME, user.getUserAlias());

		String dpId = request.getParameter(UIConstant.DP_ID);
		String invoiceId = request.getParameter("invoiceId");
		logger.info("dpid->" + dpId);
		logger.info("invoiceId->" + invoiceId);
		logger.info("requestType--> " + requestType);
		logger.info("channel " +request.getParameter("channel"));
		inputParams.put(UIConstant.DP_ID, dpId);
		inputParams.put("channel", request.getParameter("channel"));
		inputParams.put(UIConstant.DEMAT_REQUST, requestType);
		inputParams.put("invoiceId", invoiceId);
		outParams = submitDematDetailService.execute(inputParams);
		outParams.put(UIConstant.ERROR_VIEW, "errordematdetails");
		//logger.info("OutParams-->" + outParams);
		logger.info("submitBillStatement(HttpServletRequest request, HttpServletResponse response) "
						+ LoggingConstants.METHODEND);

		return new ModelAndView(UIConstant.DEMAT_BILLING_STATEMENT_DETAILS_VIEW,
				UIConstant.MODEL, outParams);
	}

	public ModelAndView printDMatDetails(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("printDMatDetails(HttpServletRequest request,HttpServletResponse response) "
				+ LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		SBIApplicationResponse appRes = new SBIApplicationResponse();
		HttpSession session = request.getSession(false);
		if (session.getAttribute("DMAT_RESPONSE") != null){
			String responseString = (String)session.getAttribute("DMAT_RESPONSE");
			outParams.put("reqString",responseString);
		}
		appRes.setErrorStatus(UIConstant.SUCCESS);
		logger.info("printDMatDetails(HttpServletRequest request,HttpServletResponse response) "
				+ LoggingConstants.METHODEND);
		return new ModelAndView("dematprint",UIConstant.MODEL, outParams);
		
	}
	
	/**
	 * @param displayDpIdService The displayDpIdService to set.
	 */
	public void setDisplayDpIdService(BaseService displayDpIdService) {
		this.displayDpIdService = displayDpIdService;
	}

	/**
	 * @param submitDematDetailService The submitDematDetailService to set.
	 */
	public void setSubmitDematDetailService(BaseService submitDematDetailService) {
		this.submitDematDetailService = submitDematDetailService;
	}

	/**
	 * @param submitDemandDetailService The submitDemandDetailService to set.
	 */

}
