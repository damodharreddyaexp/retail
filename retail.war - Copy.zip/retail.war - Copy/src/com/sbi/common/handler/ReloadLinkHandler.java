package com.sbi.common.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.dao.SBINameValueMasterDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.LinkDetails;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.EncryptMD5;
import com.sbi.common.utils.LinkUtil;

public class ReloadLinkHandler extends MultiActionController {
	protected final Logger logger = Logger.getLogger(getClass());
	
	  private ResourceBundleMessageSource logonProperty;
	  
		private ReferenceDataCache referenceDataCache;
		private SBINameValueMasterDAO sbiNameValueMasterDAOImpl;// added to reload the NAME_VALUE_MASTER record - Pons.
	private LinkUtil linkUtil;

	private Map<String, String> roleTypeMap;

	private String encryptPassword;

	private String userName;

	private String corpRoles;
	
	private String moduleName;//module name specified in configuration file  - added by Pons
	/*
	 *  <property name="moduleName"><value>${moduleName}</value> </property>
	 */
	public ModelAndView reloadLinks(HttpServletRequest request,
			HttpServletResponse response) {

		return new ModelAndView("reloadLinks");
	}

	public ModelAndView reloadLinksConfirm(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String reqUrl = request.getRequestURL().toString();
		String bankCode =request.getHeader("BankCode");
    	String bankURLKey="";
    		if(reqUrl.contains("localhost")){
    		 bankCode="0";
    		 bankURLKey="bankURL.local."+bankCode;
    	 }
    	 else bankURLKey="bankURL.prdn."+bankCode;
		ServletContext ctx = getServletContext();
		String[] bankCodeArray = request.getParameterValues("bankCode");
		String userName = request.getParameter("userName");
		String passWord = request.getParameter("password");
		String contextpath=request.getContextPath().substring(1);
		logger.info("moduleName in reloadlink ::" + moduleName);
		Map<String, Object> outparams = new HashMap<String, Object>();
		SBIApplicationResponse errorResponse = new SBIApplicationResponse();

		boolean loginStatus = EncryptMD5.verifyHash(userName + "#" + passWord,encryptPassword);
		if (loginStatus && bankCodeArray != null) {
			
			String key = UIConstant.TRANSACTION_LIMIT;
			if (ctx.getAttribute("objectsLoaded") != null)
				referenceDataCache.removeReferenceData(key);
			HashMap data = (HashMap) sbiNameValueMasterDAOImpl
					.getNameValueMasterData();

			if (data != null){
				referenceDataCache.setReferenceData(key, data);
				ctx.setAttribute(UIConstant.TRANSACTION_LIMIT_MAP,
							referenceDataCache.getReferenceData(UIConstant.TRANSACTION_LIMIT));
			}
				for (int i = 0; i < bankCodeArray.length; i++) {
					String contextRoles[] = corpRoles.split("\\|");
					for (int j = 0; j < contextRoles.length; j++) {
						logger.info(contextRoles.length);
						logger.info("contextRoles[" + j + "]"+ contextRoles[j]);
						logger.info("roleTypeMap :" + roleTypeMap);
						String contextType = roleTypeMap.get(contextRoles[j]);
						String contextTypes[] = contextType.split("\\|");
						for (int k = 0; k < contextTypes.length; k++) {
							logger.info("Loading for contextRoles[" + j + "]"+ contextRoles[j]+" and contextType["+k+"]"+contextTypes[k]+" and bank Code["+i+"]"+bankCodeArray[i]);
							ctx.removeAttribute("linksLoaded" + bankCodeArray[i]);
							Map<String, Object> links = linkUtil.getLinkDetails(contextRoles[j],contextTypes[k], bankCodeArray[i],moduleName);
							List<LinkDetails> tabs = (List<LinkDetails>) links.get("tabs");
							List<String> queryIds = (List<String>) links.get("queryIds");
							links.remove("tabs");
							links.remove("queryIds");
							ctx.setAttribute("links" + bankCodeArray[i]+ contextRoles[j] + contextTypes[k], links);
							ctx.setAttribute("tabs" + bankCodeArray[i]+ contextRoles[j] + contextTypes[k], tabs);
							ctx.setAttribute("queryIds" +bankCodeArray[i]+ contextRoles[j] + contextTypes[k],queryIds);
							ctx.setAttribute("linksLoaded" + bankCodeArray[i], "YES");
						}
					}
				}
			ctx.setAttribute("queries", linkUtil.getQueries());			
			String objectLoaded = (String) ctx.getAttribute("object_loaded");
			logger.info("objectLoaded status in reload: " + objectLoaded);
			response.sendRedirect(getPropertyVal(bankURLKey)+contextpath+"/login.htm");
		} else
			errorResponse.setErrorCode("LOG001");

		outparams.put(ServiceConstant.APPLICATION_RESPONSE, errorResponse);
		logger.info("error...." + errorResponse.getErrorCode());
		return new ModelAndView("reloadLinks", "errorModel", outparams);
	}
	
	 private String getPropertyVal(String key){
		  String value ="";
		  try {
	  		logger.info("key val :"+key);
	      	 value=logonProperty.getMessage(key, null, null);
	       }
		  catch (NoSuchMessageException ex) {
	          logger.error("NoSuchMessageException occured" ,ex );
	       }	
	      return value;
		}

	public void setLinkUtil(LinkUtil linkUtil) {
		this.linkUtil = linkUtil;
	}

	public void setRoleTypeMap(Map<String, String> roleTypeMap) {
		this.roleTypeMap = roleTypeMap;
	}

	public void setCorpRoles(String corpRoles) {
		this.corpRoles = corpRoles;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setEncryptPassword(String encryptPassword) {
		this.encryptPassword = encryptPassword;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public void setLogonProperty(ResourceBundleMessageSource logonProperty) {
		this.logonProperty = logonProperty;
	}
	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}
	   public void setSbiNameValueMasterDAOImpl(SBINameValueMasterDAO sbiNameValueMasterDAOImpl)
	    {
	        this.sbiNameValueMasterDAOImpl = sbiNameValueMasterDAOImpl;

	    }

}