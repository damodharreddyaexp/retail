/*
 * CorpLogonHandler.java
 * Created on Mar 7, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 7, 2006 KRISHNA KUMAR - Initial Creation
//SEP 20, 2007 PONNUSAMY - Khata login process added and retail user login restricted from corporate
//FEB 04, 2008 PONNUSAMY - login redirection based on role is changed to avoid double login validation.
//OCT 10,2009 LALIEATH KUMAR - Optimisation and Dynamic Link Changes
//JUL 06,2011 PONNUSAMY - File revamped to remove the hard coded values.
package com.sbi.common.handler;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import wac.logger.ErrorDictionary;

import com.sbi.common.cache.ReferenceDataCache;

import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.LinkDetails;
import com.sbi.common.model.Query;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LinkUtil;
import com.sbi.common.utils.RndString;
import com.sbi.common.utils.StringUtils;

public class CorpLogonHandler extends MultiActionController {

    protected final Logger logger = Logger.getLogger(getClass());

    private BaseService logonService;

    private JSTLConstants constants;

    private ReferenceDataCache referenceDataCache;

    private ResourceBundleMessageSource logonProperty;

    private BaseService corpProfileService;
 
    static Map<String,String> returnView;//CorpDynamicLink
    
    
    private LinkUtil linkUtil;//CorpDynamicLink
    
    private String corpRoles;//CorpDynamicLink optimisation
   
    private String moduleName;//module name specified in configuration file  - added by Pons
	private Map<String, String> roleTypeMap;//CorpDynamicLink
	private RndString rndString; //added for CR 5550
	
	private String passwordExpiryCheck; 
	private String compareDateWithToday;
	
	//CorpDynamicLink optimisation
    static{
		returnView = new HashMap<String, String>();
		returnView.put("0",UIConstant.LOGIN_PAGE);
		returnView.put("1",UIConstant.SBBJ_LOGIN_PAGE);
		returnView.put("2",UIConstant.SBH_LOGIN_PAGE);
		returnView.put("3",UIConstant.SBS_LOGIN_PAGE);//SBIInd Merger
		returnView.put("4",UIConstant.SBM_LOGIN_PAGE);
		returnView.put("5",UIConstant.SBP_LOGIN_PAGE);
		returnView.put("6",UIConstant.SBS_LOGIN_PAGE);
		returnView.put("7",UIConstant.SBT_LOGIN_PAGE);
		

	}
    
    public ModelAndView logInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("Login page display");
        String bankCode =request.getHeader("BankCode");
        String reqUrl = request.getRequestURL().toString();
        Map<String,String> loginData = new HashMap<String,String>();
        if(reqUrl.contains("localhost")){
        	loginData.put("urlHost", "local");
        	bankCode="0";
        }
        String merchant_code = request.getParameter("merchant_code");
        String cbecredirect = request.getParameter("cbecredirect");  
        
        String  keyString  = rndString.getRamdom();//Nag - added for 5034 
        loginData.put("merchant_code", merchant_code);
        loginData.put("cbecredirect", cbecredirect);
        loginData.put("keyString",keyString );//Nag - added for 5034 
        String viewPage = returnView.get(bankCode);
        return new ModelAndView(viewPage,"loginModel",loginData);
    }

    public ModelAndView sessionTimeOut(HttpServletRequest request, HttpServletResponse response) throws Exception {
        return new ModelAndView("sessionLayout");
    }

    /**
     * Login page to mypage
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     *             ModelAndView
     */
    public ModelAndView logInSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	logger.info("logInSubmit(HttpServletRequest request, HttpServletResponse response) begin");
    	ServletContext ctx = getServletContext();
    	String userIPaddress = request.getHeader("ClientIP");
        logger.info("Client IP from header : " + userIPaddress); 
       
    	String bankCode =request.getHeader("BankCode");
    	String reqUrl = request.getRequestURL().toString();
    	String keyString="";
    	String userName ="";
    	String password="";
    	String SHA512Password=""; //Added for SHA encryption algorithm
    	String bankURLKey="";
    		if(reqUrl.contains("localhost")){
    		 bankCode="0";
    		 userIPaddress="127.0.0.1";
    		 bankURLKey="bankURL.local."+bankCode;
    	 }
    	 else bankURLKey="bankURL.prdn."+bankCode;
    	 logger.info("bankCode...."+bankCode);
        if (ctx.getAttribute("objectsLoaded")==null) {
            ErrorDictionary records = ErrorDictionary.getExpInstance();
            HashMap wacErrorDictionary = records.getInstance();
            ctx.setAttribute(UIConstant.constants, constants);
            ctx.setAttribute(UIConstant.PRODUCT_DESCRIPTION, referenceDataCache.getReferenceData(UIConstant.ACCOUNTNAME_KEY));
            ctx.setAttribute(UIConstant.COUNTRY_NAME, referenceDataCache.getReferenceData(UIConstant.COUNTRY_NAME_CODE));
            ctx.setAttribute(UIConstant.TRANSACTION_LIMIT_MAP, referenceDataCache.getReferenceData(UIConstant.TRANSACTION_LIMIT));
            ctx.setAttribute(UIConstant.BRANCH_NAME_CODE_MAP, referenceDataCache.getReferenceData(UIConstant.BRANCH_DATA_KEY));
            ctx.setAttribute("wacErrorDictionary", wacErrorDictionary);
            ctx.setAttribute("objectsLoaded", "YES");
        }
        Map nameValueMap=referenceDataCache.getReferenceData(UIConstant.TRANSACTION_LIMIT); //Added by Siva
        int loginPwdExpiryDayLimit = Integer.parseInt((String)nameValueMap.get("LOGIN_PWD_CHANGE_LIMIT"));
        String loginGracePeriod = (String)nameValueMap.get("LOGIN_PWD_CHANGE_GRACE_PERIOD");
        String contextRoles[] = corpRoles.split("\\|");
	    String ctxAttribute =(String) ctx.getAttribute("linksLoaded" + bankCode);
	    logger.info("to be removed value of linksLoaded for bankCode :"+bankCode+" is "+ctxAttribute);
	    if (ctx.getAttribute("linksLoaded" + bankCode) == null) {
	    	for (int i = 0; i < contextRoles.length; i++) {
				logger.info(contextRoles.length);
				logger.info("contextRoles[" + i + "]" + contextRoles[i]);
				logger.info("roleTypeMap :" + roleTypeMap);
				String contextType = roleTypeMap.get(contextRoles[i]);
				logger.info("contextType :"+contextType);
				String contextTypes[] = contextType.split("\\|");
				for (int j = 0; j < contextTypes.length; j++) {
					Map<String, Object> links = linkUtil.getLinkDetails(contextRoles[i], contextTypes[j], bankCode,moduleName);
					logger.info("User types from commonhandler.xml:"+contextTypes[j]);
					
					List<LinkDetails> tabs = (List<LinkDetails>) links.get("tabs");
					List<String> queryIds = (List<String>) links.get("queryIds");
					links.remove("tabs");
					links.remove("queryIds");
					ctx.setAttribute("links" + bankCode + contextRoles[i]+ contextTypes[j], links);
					ctx.setAttribute("tabs" + bankCode + contextRoles[i]+ contextTypes[j], tabs);
					ctx.setAttribute("queryIds" + bankCode + contextRoles[i]+ contextTypes[j], queryIds);
					logger.info("ctx.getAttribute(..):"+ctx.getAttribute("links" + bankCode + contextRoles[i]+ contextTypes[j]));
				}
			}
	    	ctx.setAttribute("queries", linkUtil.getQueries());
	    	ctx.setAttribute("linksLoaded" + bankCode, "YES");
		}
        
        String serverName= (String)getServletContext().getAttribute("com.ibm.websphere.servlet.application.host");
        Map<Object,Object> outParams = new HashMap<Object,Object>(); 
        
      //Nag added for 5034
        userName  = (String)request.getAttribute("userName");
        password  = (String)request.getAttribute("password");
        SHA512Password	=  (String)request.getAttribute(UIConstant.SHA2_PASSWORD); //Added for SHA encryption algorithm
        keyString = (String) request.getAttribute("keyString");
        if(userName==null ||password==null||keyString==null || SHA512Password==null){//Added for SHA encryption algorithm
    
    	   userName = request.getParameter(UIConstant.USER_NAME);
    	   keyString = request.getParameter("keyString");
    	   password  = request.getParameter(UIConstant.PASSWORD);
    	   SHA512Password	=  (String)request.getParameter(UIConstant.SHA2_PASSWORD); //Added for SHA encryption algorithm
       }
        
       logger.info("username::"+userName+"password::"+password+"keyString:"+keyString+"SHA512Password:"+SHA512Password); 
        
        String errorCode = request.getParameter(UIConstant.ERROR_CODE);//Nag added for 5034
        String firstTimeLoign = (String) request.getParameter("firstTimeLogin");
        Map<Object,Object> inputParams = new HashMap<Object,Object>();
        inputParams.put(UIConstant.USER_NAME, userName);
        inputParams.put("errorCode", errorCode); //Nag added for 5034
        inputParams.put("keyString",keyString); //Nag added for 5034
        inputParams.put(UIConstant.PASSWORD, password);
        inputParams.put(UIConstant.SHA2_PASSWORD,SHA512Password); //Added for SHA encryption algorithm
        inputParams.put(UIConstant.IP_ADDRESS, userIPaddress);
        inputParams.put("serverName", serverName);
        inputParams.put("moduleName", moduleName);
        inputParams.put("keyid", request.getParameter("keyid"));
        inputParams.put("firstTimeLoginStatus", firstTimeLoign);
        //Added For CR 5405
        HttpSession session = request.getSession(true);
    	String sessionId = session.getId();
    	inputParams.put("sessionId",sessionId);
        logger.info("bankCodeJsp length:"+bankCode);
        inputParams.put(UIConstant.BANK_CODE, bankCode);
        String viewPage = returnView.get(bankCode);
        logger.info("return view" + viewPage);
        
        if (userName != null && userName.trim() != "" && password != null && password.trim() != "" && SHA512Password != null && SHA512Password.trim() != "") { //Added for SHA encryption algorithm
        	MDC.put("username", userName);
            outParams = (Map) logonService.execute(inputParams);
            logger.info("outparams" +outParams);
            Map<Object,Object> inParam = new HashMap<Object,Object>();
            // code added and modified for CR 2450 and to avoid double login validation. - by Ponnusamy
    		String userRoleStr=(String)outParams.get("USER_ROLE");
    	//	SBIApplicationResponse	applicationResponse=(SBIApplicationResponse)outParams.get("applicationResponse");  //by nag
    		logger.info("errorCode::::::::"+errorCode+"userRoleStr::"+userRoleStr); // by nag
			//Dynamic Link change
            String passwordMode = (String) outParams.get(UIConstant.PASSWORD_MODE); //  Added for CR 5550 - Immanuel for forced login
			
            boolean isRole=false;
			
			if(userRoleStr!=null){
            	if(corpRoles.indexOf(userRoleStr)>=0){
            		logger.info("corpRoles::::::::::::::::"+corpRoles.indexOf(userRoleStr));
	        		isRole=true;
	        	}
            	logger.info("isRole value in CorpLogOnHandler:"+isRole);
    			if(!isRole){
    				String roleString="role"+userRoleStr;
    	            String urlString="";
    	            String redirectURLString=null;
    	            try {
    	            	urlString = logonProperty.getMessage(roleString, null, null);
    	            	redirectURLString = getPropertyVal(bankURLKey) + urlString;
    	            	 }
    	            catch (Exception exception) {
    	            	redirectURLString = getPropertyVal(bankURLKey) + logonProperty.getMessage("bvrole", null, null);
    	                
    	            }
    				if(!userRoleStr.equals(corpRoles.indexOf(userRoleStr)) && !userRoleStr.equalsIgnoreCase("1")){// will go inside if user enter with other context root.
    					
    					logger.info("redirectURL :"+redirectURLString);
    		        	outParams.put("userName", userName);
    		            outParams.put("password", password);
    		            outParams.put("SHA512Password", SHA512Password); //Added for SHA encryption algorithm
    		            outParams.put("redirectURL", redirectURLString);
    		            outParams.put("bankCode", bankCode);
    		            outParams.put("keyString", keyString);//by nag 
    		            outParams.put("keyid", request.getParameter("keyid"));
    		            MDC.remove("username");
    		            return new ModelAndView("loginredirecturl", "outParams", outParams);
    				}// CR 2450 end
    			}
			}
			
            if (outParams.get("profile") != null) {
                UserProfile userProfile = (UserProfile) outParams.get("profile");
                Boolean isCorporateHasDisabledLinks = false;
                final String corporateId = userProfile.getCorporateId();
                if("corpuser".equals(moduleName) && "8".equals(userRoleStr) && corporateId != null ){			//disable links for corpuser
                	isCorporateHasDisabledLinks = linkUtil.getCorporateHasDisabledLinks(corporateId,moduleName);
                	if(isCorporateHasDisabledLinks){
	                	logger.info("<<for corpuser we are disabling some links>>");
	                	session.setAttribute("isCorporateHasDisabledLinks",isCorporateHasDisabledLinks);
            	    	for (int i = 0; i < contextRoles.length; i++) {
            				logger.info(contextRoles.length);
            				logger.info("contextRoles[" + i + "]" + contextRoles[i]);
            				logger.info("roleTypeMap :" + roleTypeMap);
            				String contextType = roleTypeMap.get(contextRoles[i]);//for user role 8 ===0|1|3|5|8|9
            				logger.info("contextType :"+contextType);
            				String contextTypes[] = contextType.split("\\|");
            				for (int j = 0; j < contextTypes.length; j++) {
            					Map<String, Object> links = linkUtil.getLinkDetails(contextRoles[i], contextTypes[j], bankCode,moduleName,corporateId);
            					logger.info("User types from commonhandler.xml:"+contextTypes[j]);
            					List<LinkDetails> tabs = (List<LinkDetails>) links.get("tabs");
            					List<String> queryIds = (List<String>) links.get("queryIds");
            					logger.info("Session tabs>>"+tabs);
            					links.remove("tabs");
            					links.remove("queryIds");
            					session.setAttribute("links" + bankCode + contextRoles[i]+ contextTypes[j], links);
            					session.setAttribute("tabs" + bankCode + contextRoles[i]+ contextTypes[j], tabs);
            					session.setAttribute("queryIds" + bankCode + contextRoles[i]+ contextTypes[j], queryIds);
            				}
            			}
                	}
                }	//disable links for corpuser ends
                
	            String displayName = (String) outParams.get(UIConstant.DISPLAY_NAME);
	            int loginCount = userProfile.getLoginCount().intValue();
	            //HttpSession session = request.getSession(true);
				logger.info("Session Creatted : " + userProfile.getUserAlias() + " : " + session.getId()+"userProfile.getLoginPwdChangedDayCount() .."+userProfile.getLoginPwdChangedDayCount());
				session.setAttribute("kitNo", outParams.get("kitNo"));//added for cr-5710
	            session.setAttribute(UIConstant.USER, userProfile);
	            session.setAttribute(UIConstant.DISPLAY_NAME, displayName);
	            session.setAttribute(UIConstant.LAST_TXN, userProfile.getLastTnameInternet());
	            session.setAttribute(UIConstant.LAST_LOGIN_DATE, userProfile.getLastLoginDate());
	            session.setAttribute(UIConstant.LAST_TXN_DATE, userProfile.getLastTDateInternet());
	            session.setAttribute(UIConstant.LAST_LOGIN_PWD_CHANGE_DATE, userProfile.getPasswordChangeDate());
	            session.setAttribute(UIConstant.LAST_LOGIN_FAILURE_DATE, userProfile.getLastLoginfailureDate());
	            session.setAttribute("bankCode", bankCode);
	            inParam.put(UIConstant.USER, userProfile);
	            Integer userRole = (Integer) userProfile.getRoles().get(0);
	            session.setAttribute("userRole", userRole); //modified for  corpuser paladion 
	            StringBuffer redirectURL = new StringBuffer();
	            
	            // SF Auth Flag for Corporate Roles
	            String SFAuthFlag = getPropertyVal("SFAuthFlag").trim();
	            session.setAttribute("SFAuthFlag", new Boolean(SFAuthFlag));
	            logger.info("getPropertyVal:::~~~~~~~"+ getPropertyVal("SFAuthFlag"));
	            
	            if (loginCount <= 0  && isRole ) {
	            	session.setAttribute("firstLoginFlag", "true"); //force change
	                logger.info("First time login for user "+userName+" :");
	                MDC.remove("username");
	                redirectURL= redirectURL.append(getPropertyVal(bankURLKey)).append(getContextPath(request)).append(getPropertyVal("firstTimeLoginAction"));
	                response.sendRedirect(redirectURL.toString());
	            } //  Added for CR 5550- Immanuel for forced login
				else if (passwordMode != null
						&& passwordMode.trim().length() > 0
						&& passwordMode.equalsIgnoreCase("K")) {
					if (userProfile.getCorporateId() != null) {
	                    Map outParam = corpProfileService.execute(inParam);
	                    CorporateProfile corporateProfile = (CorporateProfile) outParam.get("corp_profile");
	                    if(corporateProfile!=null){
	                    	session.setAttribute("corp_profile", corporateProfile);
	                        session.setAttribute("corporateName", corporateProfile.getCorporateName());
	                        loginCount=loginCount+1;	                        
	                    }
				 }
					MDC.remove("ip");
					MDC.remove("kioskID"); // Added for KiosK - CR 2914
					session.setAttribute("kLoginChangePwd", "false");
					redirectURL = redirectURL.append(getPropertyVal(bankURLKey)).append(getContextPath(request)).append(getPropertyVal("kModeLoginAction"));
					response.sendRedirect(redirectURL.toString());
					return null;
				}
				//  End of CR 5550
	    		
	            else {
	                String urlName = "role" + userRole.toString();
	                if (userProfile.getCorporateId() != null) {
	                    Map outParam = corpProfileService.execute(inParam);
	                    CorporateProfile corporateProfile = (CorporateProfile) outParam.get("corp_profile");
	                    if(corporateProfile!=null){
	                        session.setAttribute("corp_profile", corporateProfile);
	                        session.setAttribute("corporateName", corporateProfile.getCorporateName());
	                        if (userRole.intValue() == 8 || userRole.intValue() ==21) {//added for NAB
	                        	urlName = "role" + userRole.toString() + "." + userProfile.getUserType();
	                        }
	                        /*	DFBT-- Herer I am not changing any thing as we will fetch entire map,
                     			but iterating is done through the link details wont get any problem... 	*/
	                        List<String> queryIds = (List<String>)ctx.getAttribute("queryIds"+ bankCode + userProfile.getRoles().get(0)+ userProfile.getUserType());
	                        Map<String, Query> queries = (Map<String, Query>)ctx.getAttribute("queries");
	                        if(queryIds != null && queryIds.size()>0){
	                        	Map<String, String> queryValues = linkUtil.getQueryValues(queryIds, queries,userProfile,corporateProfile);
	                        	session.removeAttribute("queryValues");
	                        	session.setAttribute("queryValues", queryValues);
	                        }
	                    }else {
	                        MDC.remove("username");
	                        return new ModelAndView(viewPage,UIConstant.ERROR_MODEL, outParam);
	                    }
            	    }
                    session.setAttribute("landingURL",getPropertyVal(urlName));
                    // Mail Alert PopUp Change
                    boolean mailAlertFlag = new Boolean(getPropertyVal("mailAlertFlag."+userRoleStr));
                    session.setAttribute("mailAlertFlag",mailAlertFlag);
                    
                    //Start oF Force Login Change
                    if (passwordExpiryCheck.equals("YES")) {
                    	int countDown=loginPwdExpiryDayLimit-userProfile.getLoginPwdChangedDayCount();
                    	if (userProfile.getLoginPwdChangedDayCount() >= Integer
								.valueOf(getPropertyVal("priorInfoPeriod"))&& userProfile.getLoginPwdChangedDayCount() < loginPwdExpiryDayLimit) {
							session.setAttribute("priorInfoPeriodFlag", "true");
							session.setAttribute("forceChangePwdCountDown", countDown);
							urlName = "login_pwd_change_display";
						}
                    	else if (userProfile.getLoginPwdChangedDayCount() >= loginPwdExpiryDayLimit){
                    		boolean isGracePeriod=StringUtils.compareDateWithToday(loginGracePeriod, "dd-MM-yyyy", "before");
    						if(isGracePeriod) {
    							countDown=(int)StringUtils.dateDifferenceInDays(loginGracePeriod,"dd-MM-yyyy", new Date());
    							countDown+=1;
    							session.setAttribute("forceChangePwdCountDown", countDown);
    							session.setAttribute("priorInfoPeriodFlag", "true");
    							urlName = "login_pwd_change_display";
    						}
    						else {
    							urlName = "force_login_pwd_change";
    							session.setAttribute("forceChangeFlag", "true");
    							session.setAttribute("loginPwdExpiryDayLimit",loginPwdExpiryDayLimit);
    						  }
						} 
					}
                    //End oF Force Login Change
                    
                    redirectURL = redirectURL.append(getPropertyVal(bankURLKey)).append(getContextPath(request)).append(getPropertyVal(urlName));	
                    //redirectURL = redirectURL.append(getPropertyVal(bankURLKey)).append(getPropertyVal(urlName));
                    MDC.remove("username");
                    //ADDED FOR CR 5266 STARTS (corpuser)                    
                    if(userRoleStr.equals("8") || userRoleStr.equals("7") || userRoleStr.equals("13")){
                    	
                    	if(userProfile.getProfilepassword()==null || userProfile.getProfilepassword().equals("reset")){
                    		 logger.info("userProfile.getProfilepassword for user.. "+userProfile.getProfilepassword());
                    		 session.setAttribute("profilePWDStatus", "false");
                    		getServletContext().getRequestDispatcher("/setpassword.htm").forward(request, response);
                    		return null;
                    	}
						if(userProfile.getProfilepassword()!=null&&userProfile.getProfilepassword().equals("reset")){
							session.setAttribute("profilePWDStatus", "false");
						}
						if(userProfile.getTxnPassword()!=null&&userProfile.getTxnPassword().equals("reset")){
							session.setAttribute("txnPWDStatus", "false");                    	
						}
                    }
                    logger.info("redirectURL val.. "+redirectURL);
                    //ADDED FOR CR 5266 ENDS
                    response.sendRedirect(redirectURL.toString());
                    return null;
                }
            }
            else {
            	
            	keyString  = rndString.getRamdom();//Nag - added for 5034 
                logger.info("keyString~~~~~~~"+keyString );//Nag - added for 5034
                outParams.put("keyString", keyString);
				outParams.put("userName", userName);
               logger.info("Returned to Login Page with Error"+outParams); 
               MDC.remove("username");
                return new ModelAndView(viewPage, UIConstant.ERROR_MODEL, outParams);
            
            }
        }
        logger.info("logInSubmit(HttpServletRequest req, HttpServletResponse res) end");
        return new ModelAndView(UIConstant.LOGIN_PAGE, UIConstant.SUCCESS, outParams);
    }

    /**
     * Logout page
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     *  ModelAndView
     */
    public ModelAndView logOutHandler(HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession(false);
        if (session != null)
        	session.invalidate();
            
        return new ModelAndView("logoutLayout");
    }

    /**
     * 
     * @param logonService
     *  void
     */
    public void setLogonService(BaseService logonService) {
        this.logonService = logonService;
    }

    /**
     * @param jstlConstants
     *            The jstlConstants to set.
     */
    public void setConstants(JSTLConstants constants) {
        this.constants = constants;
    }

    /**
     * @param referenceDataCache
     *            The referenceDataCache to set.
     */
    public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
        this.referenceDataCache = referenceDataCache;
    }

    /**
     * @param logonProperty
     *            The logonProperty to set.
     */
    public void setLogonProperty(ResourceBundleMessageSource logonProperty) {
        this.logonProperty = logonProperty;
    }

    public void setCorpProfileService(BaseService corpProfileService) {
        this.corpProfileService = corpProfileService;
    }

	
     // referer check - starts
    public ModelAndView nullRefererenceDiplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.info("Null Referer");
        String value ="nullReferer";
        return new ModelAndView("nullReferer","fromJsp",value);

    }
    
    /* This method gets the context path from request*/
	public static String getContextPath(HttpServletRequest request)
	{
		String contextpath=request.getContextPath().substring(1);
		return contextpath;
	}
    
    public static String getModuleName(HttpServletRequest request)
    {
         String contextpath=request.getContextPath().substring(1);
        return contextpath;
    }
    
	public void setLinkUtil(LinkUtil linkUtil) {
		this.linkUtil = linkUtil;
	}
	
	public void setCorpRoles(String corpRoles) {
			this.corpRoles = corpRoles;
		}

	public void setRoleTypeMap(Map<String, String> roleTypeMap) {
		this.roleTypeMap = roleTypeMap;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	//CR-5550
	
	
	public void setRndString(RndString rndString) {
		this.rndString = rndString;
	}

    public void setPasswordExpiryCheck(String passwordExpiryCheck){
		this.passwordExpiryCheck=passwordExpiryCheck;
	}
  private String getPropertyVal(String key){
	  String value ="";
	  try {
  		logger.info("key val :"+key);
      	 value=logonProperty.getMessage(key, null, null);
       }
	  catch (NoSuchMessageException ex) {
          logger.error("NoSuchMessageException occured" ,ex );
       }	
      return value;
	}
	//CR 5550 ends
}