
/*
 *CR-1884
 */
//History
//sn27223

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;




public class CoreOffLineMessageHandler implements Controller{
	
	private BaseService coreOffLineMessageService;
	
	
    protected final Logger logger=Logger.getLogger(getClass());
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	logger.info("handleRequest(HttpServletRequest request, HttpServletResponse response) -begin");
        Map outParams=new HashMap();
        Map inParams = new HashMap();
         HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        String bankCode = request.getHeader("BankCode");
        String userRoleAndType = "USER_ROLE_"+user.getRoles().get(0)+"_TYPE_"+user.getUserType(); // for SCFU applications
        logger.info("bankCode 1::="+bankCode + " userRoleAndType ::"+userRoleAndType);
        
        if (StringUtils.isBlank(bankCode)) {
        	 bankCode = user.getBankCode();
         }
        logger.info("bankCode 2="+bankCode); 
        
        inParams.put(UIConstant.BANK_CODE,bankCode);
        inParams.put(UIConstant.USER_ROLE, userRoleAndType);
        outParams = coreOffLineMessageService.execute(inParams);        
        logger.info("handleRequest(HttpServletRequest request, HttpServletResponse response) -end");
        return new ModelAndView("coreofflinemsg",UIConstant.OUTPARAM,outParams);
    }
	public void setCoreOffLineMessageService(BaseService coreOffLineMessageService) {
		this.coreOffLineMessageService = coreOffLineMessageService;
	}
   

}
