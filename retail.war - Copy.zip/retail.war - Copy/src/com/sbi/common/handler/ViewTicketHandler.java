package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.Ticket;
import com.sbi.common.model.TicketThread;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.DeleteTicketDetailsService;
import com.sbi.common.service.MarkUnreadService;
import com.sbi.common.service.UpdateTicketDetailsService;
import com.sbi.common.service.ViewMailService;
import com.sbi.common.service.ViewTicketDetailsService;
import com.sbi.common.service.ViewTicketService;

public class ViewTicketHandler extends MultiActionController{
	
	private Logger logger = Logger.getLogger(getClass());
	
	BaseService viewTicketService;

	BaseService viewTicketDetailsService;

	BaseService updateTicketDetailsService;

	BaseService deleteTicketDetailsService;
	
	BaseService markUnreadService;
	
	BaseService viewMailService;
	
	BaseService updateMailreadStatus; 
	
	BaseService viewMailServiceForAssociateBank;


	public ModelAndView displayTicketInbox(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("displayInbox(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		String ticketType = null;
		HttpSession session=request.getSession(false);
		String requestUrl = request.getServletPath();
		if ("/viewclosedtickets.htm".equals(requestUrl)) {
			ticketType = "closedTickets";
			inParam.put("ticketType", ticketType);
		}
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		inParam.put("coprorateID", user.getCorporateId());
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		outParam=viewTicketService.execute(inParam);
		outParam.put("ticketType",ticketType);
		
		logger.info("displayInbox(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.VIEW_TICKETS,UIConstant.OUTPARAM,outParam);
	}
	
	public ModelAndView viewTicketDetails(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("viewTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession(false);
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		String ticketNo=(String)request.getParameter("ticketNo");
		inParam.put("userName",user.getUserAlias());
		inParam.put("ticketNo", ticketNo);
		String workFlowState = (String) request.getParameter("workFlowState");
		inParam.put("workFlowState", workFlowState);
		inParam.put("ticketNo", ticketNo);
		outParam=viewTicketDetailsService.execute(inParam);
		outParam.put("ticketNo", ticketNo);
		outParam.put("workFlowState", workFlowState);
		outParam.put("name", request.getParameter("name"));
		outParam.put("userName",request.getParameter("userName"));
		outParam.put("issueNature", request.getParameter("issueNature"));
		outParam.put("creationTime",request.getParameter("creationTime"));
		outParam.put("workFlowState", request.getParameter("workFlowState"));
		outParam.put("status", request.getParameter("status"));
		outParam.put("emailId",user.getEmail());
		outParam.put("ticketType",request.getParameter("ticketType"));
		
		logger.info("viewTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.VIEW_TICKETS_DETAILS,UIConstant.OUTPARAM,outParam);
	}
	
	public ModelAndView updateTicketDetails(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("updateTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession(false);
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		int workFlowState=Integer.parseInt(request.getParameter("issueStatus"));
		String information=(String)request.getParameter("information");
		String ticketNo=(String)request.getParameter("ticketNo");
		if(information!=null){
			String newLine = "\n";
			String curregeReturn ="\r";
			information = information.replaceAll(newLine," ").replaceAll(curregeReturn," ").replaceAll("'"," ");
		}
		Ticket ticket=new Ticket();
		ticket.setWorkFlowState(workFlowState);
		ticket.setTicketNo((String)request.getParameter("ticketNo"));
		ticket.setUserName(user.getUserAlias());
		TicketThread ticketThread=new TicketThread();
		ticketThread.setTicketNo(ticketNo);
		ticketThread.setThread_originator(user.getUserAlias());
		ticketThread.setThread(information);
		ticket.setTicketThread(ticketThread);
		inParam.put("ticket", ticket);
		
		outParam=updateTicketDetailsService.execute(inParam);
		outParam.put("ticketNo", ticketNo);
		if(workFlowState==110)
		outParam.put("status", "closed");
		if(workFlowState==109)
			outParam.put("status", "updated");
		
		
		logger.info("updateTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.UPDATE_TICKET_CONFIRM,UIConstant.OUTPARAM,outParam);
	}
	
	public ModelAndView deleteTicketDetails(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("deleteTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		String[] ticketList=request.getParameterValues("mailReference");
		HttpSession session=request.getSession(false);
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		inParam.put("ticketList", ticketList);
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		outParam=deleteTicketDetailsService.execute(inParam);
		String result=(String)outParam.get("result");
		if(result!=null && result.equals("success"));
		{
			
			inParam.put("coprorateID", user.getCorporateId());
			CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
			inParam.put("smallFlag", corporateProfile.getSmallFlag());			
			outParam=viewMailService.execute(inParam);
		}
		logger.info("deleteTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.VIEW_MAILS,UIConstant.OUTPARAM,outParam);
	}

	public ModelAndView markAsUnread(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("markAsUnread(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession(false);
		String mailflag=(String)request.getParameter("mailFlag");
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		inParam.put("userName",user.getUserAlias());
		String view  = UIConstant.VIEW_TICKETS;
		String[] selectedList=null;
		if("mail".equals(mailflag)){
			selectedList=request.getParameterValues("mailReference");
			inParam.put("mailflag", mailflag);
			view = UIConstant.VIEW_MAILS;
		}	
		else{
			selectedList=request.getParameterValues("ticketNo");
		}	
		inParam.put("selectedList", selectedList);
		outParam=markUnreadService.execute(inParam);
		String result=(String)outParam.get("result");
		if(result!=null && result.equals("success"));
		{
			if("mail".equals(mailflag)){
				inParam.put("coprorateID", user.getCorporateId());
				CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
				inParam.put("smallFlag", corporateProfile.getSmallFlag());			
				outParam=viewMailService.execute(inParam);
			}else{
				outParam=viewTicketService.execute(inParam);
			}	
		}
		logger.info("markAsUnread(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(view,UIConstant.OUTPARAM,outParam);
	}

	
public ModelAndView displayMailInbox(HttpServletRequest request,HttpServletResponse response){
		
		logger.info("displayInbox(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession(false);
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		/*..For Associate Bank MailBox Enable..start*/
		inParam.put("bankCode",user.getBankCode());
		logger.info("Bank Code:"+user.getBankCode());
		String contextName=request.getContextPath();
		
		/*..For Associate Bank MailBox Enable..end*/
		inParam.put("coprorateID", user.getCorporateId());
		inParam.put(UIConstant.USER_NAME, user.getUserAlias());
		CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
		inParam.put("smallFlag", corporateProfile.getSmallFlag());
		if(contextName.contains("corpuser")||contextName.contains("corpadmin")||contextName.contains("corpreg")){
			/*..For Associate Bank MailBox Enable..start*/
			System.out.println("contextName:"+contextName);
			outParam=viewMailServiceForAssociateBank.execute(inParam);
			/*..For Associate Bank MailBox Enable..end*/
		}
		else{
			outParam=viewMailService.execute(inParam);
		}
		
		logger.info("displayInbox(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.VIEW_MAILS,UIConstant.OUTPARAM,outParam);
	}

	public ModelAndView viewMailDetails(HttpServletRequest request,HttpServletResponse response){
	
	logger.info("viewTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
	
	Map inParam = new HashMap();
	Map outParam=new HashMap();
	HttpSession session=request.getSession(false);
	UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
	String mailReference=(String)request.getParameter("mailReference");
	inParam.put("userName",user.getUserAlias());
	inParam.put("mailReference", mailReference);
	outParam=updateMailreadStatus.execute(inParam);
	outParam.put("mailReference", request.getParameter("mailReference"));
	outParam.put("workFlowState", request.getParameter("workFlowState"));
	outParam.put("fromId", request.getParameter("fromId"));
	outParam.put("subject",request.getParameter("subject"));
	outParam.put("message", outParam.get("mailDescription"));
	outParam.put("creationTime",request.getParameter("creationTime"));
	
	logger.info("viewTicketDetails(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
	return new ModelAndView(UIConstant.VIEW_TICKETS_DETAILS,UIConstant.OUTPARAM,outParam);
}
	public ModelAndView displayAboutCareHandler(HttpServletRequest request, HttpServletResponse response){
        logger.debug("displayAboutCareHandler(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        String viewName = "customerCarehelppage";
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.debug("displayDefaultPage(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);
        return new ModelAndView(viewName,UIConstant.MODEL,outParams);
    }
	

	public void setMarkUnreadService(MarkUnreadService markUnreadService) {
		this.markUnreadService = markUnreadService;
	}

	public void setDeleteTicketDetailsService(DeleteTicketDetailsService deleteTicketDetailsService) {
	this.deleteTicketDetailsService = deleteTicketDetailsService;
}

	public void setUpdateTicketDetailsService(UpdateTicketDetailsService updateTicketDetailsService) {
		this.updateTicketDetailsService = updateTicketDetailsService;
	}

	public void setViewTicketDetailsService(ViewTicketDetailsService viewTicketDetailsService) {
		this.viewTicketDetailsService = viewTicketDetailsService;
	}
	
	public void setViewTicketService(ViewTicketService viewTicketService) {
		this.viewTicketService = viewTicketService;
	}
	
	public void setViewMailService(ViewMailService viewMailService) {
		this.viewMailService = viewMailService;
	}

	public void setUpdateMailreadStatus(BaseService updateMailreadStatus) {
		this.updateMailreadStatus = updateMailreadStatus;
	}

	public void setViewMailServiceForAssociateBank(
			BaseService viewMailServiceForAssociateBank) {
		this.viewMailServiceForAssociateBank = viewMailServiceForAssociateBank;
	}
	
}
