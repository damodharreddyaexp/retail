/*
 * SessionListener.java
 * Created on Nov 2, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History
//Nov 2, 2005 MURUGAN K - Initial Creation
// MARCH 19, 2010 - PONNUSAMY G -userDAOImpl bean is used to delete the logged in user details from sbi_loggedin_users table.
package com.sbi.common.handler;
 
/**
 * Session listener
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

import javax.servlet.http.*;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.model.User;
import org.apache.log4j.Logger;

/**
 * TODO Enter the description of the class here 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class SessionListener implements HttpSessionListener
{
    protected final Logger logger = Logger.getLogger(getClass());    
    private UserSessionCache userSessionCache;
    private UserDAO userDAOImpl;
    public void sessionCreated(HttpSessionEvent event)
    {
        if(event.getSession() != null)
            logger.info("Session created : " + event.getSession().getId());
        else
            logger.info("Session not created : " + event.getSession());
    }
 
    public void sessionDestroyed(HttpSessionEvent event)
    {
        HttpSession session = event.getSession();
        if(session != null)
        {
            logger.info("Session destroyed : " + event.getSession().getId());
        
            WebApplicationContext webAppCtxt = WebApplicationContextUtils.getWebApplicationContext(event.getSession()
                    .getServletContext());
            userSessionCache = (UserSessionCache) webAppCtxt.getBean("userSessionCache");
            userDAOImpl = (UserDAO)webAppCtxt.getBean("userDAOImpl");
            User user = (User) session.getAttribute("user");
			
            if(user != null && userSessionCache != null)
            {
				logger.info("Session destroyyyed : " + user.getUserAlias() + " : " + event.getSession().getId());
                String userName = user.getUserAlias();
                logger.info("User name : " + userName);
                userSessionCache.removeData(userName + "_Accounts");
                userSessionCache.removeData(userName + "_Profile");
                userSessionCache.removeData(userName + "TransactionHistory");
                logger.info("Accounts in UseSession Cache for " + userName + ":"
                        + userSessionCache.getData(userName + "_Accounts"));
                logger.info("User Profile in UseSession Cache for " + userName + ":"
                        + userSessionCache.getData(userName + UIConstant.USER_PROFILE));
                userSessionCache.removeData(userName+ "_branchList");
                userSessionCache.removeData(userName+"bmAccounts");
            }
            if(user!=null){
            	userDAOImpl.deleteActiveUserLogin(user.getUserAlias());//Added For CR 5405
            }
        }
    }

} 