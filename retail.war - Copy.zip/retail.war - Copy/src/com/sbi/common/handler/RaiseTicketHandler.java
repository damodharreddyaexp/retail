package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.model.Ticket;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.RaiseTicketService;
import com.sbi.common.handler.UIConstant;

public class RaiseTicketHandler extends MultiActionController{

	private Logger logger = Logger.getLogger(getClass());
	
	RaiseTicketService raiseTicketService;
	
	public ModelAndView raiseTicket(HttpServletRequest request,HttpServletResponse response){
		logger.info("raiseTicket(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		
		Map inParam = new HashMap();
		Map outParam=new HashMap();
		HttpSession session=request.getSession();
		UserProfile user=(UserProfile)session.getAttribute(UIConstant.USER);
		
		inParam.put(UIConstant.ISSUE_CODE,request.getParameter(UIConstant.ISSUE_CODE));
		String desc=(String)request.getParameter(UIConstant.DESCRIPTION);
		if(desc!=null){
			String newLine = "\n";
			String curregeReturn ="\r";
			desc = desc.replaceAll(newLine," ").replaceAll(curregeReturn," ").replaceAll("'"," ");
		}
		inParam.put(UIConstant.DESCRIPTION,desc);
		inParam.put(UIConstant.USER,user);
		inParam.put("issueDescription",request.getParameter("issueDescription"));
		
			
		
		
		outParam=raiseTicketService.execute(inParam);
		outParam.put("emailId", user.getEmail());
		
		
		logger.info("raiseTicket(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView(UIConstant.COMPOSE_ISSUE_CONFIRM,UIConstant.OUTPARAM,outParam);
	}

	public void setRaiseTicketService(RaiseTicketService raiseTicketService) {
		this.raiseTicketService = raiseTicketService;
	}
	
	
	 
}
