package com.sbi.common.handler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.handler.UIConstant;

public class DownloadBenificiariesListHandler  extends MultiActionController
{

	protected final Logger logger = Logger.getLogger(getClass());
	private BaseService downloadBenificiariesListService;
	
	private String thirdpartyFilePath;
    
    public String getThirdpartyFilePath() {
		return thirdpartyFilePath;
	}
	public void setThirdpartyFilePath(String thirdpartyFilePath) {
		this.thirdpartyFilePath = thirdpartyFilePath;
	}
    
	
	public ModelAndView request3PFile(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("request3PFile() method begins");
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		User user=(User)session.getAttribute("user");
		String corporateId = user.getCorporateId();
	    logger.info("corporateId--->"+corporateId);
	    inputParams.put("corporateId", corporateId);
	    inputParams.put("type", "checkRegEligible");
        if(corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim())){
        	outputParams = downloadBenificiariesListService.execute(inputParams);
       }	
        
		outputParams.put(UIConstant.ERROR_VIEW, "requestfileerror");
		logger.info("request3PFile() method end");
		return new ModelAndView("request3Pfile", "downloadParams",outputParams);
		
         }
    
	
	 public ModelAndView generateRequestIdFor3PFile(HttpServletRequest request,
	    		HttpServletResponse response) {
	    	        logger.info("generateRequestIdForFile() method begins");
					SBIApplicationResponse applnresponse=new SBIApplicationResponse();
	    	        Map inparam = new HashMap();
	    	        Map outputParams = new HashMap();
				    HttpSession session = request.getSession(false);
				    User user = (User) session.getAttribute(UIConstant.USER);
				    String userName = (String) user.getUserAlias();
	    	        String corporateId = user.getCorporateId();
					String banktype = request.getParameter("bankval");
					
					String formatType = request.getParameter("formatType");
					String adminNeeded=request.getParameter("adminNeeded");
					logger.info("adminNeeded-->"+adminNeeded);
					
					 inparam.put("formatType", formatType);
					
					
					
					String regulatorSelected=request.getParameter("regulatorToSelect");
					String adminSelected=request.getParameter("adminToSelect");
					//String approverSelected[]=request.getParameterValues("approverToSelect");
					String userRequested=request.getParameter("userRequested");
					String approverSelected[]=request.getParameterValues("approver");
					String finalApproverSelected="";
					
					if(null!=approverSelected){
						if(approverSelected.length==1)
						{
							finalApproverSelected=approverSelected[0];
						}else{
						for(int i=0;i<approverSelected.length;i++){
							logger.info(i+"-->"+approverSelected[i]);
							finalApproverSelected=finalApproverSelected+approverSelected[i]+",";
						}
						logger.info("approvers selected length -->"+finalApproverSelected.length());
						finalApproverSelected=finalApproverSelected.substring(0,finalApproverSelected.length()-1);
						}
						
					}
					logger.info("regulatorSelected-->"+regulatorSelected);
					logger.info("adminSelected-->"+adminSelected);
					logger.info("approverSelected-->"+finalApproverSelected);
					logger.info("userRequested-->"+userRequested);
					
					
					if(!regulatorSelected.equalsIgnoreCase("")){
						inparam.put("requestedBy", regulatorSelected);
					}
					
					if(!adminSelected.equalsIgnoreCase("")){
						if(!finalApproverSelected.equalsIgnoreCase("")){
							
							if(userRequested.trim().equalsIgnoreCase("ADM")){
								inparam.put("requestedBy", adminSelected);
							}
							else if(userRequested.trim().equalsIgnoreCase("APR")){
								inparam.put("requestedBy", finalApproverSelected);
							}
							
							///////
							
							if(null==adminNeeded)
							{
								//need to get both admin and approver beneficiaries
								inparam.put("requestedBy", adminSelected+","+finalApproverSelected);
							}else{
							//	if(adminNeeded.replaceAll(" ", "").equalsIgnoreCase("on")){
									//shouldnt get admin approved beneficiaries
									inparam.put("requestedBy", finalApproverSelected);
							//	}
							}
							
							
							
							
							
							/*if(adminNeeded.replaceAll(" ", "").equalsIgnoreCase("on")){
								//shouldnt get admin approved beneficiaries
								inparam.put("requestedBy", finalApproverSelected);
							}else{
								//need to get both admin and approver beneficiaries
								inparam.put("requestedBy", adminSelected+","+finalApproverSelected);
							}*/
							
							///////
							
							
							
							
							
						}
						else{
							inparam.put("requestedBy", adminSelected);
						}
					}
					
					logger.info("requestedBy :" +inparam.get("requestedBy"));
					
					inparam.put("type", "downloadfile");
					inparam.put("userName", user.getUserAlias());
	    	        inparam.put("corporateId", corporateId);
					inparam.put("banktype", banktype);
					outputParams = downloadBenificiariesListService.execute(inparam);
					String requestId=(String)outputParams.get("requestId");
					logger.info("requestId :" +requestId);
					outputParams.put(UIConstant.ERROR_VIEW, "requestfileerror");
	    	        logger.info("outputParams at request is " + outputParams);
					logger.info("generateRequestIdFor3PFile() method ends");
	    	        return new ModelAndView("displayrequestId", "requestIdModel", outputParams);
	    }
	 
	 public ModelAndView download3Pfile(HttpServletRequest request,
	    		HttpServletResponse response) {
	    			logger.info("download3Pfile method begins");
	    			  Map inparam = new HashMap();
	    			  Map outputParams = new HashMap();
	    			  Map outMap = new HashMap();
	    			  HttpSession session = request.getSession(false);
					  User user = (User) session.getAttribute(UIConstant.USER);
					  String userName = (String) user.getUserAlias();
	    			  inparam.put("userName",userName);
	    			  logger.info(" user.getUserAlias():" + user.getUserAlias());
	    			  inparam.put("type", "viewBenFilestatus");
	    			  outMap = downloadBenificiariesListService.execute(inparam);
	    			  outputParams.put("benMap", outMap); 
	    			  outputParams.put(UIConstant.ERROR_VIEW, "downloadfileerror"); 
	    			logger.info("download3Pfile method ends");
	    			return new ModelAndView("viewdownload3Pfilestatus", "viewEchequeDisplay" ,outputParams);
	    		}
	 
	 
	 public ModelAndView download3PFileBasedReportForUploader(HttpServletRequest request,
	    		HttpServletResponse response) {
	    			logger.info("download3PFileBasedReportForUploader method begins");
	    			   Map inparam = new HashMap();
	    			Map outputParams = new HashMap();
	    			 SBIApplicationResponse applnresponse=new SBIApplicationResponse();
	    			   HttpSession session = request.getSession(false);
	    			   User user = (User) session.getAttribute(UIConstant.USER);
						  String userName = (String) user.getUserAlias();
	    			 try
	    	    		{
	    	    			//String fileName=request.getParameter("requestId");
	    				  String fileName=request.getParameter("filename");
	    				  logger.info("fileName to download:::"+fileName);
	    	    			String filepath=thirdpartyFilePath;  
	    	    			logger.info(filepath);
	    	    		//InputStream bis = new FileInputStream(reportFilePath+fileName+".xls");
	    	    			InputStream bis = new FileInputStream(thirdpartyFilePath+fileName);
	    	    		
	    	    		response.reset();
	    	    		response.setContentType("text/csv");
	    	    		//response.setHeader("Content-disposition","attachment; filename=" +fileName+".xls");
	    	    		response.setHeader("Content-disposition","attachment; filename=" +fileName);
	    	    		byte[] buf = new byte[1024];
	    	    		int len;
	    	    		while ((len = bis.read(buf)) > 0){
	    	    		response.getOutputStream().write(buf, 0, len);
	    	    		}
	    	    		bis.close();
	    	    		response.getOutputStream().flush();
	    	    		}
	    			 catch(FileNotFoundException ex)
	    	    	      {
	    				 logger.info("test failed no file found:"+ex);
	    	                applnresponse.setErrorStatus(UIConstant.FAILURE);
	    	                applnresponse.setErrorCode("ECS009");
	    	                outputParams.put(UIConstant.APPLICATION_RESPONSE,applnresponse);
	        	    		return new ModelAndView("errorQuerybyeCheque", "errorQuerybyeCheque" ,outputParams);
	    	                
	    	         }
 	    		catch(Exception e){
	    	    		e.printStackTrace();
	    	    	}
	    	    		logger.info("download3PFileBasedReportForUploader method ends");
   	    		return null;
	    		}
	 


	public void setDownloadBenificiariesListService(
			BaseService downloadBenificiariesListService) {
		this.downloadBenificiariesListService = downloadBenificiariesListService;
	}
	 
	
}
