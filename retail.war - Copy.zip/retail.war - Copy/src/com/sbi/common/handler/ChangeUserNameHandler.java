
/*
 * ChangeUserName.java
 * Created on Feb 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 1, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.handler;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.authentication.algorithm.Sha512Hashing;
import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.utils.RndString;
import com.sbi.common.utils.EncryptMD5;

public class ChangeUserNameHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService findUserService;
    
    private Sha512Hashing sha512Hashing; //Added for sha
    
    private BaseService firstLogonService;
    
    private UserSessionCache userSessionCache;
    //Start CR-5550
    private String kpageUrl; 
    private RndString rndString;
    private BaseService changeKLoginPwdService; 
    //  End of CR 5550 - Immanuel- Forced login
    /**
     * @param userSessionCache The userSessionCache to set.
     */
    public void setUserSessionCache(UserSessionCache userSessionCache)
    {
        this.userSessionCache = userSessionCache;
    }
    public ModelAndView modifyUserName(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("inside modifyUserName");
       //referer check - starts - Added by Indira
       if(isRefererNull(request)){
           try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                logger.info("Exception occur in ChangeUserNameHandler : "
                        + ex.getMessage());
            }
            return null;
       }
       //referer check - ends
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        return new ModelAndView(UIConstant.CHANGE_USER_NAME,UIConstant.MODEL,outParams);
    }
    public ModelAndView modifyPassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        logger.info("modifyPassword(HttpServletRequest request, HttpServletResponse response) - begin");
        //referer check - starts - Added by Indira
        if(isRefererNull(request)){
            try{
                request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
             }catch (Exception ex) {
                 ex.printStackTrace();
                 logger.info("Exception occur in ChangeUserNameHandler : "
                         + ex.getMessage());
             }
             return null;
        }
        //referer check - ends
        Map outParams = new HashMap();
        Map inParams = new HashMap();
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        String oldUserName = user.getUserAlias() ;
        String userName = (String)request.getParameter(UIConstant.USER_NAME);
      //added for cr-5710        
        String ppKitNo = (String) session.getAttribute("kitNo");
        String userEnterKitNo = (String)request.getParameter("userEnterKitNo");
        inParams.put(UIConstant.USER_NAME,userName);
        inParams.put(UIConstant.OLD_USER_NAME,oldUserName);
        inParams.put("ppKitNo",ppKitNo);
        inParams.put("userEnterKitNo",userEnterKitNo);
        outParams = findUserService.execute(inParams);
        SBIApplicationResponse applicationResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
        outParams.put(UIConstant.USER_NAME,userName);
        String viewName;
        if(applicationResponse.getErrorStatus().equals(UIConstant.SUCCESS)){
            viewName = UIConstant.CHANGE_PASSWORD;
            
        }
        else
            viewName = UIConstant.CHANGE_USER_NAME;
        logger.info("modifyPassword(HttpServletRequest request, HttpServletResponse response) - end");
        return new ModelAndView(viewName,UIConstant.ERROR_MODEL,outParams);
    }
    public ModelAndView updatePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        logger.info("inside updatePassword");
        //      referer check - starts - Added by Indira
        String keyString="";
        if(isRefererNull(request)){
            try{
                request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
             }catch (Exception ex) {
                 ex.printStackTrace();
                 logger.info("Exception occur in ChangeUserNameHandler : "
                         + ex.getMessage());
             }
             return null;
        }
        //referer check - ends
        Map outParams = new HashMap();
        Map inParams = new HashMap();
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = user.getUserAlias() ;
        String newUserName = (String)request.getParameter(UIConstant.USER_NAME);
        String password = (String)request.getParameter(UIConstant.PASSWORD);
        String keyid = request.getParameter("keyid");
        logger.info("keyid::"+keyid);
        //added for CR 5034 - begin
		String sessionId = session.getId();
		keyString=rndString.getKey(sessionId,true);//added for CR 5034 - gettting the salt [key] using session id.
		if(keyString==null)
		{
			keyString=(String) session.getAttribute("keyid");
		}
		logger.info("sessionId::"+sessionId);
		//added for CR 5034 - end
		 //inParams.put("keyid",request.getParameter("keyid"));//added for cr-2609
		 
		logger.info("keyString::"+keyString);
        inParams.put("keyid",keyid);//modified for CR 5034  
        inParams.put("keyString",keyString);//modified for CR 5034     
        inParams.put(UIConstant.NEW_USER_NAME,newUserName);
        inParams.put(UIConstant.USER_NAME,userName);
        inParams.put(UIConstant.PASSWORD,password);
        logger.info("inparams::"+inParams);
        outParams = firstLogonService.execute(inParams);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
        logger.info("outParams:::"+outParams+"errRes::"+errorResponse);
        if(errorResponse.getErrorStatus().equalsIgnoreCase(UIConstant.SUCCESS))
        {
        	//Nag - added for 5034 start
        	String plainpassword=(String)outParams.get("password");
        	keyString  = rndString.getRamdom();
            String md5keypassword = EncryptMD5.hashMessage(EncryptMD5.hashMessage(newUserName+"#"+plainpassword)+"#"+keyString);//by nag
            String sha2password = sha512Hashing.hashingSHA2(sha512Hashing.hashingSHA2(newUserName+"#"+plainpassword)+"#"+keyString);// Added for SHA encryption algorithm
            request.setAttribute("userName", newUserName);
            request.setAttribute("password", md5keypassword);
      		request.setAttribute(UIConstant.SHA2_PASSWORD, sha2password);// Added for SHA encryption algorithm
      
            request.setAttribute("keyString", keyString);
            session.removeAttribute("firstLoginFlag");
            //response.sendRedirect(redirectURL);
            //Nag - added for 5034 end
            userSessionCache.removeData((user.getUserAlias()+ UIConstant.USER_PROFILE));
			getServletContext().getRequestDispatcher("/loginsubmit.htm").forward(request,response);
        }
        //ON SUCCESS REPLACE OLD USER NAME WITH NEW USER NAME 
        outParams.put(UIConstant.USER_NAME,newUserName);
        String viewName=UIConstant.CHANGE_PASSWORD;
        logger.info("Error code..:"+errorResponse.getErrorCode());
        String errorCode=errorResponse.getErrorCode();
        if(errorCode!=null && errorCode.equals("DAOE010"))//null check added.
            viewName = UIConstant.CHANGE_USER_NAME;
       
        return new ModelAndView(viewName,UIConstant.ERROR_MODEL,outParams);
    } 
    /**
     * @param findUserService The findUserService to set.
     */
    public void setFindUserService(BaseService findUserService)
    {
        this.findUserService = findUserService;
    }
    /**
     * @param firstLogonService The firstLogonService to set.
     */
    public void setFirstLogonService(BaseService firstLogonService)
    {
        this.firstLogonService = firstLogonService;
    }
   
    
    //referer check - starts - Added by Indira
    private boolean isRefererNull(HttpServletRequest request) {
        //Referer check - starts
        HttpSession session = request.getSession(false);
        String refervalue = request.getHeader("referer");
        boolean isrefererNull=false;
        if (refervalue== null) {
            logger.info("referer is null");
            if (session != null)
                session.invalidate();
            isrefererNull=true;
        }
        return isrefererNull;

    }
    //referer check - ends
    
    
    //  Added for CR 5550
    public ModelAndView changeKLoginPwd(HttpServletRequest request, HttpServletResponse response) throws Exception{
        logger.info("ModelAndView changeKLoginPwd(HttpServletRequest request, HttpServletResponse response) method begins");
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("ModelAndView changeKLoginPwd(HttpServletRequest request, HttpServletResponse response) method ends");
        return new ModelAndView(UIConstant.CHANGE_KLOGIN_PWD,UIConstant.MODEL,outParams);       
    }
    
    public ModelAndView updateKLoginPwd (HttpServletRequest request, HttpServletResponse response) throws Exception{
        logger.info("ModelAndView updateKLoginPwd (HttpServletRequest request, HttpServletResponse response) method begins");
        Map outParams = new HashMap();
        Map inParams = new HashMap();
        String view=UIConstant.MY_PAGE;
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        //String userIPaddress = request.getRemoteAddr();
        //Shanta
        String userIPaddress = request.getHeader("ClientIP"); 
        logger.info("Client IP from header : " + userIPaddress); 
     
        //shanta
        inParams.put(UIConstant.IP_ADDRESS, userIPaddress);
        String userName = user.getUserAlias() ;  
        String password = (String)request.getParameter(UIConstant.PASSWORD);
        String keyid = request.getParameter("keyid");//added for cr-2609
        String keyString = request.getParameter("keyString");
		String sessionId = session.getId();
		 //String md5Key = rndString.getRamdom(session.getId());
		//String keyString=rndString.getKey(sessionId,true);//added for CR 5034 - gettting the salt [key] using session id.
		//added for CR 5034 - end
		inParams.put(UIConstant.USER_NAME,userName);
        inParams.put(UIConstant.PASSWORD,password);
        inParams.put("keyid",request.getParameter("keyid"));
        inParams.put("keyString",keyString);//modified for CR 5034
        outParams = changeKLoginPwdService.execute(inParams);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		 if(errorResponse.getErrorStatus().equalsIgnoreCase(UIConstant.SUCCESS)){            
            session.removeAttribute("kLoginChangePwd");
            userSessionCache.removeData((user.getUserAlias()+ UIConstant.USER_PROFILE));
            
            Integer userRole = (Integer) user.getRoles().get(0);
            if(userRole==42) {
            	logger.info("KPAGE URL = /corpapprviewinboxlanding.htm");
	            getServletContext().getRequestDispatcher("/corpapprviewinboxlanding.htm").forward(request,response);
            }
            else {
	            logger.info("KPAGE URL"+kpageUrl);
	            getServletContext().getRequestDispatcher(kpageUrl).forward(request,response);//modified for CR 5034
            }
            return null;
        }else if (errorResponse.getErrorStatus().equalsIgnoreCase(UIConstant.FAILURE)){
        	errorResponse.setErrorStatus(UIConstant.SUCCESS);
        	view= UIConstant.LOGIN_PAGE;
            if(errorResponse.getErrorCode()== "SE151"){  
            	logger.info("last 5 password check");
            	view= UIConstant.CHANGE_KLOGIN_PWD;
            }//Sairam Added here for 5550 CR - Start
            if(errorResponse.getErrorCode()== "V0766"){
            	logger.info("Login Password and Profile Password is same");
            	view= UIConstant.CHANGE_KLOGIN_PWD;
            } if(errorResponse.getErrorCode()== "V0765"){
            	logger.info("Login Password and Tran Password is same");
            	view= UIConstant.CHANGE_KLOGIN_PWD;
            }
            //Sairam Ended here for 5550 CR- End
        }
        logger.info("ModelAndView updateKLoginPwd (HttpServletRequest request, HttpServletResponse response) method ends");
        return new ModelAndView(view,UIConstant.MODEL,outParams);
    }

	public void setChangeKLoginPwdService(BaseService changeKLoginPwdService) {
		this.changeKLoginPwdService = changeKLoginPwdService;
	}
	public void setKpageUrl(String kpageUrl) {
		this.kpageUrl = kpageUrl;
	}
	public void setRndString(RndString rndString) {
		this.rndString = rndString;
	}
	//	Added for sha
	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}		
}