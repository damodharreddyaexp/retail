/*   
 * LogonHandler.java
 * Created on Oct 14, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;


/**
 * Logon and logout
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class LogonHandler extends MultiActionController{
	
    protected final Logger logger = Logger.getLogger(getClass());

    private BaseService logonService;

    private ReferenceDataCache referenceDataCache;
    
    private String merchantDisplay;
   
    private String merchantDisplayCorporate;
    private static boolean servletFlag = true;

    public ModelAndView logInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Login page display");
        return new ModelAndView(UIConstant.LOGIN_PAGE);
    }

    public ModelAndView sessionTimeOut(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Session time out");
        String value ="sessionTimeOut";
        return new ModelAndView("sessionTimeOutBank","fromJsp",value);

    }
    
    public ModelAndView sessionTimeOutAssociate(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String bankCode = request.getParameter("bankCode");
        logger.debug("bank code from findbankcode.jsp : " + bankCode);
        String returnView = "sessionLayout";
        if(bankCode.equalsIgnoreCase("1")){
            returnView = "sbbjSessionTimeOut";
        }else if(bankCode.equalsIgnoreCase("2")){
            returnView = "sbhSessionTimeOut";
        }else if(bankCode.equalsIgnoreCase("3")){
            returnView = "sessionLayout";
        }else if(bankCode.equalsIgnoreCase("4")){
            returnView = "sbmSessionTimeOut";
        }else if(bankCode.equalsIgnoreCase("5")){
            returnView = "sbpSessionTimeOut";
        }else if(bankCode.equalsIgnoreCase("6")){
            returnView = "sessionLayout";
        }else if(bankCode.equalsIgnoreCase("7")){
            returnView = "sbtSessionTimeOut";
        }else{
            returnView = "sessionLayout";
        }
        
        return new ModelAndView(returnView);

    }

     public ModelAndView sbbjLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Sbbj Login page display");
        return new ModelAndView(UIConstant.SBBJ_LOGIN_PAGE);
    }
     
     public ModelAndView sbhLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbh Login page display");
         return new ModelAndView(UIConstant.SBH_LOGIN_PAGE);
     }
     
     public ModelAndView sbindoreLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbindore Login page display");
         return new ModelAndView(UIConstant.SBINDORE_LOGIN_PAGE);
     }
     
     public ModelAndView sbmLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbm Login page display");
         return new ModelAndView(UIConstant.SBM_LOGIN_PAGE);
     }
     
     public ModelAndView sbpLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbp Login page display");
         return new ModelAndView(UIConstant.SBP_LOGIN_PAGE);
     }
     
     public ModelAndView sbsLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbs Login page display");
         return new ModelAndView(UIConstant.SBS_LOGIN_PAGE);
     }
     
     public ModelAndView sbtLogInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
         logger.debug("sbt Login page display");
         return new ModelAndView(UIConstant.SBT_LOGIN_PAGE);
     }
     
      
    public ModelAndView logInSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Login submit - begins");

        if (servletFlag == true) {
            ServletContext ctx = getServletContext();
            ctx.setAttribute(UIConstant.PRODUCT_DESCRIPTION, referenceDataCache
                    .getReferenceData(UIConstant.ACCOUNTNAME_KEY));
            ctx.setAttribute(UIConstant.BRANCH_NAME_CODE_MAP, referenceDataCache
                    .getReferenceData(UIConstant.BRANCH_DATA_KEY));
            ctx.setAttribute(UIConstant.ALL_BRANCH_NAME_CODE_MAP, referenceDataCache
                    .getReferenceData(UIConstant.ALL_BRANCH_DATA_KEY));
            servletFlag = false;
        }
        //String userIPaddress = request.getRemoteAddr();//request.getHeader("ClientIPAddress");
      //Shanta
        String userIPaddress = request.getHeader("ClientIP"); 
        logger.info("Client IP from header : " + userIPaddress); 
       
        //shanta       
        Map outParams = new HashMap();
        logger.debug("handleRequest(HttpServletRequest req, HttpServletResponse res) begin");
        String userName = request.getParameter(UIConstant.USER_NAME);
        String password = request.getParameter(UIConstant.PASSWORD);
        HttpSession session = request.getSession(false); //
        // Added for Dmat corporate       
        String ebrokingId=(String)session.getAttribute("now_ebrokingId");
        String corporateId=(String)session.getAttribute("now_corporateId");
        String corpAdmin=(String)session.getAttribute("now_corpAdmin");
        //ends  Dmat corporate 
        String sessionId = session.getId(); //Added for CR 951
        String serverName= (String)getServletContext().getAttribute("com.ibm.websphere.servlet.application.host");
		
        Map inputParams = new HashMap();
        //Added for Dmat corporate
        inputParams.put("ebrokingId", ebrokingId);
        inputParams.put("corporateId", corporateId);
        inputParams.put("corpAdmin", corpAdmin);
        //ends Dmat corporate
        inputParams.put(UIConstant.USER_NAME, userName);
        inputParams.put(UIConstant.PASSWORD, password);
        inputParams.put(UIConstant.IP_ADDRESS, userIPaddress);
		inputParams.put("serverName", serverName);
        inputParams.put("keyid",request.getParameter("keyid"));
        inputParams.put(UIConstant.SESSION_ID, sessionId);
        //for associate bank
        String bankCodeJsp = (String)request.getParameter("bankCode");
        String merchantCode=(String)request.getParameter("merchantCode");
        logger.info("Merchant Code : "+merchantCode);
        inputParams.put(UIConstant.BANK_CODE,bankCodeJsp);
        String return_view = "";
        if(bankCodeJsp.equalsIgnoreCase("1"))
            return_view ="sbbjLogin";
        if(bankCodeJsp.equalsIgnoreCase("2")) 
            return_view ="sbhLogin";
        if(bankCodeJsp.equalsIgnoreCase("3"))
            return_view =UIConstant.LOGIN_PAGE;
        if(bankCodeJsp.equalsIgnoreCase("4"))
            return_view ="sbmLogin";
        if(bankCodeJsp.equalsIgnoreCase("5"))
            return_view ="sbpLogin";
        if(bankCodeJsp.equalsIgnoreCase("6"))
            return_view =UIConstant.LOGIN_PAGE;
        if(bankCodeJsp.equalsIgnoreCase("7"))
            return_view ="sbtLogin";
        if(bankCodeJsp.equalsIgnoreCase("0"))
            return_view =UIConstant.LOGIN_PAGE;
        logger.info("Return View : " + return_view);
        if (userName != null && userName.trim() != "" && password != null && password.trim() != "") {
            outParams = (Map) logonService.execute(inputParams);
            outParams.put("bankCode",bankCodeJsp);
            outParams.put("merchantCode",merchantCode);
            outParams.put(UIConstant.ERROR_VIEW, return_view);
            logger.debug("Object from service = " + outParams);
            SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams
                    .get(UIConstant.APPLICATION_RESPONSE);
            logger.debug("value "+outParams.get(UIConstant.USER));
            logger.debug("status "+errorResponse.getErrorStatus());
            if (outParams.get("profile") != null) {
                logger.debug("handleRequest(HttpServletRequest req, HttpServletResponse res) end");
                UserProfile userProfile = (UserProfile) outParams.get("profile");
                String displayName = (String) outParams.get(UIConstant.DISPLAY_NAME);
                int loginCount =userProfile.getLoginCount().intValue();
                session.setAttribute(UIConstant.USER, userProfile);
                session.setAttribute(UIConstant.DISPLAY_NAME, displayName);
                session.setAttribute(UIConstant.LAST_TXN,userProfile.getLastTnameInternet());
                session.setAttribute(UIConstant.LAST_LOGIN_DATE,userProfile.getLastLoginDate());
                session.setAttribute(UIConstant.LAST_TXN_DATE,userProfile.getLastTDateInternet());
                Map inParam = new HashMap();
                inParam.put(UIConstant.USER,userProfile);
            	if(!userProfile.getBankCode().equals(bankCodeJsp)){
            		logger.debug("bank code not equal");
            		outParams.put("merchantCode",merchantCode);
                	outParams.put("bankCode",bankCodeJsp);
            		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
            		applicationResponse.setErrorStatus("failure");
            		applicationResponse.setErrorCode("MP008");
            		outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
            		return new ModelAndView(return_view,UIConstant.ERROR_MODEL,outParams);
            	}else if(loginCount <= 0){
            		logger.debug("loginCount : " + loginCount);
            		outParams.put("merchantCode",merchantCode);
                	outParams.put("bankCode",bankCodeJsp);
            		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
            		applicationResponse.setErrorStatus("failure");
            		applicationResponse.setErrorCode("MP010");
            		outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
            		return new ModelAndView(return_view,UIConstant.ERROR_MODEL,outParams);
            	}else{
            		if(corporateId!=null){//Added for dmat corporate
            			getServletContext().getRequestDispatcher(merchantDisplayCorporate).forward(request, response);
            			
            		}else{
            		    getServletContext().getRequestDispatcher(merchantDisplay).forward(request, response);
            		}
            	}
            }else {
            	outParams.put("bankCode",bankCodeJsp);
                outParams.put("merchantCode",merchantCode);
                outParams.put("userName",userName);
                outParams.put(UIConstant.ERROR_VIEW, return_view);
                logger.debug("Returned to Login Page with Error : " + return_view);
                logger.debug("handleRequest(HttpServletRequest req, HttpServletResponse res) end");
                return new ModelAndView(return_view,UIConstant.ERROR_MODEL, outParams);
            }

        }
        logger.debug("Login Page created ");
        return new ModelAndView(return_view, UIConstant.SUCCESS, outParams);
    }

    public ModelAndView logOutHandler(HttpServletRequest request, HttpServletResponse response) throws Exception {
        logger.debug("Logout Page begins ");
        HttpSession session = request.getSession(false);
      	if(session != null)
            session.invalidate();
        String value ="logout";
        return new ModelAndView("sessionTimeOutBank","fromJsp",value);

    }

    public ModelAndView logOutHandlerAssociate(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	HttpSession session = request.getSession(false);
      	if(session != null)
            session.invalidate();
        String bankCode = request.getParameter("bankCode");
        logger.info("bank code from findbankcode.jsp = "+bankCode);
        String returnView = "logoutLayout";
        if(bankCode.equalsIgnoreCase("1")){
            returnView = "sbbjLogout";
        }else if(bankCode.equalsIgnoreCase("2")){
            returnView = "sbhLogout";
        }else if(bankCode.equalsIgnoreCase("3")){
            returnView = "logoutLayout";
        }else if(bankCode.equalsIgnoreCase("4")){
            returnView = "sbmLogout";
        }else if(bankCode.equalsIgnoreCase("5")){
            returnView = "sbpLogout";
        }else if(bankCode.equalsIgnoreCase("6")){
            returnView = "logoutLayout";
        }else if(bankCode.equalsIgnoreCase("7")){
            returnView = "sbtLogout";
        }else{
            returnView = "logoutLayout";
        }
        logger.debug("logout layout : "+returnView);
        return new ModelAndView(returnView);
    }

    public void setLogonService(BaseService logonService) {
        this.logonService = logonService;
    }

    public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
        this.referenceDataCache = referenceDataCache;
    }

	public void setMerchantDisplay(String merchantDisplay) {
		this.merchantDisplay = merchantDisplay;
	}

	public void setMerchantDisplayCorporate(String merchantDisplayCorporate) {
		this.merchantDisplayCorporate = merchantDisplayCorporate;
	}
}