package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;


public class ProfileHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());

	private BaseService getUserProfileService;

	private BaseService updateCorpProfileService;
	
	public ModelAndView voiceOTPEnable(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("voiceOTPEnable(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map inParams = new HashMap();
        HttpSession session = request.getSession(false);
        
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        logger.info("=====corporateID========"+corporateProfile.getCorporateID());
        if(corporateProfile != null){
        	}       
       
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);       
        inParams.put(UIConstant.USER_NAME, user.getUserAlias());
        inParams.put("enableVoiceOTP", "yes");
        Map outputParams = getUserProfileService.execute(inParams);
        inParams.put("flag", "VoiceOTPMode");
        inParams.put("corporateID", corporateProfile.getCorporateID());
       
        Map outParams = updateCorpProfileService.execute(inParams);
        outputParams.put("merchantMode",outParams.get("merchantMode"));
        outputParams.put("otpOption",user.getOtpOption());
        
        outputParams.put("errorView", "merchantHighSecurityErrorView");
		logger.info("voiceOTPEnable() method end =====> ");
		return new ModelAndView("enableVoiceOTP", "userDetails", outputParams);
		
	}
	
	public ModelAndView voiceOTPConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("voiceOTPConfirm(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map inParams = new HashMap();
        HttpSession session = request.getSession(false);
        
       
        User user = (User) session.getAttribute(UIConstant.USER);       
        inParams.put(UIConstant.USER_NAME, user.getUserAlias());
        
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        inParams.put("corporateID", corporateProfile.getCorporateID());
        inParams.put("flag", "updateVoiceOTPMode");
        inParams.put("userId", user.getUserId());
        
        String otpOption= request.getParameter("highSecurityOtpStatus");
        
        inParams.put("otpOption", otpOption);
       
        Map outputParams = updateCorpProfileService.execute(inParams);
        
        if(outputParams.get("updateOTPMode") !=null ) {
        	Boolean success=(Boolean)outputParams.get("updateOTPMode");
        	if(success) {
        	 UserProfile userProfile=(UserProfile) session.getAttribute(UIConstant.USER);       	
        	 userProfile.setOtpOption(otpOption);      
        	 session.setAttribute(UIConstant.USER,userProfile);
        	}
        }
        outputParams.put("errorView", "merchantHighSecurityErrorView");
		logger.info("voiceOTPConfirm() method end");
		return new ModelAndView("enableVoiceOTPCnfirm", "userDetails", outputParams);
		
	}
	
	
	public void setGetUserProfileService(BaseService getUserProfileService) {
		this.getUserProfileService = getUserProfileService;
	}

	public void setUpdateCorpProfileService(BaseService updateCorpProfileService) {
		this.updateCorpProfileService = updateCorpProfileService;
	}
}
