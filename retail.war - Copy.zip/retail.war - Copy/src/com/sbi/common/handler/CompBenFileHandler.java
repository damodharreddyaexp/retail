
/*
 * CompBenFileHandler.java
 * Created on August 5, 2013
 *  
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.handler.CompBenReverseFileConverter;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.FilesDownloadUtils;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.RandomString;
import com.sbi.common.handler.UIConstant;


public class CompBenFileHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService compBenFileConfigService;
	
	private BaseService compBenSetFileService;
	
	private BaseService compBenSetFileCheckService;

	private BaseService compBenApproveFileDisplayService;
	
	private BaseService compBenApproveRecordCountService;
	
	private BaseService compBenApproveRecordDisplayService;
	
	private BaseService compBenApproveRecordConfirmService;
	
	private BaseService compBenRejectRecordConfirmService;
	
	private BaseService  get3PErrorCountService;
	
	private BaseService compBenViewFileDisplayService;
	
	private BaseService compBenViewRecordCountService;
	
	private BaseService compBenViewRecordDisplayService;
	
	private BaseService downloadCompBenFileService;
	
    private FilesDownloadUtils filesDownloadUtils;
    
    private RandomString randomString;
    
    private CompBenReverseFileConverter compBenReverseFileConverter;
	
	
	
	public ModelAndView viewExisFileConfigDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewExisFileConfigDisplay(HttpServletRequest request, HttpServletResponse response) -- begins");
        HttpSession session = request.getSession(false);
        Map inParam = new HashMap();
 	    Map outParams = new HashMap();
 	    String viewName = "viewExisFileConfigDisplay";
 	    
 	    User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String fileType = "COMPOSITE_BEN";
		inParam.put("corporateId", corporateId);
		inParam.put("funcType", "getNewFileConfigDtls");
		inParam.put("fileType",fileType);
		
 	    outParams = compBenFileConfigService.execute(inParam);
 	    outParams.put("txnType",fileType);
 	    
 	    if(outParams.get("fileconfiguration")!=null) {
 	    	viewName = "viewExisFileConfigDetails";
 	    }
 	    
 	    logger.info("viewExisFileConfigDisplay(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView(viewName, "fileConfigParams", outParams);
       
    }
    public ModelAndView viewExisFileConfigDetails(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewExisFileConfigDetails(HttpServletRequest request, HttpServletResponse response) -- begins");
        HttpSession session = request.getSession(false);
        Map inParam = new HashMap();
 	    Map outParams=new HashMap();
 	    User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String fileType = request.getParameter("filetype");
		inParam.put("corporateId", corporateId);
		inParam.put("fileType",fileType);
		
 	    outParams = compBenFileConfigService.execute(inParam);
 	    outParams.put("txnType",fileType);
 	    logger.info("viewExisFileConfigDetails(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView("viewExisFileConfigDetails", "fileConfigParams", outParams);
       
    }
    public ModelAndView setNewFileConfig(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("setNewFileConfig(HttpServletRequest request, HttpServletResponse response) -- begins");
        HttpSession session = request.getSession(false);
 	    Map inParams = new HashMap();
 	    Map outParams=new HashMap();
 	    String compCheckVal;
 	    String viewName;
 	    viewName = "setNewFileConfig";
        User user=(User)session.getAttribute(UIConstant.USER);
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        int smallFlag = corporateProfile.getSmallFlag();
        String corporateId = user.getCorporateId();
        inParams.put("corporateId",corporateId);
        logger.info("SMALL FLAG "+smallFlag);
        inParams.put("smallFlag",smallFlag);
       	outParams = compBenSetFileCheckService.execute(inParams);
	    SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response = "+ outParams.get(UIConstant.APPLICATION_RESPONSE));
		outParams.put(UIConstant.APPLICATION_RESPONSE, outParams.get(UIConstant.APPLICATION_RESPONSE));
 	    logger.info("setNewFileConfig(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView(viewName, "outParams", outParams);
    }
    public ModelAndView setNewFileConfigConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("setNewFileConfigConfirm(HttpServletRequest request, HttpServletResponse response) -- begins");
        HttpSession session = request.getSession(false);
        String format = request.getParameter("format");
        String fieldDelimter = null;
        String viewName = "setNewFileConfigConfirm";
        String compConfigType = null;
        int delimitVal = 0;
        if (format.equalsIgnoreCase("Delimited"))
        {
        	fieldDelimter = request.getParameter("fieldDelimter");
        	if(fieldDelimter.equalsIgnoreCase("#"))
        	{
        		compConfigType = "delimited_ben_#";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("|"))
        	{
        		compConfigType = "delimited_ben_|";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("^"))
        	{
        		compConfigType = "delimited_ben_^";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("~"))
        	{
        		compConfigType = "delimited_ben_~";
        	}else if(fieldDelimter.equalsIgnoreCase("*"))
        	{
        		compConfigType = "delimited_ben_*";
        	}
         }
        else if(format.equalsIgnoreCase("Fixed"))
        {
        	compConfigType = "fixed_ben";
        }
		User user = (User) session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
 	    Map inParams = new HashMap();
 	    Map outParams=new HashMap();
 	    inParams.put("format",format);
 	    inParams.put("fieldDelimter",fieldDelimter);
 	    inParams.put("compConfigType",compConfigType);
 	    inParams.put("corporateId",corporateId);
 	    outParams = compBenSetFileService.execute(inParams);
 	    
 	  	SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response = "+ outParams.get(UIConstant.APPLICATION_RESPONSE));
		outParams.put(UIConstant.APPLICATION_RESPONSE, outParams.get(UIConstant.APPLICATION_RESPONSE));
	    logger.info("setNewFileConfigConfirm(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView(viewName, "outParams", outParams);
    }
    
    public ModelAndView compApproveFileDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("compApproveFileDisplay(HttpServletRequest request, HttpServletResponse response) -- begins");
    	Map inParam = new HashMap();
        Map outParam = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateID = user.getCorporateId();
        Integer userRole = (Integer) user.getRoles().get(0);
        
        inParam.put(UIConstant.USER_NAME, userName);
        inParam.put(UIConstant.USER_ROLE, userRole);
        inParam.put("coporateID",coporateID);
        inParam.put("functionType","getUploader");
        
        logger.info("userName :" + userName);
        logger.info("coporateID :" + coporateID);
        
        outParam = compBenApproveFileDisplayService.execute(inParam);
        logger.info("out params"+outParam);
        
        
		logger.info("compApproveFileDisplay(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView("cbApproveFileDisplay", "outParam", outParam);
       
    }
    public ModelAndView approveBenPendingFiles(HttpServletRequest request,HttpServletResponse response) 
    {
    	logger.info("approveBenPendingFiles(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map approveTPDetails = new HashMap();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(UIConstant.USER);
		String userName = user.getUserAlias();
		Integer userRole = (Integer) user.getRoles().get(0);
        Integer roleValue=(Integer) user.getRoles().get(0);
        String uploaderName = request.getParameter("uploaderName");
		session.setAttribute("uploaderName",uploaderName);
		//Below code Changed For Addhar
		String benFileType  = request.getParameter("benFileType");
		inputParam.put("benFileType", benFileType);
		session.setAttribute("benFileType",benFileType);
		
		inputParam.put("uploaderName", uploaderName);
		inputParam.put("userRole", userRole);
		inputParam.put(UIConstant.USER_NAME, userName);
		inputParam.put("functionType","getPendingFiles");
		inputParam.put("coporateID",user.getCorporateId());
		
		outputParam = compBenApproveFileDisplayService.execute(inputParam);
		
		outputParam.put("uploaderName", uploaderName);
		//Below code Changed For Addhar
		outputParam.put("benFileType", benFileType);
		
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));

		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.ERROR_VIEW,"errorcorpApprover3P");			

		logger.info("approveTPFileDetails :" + approveTPDetails);
		logger.info("approveBenPendingFiles(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		
		return new ModelAndView("cbPendingFiles","cbPendingFiles", outputParam);

	}
    
    public ModelAndView approveBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("approveBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map outParams = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String uploaderName = request.getParameter("uploaderName");
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        inputParam.put("uploaderName", uploaderName);
        inputParam.put("tpFileName", fileName);

        outputParam = compBenApproveRecordCountService.execute(inputParam);
       
        outParams = get3PErrorCountService.execute(inputParam);
        outputParam.put("Countval", outParams.get("Countval"));
       
        outputParam.put("uploaderName", uploaderName);
        
        if(session.getAttribute("approveTPFileDetails")!=null)
        	session.removeAttribute("approveTPFileDetails");
        if(session.getAttribute("approveBenDetails")!=null)
        	session.removeAttribute("approveBenDetails");
        if(session.getAttribute("selectAllFlag")!=null)
        	session.removeAttribute("selectAllFlag");
		
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
    	logger.info("approveBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordCount","approveTPCountDetails", outputParam);
    }
    
    public ModelAndView approveBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("approveBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String uploaderName = request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        
        outputParam = compBenApproveRecordDisplayService.execute(inputParam);
        
        outputParam.put("uploaderName", uploaderName);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		
		session.setAttribute("approveTPFileDetails",outputParam.get("approveBenRecordDetails"));
		session.setAttribute("approveBenDetails",outputParam);
		
    	logger.info("approveBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordDisplay","approveBenDetails", outputParam);
    }
    public ModelAndView approveCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("approveCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String specificFileType = request.getParameter("specificFileType");
        String uploaderName = request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        inputParam.put("specificFileType", specificFileType);
        inputParam.put("uploaderName", uploaderName);
        
        outputParam = compBenApproveRecordDisplayService.execute(inputParam);
        
        outputParam.put("uploaderName", uploaderName);
        outputParam.put("specificFileType", specificFileType);
        
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		
		session.setAttribute("approveTPFileDetails",outputParam.get("approveBenRecordDetails"));
		session.setAttribute("approveBenDetails",outputParam);
		
    	logger.info("approveCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordDisplay","approveBenDetails", outputParam);
    }
    
    public ModelAndView selectAllBenPendingRecord(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("selectAllBenPendingRecord(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
		String selectAllFlag = request.getParameter("selectAllFlag");
		String clearAllFlag = request.getParameter("clearAllFlag");
		
		if("Yes".equals(clearAllFlag)) {
			session.removeAttribute("selectAllFlag");
		}
		else {
			session.setAttribute("selectAllFlag",selectAllFlag);
		}
		outputParam=(Map)session.getAttribute("approveBenDetails");
		
    	logger.info("selectAllBenPendingRecord(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordDisplay","approveBenDetails", outputParam);
    }
    
    public ModelAndView approveBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("approveBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map approveBenRecordDetails = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String approveIds;
        String fileType;
        approveIds = request.getParameter("approvedIds");
        fileType = request.getParameter("fileType");
        String selectAllFlag = (String)request.getParameter("selectAllFlag");
        String fileName = (String)request.getParameter("fileName");
        String specificFileType = (String)request.getParameter("specificFileType");
        String uploaderName = (String)request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put(UIConstant.APPROVE_IDS,approveIds);
        inputParam.put("fileType", fileType);
        inputParam.put("selectAllFlag",selectAllFlag);
        inputParam.put("fileName",fileName);
        inputParam.put("specificFileType", specificFileType);
        
        outputParam = compBenApproveRecordConfirmService.execute(inputParam);
        
        session.removeAttribute("approveTPFileDetails");
		session.removeAttribute("approveBenDetails");
		session.removeAttribute("selectAllFlag");
		
		outputParam.put("uploaderName", uploaderName);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
    	logger.info("approveBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordConfirm","outputParam", outputParam);
    }
    
    public ModelAndView rejectBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("rejectBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map approveBenRecordDetails = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String approveIds;
        String fileType;
        approveIds = request.getParameter("approvedIds");
        fileType = request.getParameter("fileType");
        String selectAllFlag = (String)request.getParameter("selectAllFlag");
        String fileName = (String)request.getParameter("fileName");
        String specificFileType = (String)request.getParameter("specificFileType");
        String uploaderName = (String)request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put(UIConstant.APPROVE_IDS,approveIds);
        inputParam.put("fileType", fileType);
        inputParam.put("selectAllFlag",selectAllFlag);
        inputParam.put("fileName",fileName);
        inputParam.put("specificFileType", specificFileType);
        
        outputParam = compBenRejectRecordConfirmService.execute(inputParam);
        
        session.removeAttribute("approveTPFileDetails");
		session.removeAttribute("approveBenDetails");
		session.removeAttribute("selectAllFlag");
		
		outputParam.put("uploaderName", uploaderName);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
    	logger.info("rejectBenPendingRecordConfirm(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbPendingRecordConfirm","outputParam", outputParam);
    }
    
    public ModelAndView compViewFileDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("compViewFileDisplay(HttpServletRequest request, HttpServletResponse response) -- begins");
    	Map inParam = new HashMap();
        Map outParam = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateID = user.getCorporateId();
        Integer userRole = (Integer) user.getRoles().get(0);
        
        inParam.put(UIConstant.USER_NAME, userName);
        inParam.put(UIConstant.USER_ROLE, userRole);
        inParam.put("coporateID",coporateID);
        inParam.put("functionType","getUploader");
        
        logger.info("userName :" + userName);
        logger.info("coporateID :" + coporateID);
        
        outParam = compBenViewFileDisplayService.execute(inParam);
        logger.info("out params"+outParam);
        
        
		logger.info("compViewFileDisplay(HttpServletRequest request, HttpServletResponse response) -- ends");
        return new ModelAndView("cbViewFileDisplay", "outParam", outParam);
       
    }
    public ModelAndView viewBenPendingFiles(HttpServletRequest request,HttpServletResponse response) 
    {
    	logger.info("viewBenPendingFiles(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map approveTPDetails = new HashMap();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(UIConstant.USER);
		String userName = user.getUserAlias();
		Integer userRole = (Integer) user.getRoles().get(0);
        Integer roleValue=(Integer) user.getRoles().get(0);
        String uploaderName = request.getParameter("uploaderName");
		session.setAttribute("uploaderName",uploaderName);
		//Below code Changed For Addhar
		String benFileType  = request.getParameter("benFileType");
		inputParam.put("benFileType", benFileType);
		session.setAttribute("benFileType",benFileType);
		
		inputParam.put("uploaderName", uploaderName);
		inputParam.put("userRole", userRole);
		inputParam.put(UIConstant.USER_NAME, userName);
		inputParam.put("functionType","getPendingFiles");
		inputParam.put("coporateID",user.getCorporateId());
		
		outputParam = compBenViewFileDisplayService.execute(inputParam);
		
		outputParam.put("uploaderName", uploaderName);
		outputParam.put("benFileType", benFileType);
		
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));

		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.ERROR_VIEW,"errorcorpApprover3P");			

		logger.info("approveTPFileDetails :" + approveTPDetails);
		logger.info("viewBenPendingFiles(HttpServletRequest request,HttpServletResponse response)"+ LoggingConstants.METHODEND);
		
		return new ModelAndView("cbViewPendingFiles","cbPendingFiles", outputParam);

	}
    
    public ModelAndView viewBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		Map outParams = new HashMap();
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String uploaderName = request.getParameter("uploaderName");
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        inputParam.put("uploaderName", uploaderName);
        inputParam.put("tpFileName", fileName);

        outputParam = compBenViewRecordCountService.execute(inputParam);
       
        outParams = get3PErrorCountService.execute(inputParam);
        outputParam.put("Countval", outParams.get("Countval"));
       
        outputParam.put("uploaderName", uploaderName);
        
        if(session.getAttribute("approveTPFileDetails")!=null)
        	session.removeAttribute("approveTPFileDetails");
        if(session.getAttribute("approveBenDetails")!=null)
        	session.removeAttribute("approveBenDetails");

		
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		outputParam.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
    	logger.info("viewBenPendingRecordCount(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbViewPendingRecordCount","approveTPCountDetails", outputParam);
    }
    
    public ModelAndView viewBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String uploaderName = request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        
        outputParam = compBenViewRecordDisplayService.execute(inputParam);
        
        outputParam.put("uploaderName", uploaderName);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		
		session.setAttribute("approveTPFileDetails",outputParam.get("approveBenRecordDetails"));
		session.setAttribute("approveBenDetails",outputParam);
		
    	logger.info("viewBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbViewPendingRecordDisplay","approveBenDetails", outputParam);
    }
    public ModelAndView viewCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        String specificFileType = request.getParameter("specificFileType");
        String uploaderName = request.getParameter("uploaderName");
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        inputParam.put("specificFileType", specificFileType);
        inputParam.put("uploaderName", uploaderName);
        
        outputParam = compBenViewRecordDisplayService.execute(inputParam);
        
        outputParam.put("uploaderName", uploaderName);
        outputParam.put("specificFileType", specificFileType);
        
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		
		session.setAttribute("approveTPFileDetails",outputParam.get("approveBenRecordDetails"));
		session.setAttribute("approveBenDetails",outputParam);
		
    	logger.info("viewCompBenPendingRecordDisplay(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	return new ModelAndView("cbViewPendingRecordDisplay","approveBenDetails", outputParam);
    }
    
    public ModelAndView downloadCompBenFiles(HttpServletRequest request, HttpServletResponse response) throws Exception
    {   
    	logger.info("downloadCompBenFiles(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODBEGIN);
		Map inputParam = new HashMap();
		Map outputParam = new HashMap();
		
		HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String userName = (String) user.getUserAlias();
        String coporateId = user.getCorporateId();
        String fileName =  request.getParameter("fileName"); 
        String fileType = request.getParameter("fileType");
        StringBuffer textBuffer = new StringBuffer();
        
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("coporateId", coporateId);
        inputParam.put("fileName", fileName);
        inputParam.put("fileType", fileType);
        
        outputParam = downloadCompBenFileService.execute(inputParam);
        textBuffer = compBenReverseFileConverter.csvCompBenFileConverter(outputParam);
        String filename = randomString.getRandomString()+randomString.getRandomString();  
        String filenameConcat = randomString.getRandomString();
        filename = filename+filenameConcat;
        filesDownloadUtils.downloadMsExcel(filename,response,textBuffer);
        
        
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response : "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
		
	//	session.setAttribute("approveTPFileDetails",outputParam.get("approveBenRecordDetails"));
	//	session.setAttribute("approveBenDetails",outputParam);
		
    	logger.info("downloadCompBenFiles(HttpServletRequest request, HttpServletResponse response)"+ LoggingConstants.METHODEND);
    	
    	return null;
    }
   
	public void setCompBenSetFileService(BaseService compBenSetFileService) {
		this.compBenSetFileService = compBenSetFileService;
	}
	public void setCompBenFileConfigService(BaseService compBenFileConfigService) {
		this.compBenFileConfigService = compBenFileConfigService;
	}
	public void setCompBenSetFileCheckService(BaseService compBenSetFileCheckService) {
		this.compBenSetFileCheckService = compBenSetFileCheckService;
	}
	public void setCompBenApproveFileDisplayService(BaseService compBenApproveFileDisplayService) {
		this.compBenApproveFileDisplayService = compBenApproveFileDisplayService;
	}
	public void setCompBenApproveRecordCountService(BaseService compBenApproveRecordCountService) {
		this.compBenApproveRecordCountService = compBenApproveRecordCountService;
	}
	public void setCompBenApproveRecordDisplayService(BaseService compBenApproveRecordDisplayService) {
		this.compBenApproveRecordDisplayService = compBenApproveRecordDisplayService;
	}
	public void setCompBenApproveRecordConfirmService(BaseService compBenApproveRecordConfirmService) {
		this.compBenApproveRecordConfirmService = compBenApproveRecordConfirmService;
	}
	public void setCompBenRejectRecordConfirmService(BaseService compBenRejectRecordConfirmService) {
		this.compBenRejectRecordConfirmService = compBenRejectRecordConfirmService;
	}
	public void setGet3PErrorCountService(BaseService get3PErrorCountService) {
        this.get3PErrorCountService = get3PErrorCountService;
    }
	public void setCompBenViewFileDisplayService(BaseService compBenViewFileDisplayService) {
		this.compBenViewFileDisplayService = compBenViewFileDisplayService;
	}
	public void setCompBenViewRecordCountService(BaseService compBenViewRecordCountService) {
		this.compBenViewRecordCountService = compBenViewRecordCountService;
	}
	public void setCompBenViewRecordDisplayService(BaseService compBenViewRecordDisplayService) {
		this.compBenViewRecordDisplayService = compBenViewRecordDisplayService;
	}
	public void setDownloadCompBenFileService(BaseService downloadCompBenFileService) {
		this.downloadCompBenFileService = downloadCompBenFileService;
	}
	public void setFilesDownloadUtils(FilesDownloadUtils filesDownloadUtils) {
		this.filesDownloadUtils = filesDownloadUtils;
	}
    public void setRandomString(RandomString randomString){
	    this.randomString = randomString;
	}
    public void setCompBenReverseFileConverter(CompBenReverseFileConverter compBenReverseFileConverter) {
		this.compBenReverseFileConverter = compBenReverseFileConverter;
    }
	
}
