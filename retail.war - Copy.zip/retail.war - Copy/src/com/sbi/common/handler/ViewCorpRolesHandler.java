
/*
 * ViewCorpUserHandler.java
 * Created on Mar 16, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 16, 2006 Naveen Kumar � Initial Creation

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class ViewCorpRolesHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService viewCorpRolesService;
    private Map viewRolesMap;
    
    public ModelAndView viewCorpRoles(HttpServletRequest request, HttpServletResponse response) {
        logger.info("viewCorpRoles(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        String roleType=(String)viewRolesMap.get(request.getServletPath());
        inParams.put("functionType","displayUsers");
        inParams.put("roleType",roleType);
        inParams.put("causer",user.getUserAlias());
        inParams.put("corpId",user.getCorporateId());
        String nextAction="/viewcorprolesdetails.htm?roleType="+roleType;
        outParams = viewCorpRolesService.execute(inParams);
        outParams.put("roleType", roleType);
        outParams.put("nextAction", nextAction);
        outParams.put("actionType", "View");
        logger.info("Message input:"+inParams);
        logger.info("viewCorpUser(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);        
        return new ModelAndView("viewCorpRoles",UIConstant.MODEL,outParams);
    }
    
    
    public ModelAndView viewCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) {
        logger.info("viewCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inputParams = new HashMap();
        String userid = (String) request.getAttribute("approverId");
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        inputParams.put("causer",user.getUserAlias());
        inputParams.put("corporateId", user.getCorporateId());//shanta
        inputParams.put("userid",userid);
        inputParams.put("roleType",request.getParameter("roleType"));
        outParams = viewCorpRolesService.execute(inputParams);
        SBIApplicationResponse applicationResponse= new SBIApplicationResponse();
        applicationResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
        logger.info("viewCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);
        return new ModelAndView("viewCorpRolesDetails",UIConstant.MODEL,outParams);
    }

	public void setViewCorpRolesService(BaseService viewCorpRolesService) {
		this.viewCorpRolesService = viewCorpRolesService;
	}

	public void setViewRolesMap(Map viewRolesMap) {
		this.viewRolesMap = viewRolesMap;
	}


}
