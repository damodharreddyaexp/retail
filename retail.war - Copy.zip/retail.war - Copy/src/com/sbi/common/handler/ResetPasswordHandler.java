package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.handler.UIConstant;

public class ResetPasswordHandler extends MultiActionController{
	protected final Logger logger = Logger.getLogger(getClass());
	
	private BaseService resetPasswordConfirmService;
	public ModelAndView resetPasswordDisplay(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("resetPasswordDisplay(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map outParams=new HashMap();
        Map inParams=new HashMap();
		SBIApplicationResponse applicationResponse=new SBIApplicationResponse();
		applicationResponse.setErrorStatus(UIConstant.SUCCESS);
		HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);        
        String requestedURL = request.getServletPath().trim();        
        logger.info("requested URL  :" + requestedURL);
        String view=null;
        String errorView=null;
        String userRole="";
        
        inParams.put(UIConstant.CA_USER,user.getUserAlias());
        inParams.put("functionType","resetPassword");
        if(requestedURL!=null && requestedURL.equalsIgnoreCase("/superenquirerpassworddisplay.htm"))
        {
	        logger.info("superenquirer user");
	        inParams.put(UIConstant.USER_ROLE,UIConstant.SUPER_ENQR_ROLE);
	        userRole=UIConstant.SUPER_ENQR_ROLE;
	        inParams.put(UIConstant.CORPORATE_ID,user.getCorporateId());
	        logger.info("USER ROLE:"+UIConstant.SUPER_ENQR_ROLE);
	        view=UIConstant.RESET_SUPER_ENQR_PWD;
	        errorView="errorResetPwdSupEnqr";                
        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/uploaderpassworddisplay.htm")) 
        {
	        logger.info("uploader");
	        inParams.put(UIConstant.USER_ROLE,UIConstant.UPLOADER_ROLE);
	        userRole=UIConstant.UPLOADER_ROLE;
	        logger.info("USER ROLE:"+UIConstant.UPLOADER_ROLE);
	        view="resetLoginPasswordDisplay";
	        errorView="errorResetCorpUploader";            
        }
        
        
        outParams=resetPasswordConfirmService.execute(inParams);
        outParams.put(UIConstant.USER_ROLE,userRole);
        outParams.put(UIConstant.CA_USER,user.getUserAlias());
        outParams.put(UIConstant.ERROR_VIEW,errorView);
		logger.info("resetPasswordDisplay(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView(view,UIConstant.MODEL,outParams);
	}
	public ModelAndView dispatchResetPasswordConfirm(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("dispatchResetPasswordConfirm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);  
		String userName=request.getParameter("useralias");
		String profilepassword=request.getParameter("radiobutton");
		logger.info("user=="+userName);
		logger.info("password=="+profilepassword);
		logger.info("Actual UserName=="+request.getParameter("username"));
		inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
		inputParams.put("userName",userName);
		String password=request.getParameter("radiobutton");
		if( password == null)
			password="3";
		inputParams.put("password",password);
		
		/* Ramanan M - Corp Admin Paladion Security Changes */
		logger.info("Corporate ID == " + user.getCorporateId());
		inputParams.put(UIConstant.CORPORATE_ID, user.getCorporateId());
		
        String requestedURL = request.getServletPath().trim();        
        logger.info("requested URL  :" + requestedURL);
        String view=null;
        String errorView=null;
        String userRole="";
        String uploaderAdminFlag="false";
        if (requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchsuperenqrpwdconfirm.htm")) 
        {
        	userRole=UIConstant.SUPER_ENQR_ROLE;
        }else  if (requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchuploaderpwdconfirm.htm")) 
        {
        	userRole=UIConstant.UPLOADER_ROLE;
        }else if(requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchresetcorpuserpwdconfirm.htm"))
        {
        	userRole=UIConstant.CORP_USER_ROLE;
         }
        else  if (requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchresetaudituserpwdconfirm.htm")) 
        {
        	userRole=UIConstant.AUDIT_USER_ROLE;
        }else if(requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchresetsapproverpwdconfirm.htm"))
        {
        	userRole=UIConstant.APPROVER_USER_ROLE;
         }else if(requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchresetsuperuploaderadminpwdconfirm.htm"))
         {
         	userRole=UIConstant.SUPER_UPLOADER_ROLE;
         	uploaderAdminFlag="true";
          }
         else if(requestedURL!=null && requestedURL.equalsIgnoreCase("/dispatchresetuploaderadminpwdconfirm.htm"))
         {
         	userRole=UIConstant.UPLOADER_ROLE;
         	uploaderAdminFlag="true";
          }
        inputParams.put("userRole",userRole);
		outParams=resetPasswordConfirmService.execute(inputParams);
		view=UIConstant.DISPATCH_RESET_PWD_CONFIRM;
		errorView="errorResetPasswordUserConfirm";
	    outParams.put("userAlias",userName);
	    outParams.put("username",request.getParameter("username"));
	    outParams.put("userRole",userRole);
	    outParams.put("uploaderAdminFlag",uploaderAdminFlag);
	    logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    outParams.put(UIConstant.ERROR_VIEW,errorView);
	   
	    
		logger.info("dispatchResetPasswordConfirm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView(view,UIConstant.MODEL,outParams);
	}
	public ModelAndView issueKitResetPasswordConfirm(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("issueKitResetPasswordConfirm(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		HttpSession session = request.getSession(false);
		session.removeAttribute("corpUserProfile");
		User user = (User) session.getAttribute(UIConstant.USER); 
		String requestedURL = request.getServletPath().trim();        
        logger.info("requested URL  :" + requestedURL);
        String userName=request.getParameter("useralias");
		logger.info("user=="+userName);
		logger.info("Actual UserName=="+request.getParameter("username"));
		inputParams.put(UIConstant.CA_USER,user.getUserAlias());	       
		inputParams.put("userName",userName);
		inputParams.put("issueKit","true");
		//inputParams.put("userRole",request.getParameter("userRole"));
		/* Ramanan M - Corp Admin Paladion Security Changes */
		logger.info("Corporate ID == " + user.getCorporateId());
		inputParams.put(UIConstant.CORPORATE_ID, user.getCorporateId());
        String view=null;
        String errorView=null;
        String userRole="";
        String uploaderAdminFlag="false";
        
		 if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetsuperenqrpwdconfirm.htm")) 
	        {
		        userRole=UIConstant.SUPER_ENQR_ROLE;
	        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetuploaderpwdconfirm.htm")) 
	        {
		        userRole=UIConstant.UPLOADER_ROLE;
	        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetcorpuserpwdconfirm.htm")) 
	        {
		        userRole=UIConstant.CORP_USER_ROLE;
	        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetaudituserpwdconfirm.htm")) 
	        {
		        userRole=UIConstant.AUDIT_USER_ROLE;
	        }else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetuploaderadminpwdconfirm.htm")) 
	        {
	        	uploaderAdminFlag="true"; 
                userRole=UIConstant.UPLOADER_ROLE;
	        }
	        else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetsuperuploaderadminpwdconfirm.htm")) 
	        {
	        	uploaderAdminFlag="true";
		        userRole=UIConstant.SUPER_UPLOADER_ROLE;
	        }
	        else if (requestedURL!=null && requestedURL.equalsIgnoreCase("/issueKitresetsapproverpwdconfirm.htm")) 
	        {
		        userRole=UIConstant.APPROVER_USER_ROLE;
	        }
		 inputParams.put("userRole",userRole);
		 view=UIConstant.ISSUE_KIT_RESET_PWD_CONFIRM;
		 errorView="errorResetPasswordUserConfirm";
		 outParams=resetPasswordConfirmService.execute(inputParams);
		 session.setAttribute("corpUserProfile", outParams.get("corpUserProfile"));
		 outParams.put("uploaderAdminFlag",uploaderAdminFlag);
		 outParams.put("userRole",userRole);
			return new ModelAndView(view,UIConstant.MODEL,outParams);
	}
	/**
	 * @param resetPasswordConfirmService the resetPasswordConfirmService to set
	 */
	public void setResetPasswordConfirmService(
			BaseService resetPasswordConfirmService) {
		this.resetPasswordConfirmService = resetPasswordConfirmService;
	}

	
}
