package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;


public class VascoOneTimePasswordHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());

	private ResourceBundleMessageSource logonProperty;
	
	private BaseService validateDigitalPasswordService;
    
	private BaseService registerMobileNoService;
	
	private BaseService viewRejectMobileNoService;
	
	private BaseService rejectMobileNoConfirmService;
	
	public ModelAndView displayVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("displayVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) Begin");
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("displayVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) End");
        return new ModelAndView("vascoPasswordDisplay",UIConstant.MODEL,outParams);
    }
	
	public ModelAndView submitVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("submitVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) Begin");
        Map outParams = new HashMap();
        Map inParam = new HashMap();
        HttpSession session = request.getSession(false);
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        Integer userRole = 0;
        String redirectionString = "";
        if(session.getAttribute("userRole") != null) {
        	userRole = (Integer) session.getAttribute("userRole");
		}
        String vascoPassword = (String)request.getParameter("otpPassword").trim();
        if(vascoPassword!=null && !"".equals(vascoPassword) && user.getNewspreference5()!=null && !"".equals(user.getNewspreference5())){
        	logger.info("vascoPassword : " + vascoPassword);
      	    inParam.put("digitalSerialNo", user.getNewspreference5());
    	    inParam.put("digitalPassword", vascoPassword);
    	    outParams =  validateDigitalPasswordService.execute(inParam); // validate Digital password
    	    logger.info(" after validateDigitalPasswordService outParams : " + outParams);
    	    String digitalPassword = (String) outParams.get("validation");	    
            if(ServiceConstant.SUCCESS.equals(digitalPassword)){
            	redirectionString = getPropertyVal("role"+userRole.toString());
            	logger.info("redirectionString : " + redirectionString);
            	getMailAlert(request);
            	getServletContext().getRequestDispatcher(redirectionString).forward(request,response);
            	applicationResponse.setErrorStatus("SUCCESS");
            }  else if(digitalPassword.equals("ErrorThreshold")){
            	applicationResponse.setErrorCode("CHEQ003");
            }else{
            	applicationResponse.setErrorCode("CHEQ001");
            }
        }else{
        	applicationResponse.setErrorCode("CHEQ001");
        }
        
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("submitVascoSecurePassword(HttpServletRequest request, HttpServletResponse response) End");
        return new ModelAndView("vascoPasswordDisplay",UIConstant.MODEL,outParams);
    }
	
	public ModelAndView displayOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("displayOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) Begin");
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        HttpSession session = request.getSession(false); 
        String sessionOTP= (String)session.getAttribute("highSecurityPassword");
        if(sessionOTP==null){
        	applicationResponse.setErrorCode(ServiceErrorConstants.SE002);
       }        
        logger.info("displayOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) End");
        return new ModelAndView("otpPasswordDisplay",UIConstant.MODEL,outParams);
    }
	
	public ModelAndView submitOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("submitOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) Begin");
        Map outParams = new HashMap();
        HttpSession session = request.getSession(false);
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        Integer userRole = 0;
        String redirectionString = "";
        if(session.getAttribute("userRole") != null) {
        	userRole = (Integer) session.getAttribute("userRole");
		}
        
        String enteredOTP = (String)request.getParameter("smsPassword");
        String sessionOTP= (String)session.getAttribute("highSecurityPassword");
        logger.info("otpPassword : " + enteredOTP +"sessionOTP" + sessionOTP );
        
        if(enteredOTP != null && enteredOTP.equalsIgnoreCase(sessionOTP)){
        	redirectionString = getPropertyVal("role"+userRole.toString());
        	logger.info("redirectionString : " + redirectionString);
        	getMailAlert(request);
        	getServletContext().getRequestDispatcher(redirectionString).forward(request,response);
        	applicationResponse.setErrorStatus("SUCCESS");
        } else {
        	applicationResponse.setErrorCode("CHEQ002");
        }
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("submitOTPSecurePassword(HttpServletRequest request, HttpServletResponse response) End");
        return new ModelAndView("otpPasswordDisplay",UIConstant.MODEL,outParams);
    }
	
	public ModelAndView mobileNoRegistrationDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("mobileNoRegistrationDisplay(HttpServletRequest request, HttpServletResponse response) Begin");
        
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	    
	    // Added for Mobile Number registration restriction for corpuploader
	    User user=(User)session.getAttribute(UIConstant.USER);
	    String userRole="";
		if(user.getRoles().get(0)!=null)
			userRole= user.getRoles().get(0).toString();
	    
	    String oldMobileNo = profile.getMobileNumber();
	    int userId = profile.getUserId();
	    String splitMobileNo="";
	    if(oldMobileNo != null){
	    	splitMobileNo = oldMobileNo.substring(7);
	    }
	    logger.info("userId : " +  userId+", oldMobileNo : " + splitMobileNo);
	    Map outParams = new HashMap();
		outParams.put("userId", userId);
		outParams.put("oldMobileNo", splitMobileNo);
		request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "RMN");
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		
		// Added for Mobile Number registration restriction  for corpuploader
		String viewName="mobileNoRegistrationDisplay";
		if("21".equals(userRole))
		{
			applicationResponse.setErrorCode("RM004");
			applicationResponse.setErrorStatus(ServiceErrorConstants.FAILURE);
			viewName = "errorMobileNoRegistrationDisplay";
		}
		else
		{
			applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);
		}
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);
		
		
		logger.info("Error Status " + applicationResponse.getErrorStatus());
        logger.info("mobileNoRegistrationDisplay(HttpServletRequest request, HttpServletResponse response) End");
        //return new ModelAndView("mobileNoRegistrationDisplay", "outParams", outParams);
        return new ModelAndView(viewName, "outParams", outParams);
    }
	
	public ModelAndView mobileNoRegistrationConfirm(HttpServletRequest request,HttpServletResponse response) {
		logger.info("mobileNoRegistrationConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
		
		 HttpSession session = request.getSession(false);
	     UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	     RegMobileNoDetails   regMobileNoDetails = new RegMobileNoDetails();
	     Integer userId = profile.getUserId();
	     String contryCode = request.getParameter("countryCode");
	     String mobileNo = request.getParameter("mobileNo");
	     String oldMobileNo =profile.getMobileNumber();
	     String modifyUser =profile.getUserName();
	     String branchCode=profile.getBranchCode();
	     Integer userRole = (Integer) profile.getRoles().get(0);
	     //String friendlyName = profile.getFriendlyName();
	     String friendlyName = profile.getName();
	     String cororateId = profile.getCorporateId();
	     String userAlias = profile.getUserAlias();
	     String empNo=profile.getEmpNo();
	     String viewName="";
	     logger.info("userId :"+userId+"contryCode :"+contryCode+"mobileNo :"+mobileNo+"oldMobileNo :"+oldMobileNo+"userRole :"+userRole);
		logger.info("Mobile No lenth:"+mobileNo.length());
			Map inParams = new HashMap();
			inParams.put("contryCode", contryCode);
			inParams.put("mobileNo", mobileNo);
			inParams.put("userId", userId);
			inParams.put("oldMobileNo",oldMobileNo);;
			inParams.put("modifyUser",modifyUser);
			inParams.put("branchCode",branchCode);
			inParams.put("userRole",userRole);
			inParams.put("cororateId", cororateId);
			inParams.put("userAlias", userAlias);
			inParams.put("friendlyName", friendlyName);
		
		Map outParams = new HashMap();
		
		outParams = registerMobileNoService.execute(inParams);
		SBIApplicationResponse applicationResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		
		if(applicationResponse.getErrorStatus().equalsIgnoreCase("success"))
		{
			regMobileNoDetails =(RegMobileNoDetails)outParams.get("regMobileNoDetails");
			session.setAttribute("referenceNo", regMobileNoDetails.getReferenceNo());
			session.setAttribute("newMobileNo", mobileNo);
			session.setAttribute("contryCode", contryCode);
			session.setAttribute("empNo", empNo);
			session.setAttribute("friendlyName", friendlyName);
			session.setAttribute("createdUserRole",regMobileNoDetails.getUserRole());
			viewName = "mobileNoRegistrationConfirm";
		} else {
			viewName = "errorMobileNoRegistrationConfirm";
			outParams.put(UIConstant.ERROR_VIEW, "errorMobileNoRegistrationConfirm");
		}
		logger.info("Error Status " + applicationResponse.getErrorStatus());
		logger.info("#################"+session.getAttribute("createdUserRole"));
		logger.info("mobileNoRegistrationConfirm(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView(viewName, "outParams",outParams);

	}
	
	public ModelAndView mobileNoViewRejectDisplay(HttpServletRequest request,HttpServletResponse response) {
		logger.info("mobileNoViewRejectDisplay(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		Map inParams = new HashMap();
		
		RegMobileNoDetails regMobileNoDetails = null ;
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	    String oldMobileNo = profile.getMobileNumber();
	    String userId = profile.getUserId().toString();
	    String userAlias = profile.getUserAlias();
	    String cororateId = profile.getCorporateId();
	    String splitMobileNo="";
	    inParams.put("userAlias",userAlias);
	    inParams.put("cororateId",cororateId);
	    inParams.put("userId",userId);
	    outParams = viewRejectMobileNoService.execute(inParams);
		outParams.put("userId", userId);
		outParams.put("oldMobileNo", splitMobileNo);
		//request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "RMN");
		String errorView="mobileNoViewRejectError";
		outParams.put("regMobileNoDetails", outParams.get("regMobileNoList"));
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get("applicationResponse");
		outParams.put(UIConstant.ERROR_VIEW,errorView);
		logger.info("=============errorResponse========="+errorResponse);
		logger.info("mobileNoViewRejectDisplay(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODEND);
		return new ModelAndView("mobileNoViewReject", "outParams",outParams);
	}
	
	public ModelAndView mobileNoRejectConfirmDisplay(HttpServletRequest request,HttpServletResponse response) {
		logger.info("mobileNoRejectConfirmDisplay(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		Map inParams = new HashMap();
		
		HttpSession session = request.getSession(false);
	    UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	   
	    String userId = profile.getUserId().toString();
	    String userAlias = profile.getUserAlias();
	    String cororateId = profile.getCorporateId();
	    String referenceNo=request.getParameter("referenceNo");
	    logger.info("=====referenceNo========"+referenceNo);
	   
	    inParams.put("userAlias",userAlias);
	    inParams.put("cororateId",cororateId);
	    inParams.put("userId",userId);
	    inParams.put("referenceNo",referenceNo);
	    outParams = rejectMobileNoConfirmService.execute(inParams);		
	    outParams.put("referenceNo",referenceNo);
	    String errorView="mobileNoViewRejectError";
	    
		//request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "RMN");
		  SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		 
		  logger.info("=============errorResponse========="+errorResponse);
		  outParams.put(UIConstant.APPLICATION_RESPONSE, errorResponse);
		  outParams.put(UIConstant.ERROR_VIEW,errorView);
		
		logger.info("mobileNoRejectConfirmDisplay(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("mobileNoRejectConfirm", "outParams",outParams);
	}
	
	//	Added for Second factor authentication verify profile password -Start	
	public ModelAndView sfaVerifyProfilePwdDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("sfaVerifyProfilePwdDisplay(HttpServletRequest request, HttpServletResponse response) Begin");
       Map outParams = new HashMap();
       String mobileRegistration = request.getParameter("mobileRegistration");
       String dscReRegistration = request.getParameter("dscReRegistration");
       logger.info("mobileRegistration : " + mobileRegistration);
       logger.info("dscReRegistration : " + dscReRegistration);
       outParams.put("mobileRegistration", mobileRegistration);
       outParams.put("dscReRegistration", dscReRegistration);
       logger.info("sfaVerifyProfilePwdDisplay(HttpServletRequest request, HttpServletResponse response) End");
       return new ModelAndView("sfaVerifyProfilePwdDisplay", "outParams", outParams);
    }
	//	Added for Second factor authentication verify profile password -End
	
	private String getPropertyVal(String key) {
		String value = "";
		try {
			logger.info("key val :" + key);
			value = logonProperty.getMessage(key, null, null);
		} catch (NoSuchMessageException ex) {
			logger.error("NoSuchMessageException occured", ex);
		}
		return value;
	}
	
	public void getMailAlert(HttpServletRequest request){
    	logger.info("=====getMailAlert() start vasco and mobile OTP===== " );
    	HttpSession session = request.getSession(false);   	    
        if(session!=null){
        	session.setAttribute("mailAlertFlag",true);
        }
        logger.info("=====getMailAlert() end vasco and mobile OTP===== " );
	}
	
	public void setLogonProperty(ResourceBundleMessageSource logonProperty) {
		this.logonProperty = logonProperty;
	}
	
	public void setValidateDigitalPasswordService(
			BaseService validateDigitalPasswordService) {
		this.validateDigitalPasswordService = validateDigitalPasswordService;
	}

	public void setRegisterMobileNoService(BaseService registerMobileNoService) {
		this.registerMobileNoService = registerMobileNoService;
	}

	public void setViewRejectMobileNoService(BaseService viewRejectMobileNoService) {
		this.viewRejectMobileNoService = viewRejectMobileNoService;
	}

	public void setRejectMobileNoConfirmService(
			BaseService rejectMobileNoConfirmService) {
		this.rejectMobileNoConfirmService = rejectMobileNoConfirmService;
	}
}
