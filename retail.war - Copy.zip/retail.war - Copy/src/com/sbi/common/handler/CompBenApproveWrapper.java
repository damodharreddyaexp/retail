/**CompBenApproveWrapper.java
 * Created on Sep 2013 
 * This class is common for Regulator,Admin and Approver.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */
package com.sbi.common.handler;

import org.displaytag.decorator.TableDecorator;

import com.sbi.common.model.CompBenDataModel;


public class CompBenApproveWrapper extends TableDecorator {       

	public String getBeneficiaryName() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel) super.getCurrentRowObject();          
	    String beneficiaryName="&nbsp;";    
	    if(compBenDataModel!= null) {
	    	beneficiaryName=compBenDataModel.getName();
	    }
	    return beneficiaryName;
	}
	public String getOutRef7() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String outRef7="&nbsp;";    
		
		if(compBenDataModel!= null) {
			outRef7=compBenDataModel.getOutRef7();
	    }
	    return outRef7;
	}

	public String getAccountNo(){
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();
		String accountNo=compBenDataModel.getAccountNo().toString();
		System.out.print("Account No Wrappper : " +accountNo);
		if(accountNo!=null) {
			accountNo.trim();
			if(accountNo.equals("0")) {
				accountNo="-";
				System.out.print(" Inside if accountNo : " +accountNo);
			}
		}
		return accountNo;
	}

	public String getBranchCode(){
	
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();
		String branchCode="";
		if(compBenDataModel.getBranchCode()!=null){
			branchCode=compBenDataModel.getBranchCode().toString();
			branchCode.trim();
			System.out.print("BranchCodeWrappper : "+branchCode);
			if(branchCode.equals("0")){
				branchCode="-";
				System.out.print(" Inside if branchCode : "+ branchCode);
			}
		}
		else {
			branchCode="-";
		}
		return branchCode;
	}
	public String getOutRef2() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String outRef2="&nbsp;";    
		
		if(compBenDataModel!= null) {
			outRef2=compBenDataModel.getOutRef2();
	    }
	    return outRef2;
	}
	public String getStatus() {
	    CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String status=compBenDataModel.getStatus().toString();
	
		if(status.equalsIgnoreCase("0")) {
			status=  "Pending for Approval";
		}
		else if(status.equalsIgnoreCase("1") || status.equalsIgnoreCase("3")) {
			status=  "Approved";
		}
		else if(status.equalsIgnoreCase("2")) {
			status=  "Rejected";
		}
		return status;
	}
	public String getCheckBox() {
	    CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String checkBox="&nbsp;";    

		checkBox="<input id='check'  name='check' type='checkbox' value=\"" +compBenDataModel.getOid() +";\" onclick='uncheckMain();' />";
		checkBox=  checkBox+"<input type='hidden' name='rec_selected' id='rec_selected' value='True'>";

	    return checkBox;
	}
	public String getOutRef1() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String outRef1="&nbsp;";    
		
		if(compBenDataModel!= null) {
			outRef1=compBenDataModel.getOutRef1();
	    }
	    return outRef1;
	}
	public String getAadharId() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String aadharId="&nbsp;";    
		
		if(compBenDataModel!= null) {
			aadharId=compBenDataModel.getAadharId();
	    }
	    return aadharId;
	}
	public String getBAnkIin() {
		CompBenDataModel compBenDataModel=  (CompBenDataModel)super.getCurrentRowObject();          
		String bankIIN="&nbsp;";    
		
		if(compBenDataModel!= null) {
			bankIIN=compBenDataModel.getBankIIN();
	    }
	    return bankIIN;
	}
}
    