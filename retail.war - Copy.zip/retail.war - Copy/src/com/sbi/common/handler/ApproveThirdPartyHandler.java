/*
 * AddThirdPartyHandler.java
 * Created on Mar 03, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 03, 2006 Sairam.T - Initial Creation
package com.sbi.common.handler;
   
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;


/**  
 * This class extends MultiActionController. approvebulkthirdparties.htm is
 * mapped to ApproveThirdPartyHandler Purpose: For displaying profile details
 * 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class ApproveThirdPartyHandler extends MultiActionController {

    protected final Logger logger = Logger.getLogger(getClass());


    BaseService approveDel3pService;
    
    
    BaseService approveTPDelFileService;
    
    BaseService approveDelTPConfirmService;
    
    BaseService approveDel3pViewService;

    BaseService verify3PforDeleteService;
    
    

    /**
    * This method is executed to display the ApproveThirdPartyFile Details(/approvebulkthirdparties.htm)
    * link in Profile is clicked.It calls approveTPService by
    * passing Map inParam which has userName. The service method returns the
    * map outParam consists of list of ApproveTpFileNames.
    * 
    * @param request
    * @param response
    */
   
    
     /**
     * This method is executed while submitting requested information from jsp and
     * calls the Request service with inputParams Map parameter.
     * The service returns an map which contains ApproveId and UnApproveId. 
     * 
     * @param request
     * @param response
     * @param object
     * @param exception
     * @return ModelAndView
     */
    

   

 
    
     /**
        * This method is executed to display the ApproveDeleteThirdPartyFile Details(/approvebulkthirdparties.htm)
        * link in Profile is clicked.It calls approveTPService by
        * passing Map inParam which has userName. The service method returns the
        * map outParam consists of list of ApproveDeleteTpFileNames.
        * 
        * @param request
        * @param response
        */
    
    public ModelAndView approveDel3pDisplayHandler(HttpServletRequest request, HttpServletResponse response){
        logger
        .info("approveDel3pDisplayHandler(HttpServletRequest request, HttpServletResponse response)"
                + LoggingConstants.METHODBEGIN);
         logger.info("inside common");
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map dateMap = new HashMap();
        Map approveTPDetails = new HashMap();
        HttpSession session = request.getSession();
        
        User user = (User) session.getAttribute(UIConstant.USER);
        String corporateId = user.getCorporateId();
        //Added by Sunjay S Galen for CR 2753
        String strStartDate = request.getParameter("startDate");
        String strEndDate = request.getParameter("endDate");
        if (strStartDate != null && strEndDate!=null)
        {
            
            dateMap.put("startDate",strStartDate);
            dateMap.put("endDate",strEndDate);
            session.setAttribute("datemap",dateMap);
         
        }
        else
        {
           
        dateMap=(Map)session.getAttribute("datemap");
        strStartDate=(String)dateMap.get("startDate");
        strEndDate=(String)dateMap.get("endDate");
                }
      
        String functionType="approve";
        //End for CR 2753
        logger.info("corporateID :" + corporateId);
        //      Added by Sunjay S Galen for CR 2753
        logger.info("start date :"+strStartDate+","+"End Date :"+strEndDate+","+"function type :"+functionType);
        //      End for CR 2753
        inputParam.put("corporateId",corporateId);
        //Added by Sunjay S Galen for CR 2753
        inputParam.put("startDate",strStartDate);
        inputParam.put("endDate",strEndDate);
        inputParam.put("functionType","approve");
        //End for CR 2753
        //String userRole=(String)user.getRoles().get(0);   
        Integer roleValue=(Integer) user.getRoles().get(0);
        logger.info("user roleeeeee"+roleValue);
        inputParam.put("userRole",roleValue);
         if (roleValue.intValue()==7 || roleValue.intValue()==42)
        {  
                  
        outputParam = verify3PforDeleteService.execute(inputParam); 
        String status  = (String) outputParam.get("status");
        if(status.equalsIgnoreCase("1"))  
        {
             
            SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
            outputParam.put(UIConstant.APPLICATION_RESPONSE, errorResponse);
            outputParam.put(UIConstant.ERROR_VIEW, "approvebulkthirdpartiesfiledelerror");
            return new ModelAndView("approveBulkThirdPartiesDelete","approveTPDisplayDetails", outputParam);
        }
        }
        String userName = user.getUserAlias();
        
        logger.info("userName :"+userName);
        inputParam.put(UIConstant.USER_NAME, userName);
        
        outputParam = approveTPDelFileService.execute(inputParam);
        
        logger.info("outputParam  :" + outputParam);
        approveTPDetails.put("approveTPDelFileDetails",outputParam.get("approveTPDelFileDetails"));
        //Added by Sunjay S Galen for CR 2753
        approveTPDetails.put("startDate",strStartDate);
        approveTPDetails.put("endDate",strEndDate);
        //End for CR 2753
        //approveTPDetails.put("approveTPDelFileDetails",outputParam);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam
        .get(UIConstant.APPLICATION_RESPONSE);
        
        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        logger.info("Error status = " + errorResponse.getErrorStatus());
        logger.info("Error code = " + errorResponse.getErrorCode());
        logger.info("Error message = " + errorResponse.getErrorMessage());
        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        
        approveTPDetails.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
        approveTPDetails.put(UIConstant.ERROR_VIEW, "approveDel3pDisplayHandlerErrorDel3P");
        
        logger.info("approveTPFileDetails :" + approveTPDetails);
        logger.info("approveDel3pDisplayHandler(HttpServletRequest request,HttpServletResponse response)"
                        + LoggingConstants.METHODEND);
        //MOdified by Sunjay S Galen for CR 2753
        return new ModelAndView("approveBulkThirdPartiesDelete","approveTPDisplayDetails", approveTPDetails);
    
    }
    
    /**
     * This method is executed while submitting requested information from jsp and
     * calls the Request service with inputParams Map parameter.
     * The service returns an map which contains Updated ApproveIds and UnApproveIds in confrm page. 
     * 
     * @param request
     * @param response
     * @param object
     * @param exception
     * @return ModelAndView
     */
    
    public ModelAndView approveDel3pConHanlder(HttpServletRequest request, HttpServletResponse response){
        logger.info("approveDel3pConHanlder(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
        
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveTPFileDetails = new HashMap();
        
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        
        String userName = user.getUserAlias();
        inputParam.put(UIConstant.USER_NAME, userName);
        
        String tpFileName = request.getParameter("fileName");
         
        //Added by Sunjay S Galen
        if (tpFileName!= null)
            {
                session.setAttribute("tpfilename",tpFileName);
            }else
            {
                tpFileName=(String) session.getAttribute("tpfilename");
            }
            
        inputParam.put(UIConstant.TP_FILE_NAME, tpFileName);
        
        logger.info("User Name :>>>>>>>>>" + userName);
        logger.info("tpFileName :>>>>>>>>" + tpFileName);
        
//      Added by srujana
        String particularPageNumber=request.getParameter("particularPageNumber");
        logger.info("particularPageNumber#####=="+particularPageNumber);
        String pageNumber=request.getParameter("pageNumber");
        String count=request.getParameter("count");
        String maxPage=request.getParameter("max");
        
            
        if(particularPageNumber==null)
            particularPageNumber="1";
        logger.info("particularPageNumber"+particularPageNumber);
        inputParam.put("particularPageNumber",particularPageNumber);
        inputParam.put("noOfRows","50");// Modified by Sunjay S Galen
        logger.info("noOfRecords###="+inputParam.get("noOfRows"));
        
        
        outputParam = approveDel3pService.execute(inputParam);
        
        
        approveTPFileDetails.put("approveFileDetails", outputParam
                .get("approveTPFileDetails"));
        approveTPFileDetails.put(UIConstant.TP_FILE_NAME, tpFileName);
        approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
        approveTPFileDetails.put("noOfRows","50");// Modified by Sunjay S Galen
        approveTPFileDetails.put("totalPage",outputParam.get("totalPage"));
        logger.info("totalPage======================="+approveTPFileDetails.get("totalPage"));
        /*approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
        approveTPFileDetails.put("noOfRows","10");
        int totalFileDetails=((Integer)outputParam.get("totalFileDetails")).intValue();
        int noOfRows=new Integer((String)approveTPFileDetails.get("noOfRows")).intValue();
        
        int totalPage=totalFileDetails/noOfRows;
        if(totalFileDetails%noOfRows!=0)
            totalPage=totalPage+1;
        logger.info("totalPage=="+totalPage);
        approveTPFileDetails.put("totalPage",new Integer(totalPage));
        */
        if(pageNumber==null)
            pageNumber="1";
        if(count==null)
            count="1";
        if(maxPage==null)
            maxPage="1";
        if(particularPageNumber==null)
            particularPageNumber="1"; 
        approveTPFileDetails.put("pageNumber",pageNumber);
        logger.info("pageNumber=="+approveTPFileDetails.get("pageNumber"));
        
        approveTPFileDetails.put("count",count);
        approveTPFileDetails.put("max",maxPage);
        approveTPFileDetails.put("particularPageNumber",particularPageNumber);
        logger.info("particularPageNumber=="+approveTPFileDetails.get("particularPageNumber"));
        
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam
        .get(UIConstant.APPLICATION_RESPONSE);
        
        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        logger.info("Error status = " + errorResponse.getErrorStatus());
        logger.info("Error code = " + errorResponse.getErrorCode());
        logger.info("Error message = " + errorResponse.getErrorMessage());
        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        
        approveTPFileDetails.put(UIConstant.APPLICATION_RESPONSE, outputParam
                .get(UIConstant.APPLICATION_RESPONSE));
        approveTPFileDetails.put(UIConstant.ERROR_VIEW,
                "approvebulkthirdpartiesdelconfirmerror");
        
                
        logger.info("approveDel3pConHanlder(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODEND);
        
        return new ModelAndView("approveBulkTPDelConfirm","approveTPFileDetails",approveTPFileDetails);
    }
    
    public ModelAndView approveDelTPConfirmationHandler(HttpServletRequest request, HttpServletResponse response) {

        logger.info("approveDelTPConfirmationHandler method"+LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map approveDetailsConfirm = new HashMap();
        String approveIds;
        String unApproveIds;
        List checkedList = new ArrayList();
        List unCheckedList = new ArrayList();
        String fileName;
        int i = 0;
        
        approveIds = request.getParameter("approvedIds");
        unApproveIds = request.getParameter("unApprovedIds");
        fileName = request.getParameter("tpFileName");
        
        String[] checkStatus = request.getParameterValues("check");
        List checkList = new ArrayList();
                        
        logger.info("fileName :" + fileName);
        logger.info("approveIds :" + approveIds);
        logger.info("unApproveIds " + unApproveIds);
        logger.info("particularPageNumber"+request.getParameter("particularPageNumber"));
        logger.info("noOFRows"+request.getParameter("noOFRows"));

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute(UIConstant.USER);
        String corporateId = user.getCorporateId();
        String userName = user.getUserAlias();
        inputParam.put(UIConstant.TP_FILE_NAME, fileName);
        inputParam.put(UIConstant.CORPORATE_ID, corporateId);
        inputParam.put(UIConstant.USER_NAME, userName);
        inputParam.put("particularPageNumber",request.getParameter("particularPageNumber"));
        inputParam.put("noOFRows",request.getParameter("noOFRows"));
        inputParam.put(UIConstant.APPROVE_IDS, approveIds);
        inputParam.put(UIConstant.UN_APPROVE_IDS, unApproveIds);
            
        outputParam = approveDelTPConfirmService.execute(inputParam);
        
        /*ApproveDelTPModel[] approveDelTPModel =(ApproveDelTPModel[])outputParam.get("approveTPFileConfirmDetails");
        //logger.info("ApproveDelTPModel :"+approveDelTPModel);
        //logger.info("ApproveDelTPModel :"+approveDelTPModel);
        logger.info("ApproveDelTPModel :"+approveDelTPModel);
        for(i=0; i<approveDelTPModel.length;i++){
            //logger.info("approve and unapprove===="+approveDelTPModel[i]);
            ApproveDelTPModel atp = approveDelTPModel[i];
                if(atp.getStatus().toString().equals("approved")){
                    checkedList.add(atp);
                    //logger.info("checkedList :"+checkedList.size());
                }else{
                    unCheckedList.add(atp);
                    //logger.info("unCheckedList :"+unCheckedList.size());
                }
            }
        */  
        
        approveDetailsConfirm.put("approveFileConfirmDetails", outputParam
                .get("approveTPFileConfirmDetails"));
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam
                .get(UIConstant.APPLICATION_RESPONSE);

        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        logger.info("Error status = " + errorResponse.getErrorStatus());
        logger.info("Error code = " + errorResponse.getErrorCode());
        logger.info("Error message = " + errorResponse.getErrorMessage());
        logger.info("Application response = "
                + outputParam.get(UIConstant.APPLICATION_RESPONSE));
        approveDetailsConfirm.put(UIConstant.APPLICATION_RESPONSE, outputParam
                .get(UIConstant.APPLICATION_RESPONSE));
        approveDetailsConfirm.put(UIConstant.ERROR_VIEW,
                "approveDelTPConfirmationError");
        
        logger.info("unCheckedList :"+unCheckedList);
        logger.info("checkedList :"+checkedList);
        approveDetailsConfirm.put("checkedList",outputParam.get("checkedList"));
        approveDetailsConfirm.put("unCheckedList",outputParam.get("unCheckedList"));
        logger.info("approveDelTPConfirmationHandler method"+LoggingConstants.METHODEND);
        return new ModelAndView("approveDelTPConfirmation",
                "approveDetailsConfirm", approveDetailsConfirm);

    }

//Added by Sunjay S Galen
    

    
     public ModelAndView approveDelete3pDisplay(HttpServletRequest request, HttpServletResponse response) {
            logger.info("approveDelete3pDisplay() method begin");
            Map inputParams = new HashMap();
            HttpSession session = request.getSession(false);
            User user = (User) session.getAttribute(UIConstant.USER);
            inputParams.put(UIConstant.USER_NAME, user.getUserAlias());
            Map outputParams = new HashMap();
            String viewName;
            String Url=request.getServletPath().substring(1);
            logger.info("URL:"+Url);
            if (Url.equals("approvedel3padminlanding.htm"))
            viewName="approveDel3PDisplayDetails";
            else
            viewName="approveDelete3pViewDetails";
           SBIApplicationResponse res=new SBIApplicationResponse();
            res.setErrorStatus(UIConstant.SUCCESS);         
           outputParams.put(UIConstant.ERROR_VIEW,null);
           outputParams.put(UIConstant.APPLICATION_RESPONSE,res);
            logger.info("approveDelete3pDisplay() method ends");   
            return new ModelAndView(viewName, "model", outputParams);
        }

     public ModelAndView approveDel3pViewHandler(HttpServletRequest request, HttpServletResponse response){
         logger
         .info("approveDel3pViewHandler(HttpServletRequest request, HttpServletResponse response)"
                 + LoggingConstants.METHODBEGIN);
          
         Map inputParam = new HashMap();
         Map outputParam = new HashMap();
         Map approveTPDetails = new HashMap();
         HttpSession session = request.getSession();
         
         User user = (User) session.getAttribute(UIConstant.USER);
         String corporateId = user.getCorporateId();
         String strStartDate = request.getParameter("startDate");
         String strEndDate = request.getParameter("endDate");
         Integer roleValue=(Integer) user.getRoles().get(0);
         logger.info("user roleeeeee"+roleValue);
         String functionType="view";
         logger.info("corporateID :" + corporateId);
         logger.info("start date :"+strStartDate+","+"End Date :"+strEndDate+","+"function type :"+functionType);
         inputParam.put("corporateId",corporateId);
         logger.info("corp id :"+corporateId);
         inputParam.put("startDate",strStartDate);
         inputParam.put("endDate",strEndDate);
         inputParam.put("functionType","view"); 
         inputParam.put("userRole",roleValue);
          String userName = user.getUserAlias();
         
         logger.info("userName :"+userName);
         inputParam.put(UIConstant.USER_NAME, userName);
         
         outputParam = approveTPDelFileService.execute(inputParam);
         logger.info("outputParam  :" + outputParam);
         approveTPDetails.put("approveTPDelFileDetails",outputParam.get("approveTPDelFileDetails"));
         approveTPDetails.put("outputParam",outputParam);
          SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);
          logger.info("Application response = "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
         logger.info("Error status = " + errorResponse.getErrorStatus());
         logger.info("Error code = " + errorResponse.getErrorCode());
         logger.info("Error message = " + errorResponse.getErrorMessage());
         logger.info("Application response = "+ outputParam.get(UIConstant.APPLICATION_RESPONSE));
         
         approveTPDetails.put(UIConstant.APPLICATION_RESPONSE, outputParam.get(UIConstant.APPLICATION_RESPONSE));
         approveTPDetails.put(UIConstant.ERROR_VIEW,"approveDel3pViewHandlerErrorView");
         
         approveTPDetails.put("startDate",strStartDate);
         approveTPDetails.put("endDate",strEndDate);
            
         logger.info("approveTPDetails :" + approveTPDetails);
         logger.info("approveDel3pViewHandler(HttpServletRequest request,HttpServletResponse response)"
                         + LoggingConstants.METHODEND);

         return new ModelAndView("approveBulkThirdPartiesViewReg","approveTPDisplayDetails", approveTPDetails);
     
     }
     public ModelAndView approveDel3pConViewHanlder(HttpServletRequest request, HttpServletResponse response){
         logger.info("approveDel3pConViewHanlder(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
         
         Map inputParam = new HashMap();
         Map outputParam = new HashMap();
         Map approveTPFileDetails = new HashMap();
         
         HttpSession session = request.getSession(false);
         User user = (User) session.getAttribute(UIConstant.USER);
         
         String userName = user.getUserAlias();
         inputParam.put(UIConstant.USER_NAME, userName);
       
         String strStartDate = request.getParameter("startDate");
         String strEndDate = request.getParameter("endDate");
         logger.info("start date :"+strStartDate+","+"End Date :"+strEndDate);
         String tpFileName = request.getParameter("fileName");
         inputParam.put(UIConstant.TP_FILE_NAME, tpFileName);
         inputParam.put("startDate",strStartDate);
         inputParam.put("endDate",strEndDate);
         logger.info("User Name :>>>>>>>>>" + userName);
         logger.info("tpFileName :>>>>>>>>" + tpFileName);
         String particularPageNumber=request.getParameter("particularPageNumber");
         logger.info("particularPageNumber#####=="+particularPageNumber);
         String pageNumber=request.getParameter("pageNumber");
         String count=request.getParameter("count");
         String maxPage=request.getParameter("max");
         
             
         if(particularPageNumber==null)
             particularPageNumber="1";
         logger.info("particularPageNumber"+particularPageNumber);
         inputParam.put("particularPageNumber",particularPageNumber);
         inputParam.put("noOfRows","50");
         logger.info("noOfRecords###="+inputParam.get("noOfRows"));
         
         
         outputParam = approveDel3pViewService.execute(inputParam);
         
         approveTPFileDetails.put("approveFileDetails", outputParam
                 .get("approveTPFileDetails"));
         approveTPFileDetails.put(UIConstant.TP_FILE_NAME, tpFileName);
         approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
         approveTPFileDetails.put("noOfRows","50");
         approveTPFileDetails.put("totalPage",outputParam.get("totalPage"));
         logger.info("totalPage======================="+approveTPFileDetails.get("totalPage"));
         /*approveTPFileDetails.put("totalFileDetails",outputParam.get("totalFileDetails"));
         approveTPFileDetails.put("noOfRows","10");
         int totalFileDetails=((Integer)outputParam.get("totalFileDetails")).intValue();
         int noOfRows=new Integer((String)approveTPFileDetails.get("noOfRows")).intValue();
         
         int totalPage=totalFileDetails/noOfRows;
         if(totalFileDetails%noOfRows!=0)
             totalPage=totalPage+1;
         logger.info("totalPage=="+totalPage);
         approveTPFileDetails.put("totalPage",new Integer(totalPage));
         */
         if(pageNumber==null)
             pageNumber="1";
         if(count==null)
             count="1";
         if(maxPage==null)
             maxPage="1";
         if(particularPageNumber==null)
             particularPageNumber="1"; 
         approveTPFileDetails.put("pageNumber",pageNumber);
         logger.info("pageNumber=="+approveTPFileDetails.get("pageNumber"));
         
         approveTPFileDetails.put("count",count);
         approveTPFileDetails.put("max",maxPage);
         approveTPFileDetails.put("particularPageNumber",particularPageNumber);
         approveTPFileDetails.put("startDate",strStartDate);
         approveTPFileDetails.put("endDate",strEndDate);
         logger.info("particularPageNumber=="+approveTPFileDetails.get("particularPageNumber"));
         logger.info("status"+approveTPFileDetails.get("status"));
         
         
         SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam
         .get(UIConstant.APPLICATION_RESPONSE);
         
         logger.info("Application response = "
                 + outputParam.get(UIConstant.APPLICATION_RESPONSE));
         logger.info("Error status = " + errorResponse.getErrorStatus());
         logger.info("Error code = " + errorResponse.getErrorCode());
         logger.info("Error message = " + errorResponse.getErrorMessage());
         logger.info("Application response = "
                 + outputParam.get(UIConstant.APPLICATION_RESPONSE));
         
         approveTPFileDetails.put(UIConstant.APPLICATION_RESPONSE, outputParam
                 .get(UIConstant.APPLICATION_RESPONSE));
         approveTPFileDetails.put(UIConstant.ERROR_VIEW,
                 "approveDel3pConViewErrorView");
         
                 
        
         logger.info("approveDel3pConViewHanlder(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODEND);
         
         return new ModelAndView("approveTPDelViewConfirmReg","approveTPFileDetails",approveTPFileDetails);
     }
    /**
     * @param approveTPService The approveTPService to set.
     */


   


    public void setApproveDel3pService(BaseService approveDel3pService)
    {
        this.approveDel3pService = approveDel3pService;
    }


    public void setApproveDel3pViewService(BaseService approveDel3pViewService)
    {
        this.approveDel3pViewService = approveDel3pViewService;
    }


    public void setApproveDelTPConfirmService(BaseService approveDelTPConfirmService)
    {
        this.approveDelTPConfirmService = approveDelTPConfirmService;
    }


    public void setApproveTPDelFileService(BaseService approveTPDelFileService)
    {
        this.approveTPDelFileService = approveTPDelFileService;
    }

    public void setVerify3PforDeleteService(BaseService verify3PforDeleteService)
    {
        this.verify3PforDeleteService = verify3PforDeleteService;
    }
    


    /**
     * @param approveTPConfirmService The approveTPConfirmService to set.
     */
    
    



   
    
}
