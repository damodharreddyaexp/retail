/*
 * ForceChangeLoginPasswordHandler.java
 * Created on Jun 1,2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jun 1, 2011 SIVA KRISHNA  - Initial Creation
package com.sbi.common.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.SecondFactorAuthDisplay;
import com.sbi.common.handler.UIConstant;


public class ForceChangeLoginPasswordHandler extends MultiActionController {
	
protected final Logger logger = Logger.getLogger(getClass());
    
      
    private UserSessionCache userSessionCache;
    
    private BaseService verifyProfilePwdService; 
    
    private BaseService changeLoginPasswordService;
    
    private Map<String, String> profilePwdRequiredMap;
    
    private String moduleName;
    
    private SecondFactorAuthDisplay secondFactorAuthDisplay;//added for redirecting to second factor authentication page
    /**
     * @param userSessionCache The userSessionCache to set.
     */
    public void setUserSessionCache(UserSessionCache userSessionCache)
    {
        this.userSessionCache = userSessionCache;
    }
    public ModelAndView verifyProfilePassword(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("inside verifyProfilePassword");
   	//Added by thanga for 90 days validation fetching moduleName from configuration property
  
       //referer check - starts - Added by Indira
       if(isRefererNull(request)){
           try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                logger.info("Exception occur in ChangeUserNameHandler : "
                        + ex.getMessage());
            }
            return null;
       }
       //referer check - ends
       String view="forceChangeLoginPwd";
       HttpSession session = request.getSession(false);
       User user = (User) session.getAttribute(UIConstant.USER);
       List userRole=user.getRoles();
       String loggedinRole=userRole.get(0).toString();
     
   	//Modified by thanga for 90 days validation fetching moduleName from configuration property

       if("YES".equalsIgnoreCase(profilePwdRequiredMap.get(moduleName))) {
    	   view="verifyProfilepwd";
       }
       //role value handled to verify the corpapprover since approver uses corpuser application
       if("42".equalsIgnoreCase(loggedinRole))
    	   view="forceChangeLoginPwd";
   	//Modified by thanga for 90 days validation fetching moduleName from configuration property
 
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        logger.info("viewName:::"+view);
        return new ModelAndView(view,UIConstant.MODEL,outParams);
    }
    
    
    public ModelAndView loginPwdChangeDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
       logger.info("inside loginPwdChangeDisplay");
       //referer check - starts - Added by Indira
       if(isRefererNull(request)){
           try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                logger.info("Exception occur in ChangeUserNameHandler : "
                        + ex.getMessage());
            }
            return null;
       }
       //referer check - ends
        Map outParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        outParams.put(UIConstant.APPLICATION_RESPONSE,applicationResponse);
        return new ModelAndView("loginPwdChangeDisplay",UIConstant.MODEL,outParams);
    }

    
    
    public ModelAndView verifyProfilePasswordConfirm(HttpServletRequest request, HttpServletResponse response) 
    throws Exception {
       logger.info("verifyProfilePasswordConfirm() method begin");
       
       if(isRefererNull(request)){
           try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                logger.info("Exception occur in ChangeUserNameHandler : "
                        + ex.getMessage());
            }
            return null;
       }
       String profilePassword = request.getParameter(UIConstant.USER_PROFILE_PASSWORD);
       Map inputParams = new HashMap();
       HttpSession session = request.getSession(false);
       User user = (User) session.getAttribute(UIConstant.USER);
       String view=null; 
       boolean flag=false;
       inputParams.put(ServiceConstant.USER_NAME, user.getUserAlias());
       inputParams.put(UIConstant.USER_PROFILE_PASSWORD, profilePassword);
       
       //Added for SHA encryption algorithm
       String profileSHAPwd = request.getParameter(UIConstant.USER_PROFILE_SHA_PASSWORD);
       inputParams.put(UIConstant.USER_PROFILE_SHA_PASSWORD, profileSHAPwd);
       
       Map outParam = verifyProfilePwdService.execute(inputParams);
       SBIApplicationResponse appResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
       logger.info("Application Response status : " + appResponse.getErrorStatus());

       if ((appResponse.getErrorStatus()).equalsIgnoreCase(UIConstant.SUCCESS))
       {
    	   logger.info("<----------ProfilePassword is correct--------->");
    	   view="forceChangeLoginPwd";
    	   outParam.put("flag", flag);
    	   //return new ModelAndView(UIConstant.CHANGE_LOG_PWD_VIEW, UIConstant.USER_DETAILS, outParam);
    	   //return new ModelAndView(UIConstant.PERSONAL_PROFILE_VIEW, UIConstant.USER_DETAILS, outParam);
       }
       else{ 
		      view = UIConstant.PROFILE_PWD_ERRORVIEW;
		      outParam.put(UIConstant.ERROR_VIEW,UIConstant.PROFILE_PWD_ERRORVIEW);
    	    //return new ModelAndView(pwdErrorView, UIConstant.USER_DETAILS, outParam);
       }
       return new ModelAndView(view, UIConstant.ERROR_MODEL, outParam);
       
    }
    
    public ModelAndView forceChangeLoginPwdConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
      logger.info("forceChangeLoginPwdConfirm(Method begins");
    
      if(isRefererNull(request)){
          try{
            request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
          }catch (Exception ex) {
             ex.printStackTrace();
             logger.info("Exception occur in ChangeUserNameHandler : "
                     + ex.getMessage());
          }
          return null;
        }
    
           HttpSession session = request.getSession(false);
           Map inParams = new HashMap();
           Map outParam = new HashMap();
           User user = (User) session.getAttribute(UIConstant.USER);
           String oldLoginPassword = request.getParameter(UIConstant.OLD_LOGIN_PASSWORD);
           String newLoginPassword = request.getParameter(UIConstant.NEW_PASSWORD);
           String confirmLoginPassword = request.getParameter(UIConstant.CONFIRM_PASSWORD);
           String view="";
           boolean flag=false;
           //String logonView=request.getParameter("loginChangePasswordView");
           inParams.put(UIConstant.USER, user);
           inParams.put(UIConstant.OLD_LOGIN_PASSWORD, oldLoginPassword);
           inParams.put(UIConstant.NEW_PASSWORD, newLoginPassword);
           inParams.put(UIConstant.CONFIRM_PASSWORD, confirmLoginPassword);
           inParams.put("keyid",session.getAttribute("keyid"));//Added For Cr 5274
           session.removeAttribute("keyid");//Added For Cr 5274
           outParam = changeLoginPasswordService.execute(inParams);
           SBIApplicationResponse appResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
           logger.info("Application Response status : " + appResponse.getErrorStatus());
           /*outParam.put(UIConstant.ERROR_VIEW, UIConstant.ERROR_CHANGE_LOGIN_PWD);
           if(logonView!=null){
           		view="logonChangePwdConfirm";
           		outParam.put(UIConstant.ERROR_VIEW, "loginChangeProfilePassword");
           		session.setAttribute("logonDateDifference","true");
           }		
           logger.info("forceChangeLoginPwdConfirm() Method ends");
           request.setAttribute(UIConstant.TRANSACTION_NAME, "PWD");*/
           if ((appResponse.getErrorStatus()).equalsIgnoreCase(UIConstant.SUCCESS))
           {
        	   session.removeAttribute("forceChangeFlag");
        	   session.removeAttribute("changePwdGracePeriodFlag");
        	   session.removeAttribute("priorInfoPeriodFlag");
        	   session.removeAttribute("loginPwdExpiryDayLimit");
        	   logger.info("<----------LoginPassword has been changed--------->");
        	   //view="forceChangeLoginPwdConfirm";
        	   flag=true;
        	   outParam.put("flag", flag);
        	   outParam.put("Password",newLoginPassword);
        	   view ="forceChangeLoginPwd";
        	   //return new ModelAndView(UIConstant.CHANGE_LOG_PWD_VIEW, UIConstant.USER_DETAILS, outParam);
        	   //return new ModelAndView(UIConstant.PERSONAL_PROFILE_VIEW, UIConstant.USER_DETAILS, outParam);
           }
           else{ 
    		      view ="forceChangeLoginPwd";
    		      //outParam.put(UIConstant.ERROR_VIEW,UIConstant.PROFILE_PWD_ERRORVIEW);
        	    //return new ModelAndView(pwdErrorView, UIConstant.USER_DETAILS, outParam);
           }
           return new ModelAndView(view, UIConstant.ERROR_MODEL, outParam);
    	
    }
   
    
    
    
    private boolean isRefererNull(HttpServletRequest request) {
        //Referer check - starts
        HttpSession session = request.getSession(false);
        String refervalue = request.getHeader("referer");
        boolean isrefererNull=false;
        if (refervalue== null) {
            logger.info("referer is null");
            if (session != null)
                session.invalidate();
            isrefererNull=true;
        }
        return isrefererNull;

    }
    
    public ModelAndView sfaVerifyProfilePasswordConfirm(HttpServletRequest request, HttpServletResponse response) 
    throws Exception {
       logger.info("sfaVerifyProfilePasswordConfirm() method begin");
       
       if(isRefererNull(request)){
           try{
               request.getRequestDispatcher("/nullreferer.htm").forward(request, response);
            }catch (Exception ex) {
                ex.printStackTrace();
                logger.info("Exception occur in ChangeUserNameHandler : "
                        + ex.getMessage());
            }
            return null;
       }
       String profilePassword = request.getParameter(UIConstant.USER_PROFILE_PASSWORD);
 		String profileSHAPassword = request.getParameter("profileSHAPassword"); //Added for SHA 512
      
       Map inputParams = new HashMap();
       HttpSession session = request.getSession(false);
       User user = (User) session.getAttribute(UIConstant.USER);
       String view=null; 
       boolean flag=false;
       inputParams.put(ServiceConstant.USER_NAME, user.getUserAlias());
       inputParams.put(UIConstant.USER_PROFILE_PASSWORD, profilePassword);
       inputParams.put("profileSHAPassword", profileSHAPassword);
       
       
       Map outParam = verifyProfilePwdService.execute(inputParams);
       SBIApplicationResponse appResponse = (SBIApplicationResponse) outParam.get(UIConstant.APPLICATION_RESPONSE);
       logger.info("Application Response status : " + appResponse.getErrorStatus());
       String mobileRegistration = request.getParameter("mobileRegistration");
       String dscReRegistration = (String)request.getParameter("dscReRegistration"); //Added for DSC
       logger.info("mobileRegistration : " + mobileRegistration);
       
       if ((appResponse.getErrorStatus()).equalsIgnoreCase(UIConstant.SUCCESS))
       {
    	   logger.info("<----------ProfilePassword is correct--------->");
    	   
    	   request.setAttribute("isProfilePwdCorrect","Yes");
    	   String redirectUrl="";
    	   if("dscReRegister".equalsIgnoreCase(dscReRegistration)) {//Add for DSC - START
    		   outParam.put("dscReRegistration",dscReRegistration);
    		   
    		   view="reregisterdscdisplayloginmode";
    		   return new ModelAndView(view, "outParams", outParam);
    	   } //Add for DSC - END
    	   else {
    		  redirectUrl=	secondFactorAuthDisplay.redirectPage(request, response);
    	   }
    	   if(redirectUrl!=null&redirectUrl.length()>0){
    		   response.sendRedirect(redirectUrl);
    		   return null;
			}
	   }
       else{ 
		      view = "errorSfaVerifyProfilePwdDisplay";
		      outParam.put(UIConstant.ERROR_VIEW,UIConstant.PROFILE_PWD_ERRORVIEW);
       }
       outParam.put("mobileRegistration", mobileRegistration); 
       outParam.put("dscReRegistration", dscReRegistration);   
 	   logger.info("sfaVerifyProfilePasswordConfirm() method end");
       return new ModelAndView(view, UIConstant.ERROR_MODEL, outParam);
       
    }
    
    public void setVerifyProfilePwdService(BaseService verifyProfilePwdService) {
        this.verifyProfilePwdService = verifyProfilePwdService;
    }
    
    public void setChangeLoginPasswordService(BaseService changeLoginPasswordService) {
        this.changeLoginPasswordService = changeLoginPasswordService;
    }
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public void setProfilePwdRequiredMap(Map<String, String> profilePwdRequiredMap) {
		this.profilePwdRequiredMap = profilePwdRequiredMap;
	}
	public void setSecondFactorAuthDisplay(
			SecondFactorAuthDisplay secondFactorAuthDisplay) {
		this.secondFactorAuthDisplay = secondFactorAuthDisplay;
	}
	
}
