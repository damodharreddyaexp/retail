package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.HardwareTokenDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;

public class EnableHardwareTokenHandler extends MultiActionController {

protected final Logger logger = Logger.getLogger(getClass());

private BaseService enableHardwareTokenService;
private BaseService hardwareTokenFormService;//Added for second factor authentication


	public ModelAndView enableHardwareTokenHandler(HttpServletRequest request, HttpServletResponse response) {
    logger.info("enableHardwareTokenHandler method begin");
    Map inputParams = new HashMap();
    Map outputParams = new HashMap();     
    HttpSession session = request.getSession(false);
    request.setAttribute(com.sbi.common.handler.UIConstant.TRANSACTION_NAME, "VAS");
    SBIApplicationResponse res=new SBIApplicationResponse();      
    logger.info("enableHardwareTokenHandler method ends");   
    return new ModelAndView("hardwareTokenRequest", "outputParams", outputParams);
}
	
	public ModelAndView enableHardwareTokenConfirm(HttpServletRequest request, HttpServletResponse response) {
	    logger.info("enableHardwareTokenConfirm method begin");
		HttpSession session = request.getSession(false);
		UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
		HardwareTokenDetails hardwareTokenDetails = new HardwareTokenDetails();
		Integer userId = profile.getUserId();
		String branchCode = profile.getBranchCode();
		Integer userRole = (Integer) profile.getRoles().get(0);
		String friendlyName = profile.getFriendlyName();
		String corporateId = profile.getCorporateId();
		String userAlias = profile.getUserAlias();
		logger.info("userId :" + userId + "userRole :" + userRole);
		Map inParams = new HashMap();	
		inParams.put("userId", userId);
		inParams.put("branchCode", branchCode);
		inParams.put("userRole", userRole);
		inParams.put("corporateId", corporateId);
		inParams.put("userAlias", userAlias);
		inParams.put("friendlyName", friendlyName);

		Map outputParams = new HashMap();

		outputParams = enableHardwareTokenService.execute(inParams);
		SBIApplicationResponse applicationResponse = (SBIApplicationResponse) outputParams.get(UIConstant.APPLICATION_RESPONSE);

		if (applicationResponse.getErrorStatus().equalsIgnoreCase("success")) 
		{
			hardwareTokenDetails = (HardwareTokenDetails) outputParams.get("hardwareTokenDetails");
			session.setAttribute("referenceNo", hardwareTokenDetails.getReferenceNo());
		}
		logger.info("Error Status " + applicationResponse.getErrorStatus());
		logger.info("enableHardwareTokenConfirm method ends");   
	    return new ModelAndView("hardwareTokenConfirm", "outputParams", outputParams);
	
	
}
	public ModelAndView getC10FormListDetails(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("getC10FormListDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		String errorView=null;
		
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(UIConstant.USER);    
		
		inputParams.put("userId", user.getUserId());
		inputParams.put("corporateId",user.getCorporateId());
		inputParams.put("functionType","listView");
		
		outParams=hardwareTokenFormService.execute(inputParams);
		outParams.put("userName", user.getUserAlias());
		outParams.put(UIConstant.ERROR_VIEW,errorView);
	    logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    
	    logger.info("getC10FormListDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("c10formlistdetails","model",outParams);
	}
	
	public ModelAndView getC10FormDetails(HttpServletRequest request,HttpServletResponse response)
	{
		logger.info("getC10FormDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODBEGIN);
		Map inputParams=new HashMap();
		Map outParams=new HashMap();
		String errorView=null;
		HttpSession session = request.getSession(false);
		String referenceNo = (String)request.getParameter("referenceNo");
		
		inputParams.put("referenceNo", referenceNo);
		
		outParams=hardwareTokenFormService.execute(inputParams);
		
		session.setAttribute("referenceNo",outParams.get("referenceNo"));
        
        logger.info("Application response" + outParams.get(UIConstant.APPLICATION_RESPONSE));
	    outParams.put(UIConstant.ERROR_VIEW,errorView);
	    
	    logger.info("getC10FormDetails(HttpServletRequest request,HttpServletResponse response)"+LoggingConstants.METHODEND);
		return new ModelAndView("c10formdetails","model",outParams);
	}
	
	public void setEnableHardwareTokenService(BaseService enableHardwareTokenService) {
		this.enableHardwareTokenService = enableHardwareTokenService;
	}

	public void setHardwareTokenFormService(BaseService hardwareTokenFormService) {
		this.hardwareTokenFormService = hardwareTokenFormService;
	}
	
}


