/*
 * AddThirdPartyHandler.java
 * Created on Mar 03, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 03, 2006 Sairam.T - Initial Creation
package com.sbi.common.handler;
   
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.User;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.handler.UIConstant;


/**  
 * This class extends MultiActionController. approvebulkthirdparties.htm is
 * mapped to ApproveThirdPartyHandler Purpose: For displaying profile details
 * 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class ApproveBeneficiaryHandler extends MultiActionController {

    protected final Logger logger = Logger.getLogger(getClass());

    BaseService approveBeneficiaryDisplayService;

    BaseService approveBeneficiaryConfirmService;    
    
    private Map typeResolver;  
    
    public ModelAndView approveBeneficiaryDisplayHandler(HttpServletRequest request, HttpServletResponse response){
        logger.info("approveBeneficiaryDisplayHandler(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map dateMap = new HashMap();        
        HttpSession session = request.getSession();        
        User user = (User) session.getAttribute(UIConstant.USER);
        String type=(String)typeResolver.get(request.getServletPath());  
        inputParam.put("type",type);
        inputParam.put("user", user);
        outputParam = approveBeneficiaryDisplayService.execute(inputParam);
        outputParam.put("type", type);
        logger.info("type >>>>"+type);
               
        /* Added by Sairam Mobile Registration Phase2 - Start */	     
        CorporateProfile corporateProfile=(CorporateProfile) session.getAttribute("corp_profile");
        String ehsEnable =null;
        String ehsType =null;
        String transactionName = "AppoveBen";
        if(corporateProfile != null){
        	ehsEnable = corporateProfile.getEhsEnable();
        	ehsType = corporateProfile.getEhsType();
        }
        logger.info("ehsEnable :"+ehsEnable);
        logger.info("ehsType :"+ehsType);
        outputParam.put("ehsEnable", ehsEnable);
        outputParam.put("ehsType", ehsType);
        outputParam.put("transactionName", transactionName);
        /* Added by Sairam Mobile Registration Phase2 - End */
       
        
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);               
        logger.info("approveBeneficiaryDisplayHandler(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
        return new ModelAndView("approveBeneficiaryDisplay","model", outputParam);
    
    }

    
    public ModelAndView approveBeneficiaryConfirmHandler(HttpServletRequest request, HttpServletResponse response){
        logger.info("approveBeneficiaryConfirmHandler(HttpServletRequest request, HttpServletResponse response)" + LoggingConstants.METHODBEGIN);
        Map inputParam = new HashMap();
        Map outputParam = new HashMap();
        Map dateMap = new HashMap();        
        HttpSession session = request.getSession();        
        User user = (User) session.getAttribute(UIConstant.USER);
        String type=(String)typeResolver.get(request.getServletPath());  
        logger.info(request.getParameter("actionType"));
        logger.info(request.getParameter("inputs"));
        inputParam.put("type",type);
        inputParam.put("actionType",request.getParameter("actionType"));
        inputParam.put("oids",request.getParameter("oids"));
        inputParam.put("remarks",request.getParameter("remarks"));
        inputParam.put("user", user);
        outputParam = approveBeneficiaryConfirmService.execute(inputParam);
        outputParam.put("type", type);
        SBIApplicationResponse errorResponse = (SBIApplicationResponse) outputParam.get(UIConstant.APPLICATION_RESPONSE);            
        logger.info("approveBeneficiaryConfirmHandler(HttpServletRequest request,HttpServletResponse response)" + LoggingConstants.METHODEND);
        return new ModelAndView("approve"+type+"BeneficiaryConfirm","model", outputParam);
    
    }
	public void setApproveBeneficiaryDisplayService(
			BaseService approveBeneficiaryDisplayService) {
		this.approveBeneficiaryDisplayService = approveBeneficiaryDisplayService;
	}



	public void setApproveBeneficiaryConfirmService(
			BaseService approveBeneficiaryConfirmService) {
		this.approveBeneficiaryConfirmService = approveBeneficiaryConfirmService;
	}

	public void setTypeResolver(Map typeResolver) {
		this.typeResolver = typeResolver;
	}
   
}
