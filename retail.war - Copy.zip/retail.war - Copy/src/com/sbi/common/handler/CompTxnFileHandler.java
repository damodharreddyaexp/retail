
/*
 * CompTxnFileHandler.java
 * Created on August 31, 2013
 *  
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.handler.UIConstant;


public class CompTxnFileHandler extends MultiActionController
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService compTxnFileConfigService;
	private BaseService compTxnSetFileService;
	private BaseService compTxnSetFileCheckService;
	
	
	
	public ModelAndView viewExisTxnFileConfigDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewExisTxnFileConfigDisplay -- begins");
        HttpSession session = request.getSession(false);
        Map inParam = new HashMap();
 	    Map outParams = new HashMap();
 	    String viewName = "viewExisTxnFileConfigDisplay";
 	    
 	    User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String fileType = "COMPOSITE_TXN";
		inParam.put("corporateId", corporateId);
		inParam.put("funcType", "getNewFileConfigDtls");
		inParam.put("fileType",fileType);
		
 	    outParams = compTxnFileConfigService.execute(inParam);
 	    
 	    if(outParams.get("fileconfiguration")!=null) {
 	    	viewName = "viewExisTxnFileConfigDetails";
 	    }
 	    
 	    logger.info("viewExisTxnFileConfigDisplay -- ends");
        return new ModelAndView(viewName, "fileConfigParams", outParams);
       
    }
	
	public ModelAndView viewExisTxnFileConfigDetails(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("viewExisTxnFileConfigDetails -- begins");
        HttpSession session = request.getSession(false);
        Map inParam = new HashMap();
 	    Map outParams=new HashMap();
 	    User user=(User)session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
		String fileType = request.getParameter("filetype");
		inParam.put("corporateId", corporateId);
		inParam.put("fileType",fileType);
		
 	    outParams = compTxnFileConfigService.execute(inParam);
 	    outParams.put("txnType",fileType);
 	    logger.info("viewExisTxnFileConfigDetails -- ends");
        return new ModelAndView("viewExisTxnFileConfigDetails", "fileConfigParams", outParams);
       
    }
	
    public ModelAndView setNewTxnFileConfig(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("setNewtxnFileConfig -- begins");
        HttpSession session = request.getSession(false);
 	    Map inParams = new HashMap();
 	    Map outParams=new HashMap();
 	    String compCheckVal;
 	    String viewName;
 	    viewName = "setNewtxnFileConfig";
        User user=(User)session.getAttribute(UIConstant.USER);
        CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
        int smallFlag = corporateProfile.getSmallFlag();
        String corporateId = user.getCorporateId();
        inParams.put("corporateId",corporateId);
        logger.info("SMALL FLAG "+smallFlag);
		inParams.put("smallFlag",smallFlag);
       	outParams = compTxnSetFileCheckService.execute(inParams);
		SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response = "+ outParams.get(UIConstant.APPLICATION_RESPONSE));
		outParams.put(UIConstant.APPLICATION_RESPONSE, outParams.get(UIConstant.APPLICATION_RESPONSE));
        logger.info("setNewFileConfig -- ends");
        return new ModelAndView(viewName, "outParams", outParams);
    }
    
    public ModelAndView setNewFileTxnConfigConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("setNewFiletxnConfigConfirm -- begins");
        HttpSession session = request.getSession(false);
        String format = request.getParameter("format");
        String fieldDelimter = null;
        String viewName = "setNewFiletxnConfigConfirm";
        String compConfigType = null;
        int delimitVal = 0;
        if (format.equalsIgnoreCase("Delimited"))
        {
        	fieldDelimter = request.getParameter("fieldDelimter");
        	if(fieldDelimter.equalsIgnoreCase("#"))
        	{
        		compConfigType = "delimited_txn_#";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("|"))
        	{
        		compConfigType = "delimited_txn_|";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("^"))
        	{
        		compConfigType = "delimited_txn_^";
        	}
        	else if(fieldDelimter.equalsIgnoreCase("~"))
        	{
        		compConfigType = "delimited_txn_~";
        	}
         }
        else if(format.equalsIgnoreCase("Fixed"))
        {
        	compConfigType = "fixed_txn";
        }
		User user = (User) session.getAttribute(UIConstant.USER);
		String corporateId = user.getCorporateId();
 	    Map inParams = new HashMap();
 	    Map outParams=new HashMap();
 	    inParams.put("format",format);
 	    inParams.put("fieldDelimter",fieldDelimter);
 	    inParams.put("compConfigType",compConfigType);
 	    inParams.put("corporateId",corporateId);
 	    outParams = compTxnSetFileService.execute(inParams);
 	    
 	  	SBIApplicationResponse errorResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
		logger.info("Application response = "+ outParams.get(UIConstant.APPLICATION_RESPONSE));
		outParams.put(UIConstant.APPLICATION_RESPONSE, outParams.get(UIConstant.APPLICATION_RESPONSE));
	    logger.info("setNewFileConfigConfirm -- ends");
        return new ModelAndView(viewName, "outParams", outParams);
    }
    	
    public void setCompTxnFileConfigService(BaseService compTxnFileConfigService) {
		this.compTxnFileConfigService = compTxnFileConfigService;
	} 
    
    public void setCompTxnSetFileService(BaseService compTxnSetFileService) {
		this.compTxnSetFileService = compTxnSetFileService;
	}

	public void setCompTxnSetFileCheckService(BaseService compTxnSetFileCheckService) {
		this.compTxnSetFileCheckService = compTxnSetFileCheckService;
	}
	 
}
