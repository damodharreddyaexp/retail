
/*
 * ModifyCorpUserHandler.java
 * Created on Mar 14, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 14, 2006 nh32963 � Initial Creation

package com.sbi.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;

public class ModifyCorpRolesHandler extends MultiActionController
{ 
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BaseService viewCorpRolesService;
    private BaseService modifyCorpRolesService;
    private Map modifyRolesMap;
    
    public ModelAndView viewCorpRoles(HttpServletRequest request, HttpServletResponse response) {
        logger.info("viewCorpRoles(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inParams = new HashMap();
        SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
        applicationResponse.setErrorStatus("SUCCESS");
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        String roleType=(String)modifyRolesMap.get(request.getServletPath());
        inParams.put("functionType","displayUsers");
        inParams.put("roleType",roleType);
        inParams.put("causer",user.getUserAlias());
        inParams.put("corpId",user.getCorporateId());
        String nextAction="/modifycorprolesdetails.htm?roleType="+roleType;
        outParams = viewCorpRolesService.execute(inParams);
        outParams.put("roleType", roleType);
        outParams.put("nextAction", nextAction);
        outParams.put("actionType", "Modify");
        logger.info("Message input:"+inParams);
        logger.info("viewCorpUser(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);        
        return new ModelAndView("viewCorpRoles",UIConstant.MODEL,outParams);
    }
    
    public ModelAndView modifyCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) {
        logger.info("modifyCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inputParams = new HashMap();
        String userid = (String) request.getAttribute("approverId");
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(UIConstant.USER);
        inputParams.put("causer",user.getUserAlias());
        inputParams.put("userid",userid);
        inputParams.put("roleType",request.getParameter("roleType"));
        inputParams.put("corporateId",user.getCorporateId()); //shanta
        outParams = viewCorpRolesService.execute(inputParams);
        SBIApplicationResponse applicationResponse= new SBIApplicationResponse();
        applicationResponse = (SBIApplicationResponse) outParams.get(UIConstant.APPLICATION_RESPONSE);
        outParams.put("userName",userid);
        logger.info("modifyCorpRolesDetails(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);
        return new ModelAndView("modifyCorpRolesDetails",UIConstant.MODEL,outParams);
    }
    
    public ModelAndView modifyCorpRolesConfirm(HttpServletRequest request, HttpServletResponse response) {
        
        logger.info("modifyCorpRolesConfirm(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        Map inputParams = new HashMap();
        RegMobileNoDetails regMobileNoDetails =null;
        HttpSession session = request.getSession(false);
        UserProfile user = (UserProfile) session.getAttribute(UIConstant.USER);
        UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
        logger.info("User Name to Change"+request.getParameter("userid"));
        logger.info("request.getAttribute approverId)"+request.getAttribute("approverId"));
        String roleType=request.getParameter("roleType");
        inputParams.put("userId",request.getParameter("userid"));
        inputParams.put("name",request.getParameter("name"));
        inputParams.put("address",request.getParameter("address1"));
        inputParams.put("address2",request.getParameter("address2"));
        inputParams.put("city",request.getParameter("city"));
        inputParams.put("state",request.getParameter("state"));
        inputParams.put("pincode",request.getParameter("pincode"));
        inputParams.put("district",request.getParameter("district"));
        inputParams.put("country",request.getParameter("country"));
        inputParams.put("emailId",request.getParameter("emailId"));
        inputParams.put("phone",request.getParameter("phone"));
        inputParams.put("emp",request.getParameter("emp"));
        inputParams.put("designation",request.getParameter("designation"));
        inputParams.put("department",request.getParameter("department"));
        inputParams.put("corpId",user.getCorporateId());
        inputParams.put("branchCode",user.getBranchCode());
        inputParams.put("bankCode",user.getBankCode());
        inputParams.put("createdBy",user.getCreatedBy());
        inputParams.put("userName",(String) request.getParameter("userName"));
      /*MobileNo updation - Start*/  
        //Integer userRole = (Integer) profile.getRoles().get(0);
        String updateMobileNo = request.getParameter("updatemobileno");
        String newmobileno = request.getParameter("newmobileno");
        String countryCode = request.getParameter("countryCode1");
       // String oldcountryCode = profile.getCountryCode();
        String oldcountryCode=request.getParameter("oldcountrycode");
        Integer regUserID =Integer.valueOf(request.getParameter("userid"));
        logger.info("oldCountryCode from hidden...."+oldcountryCode );
        logger.info("oldCountryCode from profile...."+profile.getCountryCode()+":" );
        logger.info("newCountryCode from profile...."+profile.getNewCountryCode()+":" );
        logger.info("oldcountryCode"+oldcountryCode+"countrycode;;;;;"+countryCode+"oldCCode"+oldcountryCode); 
       // logger.info("userRole>>>"+userRole);
        logger.info("userid>>>"+request.getParameter("userid"));
        inputParams.put("updateMobileNo",updateMobileNo);
        inputParams.put("newmobileno",newmobileno);
        String oldMobileno = request.getParameter("mobileno");
        inputParams.put("oldMobileno",oldMobileno);
        inputParams.put("countryCode",countryCode);
        inputParams.put("oldcountryCode",oldcountryCode);
       // inputParams.put("userRole",userRole);
        inputParams.put("userAlias",profile.getUserAlias());
        inputParams.put("friendlyName",profile.getFriendlyName());
        inputParams.put("regUserID",regUserID);
        inputParams.put("roleType",roleType);
        logger.info("userName : " + request.getParameter("userName"));
        logger.info("NAME:::::: : " + request.getParameter("name"));
        logger.info("userType"+request.getParameterValues("userType"));
        logger.info("accRights"+request.getParameter("accRights"));
        logger.info("inputParams"+inputParams);
        logger.info("FriendlyName  :"+profile.getFriendlyName());
        logger.info("FriendlyName  :"+profile.getFriendlyName());
        logger.info("Name  :"+request.getParameter("name"));
        logger.info("Name  :"+request.getParameter("name"));
        logger.info("Name  :"+request.getParameter("name"));
        inputParams.put("name",request.getParameter("name"));
        /*MobileNo updation - End*/
        logger.info("inputParams"+inputParams);
        outParams = modifyCorpRolesService.execute(inputParams);
        
        logger.info("updateMobileNoDetails::*****:::"+outParams.get("updateMobileNoDetails"));
        regMobileNoDetails = (RegMobileNoDetails) outParams.get("updateMobileNoDetails");
        
        if(regMobileNoDetails != null){
            // logger.info("updateMobileNoDetails :::in side if ###::"+updateMobileNoDetails);
             session.setAttribute("referenceNo", regMobileNoDetails.getReferenceNo());
     		session.setAttribute("newMobileNo", updateMobileNo);
     		session.setAttribute("contryCode", countryCode);
     		session.setAttribute("empNo", request.getParameter("emp"));
     		session.setAttribute("frdName", request.getParameter("name"));
     		session.setAttribute("createdUserRole", regMobileNoDetails.getUserRole());
     		logger.info("createdUserRole>>>"+session.getAttribute("createdUserRole"));
     		
         }
        
        
        outParams.put("displayName",request.getParameter("name"));
        String returnAction="modify"+roleType.toLowerCase()+".htm";
        outParams.put("returnAction",returnAction);
        logger.info("modifyCorpRolesConfirm(HttpServletRequest request, HttpServletResponse response) "+LoggingConstants.METHODEND);
        return new ModelAndView("modifyCorpRolesConfirm",UIConstant.MODEL,outParams);
    }

    
    public ModelAndView showregisterMobileNoC9Form(HttpServletRequest request,HttpServletResponse response) {
		logger.info("showregisterMobileNoC9Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODBEGIN);
	
		 RegMobileNoDetails regMobileNoDetails = null ;
		 HttpSession session = request.getSession(false);
	     UserProfile profile = (UserProfile) session.getAttribute(UIConstant.USER);
	     CorporateProfile corporateProfile = (CorporateProfile) session.getAttribute("corp_profile");
	     String mobileNo =(String) session.getAttribute("newMobileNo");
	     String countryCode =(String) session.getAttribute("contryCode");
	     
	     String corporateId = profile.getCorporateId();
	     String corporateName = corporateProfile.getCorporateName();
	     String reffNo =(String) session.getAttribute("referenceNo");
	     String friendlyName = (String) session.getAttribute("frdName");
	     String empNo = (String) session.getAttribute("empNo");
	     String createdUserRole = (String )session.getAttribute("createdUserRole");
		  
		Map outParams = new HashMap();
		SBIApplicationResponse applicationResponse = new SBIApplicationResponse();
		outParams.put(UIConstant.APPLICATION_RESPONSE, applicationResponse);	
		outParams.put("mobileNo",countryCode+"|"+mobileNo);
		outParams.put("referenceNo",reffNo);
		outParams.put("corporateId",corporateId);
		outParams.put("corporateName",corporateName);
		outParams.put("friendlyName",friendlyName);
		outParams.put("empNo",empNo);
		outParams.put("createdUserRole",createdUserRole);
	
	
		applicationResponse.setErrorStatus(ServiceErrorConstants.SUCCESS);

		logger.info("showregisterMobileNoC9Form(HttpServletRequest request, HttpServletResponse response)"
						+ LoggingConstants.METHODEND);
		return new ModelAndView("showRegisterMobileNoForm", "outParams",outParams);

	}

	public void setViewCorpRolesService(BaseService viewCorpRolesService) {
		this.viewCorpRolesService = viewCorpRolesService;
	}


	public void setModifyCorpRolesService(BaseService modifyCorpRolesService) {
		this.modifyCorpRolesService = modifyCorpRolesService;
	}


	public void setModifyRolesMap(Map modifyRolesMap) {
		this.modifyRolesMap = modifyRolesMap;
	} 
   
}
