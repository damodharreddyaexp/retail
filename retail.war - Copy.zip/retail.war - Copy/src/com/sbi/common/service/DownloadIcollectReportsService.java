package com.sbi.common.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.dao.IcollectDao;

public class DownloadIcollectReportsService extends BaseService {
	protected static Logger logger = Logger.getLogger(DownloadIcollectReportsService.class);
	private IcollectDao icollectDaoImpl;
	public Map execute(Map inParams) {
		Map outParams = new HashMap();
		StringBuffer filecontent = new StringBuffer();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			int reportList = 0;
			String categoryID = (String) inParams.get("categoryID");
			String startDate = (String) inParams.get("startDate");
			String endDate = (String) inParams.get("endDate");
			String fileType = (String) inParams.get("fileType");
			String userName = (String) inParams.get("userName");
			String paymentmode =(String) inParams.get("paymentmode");
			String corporateId =(String) inParams.get("corporateId"); // All Category report
			String accountNo	=(String) inParams.get("accountNo");
			String requestType	= (String) inParams.get("reportType");
			
			Date d = new Date();
			Random randomGenerator = new Random();
			String dateString = new String();
			String requestId=String.valueOf(d.getTime()+randomGenerator.nextInt(9999));
			if( categoryID != null &&  startDate!=null && endDate!=null && fileType!= null){
								
				reportList = icollectDaoImpl.insertReportDetails(requestId,categoryID, startDate, endDate,userName,fileType,paymentmode,corporateId,accountNo,requestType);
				outParams.put("requestId", requestId);
				logger.info("reportList"+reportList);
				logger.info("requestId"+requestId+"categoryID"+categoryID+"startDate"+startDate+"endDate"+endDate+"userName"+userName+"fileType"+fileType+"paymentmode"+paymentmode);
				if(reportList>0){
					response.setErrorStatus(ServiceConstant.SUCCESS);
				}else{
					response.setErrorCode(" LA003");
				}
				
			}else{
				response.setErrorCode("SUV022");
				logger.error("Null parameters received to service: "+categoryID+","+startDate+","+endDate+","+fileType);
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParams;
	}
	
	/*private static StringBuffer generateExcelFileBuffer(List reportList,String startDate,String endDate){
		StringBuffer writer = new StringBuffer();
		writer.append("Start Date:\t");
		writer.append(startDate);
		writer.append("\r\n");
		writer.append("End Date:\t");
		writer.append(endDate);
		writer.append("\r\n");
		writer.append("\r\n");
		Map<String, List<String>> categoryParams = new HashMap<String, List<String>>();
			for (int i = 0; i < reportList.size(); i++) {
				StringBuffer parseString = new StringBuffer();
				Map paymentDetails = (Map) reportList.get(i);
				StringBuffer heading = new StringBuffer();
				parseString.append(paymentDetails.get("ECHEQUE_NO"));
				parseString.append("\t");
				parseString.append(StringUtils.String2Date(paymentDetails.get("ECHEQUE_DATE").toString()));
				parseString.append("\t");
				parseString.append(paymentDetails.get("ECHEQUE_AMOUNT"));
				parseString.append("\tCompleted Successfully\t");
				String valueString = paymentDetails.get("OUTREF9").toString() + paymentDetails.get("OUTREF10").toString();
				String[] fields = valueString.split("~");
				for (int j=1;j<fields.length;j++){
					if(j%2==0){
						//logger.info("value::"+j+"..."+fields[j]);
						parseString.append(fields[j]+"\t");
					}else{
						//logger.info("value::"+j+"..."+fields[j]);
						heading.append(fields[j]+"~");
					}
				}
				String headingString = heading.toString();
				
				List<String> transactionList = categoryParams.get(headingString);
                if (transactionList == null){
                	transactionList=new ArrayList<String>();
                	transactionList.add(parseString.toString());
                }else
                	transactionList.add(parseString.toString());
                categoryParams.put(headingString, transactionList);
			}
			// For keys of a map
			for (Iterator it=categoryParams.keySet().iterator(); it.hasNext(); ) {
			    Object key = it.next();
			    List PaymentList = categoryParams.get(key);
			    writer.append("Bank Reference No\tTransaction Date\tAmount\tStatus\t");
				writer.append(key.toString().replaceAll("~", "\t"));
				writer.append("\r\n");
			    Iterator list = PaymentList.iterator();
			    while (list.hasNext()) {
					writer.append(list.next().toString());
					writer.append("\r\n");	
			    }
			    writer.append("\r\n\r\n\r\n");
			}
			return writer;
	}
	
	
	private static StringBuffer generateCsvFileBuffer(List reportList,String startDate,String endDate)
	{
			StringBuffer writer = new StringBuffer();
			writer.append("Start Date: ");
			writer.append(startDate);
			writer.append("\r\n");
			writer.append("End Date: ");
			writer.append(endDate);
			writer.append("\r\n");
			writer.append("\r\n");
		   	for (int i = 0; i < reportList.size(); i++) {
				Map paymentDetails = (Map) reportList.get(i);
				writer.append(paymentDetails.get("ECHEQUE_NO"));
				writer.append("~");
				writer.append(StringUtils.String2Date(paymentDetails.get("ECHEQUE_DATE").toString()));
				writer.append("~");
				writer.append(paymentDetails.get("ECHEQUE_AMOUNT"));
				writer.append("~");
				writer.append("Completed Successfully");
				writer.append(paymentDetails.get("OUTREF9"));
				writer.append(paymentDetails.get("OUTREF10"));
				writer.append("\r\n");
			}
			
		return writer;
	}*/
	
	public void setIcollectDaoImpl(IcollectDao icollectDaoImpl) {
		this.icollectDaoImpl = icollectDaoImpl;
	}
}
