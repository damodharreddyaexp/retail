/*
 * ForgetProfilePWDService.java
 * Created on Dec 24, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 24, 2005 MURUGAN K - Initial Creation
//Feb 01, 2006  RAMAKRISHNAREDDY - Logger changes
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ProfileDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class ForgetProfilePWDService extends BaseService {
	protected final Logger logger = Logger.getLogger(getClass());

	private ProfileDAO profileDAOImpl;

	public Map execute(Map inputParams) {

		logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled())
		logger.debug("inputparams Map:" + inputParams);
		Map outParams = new HashMap();
		String responseString = null;
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
		String branchCode = (String) inputParams
				.get(ServiceConstant.BRANCH_CODE);

		try {

			if (userName != null && branchCode != null) {

				responseString = profileDAOImpl.insertPasswordCount(userName,
						branchCode);
				//logger.info("Reference No : "  + responseString);
				if (responseString != null) {
					response.setErrorStatus(ServiceConstant.SUCCESS);
					if (logger.isDebugEnabled())
					logger.debug("Reference No : " + responseString);
					outParams.put(ServiceConstant.REFERENCE_NO, responseString);

				} else {
					response.setErrorCode(ServiceErrorConstants.SE002);
				}
			}

		} catch (Exception exp) {
			logger.error("Exception occured :" + exp);
			response.setErrorStatus(ServiceConstant.FAILURE);
			response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
			response.setErrorCode(ServiceErrorConstants.SE002);
			exp.printStackTrace();
		}

		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		if (logger.isDebugEnabled())
		logger.debug("outParams Map contains: " + outParams);
		logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
		return outParams;

	}

	public void setProfileDAOImpl(ProfileDAO profileDAOImpl) {
		this.profileDAOImpl = profileDAOImpl;
	}

}
