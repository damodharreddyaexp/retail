/*
 * ServiceConstant.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History  
//Oct 18, 2005 MURUGAN K - Initial Creation
package com.sbi.common.service;
 
import java.util.Map;
import com.sbi.common.exception.SBIApplicationException;

/**
 * TODO This is Abtract class , its implemeted by
 * AccountStatementDisplayService.java,CreditToPPFAccountDisplayService.java,
 * FundsTransferDisplayService.java
 * ,LogonService.java,PPFDisplayService.java,ServiceConstant.java,
 * ThirdPartyTransferDisplayService.java
 * BaseService.java,DemandDraftDisplayService.java,FundsTransferService.java,MyAccountsService.java
 * QuickLookService.java,ThirdPartyDisplayService.java,ViewAccountStatementService.java
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public abstract class BaseService {
    String execute(String xmlString) {
        return null;
    }

    /**
     * TODO This is base method to call the specified methods and process it
     * return the Map which is contains account or Transaction Information
     * 
     * @param inputParams
     * @return
     * @throws SBIApplicationException
     *             Map
     */
    public Map execute(Map inputParams){
        return null;
    }

}
