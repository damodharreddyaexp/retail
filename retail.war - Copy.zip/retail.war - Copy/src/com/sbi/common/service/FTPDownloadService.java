/*
 * FTPDownloadService.java
 * Created on 2012
 *
 * Copyright (c) 2012 by SBI All Rights Reserved.
 * $Header: $
 */

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.FtpDownloadUtils;
import com.sbi.common.utils.JserviceClient;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
 
public class FTPDownloadService  extends BaseService{
    
	private JserviceClient jserviceClient;
	private FtpDownloadUtils ftpDownloadUtils;

	protected final Logger logger = Logger.getLogger(getClass());
	public Map execute(Map inputParams) {
        
   	 logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
 	String requestString=(String)inputParams.get("requestString");
 	String referenceNo=(String)inputParams.get("referenceNo");
 	String pageCount=(String)inputParams.get("pageCount");
	String instanceName=(String)inputParams.get("instanceName");
 	     Map map = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
       
        boolean flag = false;
        try 
        {
            if (requestString != null && referenceNo !=null)
            {	
            	String fileName=StringUtils.uniqueNumberUsingDateAndRandom(referenceNo);
             	requestString+="|fileName="+fileName+"|messageId="+fileName+"|pageCount="+pageCount;
             	HttpServletResponse httpResponse=null;
               String statusCode=jserviceClient.sendRequestToJservices(requestString,instanceName, fileName,httpResponse);
             /*  if(statusCode!=null&&"00".equalsIgnoreCase(statusCode)){
            	   boolean downloadStatus=ftpDownloadUtils.download(fileName+".zip");
            	   logger.info("downloadStatus.."+downloadStatus);
            	   if(downloadStatus){
            		   map.put("fileName", fileName);
            		   response.setErrorStatus( ServiceErrorConstants.SUCCESS );
            	   }
            	   else{
            		   SBIApplicationException.throwException("SE111");
            	   }
               }*/
               if(statusCode!=null){
            	   map.put("fileName", fileName);
            	   response.setErrorStatus( ServiceErrorConstants.SUCCESS );
               }else{
            	   logger.info("Failure:::::::");
            	   SBIApplicationException.throwException("SE111");
               }
            }
        }
        catch (SBIApplicationException sbiExc) {
            response.setErrorCode(sbiExc.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION,sbiExc);
        }
        
        catch (DAOException daoExp) {
            response.setErrorCode(daoExp.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION,daoExp);
        }
        catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
       }
       
        if (logger.isDebugEnabled())
        {
        logger.debug("response" + response.getErrorCode());
        logger.debug("response" + response.getErrorStatus());
        }
        map.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return map;

    }
   

   	public void setJserviceClient(JserviceClient jserviceClient) {
		this.jserviceClient = jserviceClient;
	}



	public void setFtpDownloadUtils(FtpDownloadUtils ftpDownloadUtils) {
		this.ftpDownloadUtils = ftpDownloadUtils;
	}
   
     
}
