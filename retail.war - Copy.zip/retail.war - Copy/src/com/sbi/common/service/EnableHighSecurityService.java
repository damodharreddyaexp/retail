/*
 * EnableHighSecurityService.java
 * Created on Jan 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 18, 2006 MANIKANDAN - Initial Creation
//April 30,2011 PONNUSAMY - File is revamped to send the SMS thru SMS gateway.
package com.sbi.common.service; 

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;

import com.sbi.common.dao.SMSAlertDAO;

import com.sbi.common.bp.SMSGatewayBP;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.SendSMS;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.UtilsConstant;


public class EnableHighSecurityService extends BaseService{
	
	private ResourceBundleMessageSource transactionProperties;
	private SMSAlertDAO smsAlertDAOImpl;
	
	private SMSGatewayBP smsGatewayBP;
	private SBIApplicationResponse response=new SBIApplicationResponse();
	
	protected final Logger logger=Logger.getLogger(getClass());
	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
		response.setErrorStatus(ServiceConstant.FAILURE);
		Map outParam=new HashMap();
		Map<String,String> SMSRequest =new HashMap<String,String>();
		try{
			String password=StringUtils.randomNumber().toString();
			String transferType=(String)inputParams.get("transferType");
			String merchantName=(String)inputParams.get("merchantName");
			String smsModuleType=(String)inputParams.get("smsModuleType");
			String moduleName=(String)inputParams.get("moduleName");
			String countryCode=(String)inputParams.get("countryCode");
			String mobileNo=(String)inputParams.get("mobileNo");
			Integer userId=(Integer)inputParams.get("userId");
			String emailId=(String)inputParams.get("emailId");
			//String otpOption=inputParams.get("otpOption").toString().trim(); //Added for Voice OTP
			String otpOption=(String)inputParams.get("otpOption");
			if( otpOption != null )
				otpOption = otpOption.trim();
			
			String message=null; 
			String messageTypeId = null;
			List<String> param=new LinkedList<String>();
			String userName=(String)inputParams.get("userName");
            String userRole=(String)inputParams.get("userRole");
            String bankCode=(String)inputParams.get("bankCode");
          //Added for resend SMS
            String resendsms=(String) inputParams.get("resendsms");
            String sessionPassword=(String) inputParams.get("sessionPassword");
            int count=0;
            logger.info("transferType :"+transferType);
            logger.info("merchantName :"+merchantName);
            logger.info("smsModuleType :"+smsModuleType);
            logger.info("moduleName :"+moduleName);
            logger.info("userName :"+userName);
            logger.info("userRole :"+userRole);
            logger.info("emailId :"+emailId);
           if(userId!= null && mobileNo==null || mobileNo.equalsIgnoreCase("")){

        	   
        	    count = smsAlertDAOImpl.findRegisteredMobile(userId); // abaaba
               if (count > 0) {
                   response.setErrorStatus(ServiceErrorConstants.FAILURE);
                   response.setErrorCode(ServiceErrorConstants.RM009);
                        logger.info("mobileNo =" + mobileNo);

               }
               else {
            	   response.setErrorStatus(ServiceErrorConstants.FAILURE);
                   response.setErrorCode(ServiceErrorConstants.RM008);

               }

              
           }else{
            if(transferType!=null && transferType.trim().length()>0 && mobileNo != null && mobileNo.trim().length() > 0){
            	messageTypeId=getMessageTypeId(transferType);
            	 SMSRequest.put("userName", userName);
                 SMSRequest.put("moduleName", moduleName);
                 SMSRequest.put("countryCode", countryCode);
                 SMSRequest.put("mobileNo", mobileNo);
                 SMSRequest.put("otpOption", otpOption);  //Added for Voice OTP
                 SMSRequest.put("bankCode", bankCode);
                 SMSRequest.put("smsModuleType", smsModuleType);
                 SMSRequest.put("emailId", emailId);
                 if(messageTypeId != null && messageTypeId.trim().length() > 0){
                 SMSRequest.put("messageTypeId", messageTypeId);
                 }else{
                	 logger.info("Configuration missing in Properties file.");
                	 response.setErrorCode(ServiceErrorConstants.SE002);
                 }
                 logger.info("resendsms : " + resendsms);
                 if(resendsms!=null && resendsms.equals("true")){                	 
                	 SMSRequest.put("sendOrder", "1");
                	 password=sessionPassword;
                	 param.add(password);
                 } else {
                	 SMSRequest.put("sendOrder", "0");
                	 if (transferType.trim().equalsIgnoreCase("PF") || transferType.trim().equalsIgnoreCase("BU")){
     					password=(String)inputParams.get("password");
     					param.add(password);
     				}
                	 /*else if(transferType.trim().equalsIgnoreCase("BU")){
     					String resendPassword=(String)inputParams.get("password");
     					param.add(resendPassword);
     				}*/else
                	 param.add(password);
                 }
                 logger.info("sendOrder : " + SMSRequest.get("sendOrder")); //Added for resend SMS
                 //logger.info("Password : " + password); //Added for resend SMS
                 
                // SMSRequest.put("readResponse", "YES");
				if (transferType.trim().equalsIgnoreCase("MP"))
                    param.add(merchantName);
				if (transferType.trim().equalsIgnoreCase(UtilsConstant.RTGS)
               		 || transferType.trim().equalsIgnoreCase(UtilsConstant.NEFT)
               		 || transferType.trim().equalsIgnoreCase(UtilsConstant.GRPT)){
               	param.add(transferType);
				}
				
				String sgateResponse=smsGatewayBP.processSMSRequest(SMSRequest,param);
				logger.info("sgateResponse::::::"+sgateResponse);
				//if(sgateResponse!=null && sgateResponse.equals("00")){
					outParam.put("password",password);
					response.setErrorStatus(ServiceConstant.SUCCESS);
				/*}
				else
					response.setErrorCode(ServiceErrorConstants.SE002);*/
				
			}
			else
				response.setErrorCode(ServiceErrorConstants.SE003);
		}
           }
		catch(SBIApplicationException exception){
			
			response.setErrorCode(exception.getErrorCode());
		}
		catch(Exception exception){
			logger.info("Exception Occured : " + exception.getMessage());
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParam.put(ServiceConstant.APPLICATION_RESPONSE,response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParam; 
	}
	
	private String getMessageTypeId(String type) {
        String messageTypeId = DAOConstants.TXN_STATUS_UNKNOWN;
        try {
        	messageTypeId = transactionProperties.getMessage("smsMessageType."+type, null, null);
                   }
        catch (NoSuchMessageException ex) {
           //logger.error("Exception occured" ,ex );
        }

        return messageTypeId;
    }
	
	
    public void setTransactionProperties(ResourceBundleMessageSource transactionProperties) {
        this.transactionProperties = transactionProperties;
    }

	public void setSmsGatewayBP(SMSGatewayBP smsGatewayBP) {
		this.smsGatewayBP = smsGatewayBP;
	}

	public void setSmsAlertDAOImpl(SMSAlertDAO smsAlertDAOImpl) {
		this.smsAlertDAOImpl = smsAlertDAOImpl;
	}
} 
