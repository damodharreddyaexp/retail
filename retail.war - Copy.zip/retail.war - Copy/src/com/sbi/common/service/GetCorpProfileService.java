/*
 * GetCorpProfileService.java
 * Created on Sep 18, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Sep 18, 2006 JD37715 - Initial Creation
//Nov 23, 2009 LP49927 - Modified for corpDynamic Links
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.CorporateProfileDAO;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.UserProfile;

public class GetCorpProfileService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private CorporateProfileDAO corpProfDaoImpl;

	private UserDAO userDAOImpl;

	private static final String CORP_PROFILE = "corp_profile";

	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map:" + inputParams);
		Map outParams = new HashMap();
		CorporateProfile corporateProfile = null;

		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		UserProfile userProfile = (UserProfile) inputParams.get(ServiceConstant.USER);
		try {
			if (userProfile != null) {
				corporateProfile = corpProfDaoImpl.findCorporateProfileDetails(userProfile.getCorporateId());
				outParams.put(CORP_PROFILE, corporateProfile);
				response.setErrorStatus(ServiceConstant.SUCCESS);
			} else {
				response.setErrorCode(ServiceErrorConstants.SE002);
			}
		} catch (Exception exp) {
			logger.error("Exception occured :" + exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
			exp.printStackTrace();
		}

		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		if (logger.isDebugEnabled()) {

			logger.debug("outParams Map contains: " + outParams);
		}
		logger.info("execute(Map inputParams) method end"
				+ LoggingConstants.METHODEND + " " + outParams);
		return outParams;

	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	public void setCorpProfDaoImpl(CorporateProfileDAO corpProfDaoImpl) {
		this.corpProfDaoImpl = corpProfDaoImpl;
	}
}
