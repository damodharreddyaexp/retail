package com.sbi.common.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.DematDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class DmatunmarkCorpDetailsService extends BaseService{

    private DematDAO dematDAOImpl;

    private final Logger logger=Logger.getLogger(getClass());
    
    private SBIApplicationResponse response=new SBIApplicationResponse();
    
   public Map execute(Map inputParams){
    	
        logger.info("execute DmatunmarkCorpDetailsService " +LoggingConstants.METHODBEGIN);
        Map outParams=new HashMap();
        Map resultParams=new HashMap();
        List userReleaseDetails=new ArrayList();
        int count=0;
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName=(String)inputParams.get("userName");
        String eBrokingId=(String)inputParams.get("eBrokingId");
        String releaseAmt1=(String)inputParams.get("releaseAmt");       
        String referenceNo=(String)inputParams.get("referenceNo");
        String hiddenAmount=(String)inputParams.get("amount");
        String requestType=(String)inputParams.get("requestType");
        String startDate =(String)inputParams.get("startDate");
		String endDate = (String)inputParams.get("endDate");
		String lienAmt = (String)inputParams.get("lienAmt");
		logger.info("lienAmt in service"+lienAmt);
		String lienRefNo =null;
        logger.info("requestType1111 " +requestType+"eBrokingId2222"+eBrokingId);
        logger.info("startDate"+startDate);
        logger.info("endDate"+endDate);
        logger.info("hiddenAmount2222"+hiddenAmount);
        try {
        	
        	 String  corpId=dematDAOImpl.getCorpId(eBrokingId);
    		 logger.info("corpId in dmat unmark detail service"+corpId);
        	logger.info("userName"+userName+"eBrokingId"+eBrokingId+"releaseAmt"+releaseAmt1+"referenceNo"+referenceNo+"amount"+hiddenAmount);
           if(requestType!=null && requestType.equalsIgnoreCase("NOW_STATUS_RELEASE")){
                    if(eBrokingId!=null && startDate!=null && endDate !=null )
        			userReleaseDetails=dematDAOImpl.getStatusDetails(eBrokingId,startDate,endDate);
        			if(userReleaseDetails != null && userReleaseDetails.size() >0){
					logger.info("userReleaseDetails size"+userReleaseDetails.size());
					outParams.put("userReleaseDetails",userReleaseDetails);
	                response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				}else{	
					 response.setErrorStatus(ServiceErrorConstants.FAILURE);
					response.setErrorCode("NOW001");
				}

        		}
        	
        	else if(userName!=null && eBrokingId!=null && releaseAmt1!="" && releaseAmt1!=null  && hiddenAmount!="" && hiddenAmount!=null && lienAmt!=null && lienAmt!="" && corpId!=null && corpId!="" ){
        		logger.info("inside double condition");
        		
        		 double releaseAmt=Double.parseDouble(releaseAmt1);
        		 logger.info("releaseAmt222222222"+releaseAmt);
        		 double amount=Double.parseDouble(hiddenAmount);
        		 double lienAmount=Double.parseDouble(lienAmt);
        		 logger.info("lienAmount"+releaseAmt);
        		 double validateAmt=releaseAmt+amount;
        		 logger.info("validateAmt"+validateAmt);
        		 if(validateAmt>lienAmount){
        			 logger.info("inside errror view");
        		 response.setErrorStatus(ServiceErrorConstants.FAILURE); 
        		 response.setErrorCode("LUN001");
        		 }
        		 
        		
        		 else{
        			 lienRefNo=dematDAOImpl.insertCorpLienReleaseAmount(userName,eBrokingId,releaseAmt,referenceNo,amount,corpId);        	
        		 }
        		 logger.info("amount222222222"+amount);
        		 logger.info("lienAmount in service"+lienAmount);
        		
        		 
        		if(lienRefNo!= null){
					logger.info("referenceNo "+lienRefNo);	
					outParams.put("lienRefNo",lienRefNo);
	                response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				}
        					
        	}
        	else{
        		response.setErrorCode(ServiceErrorConstants.FAILURE);
        		response.setErrorCode(ServiceErrorConstants.SE002);
        	}
        	
 } catch(SBIApplicationException aex){
        	response.setErrorCode(aex.getErrorCode());
        }
 catch (Exception exception) {
        	logger.error("Exception :",exception);
        	response.setErrorCode(ServiceErrorConstants.SE002);
          
        }
 		outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);
       logger.info("execute DmatunmarkCorpDetailsService " +LoggingConstants.METHODEND);
        return outParams;
        
    }
	public void setDematDAOImpl(DematDAO dematDAOImpl) {
		this.dematDAOImpl = dematDAOImpl;
	}
}



