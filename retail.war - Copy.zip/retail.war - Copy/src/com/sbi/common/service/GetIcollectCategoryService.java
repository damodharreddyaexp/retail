package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.dao.IcollectDao;



public class GetIcollectCategoryService extends BaseService {
	protected static Logger logger = Logger.getLogger(GetIcollectCategoryService.class);
	
	private IcollectDao icollectDaoImpl;
	
	public Map execute(Map inParams) {
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		logger.info("GetIcollectCategoryService execute method is called");
		try{
			String corporateID = (String)inParams.get("coporateID");
			String userName	=	(String)inParams.get("userName");
			
			List categoryList = null;
			List accountDetails = null;
			
			if( corporateID != null &&  !"".equalsIgnoreCase(corporateID.trim())){
				categoryList = icollectDaoImpl.findIcollectCategories(corporateID);
				accountDetails = icollectDaoImpl.fetchAccountDetails(corporateID,userName);
				
				if(categoryList!=null){
					outParams.put("categoryList",categoryList);
					outParams.put("accountDetails",accountDetails);
					response.setErrorStatus(ServiceConstant.SUCCESS);
				}
			}else{
				response.setErrorCode("SUV001");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParams;
	}
	
	public void setIcollectDaoImpl(IcollectDao icollectDaoImpl) {
		this.icollectDaoImpl = icollectDaoImpl;
	}
}
