/*
 * AddThirdPartyHandler.java
 * Created on Mar 17, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 17, 2006 Asit- Initial Creation

package com.sbi.common.service;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ThirdPartyDAO;
import com.sbi.common.model.ApproveDelTPModel;
import com.sbi.common.model.ApproveDelTPModelStatus;

public class ApproveDelTPConfirmService extends BaseService{
    
    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO thirdPartyDAOImpl;

    
     /**
     * call the [thirdPartyDAOImpl.updateDelTPState(approveIds, un_ApproveIds, userName)]  to update the 
     * Approve and unApprove Details in Database return Map which is contains 
     * Updated Aproved and Unapproved Information.
     * 
     * @param inputParams
     * @return Map
     * 
     */
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();

        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        Map outParams = new HashMap();
        String apprIds;
        String unApprIds;
        String[] approveIds_arr = { "-1" };
        String[] un_ApproveIds_arr = { "-1" };
        boolean status;
        String[] approveIds = { "-1" };
        String[] un_ApproveIds = { "-1" };
        Integer[] approve;
        String fileName = "";
        ApproveDelTPModelStatus[] approveDelTPModelStatus = null;
        Object obapprId = inputParam.get(ServiceConstant.APPROVE_IDS);
        
        fileName = (String) inputParam.get(ServiceConstant.TP_FILE_NAME);
        String userName = (String) inputParam.get(ServiceConstant.USER_NAME);
        logger.info("userName :" + userName);
        logger.info("tpName :" + fileName);
        try {
            if (userName != null && !userName.equals(ServiceConstant.EMPTY)) {
                if (obapprId != null) {
                    apprIds = (String) obapprId;
                    logger.info("apprIds :" + apprIds);
                    if (apprIds != null && apprIds.length() > 0) {
                        if (apprIds.indexOf(",") > 0)
                            approveIds_arr = apprIds.split(",");
                        else
                            approveIds_arr[0] = apprIds;

                        approveIds = new String[approveIds_arr.length];
                
                        for (int i = 0; i < approveIds_arr.length; i++) {
                            approveIds[i] = approveIds_arr[i].trim();
                        
                        }
                    }
                }

                
                status = thirdPartyDAOImpl.updateDelTPState(approveIds,userName);

                if (status) {
                    if (fileName != null
                            && !fileName.trim().equals(ServiceConstant.EMPTY)) {
                        String[] pages = new String[3];
                        int i = 0;
                        int index = fileName.indexOf('.');
                        String name = fileName.substring(0, index);
                                        String appFileName = name+"%";

                        logger.info("appFileName :" + appFileName);
                        if (obapprId != null) {
                            apprIds = (String) obapprId;
                            logger.info("apprIds :" + apprIds);
                            if (apprIds != null && apprIds.length() > 0) {
                                if (apprIds.indexOf(",") > 0)
                                    approveIds_arr = apprIds.split(",");
                                else
                                    approveIds_arr[0] = apprIds;

                                approveIds = new String[approveIds_arr.length];
                        
                                for (int k = 0; k < approveIds_arr.length; k++) {
                                    approveIds[k] = approveIds_arr[k].trim();
                                
                                }
                            }
                        }
                
                      
                        approveDelTPModelStatus = thirdPartyDAOImpl.findDelTPsByStatus(userName,appFileName,approveIds);
                        if(approveDelTPModelStatus.length>=1)
                        {
                        logger.info("noOFRows="+inputParam.get("noOFRows"));
                        logger.info("particularPageNumber=="+inputParam.get("particularPageNumber"));
                        int limits=new Integer((String)inputParam.get("noOFRows")).intValue();
                        logger.info("limits=="+limits);
                        //ApproveDelTPModel[] approveDelTPModel1=new ApproveDelTPModel[limits];
                        ApproveDelTPModelStatus[] approveDelTPModel1;
                        if(limits<=approveDelTPModelStatus.length)
                        {
                            approveDelTPModel1=new ApproveDelTPModelStatus[limits];
                        }
                        else
                        {
                            approveDelTPModel1=new ApproveDelTPModelStatus[approveDelTPModelStatus.length];
                        }
                         //int limits = 2;
                            int pageNo = (new Integer((String) inputParam.get("particularPageNumber"))).intValue();
                            int k=0;
                            for (int j = (pageNo - 1) * limits; j < limits * pageNo && j < approveDelTPModelStatus.length; j++) {

                             //limitedList.add(corporateTP[j]);
                                approveDelTPModel1[k]=approveDelTPModelStatus[j];
                             k=k+1;

                            }
                         List checkedList=new ArrayList();
                         if (approveDelTPModel1!= null) {
                            outParam.put("approveTPFileConfirmDetails",approveDelTPModel1);
                             String ptp;
                               String utp;
                                for(i=0; i<approveDelTPModel1.length;i++){
                                 ApproveDelTPModelStatus atp = approveDelTPModelStatus[i];
                                  for(k=0;k<approveIds.length;k++)
                                    {
                                        ptp=approveIds[k];
                                        if((atp.getStatus().toString().equals("approved"))&& (atp.getRowID().toString().equalsIgnoreCase(ptp))){
                                        checkedList.add(atp);
                                                                                      
                                        }
                                    
                                    }          
                                }
                            outParam.put("checkedList",checkedList);
                                                    
                            response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                        } else {
                            response.setErrorCode(ServiceErrorConstants.CR001);
                        }
                        }


                    } else {
                        response.setErrorCode(ServiceErrorConstants.CR002);
                    }
                } else {
                    response.setErrorCode(ServiceErrorConstants.CR011);
  
                }
            } else {

                response.setErrorCode(ServiceErrorConstants.CR002);
            }

        } catch (SBIApplicationException appex) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION + exp);
        }
        
        outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);

        return outParam;
    }


    public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl)
    {
        this.thirdPartyDAOImpl = thirdPartyDAOImpl;
    }

     /**
     * TODO ThirdPartyDAOImpl  injection done here
     * @param thirdPartyDAOImpl void
     */
    
  
}



