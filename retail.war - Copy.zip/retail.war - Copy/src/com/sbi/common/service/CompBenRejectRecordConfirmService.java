package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CompBenDataModel;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompBenRejectRecordConfirmService extends BaseService {
	
	protected static Logger logger = Logger.getLogger(CompBenRejectRecordConfirmService.class);
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		logger.info("execute(Map inParams)" + LoggingConstants.METHODBEGIN);
		
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inParams.get("userName");
			String corporateId = (String)inParams.get("coporateId");
			String rejIds = (String)inParams.get("approveIds");
			String fileType = (String) inParams.get("fileType");
			String selectAllFlag = (String) inParams.get("selectAllFlag");
			String fileName = (String) inParams.get("fileName");
			String specificFileType = (String) inParams.get("specificFileType");
			
			String[] rejIdsSplit = null;
			List rejectOid = new ArrayList();
			CompBenDataModel[] compBenDataModel;
			int rejectStatus =0;
			if(userName != null  && corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim()) &&  fileType != null  && rejIds != null && rejIds.length() > 0  ){
				logger.info("Ids to Reject"+rejIds +"UserNAme"+userName);
				
				if("COMPOSITE_BEN".equalsIgnoreCase(fileType) || "ABTP".equalsIgnoreCase(fileType)) {
					
					if("Yes".equals(selectAllFlag)) {
						rejectStatus = compBenFileDAOImpl.updateCompBenStatusRejectConfirm(fileName, userName, specificFileType, corporateId);
						
					}
					else {
						if(rejIds.indexOf(";") >0) {
							rejIdsSplit = rejIds.split(";");
							for(int i=0; i<rejIdsSplit.length;i++) {
								rejectOid.add(rejIdsSplit[i]);
							}
						}else {
							rejectOid.add(rejIds);
						}
						rejectStatus = compBenFileDAOImpl.updateCompBenStatusRejectConfirm(rejectOid, userName, specificFileType, corporateId, fileName);
					
					}
					if (rejectStatus > 0) {
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("fileAction","Reject");
					}else
					{
						response.setErrorCode("BEN009");
					}
				}else {
					if("Yes".equals(selectAllFlag)) {
						rejectStatus = compBenFileDAOImpl.updateBenStatusRejectConfirm(fileName, userName, fileType, corporateId);
						
					}
					else {
						if(rejIds.indexOf(";") >0) {
							rejIdsSplit = rejIds.split(";");
							for(int i=0; i<rejIdsSplit.length;i++) {
								rejectOid.add(rejIdsSplit[i]);
							}
						}else {
							rejectOid.add(rejIds);
						}
						rejectStatus = compBenFileDAOImpl.updateBenStatusRejectConfirm(rejectOid, userName, fileType, corporateId, fileName);
					}
					if (rejectStatus > 0) {
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("fileAction","Reject");
					}else {
						response.setErrorCode("BEN009");
					}
				}
				
			outParams.put("fileType",fileType);
      		}
			else{
				response.setErrorCode("SE010");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}

	
	
	
}
