package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.LateProcessRequestDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

import com.sbi.common.service.BaseService;

public class DownloadReconFilesService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private LateProcessRequestDAO lateProcessRequestDAOImpl;
	
	public Map execute(Map inputParams) {
		logger.info("Map execute(Map inputParams)"+LoggingConstants.METHODBEGIN);
		logger.info("inparams :" + inputParams);
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus("failure");
		List reconList =null;
		String fromDate=(String)inputParams.get("fromDate");
		String toDate=(String)inputParams.get("toDate");
		String corpId=(String)inputParams.get("corpId");
		try {
			if(toDate==null || fromDate == null)
				SBIApplicationException.throwException("SE002");
			reconList=lateProcessRequestDAOImpl.getReconFilesbyDate(corpId, fromDate, toDate);
			if(reconList!=null && reconList.size()>0){
				outParams.put("reconList", reconList);
				response.setErrorStatus("success");
			}
			else
				response.setErrorCode("CA011");
			
		} catch (SBIApplicationException appexp) {
			logger.error(LoggingConstants.EXCEPTION, appexp);
			response.setErrorCode(appexp.getErrorCode());
		} catch (Exception exp) {
			response.setErrorStatus("failure");
			response.setErrorCode("SE002");
			logger.error(LoggingConstants.EXCEPTION, exp);
		}
		outParams.put("applicationResponse", response);

		return outParams;
	}
    public void setLateProcessRequestDAOImpl(
			LateProcessRequestDAO lateProcessRequestDAOImpl) {
		this.lateProcessRequestDAOImpl = lateProcessRequestDAOImpl;
	}
}
