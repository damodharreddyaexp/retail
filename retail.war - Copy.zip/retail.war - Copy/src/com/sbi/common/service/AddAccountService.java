/*
 * AddAccountService.java
 * Created on Dec 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 21, 2005 MURUGAN K - Initial Creation and Method implementations
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.bp.ProfileBP;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.utils.BranchUtils;
import com.sbi.common.utils.LoggingConstants;

/**
 * TODO This class is using for add a account for particular user
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class AddAccountService extends BaseService {

    private ProfileBP profileBP;

    private BranchUtils branchUtils;

    protected final Logger logger = Logger.getLogger(getClass());

    /* (non-Javadoc)
     * @see com.sbi.service.BaseService#execute(java.util.Map)
     */
    public Map execute(Map inputParams)

    {
        logger.info("execute()" + LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Integer accountType = (Integer) inputParams.get(ServiceConstant.ACCOUNT_TYPE);
        String thirdPartyName = (String) inputParams.get(ServiceConstant.THIRD_PARTY_NAME);
        String accountNo = (String) inputParams.get(ServiceConstant.ACCOUNT_NO);
        String branchCode = (String) inputParams.get(ServiceConstant.BRANCH_CODE);
        String transferLimit = (String) inputParams.get(ServiceConstant.TRANSACTION_LIMIT);
        String accessLevel = (String) inputParams.get(ServiceConstant.ACCESS_LEVEL);
        try

        {

            if (userName != null) {

                Account account = new Account();
                account.setAccountNo(accountNo);
                account.setAccountNickName(thirdPartyName);
                account.setUserName(userName);
                account.setBranchCode(branchCode);
                account.setAccountNature(accountType.toString());
                account.setBranchName(branchUtils.getBranchName(branchCode));

                if (accountType != null && accountType.equals(ServiceConstant.THIRD_PARTY) && transferLimit != null) {

                    account.setAccessLevel(new Integer(accessLevel));
                    account.setBalance(new Double(transferLimit));

                }
                Account updatedAccount = profileBP.addUserAccounts(account);
                if (updatedAccount != null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Updated Account :" + updatedAccount.toString());
                    }
                    logger.debug("Updated Account : " + updatedAccount.toString());
                    outParams.put(ServiceConstant.ACCOUNT_DETAILS, updatedAccount);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);

                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE002);
                }
            }
            else {

                response.setErrorCode(ServiceErrorConstants.SE003);
            }

        }
        catch (SBIApplicationException sbiExc) {
            response.setErrorCode(sbiExc.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, sbiExc);

        }
        catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParams;
    }

    public void setProfileBP(ProfileBP profileBP) {
        this.profileBP = profileBP;
    }

    public void setBranchUtils(BranchUtils branchUtils) {
        this.branchUtils = branchUtils;
    }

}
