package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CompBenDataModel;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompBenApproveRecordConfirmService extends BaseService {
	
	protected static Logger logger = Logger.getLogger(CompBenApproveRecordConfirmService.class);
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		logger.info("execute(Map inParams)"+ LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inParams.get("userName");
			String corporateId = (String)inParams.get("coporateId");
			String apprIds = (String)inParams.get("approveIds");
			String fileType = (String) inParams.get("fileType");
			String selectAllFlag = (String) inParams.get("selectAllFlag");
			String fileName = (String) inParams.get("fileName");
			String specificFileType = (String) inParams.get("specificFileType");
			
			String[] apprIdsSplit = null;
			List approveOid = new ArrayList();
			CompBenDataModel[] compBenDataModel;
			int approveStatus =0;
			if(userName != null  && corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim()) &&  fileType != null  && apprIds != null && apprIds.length() > 0  ){
				logger.info("Ids to approve"+apprIds +"UserNAme"+userName);
				
				if("COMPOSITE_BEN".equalsIgnoreCase(fileType) || "ABTP".equalsIgnoreCase(fileType)) {
					if("Yes".equals(selectAllFlag)) {
						approveStatus = compBenFileDAOImpl.updateCompBenStatusConfirm(fileName, userName, specificFileType, corporateId);
						
					}
					else {
						if(apprIds.indexOf(";") >0){
							apprIdsSplit = apprIds.split(";");
							for(int i=0; i<apprIdsSplit.length;i++){
								approveOid.add(apprIdsSplit[i]);
							}
						}else 
						{
							approveOid.add(apprIds);
						}
						approveStatus = compBenFileDAOImpl.updateCompBenStatusConfirm(approveOid, userName, specificFileType, corporateId,fileName);
						
						
						
					}
					if (approveStatus > 0){
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("fileAction","Approve");
					}else
					{
						response.setErrorCode("BEN006");
					}
				}
				else {
					if("Yes".equals(selectAllFlag)) {
						approveStatus = compBenFileDAOImpl.updateBenStatusConfirm(fileName, userName, fileType, corporateId);
						
					}
					else {
						if(apprIds.indexOf(";") >0){
							apprIdsSplit = apprIds.split(";");
							for(int i=0; i<apprIdsSplit.length;i++){
								approveOid.add(apprIdsSplit[i]);
							}
						}else 
						{
							approveOid.add(apprIds);
						}
						approveStatus = compBenFileDAOImpl.updateBenStatusConfirm(approveOid, userName, fileType, corporateId);
						
						
						
					}
					if (approveStatus > 0){
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("fileAction","Approve");
					}else
					{
						response.setErrorCode("BEN006");
					}
				}
				outParams.put("fileType",fileType);
      		}
			else{
				response.setErrorCode("SE010");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}

	
	
	
}
