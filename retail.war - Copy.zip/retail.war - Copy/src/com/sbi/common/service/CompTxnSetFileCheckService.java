/*
 * CompTxnSetFileCheckService.java
 * Created on Sep 18, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;


import com.sbi.common.dao.CompTxnFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;

import org.apache.log4j.Logger;

public class CompTxnSetFileCheckService  extends BaseService{
	private Logger logger=Logger.getLogger(getClass());
	
	private CompTxnFileDAO compTxnFileDAOImpl;
	
	public Map execute(Map inParams) {
		Map outParams=new HashMap();
		
		SBIApplicationResponse response = new SBIApplicationResponse();
		try
		{
		   logger.info("Map execute(Map inputParams) "	+ LoggingConstants.METHODBEGIN);
		 
		   String corporateId = (String)inParams.get("corporateId");
		   int smallFlag = (Integer)inParams.get("smallFlag");
		   response.setErrorStatus(ServiceErrorConstants.FAILURE);
		   if(corporateId != null)
		   {
			   int configCount = 0;
			   String  txnTypeComp = "'COMPOSITE_TXN'";
			   configCount = compTxnFileDAOImpl.findConfigtxnCount(corporateId, txnTypeComp);
			  if(configCount > 0) {
					   outParams.put("compFileConfigFlag","true");
				   }
				   else {
					   outParams.put("compFileConfigFlag","false");
				   }
				   if (smallFlag == 0) {
					   logger.info("In to Vyapar Comp Check "+smallFlag);
			           if(configCount > 0) {
			        	   response.setErrorCode(ServiceErrorConstants.VYAAPAR_CHECK);
			           }else {
				       response.setErrorStatus(ServiceErrorConstants.SUCCESS);
			           }
				   }
				   else {
					   response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				   }
			 
           }else{
        	   response.setErrorCode(ServiceErrorConstants.CORPID_NOT_PRESENT);
	       }
		   
		}catch (SBIApplicationException appex) {
			logger.error(LoggingConstants.EXCEPTION + appex);
			response.setErrorCode(appex.getErrorCode());
		}catch (DAOException exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);

			logger.error(LoggingConstants.EXCEPTION + exp);
		}catch (Exception exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
			response.setErrorCode(ServiceErrorConstants.SE002);
			logger.error(LoggingConstants.EXCEPTION + exp);
		}
		logger.info("execute(Map inParams) end");
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		return outParams;
	}
	
	public void setCompTxnFileDAOImpl(CompTxnFileDAO compTxnFileDAOImpl) {
		this.compTxnFileDAOImpl = compTxnFileDAOImpl;
	}

}
