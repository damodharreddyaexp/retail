/*
 * DigitalCertificateAuthenticateService.java
 * Created on March 29, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */

package com.sbi.common.service;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.sbi.common.dao.DigitalCertificateDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.PKCS7CertificateExtractor;

import emas.ws.ds.DSAuthenticateWS;
import emas.ws.ds.DSAuthenticateWSProxy;

public class DigitalCertificateAuthenticateService extends BaseService {
    private DigitalCertificateDAO digitalCertificateDAOImpl;

    
	protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {

        logger.info("RegisterCertificateConfirmService Method Starts ");

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        Map outParams = new HashMap();
        String userName = (String)inputParams.get("userName");
        String profileSerialNo = (String)inputParams.get("profileSerialNo");
        String signedData = (String)inputParams.get("signedData");
        String serialNo = "";
        String digitalErrorCode ="";
        logger.info("userName : " + serialNo);
        logger.info("profileSerialNo : " + profileSerialNo);
        logger.info("signedData : " + signedData);
        boolean isValid = false;
        try {
        	DSAuthenticateWS authenticateWS = new DSAuthenticateWSProxy().getDSAuthenticateWS();
        	String verifyMsg = authenticateWS.authenticate(userName, signedData,null, null);
        	if(verifyMsg != null)
        	digitalErrorCode = verifyMsg.substring(0,5);
        	
        	logger.info("digitalErrorCode >>>"+digitalErrorCode);
        		logger.info("verifyMsg :" + verifyMsg);
        		if (verifyMsg.startsWith("success")) {
        			serialNo = getSNFromPKCS7(signedData);
        			if (serialNo.equalsIgnoreCase(profileSerialNo)) {
        				isValid = true;
        			}
        			logger.info("isValid :" + isValid);
            		outParams.put("isValid",isValid);
            		response.setErrorStatus(ServiceErrorConstants.SUCCESS);
        		}else if(digitalErrorCode.equalsIgnoreCase("e9001")){
                	response.setErrorCode("DSC003");
                }else{                	
                	response.setErrorCode("DSC001");
                }
               
        		
	        }
	        catch (SBIApplicationException sbiApplicationException) {
	
	            logger.error(sbiApplicationException, sbiApplicationException);
	            response.setErrorStatus(ServiceErrorConstants.FAILURE);
	            response.setErrorCode(sbiApplicationException.getErrorCode());
	
	        }
	        catch (DAOException daoException) {
	
	            logger.error(daoException, daoException);
	            response.setErrorStatus(ServiceErrorConstants.FAILURE);
	            response.setErrorCode(ServiceErrorConstants.SE002);
	        }
	         catch (Exception exp) {
	            response.setErrorStatus(ServiceErrorConstants.FAILURE);
	            response.setErrorCode(ServiceErrorConstants.SE002);
	            logger.error("Exception occured: " , exp);
	        }

      
        outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("RegisterCertificateConfirmService Method Ends ");
        return outParams;
    }
    
    private String getSNFromPKCS7(String pkcs7Data) {
        PKCS7CertificateExtractor certificateExtractor = new PKCS7CertificateExtractor(
                Base64.decodeBase64(pkcs7Data));
        Certificate[] certificates = certificateExtractor.extract();
        String serialNumber = getSNFromCertificate(certificates[0]);
        logger.info("Serial Number ----->" + serialNumber);
        return serialNumber;
    }
    private String getSNFromCertificate(Certificate certificate) {
        X509Certificate x509Certificate = (X509Certificate) certificate;
        String serialNumber = x509Certificate.getSerialNumber().toString();
        return serialNumber;
    }

	public void setDigitalCertificateDAOImpl(
			DigitalCertificateDAO digitalCertificateDAOImpl) {
		this.digitalCertificateDAOImpl = digitalCertificateDAOImpl;
	}
    
 }
