/*
 * AddThirdPartyHandler.java
 * Created on Mar 17, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 17, 2006 Asit- Initial Creation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ThirdPartyDAO;
import com.sbi.common.model.ApproveDelTPModel;

/**
 * This class used for to display the ApproveDeleteThirdParty Information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
 public class ApproveDel3pService extends BaseService{
    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO thirdPartyDAOImpl;
    
    
     /**
     * call the [thirdPartyDAOImpl.findDelTPsByFile(userName,appFileName)] return Map which is contains 
     * ApproveDeleteTpFile Aproved and Unapproved Names.
     * 
     * @param inputParams
     * @return Map
     * 
     */
    
    public Map execute(Map inputParam) {
        logger.info("ecutParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();

        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String fileName = "";
        String userName = "";
        ApproveDelTPModel[] approveDelTPModel;
        fileName = (String) inputParam.get("tpFileName");
        
        logger.info("File Name:    " + fileName);

        userName = (String) inputParam.get(ServiceConstant.USER_NAME);
        logger.info("userName :" + userName);
        String[] pages = new String[3];
        int i = 0;
        int index = fileName.indexOf('.');
        logger.info("index :"+index);
        String name = fileName.substring(0,index);
        logger.info("name :"+name);
        /*StringTokenizer st = new StringTokenizer(name, "/");

        while (st.hasMoreTokens()) {
            pages[i] = st.nextToken();
            i++;
        }*/
      
        //String appFileName = pages[1]+"%";
        String appFileName = name+"%";
        
        logger.info("The file name passed ........" + appFileName );
        try {
            if (fileName != null
                    && !fileName.trim().equals(ServiceConstant.EMPTY)
                    && userName != null
                    && !userName.trim().equals(ServiceConstant.EMPTY)) {

                approveDelTPModel= thirdPartyDAOImpl.findDelTPsByFile(userName,appFileName);
                logger.info("The model......." + approveDelTPModel);

                if (approveDelTPModel != null && approveDelTPModel.length > 0) {
                    logger.info("noOfRecords="+inputParam.get("noOfRows"));
                    logger.info("particularPageNumber=="+inputParam.get("particularPageNumber"));
                    //Added by Sunjay S Galen
                    int limits=new Integer((String)inputParam.get("noOfRows")).intValue();
                     int pageNo = (new Integer((String) inputParam.get("particularPageNumber"))).intValue();
                        int l=0;
                        for (int j = (pageNo - 1) * limits; j < limits * pageNo && j < approveDelTPModel.length; j++) {

                         //limitedList.add(corporateTP[j]);
                            //approveDelTPModel1[k]=approveDelTPModel[j];
                            l=l+1;

                        }

                    ApproveDelTPModel[] approveDelTPModel1;
                    if(limits<=approveDelTPModel.length)
                    {
                        approveDelTPModel1=new ApproveDelTPModel[l];
                    }
                    else
                    {
                        approveDelTPModel1=new ApproveDelTPModel[approveDelTPModel.length];
                    }
                     
                     int k=0;
                        for (int j = (pageNo - 1) * limits; j < limits * pageNo && j < approveDelTPModel.length; j++) {

                         //limitedList.add(corporateTP[j]);
                            approveDelTPModel1[k]=approveDelTPModel[j];
                         k=k+1;
                      
                        }
                     //int limits = 2;
                       
                    outParam.put("approveTPFileDetails", approveDelTPModel1);
                     //outParam.put("approveTPFileDetails", limitedList);
                    outParam.put("totalFileDetails",new Integer(approveDelTPModel.length));
                    
                    int len=approveDelTPModel.length;
                    int totalPage=len/limits;
                    if(len%limits!=0)
                        totalPage=totalPage+1;
                    logger.info("totalPage=="+totalPage);
                    outParam.put("totalPage",new Integer(totalPage));
                    

                    //outParam.put("approveTPFileDetails", approveDelTPModel);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                } else {
                    response.setErrorCode(ServiceErrorConstants.CR001);
                }
            } else {
                response.setErrorStatus(ServiceErrorConstants.CR002);
            }
            
        } catch (SBIApplicationException appex) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("outParam :" + outParam);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParam;

    }


    public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl)
    {
        this.thirdPartyDAOImpl = thirdPartyDAOImpl;
    }

     /**
     * TODO ThirdPartyDAOImpl  injection done here
     * @param thirdPartyDAOImpl void
     */
    
    
    
    
}


