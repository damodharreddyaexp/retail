/*
 * GenerateDSCFormService.java
 * Created on Mar 29, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DigitalCertificateDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.DSCDetails;


public class GenerateDSCFormService extends BaseService{
	
	private final Logger logger=Logger.getLogger(getClass());
	private SBIApplicationResponse response=new SBIApplicationResponse();
	Map outParams=new HashMap();
	private DigitalCertificateDAO digitalCertificateDAOImpl;

	public Map execute(Map inputParams){

		logger.info(" execute(Map inputParams) - begin");
		response.setErrorStatus(ServiceConstant.FAILURE);
		List c11FormRegList=new  ArrayList();
		List c11FormReRegList=new  ArrayList();
		Map outParams = new HashMap();
		DSCDetails dscDetails=null;
		try{

			String userName = (String)inputParams.get("userName");
			String corporateId = (String)inputParams.get("corporateId");
			String functionType = (String)inputParams.get("functionType");
			String referenceNo = (String)inputParams.get("referenceNo");
			String requestType = (String)inputParams.get("requestType");
			
			if (userName != null || referenceNo!=null) {
				
				if(functionType!=null && "listView".equalsIgnoreCase(functionType)) {
					
					c11FormRegList = digitalCertificateDAOImpl.getC11FormRegListDetails(userName,corporateId);
					logger.info("c11FormRegList ::"+c11FormRegList);
					
					c11FormReRegList = digitalCertificateDAOImpl.getC11FormReRegListDetails(userName,corporateId);
					logger.info("c11FormReRegList ::"+c11FormReRegList);
					
					
					if (c11FormRegList != null && c11FormRegList.size()> 0) {
						
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("c11FormRegList", c11FormRegList);
						
					}
					if (c11FormReRegList != null && c11FormReRegList.size()> 0) {
						
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("c11FormReRegList", c11FormReRegList);
						
					}else {
						response.setErrorCode("DSC002");
					}
				}
				else {
					dscDetails = digitalCertificateDAOImpl.getDSCFormDetails(referenceNo,requestType);
					logger.info("dscDetails ::"+dscDetails);
					
					if (dscDetails != null) {
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("dscDetails", dscDetails);
						outParams.put("referenceNo", dscDetails.getReferenceNo());
					}
					else {
						response.setErrorCode("DSC002");
					}
				}	
			}
			else {
				response.setErrorCode(ServiceErrorConstants.SE002);
			}
		

		}catch (DAOException daoException) {
			response.setErrorCode(daoException.getErrorCode());
		}catch (Exception exception) {
			exception.printStackTrace();
			response.setErrorCode(ServiceErrorConstants.SE002);;
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);   
		logger.info(" execute(Map inputParams) - end");
		return outParams;
	}

	public void setDigitalCertificateDAOImpl(
			DigitalCertificateDAO digitalCertificateDAOImpl) {
		this.digitalCertificateDAOImpl = digitalCertificateDAOImpl;
	}

	
	
 }
