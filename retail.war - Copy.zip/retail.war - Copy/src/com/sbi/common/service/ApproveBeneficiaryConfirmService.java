/*
 * AddThirdPartyHandler.java
 * Created on Mar 17, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 17, 2006 Asit- Initial Creation

package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ThirdPartyDAO;
import com.sbi.common.model.ApproveDelTPModel;
import com.sbi.common.model.User;

 public class ApproveBeneficiaryConfirmService extends BaseService{
    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO thirdPartyDAOImpl;    

    
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParam))" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);        
        User user = (User) inputParam.get("user");
        String corpId=user.getCorporateId();
        String userName=user.getUserAlias();
        String actionType=(String)inputParam.get("actionType");
        String oids=(String)inputParam.get("oids");
        boolean status = false;
        String oidsApproved="";
        String remarks="-";
        String type=(String)inputParam.get("type");
        List beneficiaryDetailsConfirm;
        
        try {
        	
        	    if(actionType.equals("Approved")){
        	    	
        	   //Below code commented to remove validation and these validation done in add ben in corpuser -beneficiary revamp form based. 	
        	    //	List adminOidsList=thirdPartyDAOImpl.getAlreadyAddedOids(oids,userName,type);
        	    	/*if(adminOidsList!=null&&adminOidsList.size()!=0){
        	    		String oidsRejected=adminOidsList.toString();
        	    		oidsRejected=oidsRejected.substring(1, oidsRejected.length()-1);
        	    	    logger.info("Rejected Oids :"+oidsRejected);   
//        	    	    thirdPartyDAOImpl.approveBeneficiary(userName,"Rejected","Already added by Admin or Regulator",oidsRejected,type);
        	    	    thirdPartyDAOImpl.approveBeneficiary(userName,"Rejected","Already added by Admin or Regulator",oidsRejected,type,corpId);	 Ramanan M - Corp Admin Paladion Security Changes 
        	    	    int count = 0;
        	    	    for(String oid: oids.split(",")){
        	    	    	if(!adminOidsList.contains(oid)){
        	    	    		if(oidsApproved.equals(""))
        	    	    		    oidsApproved=oidsApproved+oid;
        	    	    		else
        	    	    			oidsApproved=oidsApproved+","+oid;
        	    	    	}
        	    	    }
        	    	    logger.info("Approved Oids :"+oidsApproved);
        	    	 }
        	    	else{
        	    		logger.info("Already No Acccounts admin Added");
        	    		oidsApproved=oids;
        	    	} */
        	    if(oids!=null&&oids.trim().length()>0){
        	    	if(type.equals("interbank"))
        	    		actionType="active";
//        	      thirdPartyDAOImpl.approveBeneficiary(userName,actionType,remarks,oidsApproved,type);
        	    	status=	thirdPartyDAOImpl.approveBeneficiary(userName,actionType,remarks,oids,type,corpId);	/* Ramanan M - Corp Admin Paladion Security Changes */
        	    }
        	    }
        	    else if (actionType.equals("Rejected")){
        	        remarks=(String)inputParam.get("remarks");  
//        	        thirdPartyDAOImpl.approveBeneficiary(userName,actionType,remarks,oids,type);
        	        status=  thirdPartyDAOImpl.approveBeneficiary(userName,actionType,remarks,oids,type,corpId);	/* Ramanan M - Corp Admin Paladion Security Changes */
        	    }     
        	    if (status != false){
                 beneficiaryDetailsConfirm=thirdPartyDAOImpl.getBeneficiaryByOid(oids,type,corpId);
                   if(beneficiaryDetailsConfirm!=null&&beneficiaryDetailsConfirm.size()!=0){
                     response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                     outParam.put("beneficiaryDetailsConfirm",beneficiaryDetailsConfirm);
                     logger.info(actionType+"List :"+beneficiaryDetailsConfirm.toString());
                   }
                   else
                	   response.setErrorCode("CR003");  
        	    }
        	    else {
        	    	 response.setErrorCode("CR002");  
        	    	
        	    }
                  
               
        }  catch (Exception exp) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("outParam :" + outParam);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParam;

    }
   
   /* private ArrayList formatInput(String inputs,String type,String actionType,String remarks){

		ArrayList al=new ArrayList();
    	if(type.equals("TP")){
    		String[] thirdPartyDetails=inputs.split(",");
    		for(int i=0;i<thirdPartyDetails.length;i++){
    			String value=thirdPartyDetails[i];
    			String[] thirdParty=value.split("#");
    			CorporateTP tp=new CorporateTP();
    			tp.setOid(Integer.parseInt(thirdParty[0]));
    			tp.setName(thirdParty[1]);
    			tp.setAddedBy(thirdParty[2]);
    			tp.setBranchCode(thirdParty[3]);
    			tp.setAccountNo(thirdParty[4]);
    			tp.setApprovedStatus(actionType);
    			tp.setRemarks(remarks);
    			logger.info(tp);
    			al.add(tp);
    		}
    	}
    	return al;
    }*/

    public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl)
    {
        this.thirdPartyDAOImpl = thirdPartyDAOImpl;
    }

     /**
     * TODO ThirdPartyDAOImpl  injection done here
     * @param thirdPartyDAOImpl void
     */
    
    
    
    
}


