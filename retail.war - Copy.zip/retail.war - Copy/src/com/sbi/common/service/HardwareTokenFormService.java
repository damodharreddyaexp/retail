/*
 * GenerateDSCFormService.java
 * Created on Mar 29, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.EnableHardwareTokenDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.HardwareTokenDetails;


public class HardwareTokenFormService extends BaseService{
	
	private final Logger logger=Logger.getLogger(getClass());
	private SBIApplicationResponse response=new SBIApplicationResponse();
	Map outParams=new HashMap();
	private EnableHardwareTokenDAO enableHardwareTokenDAOImpl;

	public Map execute(Map inputParams){

		logger.info(" execute(Map inputParams) - begin");
		response.setErrorStatus(ServiceConstant.FAILURE);
		List c10FormList=new  ArrayList();
		Map outParams = new HashMap();
		HardwareTokenDetails hardwareTokenDetails=null;
		try{

			String userId = String.valueOf(inputParams.get("userId"));
			String corporateId = (String)inputParams.get("corporateId");
			String functionType = (String)inputParams.get("functionType");
			String referenceNo = (String)inputParams.get("referenceNo");
			
			if (userId != null || referenceNo!=null) {
				
				if(functionType!=null && "listView".equalsIgnoreCase(functionType)) {
					
					c10FormList = enableHardwareTokenDAOImpl.getC10FormListDetails(userId,corporateId);
					logger.info("c10FormList ::"+c10FormList);
					
					if (c10FormList != null && c10FormList.size()> 0) {
						
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("c10FormList", c10FormList);
						
					}
					else {
						response.setErrorCode("VS002");
					}
				}
				else {
					hardwareTokenDetails = enableHardwareTokenDAOImpl.getC10FormDetails(referenceNo);
					logger.info("hardwareTokenDetails ::"+hardwareTokenDetails);
					
					if (hardwareTokenDetails != null) {
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("hardwareTokenDetails", hardwareTokenDetails);
						outParams.put("referenceNo", hardwareTokenDetails.getReferenceNo());
					}
					else {
						response.setErrorCode("VS002");
					}
				}	
			}
			else {
				response.setErrorCode(ServiceErrorConstants.SE002);
			}
		

		}catch (DAOException daoException) {
			response.setErrorCode(daoException.getErrorCode());
		}catch (Exception exception) {
			exception.printStackTrace();
			response.setErrorCode(ServiceErrorConstants.SE002);;
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);   
		logger.info(" execute(Map inputParams) - end");
		return outParams;
	}

	public void setEnableHardwareTokenDAOImpl(
			EnableHardwareTokenDAO enableHardwareTokenDAOImpl) {
		this.enableHardwareTokenDAOImpl = enableHardwareTokenDAOImpl;
	}

	
 }
