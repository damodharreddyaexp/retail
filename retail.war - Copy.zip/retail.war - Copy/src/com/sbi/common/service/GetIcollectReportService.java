package com.sbi.common.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import com.sbi.common.dao.IcollectDao;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;

public class GetIcollectReportService extends BaseService{
	protected static Logger logger = Logger.getLogger(DownloadIcollectReportsService.class);
	private IcollectDao icollectDaoImpl;
	public Map execute(Map inParams) {
		Map outParams = new HashMap();
		StringBuffer filecontent = new StringBuffer();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			List reportList = null ;
			String userName = (String) inParams.get("userName");
			reportList = icollectDaoImpl.getReportRequest(userName);
			if(reportList != null && reportList.size() > 0){
				outParams.put("reportList", reportList);
				response.setErrorStatus(ServiceConstant.SUCCESS);
			}else{
				response.setErrorCode("SUV042");
			}
			
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParams;
	}
	public void setIcollectDaoImpl(IcollectDao icollectDaoImpl) {
		this.icollectDaoImpl = icollectDaoImpl;
	}
}
