package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CorporateReportDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;



public class  FailureTxnService extends BaseService {

    protected final Logger logger = Logger.getLogger(getClass());

	private CorporateReportDAO corporateReportDAOImpl;
    
    public Map execute(Map inputParams) {

    	logger.info("execute(Map inputParams) method begin " + LoggingConstants.METHODBEGIN); 
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        Map outParams = new HashMap();
        String requestId = "";
        String funcType = (String)inputParams.get("funcType");
        
        try {
        	if("requestFailureTxn".equals(funcType)) {
        		
        		if(inputParams.get("startDate")!=null  && inputParams.get("endDate")!=null && inputParams.get("userName")!=null) {
	        		 	
	    		 	logger.info("inputParams"+ inputParams);
	    		 	requestId = corporateReportDAOImpl.reqFailureTxn(inputParams);
	    		 	
	    		 	logger.info("requestId :" +requestId);
	    		 	if(requestId!=null && !"".equals(requestId.trim())) {
	    		 		outParams.put("requestId", requestId);
	    		 		response.setErrorStatus(ServiceErrorConstants.SUCCESS);
	    		 	}else {
	        			response.setErrorCode("F001");
	        		}
	    		 	
	        	}
        		else {
        			response.setErrorCode("FT001");
            		logger.info("Null Input");
        		}
        	}	
        	else if("downloadStatusFailureTxn".equals(funcType))
			{
				
				String userName = (String)inputParams.get("userName");
				logger.info("userName:"+userName);
				
				List failureTxnList= corporateReportDAOImpl.downloadFailureTxnRequestStatus(userName);
            	if (failureTxnList != null && failureTxnList.size() > 0)
            	{
            		outParams.put("failureTxnList", failureTxnList);
            		response.setErrorStatus(ServiceConstant.SUCCESS);
            	}
            	else {
            		logger.info("No Records Found");
            		response.setErrorCode("FT002");
            		
            	}
            	
			}
        }
        catch (DAOException daoExp) {
            logger.error("execute(Map inputParams) method throws Exception :" + daoExp.toString());
            SBIApplicationException exception = new SBIApplicationException(daoExp.getMessage());
            throw exception;
        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error("Exception occured: " + exp);
        }
        outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams) method end" + LoggingConstants.METHODEND);
        return outParams;
        	
    }

    public void setCorporateReportDAOImpl(CorporateReportDAO corporateReportDAOImpl) {
		this.corporateReportDAOImpl = corporateReportDAOImpl;
	}

}

