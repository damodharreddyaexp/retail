
/*
 * GEUserLogonService.java
 * Created on Feb 13, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 13, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.GEUserLogonDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
public class GEUserLogonService extends BaseService
{
    private GEUserLogonDAO geUserLogonDAOImpl;
    
    protected final Logger logger = Logger.getLogger(getClass());
   
    public Map execute(Map inputParams)
    {
        logger.info("execute(Map inputParams) begin");
        String userName =(String) inputParams.get(ServiceConstant.USER_NAME);
        String password= (String) inputParams.get(ServiceConstant.PASSWORD );
        Map map = new HashMap();
        boolean rowsUpdated ;
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus( ServiceErrorConstants.FAILURE );
        try{
            if(userName != null && password != null ){
                String status = geUserLogonDAOImpl.findStatus(userName,password);
                
                if(status.equalsIgnoreCase(ServiceConstant.PROCESSED))
                {
                    rowsUpdated= geUserLogonDAOImpl.updateStatus(userName,password);
                    if(rowsUpdated == true)
                    {
                        map.put(ServiceConstant.STATUS,status);
                        response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    }else{
                        response.setErrorCode(ServiceErrorConstants.SE002);
                    }
                }else if(status != null){
                    map.put(ServiceConstant.STATUS,status);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                }else{
                    map.put(ServiceConstant.STATUS,ServiceConstant.NO_DATA);
                }
            }
        }catch (SBIApplicationException appexp) {
            logger.error(LoggingConstants.EXCEPTION, appexp);
            response.setErrorCode(appexp.getErrorCode());

        }
        catch (DAOException doaExp) {
            response.setErrorCode(doaExp.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION,  doaExp);

        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION,  exp);

        }
        map.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("Map execute(Map inputParams) method end");
        return map;
        
    }

    /**
     * @param geUserLogonDAOImpl The geUserLogonDAOImpl to set.
     */
    public void setGeUserLogonDAOImpl(GEUserLogonDAO geUserLogonDAOImpl)
    {
        this.geUserLogonDAOImpl = geUserLogonDAOImpl;
    }
    
}
