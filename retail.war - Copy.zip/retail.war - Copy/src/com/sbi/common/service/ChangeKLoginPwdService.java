package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

 //Added for SHA encryption algorithm
import com.sbi.authentication.algorithm.Sha512Hashing;
import com.sbi.authentication.user.RequestResponseService;

import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import org.apache.log4j.Logger;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.bp.LogonBP;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.*;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.CommonUtils;
import com.sbi.common.utils.Decrypt;
import com.sbi.common.utils.EncryptMD5;
import com.sbi.common.utils.LogonValidator;
import com.sbi.common.utils.TransactionPWDUtil;


public class ChangeKLoginPwdService extends BaseService
{

    private UserDAO userDAOImpl;
    private CommonUtils commonUtils; //sairam added this line for CR5550
    private String rndString;
   
    protected final Logger logger = Logger.getLogger(getClass());
    
    private LogonValidator logonValidator;
    
    private RequestResponseService requestResponseService; //Added for SHA encryption algorithm

    private Sha512Hashing sha512Hashing; //Added for sha
    
	public Map execute(Map inputParams){
	
        Map outParams = new HashMap();
        Decrypt dec=new Decrypt();
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);        
        String password = (String) inputParams.get(ServiceConstant.PASSWORD);
        String keyid = (String)inputParams.get("keyid");
        String keyString = (String)inputParams.get("keyString");
        String ip_address = (String)inputParams.get("ip_address");
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        UserProfile userProfile = null;//sairam added this line for CR5550
    	String profilePassword = null;//sairam added this line for CR5550
    	String txnPassword = null;//sairam added this line for CR5550
          try {
			//by nag start
			if(keyid != null && keyid.length() > 0){
				password=dec.decrypt(keyid, password);
			}
			else if(keyString != null && keyString.length() > 0){
				password=dec.decrypt(keyString, password);
			}
			//by nag end			
		} catch (Exception exp) {
			exp.printStackTrace();
			logger.info("changeKlogin",exp);
			logger.error(LoggingConstants.EXCEPTION,exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
			outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);	
			return outParams;
		}
		
        if(userName != null && !userName.trim().equalsIgnoreCase("") && password != null && !password.trim().equalsIgnoreCase("")){
	       try{
	            logger.info("userName ="+userName);
	            if(logonValidator.loginPassword(password))
	            {	  
	            	//sairam added here for CR 5550  - start
	            	String encPassword = EncryptMD5.hashMessage(userName+"#"+password);
		           userProfile = userDAOImpl.findUserProfile(userName);
		           	profilePassword=userProfile.getProfilepassword();
		           	txnPassword=userProfile.getTxnPassword();   	
		           	
		           	//Added for SHA encryption algorithm
		        	String profilePwdType=userProfile.getProfileHashing();
		        	String txnPwdType=userProfile.getTransactionHashing();
		           	
	                  //if(profilePassword!=null && commonUtils.verifyEncryption(userName + "|" + password, profilePassword))
		        	if(profilePassword!=null)  
        			{
	        			 if("SHA-512".equals(profilePwdType) && requestResponseService.validateHashSHA2(profilePassword,userName+ "|" + password))
	    				 {
	    					 response.setErrorCode("V0766");
	    				 }
	    				 else if(commonUtils.verifyEncryption(userName + "|" + password, profilePassword))
	    				 {
	        				response.setErrorCode("V0766");
	    				 }
		        		//response.setErrorCode("V0766");
	                }
	      			 //else if (txnPassword !=null && TransactionPWDUtil.encryptPassword(password).equals(txnPassword))
	                  if(txnPassword !=null) 
	                  {
	                	  	if("SHA-512".equals(txnPwdType) && requestResponseService.validateHashSHA2(txnPassword,userName+ "~" + password))
							{
								response.setErrorCode("V0765");
							}
							else if((TransactionPWDUtil.encryptPassword(password).equals(txnPassword)))
							{
	                	  		response.setErrorCode("V0765");
							}
	                	  //response.setErrorCode("V0765");
	                   }
	                  //else{
        			//sairam added here for CR 5550 - End
	            	int passHistCount = userDAOImpl.getPrevPassHistory(userName, encPassword);
	            	
	            	//Added for SHA encryption algorithm -Start
	    			int passHistSHACount = userDAOImpl.getPrevPassHistory(userName, sha512Hashing.hashingSHA2(userName + "#" + password));
	    			passHistCount=passHistCount+passHistSHACount;
	    			//Added for SHA encryption algorithm -End
	    			
	    			/*if (passHistCount <= 0){
	    				 userDAOImpl.changeKLoginPassword(userName,password,ip_address); 	
	    				 response.setErrorStatus(ServiceConstant.SUCCESS);
	    			}else{
	    				response.setErrorCode("SE151");
	    			}*/
	    			if (passHistCount>0){
	    				response.setErrorCode("SE151");
	    			}
	    			if(response.getErrorCode()==null || "".equals(response.getErrorCode()))
	    			{
	    				userDAOImpl.changeKLoginPassword(userName,password,ip_address); 	
	   				 	response.setErrorStatus(ServiceConstant.SUCCESS);
	    			}
	    			
	            //}
	    		
	            }
	        }
	        catch (DAOException daoException){
	            logger.error(LoggingConstants.EXCEPTION, daoException);
	            response.setErrorCode(daoException.getErrorCode());
	        }
	        catch (Exception excep){
	            logger.error(LoggingConstants.EXCEPTION, excep);
	            response.setErrorCode(ServiceErrorConstants.SE002);
	        }
	
	        }else{
	            logger.info("one of the value is null");
	            response.setErrorCode(ServiceErrorConstants.SE003);
	        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);        
        return outParams;

    }


public void setUserDAOImpl(UserDAO userDAOImpl) {
	this.userDAOImpl = userDAOImpl;
}


public void setLogonValidator(LogonValidator logonValidator) {
	this.logonValidator = logonValidator;
}
//Sairam Added here for CR5550 - Start
public void setCommonUtils(CommonUtils commonUtils) {
    this.commonUtils = commonUtils;
}
//Sairam Added here for CR5550 - End
private LogonValidator passwordValidator;

	//Added for SHA encryption algorithm
	public void setRequestResponseService(
			RequestResponseService requestResponseService) {
		this.requestResponseService = requestResponseService;
	}
	//	Added for sha
	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}		
}
