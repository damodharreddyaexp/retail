/* 
 * CSupportLogonService .java
 * Created on Nov 20, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $  
 */
//	History
//	Nov 20, 2006 Aparna S - Initial Creation
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import com.sbi.common.bp.LogonBP;
import com.sbi.common.bp.ProfileBP;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.EncryptMD5;

/**
 * TODO This class is used get the User related information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class CSupportLogonService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private LogonBP logonBP;

	private ResourceBundleMessageSource logonProperty;

	
	/** 
	 * TODO Call [UserDAOImpl.findUser(userName, password)] return User objec,
	 * Call [UserDAOImpl.findUserProfile(User.getUserId()] return UserProfile
	 * object
	 * 
	 * @param inputParams
	 * @return Map
	 */
	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams of CSupportLogonService) "
				+ LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map:" + inputParams);
		Map outParams = new HashMap();
		//Map inParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
		String password = (String) inputParams.get(ServiceConstant.PASSWORD);
		String bankCode = (String) inputParams.get(ServiceConstant.BANK_CODE);
		String sessionId = (String) inputParams.get(ServiceConstant.SESSION_ID);
		
		logger.info("Bank Code :  " + bankCode);
		logger.info("password ::  " + password);
		logger.info("User ::  " + userName);
		User user = new User();
		user.setUserAlias(userName);
		user.setUserIPaddress((String) inputParams
				.get(ServiceConstant.IP_ADDRESS));
		logger.info("Ip add in CSSupport service ::"+user.getUserIPaddress());
		String loginStatus = null;
		if (userName != null && password != null && bankCode != null) {
				
				try {
					boolean flag=false;
					String fromProperty = logonProperty.getMessage(
							"CSupportLoginPWD", null, null);
					logger.info("pwd from property file  : "+fromProperty);
					
					flag = EncryptMD5.verifyHash(password,fromProperty);
					logger.info("flag --------"+flag);
					if (flag) {
	
						outParams = logonBP.getUserDetails(inputParams);
						UserProfile profile = (UserProfile) outParams
								.get("profile");
						String displayName = profile.getFriendlyName();
						if (displayName == "")
							displayName = profile.getName();
						outParams
								.put(ServiceConstant.DISPLAY_NAME, displayName);
						loginStatus = ServiceConstant.LOGIN_SUCCESS;
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}

				

			} catch (SBIApplicationException sbiExp) {
				loginStatus = ServiceConstant.LOGIN_FAILURE;
				logger.error(LoggingConstants.EXCEPTION, sbiExp);
				response.setErrorCode(sbiExp.getErrorCode());
			} catch (DAOException appexp) {
				logger.error(LoggingConstants.EXCEPTION, appexp);
				response.setErrorCode(appexp.getErrorCode());
			} catch (Exception exp) {
				logger.error(LoggingConstants.EXCEPTION, exp);
				response.setErrorCode(ServiceErrorConstants.SE002);
			}

		} else {
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		if (logger.isDebugEnabled())
			logger.debug("outParams Map contains: " + outParams);
		logger.info("execute(Map inputParams) method end"
				+ LoggingConstants.METHODBEGIN);

		return outParams;
	}
	/**
	 * TODO UserDAOImpl object injection
	 * 
	 * @param userDAOImpl
	 *            void
	 */

	public void setLogonBP(LogonBP logonBP) {
		this.logonBP = logonBP;
	}

	public void setLogonProperty(ResourceBundleMessageSource logonProperty) {
		this.logonProperty = logonProperty;
	}

}
