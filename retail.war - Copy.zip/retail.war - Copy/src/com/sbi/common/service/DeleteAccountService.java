/*
 * DeleteAccountService.java
 * Created on Dec 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 21, 2005 MURUGAN K - Initial Creation and Implementations
//Jan 31 MURUGAN K - Log changes
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.utils.LoggingConstants;

/**
 * TODO Enter the description of the class here 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class DeleteAccountService extends BaseService {

    private AccountDAO accountDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams)

    {
        logger.info("execute()" + LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Integer accountNature = (Integer) inputParams.get(ServiceConstant.ACCOUNT_TYPE);
        String thirdPartyName = (String) inputParams.get(ServiceConstant.THIRD_PARTY_NAME);
        String accountNo = (String) inputParams.get(ServiceConstant.ACCOUNT_NO);
        String branchCode = (String) inputParams.get(ServiceConstant.BRANCH_CODE);
        String corporateId = (String) inputParams.get("corporateId");
        String oid = (String) inputParams.get("oid");
				
        String type=(String) inputParams.get("type");
        if (logger.isDebugEnabled())
            logger.debug("Account No " + accountNo + "accountNature" + accountNature);

        Account account = new Account();
        account.setAccountNo(accountNo);
        account.setAccountNickName(thirdPartyName);
        account.setUserName(userName);
        account.setBranchCode(branchCode);
        account.setAccountNature(accountNature.toString());
        account.setAccountNickName(thirdPartyName);
        account.setRefNo(oid);
        boolean status = false;
        try

        {

            if (userName != null) {
            	Account updatedAccount=null;
            	if(type!=null && type.equals("DD"))//Changed For CR 5390 defect only for DD beneficiary added by corpuser
                    updatedAccount = accountDAOImpl.deleteAccount(account);
            	else {
            		//updatedAccount = accountDAOImpl.deleteTPAccount(account);
            		updatedAccount = accountDAOImpl.deleteTPAccountDtls(account,corporateId);
            	}
                if (updatedAccount != null) {
                    outParams.put(ServiceConstant.ACCOUNT_DETAILS, updatedAccount);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    if (logger.isDebugEnabled())
                        logger.debug("Updated Account" + updatedAccount.toString());

                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE002);

                }

            }
            else {
                response.setErrorCode(ServiceErrorConstants.SE002);

            }

        }
        catch (SBIApplicationException sbiExc) {
            response.setErrorCode(sbiExc.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, sbiExc);
        }
        catch (DAOException daoExp) {
            response.setErrorCode(daoExp.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, daoExp);
        }
        catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
            logger.debug("output Map contains :" + outParams);
        logger.info("Map execute(Map inputParams) method end");
        return outParams;
    }

    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

}
