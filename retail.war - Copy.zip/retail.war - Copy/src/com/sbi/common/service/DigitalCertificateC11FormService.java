package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DigitalCertificateDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;


public class DigitalCertificateC11FormService extends BaseService {

	private DigitalCertificateDAO digitalCertificateDAOImpl;


	protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {

        logger.info("DigitalCertificateC11FormService Method Starts ");

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        Map outParam = new HashMap();
        String referenceNo = (String)inputParams.get("referenceNo");
        String dscFunction = (String)inputParams.get("dscFunction");
        logger.info("referenceNo :"+referenceNo);
        List dscDetailsList=null;
        
            try {
       
            	if(referenceNo != null){
            		dscDetailsList = digitalCertificateDAOImpl.getc11FormDetails(referenceNo,dscFunction);
            		if(dscDetailsList.get(0)!= null)
            	outParam.put("dscDetails", dscDetailsList.get(0));
            	
            	if(dscDetailsList.get(1)!= null)
            	outParam.put("certificateDetails", dscDetailsList.get(1));
            	
            	response.setErrorStatus(ServiceConstant.SUCCESS); 
            	 logger.info("dscDetails=======>"+outParam.get("dscDetails"));
            	 logger.info("certificateDetails=======>"+outParam.get("certificateDetails"));
            	}else{
            		response.setErrorCode(ServiceErrorConstants.RM001);
            	}
           
            	 logger.info("DES Details -->"+outParam.get("dscDetails"));
            	 logger.info("certificateDetails Details -->"+outParam.get("certificateDetails"));
                
            }
            catch (SBIApplicationException sbiApplicationException) {

                logger.error(sbiApplicationException, sbiApplicationException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(sbiApplicationException.getErrorCode());

            }
            catch (DAOException daoException) {

                logger.error(daoException, daoException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
            }
             catch (Exception exp) {
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
                logger.error("Exception occured: " , exp);
            }

          
 	       outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("DigitalCertificateC11FormService Method Ends ");
        return outParam;
    }
    
    /*private String getSNFromPKCS7(String pkcs7Data) {
        PKCS7CertificateExtractor certificateExtractor = new PKCS7CertificateExtractor(Base64.decodeBase64(pkcs7Data));
        Certificate[] certificates = certificateExtractor.extract();
        String serialNumber = getSNFromCertificate(certificates[0]);
        logger.info("Serial Number ----->" + serialNumber);
        return serialNumber;
    }
    private String getSNFromCertificate(Certificate certificate) {
        X509Certificate x509Certificate = (X509Certificate) certificate;
        String serialNumber = x509Certificate.getSerialNumber().toString();
        return serialNumber;
    }*/

	public void setDigitalCertificateDAOImpl(
			DigitalCertificateDAO digitalCertificateDAOImpl) {
		this.digitalCertificateDAOImpl = digitalCertificateDAOImpl;
	}

 }
