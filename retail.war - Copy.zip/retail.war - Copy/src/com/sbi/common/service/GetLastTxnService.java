
/*
 * GetLastTxnService.java
 * Created on Feb 2, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 2, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.service;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.LoggingConstants;
public class GetLastTxnService extends BaseService
{
    protected final Logger logger = Logger.getLogger(getClass());

    private UserDAO userDAOImpl;
    
    public Map execute(Map inputParams) {
    
    logger.info("execute(Map inputParams) "+LoggingConstants.METHODBEGIN);
    if (logger.isDebugEnabled())
    logger.debug("inputparams Map:" + inputParams);
    Map outParams = new HashMap();
    UserProfile profile = null;
    SBIApplicationResponse response = new SBIApplicationResponse();
    response.setErrorStatus(ServiceConstant.FAILURE);
    String userName = (String) inputParams.get(ServiceConstant.USER_NAME);

    if (userName != null ) {
        try {
            profile = userDAOImpl.findUserProfile(userName);
            if (profile != null) {
                    String lastTransaction= profile.getLastTnameInternet();
                    Timestamp lastTxnDate = profile.getLastTDateInternet();
                    logger.info("lastTransaction"+lastTransaction);
                    outParams.put(ServiceConstant.LAST_TXN,lastTransaction);
                    outParams.put(ServiceConstant.LAST_TXN_DATE,lastTxnDate);
                    response.setErrorStatus(ServiceConstant.SUCCESS);
                } else { // profile null
                    response.setErrorCode(ServiceErrorConstants.SE007);
                        }
         } catch (DAOException appexp) {
            logger.error(LoggingConstants.EXCEPTION,appexp);
            
            response.setErrorCode(appexp.getErrorCode());
            response.setErrorStatus(ServiceConstant.FAILURE);

        } catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION,exp);
            
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }
     }else{
        response.setErrorCode(ServiceErrorConstants.SE002);
     }
    outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
    if (logger.isDebugEnabled())
    logger.debug("outParams Map contains: " + outParams);
    logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
    
    return outParams;
  }

    /**
     * @param userDAOImpl The userDAOImpl to set.
     */
    public void setUserDAOImpl(UserDAO userDAOImpl)
    {
        this.userDAOImpl = userDAOImpl;
    }
}
