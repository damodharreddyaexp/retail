/*
 * GetAccountService.java
 * Created on Nov 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History 
//Nov 26, 2005 Sairam.T - Initial Creation
//Feb 01, 2006 RAMAKRISHNAREDDY - Logger changes
package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.AssociateBankAccountsFilter;

import org.apache.log4j.Logger;
/**
 * This class used for to display the AccountInformation
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class GetAccountService extends BaseService {

    protected final Logger logger = Logger.getLogger(getClass());

    private AccountDAO accountDAOImpl;

    List accounts = new ArrayList();

    /**
     * call the [accountDAOImpl.findAccounts(String userName, String[]
     * productType,Integer accessLevel )] return Map which is contains List
     * Accounts
     * 
     * @param inputParams
     * @return Map
     * 
     */
    public Map execute(Map inputParams) {
        logger.info("execute(Map inputParams) method begin " + LoggingConstants.METHODBEGIN);
        Map accountList = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        String[] productType = (String[]) inputParams.get(ServiceConstant.PRODUCT_TYPE);
        Integer accessLevel = new Integer((String) inputParams.get(ServiceConstant.ACCESS_LEVEL));
        String bankSystem = (String) inputParams.get(ServiceConstant.BANK_SYSTEM);
        String bankCode = (String) inputParams.get("bankCode");
        //if (logger.isDebugEnabled()) {
            logger.info("Input parameter userName " + userName);
            logger.info("Input parameter productType " + productType);
            logger.info("Input parameter accessLevel " + accessLevel);
            logger.info("Input parameter bankCode " + bankCode);
        //}
        try {
            if (userName != null ) {
                accounts = accountDAOImpl.findAccounts(userName, productType, accessLevel);
                

                if (accounts != null &&  accounts.size() > 0  &&  bankSystem != null ) {
                    accounts =  accountsFilter(accounts,bankSystem);
                       if(accounts != null && accounts.size() > 0 )
                       {  
						// for Associate Bank Core account filter
                    	logger.info("accounts List before filter: " + accounts.size() );
                    	accounts = AssociateBankAccountsFilter.associateBankAccounts(bankCode,accounts);
                    	
                    	 if(accounts != null) {
                    			
                    		logger.info("accounts List after filter : " + accounts.size() );
                    		 accountList.put(ServiceConstant.CREDIT_ACCOUNT, accounts);
                             response.setErrorStatus(ServiceConstant.SUCCESS);
                    		
                    	}else {
                    		
                    		response.setErrorCode(ServiceErrorConstants.SE001);
                    		response.setErrorStatus(ServiceConstant.FAILURE);
                    	}

                       }
                       else
                       {
                           response.setErrorCode(ServiceErrorConstants.SE001);
                       }
                }    
                else {
                    response.setErrorCode(ServiceErrorConstants.SE001);
                  }
            }
            else {
                if (logger.isDebugEnabled())
                    logger.debug("input parameter user Name " + userName);
                response.setErrorCode(ServiceErrorConstants.SE004);
            }
        }
        catch (DAOException daoExp) {
            logger.error("accountDAOImpl.findAccounts method throws Exception :" + daoExp.toString());
            SBIApplicationException exception = new SBIApplicationException(daoExp.getMessage());
            throw exception;
        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error("Exception occured: " + exp);
        }
        accountList.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams) method end" + LoggingConstants.METHODEND);
        return accountList;

    }

    /**
     * TODO This method is using for filter the accounts based upon bankSystem
     * to given List account;
     * 
     * @param accountList
     * @param bankSystem
     * @return List
     */
    private List accountsFilter(List accountList, String bankSystem) {

        logger.info("Account List before filtering: " + accountList.size());
        
        if(bankSystem.equalsIgnoreCase("all") )
        {
            return accountList;
        }
        else
        {
        for (Iterator iterator = accountList.iterator(); iterator.hasNext();) {

            Account account = (Account) iterator.next();
            System.out.println("Bank System " + account.getBankSystem());
            if (!account.getBankSystem().equalsIgnoreCase(bankSystem)) {
                iterator.remove();
            }      }
        logger.info("Account List after filtering: " + accountList.size());
        return accountList;
        }
        }

    /**
     * AccountDAOImpl object injection done here
     * 
     * @param accountDAOImpl
     * 
     */
    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

}
