package com.sbi.common.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompBenViewFileDisplayService extends BaseService {
	
	protected static Logger logger = Logger.getLogger(CompBenViewFileDisplayService.class);
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		logger.info("execute(Map inParams)"+ LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inParams.get("userName");
			String corporateID = (String)inParams.get("coporateID");
			String functionType = (String)inParams.get("functionType");
			List<CorporateFile> ben3PFileList = new ArrayList<CorporateFile>();
			List<CorporateFile> benIBTPFileList = new ArrayList<CorporateFile>();
			List<CorporateFile> benD3PFileList = new ArrayList<CorporateFile>();
			List<CorporateFile> benDIBTPFileList = new ArrayList<CorporateFile>();
			List<CorporateFile> benCompFileList = new ArrayList<CorporateFile>();
			List<CorporateFile> benFileList = new ArrayList<CorporateFile>(); 
			
			String uploaderName = (String) inParams.get("uploaderName");
			String benFileType = (String) inParams.get("benFileType");
			Integer userRole=(Integer)inParams.get("userRole");
	        
			if("getUploader".equals(functionType)) {
				
				List uploaderList = null;
				if(userName != null  && corporateID != null &&  !"".equalsIgnoreCase(corporateID.trim())){
					uploaderList = compBenFileDAOImpl.findUploader(userName,corporateID);
					if(uploaderList!=null && uploaderList.size()>0){
	 					outParams.put("uploaderList",uploaderList);
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}
					else {
						response.setErrorCode("BEN001");
					}
				}else{
					response.setErrorCode("SE010");
				}
			}else if("getPendingFiles".equals(functionType)) {
				
				if (userName != null && userName.trim().length() > 0 && uploaderName  != null  && benFileType != null) {
	                   
					if(!"ABTP".equals(benFileType)){	
					//Added for fetching 3p beneficiary files
					ben3PFileList = compBenFileDAOImpl.viewTPFiles(userName,uploaderName);
					if(ben3PFileList!=null && ben3PFileList.size()>0)   
						benFileList.addAll(ben3PFileList);
					
					//Added for fetching ibtp beneficiary files 
					benIBTPFileList = compBenFileDAOImpl.viewTPInterFiles(userName,uploaderName);
					if(benIBTPFileList!=null && benIBTPFileList.size()>0)
						benFileList.addAll(benIBTPFileList);
					
					//Added for fetching d3p beneficiary files
					benD3PFileList = compBenFileDAOImpl.viewTPDelFiles(userName,uploaderName);
					if(benD3PFileList!=null && benD3PFileList.size()>0)
						benFileList.addAll(benD3PFileList);
	                
					
	                //Added for fetching dibtp beneficiary files -Start
	                benDIBTPFileList = compBenFileDAOImpl.viewDIBTPFiles(userName,uploaderName);
					if(benDIBTPFileList!=null && benDIBTPFileList.size()>0)
						benFileList.addAll(benDIBTPFileList);
					}
					
	                //Added for fetching composite beneficiary files -Start
					benCompFileList = compBenFileDAOImpl.viewCompBenFiles(corporateID,userName,uploaderName,benFileType);
					if(benCompFileList!=null && benCompFileList.size()>0)
						benFileList.addAll(benCompFileList);
					
					//Added for fetching sftp uploader uploaded  beneficiary files
					if(userRole == 7 )
					{
						benCompFileList = compBenFileDAOImpl.viewAdminSftpBenFiles(corporateID, userName, uploaderName,benFileType);
						if(benCompFileList!=null && benCompFileList.size()>0)
							benFileList.addAll(benCompFileList);
					}/*else if (userRole == 10 ){
						benCompFileList = compBenFileDAOImpl.viewRegSftpBenFiles(corporateID, userName, uploaderName);
						if(benCompFileList!=null && benCompFileList.size()>0)
							benFileList.addAll(benCompFileList);
					}*/
					
					
	                if (benFileList!=null && benFileList.size()>0) {
	                	Collections.sort(benFileList, BenFileComparator);
	                	outParams.put("benFileList", benFileList);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					}
					else {
						response.setErrorCode("BEN010");
					}
						
				} else {
					response.setErrorCode("BEN007");
				}
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)"+ LoggingConstants.METHODEND);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}
	
	public static Comparator<CorporateFile> BenFileComparator 
    = new Comparator<CorporateFile>() {

		public int compare(CorporateFile corporateFile1, CorporateFile corporateFile2) {
		
			Date date1 = corporateFile1.getUploadedDate();
			Date date2 = corporateFile2.getUploadedDate();
			
			//ascending order
			//return date1.compareTo(date2);
			
			//descending order
			return date2.compareTo(date1);
		}
	
	};

	
}
