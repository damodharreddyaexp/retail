/* 
 * AddDDBeneficiaryService.java
 * Created on  Mar 18, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 18, 2006 Asit - Initial Creation and Method implementation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;


import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.dao.ThirdPartyDAO;
import com.sbi.common.model.CorporateFile;
import org.apache.log4j.Logger;

public class ApproveTPDelFileService extends BaseService{
    
    private ThirdPartyDAO thirdPartyDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    
     /**
     * call the [thirdPartyDAOImpl.findTPDelFiles(userName)] to get the ApproveDel file Names 
     * return Map which is contains AprovedDelTpFile Information.
     * 
     * @param inputParams
     * @return Map
     * 
     */
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        String userName;

        Map outParam = new HashMap();

        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);

        userName = (String) inputParam.get(ServiceConstant.USER_NAME);
        //Added by Sunjay S Galen
        String startDate = (String)inputParam.get("startDate");       
        String endDate = (String)inputParam.get("endDate");
        String functionType = (String)inputParam.get("functionType");
        Integer userRole=(Integer)inputParam.get("userRole");
        logger.info("functionType::"+functionType);
       logger.info("userName >>>>" + userName);
       
    
        CorporateFile[] corporateFile;

        try {

            if (functionType.equalsIgnoreCase("approve"))
            {
            if (userName != null && !userName.trim().equals(ServiceConstant.EMPTY) ) 
                    {

                corporateFile = thirdPartyDAOImpl.findTPDelFiles(userName,startDate,endDate,userRole);
                
                if (corporateFile != null && corporateFile.length >0) {
                    outParam.put("approveTPDelFileDetails",corporateFile);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                } else {
                    response.setErrorCode(ServiceErrorConstants.CSE016);
                }
   
            }

            else {
                response.setErrorStatus(ServiceErrorConstants.CR002);
            }
            }
            //Added by Sunjay S Galen
            else 
            {
                if (!functionType.equalsIgnoreCase("approve"))
                {
                if (userName != null && !userName.trim().equals(ServiceConstant.EMPTY)) {

                    corporateFile = thirdPartyDAOImpl.findTPDelFilesView(userName,startDate,endDate,userRole);
                    
                    if (corporateFile != null && corporateFile.length >0) {
                        outParam.put("approveTPDelFileDetails",corporateFile);
                                       
                        response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    } else {
                        response.setErrorCode(ServiceErrorConstants.CSE016);
                    }
       
                } 
                
                else {
                    response.setErrorStatus(ServiceErrorConstants.CR002);
                }
                }
            }
        } catch (SBIApplicationException appex) {
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("outParam :" + outParam);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);

        return outParam;

    }


    public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl)
    {
        this.thirdPartyDAOImpl = thirdPartyDAOImpl;
    }

     /**
     * TODO ThirdPartyDAOImpl  injection done here
     * @param thirdPartyDAOImpl void
     */
    
  


    

}
