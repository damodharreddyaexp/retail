package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DebitTransactionDetailsDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;

public class DebitTransactionDetailsService extends BaseService{
	
	private DebitTransactionDetailsDAO debitTransactionDetailsDAOImpl;
	
	protected final Logger logger = Logger.getLogger(getClass());
	public Map execute(Map inparams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);

		Map getCreditMap = new HashMap();
		Map outParams = new HashMap();
		List getdebitlist = new ArrayList();
		CorpTransactionLeg corpTxLeg = new CorpTransactionLeg();
		String echequeNo = null;
		try{
			echequeNo = (String) inparams.get("referenceNo");
			if(echequeNo != null){
				corpTxLeg = debitTransactionDetailsDAOImpl.getEcheque(echequeNo);
				if(corpTxLeg!=null){
						if(corpTxLeg.getEchequeNo().substring(0, 2).equalsIgnoreCase(UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME) 
								|| corpTxLeg.getEchequeNo().substring(0, 2).equalsIgnoreCase(UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME)
								|| corpTxLeg.getEchequeNo().substring(0, 2).equalsIgnoreCase(UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME)//Added for GRPT
								|| corpTxLeg.getEchequeNo().substring(0, 2).equalsIgnoreCase("CD")) {
									double echequeAmount = corpTxLeg.getAmount().doubleValue();
									double commAmount= 0;
									  
									if( corpTxLeg.getRateOfInterest()!=null)
										commAmount= new Double(corpTxLeg.getRateOfInterest()).doubleValue();
									double totalDebit = echequeAmount+commAmount;
								
									outParams.put("totalDebitAmount",new Double(totalDebit));
									outParams.put("commissionAmount",new Double(commAmount));
						}else{
							outParams.put("totalDebitAmount",new Double(corpTxLeg.getAmount().doubleValue()));
						}
						outParams.put("debitcorptran", corpTxLeg);
				}else{
					response.setErrorCode("DTD002"); 
				}
			}else {
				logger.info("Input values are null");
				response.setErrorCode("DTD001"); 
			}
		}catch (SBIApplicationException ex) {
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode(ex.getErrorCode());
		} catch (DAOException ex) {
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode(ex.getErrorCode());
		} catch (Exception ex) {
			ex.printStackTrace();	
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode("CIRS040");
		}
		response.setErrorStatus(ServiceConstant.SUCCESS);
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		
		logger.info("response.getErrorCode():: " + response.getErrorCode() );
		return outParams;
	}
	public void setDebitTransactionDetailsDAOImpl(
			DebitTransactionDetailsDAO debitTransactionDetailsDAOImpl) {
		this.debitTransactionDetailsDAOImpl = debitTransactionDetailsDAOImpl;
	}
}
