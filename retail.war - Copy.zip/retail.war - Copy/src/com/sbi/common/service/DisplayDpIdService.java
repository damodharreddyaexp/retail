
/*
 * DisplayDPService.java
 * Created on Aug 9, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 9, 2006 Viiveek � Initial Creation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.DematDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.DematUtils;

public class DisplayDpIdService extends BaseService{
    private final Logger logger=Logger.getLogger(getClass());
    private SBIApplicationResponse response=new SBIApplicationResponse();
    private DematDAO dematDAOImpl;
    private DematUtils dematUtils;
    
	Map outParams=new HashMap();
    public Map execute(Map inputParams){    	
        response.setErrorStatus(ServiceConstant.FAILURE);
        try{
        	 
            if(inputParams!=null && inputParams.size()>0){
            	List dpList = null;
            	List ebrokingList = null;
            	String dematagent = (String) inputParams.get("dematagent"); 
            	if("SSL".equalsIgnoreCase(dematagent)){
            		ebrokingList=dematDAOImpl.getSSLeBrokingIds(inputParams.get(ServiceConstant.USER_NAME).toString());
            		if(ebrokingList!=null){
            			dpList=dematUtils.getDpIds(ebrokingList);
            		}
            	}else{
            		dpList=dematDAOImpl.getDpIds(inputParams.get(ServiceConstant.USER_NAME).toString());
            	}
            	 String nreCheck = (String) inputParams.get("NRE_LOGIN");
                 if (nreCheck == null){
            	String NRIAccountType = dematDAOImpl.getNRIAccountsAvailability(inputParams.get(ServiceConstant.USER_NAME).toString());
                // to get the NRI PIS accounts availability and set it in session.
	            	if (NRIAccountType != null && NRIAccountType.length() >0){
	            		logger.info("NRIAccountType :"+NRIAccountType);
	            		outParams.put("NRIAccountType",NRIAccountType);
	            	}
                 }
				if(dpList != null && dpList.size() >0){
					logger.info("dpList size"+dpList.size());
					outParams.put("dpIds",dpList);
	                outParams.put("DEMAT_ACCT","YES");
	                response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				}else{					
					response.setErrorCode("V113");
				}
				
            }
            else
                response.setErrorCode(ServiceErrorConstants.SE003);
        }catch (DAOException daoException) {
            response.setErrorCode(daoException.getErrorCode());
        }catch (Exception exception) {
            response.setErrorCode(ServiceErrorConstants.SE002);;
        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);        
        return outParams;
    }
	/**
	 * @param dematDAOImpl The dematDAOImpl to set.
	 */
	public void setDematDAOImpl(DematDAO dematDAOImpl) {
		this.dematDAOImpl = dematDAOImpl;
	}
	public void setDematUtils(DematUtils dematUtils) {
		this.dematUtils = dematUtils;
	}
}
