package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DigitalCertificateDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;


public class DeactivationDSCConfirmService extends BaseService {
    
	private DigitalCertificateDAO digitalCertificateDAOImpl;

   

	protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {

        logger.info("DeactivationDSCConfirmService Method Starts ");

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        Map outParam = new HashMap();
        String userName = (String)inputParams.get("userName");
        String referenceNo =(String)inputParams.get("referenceNo");
        String mobileNo =(String)inputParams.get("mobileNo");
      
      //  String serialNo= (String)inputParams.get("serialNo");
      //  String securityOption= (String) inputParams.get("securityOption");
        
        logger.info("userName ::"+userName);
        logger.info("referenceNo ::"+referenceNo);
     
        
       // DSCDetails dscDetails=null;
        
       // String digitalErrorCode ="";
      //  String certificateMsg="";
      //  String verifymsg="";
        boolean deactivateFlag= false;
         try {
       
        	 if(mobileNo==null || "".equals(mobileNo.trim())) {
     			logger.info("mobile no is empty error");
     			response.setErrorCode("DSC009");
 			 }else {
        	 
        	 
            	if(userName != null && referenceNo != null && !referenceNo.equals("") && !userName.equals("")){
            		
        			deactivateFlag = digitalCertificateDAOImpl.getDeactivationDSCertificate(userName,referenceNo);
            		
            	
            	if(deactivateFlag){
            		logger.info("deactivateFlag >if>>>"+deactivateFlag);
            	   outParam.put("deactivateFlag", deactivateFlag);
            	   response.setErrorStatus(ServiceConstant.SUCCESS); 
            	}else{
            		logger.info("deactivateFlag >else>>>"+deactivateFlag);
            	   response.setErrorCode("DSR005");
            	   response.setErrorStatus(ServiceErrorConstants.FAILURE);
            	}
            	}else{
            		response.setErrorCode(ServiceErrorConstants.RM001);
            	}
           
 			 }  
          }catch (SBIApplicationException sbiApplicationException) {
                logger.error(sbiApplicationException, sbiApplicationException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(sbiApplicationException.getErrorCode());

            }
            catch (DAOException daoException) {

                logger.error(daoException, daoException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
            }
             catch (Exception exp) {
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
                logger.error("Exception occured: " , exp);
            }

          
 	        outParam.put("deactivateFlag", deactivateFlag);	
 	        

 	       outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("DeactivationDSCConfirmService Method Ends ");
        return outParam;
    }
    
  /*  private String getSNFromPKCS7(String pkcs7Data) {
        PKCS7CertificateExtractor certificateExtractor = new PKCS7CertificateExtractor(Base64.decodeBase64(pkcs7Data));
        Certificate[] certificates = certificateExtractor.extract();
        String serialNumber = getSNFromCertificate(certificates[0]);
        logger.info("Serial Number ----->" + serialNumber);
        return serialNumber;
    }
    private String getSNFromCertificate(Certificate certificate) {
        X509Certificate x509Certificate = (X509Certificate) certificate;
        String serialNumber = x509Certificate.getSerialNumber().toString();
        return serialNumber;
    }
    */
    
   
	public void setDigitalCertificateDAOImpl(
			DigitalCertificateDAO digitalCertificateDAOImpl) {
		this.digitalCertificateDAOImpl = digitalCertificateDAOImpl;
	}

 }
