package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.bp.AddCorpRolesBP;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.UIConstant;
import com.sbi.common.model.Address;
import com.sbi.common.model.C9UserProfile;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.service.ServiceErrorConstants;
  
public class AddCorpRolesConfirmService extends BaseService {
	protected final Logger logger = Logger.getLogger(getClass());
	private AddCorpRolesBP addCorpRolesBP;
    public AddCorpRolesBP getAddCorpRolesBP() {
		return addCorpRolesBP;
	}

	private UserDAO userDAOImpl;
	private Map rolesMap;
	  
	public Map execute(Map inputParams)
	{
		logger.info("execute(Map inputParams)"+LoggingConstants.METHODBEGIN);
		UserProfile userProfile;
		SBIApplicationResponse response;		
	    Map outParams = new HashMap() ;		
		response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String)inputParams.get("userName");////for search by employee number
        String[] userType = (String[])inputParams.get("userType");        
        int smallFlag = ((Integer)inputParams.get("smallFlag")).intValue()  ;
        int userProfileType = 0;     
        String corporateType =(String) inputParams.get("corporateType");  
        String ppkits=(String)inputParams.get("ppkits");
        String roleType=(String)inputParams.get("roleType");
        String role=(String)rolesMap.get(roleType);        
        String accRights = (String)inputParams.get("accRights");
        String oldempno = (String)inputParams.get("oldempno");
        //Only for Corp User
        if(userType!=null){ 
        	if(userType.length == 2){
        		roleType = "corpddebituser";
        	}else if(userType.length==1){
        		if( userType[0].equalsIgnoreCase("corpuser"))
        			accRights = "";
        		roleType = userType[0];
        	}
        	
    	}else
    		accRights = "";
        String address2="";
        Address address=new Address();
        if(inputParams.get(ServiceConstant.ADDRESS2)!=null)
        	address2=(String)inputParams.get(ServiceConstant.ADDRESS2);
        address.setAddress1((String)inputParams.get(ServiceConstant.ADDRESS1) + ", " + address2);
        address.setCity((String)inputParams.get(ServiceConstant.CITY));
        address.setState((String)inputParams.get(ServiceConstant.STATE));
        address.setCountry((String)inputParams.get(ServiceConstant.COUNTRY));
        address.setPin((String)inputParams.get(ServiceConstant.ZIP));

        logger.info("role :" + role);
        logger.info("address :" + address);
        logger.info("userType : " + roleType);
        logger.info("accRights :" + accRights);
        userProfile=new UserProfile();
        userProfile.setDistrict((String)inputParams.get(ServiceConstant.DISTRICT));
        userProfile.setEmpNo((String)inputParams.get("empno"));
        userProfile.setName((String)inputParams.get(ServiceConstant.NAME));
        userProfile.setAddress(address);
        userProfile.setEmail((String)inputParams.get(ServiceConstant.EMAIL));
        userProfile.setHomePhone((String)inputParams.get(ServiceConstant.HOME_PHONE));
        userProfile.setCorporateId((String)inputParams.get(ServiceConstant.CORPORATE_ID));
        userProfile.setBranchCode(inputParams.get("branchCode").toString());
        userProfile.setDesignation((String)inputParams.get("designation"));
        userProfile.setDepartment((String)inputParams.get("department"));
        
        //Added By Amar for Mobile Number Registeration
        userProfile.setMobileNumber((String)inputParams.get("mobileno"));
        
        userProfile.setBankCode(inputParams.get("bankCode").toString());
        userProfile.setCreatedBy(inputParams.get(ServiceConstant.CREATED_BY).toString());
        userProfile.setSource((String)inputParams.get("source"));
        userProfile.setTypeOfUser(roleType);
        userProfile.setUserAlias(userName);
        //Added for mobile Registration Phase 2 
        /*if( roleType.equalsIgnoreCase("CorpUser") || roleType.equalsIgnoreCase("Approver"))
        	userProfile.setSmsSecurity(new Integer((String)inputParams.get("smsSecurity")));
        else {
        */
//        Integer smsSecurity=null;
//        userProfile.setSmsSecurity(smsSecurity);
        String smsSecurity = (String)inputParams.get("smsSecurity");
        if(smsSecurity != null && !"".equals(smsSecurity)){
        	userProfile.setSmsSecurity(new Integer(smsSecurity));
        }
        
        logger.info("SMSSECURITY::"+ userProfile.getSmsSecurity());
        // }  Added for mobile Registration Phase 2  ENDS
        logger.info("userProfile for archana " + userProfile);
        if(oldempno!=null)
        	userProfile.setEmpNo(oldempno);			   
		   
        try{   
        		if (logger.isDebugEnabled()) {
                    logger.debug("userProfile " + userProfile);
                }
        		boolean dulicateFlag;
        		if(roleType.equalsIgnoreCase("superenquirer"))
        			dulicateFlag=addCorpRolesBP.userExists(userProfile.getEmpNo(),userProfile.getCorporateId());
        		else
        			dulicateFlag=addCorpRolesBP.userExists(userProfile.getEmpNo(), role, userProfile.getCreatedBy(), userProfile.getCorporateId());
         	   if(!dulicateFlag){
         		   if(oldempno!=null)
         			   role="800";
                if(ppkits!= null && ppkits.equalsIgnoreCase("Yes")){
                	outParams=addCorpRolesBP.addUserPrePrintKit(userProfile,role);
                	
                	//Added By Amar for Mobile Number Registeration
                	String pp_id=(String) outParams.get("pp_id");
                	addCorpRolesBP.insertMobileDetailsPPKit(userProfile,role,pp_id);
            		//C9UserProfile c9userProfile=new C9UserProfile();
                	//c9userProfile = (C9UserProfile) outParams.get("userProfile");
                	outParams.put("c9userProfile", userProfile);
                	response.setErrorStatus(ServiceConstant.SUCCESS);
                }
                else {
                	userProfile = addCorpRolesBP.addUser(userProfile,role);
                	User user=userDAOImpl.findUser(userProfile.getUserName().toString());
                   	addCorpRolesBP.insertMobileDetails(userProfile,role,user.getUserId().toString());
                   	outParams.put("c9userProfile",userProfile);
                	                	
	                if(userProfile!=null){
	                	if(roleType.equalsIgnoreCase("corpuser")||roleType.equalsIgnoreCase("ddebituser")||roleType.equalsIgnoreCase("corpddebituser")){
	                		                      
                            if(roleType.equals("ddebituser")){                           	 
                           	 userProfileType = 1;
                           	 logger.info("ddebituser");
                            }
                            if(smallFlag==2){
                           	 //userProfileType = 3;
                            	userProfileType = 0;
                           	 logger.info("khata plus user");
                            }                            
                            if(corporateType!= null && corporateType.equalsIgnoreCase("BANK")){
                           	 userProfileType = 5;
                           	 logger.info("NAB User");
                            }
                            if(corporateType!= null && corporateType.equalsIgnoreCase("CPSMS")){//Added for CPSMS
                              	 userProfileType = 8;
                              	 logger.info("CPSMS User");
                               }
							//Added for Raksha-IRCTC Corporate - Start
                            if(corporateType!= null && UIConstant.RAKSHA_CORPORATE.equalsIgnoreCase(corporateType)){//Added for CPSMS
                             	 userProfileType = 9;
                             	 logger.info("raksha User");
                              }
							//Added for Raksha-IRCTC Corporate - End
                            addCorpRolesBP.updateUserType(userProfile.getUserName(), userProfileType);
	                	}
	        			outParams.put(ServiceConstant.USER_DETAILS,userProfile);
	        			response.setErrorStatus(ServiceConstant.SUCCESS);
	        		}else
	        			response.setErrorCode("CR014");                   
		                
                }
         	   }
         	   else
         		  response.setErrorCode("CR018");
            
        }catch (SBIApplicationException appex) {
        	logger.error(LoggingConstants.EXCEPTION + appex);
                response.setErrorCode(appex.getErrorCode());
        }catch (Exception exp) {
                response.setErrorCode(ServiceErrorConstants.SE002);
                logger.error(LoggingConstants.EXCEPTION + exp);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Error status : " + response.getErrorStatus());;
        }
        
        outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams)"+LoggingConstants.METHODEND);
		return outParams;
       
      }


	public void setAddCorpRolesBP(AddCorpRolesBP addCorpRolesBP) {
		this.addCorpRolesBP = addCorpRolesBP;
	}


	public void setRolesMap(Map rolesMap) {
		this.rolesMap = rolesMap;
	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}



  }

