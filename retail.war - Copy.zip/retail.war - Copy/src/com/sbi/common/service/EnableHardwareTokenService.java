package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.EnableHardwareTokenDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.model.HardwareTokenDetails;

public class EnableHardwareTokenService extends BaseService{
	protected final Logger logger = Logger.getLogger(getClass());	
	 private EnableHardwareTokenDAO enableHardwareTokenDAOImpl; 
	 

	public Map execute(Map inputParam) {
		 
		   logger.info("execute(Map inputParam))" + LoggingConstants.METHODBEGIN);
	        Map outParam = new HashMap();
	        SBIApplicationResponse response = new SBIApplicationResponse();
	        response.setErrorStatus(ServiceConstant.FAILURE);      
	        HardwareTokenDetails hardwareTokenDetails = null ;
	        Integer userId = null;
	        userId =  (Integer) inputParam.get("userId");
			String branchCode=(String)inputParam.get("branchCode");
			int userRole =(Integer)inputParam.get("userRole");
			String corporateId =(String) inputParam.get("corporateId");
			String userAlias = (String)inputParam.get("userAlias");
			String friendlyName = (String)inputParam.get("friendlyName");
			
			
			try{
			 if(userId !=null && userAlias != null){
				if(userRole == 10 || userRole==7 || userRole==21 || userRole==42 || userRole==8){
					hardwareTokenDetails =	enableHardwareTokenDAOImpl.insertUserDetails(userId,branchCode,userRole,corporateId,userAlias,friendlyName);
				  response.setErrorStatus(ServiceConstant.SUCCESS); 
				}else{
					response.setErrorCode(ServiceErrorConstants.RM002);
				}
			}else{
				
					response.setErrorCode(ServiceErrorConstants.RM001);
			}
			}catch(DAOException exp){
				logger.info("exp.getErrorCode()-->"+exp.getErrorCode());
				response.setErrorCode(exp.getErrorCode());
			}catch(Exception e){
				logger.info("Exception:", e);
				response.setErrorCode("SE002");
				
			}
			outParam.put(ServiceConstant.APPLICATION_RESPONSE,response);
	        outParam.put("hardwareTokenDetails", hardwareTokenDetails);	
	        logger.info("Map execute(Map inputParams)"+LoggingConstants.METHODEND);	
		 return outParam;
	 }



	public void setEnableHardwareTokenDAOImpl(
			EnableHardwareTokenDAO enableHardwareTokenDAOImpl) {
		this.enableHardwareTokenDAOImpl = enableHardwareTokenDAOImpl;
	}
	
	

}
