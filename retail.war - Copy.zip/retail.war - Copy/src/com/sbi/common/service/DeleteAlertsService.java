
/*
 * DeleteAlertsService.java
 * Created on Jan 3, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 3, 2006 KRISHNA KUMAR - Initial Creation
//Jan 31, 2006 MURUGAN K  - log changes

/**
 * @(#) DeleteAlertsService.java
 */
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.SMSAlertDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.SMSAlertSpec;
import com.sbi.common.utils.LoggingConstants;

public class DeleteAlertsService extends BaseService
{
    protected final Logger logger = Logger.getLogger(getClass());
    private SMSAlertDAO smsAlertDAOImpl;
    
    public Map execute(Map inputParams) {
        logger.info("execute()" + LoggingConstants.METHODBEGIN);
        String userName =(String) inputParams.get(ServiceConstant.USER_NAME);
        String nickName  = (String) inputParams.get(ServiceConstant.NICK_NAME);
        String alertName = (String)inputParams.get(ServiceConstant.ALERT_NAME );
        Integer alertID = new Integer((String)inputParams.get(ServiceConstant.ALERT_ID));
        Map map = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus( ServiceErrorConstants.FAILURE );
        //boolean flag = false;
        
        try{
            if(userName != null && nickName != null && alertName != null){
                SMSAlertSpec smsAlert = smsAlertDAOImpl.deleteAlertSpec(userName,nickName,alertName,alertID);
        
                if(smsAlert != null){
                	map.put(ServiceConstant.SMS_MODEL,smsAlert);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                }else{
                	response.setErrorCode(ServiceErrorConstants.SE002);
                }
            }
        }catch (SBIApplicationException appexp) {
            logger.error(LoggingConstants.EXCEPTION, appexp);
            response.setErrorCode(appexp.getErrorCode());

        }
        catch (DAOException doaExp) {
            response.setErrorCode(doaExp.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION,  doaExp);

        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION,  exp);

        }
        map.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("Map execute(Map inputParams) method end");
        return map;
    }

    /**
     * @param smsAlertDAOImpl The smsAlertDAOImpl to set.
     */
    public void setSmsAlertDAOImpl(SMSAlertDAO smsAlertDAOImpl)
    {
        this.smsAlertDAOImpl = smsAlertDAOImpl;
    }
    
}

