package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CompBenDataModel;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompBenViewRecordDisplayService extends BaseService {
	
	protected static Logger logger = Logger.getLogger(CompBenViewRecordDisplayService.class);
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		logger.info("execute(Map inParams)" + LoggingConstants.METHODBEGIN);
		
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inParams.get("userName");
			String corporateId = (String)inParams.get("coporateId");
			String fileName = (String)inParams.get("fileName");
			String fileType = (String) inParams.get("fileType");
			String specificFileType = (String) inParams.get("specificFileType");
			String uploaderName = (String) inParams.get("uploaderName");
			int categoryCount=0;
			
			CompBenDataModel[] compBenDataModel=null;
			
			int index = fileName.indexOf('.');
			String fName = fileName.substring(0, index);
			
			if(userName != null  && corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim()) && fileName != null && fileType != null && !fileName.trim().equals(ServiceConstant.EMPTY) ){
				
				if("COMPOSITE_BEN".equalsIgnoreCase(fileType)  || "ABTP".equalsIgnoreCase(fileType)) {
					
					compBenDataModel = compBenFileDAOImpl.findCompViewBenRecDisplay(fName,userName,corporateId,specificFileType,uploaderName);
					if(compBenDataModel != null && compBenDataModel.length > 0){
						outParams.put("approveBenRecordDetails", compBenDataModel);
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}
					else {
						response.setErrorCode("BEN007");
					}
				}
				else if("validationFailure".equalsIgnoreCase(fileType)  || "validationFailure_aadhar".equalsIgnoreCase(fileType)) {
					compBenDataModel = compBenFileDAOImpl.findCompViewBenRecDisplay(fName,userName,corporateId,specificFileType,uploaderName);
					if(compBenDataModel != null && compBenDataModel.length > 0){
						outParams.put("approveBenRecordDetails", compBenDataModel);
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}
					else {
						response.setErrorCode("BEN007");
					}
				}
				else {
				    compBenDataModel = compBenFileDAOImpl.findViewBenRecDisplay(fName,userName,corporateId,fileType);
					if(compBenDataModel != null && compBenDataModel.length > 0){
						outParams.put("approveBenRecordDetails", compBenDataModel);
						response.setErrorStatus(ServiceConstant.SUCCESS);
					}
					else {
						response.setErrorCode("BEN007");
					}
				}
				outParams.put("fileType",fileType);
				outParams.put("fileName",fileName);
				if(compBenDataModel!=null) {
					categoryCount=compBenDataModel.length;
				}
				outParams.put("categoryCount",categoryCount);
			
      		}
			else{
				response.setErrorCode("SE010");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}

	
	
	
}
