/*
 * GetFavoriteNameServcie.java
 * Created on Jan 10, 2006
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 10, 2006 MURUGAN K - Initial Creation
//Feb 01, 2006 RAMAKRISHNAREDDY - Logger changes
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.FavoritesDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class GetFavoriteNameServcie extends BaseService {
    protected final Logger logger = Logger.getLogger(getClass());

    private FavoritesDAO favoritesDAOImpl;
    
    private static final String FAVORITE_NAMES = "favoriteNames";

    public Map execute(Map inputParams) {
    	logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
       Map  outMap = new HashMap();
          
        Map favoriteMap = new HashMap();

        try {
            if (userName != null) {
                favoriteMap = favoritesDAOImpl.findFavoriteName(userName);

                if (favoriteMap != null) {

                    if (logger.isDebugEnabled()) {
                        logger.debug("FavoriteMap*********** : " + favoriteMap);
                    }
                    response.setErrorStatus(ServiceConstant.SUCCESS);
                }
                else {
                   // response.setErrorCode(ServiceErrorConstants.SE101);
                }
            }
            else {
            	 if (logger.isDebugEnabled())
                logger.debug("input parameter user Name " + userName);
                response.setErrorCode(ServiceErrorConstants.SE003);
            }
        }
        catch (DAOException daoExp) {
            logger.error("accountDAOImpl.findAccounts method throws Exception :" + daoExp.toString());
            SBIApplicationException exception = new SBIApplicationException(daoExp.getMessage());
            throw exception;
        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION, exp);
        }
        outMap.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        outMap.put(FAVORITE_NAMES,favoriteMap);
        if (logger.isDebugEnabled())
        logger.debug("FavoriteMap*********** : " + favoriteMap);
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return outMap;

    }

    public void setFavoritesDAOImpl(FavoritesDAO favoritesDAOImpl) {
        this.favoritesDAOImpl = favoritesDAOImpl;
    }

}
