/*
 * EditAccountService.java
 * Created on Dec 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 21, 2005 MURUGAN K - Initial Creation and Method implementations
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.bp.ProfileBP;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.utils.LoggingConstants;
 
/**
 * TODO This class is using to edit process for Third Partty Accounts
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class EditAccountService extends BaseService {

    private ProfileBP profileBP;

    protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams)

    {
        logger.info("execute()" + LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Integer accountType = (Integer) inputParams.get(ServiceConstant.ACCOUNT_TYPE);
        String userRole  = (String) inputParams.get("corpUser");
        Account updatedAccount=null;
       
        try

        {

              if ( userName != null && accountType != null && accountType.equals(ServiceConstant.THIRD_PARTY)) {
               
                  String thirdPartyName = (String) inputParams.get(ServiceConstant.THIRD_PARTY_NAME);
                  String accountNo = (String) inputParams.get(ServiceConstant.ACCOUNT_NO);
                  String branchCode = (String) inputParams.get(ServiceConstant.BRANCH_CODE);
                  String corpId = (String) inputParams.get(ServiceConstant.CORPORATE_ID);
                  Double transferLimit = new Double((String) inputParams.get(ServiceConstant.TRANSACTION_LIMIT));
                 logger.debug("TransferLimit "  + transferLimit);
                 if (accountNo != null && branchCode != null && thirdPartyName != null && transferLimit != null) {
                    Account account = new Account();
                    account.setAccountNo(accountNo);
                    account.setAccountNickName(thirdPartyName);
                    account.setUserName(userName);
                    account.setBranchCode(branchCode);
                    
                    account.setAccountNature(accountType.toString());
                    
                    if (userRole != null && userRole.equalsIgnoreCase("corpUser") )
                    {
                         updatedAccount = profileBP.editUserAccount(account);  
                    
                    }
                    else if ( transferLimit != null)
                    {
                        account.setBalance(transferLimit);
                        updatedAccount = profileBP.editUserAccount(account);
                    }
                    
                    if (updatedAccount != null) {
                        outParams.put(ServiceConstant.ACCOUNT_DETAILS, updatedAccount);
                        response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    }
                    else {
                        response.setErrorCode(ServiceErrorConstants.SE002);
                    }
                }
                else { 
                  
                    response.setErrorCode(ServiceErrorConstants.SE003);
                }
            }
              
            else {
                response.setErrorCode(ServiceErrorConstants.SE003);
            }

        }
        catch (SBIApplicationException sbiExc) {
            response.setErrorCode(sbiExc.getErrorCode());

            logger.error(LoggingConstants.EXCEPTION,sbiExc);
        }
        catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
        logger.debug("output Map contains :" + outParams);
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODBEGIN);
        return outParams;
    }

    public void setProfileBP(ProfileBP profileBP) {
        this.profileBP = profileBP;
    }

}
