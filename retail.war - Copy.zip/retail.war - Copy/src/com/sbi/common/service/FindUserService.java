
/*
 * FindUserService.java
 * Created on Feb 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 1, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.LogonValidator;

public class FindUserService extends BaseService
{
    private UserDAO userDAOImpl;
    
    private LogonValidator logonValidator;
    
    protected final Logger logger = Logger.getLogger(getClass());
    
    public Map execute(Map inputParams)
    {
        logger.info("execute(Map inputParams) "+LoggingConstants.METHODBEGIN);
                
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);        
        logger.info("userName :"+userName);
        String ppKitNo = (String)inputParams.get("ppKitNo");
        String userEnterKitNo = (String)inputParams.get("userEnterKitNo");
        logger.info("userEnterKitNo:"+userEnterKitNo+" ppKitNo:"+ppKitNo);
        
        Map map = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);

        try
        {
        	if(ppKitNo!=null&&userEnterKitNo!=null&&ppKitNo.length()>0&&userEnterKitNo.length()>0&&!ppKitNo.equals(userEnterKitNo)){
        		 response.setErrorStatus(ServiceErrorConstants.FAILURE);
        		 response.setErrorCode(ServiceErrorConstants.PPK0001);
        	}
          
        	else if (userName != null)
            {
                if(logonValidator.loginUserName(userName))
                {
                    User user = userDAOImpl.findUser(userName);
                    if(user == null) //user name doesn't exist
                    {
                        response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    }else{
                        response.setErrorCode(ServiceErrorConstants.V104);
                    }
                    
                }               
            }
            else
            {
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE003);
            }
        }
        catch (DAOException daoException)
        {
            logger.error("Exception occured: " + daoException);
            response.setErrorCode(daoException.getErrorCode());

        }
        catch (SBIApplicationException appexp)
        {
            logger.error("Exception occured: " + appexp);
            response.setErrorCode(appexp.getErrorCode());
        }
        catch (Exception exp)
        {
            response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
        }
       
        logger.info("response errorCode :" + response.getErrorCode());
        logger.info("response errorStatus :" + response.getErrorStatus());       

        map.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("Map execute(Map inputParams) method end");

        return map;
    }

    /**
     * @param userDAOImpl The userDAOImpl to set.
     */
    public void setUserDAOImpl(UserDAO userDAOImpl)
    {
        this.userDAOImpl = userDAOImpl;
    }

    /**
     * @param logonValidator The logonValidator to set.
     */
    public void setLogonValidator(LogonValidator logonValidator)
    {
        this.logonValidator = logonValidator;
    }
} 
