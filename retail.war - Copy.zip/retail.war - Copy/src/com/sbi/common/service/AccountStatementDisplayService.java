/*MyAccountsService.java
 * Created on Oct 18, 2005
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * 
 */
//History
//Oct 18, 2005 MURUGAN K - Initial Creation
//Oct 19, 2005 MURUGAN K - Method Implemetations
package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.sbi.common.bp.*;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;
import org.apache.log4j.Logger;

/**
 * TODO This class used for to display the AccountInformation
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class AccountStatementDisplayService extends BaseService {
    private AccountInformationBP accountInformationBp;

    protected final Logger logger = Logger.getLogger(getClass());

    /**
     * TODO call the [AccountInformationBp.getUserAccountDetails(String
     * accountNo, String branchCode,String userName)] return Map which is
     * contains List Accounts
     * 
     * @param inputParams
     * @return Map
     * @throws SBIApplicationException
     */

    public Map execute(Map inputParams) {
        logger.info("Map execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Map map = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);

        if (userName != null) {
            try {
                List accountList = accountInformationBp.getUserAccounts(userName);
                if (accountList != null && accountList.size() > 0) {
                    logger.info("Accounts List size: " + accountList.size());
                    map.put(ServiceConstant.MYACCOUNTS, accountList);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE001);
                }
            }
            catch (SBIApplicationException appexp) {
                logger.error(LoggingConstants.EXCEPTION,appexp);
                response.setErrorCode(appexp.getErrorCode());
            }
            catch (Exception exp) {
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
                logger.error(LoggingConstants.EXCEPTION, exp);
            }
        }
        else {
            response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE004);
        }
        map.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        
        logger.info("Map execute(Map inputParams)" + LoggingConstants.METHODEND);
        return map;
    }

    /**
     * TODO AccountInformationBp object injection done here
     * 
     * @param accountInformationBp
     *            void
     */
    public void setAccountInformationBp(AccountInformationBP accountInformationBp) {
        this.accountInformationBp = accountInformationBp;
    }

}
