package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.IssueDetailsDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class DeleteTicketDetailsService extends BaseService{

	protected final Logger logger=Logger.getLogger(getClass());
	
	IssueDetailsDAO issueDetailsDAOImpl;
	
	public Map execute(Map inputParams){
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response =new SBIApplicationResponse();
		Map outParam=new HashMap();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		List selectTicketList=new ArrayList();
		if(inputParams!=null && inputParams.size()>0){
			logger.info("the inputParams are :"+inputParams);
			String[] ticketList=(String[])inputParams.get("ticketList");
			for(int i=0;i<ticketList.length;i++)
			{
				if(ticketList[i]!=null && ticketList[i].trim()!="" && ticketList[i].trim().length()>0)
					selectTicketList.add(ticketList[i]);
			}
			inputParams.put("ticketList", selectTicketList);
			
			try{
				issueDetailsDAOImpl.deleteTicketDetails(inputParams);
				response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				outParam.put("result", "success");
			}catch(DAOException daoException){
				logger.error(LoggingConstants.EXCEPTION,daoException);
				response.setErrorCode(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
			catch(SBIApplicationException appException){
				logger.error(LoggingConstants.EXCEPTION,appException);
				response.setErrorCode(appException.getErrorCode());
			}
			catch(Exception exception){
				logger.error(LoggingConstants.EXCEPTION,exception);
				response.setErrorCode(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		else
			response.setErrorCode(ServiceErrorConstants.SE002);
		
		outParam.put(ServiceConstant.APPLICATION_RESPONSE,response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return outParam;
	}

	public void setIssueDetailsDAOImpl(IssueDetailsDAO issueDetailsDAOImpl) {
		this.issueDetailsDAOImpl = issueDetailsDAOImpl;
	}
	
}
