/*
 * CompBenSetFileService.java
 * Created on Aug 13, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;


import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;

import org.apache.log4j.Logger;

public class CompBenSetFileService  extends BaseService{
	private Logger logger=Logger.getLogger(getClass());
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		Map outParams=new HashMap();
		
		SBIApplicationResponse response = new SBIApplicationResponse();
		try
		{
		   logger.info("Map execute(Map inParams) "	+ LoggingConstants.METHODBEGIN);
		   String format = (String)inParams.get("format");
		   String fieldDelimter = (String)inParams.get("fieldDelimter");
		   String compConfigType = (String)inParams.get("compConfigType");
		   String corporateId = (String)inParams.get("corporateId");
		   response.setErrorStatus(ServiceErrorConstants.FAILURE);
		  
		   int configCount = 0;
		   int compConfigCount = 0;
		   int  delConfigCount = 0;
		   int formatVal = 0;
		   int insertCount =0;
		   int updateCount = 0;
		   Map updateVal = new HashMap();
		   String configCheckData;
		   if(format != null)
		   {
		     if(format.equalsIgnoreCase("Fixed")){
			   formatVal = 1;
		      }
		   String txnTypeConfig = "'IBTP' ,'3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP'";
		   String  txnTypeComp = "'COMPOSITE_BEN'";
		   configCount = compBenFileDAOImpl.findConfigCount(corporateId, txnTypeConfig);
		    if(configCount > 0){
			   logger.info("To Remove Records in sbicorp_delimited_config or sbicorp_fixed_config and to insert record in sbicorp_file_config");
			   delConfigCount = compBenFileDAOImpl.deleteOldConfig(corporateId);
			   if (delConfigCount > 0)
			   {
				   insertCount =  compBenFileDAOImpl.insertFileConfigComp(formatVal, corporateId, fieldDelimter, compConfigType);
				   if (insertCount > 0 ){
				   response.setErrorStatus(ServiceErrorConstants.SUCCESS);  
				   }else
				   {
				   response.setErrorCode("F001");
				   }
			   }
		       }else{
	    	       compConfigCount = compBenFileDAOImpl.findConfigCount(corporateId, txnTypeComp);
	    	       if(compConfigCount > 0) {
	    		   logger.info("To update record in sbicorp_file_config for already present confgiurations");
	    		   updateVal=  compBenFileDAOImpl.updateFileConfigComp(formatVal, corporateId, fieldDelimter, compConfigType);
	    		   updateCount = (Integer)updateVal.get("updateCount");
	    		   if(updateCount > 0){
	    			   response.setErrorStatus(ServiceErrorConstants.SUCCESS);  
	    		   }else
	    		   {
	    			   configCheckData = (String)updateVal.get("configPresentVal");
	    			   if(configCheckData.equalsIgnoreCase("Yes")){
	    			   response.setErrorCode(ServiceErrorConstants.CONFIG_ALREADY_PRESENT);
	    			   }
	    			   else {
	    			   response.setErrorCode("F001");
	    			   }
	    			   
	    		   }  
	    		
	    	       }else {
	    		    logger.info("To Insert record in sbicorp_file_config if no records present in config table");
	    		    insertCount = compBenFileDAOImpl.insertFileConfigComp(formatVal, corporateId, fieldDelimter, compConfigType);
	    		       if (insertCount > 0){
					   response.setErrorStatus(ServiceErrorConstants.SUCCESS);  
					   }else
					   {
					   response.setErrorCode("F001");
					   }
	    	       }
		   }
         outParams.put("fieldDelimter",fieldDelimter);
         outParams.put("format",format);
        }else{
		    response.setErrorCode(ServiceErrorConstants.FORMAT_NOT_PRESENT);
	     }
      }catch (SBIApplicationException appex) {
			logger.error(LoggingConstants.EXCEPTION + appex);
			response.setErrorCode(appex.getErrorCode());
	  }catch (DAOException exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);

			logger.error(LoggingConstants.EXCEPTION + exp);
	  }catch (Exception exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
			response.setErrorCode(ServiceErrorConstants.SE002);
			logger.error(LoggingConstants.EXCEPTION + exp);
	  }
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}
 

}
