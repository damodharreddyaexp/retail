package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DownloadBenificiariesListDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;

public class DownloadBenificiariesListService extends BaseService {
	protected static Logger logger = Logger.getLogger(DownloadBenificiariesListService.class);
	
private DownloadBenificiariesListDAO downloadBenificiariesListDAOImpl;
	
	public Map execute(Map inputParams) {
		Map echequeMap = new HashMap();
		List echequeMasterList = null;
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inputParams.get("userName");
			String corporateId = (String)inputParams.get("corporateId");
		     String banktype = (String) inputParams.get("banktype");
			logger.info("userName"+userName+"corporateId"+corporateId);
			 String requestedBy = (String) inputParams.get("requestedBy");
			logger.info("requestedBy :" +requestedBy);
			
			String formatType = (String)inputParams.get("formatType");
			logger.info("formatType :" +formatType);
			
			String requestId="";
			 int resultcheck=1;
			if (inputParams.get("type")!=null  && inputParams.get("type").equals("checkRegEligible"))
			{
			if(corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim())){
				resultcheck=downloadBenificiariesListDAOImpl.checkEligibilityForRegulator(corporateId);
	            logger.info("requestId :" +requestId);
	           
	           	echequeMap.put("resultcheck", resultcheck);
	           	response.setErrorStatus(ServiceConstant.SUCCESS);
	            
			}else{
				response.setErrorCode("SUV001");
			}
			}
			else if (inputParams.get("type")!=null  && inputParams.get("type").equals("downloadfile"))
			{
			if(userName != null  && corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim())){
				requestId=downloadBenificiariesListDAOImpl.generateRequestIdForDownload3PFile(userName,banktype,corporateId,requestedBy,formatType);
	            logger.info("requestId :" +requestId);
	            if(requestId!=null ){
	           	echequeMap.put("requestId", requestId);
	           	response.setErrorStatus(ServiceConstant.SUCCESS);
	            }
	            else
	            {
	           	response.setErrorCode("CSE016");
               logger.info("Null Input");//error message
	            }  
			}else{
				response.setErrorCode("SUV001");
			}
			}
			else if (inputParams.get("type")!=null  && inputParams.get("type").equals("viewBenFilestatus"))
			{
				logger.info("inside viewBenFilestatus:::;"+userName);
            	echequeMasterList= downloadBenificiariesListDAOImpl.viewBenDownload3PFileRequestStatus(userName);
            	if (echequeMasterList != null && echequeMasterList.size() > 0)
            	{
            		 echequeMap.put("echequeMap", echequeMasterList);
                     response.setErrorStatus(ServiceConstant.SUCCESS);
                     response.setErrorCode(null);
            		 response.setErrorStatus(ServiceConstant.SUCCESS);
            	}
            	else {
            		response.setErrorCode("ECS009");
            		logger.info("Null Input");// Exception to be added
            	}
            	
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		echequeMap.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
		return echequeMap;
	}

	public void setDownloadBenificiariesListDAOImpl(
			DownloadBenificiariesListDAO downloadBenificiariesListDAOImpl) {
		this.downloadBenificiariesListDAOImpl = downloadBenificiariesListDAOImpl;
	}
	
	
}
