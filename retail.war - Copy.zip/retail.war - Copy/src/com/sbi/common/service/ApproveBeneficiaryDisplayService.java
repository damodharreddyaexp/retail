/*
 * AddThirdPartyHandler.java
 * Created on Mar 17, 2006
 *
 * Copyright (c) 2006 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 17, 2006 Asit- Initial Creation

package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ThirdPartyDAO;
import com.sbi.common.model.ApproveDelTPModel;
import com.sbi.common.model.User;

/**
 * This class used for to display the ApproveDeleteThirdParty Information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
 public class ApproveBeneficiaryDisplayService extends BaseService{
    protected final Logger logger = Logger.getLogger(getClass());

    private ThirdPartyDAO thirdPartyDAOImpl;
    
    
    public Map execute(Map inputParam) {
        logger.info("execute(Map inputParam))" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);        
        User user = (User) inputParam.get("user");
        String type=(String)inputParam.get("type");
        String corpId=user.getCorporateId();
        String userName=user.getUserAlias();
        logger.info("userName :" + userName);
        try {
                List approveBeneficiaryDetails= thirdPartyDAOImpl.findApproveBeneficiary(corpId,userName,type);
                if(approveBeneficiaryDetails.size()!=0){
                   logger.info("The model......." + approveBeneficiaryDetails.size());
                   response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                   outParam.put("approveBeneficiaryDetails", approveBeneficiaryDetails);
                   }
                else
                    response.setErrorCode("CSE015");
               
        } catch (Exception exp) {
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("outParam :" + outParam);
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODEND);
        return outParam;

    }


    public void setThirdPartyDAOImpl(ThirdPartyDAO thirdPartyDAOImpl)
    {
        this.thirdPartyDAOImpl = thirdPartyDAOImpl;
    }

}


