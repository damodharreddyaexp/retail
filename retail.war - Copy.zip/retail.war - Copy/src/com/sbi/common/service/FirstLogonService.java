/*
 * FirstLogonService.java
 * Created on Feb 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 1, 2006 KRISHNA KUMAR - Initial Creation
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.Decrypt;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.LogonValidator;
import com.sbi.common.bp.LogonBP;

public class FirstLogonService extends BaseService
{

    private UserDAO userDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());
    
    private LogonValidator logonValidator;
    private LogonBP logonBP;
/**
     * @param logonValidator The logonValidator to set.
     */
    public void setLogonValidator(LogonValidator logonValidator)
    {
        this.logonValidator = logonValidator;
    }
public Map execute(Map inputParams)
    {

        logger.info("execute(Map inputParams) " + LoggingConstants.METHODBEGIN);
   
        Map outParams = new HashMap();
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);        
        String password = (String) inputParams.get(ServiceConstant.PASSWORD);
        String newUserName= (String) inputParams.get(ServiceConstant.NEW_USER_NAME);  
        Decrypt dec=new Decrypt();//added for CR 5034
        String keyid = (String)inputParams.get("keyid");
        String keyString = (String)inputParams.get("keyString");
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        
        //modified for CR 5034 - begin
        if(keyid != null && keyid.trim().length() > 0)
			password=logonBP.getPAssword(keyid,password);
        else if(keyString!=null && keyString.length()>0){    		
		try {
			password=dec.decrypt(keyString, password);
		} catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION,exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
      }
		//added for CR 5034 - end
        
        if(userName != null && !userName.trim().equalsIgnoreCase("") && password != null && !password.trim().equalsIgnoreCase("") && newUserName != null && !newUserName.trim().equalsIgnoreCase("") ){
        try{
            logger.info("newUserName ="+newUserName);
            if(logonValidator.loginPassword(password)){
	            boolean result = userDAOImpl.changeCorporateUserName(newUserName,userName,password);
	            if(result)
	                response.setErrorStatus(ServiceConstant.SUCCESS);
	            else
	                response.setErrorCode(ServiceErrorConstants.SE002);
            }
        }
        catch (DAOException daoException){
            logger.error(LoggingConstants.EXCEPTION, daoException);
            response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode(daoException.getErrorCode());    //changed for CR NO:2013

        }
        catch (SBIApplicationException sbiApplException){//added to get the SBIApplicationException if it is thrown
            logger.error(LoggingConstants.EXCEPTION, sbiApplException);
            response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode(sbiApplException.getErrorCode());  

        }
        catch (Exception excep){
            logger.error(LoggingConstants.EXCEPTION, excep);
            response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE002);
        }

        }else{
            logger.info("one of the value is null");
            response.setErrorCode(ServiceErrorConstants.SE003);
        }
        outParams.put("password", password);//by nag
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);        
        
        logger.info("execute(Map inputParams) " + LoggingConstants.METHODEND);
        return outParams;

    }    /**
             * @param userDAOImpl
             *            The userDAOImpl to set.
             */
    public void setUserDAOImpl(UserDAO userDAOImpl)
    {
        this.userDAOImpl = userDAOImpl;
    }
    public void setLogonBP(LogonBP logonBP) {
		this.logonBP = logonBP;
	}
}
