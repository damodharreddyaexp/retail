package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CreditTransactionDetailsDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.utils.LoggingConstants;

public class CreditTransactionDetailsService extends BaseService{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	private CreditTransactionDetailsDAO creditTransactionDetailsDAOImpl;
	
	public Map execute(Map inparams) {
		logger.info("execute(Map inputParams) method begin "
				+ LoggingConstants.METHODBEGIN);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);

		Map outParams = new HashMap();
		List getcreditlist = new ArrayList();
		int count = 0;
		String echequeNo = null;
		String pageNo = null;
		String limit = null;
		try{
			echequeNo = (String) inparams.get("referenceNo");
			pageNo = (String) inparams.get("pageNo");
			limit = (String) inparams.get("limit");
			if(echequeNo != null){
				outParams = creditTransactionDetailsDAOImpl.findCredits(echequeNo,pageNo,limit);
				if (outParams != null && outParams.size() > 0){
					getcreditlist  = (List)outParams.get("pendingEcheques");						
					if(getcreditlist != null){
						for (int i=getcreditlist.size()-1;i>=0;i--){
							CorpTransactionLeg corpTransactionLeg=(CorpTransactionLeg)getcreditlist.get(i);
							
							double echequeAmount = new Double(corpTransactionLeg.getAmount()).doubleValue();
							
							if(echequeAmount != 0d){
								corpTransactionLeg.setAmount(echequeAmount); 
							}
							String narrative3=corpTransactionLeg.getCreditNarrative3();
							if(narrative3 != null){
								corpTransactionLeg.setNarrative3(narrative3);
							}
							getcreditlist.remove(i);
							getcreditlist.add(corpTransactionLeg);
							logger.info("Credit List===="+getcreditlist);
						}
						outParams.put("creditList", getcreditlist);
						logger.info("Credit List Size per page: " + getcreditlist.size());
					}else{
						response.setErrorCode("CTD001"); 
					}
				}else{
					response.setErrorCode("CTD001"); 
				}
			}else{
				logger.info("Input values are null");
				response.setErrorCode("DTD001"); 
			}
		}catch (SBIApplicationException ex) {
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode(ex.getErrorCode());
		} catch (DAOException ex) {
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode(ex.getErrorCode());
		} catch (Exception ex) {
			ex.printStackTrace();	
			logger.error(LoggingConstants.EXCEPTION, ex);
			response.setErrorCode("CIRS040");
		}
		response.setErrorStatus(ServiceConstant.SUCCESS);
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		
		logger.info("response.getErrorCode():: " + response.getErrorCode() );
		return outParams;
	}

	public void setCreditTransactionDetailsDAOImpl(
			CreditTransactionDetailsDAO creditTransactionDetailsDAOImpl) {
		this.creditTransactionDetailsDAOImpl = creditTransactionDetailsDAOImpl;
	}

}
