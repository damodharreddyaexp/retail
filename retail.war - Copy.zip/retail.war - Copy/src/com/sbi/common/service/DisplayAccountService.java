/*
 * DisplayAccService.java
 * Created on Dec 21, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 21, 2005 MURUGAN K - Initial Creation and Method implementations
//Feb 01, 2006 MURUGAN K - Log changes
package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.bp.AccountInformationBP;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;

import com.sbi.common.model.Account;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.UserDAO;

public class DisplayAccountService extends BaseService {

    private AccountInformationBP accountInformationBp;

    protected final Logger logger = Logger.getLogger(getClass());
    
    private UserDAO userDAOImpl;

    /**
     * TODO Call the
     * [AccountInformationBp.getTransactionAccounts(userName,ServiceConstant.DEBIT_ACCOUNT)]
     * return the Debit Accounts List and call
     * [AccountInformationBp.getTransactionAccounts(userName,THIRD_PARTY)]
     * return the Third party Accounts List
     * 
     * @param inputParams
     * @return Map
     */
    public Map execute(Map inputParams) {
        logger.info("execute(Map inputParams) " + LoggingConstants.METHODBEGIN);
        logger.debug("Inputparams: " + inputParams);

        Map outputParams = new HashMap();
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Integer accountType = (Integer) inputParams.get(ServiceConstant.ACCOUNT_TYPE);
        SBIApplicationResponse response = new SBIApplicationResponse();
        String viewType=(String)inputParams.get("selectedType");
        if (userName != null && accountType != null) {

            try {

                if (accountType.equals(ServiceConstant.THIRD_PARTY)) {
                    List thirdPartyAccountList = accountInformationBp.getTPAccounts(userName); //Changed for CR-5390
                    
                    if (thirdPartyAccountList != null && thirdPartyAccountList.size() > 0) {
                        
                        thirdPartyAccountList = filterAccount( thirdPartyAccountList );
                        
                        logger.info("viewtype:"+viewType);
                        
                        //For filtering Rejected Accounts for modify and delete CR-5390
                        if(!"view".equalsIgnoreCase(viewType))
                        { logger.info("viewtype1:"+viewType);
                        	
                          thirdPartyAccountList=filterforRejectedTPAccounts(thirdPartyAccountList);
                        }
                        
                        // After filtering the accounts
                        if( thirdPartyAccountList.size() > 0 )
                        {
                            outputParams.put(ServiceConstant.THIRD_PARTY_ACCOUNT,thirdPartyAccountList );
                            response.setErrorStatus(ServiceErrorConstants.SUCCESS); 
                        }
                        else
                        {
                            response.setErrorCode("FORMB006"); 
                            response.setErrorStatus(ServiceErrorConstants.FAILURE);
                        }
                        
                        if (logger.isDebugEnabled()) {
                            logger.debug("ThirdPartyAccountList is: " + thirdPartyAccountList);
                        }
                        UserProfile userprofile = userDAOImpl.findUserProfile(userName);
                        outputParams.put(ServiceConstant.USER_PROFILE, userprofile);
                    }
                    else {
                        response.setErrorCode("FORMB006");
                        response.setErrorStatus(ServiceErrorConstants.FAILURE);

                    }
                }
                else {
                    if (accountType.equals(ServiceConstant.PPF)) {
                        List ppfAccountList = accountInformationBp.getAccountsByNature(userName, ServiceConstant.PPF);
                        if (ppfAccountList != null && ppfAccountList.size() > 0) {
                            outputParams.put(ServiceConstant.PPF_ACCOUNT, ppfAccountList);
                            response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                            if (logger.isDebugEnabled()) {
                                logger.debug("PPF account List is: " + ppfAccountList);

                            }
                        }
                        else {
                            response.setErrorCode(ServiceErrorConstants.SE065);
                            response.setErrorStatus(ServiceErrorConstants.FAILURE);

                        }
                    }
                }
            }
            catch (SBIApplicationException sbiexp) {
                logger.error(LoggingConstants.EXCEPTION,sbiexp);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(sbiexp.getErrorCode());

            }
            catch (Exception exp) {
                logger.error(LoggingConstants.EXCEPTION, exp);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
                response.setErrorCode(ServiceErrorConstants.SE002);
                exp.printStackTrace();
            }

        }
        else {
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorCode(ServiceErrorConstants.SE003);

        }
        outputParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
        logger.debug("outparams  Map contains: " + outputParams);
        logger.info("execute(Map inputParams) " + LoggingConstants.METHODEND);
        return outputParams;
    }

    
    private List filterAccount(List accList)
    {
        List resultList = new ArrayList();
        int count = accList.size();
        Account account;
        String accountNo;
        for(int i =0;i<count; i++ )
        {
            account = (Account) accList.get(i);
            accountNo = account.getAccountNo();
            
            logger.info("Account Number " + accountNo);
            
            int index  = accountNo.indexOf("NONE");
            logger.info("index " + index );
            if (index == -1)
            { 
                resultList.add(account);
            }
                
        
        }
        
     
        return resultList;
    }
    
    //Added for CR-5390
    private List filterforRejectedTPAccounts(List accList)
    {
    	
    	 List resultList = new ArrayList();
         int count = accList.size();
         Account account;
         String approvalStatus;
         for(int i =0;i<count; i++ )
         {
             account = (Account) accList.get(i);
             approvalStatus = account.getCoreMigrationDisplay();
             logger.info("approvalStatus"+approvalStatus);
             
             
             if (approvalStatus!=null && !approvalStatus.equalsIgnoreCase("Rejected"))
             { 
                 resultList.add(account);
             }
                 
         
         }
    	logger.info("resultList"+resultList);
    	return resultList;
    }
    
    /**
     * TODO AccountInformationBp object injection done here
     * 
     * @param accountInformationBp
     *            void
     */
    public void setAccountInformationBp(AccountInformationBP accountInformationBp) {
        this.accountInformationBp = accountInformationBp;
    }

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}
}
