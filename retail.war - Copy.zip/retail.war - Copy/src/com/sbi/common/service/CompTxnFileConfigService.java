package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompTxnFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CompTxnFileModel;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompTxnFileConfigService extends BaseService {
	
	private CompTxnFileDAO compTxnFileDAOImpl;
   

	protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {
    	logger.info("execute(Map inputParams...) - begin");
		Map outputParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		if(inputParams!=null && inputParams.size()>0){
			String funcType = (String) inputParams.get("funcType");
			String corporateId = (String) inputParams.get("corporateId");
			String fileType = (String) inputParams.get("fileType");
			List list = null;
			List masterConfigList = null;
			
			
			try {
				
				if("getNewFileConfigDtls".equalsIgnoreCase(funcType)) {
					
					list = compTxnFileDAOImpl.getNewFileConfiguration(corporateId,fileType);
					
					if(list!= null && list.size() > 0) {
						/*getConfigurationString(list,fileType);*/
						outputParams.put("txnType",list.get(list.size()-1));
						list.remove(list.size()-1);
						outputParams.put("fileconfiguration", list);
					}
					response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					
				} else {
					list = compTxnFileDAOImpl.getFileConfiguration(corporateId,fileType);
					
					if ((list == null) || (list.size() == 0)) {
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorCode(ServiceErrorConstants.NO_FILE_CONFIG_EXISTS);
					} else {
						getConfigurationString(list,fileType);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
						outputParams.put("fileconfiguration", list);
					}
				}
				
			}
			catch(DAOException ex)
			{
				ex.printStackTrace();
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				if(ex.getErrorCode()!=null)
					response.setErrorCode(ex.getErrorCode());
				else
					response.setErrorCode("F001");
			}
			catch (Exception e) {
				logger.error("Error occured",e);
				e.printStackTrace();
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorCode(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		else
			response.setErrorCode(ServiceErrorConstants.SE003);
		outputParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams) - end");
		return outputParams;
	}
    
    private String[] getConfigurationString(List input,String txnType){
		logger.info("getConfigurationString(List input) - begin");
		String result[]=new String[2];
		Map configuration=new HashMap();
		String fieldDelimiter="";
		//added CR-5583
		configuration.put("Beneficiary Branch Code", "08586");
		configuration.put("Beneficiary Mobile Number", "9800000000");
		configuration.put("Beneficiary Account No", "01600123456");
		configuration.put("Beneficiary Code", "000010014");
		configuration.put("Email Id", "test@sbi.co.in");
		configuration.put("Name of the Beneficiary", "Ankit Electricals Ltd");
		//End
		
		configuration.put("Debit Branch Code", "08586");
		configuration.put("Branch Code", "08586");
		configuration.put("Account NoD", "01600123456");
		configuration.put("Account NoC", "01004567891");
		configuration.put("Debit Account No", "01600123456");
		configuration.put("Date", "22/02/2006");
		configuration.put("Debit Date", "22/02/2006");
		configuration.put("Debit MICR Code", "012345678");
		configuration.put("MICR Code", "012345678");
		configuration.put("Payee Name", "Test Payee");
		configuration.put("Description", "Ankit Electricals Ltd");
		configuration.put("Reference No", "UNIQ_REF_NO");
		configuration.put("Debit Hour", "10");
		configuration.put("Debit Min", "10");
		configuration.put("Debit Amount", "1.00");
		configuration.put("Amount", "1.00");
		configuration.put("Credit Branch Code", "08586");
		/*if((txnType!=null && txnType.equalsIgnoreCase("CR"))||(bankType!=null && bankType.equalsIgnoreCase("BOTH")))
			configuration.put("Credit Branch Code", "BKID0008605");*/
		configuration.put("Credit Account No", "01004567891");
		configuration.put("Credit MICR Code", "012345678");
		configuration.put("Credit Amount", "1.00");
		configuration.put("Credit Date", "22/02/2006");
		configuration.put("Account No", "01600123456");
		configuration.put("Dealer Code","DC1");
		//added for inter bank third party
        configuration.put("Beneficiary Name", "Ankit Electricals Ltd");
        configuration.put("Account Number", "01600123456");
        configuration.put("Ifsc Code", "SBIN0003137");        
        configuration.put("Address1", "Red Hill Lane");
        configuration.put("Address2", "Cullen Road");
        configuration.put("Address3", "Bangalore");
        configuration.put("Mobile_no", "9800000000");
        //inter bank third party ends here 
        //added for defect 5165
//        configuration.put("Payment_Identifier",  (bankType!=null && bankType.equalsIgnoreCase("INTRA")?"":"NEFT"));
        //changes for defect 5165 ends here

        configuration.put("PAN", "BGZPS8479K");
        configuration.put("NAME", "Testuser");
        configuration.put("HOUSE NO", "Test No: 1");
        configuration.put("PREMISES", "Test");
        configuration.put("STREET", "Street");
        configuration.put("LOCALITY", "Locality");
        configuration.put("CITY", "City");
        configuration.put("STATE", "State");
        configuration.put("PINCODE", "999999");
		
        CompTxnFileModel fileConfiguration=(CompTxnFileModel)input.get(input.size()-1);
		
		if(fileConfiguration.getFormat()==0){
			if(txnType.equalsIgnoreCase("3P") || txnType.equalsIgnoreCase("IBTP") || txnType.equalsIgnoreCase("D3P") || txnType.equalsIgnoreCase("DIBTP") || txnType.equalsIgnoreCase("COMPOSITE_BEN")){
				String[] debitString =new String[fileConfiguration.getOrderNumber()+1];
				for(int i=0;i<input.size();i++){
					CompTxnFileModel fileConf=(CompTxnFileModel)input.get(i);
					if(i==0)
						fieldDelimiter=fileConf.getFieldDelimiter();
					debitString[fileConf.getOrderNumber()]=(String)configuration.get(fileConf.getFieldName().trim());
					
					//added CR5583
					String fldnamedel=fileConf.getFieldName();
					if(fldnamedel.equalsIgnoreCase("Beneficiary Name")||fldnamedel.equalsIgnoreCase("Description")){
						fileConf.setFieldName("Beneficiary Name");					
					}
					
					if(fldnamedel.equalsIgnoreCase("Account Number")||fldnamedel.equalsIgnoreCase("Debit Account No")){
						fileConf.setFieldName("Beneficiary Account No");				
					}
					
					if(fldnamedel.equalsIgnoreCase("Debit Branch Code")){
						fileConf.setFieldName("Beneficiary Branch Code");												
					}
					/*if(fldnamedel.equalsIgnoreCase("OUTREF")){
						fileConf.setFieldName("Beneficiary Code");
										
					}*/
					if(fldnamedel.equalsIgnoreCase("Mobile_no")){
						fileConf.setFieldName("Beneficiary Mobile Number");
										
					}
					//End
				}
				for(int i=0;i<debitString.length;i++){
					if(i==0)
						result[0]=debitString[i];
					else
						result[0]=result[0]+fieldDelimiter+debitString[i];
				}
			}			
		}
		else{
			
			CompTxnFileModel fileConf1=(CompTxnFileModel)input.get(input.size()-1);
			
			if(txnType.equalsIgnoreCase("3P")|| txnType.equalsIgnoreCase("IBTP") || txnType.equalsIgnoreCase("D3P")|| txnType.equalsIgnoreCase("DIBTP")){               
				StringBuffer debitString=new StringBuffer();
				String emptyStr="";
				String filedValue="Other Details";
				for(int i=0;i<fileConf1.getEndIndex();i++){
					emptyStr=emptyStr+" ";
				}
				
				debitString.replace(0,fileConf1.getEndIndex(),emptyStr);
				
				for(int i=0;i<input.size();i++){
					
					filedValue="Other Details";
					CompTxnFileModel fileConf=(CompTxnFileModel)input.get(i);
					if(configuration.get(fileConf.getFldName().trim())!=null)
						filedValue=(String)configuration.get(fileConf.getFldName().trim());
                	if(fileConf.getEndIndex()-fileConf.getStartIndex()<filedValue.length())
						filedValue=filedValue.substring(0,fileConf.getEndIndex()-fileConf.getStartIndex()+1);
					int startIndex=fileConf.getStartIndex();
					debitString.replace(startIndex,startIndex+filedValue.length(),filedValue);
					
					String fldname=fileConf.getFldName();
					if(fldname.equalsIgnoreCase("Description")||fldname.equalsIgnoreCase("Beneficiary Name")){
						fileConf.setFldName("Beneficiary Name");					
					}
					if(fldname.equalsIgnoreCase("Debit Account No")||fldname.equalsIgnoreCase("Account Number")){
						fileConf.setFldName("Beneficiary Account No");				
					}
					if(fldname.equalsIgnoreCase("Debit Branch Code")){
						fileConf.setFldName("Beneficiary Branch Code");
										
					}
					if(fldname.equalsIgnoreCase("Mobile_no")){
						fileConf.setFldName("Beneficiary Mobile Number");
										
					}
					/*if(fldname.equalsIgnoreCase("OUTREF")){
						fileConf.setFldName("Beneficiary Code");
										
					}*/
					
					//End
				}
				result[0]=debitString.toString();
			}
			
		}
		logger.info("getConfigurationString(List input) - end");
		return result;
	}
    
	public void setCompTxnFileDAOImpl(
			CompTxnFileDAO compTxnFileDAOImpl) {
		this.compTxnFileDAOImpl = compTxnFileDAOImpl;
	}
	
 }
