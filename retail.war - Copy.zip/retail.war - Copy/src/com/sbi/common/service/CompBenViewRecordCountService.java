package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.handler.LoggingConstants;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.service.ServiceErrorConstants;



public class CompBenViewRecordCountService extends BaseService {
	
	protected static Logger logger = Logger.getLogger(CompBenViewRecordCountService.class);
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		
		logger.info("execute(Map inParams)" + LoggingConstants.METHODBEGIN);
		Map outParams = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceConstant.FAILURE);
		try{
			String userName  = (String)inParams.get("userName");
			String corporateId = (String)inParams.get("coporateId");
			String fileName = (String)inParams.get("fileName");
			String fileType = (String) inParams.get("fileType");
			String uploaderName = (String) inParams.get("uploaderName");
			
			int index = fileName.indexOf('.');
			String fName = fileName.substring(0, index);
			int benRecCount = 0;
			
			Map compBenRecCount =new HashMap();
			int sameBankAddRecCount = 0;
			int sameBankDeleteRecCount = 0;
			int otherBankAddRecCount = 0;
			int otherBankDeleteRecCount = 0;
			
			
			if(userName != null  && corporateId != null &&  !"".equalsIgnoreCase(corporateId.trim()) && fileName != null && fileType != null){
				if("COMPOSITE_BEN".equalsIgnoreCase(fileType) || "validationFailure".equalsIgnoreCase(fileType)|| "ABTP".equalsIgnoreCase(fileType)|| "validationFailure_aadhar".equalsIgnoreCase(fileType)) {
					compBenRecCount = compBenFileDAOImpl.findCompViewBenRecCount(fName,userName,corporateId,uploaderName,fileType);
					
					outParams.put("sameBankAddRecCount",compBenRecCount.get("sameBankAddRecCount"));
					outParams.put("sameBankDeleteRecCount",compBenRecCount.get("sameBankDeleteRecCount"));
					outParams.put("otherBankAddRecCount",compBenRecCount.get("otherBankAddRecCount"));
					outParams.put("otherBankDeleteRecCount",compBenRecCount.get("otherBankDeleteRecCount"));
					outParams.put("validationFailureCount",compBenRecCount.get("validationFailureCount"));
					
					response.setErrorStatus(ServiceConstant.SUCCESS);
				}
				else {
					
			       	benRecCount = compBenFileDAOImpl.findViewBenRecCount(fName,userName,corporateId,fileType);
					if(benRecCount > 0){
	 					outParams.put("benRecCount",benRecCount);
	 					if("3P".equals(fileType) || "IBTP".equals(fileType) )
	 					{
	 				     outParams.put("fileTypeDesc","Add");
	 					}else if("D3P".equals(fileType) || "DIBTP".equals(fileType)){
	 					 outParams.put("fileTypeDesc","Delete");
	 					}
	 					response.setErrorStatus(ServiceConstant.SUCCESS);
					}
					else {
						response.setErrorCode("BEN007");
					}
					outParams.put("benRecCount",benRecCount);
				}
				outParams.put("fileType",fileType);
				outParams.put("fileName",fileName);
      		}
			else{
				response.setErrorCode("SE010");
			}
		}catch (DAOException sbiExc) {
			response.setErrorCode(sbiExc.getErrorCode());
			logger.error(LoggingConstants.EXCEPTION, sbiExc);
		}
		catch (Exception exp) {
			logger.error(LoggingConstants.EXCEPTION, exp);
			response.setErrorCode(ServiceErrorConstants.SE002);
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		return outParams;
	}

	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}

	
	
	
}
