/*
 * DisplayAlertsService.java
 * Created on Jan 3, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 3, 2006 KRISHNA KUMAR - Initial Creation
// Jan 19,2006 MURUGAN K - Changes in conditions and set the Error Code for there is no alert
// Feb 01 ,2006 MURUGAN K - Changes in Logs

package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.SMSAlertDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class DisplayAlertsService extends BaseService {
    protected final Logger logger = Logger.getLogger(getClass());

    private SMSAlertDAO smsAlertDAOImpl;

    public Map execute(Map inputParams) {

        logger.info("execute(Map inputParams) " + LoggingConstants.METHODBEGIN);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);

        Map outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);

        try {
            if (userName != null) {

                List smsAlertList = smsAlertDAOImpl.findUserAlerts(userName);
                if (smsAlertList != null && smsAlertList.size() > 0) {
                    outParams.put(ServiceConstant.SMS_ALERT_LIST, smsAlertList);
                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                    if (logger.isDebugEnabled())
                        logger.debug("outparams =" + outParams);

                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE055);

                }

            }
            else {
                response.setErrorCode(ServiceErrorConstants.SE003);

            }
        }
        catch (SBIApplicationException appexp) {
            logger.error(LoggingConstants.EXCEPTION, appexp);
            response.setErrorCode(appexp.getErrorCode());

        }
        catch (DAOException doaExp) {
            response.setErrorCode(doaExp.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, doaExp);

        }
        catch (Exception exp) {
            response.setErrorCode(ServiceErrorConstants.SE002);
            logger.error(LoggingConstants.EXCEPTION, exp);

        }

        outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams) " + LoggingConstants.METHODEND);
        return outParams;
    }

    /**
     * @param smsAlertDAOImpl The smsAlertDAOImpl to set.
     */
    public void setSmsAlertDAOImpl(SMSAlertDAO smsAlertDAOImpl) {
        this.smsAlertDAOImpl = smsAlertDAOImpl;
    }

}
