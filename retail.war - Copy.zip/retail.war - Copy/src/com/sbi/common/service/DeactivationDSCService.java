package com.sbi.common.service;

//import java.security.cert.Certificate;
//import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.DigitalCertificateDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.DSCDetails;



public class DeactivationDSCService extends BaseService {
	
	private DigitalCertificateDAO digitalCertificateDAOImpl;
   

	protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {

        logger.info("DeactivationDSCService Method Starts ");

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        Map outParam = new HashMap();
        String userName = (String)inputParams.get("userName");
        String serialNo= (String)inputParams.get("serialNo");
        String securityOption= (String) inputParams.get("securityOption");
        
        logger.info("userName ::"+userName);
        logger.info("serialNo ::"+serialNo);
        logger.info("securityOption ::"+securityOption);
        
        DSCDetails dscDetails=null;
        
       // String digitalErrorCode ="";
      //  String certificateMsg="";
      //  String verifymsg="";
        boolean deactFlag= false;
         try {
       
            	if(userName != null && serialNo != null  ){
            		dscDetails = digitalCertificateDAOImpl.getDeactivationDetails(userName,serialNo,securityOption);
            	
            	if(dscDetails != null){
            		logger.info("dscDetails >if>>>"+dscDetails);
            	   outParam.put("dscDetails", dscDetails);
            	   response.setErrorStatus(ServiceConstant.SUCCESS); 
            	}else{
            		logger.info("deactFlag >else>>>"+dscDetails);
            	   response.setErrorCode("DSR004");
            	   response.setErrorStatus(ServiceErrorConstants.FAILURE);
            	}
            	}else{
            		response.setErrorCode("DSR004");
             	   response.setErrorStatus(ServiceErrorConstants.FAILURE);
            	}
           
               
          }catch (SBIApplicationException sbiApplicationException) {
                logger.error(sbiApplicationException, sbiApplicationException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(sbiApplicationException.getErrorCode());

            }
            catch (DAOException daoException) {

                logger.error(daoException, daoException);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
            }
             catch (Exception exp) {
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(ServiceErrorConstants.SE002);
                logger.error("Exception occured: " , exp);
            }

          
 	        outParam.put("deactFlag", deactFlag);	
 	        

 	       outParam.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("DeactivationDSCService Method Ends ");
        return outParam;
    }
    
   /* private String getSNFromPKCS7(String pkcs7Data) {
        PKCS7CertificateExtractor certificateExtractor = new PKCS7CertificateExtractor(Base64.decodeBase64(pkcs7Data));
        Certificate[] certificates = certificateExtractor.extract();
        String serialNumber = getSNFromCertificate(certificates[0]);
        logger.info("Serial Number ----->" + serialNumber);
        return serialNumber;
    }*/
   /* private String getSNFromCertificate(Certificate certificate) {
        X509Certificate x509Certificate = (X509Certificate) certificate;
        String serialNumber = x509Certificate.getSerialNumber().toString();
        return serialNumber;
    }
*/
	public void setDigitalCertificateDAOImpl(
			DigitalCertificateDAO digitalCertificateDAOImpl) {
		this.digitalCertificateDAOImpl = digitalCertificateDAOImpl;
	}
    
    
   
 }
