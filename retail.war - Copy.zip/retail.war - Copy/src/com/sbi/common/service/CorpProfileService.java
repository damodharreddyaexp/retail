/*
 * CorpProfileService.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History



package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.dao.BranchMasterDAO;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.LoggingConstants;

public class CorpProfileService extends BaseService {
    protected final Logger logger = Logger.getLogger(getClass());

    private UserDAO userDAOImpl;
   

    public Map execute(Map inputParams) {
    	logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
    	if (logger.isDebugEnabled())
        logger.debug("inputparams Map:" + inputParams);
        Map outParams = new HashMap();
        
        List locationList = null;

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        Integer userId= (Integer) inputParams.get(ServiceConstant.USER_ID);
        String highSecurityStatus = (String) inputParams.get("highSecurityStatus");
        String corporateID = (String) inputParams.get("corporateID");
        String flag = (String) inputParams.get("flag");
        logger.info("=====corporateID========"+corporateID);
        try {

            if (corporateID != null && flag.equalsIgnoreCase("updateMerchantMode")) {

               int count = userDAOImpl.updateCorpProfile(userName,highSecurityStatus,corporateID);
               logger.info("=========count=>>>>>>>>>>>>>>>"+count);
               if (count>0){
            	   response.setErrorStatus(ServiceConstant.SUCCESS);
               }else{
            	   response.setErrorCode(ServiceErrorConstants.SE002);
               }               
            }
           else if(corporateID != null && flag.equalsIgnoreCase("VoiceOTPMode")) {
            	   String merchantMode=userDAOImpl.getMerchantMode(corporateID);
            	   outParams.put("merchantMode",merchantMode);
            }
           else if(corporateID != null && flag.equalsIgnoreCase("updateVoiceOTPMode")) {
        	   String otpOption=(String) inputParams.get("otpOption");
        	   Boolean success=userDAOImpl.updateOTPDeliveryMode(userId.toString(),otpOption);
        	   if(success) {        		   
        		   outParams.put("updateOTPMode",success);
        		   response.setErrorStatus(ServiceConstant.SUCCESS);
        	   }
           }else{
            	logger.info("CorporateId is null");
            	response.setErrorStatus(ServiceConstant.FAILURE);
            	response.setErrorCode(ServiceErrorConstants.SE002);
            }

        }
        catch (Exception exp) {
            logger.error("Exception occured :" + exp);
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }

        //outParams.put(ServiceConstant.USER_PROFILE, profile);
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
       
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return outParams;

    }

    public void setUserDAOImpl(UserDAO userDAOImpl) {
        this.userDAOImpl = userDAOImpl;
    }
  
    

}