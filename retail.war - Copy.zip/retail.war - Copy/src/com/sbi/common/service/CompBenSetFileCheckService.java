/*
 * CompositeSetFileService.java
 * Created on Aug 13, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.sbi.common.dao.CompBenFileDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.service.BaseService;
import com.sbi.common.service.ServiceErrorConstants;

import org.apache.log4j.Logger;

public class CompBenSetFileCheckService  extends BaseService{
	private Logger logger=Logger.getLogger(getClass());
	
	private CompBenFileDAO compBenFileDAOImpl;
	
	public Map execute(Map inParams) {
		Map outParams=new HashMap();
		
		SBIApplicationResponse response = new SBIApplicationResponse();
		try
		{
		   logger.info("Map execute(Map inParams) "	+ LoggingConstants.METHODBEGIN);
		 
		   String corporateId = (String)inParams.get("corporateId");
		   int smallFlag = (Integer)inParams.get("smallFlag");
		   response.setErrorStatus(ServiceErrorConstants.FAILURE);
		   List list = null;
		   
		   if(corporateId != null)
		   { 
			   boolean checkPending = compBenFileDAOImpl.findFileStatusTP(corporateId);
			   logger.info("FindStatus for pending :" + checkPending);
			   if (!checkPending) {
				   
				   		
				   int configCount = 0;
				   String  txnTypeComp = "'COMPOSITE_BEN'";
				   configCount = compBenFileDAOImpl.findConfigCount(corporateId, txnTypeComp);
				   if(configCount > 0) {
					   outParams.put("compFileConfigFlag","true");
				   }
				   else {
					   outParams.put("compFileConfigFlag","false");
				   }
				   if (smallFlag == 0) {
					   logger.info("In to Vyapar Comp Check "+smallFlag);
			           if(configCount > 0) {
			        	   response.setErrorCode(ServiceErrorConstants.VYAAPAR_CHECK);
			           }else {
				       response.setErrorStatus(ServiceErrorConstants.SUCCESS);
			           }
				   }
				   else {
					   response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				   }
			   }
			   else {
				   logger.info("Pending files is present in sbi_file_master table");
				   response.setErrorCode(ServiceErrorConstants.FILES_PRESENT);
			   }
				   
           }else{
        	   response.setErrorCode(ServiceErrorConstants.CORPID_NOT_PRESENT);
	       }
		   
		}catch (SBIApplicationException appex) {
			logger.error(LoggingConstants.EXCEPTION + appex);
			response.setErrorCode(appex.getErrorCode());
		}catch (DAOException exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);

			logger.error(LoggingConstants.EXCEPTION + exp);
		}catch (Exception exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
			response.setErrorCode(ServiceErrorConstants.SE002);
			logger.error(LoggingConstants.EXCEPTION + exp);
		}
		logger.info("execute(Map inParams)" + LoggingConstants.METHODEND);
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		return outParams;
	}
	
	public void setCompBenFileDAOImpl(CompBenFileDAO compBenFileDAOImpl) {
		this.compBenFileDAOImpl = compBenFileDAOImpl;
	}

}
