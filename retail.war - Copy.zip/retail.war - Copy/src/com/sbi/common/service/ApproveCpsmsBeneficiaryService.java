/* 
 * ApproveCpsmsBeneficiaryService.java
 *
 *  This service is used to display the Files Uploaded.
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */



package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CpsmsBeneficiaryDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.model.CpsmsBeneficiary;
import com.sbi.common.utils.LoggingConstants;



/**
 * This class used for to display the ApproveThirdParty Information
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class ApproveCpsmsBeneficiaryService extends BaseService {

    private CpsmsBeneficiaryDAO cpsmsBeneficiaryDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    
     /**
     * call the [cpsmsBeneficiaryDAOImpl.findTPFiles(userName,userRole,bankType,startDate,endDate,functiontype)] return Map which is contains 
     * ApproveTpFile Names.
     * 
     * @param inputParams userName,userRole,bankType,startDate,endDate and functiontype
     * @return Map
     * 
     */
 
    public Map execute(Map inputParam) {
        logger.debug("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);

        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        Integer userRole=(Integer)inputParam.get("userRole");
        String userName = (String) inputParam.get("userName");
        String startDate = (String) inputParam.get("startDate");
        String endDate = (String) inputParam.get("endDate");
        String viewType = (String) inputParam.get("viewType");
        String fileName=(String) inputParam.get("fileName");
        String corporateId=(String) inputParam.get("corporateId");
        String recordsflag=(String)inputParam.get("recordsflag");
        String count=(String)inputParam.get("count");
        String bankCode=(String)inputParam.get("bankCode");  //Added for CPSMS associate banks
        
        // CR CPSMS Beneficiary details display
        String adminAccNo = (String) inputParam.get("accountNo");
        
        String beneficiaryType=null;
        String requestType=null;
        if(recordsflag!=null && recordsflag!=""){
        	beneficiaryType=(String)inputParam.get("beneficiaryType");
        	requestType=(String)inputParam.get("requestType");
        }
        
        CorporateFile[] corporateFile = null;
        Map fileDetails=new HashMap();
        CpsmsBeneficiary[] corporateTPArray = null;
        try {
        	
        	if("true".equals(recordsflag)&& corporateId != null
                    && corporateId.trim().length() > 0 && fileName!=null && fileName.trim().length()>0){
        		corporateTPArray=cpsmsBeneficiaryDAOImpl.findTPsByFile(corporateId, fileName, beneficiaryType, requestType, viewType,adminAccNo);
        		if (corporateTPArray != null && corporateTPArray.length >0) {
                    outParam.put("approveTPFileDetails", corporateTPArray);
                    response.setErrorStatus("success");
                } else {
                	 
                    response.setErrorCode("RTGS003"); 
                }
        		
        	}
        	else if("true".equals(count) && corporateId != null
                    && corporateId.trim().length() > 0 && fileName!=null && fileName.trim().length()>0){
        		
        		fileDetails=cpsmsBeneficiaryDAOImpl.findBenFiledetails(corporateId,fileName,viewType,adminAccNo);
        		if(!fileDetails.isEmpty() && fileDetails.size()>0){
        			 
        			int total_count=(Integer)fileDetails.get("intra_add") + 
        		      (Integer)fileDetails.get("inter_add")+ 
        		      (Integer)fileDetails.get("intra_del")+
        		      (Integer)fileDetails.get("inter_del")+
        		      (Integer)fileDetails.get("validation_fail");
        			fileDetails.put("total_count", total_count);
        			fileDetails.put("fileName", fileName);
        			outParam.put("approveTPFileDetails", fileDetails);
                    response.setErrorStatus("success");
        		}
        		else {
                    response.setErrorStatus("CR002");//Request cannot be processed currently
                }
        		
        	}
        	else if (corporateId != null
                    && corporateId.trim().length() > 0 ) {
                corporateFile = cpsmsBeneficiaryDAOImpl.findTPFiles(corporateId,startDate,endDate,viewType,bankCode,adminAccNo);
                
                if (corporateFile != null && corporateFile.length >0) {
                    outParam.put("approveTPFileDetails", corporateFile);
                    response.setErrorStatus("success");
                } else {
                	String errorCode=("approve".equals(viewType)?"RTGS003":"BENF001");
                	 /*if("approve".equals(viewType))
                		 response.setErrorCode("RTGS003"); //There are no Inter bank beneficiary files for approval.
                	 else
                		 response.setErrorCode("BENF001"); // No Approved/Rejected FILES to view.
                	  */  
                		response.setErrorCode(errorCode);
                	}

            } else {
                response.setErrorStatus("CR002");//Request cannot be processed currently
            }
        } catch (SBIApplicationException appex) {
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        } catch (Exception exp) {
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);
        }

        outParam.put("applicationResponse", response);
        if(logger.isDebugEnabled()){
        	logger.debug("outParam :" + outParam);
        	logger.debug("execute(Map inputParams)" + LoggingConstants.METHODEND);
        }

        return outParam;

    }


    public void setCpsmsBeneficiaryDAOImpl(CpsmsBeneficiaryDAO cpsmsBeneficiaryDAOImpl)
    {
        this.cpsmsBeneficiaryDAOImpl = cpsmsBeneficiaryDAOImpl;
    }

    

}
