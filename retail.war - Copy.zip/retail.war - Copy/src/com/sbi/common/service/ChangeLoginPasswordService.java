/* 
 * ChangeLoginPasswordService.java
 * Created on Dec 23, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 23, 2005 MURUGAN K - Initial Creation and Method implementation
//Jan, 2006 MURUGAN K - Logger changed
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.bp.ProfileBP;
import com.sbi.common.bp.LogonBP;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.Decrypt;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.model.User;

public class ChangeLoginPasswordService extends BaseService {

    protected final Logger logger = Logger.getLogger(getClass());

    private ProfileBP profileBP;
    private LogonBP logonBP;
    public Map execute(Map inputParams) {

        logger.info("execute(Map inputParams) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
            logger.debug("inputParams :" + inputParams);

        HashMap outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        User user = (User) inputParams.get(ServiceConstant.USER);
        String oldPwd = (String) inputParams.get(ServiceConstant.OLD_LOGIN_PASSWORD);
        String newPwd = (String) inputParams.get(ServiceConstant.NEW_PASSWORD);
        String keyid = (String)inputParams.get("keyid");
        String reTypePwd = (String) inputParams.get(ServiceConstant.CONFIRM_PASSWORD);
        try {        	
        	if (logger.isDebugEnabled())
            logger.debug("newPwd"+newPwd);
            if (oldPwd != null && newPwd != null && reTypePwd != null && keyid!=null&&keyid.trim().length()!=0) {//Modified for CR 5274
            	
            	newPwd = Decrypt.decrypt(keyid,newPwd); 
                oldPwd = Decrypt.decrypt(keyid,oldPwd);
                reTypePwd= Decrypt.decrypt(keyid,reTypePwd);
                if(newPwd.equals(reTypePwd)){
                	profileBP.changeLoginPassword(user, oldPwd, newPwd);
                    response.setErrorStatus(ServiceConstant.SUCCESS);
                	}
                	else{
                		response.setErrorCode("CPWD001");
                	}
            	}
               
            else {
                response.setErrorCode(ServiceErrorConstants.SE003);
            }
        }
        catch (SBIApplicationException appexp) {
            logger.error(LoggingConstants.EXCEPTION, appexp);
            response.setErrorCode(appexp.getErrorCode());
        }
        catch (Exception exp) {
            logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
        }

        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        logger.info("HashMap execute(HashMap inputParams) end " + LoggingConstants.METHODEND);
        return outParams;

    }

    public void setProfileBP(ProfileBP profileBP) {
        this.profileBP = profileBP;
    }
    public void setLogonBP(LogonBP logonBP) {
		this.logonBP = logonBP;
	}
}
