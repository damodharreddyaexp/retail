/*
 * GetLatestBalanceService.java
 * Created on Jan 11, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 11, 2006 MURUGAN K - Initial Creation
//Feb 01, 2006 RAMAKRISHNAREDDY - Logger changes

package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.AccountDAO;
import com.sbi.common.dao.TransactionHistoryDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.Account;
import com.sbi.common.utils.LoggingConstants;

public class GetLatestBalanceService extends BaseService {
    
    private AccountDAO accountDAOImpl;

    private TransactionHistoryDAO transactionHistoryDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams) {
    	logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceErrorConstants.FAILURE);
        HashMap outMap = new HashMap();
        List transactionHistoryList = null;
         try {

            String accountNo = (String) inputParams.get(ServiceConstant.ACCOUNT_NO);
            String branchCode = (String) inputParams.get(ServiceConstant.BRANCH_CODE);
            String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
          
            if (userName != null && accountNo != null && branchCode != null) {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (logger.isDebugEnabled())
                logger.debug("Account return by AccountDAOImpl is" + account);

                if (account != null) {
                    transactionHistoryList =  transactionHistoryDAOImpl.findLatestBalance(account);
                    if (transactionHistoryList != null && transactionHistoryList.size() > 0) {

                        outMap.put(ServiceConstant.ACCOUNT_DETAILS, account);
                        outMap.put(ServiceConstant.TRANSACTION_HISTORY, transactionHistoryList);
                        response.setErrorStatus(ServiceErrorConstants.SUCCESS);
                        
                        

                    }
                    else { 

                        response.setErrorCode(ServiceErrorConstants.SE101);
                    }

                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE001);

                }

            }
            else {

                response.setErrorCode(ServiceErrorConstants.SE003);
            }

        }
        catch (DAOException daoExp) {
        	logger.error(LoggingConstants.EXCEPTION, daoExp);
            response.setErrorCode(daoExp.getErrorCode());
        }
        catch (Exception daoExp) {
        	logger.error(LoggingConstants.EXCEPTION, daoExp);
            response.setErrorCode(ServiceErrorConstants.SE002);
        }
        outMap.put(ServiceConstant.APPLICATION_RESPONSE, response);
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return outMap;
    }

    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

    public void setTransactionHistoryDAOImpl(TransactionHistoryDAO transactionHistoryDAOImpl) {
        this.transactionHistoryDAOImpl = transactionHistoryDAOImpl;
    }
 
}