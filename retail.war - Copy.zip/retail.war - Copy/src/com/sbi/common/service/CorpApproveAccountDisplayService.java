package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.AccountDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

import com.sbi.common.service.BaseService;

public class CorpApproveAccountDisplayService extends BaseService {

	protected final Logger logger = Logger.getLogger(getClass());

	private AccountDAO accountDAOImpl;

	public Map execute(Map inputParams) {
		logger.info("Map execute(Map inputParams)"
				+ LoggingConstants.METHODBEGIN);
		logger.info("inparams :" + inputParams);
		String userName = (String) inputParams.get("userName");
		String corporateId = (String) inputParams.get("corporateId");

		Map map = new HashMap();
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus("failure");
		List accountList = new ArrayList();
		try {
			accountList = accountDAOImpl.findAccountsApprover(userName,corporateId);
			if (accountList != null && accountList.size() > 0) {
				logger.info("Accounts List size: " + accountList.size());
				map.put("accountList", accountList);
				response.setErrorStatus("success");
			} else {
				response.setErrorCode("SE001");
			}

		} catch (SBIApplicationException appexp) {
			logger.error(LoggingConstants.EXCEPTION, appexp);
			response.setErrorCode(appexp.getErrorCode());
		} catch (Exception exp) {
			response.setErrorStatus("failure");
			response.setErrorCode("SE002");
			logger.error(LoggingConstants.EXCEPTION, exp);
		}
		map.put("applicationResponse", response);

		return map;
	}

	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}

}
