/*
 * GeneratePPKITService.java
 * Created on Nov 17, 2010
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 17, 2010 Amar - Initial Creation

package com.sbi.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;


public class GeneratePPKITService extends BaseService{
	
	private final Logger logger=Logger.getLogger(getClass());
	private SBIApplicationResponse response=new SBIApplicationResponse();
	Map outParams=new HashMap();
	private UserDAO userDAOImpl;

	public Map execute(Map inputParams){

		logger.info(" execute(Map inputParams) - begin");
		response.setErrorStatus(ServiceConstant.FAILURE);
		List ppkitList=new  ArrayList();
		Map outParams = new HashMap();
		try{

			String userName = (String)inputParams.get("caUser");
			String corpId=(String)inputParams.get("corporateID");
			String ppID=(String)inputParams.get("ppID");
			String flag=(String)inputParams.get("flag");
			if (userName != null) {

				ppkitList = userDAOImpl.findPPKIT(userName,corpId,ppID,flag);
				logger.info("ppkitList in Service is::"+ppkitList);
				if (ppkitList != null && ppkitList.size() > 0) {
						response.setErrorStatus(ServiceConstant.SUCCESS);
						outParams.put("ppkitList", ppkitList);
					} else if((ppkitList == null || ppkitList.size() <= 0) && flag.equalsIgnoreCase("listViewC9")) {
						response.setErrorCode("C9F001");
					}else if((ppkitList == null || ppkitList.size() <= 0) && flag.equalsIgnoreCase("c7bView")) {
						response.setErrorCode("C7B001");
					}
				else {
						response.setErrorCode("PPK001");// No PP ID available for this user.
					}
				}else
					response.setErrorCode(ServiceErrorConstants.SE002);;
		

		}catch (DAOException daoException) {
			response.setErrorCode(daoException.getErrorCode());
		}catch (Exception exception) {
			exception.printStackTrace();
			response.setErrorCode(ServiceErrorConstants.SE002);;
		}
		outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);   
		logger.info(" execute(Map inputParams) - end");
		return outParams;
	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}
	
 }
