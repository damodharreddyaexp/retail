package com.sbi.common.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.service.BaseService;
import com.sbi.common.dao.DownloadChallanByDateDao;
import com.sbi.common.model.ChallanDetailsModel;



public class DownloadChallanByDateService extends BaseService {

	private DownloadChallanByDateDao downloadChallanByDateDaoImpl;
	
    private String nabFileDownload;

	private Logger logger = Logger.getLogger(getClass());

	public Map execute(Map inputParams) {
		Map outputParams = new HashMap();
		List challanDetailsList = null;
		logger.info("execute(Map inputParams) - begin ");
		logger.info("inputparams values..."+inputParams);
		SBIApplicationResponse response = new SBIApplicationResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		List modifyChallanList = new ArrayList();
		if(inputParams!=null && inputParams.size()>0){
			String corporateId = (String) inputParams.get(ServiceConstant.CORPORATEID);
			String start_date = (String) inputParams.get("start_date");
			ChallanDetailsModel challanDetails = null;
			String fileStatus=null;
			try {
	              if (corporateId != null) {
						challanDetailsList = downloadChallanByDateDaoImpl.getChallanDetails(corporateId, start_date);
						logger.info(" challanDetailsList size"+ challanDetailsList.size());
						if (challanDetailsList != null && challanDetailsList.size() > 0) {
							for (int i = 0; i < challanDetailsList.size(); i++) {
								challanDetails = (ChallanDetailsModel) challanDetailsList.get(i);
								String actualFileName = corporateId.concat(challanDetails.getFileName());
								String newPath = nabFileDownload+ actualFileName + ".html";
								logger.info(" actualFileName " + actualFileName	+ " newPath" + newPath);
								File file = new File(newPath);
								boolean exists = file.isFile();
								if (file.exists()) {
									// File or directory exists
									fileStatus=downloadChallanByDateDaoImpl.getFileStatus(corporateId,challanDetails.getFileName());
									logger.info(" fileStatus ="+fileStatus);
									if(fileStatus!=null){
									challanDetails.setStatus(fileStatus);
									}else{
									challanDetails.setStatus("Pending");	
									}
								}
									else{
									challanDetails.setStatus("Pending");
								}
								challanDetails.setModifiedFileName(actualFileName);
								modifyChallanList.add(challanDetails);
								// challanDetailsList.add(i,challanDetails);
							}
							   logger.info(" modifyChallanList size"+modifyChallanList.size());
			                    outputParams.put("challanDetailsList",modifyChallanList);
			                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
						}
						else
						{
							response.setErrorCode("BCD002");
						}
					}
	                    else{
	                    	
	                    	response.setErrorCode("BCD001");
	                    }
                 
                   
					
					//outputParams.put(ServiceConstant.FILE_NAME, file.getName());
				
			} catch (Exception e) {
				logger.error("Error occured :",e);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response
						.setErrorCode(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		else
			response.setErrorCode(ServiceErrorConstants.SE003);
		outputParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams) - end ");
		return outputParams;
	}

   

	public void setNabFileDownload(String nabFileDownload) {
		this.nabFileDownload = nabFileDownload;
	}



	public void setDownloadChallanByDateDaoImpl(
			DownloadChallanByDateDao downloadChallanByDateDaoImpl) {
		this.downloadChallanByDateDaoImpl = downloadChallanByDateDaoImpl;
	}

}
