/*
 * ApproveCpsmsBenConfirmService.java
 * Created on Jan '08 by Treesa
 *
 * Copyright (c) 2008 by SBI All Rights Reserved.
 */

package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CpsmsBeneficiaryDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.CpsmsBeneficiary;
import com.sbi.common.utils.LoggingConstants;

public class ApproveCpsmsBenConfirmService extends BaseService
{

    protected final Logger logger = Logger.getLogger(getClass());

    private CpsmsBeneficiaryDAO cpsmsBeneficiaryDAOImpl;

    /**
     * call the [thirdPartyDAOImpl.updateTPState(apprIds,unApprIds,
     * userName,banktype),updateTPStateALL(apprIds,unApprIds, userName)] to get the
     * ApproveFile Details return objectArray which is contains ApproveTpFile
     * Approve and UnApprove Details.
     * 
     * @param inputParams
     * @return Map
     * 
     */

    public Map execute(Map inputParam)
    {
        logger.info("execute(Map inputParams)" + LoggingConstants.METHODBEGIN);
        Map outParam = new HashMap();
        SBIApplicationResponse response;
        response = new SBIApplicationResponse();
        response.setErrorStatus("failure");
        String apprIds = null;
        boolean status = false;
        boolean deleted=false;
        CpsmsBeneficiary[] corporateTP = null;
        Object obapprId = null;
        Object approveIds = inputParam.get("approveIds");
        //added by Damodar
        String selectallcat = "";
        
         selectallcat = (String) inputParam.get("selectedall");
        logger.info("selectallcat : " + selectallcat);
        Object actionType=inputParam.get("actionType"); //Added for Reject Benificiary File
        String actionTypeStr="";
        if(actionType!=null)
        	actionTypeStr=actionType.toString();
        
       // Object obapprId = inputParam.get("approveIds");
      //  Object obunApprId = inputParam.get("unApproveIds");
//        <!-- Ramanan M - SR-88046 - Delete3P Defect-->
		if (approveIds != null	&& (approveIds.toString().length() > 0)) {
			//condition changed for SR93990 ends here
         obapprId = inputParam.get("approveIds");
        } 
        String filename = (String) inputParam.get("tpFileName");
        String Adminaccno = (String) inputParam.get("accountNo");
        //int index = fileName.indexOf('.');
        //String filename = fileName.substring(0, index);
        String userName = (String) inputParam.get("userName");
        String bankType = (String) inputParam.get("bankType");// added for default file config
        String functionType = (String) inputParam.get("functionType");
        /* Ramanan M - Corp Admin Paladion Security Changes */
        String corporateID = (String) inputParam.get("coporateID");
        logger.info("tpName :" + filename +"bankType :"+bankType+"functionType :"+functionType+ " coporateID:" + corporateID+" adminaccountno:" + Adminaccno);
        logger.info("obapprId : " + obapprId);
        try
        {
            if (userName != null && !userName.equals(""))
            {

                if (obapprId != null)
                {
                    apprIds = (String) obapprId;
                    logger.info(" apprIds  " +apprIds);
                    	            		
                    	if("Reject".equals(actionTypeStr))
                    	
                    		
                			status = cpsmsBeneficiaryDAOImpl.rejectTPState(apprIds,functionType, userName, bankType, corporateID,selectallcat,filename,Adminaccno);
                		else 
                			
                			if (selectallcat != null )
                	        {
                				 if(selectallcat.equalsIgnoreCase("YES"))
                        	   {
                    			 status = cpsmsBeneficiaryDAOImpl.updateAllTPState(apprIds,functionType, userName, bankType, corporateID,filename,Adminaccno);
                    		  
                        	   }
                	        }
                		
                     
                			else
                			
                				status = cpsmsBeneficiaryDAOImpl.updateTPState(apprIds,functionType, userName, bankType, corporateID);
                    	
                    	
                    	
                		
                    logger.info("status :" + status);
                   
                    if (status)
                    {
                    	
                    	if (filename != null && filename.trim().length() > 0)
                        {
                                corporateTP = cpsmsBeneficiaryDAOImpl.findTPdetails(userName, filename, apprIds,bankType,functionType);
                            
                            logger.info("corporateTP.length  " + corporateTP.length);
                            
                            if (corporateTP.length >= 1)
                            {
                                 
                                if (corporateTP != null)
                                {
                                    outParam.put("approveTPFileConfirmDetails", corporateTP);
                                    response.setErrorStatus("success");
                                }
                                else
                                {
                                    response.setErrorCode("CR001");
                                }
                            }
                            else
                            {
                                response.setErrorCode("CR002");
                            }
                        }
                        else
                        {
                            response.setErrorCode("CR002");
                        }
                    }
                    else
                    {
                        response.setErrorCode("CR011");

                    }
                }
                else
                {

                    response.setErrorCode("CR002");
                }
            }

            else
            {

                response.setErrorCode("CR002");
            }

        }
        catch (SBIApplicationException appex)
        {
            response.setErrorStatus("failure");
            logger.error(LoggingConstants.EXCEPTION + appex);
            response.setErrorCode(appex.getErrorCode());
        }
        catch (DAOException daoException)
        {
            response.setErrorStatus("failure");
            response.setErrorCode(daoException.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION, daoException);
        }
        catch (Exception exp)
        {
            response.setErrorStatus("failure");
            response.setErrorCode("SE002");
            logger.error(LoggingConstants.EXCEPTION + exp);

        }

        outParam.put("applicationResponse", response);

        return outParam;
    }

    
    public void setCpsmsBeneficiaryDAOImpl(CpsmsBeneficiaryDAO cpsmsBeneficiaryDAOImpl)
    {
        this.cpsmsBeneficiaryDAOImpl = cpsmsBeneficiaryDAOImpl;
    }

}
