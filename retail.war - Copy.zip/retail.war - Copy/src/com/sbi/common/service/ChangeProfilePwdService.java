/* 
 * ChangeProfilePwdService.java
 * Created on Dec 23, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 23, 2005 MURUGAN K - Initial Creation and Method implementation
//Jan, 2006 MURUGAN K - Logger changed
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.bp.ProfileBP;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.Decrypt;//Added For CR 5274
import com.sbi.common.utils.LoggingConstants;

/**
 * Accepts the new and old passwords in the input map and forwards the
 * request to the ProfileBP's updateProfilePassword method.
 */
public class ChangeProfilePwdService extends BaseService {

    protected final Logger log = Logger.getLogger(getClass());

    private ProfileBP profileBP;

    public Map execute(Map inputParams) {
        log.info("HashMap Execute(HashMap inputParams)" + LoggingConstants.METHODBEGIN);
        HashMap outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        User user = (User) inputParams.get(ServiceConstant.USER);
        //modification for CR 5274      
        String keyId = (String) inputParams.get("keyid");
        String newPwd=(String) inputParams.get(ServiceConstant.NEW_PASSWORD);
        String oldPwd=(String) inputParams.get(ServiceConstant.OLD_PROFILE_PASSWORD);
        String reTypeProfilePwd=(String) inputParams.get(ServiceConstant.CONFIRM_PASSWORD);
        try {        	
            if (oldPwd != null && newPwd != null && reTypeProfilePwd != null && keyId!=null && keyId.trim().length()!=0) {
            	//Added for cr 5274 Starts
            	newPwd = Decrypt.decrypt(keyId,newPwd); 
                oldPwd = Decrypt.decrypt(keyId,oldPwd); 
                reTypeProfilePwd = Decrypt.decrypt(keyId,reTypeProfilePwd);
                if(newPwd.equals(reTypeProfilePwd)){
                	UserProfile userProfile = profileBP.changeProfilePassword(newPwd, oldPwd, user);
                    response.setErrorStatus(ServiceConstant.SUCCESS); 
                }
                else{
                	response.setErrorCode("CPWD002");
                }
                                              
            }
            else {
                response.setErrorCode(ServiceErrorConstants.SE003);
            }
        }
        catch (SBIApplicationException appexp) {
            log.error(LoggingConstants.EXCEPTION, appexp);
            response.setErrorCode(appexp.getErrorCode());
        }
        catch (Exception exp) {
            log.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }

        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        log.info("HashMap Execute(HashMap inputParams)" + LoggingConstants.METHODEND);
        return outParams;

    }

    public void setProfileBP(ProfileBP profileBP) {
        this.profileBP = profileBP;
    }

}
