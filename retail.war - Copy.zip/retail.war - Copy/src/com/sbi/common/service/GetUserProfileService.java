/*
 * GetUserProfileService.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 MURUGAN K - Initial Creation
//Feb 01, 2006 RAMAKRISHNAREDDY - Logger changes


package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.common.cache.ReferenceDataCache;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.dao.BranchMasterDAO;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.LoggingConstants;

public class GetUserProfileService extends BaseService {
    protected final Logger logger = Logger.getLogger(getClass());

    private UserDAO userDAOImpl;

    private AccountDAO accountDAOImpl;
    
    private BranchMasterDAO branchMasterDAOImpl;
    
    private ReferenceDataCache referenceDataCache;

    public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
        this.branchMasterDAOImpl = branchMasterDAOImpl;
    }

    public Map execute(Map inputParams) {
    	logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
    	if (logger.isDebugEnabled())
        logger.debug("inputparams Map:" + inputParams);
        Map outParams = new HashMap();
        UserProfile profile = null;
        List locationList = null;

        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        String viewStatus = (String) inputParams.get(ServiceConstant.VIEW_STATUS);// "profileLimitDispaly");
        try {

            if (userName != null) {

                profile = userDAOImpl.findUserProfile(userName);
                if (logger.isDebugEnabled())
                logger.debug("Profile " + profile);
                if (profile != null) {
                    if (viewStatus != null && viewStatus.trim().equalsIgnoreCase("profilelimitDispaly")) {
                        Double maxTpLimit = accountDAOImpl.findMaximumTPAccountLimit(userName);
                        outParams.put(ServiceConstant.TP_MAX_LIMIT, maxTpLimit );
                    }
                    else if(viewStatus !=null && viewStatus.trim().equalsIgnoreCase("corpAddTPDispaly") )
                    {
                        locationList = branchMasterDAOImpl.findINBLocation(profile.getBankCode());
                        outParams.put("locationList",locationList);
                    }
                    
                    if(profile.getMobileNumber() != null ) {
                    	
                    	// Check whether the users mobile number is applicable for enabling  Voice OTP
                    	if(inputParams.get("enableVoiceOTP") != null && "yes".equalsIgnoreCase((String) inputParams.get("enableVoiceOTP"))) {
                    		Boolean isValidVoiceOTP =false;
                    			Map voiceOTPSeriesdata = referenceDataCache.getReferenceData("voiceOTPSeries");
                			if(voiceOTPSeriesdata.containsKey(profile.getMobileNumber().substring(0,4)) )
                			{
                				isValidVoiceOTP=true;
                			} 
                    		outParams.put("enableVoiceOTP", isValidVoiceOTP); 
                    	}
                    	
                    }
                    response.setErrorStatus(ServiceConstant.SUCCESS);

                }
                else {
                    response.setErrorCode(ServiceErrorConstants.SE002);
                }
            }

        }
        catch (Exception exp) {
            logger.error("Exception occured :" + exp);
            response.setErrorStatus(ServiceConstant.FAILURE);
            response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }

        outParams.put(ServiceConstant.USER_PROFILE, profile);
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
        {
        logger.debug("profile.getProfilepassword(): " + profile.getProfilepassword());
        logger.debug("outParams Map contains: " + outParams);
        }
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return outParams;

    }

    public void setUserDAOImpl(UserDAO userDAOImpl) {
        this.userDAOImpl = userDAOImpl;
    }
  
    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

	
	public void setReferenceDataCache(ReferenceDataCache referenceDataCache) {
		this.referenceDataCache = referenceDataCache;
	}

    
}