package com.sbi.common.service;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import com.sbi.common.dao.DematDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;


public class DisplayUnmarkDetailsService extends BaseService {
	
    private DematDAO dematDAOImpl;

    private final Logger logger=Logger.getLogger(getClass());
    
    private SBIApplicationResponse response=new SBIApplicationResponse();
    
    public Map execute(Map inputParams){
    	
        logger.info("DisplayUnmarkDetailsService " +LoggingConstants.METHODBEGIN);
        Map outParams=new HashMap();
        Map resultParams=new HashMap();
        List userEbrokingDetails=new ArrayList();
        List accountList =new ArrayList();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName=(String)inputParams.get("userName");
       logger.info("user name in DisplayUnmarkDetailsService"+userName);
        int size;
    	int lienStatusCount=0;
		String lienRefNo="";
		Double amount=0.0;
		Double lienAmount=0.0;
        try {
        	if(userName!=null){
        		
        		int accCount=dematDAOImpl.getAcccountCount(userName);
        		logger.info("account count in DisplayUnmarkDetailsService "+accCount);
        		
        		if(accCount>0){
        			
        		
        		userEbrokingDetails=dematDAOImpl.getEbrokingDetailsForCorp(userName);
        		if(userEbrokingDetails != null && userEbrokingDetails.size() >0){
					logger.info("userEbrokingDetails size1111"+userEbrokingDetails.size());
					logger.info("userEbrokingDetails222222 "+userEbrokingDetails.get(0));
					size=userEbrokingDetails.size();
					String eBrokingId=null;
					if(size==1){			
						eBrokingId=(String)((Map)userEbrokingDetails.get(0)).get("EBROKING_ID");
						logger.info("eBrokingId"+eBrokingId);
						lienStatusCount=dematDAOImpl.getEbrokingStatus(eBrokingId);
			
						logger.info("lienStatusCount"+lienStatusCount);
						if(lienStatusCount==0){
							
							 lienAmount=dematDAOImpl.getEbrokingLienAmount(eBrokingId);
							logger.info("lienAmount"+lienAmount);
							if(lienAmount!=0.0){
							outParams=dematDAOImpl.getLienReferenceNo(eBrokingId);
							logger.info("AMOUNT"+outParams.get("AMOUNT"));
								if(outParams.get("REFERENCE_NO")!=null&&outParams.get("AMOUNT")!=null)
								{
									lienRefNo=(String)outParams.get("REFERENCE_NO");
									logger.info("lienRefNo"+lienRefNo);
									amount=Double.parseDouble(outParams.get("AMOUNT").toString());
									logger.info("amount"+amount);
									outParams.put("lienRefNo", lienRefNo);
									outParams.put("amount", amount);
									outParams.put("lienAmt",lienAmount);
								}
								else{
								outParams.put("lienAmt",lienAmount);
								outParams.put("lienRefNo", "0");
								outParams.put("amount", amount);	
								}
							}
							else{
							outParams.put("lienAmt",lienAmount);
							outParams.put("lienRefNo", "0");
							outParams.put("amount", amount);		
							}
							}
					
						else{
							outParams.put("lienAmt",lienAmount);
							outParams.put("lienRefNo", lienRefNo);
							outParams.put("amount", amount);
							outParams.put("lienStatusCount",lienStatusCount);	
							}
						outParams.put("lienStatusCount",lienStatusCount);
						outParams.put("userEbrokingDetails",userEbrokingDetails);
						outParams.put("size",size);
						outParams.put("eBrokingId",eBrokingId);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					}
					outParams.put("userEbrokingDetails",userEbrokingDetails);
					outParams.put("size",size);
					outParams.put("eBrokingId",eBrokingId);
	                response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				}
        		else{					
					response.setErrorCode("NOW001");
					response.setErrorStatus(ServiceErrorConstants.FAILURE);
				}
        		}else{					
					response.setErrorCode("NOW002");
					response.setErrorStatus(ServiceErrorConstants.FAILURE);
				}
        	}
        	
 } catch(SBIApplicationException aex){
        	response.setErrorCode(aex.getErrorCode());
        }
 catch (Exception exception) {
        	logger.error("Exception :",exception);
        	response.setErrorCode(ServiceErrorConstants.SE002);
          
        }
 		outParams.put(ServiceConstant.APPLICATION_RESPONSE,response);
       logger.info("execute(Map inputParams) " +LoggingConstants.METHODEND);
        return outParams;
        
    }
	public void setDematDAOImpl(DematDAO dematDAOImpl) {
		this.dematDAOImpl = dematDAOImpl;
	}
}

