/* 
 * CoreOffLineMessageService.java
*/
package com.sbi.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.common.dao.CoreOffLineMessageDAO;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;

public class CoreOffLineMessageService extends BaseService {

    protected final Logger logger = Logger.getLogger(getClass());
    
    private String coreOfflineRole;
    private CoreOffLineMessageDAO coreOffLineMessageDAOImpl;
    

    public Map execute(Map inputParams) {

        logger.info("execute(Map inputParams) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
            logger.debug("inputParams :" + inputParams);

        HashMap outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.SUCCESS);
        
       
        try {
        	logger.info("inputParams :" + inputParams);
        	String bankCode = (String)inputParams.get(ServiceConstant.BANK_CODE);
       		coreOfflineRole = (String)inputParams.get("userRole");
        	logger.info("coreOfflineRole ::"+coreOfflineRole);
        	List coreMessage = coreOffLineMessageDAOImpl.getCoreOffLineMessage(bankCode,coreOfflineRole);        	
        	if(coreMessage != null){
        		logger.info("coreMessage size="+coreMessage.size()); 
        	}
        	if(logger.isDebugEnabled())
            logger.debug("coreMessage :" + coreMessage);
        	logger.info("coreMessage="+coreMessage);
        	outParams.put("coreMsg",coreMessage);
        	
        }       
        catch (Exception exp) {      	
        	logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
        }
        
       
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        logger.info("HashMap execute(HashMap inputParams) end " + LoggingConstants.METHODEND);
        return outParams;

    }



	public void setCoreOffLineMessageDAOImpl(
			CoreOffLineMessageDAO coreOffLineMessageDAOImpl) {
		this.coreOffLineMessageDAOImpl = coreOffLineMessageDAOImpl;
	}

    

}
