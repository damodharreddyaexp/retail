/*
 * GetUserBranchService.java
 * Created on Dec 22, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 22, 2005 MURUGAN K - Initial Creation
//Feb 01, 2006 RAMAKRISHNAREDDY - Logger changes
package com.sbi.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ProfileDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;
import com.sbi.common.utils.LoggingConstants;
public class GetUserBranchService extends BaseService {
 
    ProfileDAO profileDAOImpl;
   

    protected final Logger logger = Logger.getLogger(getClass());

    public Map execute(Map inputParams)

    {
    	logger.info("execute(Map inputParams) method begin "+LoggingConstants.METHODBEGIN);
        Map outParams = new HashMap();
        SBIApplicationResponse response = new SBIApplicationResponse();
        response.setErrorStatus(ServiceConstant.FAILURE);
        String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
        String bankSystem = (String) inputParams.put(ServiceConstant.BANK_SYSTEM,ServiceConstant.CORE_NONCORE_SYSTEM);
        Map branchNameCode = null;        
        try

        {
            if (userName != null) {

	                branchNameCode = profileDAOImpl.findUserBranches(userName, bankSystem);
	
	                if (branchNameCode != null) {
	
	                    outParams.put(ServiceConstant.BRANCH_LIST, branchNameCode);
	                    
	                    response.setErrorStatus(ServiceErrorConstants.SUCCESS);
	
	                }
	                else {
	                	response.setErrorCode(ServiceErrorConstants.SE060);
	                }
            	}

            else {
            	if (logger.isDebugEnabled())
                logger.debug("Input values from Handler are null");
            }

        }
        catch (SBIApplicationException sbiExc) {
            response.setErrorCode(sbiExc.getErrorCode());
            logger.error(LoggingConstants.EXCEPTION,sbiExc);
        }
        catch (Exception exp) {
        	logger.error(LoggingConstants.EXCEPTION, exp);
            response.setErrorCode(ServiceErrorConstants.SE002);
            exp.printStackTrace();
        }
        outParams.put(ServiceConstant.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
        logger.debug("output Map contains :" + outParams);
        logger.info("execute(Map inputParams) method end"+ LoggingConstants.METHODEND);
        return outParams;
    }

    public void setProfileDAOImpl(ProfileDAO profileDAOImpl) {
        this.profileDAOImpl = profileDAOImpl;
    }
}
