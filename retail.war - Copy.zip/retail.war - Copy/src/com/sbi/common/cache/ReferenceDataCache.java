/*  
 * ReferenceDataCache.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History 
//Oct 18, 2005 BOOPATHI - Initial Creation
//Nov 07,2005 MURUGAN K - logs added
//NOV 23 , 2005 CONSTANTS ADDED
//NOV 23, 2005 ACCOUNTNAME MAP ADDED
package com.sbi.common.cache;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ProfileDAO;
import com.sbi.common.dao.SBINameValueMasterDAO;
import com.sbi.common.dao.BranchMasterDAO;

public class ReferenceDataCache
{
    private Hashtable cacheReferenceData = new Hashtable();

    private SBINameValueMasterDAO sbiNameValueMasterDAOImpl;
    
    private ProfileDAO profileDAOImpl;
    
    private BranchMasterDAO branchMasterDAOImpl; //Added for eTDR/eSTDR

    protected final Logger logger = Logger.getLogger(getClass());

    private void init()
    {

        logger.info(" init() begin ");
        HashMap coreErrorData = (HashMap) sbiNameValueMasterDAOImpl.getSBICoreErrorData();
        String coreErrorKey = DAOConstants.CORE_ERRORS;
        if (coreErrorData != null)
            setReferenceData(coreErrorKey, coreErrorData);

        HashMap switchErrorData = (HashMap) sbiNameValueMasterDAOImpl.getSBISwitchErrorData();
        String switchErrorKey = DAOConstants.SWITCH_ERRORS;
        if (switchErrorData != null)
            setReferenceData(switchErrorKey, switchErrorData);

        HashMap data = (HashMap) sbiNameValueMasterDAOImpl.getNameValueMasterData();
        String key = DAOConstants.TRANSACTION_LIMIT;
        if (data != null)
            setReferenceData(key, data);
        
        
        HashMap branchData = (HashMap) sbiNameValueMasterDAOImpl.findAllBranchName();
        String branchDataKey = DAOConstants.BRANCH_DATA_KEY;
        if (data != null)
            setReferenceData(branchDataKey, branchData);
       
        //Added for eTDR/eSTDR -Start
        if(branchMasterDAOImpl!=null) {
	        HashMap allBranchData = (HashMap) branchMasterDAOImpl.findAllBranchesWithCode();
	        String allBranchDataKey = "allBranchDataKey";
	        if (data != null)
	            setReferenceData(allBranchDataKey, allBranchData);
        }
        //Added for eTDR/eSTDR -End
        
        /* set the Country Name and Codes  from ProfileDAOImpl.findCountryNameCodes() */
       
    
        HashMap countryNameCodes = (HashMap) profileDAOImpl.findCountryNameCodes();
        String countryNameCodesKey = DAOConstants.COUNTRY_NAME_CODE;
        if (countryNameCodes != null)
        {
            setReferenceData(countryNameCodesKey, countryNameCodes);
        } 
        
        /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
        HashMap nreProductCodes = (HashMap) sbiNameValueMasterDAOImpl.findAllNREProductCodes();
        String nreProductCodesKey = DAOConstants.NRE_PRODUCT_CODES;
        if (nreProductCodes != null)
        {
            setReferenceData(nreProductCodesKey, nreProductCodes);
        } 
        /*	CR-5655 Ramanan M - END - NRE check through Product Code	*/
		/* Added for Voice OTP */
        
        HashMap voiceOTPSeries = (HashMap) profileDAOImpl.findVoiceOTPMobileSeries();
        if (voiceOTPSeries != null)
        {
            setReferenceData(DAOConstants.VOICE_OTP_SERIES, voiceOTPSeries);
        } 
        /* End of Voice OTP */
        Map accountName = new HashMap();
        accountName.put(DAOConstants.A1, DAOConstants.SAVINGS_ACCOUNT);
        accountName.put(DAOConstants.A2, DAOConstants.CURRENT_ACCOUNT);
        accountName.put(DAOConstants.A3, DAOConstants.CASH_CREDIT);
        accountName.put(DAOConstants.A4, DAOConstants.OD_ACCOUNT);
        accountName.put(DAOConstants.A5, DAOConstants.DEPOSIT_ACCOUNT);
        accountName.put(DAOConstants.A6, DAOConstants.LOAN_ACCOUNT);
        accountName.put(DAOConstants.B1, DAOConstants.PPF_ACCOUNT);
        accountName.put(DAOConstants.A8,DAOConstants.TRADE_ACCOUNT);
        accountName.put(DAOConstants.A9,DAOConstants.TRADE_ACCOUNT);
        accountName.put(DAOConstants.B2,DAOConstants.BROKER_ACCOUNT);	 // <!-- IR 71227-->
        
        //added by archana for GVF CR5160
        accountName.put("AdvanceAcct", "Advance Account");
        accountName.put("DebitAccount", "Debit Account");
        accountName.put("DebitInterestAcct", "Debit Interest");
        accountName.put("CreditAccount","Credit Account");
        accountName.put("CreditCommissionChargeAcct","Credit Commission Charge");
        accountName.put("CreditInterestAcct","Credit Interest");
        accountName.put("CreditPostageChargeAcct","CreditPostageCharge");
        accountName.put("CreditProcessingChargeAcct","Credit Processing Charge");
        accountName.put("CreditTaxAcct","Credit Tax");
       	accountName.put("DebitCommissionChargeAcct","Debit Commission Charge");
        accountName.put("DebitPostageChargeAcct","Debit Postage Charge");
        accountName.put("DebitProcessingChargeAcct","Debit Processing Charge");
        accountName.put("DebitTaxAcct","Debit Tax");
        setReferenceData(DAOConstants.ACCOUNTNAME_KEY, accountName);

        logger.info(" init() end ");

    }

    /**
     * TODO Get the HashMap value from Hashtable with reference of the key
     * @param key String 
     * @return HashMap 
     */
    public HashMap getReferenceData(String key)
    {
        logger.info("getReferenceData( String key ) begin");
        /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	- Included one more condition NRE_PRODUCT_CODES*/
        if (key.equalsIgnoreCase(DAOConstants.SWITCH_ERRORS)
				|| key.equalsIgnoreCase(DAOConstants.TRANSACTION_LIMIT)
				|| key.equalsIgnoreCase(DAOConstants.CORE_ERRORS)
				|| key.equalsIgnoreCase(DAOConstants.ACCOUNTNAME_KEY)
				|| key.equalsIgnoreCase(DAOConstants.BRANCH_DATA_KEY)
				|| key.equalsIgnoreCase(DAOConstants.COUNTRY_NAME_CODE)
				|| key.equalsIgnoreCase(DAOConstants.NRE_PRODUCT_CODES))
        {
            HashMap h = (HashMap) cacheReferenceData.get(key);
            logger.info(" The Key value is 	~~~~~~~~~~~>>> " + key);
            if (h != null)
            {
            	logger.info("getReferenceData( String key ) end");
                return h;
            }
            else
            {
                init();
                HashMap data = (HashMap) cacheReferenceData.get(key);
                logger.info("getReferenceData( String key ) end");
                return data;
            }
        }
        else
        {

            HashMap h = (HashMap) cacheReferenceData.get(key);
            logger.info("getReferenceData( String key ) end");
            return h;

        }
    }

    /**
     * TODO Set the Map value into the Hashtable with reference of the key
     * @param key String
     * @param value Map
     */
    public void setReferenceData(String key, Map value)
    {
        logger.info("setReferenceData( String key, Map value )begin");
        cacheReferenceData.put(key, value);
        logger.info("setReferenceData( String key, Map value )end");
    }

    /** 
     * TODO Remove the Map value from Hashtable with reference of the key
     * @param key String
     */
    public void removeReferenceData(String key)
    {
        logger.info("removeReferenceData( String key )begin");
        cacheReferenceData.remove(key);
        logger.info("removeReferenceData( String key )end");
    }

    /**
     * TODO SBINameValueMasterDAOImpl injection 
     * @param sbiNameValueMasterDAOImpl SBINameValueMasterDAO
     */
    public void setSbiNameValueMasterDAOImpl(SBINameValueMasterDAO sbiNameValueMasterDAOImpl)
    {
        this.sbiNameValueMasterDAOImpl = sbiNameValueMasterDAOImpl;

    }

    public void setProfileDAOImpl(ProfileDAO profileDAOImpl) {
        this.profileDAOImpl = profileDAOImpl;
    }

	//Added for eTDR/eSTDR -Start
	public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}
	//Added for eTDR/eSTDR -End
   

 
}

