package com.sbi.common.cache;

public class CorePropertiesDataCache extends UserSessionCache{

}
