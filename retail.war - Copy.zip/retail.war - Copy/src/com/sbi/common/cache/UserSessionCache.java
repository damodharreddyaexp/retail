/*
 * UserSessionCache.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
package com.sbi.common.cache;

import java.util.Hashtable; 
import org.apache.log4j.Logger;

public class UserSessionCache
{
    private Hashtable userSessionCache = new Hashtable();

    protected final Logger logger = Logger.getLogger(getClass());

    /**
     * TODO Get the data from Hashtable with reference of the key
     * @param key String 
     * @return Object 
     */
    public Object getData(String key)
    {
        //logger.info("getData() method begin - key :" + key);
        //logger.info("getData() method end");
        return userSessionCache.get(key);
    }

    /**
     * TODO Set the Object value into the Hashtable with reference of the key 
     * @param key String 
     * @param value Object
     */
    public void setData(String key, Object value)
    {
        //logger.info("setData() method begin - key :" + key + " and value :" + value.toString());
        userSessionCache.put(key, value);
        //logger.info("setData() method end");
    }

    /**
     * TODO Remove the value from Hashtable with reference of the key
     * @param key String
     */
    public void removeData(String key)
    {
        //logger.info("removeData() method begin - key :" + key);
        userSessionCache.remove(key);
        //logger.info("removeData() method end");

    } 

}
