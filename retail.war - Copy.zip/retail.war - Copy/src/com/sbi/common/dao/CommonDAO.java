package com.sbi.common.dao;

import java.util.Map;

import com.sbi.common.exception.DAOException;

public interface CommonDAO {
	public boolean execute(String query,Object[] params) throws DAOException;
	
	public String getRegisteredCreatedUser(String accountNo, String userName);//Added by Sulthan for IR71772
	
	public Map getPaymentMode(String refNo, String merchantCode); // Changes for Other Banks Internet Banking

}
