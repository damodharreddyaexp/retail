package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.utils.LoggingConstants;
   
public  class ViewRejectMobileNoDAOImpl extends JdbcDaoSupport implements ViewRejectMobileNoDAO{
	
	  protected final Logger logger = Logger.getLogger(getClass());
	  
	  
	  public static final String FINE_MOBILENO_PENDINGLIST = "select * from sbicorp_user_mobile_no where user_id=? order by creation_time desc";

	  public static final String UPDATE_MOBILENO_STATUS = "update sbicorp_user_mobile_no set status='Rejected',reject_reason=? where reference_no=? and status='Pending'";

	 /* public static final String FINE_MOBILENO_PENDINGLIST_FOR_USER = "SELECT D.REFERENCE_NO,B.mobile_no,D.NEW_MOBILE_NO," +
		"A.USER_ALIAS,D.STATUS,D.USER_ID FROM BV_USER A , " +
		"BV_USER_PROFILE B , SBICORP_USER_MOBILE_NO D " +
		"WHERE A.USER_ID = B.USER_ID " +
		"AND A.USER_ID=D.USER_ID " +
		"AND A.USER_STATE=0 " +
		"AND B.CREATED_BY=? AND STATUS='Pending'"; */
	  
	/*  public static final String FINE_MOBILENO_PENDINGLIST_FOR_USER = "select D.REFERENCE_NO,c.mobile_no,D.NEW_MOBILE_NO," +
		" b.USER_ALIAS,D.STATUS,D.USER_ID from  sbicorp_ca_user_map a,bv_user b, bv_user_profile c," +
		"SBICORP_USER_MOBILE_NO D where  a.ca_user =?  and  b.user_alias =a.user_name  and " +
		" b.user_id = c.user_id  and  c.user_id = d.user_id AND d.STATUS='Pending'";  */
	  
	  
	  public static final String FINE_MOBILENO_PENDINGLIST_FOR_USER = "SELECT D.REFERENCE_NO,B.mobile_no,D.NEW_MOBILE_NO, A.USER_ALIAS,D.STATUS,D.USER_ID FROM BV_USER A , BV_USER_PROFILE B , SBICORP_USER_MOBILE_NO D WHERE D.CORPORATE_ID = ? AND A.USER_ID = B.USER_ID AND A.USER_ID=D.USER_ID AND A.USER_STATE=0 AND B.CREATED_BY=? AND STATUS='Pending'";
		  
	  public static final String REJECT_MOBILENO_CONFIRM_FOR_USER = "update sbicorp_user_mobile_no set status='Rejected',last_mod_time=sysdate where reference_no=?";
	  
	  class ViewRejectMobileNoDetailsRowMapper implements ResultSetExtractor{
			List<Map> returnList = new ArrayList<Map>();
			public Object extractData(ResultSet rs) throws SQLException{
				while(rs.next()){
				Map<String,String> dataMap=new HashMap<String,String>();
				dataMap.put("id",rs.getString("user_id"));
				dataMap.put("referenceNo",rs.getString("reference_no"));
				dataMap.put("oldMobileNo",rs.getString("old_mobile_no"));
				dataMap.put("newMobileNo",rs.getString("new_mobile_no"));
				dataMap.put("status",rs.getString("status"));
				returnList.add(dataMap);
				}
				return returnList;
			}
			
		}


	public List viewRejectMobileNoDetails(Map inParam) throws DAOException {
		 logger.info("viewRejectMobileNoDetails Method - begin " );
		String userAlias=(String)inParam.get("userId");
		 logger.info("userAlias :"+userAlias );
		List regMobileNoList=null;
		try{
			  Object [] params={userAlias};        
              int[] types = new int[]{Types.VARCHAR};
              regMobileNoList=(List)getJdbcTemplate().query(FINE_MOBILENO_PENDINGLIST,params,types,new ViewRejectMobileNoDetailsRowMapper()); 
              
		}catch(DataAccessException dataAccessException) {           
            dataAccessException.printStackTrace();
            DAOException.throwException("F001",new Object[] { }); //Due to Tech Problems
			
		}
		logger.info("viewRejectMobileNoDetails Method - end " );
		return regMobileNoList;
	}
	
	
	public int rejectMobileNoConfirm(Map inParam) throws DAOException {
		logger.info("rejectMobileNoConfirm - begin" );
		String userAlias="Rejected by "+(String)inParam.get("userAlias");
		String referenceNo=(String)inParam.get("referenceNo");	
		logger.info(" userAlias :"+userAlias );
		logger.info("referenceNo :"+referenceNo );
		int count=0;
		try{
			  Object [] params={userAlias,referenceNo,};        
              int[] types = new int[]{Types.VARCHAR};
              count=getJdbcTemplate().update(UPDATE_MOBILENO_STATUS,params); 
              logger.info("=====count end====="+count );
		}catch(DataAccessException dataAccessException) {           
            dataAccessException.printStackTrace();
            DAOException.throwException("F001",new Object[] { }); //Due to Tech Problems
			
		}
		logger.info("rejectMobileNoConfirm - end" );
		return count;
	}  
	public List viewRejectMobileNoDetailsUser(Map inParam) throws DAOException {
	
		logger.info("viewRejectMobileNoDetailsUser - begin");
		String userAlias = (String) inParam.get("userAlias");
		String corpId = (String)inParam.get("corporateId");
		logger.info("corporateId #############"+corpId);
		List regMobileNoList = null;
		int count=0;
		String flag=(String)inParam.get("flag");
		try {
			if(flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("cancelviewuser")){
			
				Object[] params = {corpId,userAlias };
				regMobileNoList = (List) getJdbcTemplate().query(FINE_MOBILENO_PENDINGLIST_FOR_USER, params,new ViewRejectMobileNoDetailsForUserRowMapper());
				
			}
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			DAOException.throwException("F001", new Object[] {}); 		}
		logger.info("viewRejectMobileNoDetailsUser - end");
		return regMobileNoList;
	} 
	
	class ViewRejectMobileNoDetailsForUserRowMapper implements ResultSetExtractor{
		List<Map> returnList = new ArrayList<Map>();
		public Object extractData(ResultSet rs) throws SQLException{
			while(rs.next()){
			Map<String,String> dataMap=new HashMap<String,String>();
			dataMap.put("referenceNo",rs.getString("reference_no"));
			String oldMobileNumberWithCode = rs.getString("mobile_no");
			String newMobileNumberWithCode = rs.getString("new_mobile_no");
			 String mobileNo = "";
			 String newNobileNo = "";
	            String coutryCode = "";
	            String newCoutryCode = "";
	            String busContryCode="";
	            String tmpMobileNo = "";
			if (oldMobileNumberWithCode != null && oldMobileNumberWithCode != ""
                && oldMobileNumberWithCode.indexOf("|") > 0) {
				StringTokenizer token = new StringTokenizer(oldMobileNumberWithCode,
                    "|");  
            if (token.hasMoreTokens())
                coutryCode = token.nextToken();
            if (token.hasMoreTokens())
                mobileNo = token.nextToken();
            
            	dataMap.put("oldMobileNo",mobileNo);
        } else {
        		dataMap.put("oldMobileNo",oldMobileNumberWithCode);
        }
			
			if (newMobileNumberWithCode != null && newMobileNumberWithCode != ""
                && newMobileNumberWithCode.indexOf("|") > 0) {
				StringTokenizer token = new StringTokenizer(newMobileNumberWithCode,
                    "|");  
            if (token.hasMoreTokens())
            	newCoutryCode = token.nextToken();
            if (token.hasMoreTokens())
                newNobileNo = token.nextToken();
            
            	dataMap.put("newMobileNo",newNobileNo);
        } else {
        	dataMap.put("newMobileNo",newMobileNumberWithCode);
        }
			
			
			dataMap.put("userAlias",rs.getString("user_alias"));
			dataMap.put("status",rs.getString("status"));
			dataMap.put("userId",rs.getString("user_id"));
			returnList.add(dataMap);
			}
			return returnList;
		}
		
	}

	public int cancelMobileNoUserConfirm(Map inParam,String[] approvedCMRNo) throws DAOException {
		
		 logger.info("cancelMobileNoUserConfirm - begin" );
		String userAlias=(String)inParam.get("userId");
		
		List regMobileNoList=null;
		int rejectCount=0;
		String flag=(String)inParam.get("flag");
		String refNo=(String)inParam.get("refNo");
		
		 logger.info("flag----->"+flag);
		 
		if(approvedCMRNo != null){
		try{
			
			
            
			for(int i=0;i<approvedCMRNo.length; i++){
				
				//Integer approveIDs = new Integer(approvedCMRNo[i]);
				String approveIDs = approvedCMRNo[i];
				logger.info("approveIDs >>>>>>>>"+approveIDs);
				Object[] params = new Object[]{approveIDs};
         		 rejectCount = getJdbcTemplate().update(REJECT_MOBILENO_CONFIRM_FOR_USER,
								params);
								
			logger.info("rejectCount ::"+rejectCount);	
				
			}
            
            
            
		}catch(DataAccessException dataAccessException) {           
            dataAccessException.printStackTrace();
            DAOException.throwException("F001",new Object[] { }); //Due to Tech Problems
			
		}
		}else{
			DAOException
			.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("cancelMobileNoUserConfirm - end" );
		return rejectCount;
	}  

	}
