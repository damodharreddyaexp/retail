package com.sbi.common.dao;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;

public class CommissionDAOImpl extends JdbcDaoSupport implements
CommissionDAO {

	protected final Logger logger = Logger.getLogger(getClass());


	private static final String FIND_COMMISSION_QRY_CORPORATE = "select * from (select decode(corporate_id, 'default',9,'DEFAULT',9,0) num, PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from sbi_rtgs_commission_master"
							+" where lower(corporate_id) in (?,'default') and BANK_CODE=? and(upper(type)=? or upper(type)='BOTH')  and transaction_amount>=? order by num,transaction_amount) where rownum < 2" ;
		
	private static final String FIND_COMMISSION_QRY_RETAIL = "select PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from (select PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from sbi_rtgs_commission_master"
			+" where lower(corporate_id) in ('retail','cris') and BANK_CODE=? and(upper(type)=? or upper(type)='BOTH')  and transaction_amount >=? order by transaction_amount) where rownum=1" ;
	
	/*	CR-5687 BEGIN - Ramanan	*/
	//	private static final String FIND_COMMISSION_QRY_CORPORATE_WAIVER = "select * from (( select decode(corporate_id, 'default',9,'DEFAULT',9,0) num, PERCENTAGE_VALUE, MIN_AMOUNT, MAX_AMOUNT, BASE_VALUE  from sbi_rtgs_commission_master a where lower(a.corporate_id) in ( ? ,'default') and a.BANK_CODE = ? and (upper(type) = ? or upper(type)='BOTH')  and a.transaction_amount >= ? and a.product_code is null " 
	//			+ ") UNION ( select decode(corporate_id, 'default',9,'DEFAULT',9,0) num, PERCENTAGE_VALUE, MIN_AMOUNT, MAX_AMOUNT, BASE_VALUE  from sbi_rtgs_commission_master b where lower(b.corporate_id) in ( ? ,'default') and b.BANK_CODE = ?  and(upper(type) = ? or upper(type)='BOTH')  and b.product_code = ? and ( b.transaction_amount='0' or b.transaction_limit >= ? ))) where rownum < 2";
	private static final String FIND_COMMISSION_QRY_CORPORATE_WAIVER =   "select * from ( select decode(corporate_id, 'default',9,'DEFAULT',9,0) num, PERCENTAGE_VALUE, MIN_AMOUNT, MAX_AMOUNT, BASE_VALUE from sbi_rtgs_commission_master " +
	"where lower(corporate_id) in ( ? ,'default') and BANK_CODE = ?  and(upper(type) = ?  or upper(type)='BOTH')  and (transaction_amount >= ?   OR (nvl(PRODUCT_CODE,'*') =nvl(?,'*')  AND ((transaction_amount='0' AND transaction_limit='0')  OR transaction_limit >= ? ))) order by num, product_code, transaction_amount) where rownum < 2";
	/*	CR-5687 BEGIN - Ramanan	*/
	
//	private static final String FIND_COMMISSION_QRY_RETAIL_WAIVER = "select PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from (( select TRANSACTION_AMOUNT,PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from sbi_rtgs_commission_master a where lower(a.corporate_id) in ('retail','cris') and a.BANK_CODE= ? and (upper(type) = ? or upper(type)='BOTH')  and a.transaction_amount >= ? and a.product_code is null " 
//			+ ") UNION ( select TRANSACTION_AMOUNT,PERCENTAGE_VALUE,MIN_AMOUNT,MAX_AMOUNT,BASE_VALUE from sbi_rtgs_commission_master b where lower(b.corporate_id) in ('retail','cris') and b.BANK_CODE = ?  and (upper(type) = ? or upper(type)='BOTH')  and b.product_code= ? and ( b.transaction_amount='0' or b.transaction_limit >= ? ))) where rownum=1" ;
	
	private static final String FIND_COMMISSION_QRY_RETAIL_WAIVER = "select * from ( select PERCENTAGE_VALUE, MIN_AMOUNT, MAX_AMOUNT, BASE_VALUE from sbi_rtgs_commission_master where lower(corporate_id) in ( 'retail','cris') and BANK_CODE = ?  and(upper(type) = ?  or upper(type)='BOTH')  and (transaction_amount >= ?   OR (nvl(PRODUCT_CODE,'*') =nvl(?,'*')  AND ((transaction_amount='0' AND transaction_limit='0')  OR transaction_limit >= ? ))) order by product_code, transaction_amount) where rownum < 2";
	
	//DD Commission charge change CR 5774 - Sulthan
	private static final String FIND_DD_COMMISSION_QRY_CORPORATE_WAIVER = " select decode(lower(corporate_id), 'default',9,0) num, PERCENTAGE_VALUE, MIN_AMOUNT, MAX_AMOUNT,BASE_VALUE  from sbi_rtgs_commission_master a where nvl(lower(a.corporate_id),'default') = 'default' and a.BANK_CODE =? and (upper(type)) in (?,'BOTH')  and a.transaction_amount >= ? and a.product_code = ?";
	//DD Commission charge change CR 5774 - Sulthan
	
	public Map  getCommissionAmountForCorporate(String bankCode, String merchantCode,String corpId,Double debitAmount) {
		logger.info(" getCommissionAmount(String bankCode, String merchantCode) method begins");
		logger.info("bankCode:" + bankCode + " merchantCode: " + merchantCode);
		Map commissionMap = null;
		if (bankCode != null && merchantCode != null && corpId!=null && debitAmount!=null) {
			Object params[] = {corpId, bankCode, merchantCode,debitAmount };
			try {
				commissionMap = getJdbcTemplate().queryForMap(
						FIND_COMMISSION_QRY_CORPORATE, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :" + accessException);
				DAOException.throwException("RTGS023", params);
			}
		} else
			DAOException.throwException("RTGS024");
		logger
				.info(" getCommissionAmount(String bankCode, String merchantCode) method ends");
		return commissionMap;
	}

	public Map getCommissionAmountForRetail(String bankCode,String type,Double debitAmount) {
		logger.info(" getCommissionAmount(String bankCode, String type,Double debitAmount) method begins");
		logger.info("bankCode:" + bankCode+"Type is  ::"+type );
		Map commissionMap=null;
		if (bankCode != null && type!=null && debitAmount!=null) {
			Object params[] = {bankCode,type,debitAmount};
			try {
			
				commissionMap=getJdbcTemplate().queryForMap(FIND_COMMISSION_QRY_RETAIL, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :" + accessException);
				DAOException.throwException("IBFT003", params);
			}
		} else
			DAOException.throwException("F001");
		logger.info(" getCommissionAmount(String bankCode, String type,Double debitAmount) method ends");
		return commissionMap;
	
	}
	
	/*	CR-5687 BEGIN - Ramanan	*/
	public Map  getCommissionAmountForCorporate(String bankCode, String merchantCode, String corpId, Double debitAmount, String productCode) {
		logger.info(" getCommissionAmount(String bankCode, String merchantCode, String corpId, Double debitAmount, String productCode) method begins");
		logger.info("bankCode: " + bankCode + " merchantCode: " + merchantCode + "corpId: " + corpId + "debitAmount: " + debitAmount + "productCode: " + productCode);
		Map commissionMap = null;
		if (bankCode != null && merchantCode != null && corpId!=null && debitAmount!=null) {
			//	Object params[] = { corpId, bankCode, merchantCode, debitAmount, corpId, bankCode, merchantCode, productCode, debitAmount };
			Object params[] = { corpId, bankCode, merchantCode, debitAmount, productCode, debitAmount };
			try {
				commissionMap = getJdbcTemplate().queryForMap(
						FIND_COMMISSION_QRY_CORPORATE_WAIVER, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :" + accessException);
				DAOException.throwException("RTGS023", params);
			}
		} else
			DAOException.throwException("RTGS024");
		logger
				.info(" getCommissionAmount(String bankCode, String merchantCode, String corpId, Double debitAmount, String productCode) method ends");
		return commissionMap;
	}
	/*	CR-5687 END - Ramanan	*/
	
	/*	CR-5687 BEGIN - Ramanan	*/
	public Map getCommissionAmountForRetail(String bankCode,String type,Double debitAmount, String productCode) {
		logger.info(" getCommissionAmountForRetail(String bankCode,String type,Double debitAmount, String productCode) method begins");
		logger.info("bankCode: " + bankCode+" Type is  : "+type + " debitAmount: "+ debitAmount + " productCode : "+productCode);
		Map commissionMap=null;
		if (bankCode != null && type!=null && debitAmount!=null) {
//			Object params[] = {bankCode, type, debitAmount, bankCode, type, productCode, debitAmount};
			Object params[] = {bankCode, type, debitAmount, productCode, debitAmount};
			try {
			
				commissionMap=getJdbcTemplate().queryForMap(FIND_COMMISSION_QRY_RETAIL_WAIVER, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :" + accessException);
				DAOException.throwException("IBFT003", params);
			}
		} else
			DAOException.throwException("F001");
		logger.info(" getCommissionAmountForRetail(String bankCode,String type,Double debitAmount, String productCode) method ends");
		return commissionMap;
	
	}
	/*	CR-5687 END - Ramanan	*/
	//DD Commission charge change CR 5774  by Sulthan-Starts
	public Map  getDDCommissionAmountForCorporate(String bankCode, String merchantCode,  Double debitAmount, String productCode) {
		logger.info(" getCommissionAmount(String bankCode, String merchantCode, String corpId, Double debitAmount, String productCode) method begins");
		logger.info("bankCode: " + bankCode + " merchantCode: " + merchantCode + "debitAmount: " + debitAmount + "productCode: " + productCode);
		Map commissionMap = null;
		if (bankCode != null && merchantCode != null && debitAmount!=null && productCode!=null) {
			Object params[] = {  bankCode, merchantCode, debitAmount,productCode};
			try {
				commissionMap = getJdbcTemplate().queryForMap(
						FIND_DD_COMMISSION_QRY_CORPORATE_WAIVER, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :" + accessException);
				DAOException.throwException("RTGS023", params);
			}
		} else
			DAOException.throwException("RTGS024");
		logger
				.info(" getCommissionAmount(String bankCode, String merchantCode, String corpId, Double debitAmount, String productCode) method ends");
		return commissionMap;
	}
	//DD Commission charge change CR 5774  by Sulthan-Ends

	
		
	
}
