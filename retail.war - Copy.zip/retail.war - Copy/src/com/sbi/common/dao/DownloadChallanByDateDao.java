package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;

/**
 * 
 * This is the base dao interface for the Download challan By Date module
 * 
 * @author Siva
 * @version 1.0
 * 
 */
public interface DownloadChallanByDateDao {
	
	List getChallanDetails(String corporateId,String startdate) throws DAOException;
	
	String getFileStatus(String corporateId,String fileName);
}
