/* 
 * BranchMasterDAOImpl.java
 * Created on Oct 29, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 29, 2005 BOOPATHI - Initial Creation
//Nov 07  changes: public Branch findBranchDetails(String branchCode) instead of return value Map.
//NOV 23 CONSTANTS ADDED
// DEC 28, 2005 - BOOPATHI - Exception modified
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
 
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.model.Branch;
import com.sbi.common.service.ServiceErrorConstants;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.dao.ErrorConstants;

import org.apache.log4j.Logger;

public class BranchMasterDAOImpl extends JdbcDaoSupport implements BranchMasterDAO
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    static final String FIND_INBRANCH = "select * from sbi_branch_master where branch_Code=? and  status=1 and ((live=0 and last_conn_time is not null) or core_banking=0)";
    
    public static final String INVALID_BRANCHCODE="CSE009"; //Invalid BranchCode - ErrorCode
    
    static final String FIND_SBIBRANCH="select * from sbi_all_branches where branch_code=? and status=1"; // For Regulator

    public List findAllStates()
    {
        logger.info("findAllStates() " + LoggingConstants.METHODBEGIN);
        List states = null;
        try
        {
            states = getJdbcTemplate().query(SQLConstants.FIND_ALL_STATES, new BranchDetailsRowMapper());
            if (logger.isDebugEnabled())
            {
                logger.debug("states" + states);
            }
            logger.info("findAllStates() " + LoggingConstants.METHODEND);
            return states;
        }
        catch (DataAccessException ex)
        {
            logger.error("DataAccessException :",ex);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;
    }

    public List findLocation(String state)
    {

        List states = null;

        logger.info("findLocation(String state) " + LoggingConstants.METHODBEGIN);
        
        
        logger.info("state" + state);
        

        if (state != null && !state.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try
            {
                Object[] parameters = new Object[] { state };
                states = getJdbcTemplate().query(SQLConstants.FIND_LOCATION, parameters, new BranchDetailsRowMapper());

                if (states.size() > 0)
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("states" + states);
                    }
                    logger.info("findLocation(String state) " + LoggingConstants.METHODEND);
                    return states;
                }
                else{
                	logger.info("findLocation(String state) " + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex)
            {
				logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public List findLocation()
    {

        List states = null;

        logger.info("findLocation() " + LoggingConstants.METHODBEGIN);        
        
        try
        {
        	states = getJdbcTemplate().query(SQLConstants.FIND_ALL_LOCATION, new BranchDetailsRowMapper());
        	if (states.size() > 0)
            {
        		logger.info("findLocation(String state) " + LoggingConstants.METHODEND);        		
                return states;
            }
            else{
            	logger.info("findLocation(String state) " + LoggingConstants.METHODEND);
            	return null;
            }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
            return null;
       
    }
    
    public List findAllLocations(String bankCode)
    {

        List states = null;

        logger.info("findAllLocations(String bankCode) " + LoggingConstants.METHODBEGIN);        
        
        try
        {
        	if(bankCode!=null && bankCode.length()>0){
        		Object[] params={bankCode}; 
	        	states = getJdbcTemplate().query(SQLConstants.FIND_ALL_LOCATION,params, new BranchDetailsRowMapper());
	        	if (states.size() > 0)
	            {
	        		logger.info("findLocation(String state) " + LoggingConstants.METHODEND);        		
	                return states;
	            }
	            else{
	            	logger.info("findAllLocation(String bankCode) " + LoggingConstants.METHODEND);
	            	return null;
	            }
        	}
        	else{
        		DAOException.throwException(ServiceErrorConstants.SE003);
        	}
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
            return null;
       
    }
    
    public List findBranches(String location)
    {

        logger.info("findBranches(String location) " + LoggingConstants.METHODBEGIN);
       
        logger.info("location" + location);
       

        List branches = null;
        if (location != null && !location.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try
            {
                Object[] parameters = new Object[] { location };
                branches = getJdbcTemplate()
                        .query(SQLConstants.FIND_BRANCHES, parameters, new BranchDetailsRowMapper());

                if (branches.size() > 0)
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("branches" + branches);
                    }
                    logger.info("findBranches(String location) " + LoggingConstants.METHODEND);
                    return branches;
                }
                else{
                	logger.info("findBranches(String location) " + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex)
            {
	            logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public List findINBLocation(String bankCode)
    {

        List locations = null;

        logger.info("findINBLocation(String bankCode) " + LoggingConstants.METHODBEGIN);

        try
        {
        	if(bankCode!=null && bankCode.length()>0){
        		Object[] params={bankCode};
	        	locations = getJdbcTemplate().query(SQLConstants.FIND_INB_LOCATION,params,new BranchDetailsRowMapper());
	        	
	        	if (locations.size() > 0)
	        	{
	        		if (logger.isDebugEnabled())
	        		{
	        			logger.debug("locations" + locations);
	        		}
	        		logger.info("findINBLocation() " + LoggingConstants.METHODEND);
	        		return locations;
	        	}
	        	else{
	        		logger.info("findINBLocation() " + LoggingConstants.METHODEND);
	        		return null;
	        	}
        	}
        	else{
        		DAOException.throwException(ServiceErrorConstants.SE003);
        	}
        }
        catch (DataAccessException ex)
        {
        	logger.error("DataAccessException :", ex);
        	DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;
    }

    public List findINBBranches(String location)
    {

        logger.info("findINBBranches(String location) " + LoggingConstants.METHODBEGIN);
        logger.info("location" + location);
        

        List branches = null;
        if (location != null && !location.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try
            {
                Object[] parameters = new Object[] { location };
                branches = getJdbcTemplate()
                        .query(SQLConstants.FIND_INB_BRANCHES, parameters, new BranchDetailsRowMapper());

                if (branches.size() > 0)
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("findINBBranches branches" + branches);
                    }
                    logger.info("findINBBranches(String location) " + LoggingConstants.METHODEND);
                    return branches;
                }
                else{
                	logger.info("findINBBranches(String location) " + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public List findAllBranches()
    {

        logger.info("findAllBranches() " + LoggingConstants.METHODBEGIN);
        List branchList = null;
        try
        {
            branchList = getJdbcTemplate().query(SQLConstants.FIND_ALL_BRANCHES, new BranchRowMapper());
            if (logger.isDebugEnabled())
            {
                logger.debug("branchList" + branchList);
            }
            logger.info("findAllBranches() " + LoggingConstants.METHODEND);
            return branchList;
        }
        catch (DataAccessException ex)
        {
        	logger.error("DataAccessException :", ex);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;
    }

    public Branch findBranchDetails(String branchCode)
    {
        logger.info("findBranchDetails(String branchCode) " + LoggingConstants.METHODBEGIN);
        logger.info("branchCode :"+branchCode);
        
        Branch branch = null;  
        
        if (branchCode != null && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try
            {
                Object[] parameters = new Object[] { branchCode };
                Object obj = getJdbcTemplate().query(SQLConstants.FIND_BRANCH_DETAILS, parameters, new BranchRowExtractor());
                branch = (Branch)obj;
               
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        logger.info("branch :"+branch);
        logger.info("findBranchDetails(String branchCode) " + LoggingConstants.METHODEND);
        
        if(branch.getBranchName() != null  && !branch.getBranchName().equalsIgnoreCase(DAOConstants.EMPTY))        
        	return branch;
        //else
        	//DAOException.throwException("SE021");
        
        return null;

    }

    public String findBankSystem(String branchCode) throws DAOException
    {
        logger.info("findBankSystem(String branchCode) " + LoggingConstants.METHODBEGIN);
        logger.info("branchCode" + branchCode);
        

        if (branchCode != null && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
 
        	Branch branch = null;
        	
        	branch = findBranchDetails(branchCode);
        	
            if (branch != null)
            {
                if (branch.getBankSystem().equalsIgnoreCase(DAOConstants.CORE_SYMBOL))
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("bankSystem :" + DAOConstants.CORE_SYMBOL);
                    }
                    return DAOConstants.CORE_SYMBOL;
                }
                else
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("bankSystem :" + DAOConstants.NONCORE_SYMBOL);
                    }
                    return DAOConstants.NONCORE_SYMBOL;
                }
            }
            return "";
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return "";

    }

    public String[][] findBranchesWithCode(String location,String bankCode)
    {
        logger.info("findBranchesWithCode(String location) " + LoggingConstants.METHODBEGIN);
        logger.info("location" + location);
        
        
        if (location != null && location.length()>0 && bankCode!=null && bankCode.length()>0)
        { 
            try
            {
                Object[] parameters = new Object[] { location,bankCode };
                List branches = getJdbcTemplate().query(SQLConstants.FIND_BRANCHES_WITH_CODE, parameters,
                        new BranchCodeRowMapper());

                String[][] branchData = null;
                if (branches != null && branches.size() > 0)
                {
                   Map data = (Map) branches.get(0);
                    branchData = new String[data.size()][2];
                    int i = 0;
                    String tempKey = null;
                    for (Iterator iterate = data.keySet().iterator(); iterate.hasNext(); i++)
                    {
                        tempKey = (String) iterate.next();
                        branchData[i][0] = tempKey;
                        branchData[i][1] = (String) data.get(tempKey);
                    }
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("branchData" + branchData);
                    }
                }
                logger.info("findBranchesWithCode(String location) " + LoggingConstants.METHODEND);
                return branchData;
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

    
   
    
    /**select * from sbi_all_branches where branch_code='BranchCode' and status=1*/
	/* (non-Javadoc)
	 * @see com.sbi.dao.CorporateProfileDAO#findSBIBranch(java.lang.String)
	 */
	 public boolean  findSBIBRanch(String branchCode)
	{
		logger.info("findSBIBranch( String branchCode )"+LoggingConstants.METHODBEGIN);
		logger.info("branchCode :"+branchCode);
		
		if(logger.isDebugEnabled())
        	logger.debug("branchCode :"+branchCode);
        
		if(branchCode!=null && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY)){
        	  
           try{
         	  Object[] parameter=new Object[]{branchCode};
         	   List result=getJdbcTemplate().queryForList(FIND_SBIBRANCH,parameter);
         	  
         	   if(result.size()>0)
         		   return true;
         	   else
         			  DAOException.throwException(INVALID_BRANCHCODE);  
         	   
         	   if(logger.isDebugEnabled()){
         		logger.debug("result :"+result);
         	   }
         	        logger.info("findSBIBranch( String branchCode )"+LoggingConstants.METHODEND);
               
                     return true;
            	
             }catch (DataAccessException exception) {
            	 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
              }
      
        }else{
        	 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
           return false;
	}
	


    public String[][] findINBBranchesWithCode(String location,String bankCode)
    {
        logger.info("findINBBranchesWithCode(String location,String bankCode) " + LoggingConstants.METHODBEGIN);
        logger.info("location" + location);
        

        if (location != null && location.length()>0 && bankCode!=null && bankCode.length()>0)
        {
            try
            {
                Object[] parameters = new Object[] { location,bankCode };
                List branches = getJdbcTemplate().query(SQLConstants.FIND_INB_BRANCHES_WITH_CODE, parameters,
                        new INBBranchCodeRowMapper());

                String[][] branchData = null;
                if (branches != null && branches.size() > 0)
                {
                    Map data = (Map) branches.get(0);
                    branchData = new String[data.size()][2];
                    int i = 0;
                    String tempKey = null;
                    for (Iterator iterate = data.keySet().iterator(); iterate.hasNext(); i++)
                    { 
                        tempKey = (String) iterate.next();
                        branchData[i][0] = tempKey;
                        branchData[i][1] = (String) data.get(tempKey);
                    }
                    if (logger.isDebugEnabled())
                    {
                        logger.debug("branchData" + branchData);
                    }
                }
                logger.info("findINBBranchesWithCode(String location,String bankCode) " + LoggingConstants.METHODEND);
                return branchData;
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :",ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

    private class FindAllBranchesExtractor implements ResultSetExtractor{

    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
    		Map result=new LinkedHashMap();
    		while(rs.next()){
    			result.put(rs.getString("BRANCH_CODE"),rs.getString("BRANCH_NAME"));
    		}
    		return result;
    	}
    	
    }
    
    public Map findAllBranchesWithCode()throws DAOException{
    	Map branchMap=null;
       String query="select distinct branch_name, branch_code from sbi_all_branches where DECODE(lower(SUBSTR(branch_code,0,1)),'a','0','6','0','3','0',SUBSTR(branch_code,0,1))='0' or DECODE(lower(SUBSTR(branch_code,0,1)),'a','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '9'";//mod for SBS merger
    	try{
    		branchMap=(Map)getJdbcTemplate().query(query,new FindAllBranchesExtractor());
    	}catch(DataAccessException dataAccessException){
    		DAOException.throwException(ServiceErrorConstants.SE003,dataAccessException);
    	}
    	catch (Exception exception) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,exception);
		}
    	return branchMap;
    }

    
     /**
     * For corporate add third party
     * 
     * Added by Saravanan N
     */
    
    public boolean findINBBranch(String branchCode )
	{ 
		logger.info("findINBBranch( String branchCode )"+LoggingConstants.METHODBEGIN);
        if(logger.isDebugEnabled())
        	logger.debug("branchCode :"+branchCode);
           boolean test=false;
           logger.info("branch--code=="+branchCode);
            if(branchCode!=null && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY))
            {
            	 logger.info("dgfdjfgsdjf");
        	  Object[] parameter=new Object[]{branchCode};
        	  logger.info("branchCode :"+branchCode);
        	   List result=getJdbcTemplate().queryForList(FIND_INBRANCH,parameter);
        	   logger.info("List size=="+result.size());
        	   if(logger.isDebugEnabled())
               	logger.debug("result :"+result);
        	  
        	   if (result != null && result.size() == 1) {
                   logger.info("NBBRanch Find:" + true);
                   logger.info("findINBBranch( String branchCode )"+LoggingConstants.METHODEND);
                    test=true;
                    return test;
           	}else
           	{  
               logger.info("findINBBranch( String branchCode ) invalid branchCode "+ branchCode);
               DAOException.throwException(INVALID_BRANCHCODE);
       } 
     
            }else
            	DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
               
            return test;
	}  
    
    
    public String findBranchName(String branchCode)throws DAOException{
    	String branchName="";
    	String query="select  branch_name from sbi_all_branches where branch_code=?";
    	try{
    		Object[] params={branchCode};
    		Map branchNameMap=getJdbcTemplate().queryForMap(query,params);
    		if(branchNameMap!=null && branchNameMap.size()>0)
    			branchName=branchNameMap.get("BRANCH_NAME").toString();
    		logger.info("Branch Name : " + branchName);
    	}catch(DataAccessException dataAccessException){
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
    	}
    	catch (Exception e) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,e);
		}
    	return branchName;
    }
    
    class BranchRowExtractor implements ResultSetExtractor{

		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			
			Branch branch = new Branch();
			while(rs.next())			
			{
	            branch.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
	            branch.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));
	            if (rs.getInt(DAOConstants.CORE_BANKING) == 1)
	                branch.setBankSystem(DAOConstants.NONCORE_SYMBOL);
	            else
	                branch.setBankSystem(DAOConstants.CORE_SYMBOL);
	            branch.setUserCount(rs.getString(DAOConstants.USER_COUNT));
	            branch.setBankCode(rs.getString(DAOConstants.BANK_CODE));
	            branch.setAvailability(DAOConstants.EMPTY);
			}
	        return branch;
		}
    	
    }
    
    class BranchRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {

            Branch branch = new Branch();
            branch.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            branch.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));
            if (rs.getInt(DAOConstants.CORE_BANKING) == 1)
                branch.setBankSystem(DAOConstants.NONCORE_SYMBOL);
            else
                branch.setBankSystem(DAOConstants.CORE_SYMBOL);
            branch.setUserCount(rs.getString(DAOConstants.USER_COUNT));
            branch.setBankCode(rs.getString(DAOConstants.BANK_CODE));
            branch.setAvailability(DAOConstants.EMPTY);

            return branch;
        }
    }

    class BranchDetailsRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            return rs.getString(1);
        }
    }

    class BranchCodeRowMapper implements RowMapper
    {
        Map branchData = new LinkedHashMap();

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            branchData.put(rs.getString(1), rs.getString(2));
            return branchData;
        }
    }

	//Added for CR-5602 by Shreya
    class BranchCodeNewRowMapper implements RowMapper
    {
    	Map branchData = new LinkedHashMap();
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	branchData.put(rs.getString(1), rs.getString(2));
            return branchData;
            
        }
    }
    class INBBranchCodeRowMapper implements RowMapper
    {
        Map branchData = new LinkedHashMap();

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            branchData.put(rs.getString(1), rs.getString(2)+"-"+rs.getString(3));
            return branchData;
        }
    } 
    public Map findAllBranchesWithCode(String bankCode)throws DAOException{
        Map branchMap=null;
        //String query="select distinct branch_name, branch_code from sbi_all_branches where DECODE(lower(SUBSTR(branch_code,0,1)),'a','0','6','0',SUBSTR(branch_code,0,1))='0' or DECODE(lower(SUBSTR(branch_code,0,1)),'a','0','6','0',SUBSTR(branch_code,0,1)) = '9'";//mod for SBS merger
        //CR 2879-Ddebit 
        String query="select distinct branch_name, branch_code from sbi_all_branches where bank_code='"+bankCode+"'";//mod for SBS merger
        try{
            branchMap=(Map)getJdbcTemplate().query(query,new FindAllBranchesExtractor());
        }catch(DataAccessException dataAccessException){
            DAOException.throwException(ServiceErrorConstants.SE003,dataAccessException);
        }
        catch (Exception exception) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,exception);
        }
        return branchMap;
    }
  //Added for IOI
	public String findBranchIOIEnabled(String branchCode) throws DAOException
    {
        String bankIOIEnabled = "N";
		logger.debug("findBranchIOIEnabled(String branchCode) Begin" );
		String query="select NVL(IOI_ENABLED,'N') IOI_ENABLED from sbi_branch_master where branch_code = ?";
    	try{
    		Object[] params={branchCode};
    		bankIOIEnabled=(String) getJdbcTemplate().queryForObject(query,params,String.class);
    		logger.info("Branch IOI Enabled " + bankIOIEnabled);
    	}catch(DataAccessException dataAccessException){
    		DAOException.throwException(ServiceErrorConstants.SE002,dataAccessException);
    	}
    	catch (Exception e) {
			DAOException.throwException(ServiceErrorConstants.SE002,e);
		}
    	return bankIOIEnabled;
    }
//End
//Added for CR-5602 by Shreya
	
	  public String[][] findBankName(String branch,String location)  
	  {
	        logger.info("findBankName(String branch,String location) " + LoggingConstants.METHODBEGIN);
	        logger.info("branch" + branch);
	        logger.info("Loc " + location);
	        if (branch != null && branch.length()>0 )
	        { 
	            try
	            {
	                Object[] parameters = new Object[] { branch ,location};
	                
	                String qry = "select branch_name,ifsc_code from SBI_RTGS_BRANCH_MASTER where state=? and bank_name=?";
	                List branches = getJdbcTemplate().query(qry, parameters,
	                        new BranchCodeNewRowMapper());
	                logger.info("branches"+branches);
	                String[][] branchData = null;
	                if (branches != null && branches.size() > 0)
	                {
	                   Map data = (Map) branches.get(0);
	                    branchData = new String[data.size()][2];
	                    int i = 0;
	                    String tempKey = null;
	                    for (Iterator iterate = data.keySet().iterator(); iterate.hasNext(); i++)
	                    {
	                        tempKey = (String) iterate.next();
	                        branchData[i][0] = tempKey;
	                        branchData[i][1] = (String) data.get(tempKey);
	                    }
	                    if (logger.isDebugEnabled())
	                    {
	                        logger.debug("branchData" + branchData);
	                    }
	                }
	                logger.info("findBankName(String branch,String location)" + LoggingConstants.METHODEND);
	                return branchData;
//	                return branches;
	            }
	            catch (DataAccessException ex)
	            {
	            	logger.error("DataAccessException :", ex);
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	            }
	        }
	        else
	        {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }
	        return null;

	    }
	  
	  //Added for CR-5602
	  
	  public List findRTGSBankName()
	    {

	        logger.info("findRTGSBankName() " + LoggingConstants.METHODBEGIN);

	        try
	        {
	        	String qry="select distinct(bank_name) from SBI_RTGS_BRANCH_MASTER";
	        	List bankName = getJdbcTemplate().query(qry,new BranchDetailsRowMapper());
		        	
		        	if (bankName.size() > 0)
		        	{
		        		if (logger.isDebugEnabled())
		        		{
		        			logger.debug("BankName" + bankName);
		        		}
		        		logger.info("findRTGSBankName()" + LoggingConstants.METHODEND);
		        		return bankName;
		        	}
		        	else{
		        		logger.info("findRTGSBankName()" + LoggingConstants.METHODEND);
		        		return null;
		        	}
	        	
	        }
	        catch (DataAccessException ex)
	        {
	        	logger.error("DataAccessException :", ex);
	        	DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
	        return null;
	    }
	
	  //Added for CR-5602
	  
	  public List findRTGState(String bankName)
	    {

	        logger.info("findRTGState() " + LoggingConstants.METHODBEGIN);

	        try
	        {
	        	String qry="select distinct(state) from SBI_RTGS_BRANCH_MASTER where bank_name =?";
	        	 Object[] parameters = new Object[] { bankName };
	        	List state = getJdbcTemplate().query(qry,parameters,new BranchDetailsRowMapper());
		        	logger.info("States - " +state);
		        	if (state.size() > 0)
		        	{
		        		if (logger.isDebugEnabled())
		        		{
		        			logger.debug("state" + state);
		        		}
		        		logger.info("findRTGState()" + LoggingConstants.METHODEND);
		        		return state;
		        	}
		        	else{
		        		logger.info("findRTGState()" + LoggingConstants.METHODEND);
		        		return null;
		        	}
	        	
	        }
	        catch (DataAccessException ex)
	        {
	        	logger.error("DataAccessException :", ex);
	        	DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
	        return null;
	    }
    //Added for CR 5552 branch name fix
	public Branch getNeftbankName(String ifscCode){
   
      
        Branch branch = null;  
        String query = "select bank_name,branch_name from bvsbi.sbi_rtgs_branch_master where upper(ifsc_code) = ?";
        
        if (ifscCode != null && !ifscCode.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try
            {
                Object[] parameters = new Object[] { ifscCode };
                branch = (Branch) getJdbcTemplate().queryForObject(query, parameters, new NeftBranchRowExtractor());
            }
            catch (DataAccessException ex)
            {
            	logger.error("DataAccessException :", ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
       	return branch;
     }
	 class NeftBranchRowExtractor implements RowMapper
	    {
	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {
	            Branch branch = new Branch();
	            branch.setBranchCode(rs.getString("BANK_NAME"));
	            branch.setBranchName(rs.getString("BRANCH_NAME"));
	            return branch;
	        }
	    }
	
}
