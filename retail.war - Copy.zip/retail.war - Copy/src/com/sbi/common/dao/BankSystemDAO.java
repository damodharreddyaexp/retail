/*
 * BankSystemDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
package com.sbi.common.dao;

import java.util.Map;
import java.util.List;

import com.sbi.common.exception.DAOException;

public interface BankSystemDAO
{
    /** 
     * 
     * 
     * @param request
     * @return Map
     */
    Map getDataFromBankSystem(String request);

    /**
     * Call CoreDAOImpl with the inputParameter and get List result from
     * CoreDAOImpl
     * 
     * @param request
     * @return List
     */
    List getDataFromBankSystem(Map request) throws DAOException;

}
