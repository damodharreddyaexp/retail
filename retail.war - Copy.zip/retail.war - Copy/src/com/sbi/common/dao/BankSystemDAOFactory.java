/*
 * BankSystemDAOFactory.java
 * Created on Nov 25, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 25, 2005 BOOPATHI - Initial Creation
//Dec 28, 2005 BOOPATHI - Exception modified

package com.sbi.common.dao;

import org.apache.log4j.Logger;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;

public class BankSystemDAOFactory
{
    protected final Logger logger = Logger.getLogger(getClass());
    private BankSystemDAO switchDAOImpl;
    private BankSystemDAO coreDAOImpl;
    
    public BankSystemDAO getBankSystemDAO(String txnPath){
        
        if(logger.isDebugEnabled())
        	logger.debug("getBankSystemDAO(String txnPath) "+LoggingConstants.METHODBEGIN);
        
        if(txnPath != null && !txnPath.trim().equalsIgnoreCase(UtilsConstant.EMPTY)){
            
            if (txnPath.equalsIgnoreCase(DAOConstants.CORE_TO_CORE) || txnPath.equalsIgnoreCase(DAOConstants.CORE_TO_NONCORE) || txnPath.equalsIgnoreCase("CMC")){
            	if(logger.isDebugEnabled())
                	logger.debug("getBankSystemDAO(String txnPath) "+LoggingConstants.METHODEND);
                return coreDAOImpl;
            }
            else{ 
            	if(logger.isDebugEnabled())
                	logger.debug("getBankSystemDAO(String txnPath) "+LoggingConstants.METHODEND);
                return switchDAOImpl;
            }
        }else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }
    
    /**
     * CoreDAOImpl injection
     * @param coreFormatter void 
     */
    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl)
    {
        this.coreDAOImpl = coreDAOImpl;
    }
    
    /**
     * SwitchDAOImpl injection
     * @param switchFormatter void 
     */
    public void setSwitchDAOImpl(BankSystemDAO switchDAOImpl)
    {
        this.switchDAOImpl = switchDAOImpl;
    }
     
}
