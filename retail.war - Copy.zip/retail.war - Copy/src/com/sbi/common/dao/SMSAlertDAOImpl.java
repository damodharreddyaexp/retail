
/*
 * SMSAlertDAOImpl.java
 * Created on Dec 31, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 31, 2005 KRISHNA KUMAR - Initial Creation

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.SMSAlertSpec;
import com.sbi.common.utils.BranchUtils;
import com.sbi.common.utils.LoggingConstants;

public class SMSAlertDAOImpl extends JdbcDaoSupport implements SMSAlertDAO
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    private BranchUtils branchUtils;
    
    //Added by Venkatesh for CR 2403
    
    private static final String GET_ALERT_REFERENCE_SEQUENCE = "select  lpad(SYSTEM_ALERT_REF_NO.NEXTVAL,8,'0') ALERT_REFERENCE FROM DUAL";
    
    private static final String INSERT_SMS_DETAILS="insert into sbi_system_alert_history(ALERT_REFERENCE,RECEIVER_INFO,ALERT_ID,MOBILE_NO,MESSAGE,EMAIL_STATUS,MOBILE_STATUS,CREATION_TIME,ALERT_SENT_STATUS,ALERT_SENT_TIME,REASON_FAILURE,ALERT_TYPE,ALERT_MODE) values (?,?,?,?,?,'N','Y',sysdate,'Y',sysdate,'success',?,'SMS')";
    
    //End of CR 2403
    
    public SMSAlertSpec deleteAlertSpec(String userName, String nickName, String alertName, Integer alertId) throws DAOException
    {
        logger.info("deleteAlertSpec(String userName, String nickName, String alertName, Integer alertId)"+LoggingConstants.METHODBEGIN);
        Object[] params = {userName,alertName,alertId,nickName};
        boolean rowsDeleted;
        if (userName != null&& !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && alertName != null&& !alertName.trim().equalsIgnoreCase(DAOConstants.EMPTY)
                && alertId != null && nickName != null&& !nickName.trim().equalsIgnoreCase(DAOConstants.EMPTY) ){
            try{
            	SMSAlertSpec smsAlert = findAlertSpec(userName,nickName);
                int rows = getJdbcTemplate().update(SQLConstants.DELTE_SMS_ALERT,params);
                if(rows > 0)
                    rowsDeleted = true;
                else
                    rowsDeleted = false;
                if (logger.isDebugEnabled()) {
                    logger.debug("rows affected = " +rows);                    
                }
                logger.info("rowsDeleted"+rowsDeleted);
                logger.info("deleteAlertSpec(String userName, String nickName, String alertName, Integer alertId)"+LoggingConstants.METHODEND);
                if(rowsDeleted)
                	return smsAlert;
                else
                	return null;
             }catch (DataAccessException ex)
             { 
                logger.fatal(LoggingConstants.EXCEPTION, ex);
                DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                logger.fatal(LoggingConstants.EXCEPTION, exception);
                throw exception;
    
             }
        
        }else {

            DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            logger.fatal(LoggingConstants.EXCEPTION, exception);
            throw exception;
        } 
        
    }

   
    public SMSAlertSpec findAlertSpec(String userName, String nickName) throws DAOException
    {
        logger.info("findAlertSpec(String userName, String nickName)"+LoggingConstants.METHODBEGIN);
        List smsAlertData = null;
        SMSAlertSpec smsAlertSpec = new SMSAlertSpec();
        Object[] params = {userName,nickName};
        if (logger.isDebugEnabled()) {
            logger.debug("userName"+userName );
            logger.debug("nickName"+nickName );
        }
        if (userName != null&& !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && nickName != null&& !nickName.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
            try{
                smsAlertData = getJdbcTemplate().query(SQLConstants.FIND_ALERT_SPEC, params, new SMSAlertRowMapper(branchUtils));
                logger.info("The output from findUserAlerts"+smsAlertData);
            }catch (DataAccessException ex)
            {
               logger.fatal(LoggingConstants.EXCEPTION, ex);
               DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
               logger.fatal(LoggingConstants.EXCEPTION, exception);
               throw exception;
    
            }
            if(smsAlertData.size()>0)
            {
                smsAlertSpec = (SMSAlertSpec) smsAlertData.get(0);
                if (logger.isDebugEnabled()) {
                    logger.debug("smsAlertSpec = "+ smsAlertSpec );
                }
                logger.info("findAlertSpec(String userName, String nickName)"+LoggingConstants.METHODEND);
                return smsAlertSpec;
            }else{
                    if (logger.isDebugEnabled()) {
                        logger.debug("return null");                    
                    }
                    logger.info("findAlertSpec(String userName, String nickName) "+LoggingConstants.METHODEND);
                    return null;
                }
         }else {

                DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                logger.fatal(LoggingConstants.EXCEPTION, exception);
                throw exception;
            }   
        
            
            
    }
     
    public SMSAlertSpec findAlertSpecByName(String userName, String alertName) throws DAOException
    {
        logger.info("findAlertSpecByName(String userName, String nickName)"+LoggingConstants.METHODBEGIN);
        List smsAlertData = null;
        SMSAlertSpec smsAlertSpec = new SMSAlertSpec();
        Object[] params = {userName,alertName};
        if (logger.isDebugEnabled()) {
            logger.debug("userName"+userName );
            logger.debug("nickName"+alertName );
        }
        if (userName != null&& !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && alertName != null&& !alertName.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
            try{
                smsAlertData = getJdbcTemplate().query(SQLConstants.FIND_ALERT_SPEC_BY_NAME, params, new SMSAlertRowMapper(branchUtils));
                logger.info("The output from findUserAlerts: "+ smsAlertData);
            }catch (DataAccessException ex)
            {
               logger.fatal(LoggingConstants.EXCEPTION, ex);
               DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
               logger.fatal(LoggingConstants.EXCEPTION, exception);
               throw exception;
    
            }
            if(smsAlertData.size()>0)
            {
                smsAlertSpec = (SMSAlertSpec) smsAlertData.get(0);
                if (logger.isDebugEnabled()) {
                    logger.debug("smsAlertSpec = "+ smsAlertSpec );
                }
                logger.info("findAlertSpecByName(String userName, String alertName)"+LoggingConstants.METHODEND);
                return smsAlertSpec;
            }else{
                    if (logger.isDebugEnabled()) {
                        logger.debug("return null");                    
                    }
                    logger.info("findAlertSpecByName(String userName, String alertName)"+LoggingConstants.METHODEND);
                    return null;
                }
         }else {

                DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                logger.fatal(LoggingConstants.EXCEPTION, exception);
                throw exception;
            }   
        
            
            
    }

    
    public List findUserAlerts(String userName) throws DAOException
    {
        logger.info("findUserAlerts(String userName)"+LoggingConstants.METHODBEGIN);
        List smsAlertData = null;
        Object[] params = {userName};
        logger.info("userName"+userName );
        if(userName !=null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY )){
            try{
                smsAlertData = getJdbcTemplate().query(SQLConstants.FIND_USER_ALERT, params, new SMSAlertRowMapper(branchUtils));
                logger.info("The output from findUserAlerts"+smsAlertData);
                logger.info("findUserAlerts(String userName)"+LoggingConstants.METHODEND);
                return smsAlertData;
            }catch (DataAccessException ex)
                {
                   logger.fatal(LoggingConstants.EXCEPTION, ex);
                   DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                   logger.fatal(LoggingConstants.EXCEPTION, exception);
                   throw exception;
        
                }
        }else {

            DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            logger.fatal(LoggingConstants.EXCEPTION, exception);
            throw exception;
        }
    }

   
    public SMSAlertSpec insertAlertSpec(SMSAlertSpec alertSpec) throws DAOException
    {
        logger.info("insertAlertSpec(String userName)"+LoggingConstants.METHODBEGIN);
        logger.info("SMSAlertSpec"+alertSpec ); 
        
        if(alertSpec !=null){
            Object[] params = {alertSpec.getScheduleName()};
            try{
                    long oid = getJdbcTemplate().queryForLong(SQLConstants.FIND_SMSALERT_OID,params);
                    logger.info("oid(job id) from BV_ALERTSCED table"+oid);
                    Object[] paramSpec = {alertSpec.getUserId(),alertSpec.getAlertName()};
                    int alertId = getJdbcTemplate().queryForInt(SQLConstants.FIND_SMS_ALERTID,paramSpec);
                    logger.info("alertId from BV_ALERTSCED table"+alertId);
                    if(alertSpec !=null)
                    {
                        alertSpec.setJobId(new Long(oid));
                        alertSpec.setAlertId(new Integer(alertId));
                    }
                    Object[] paramInsert = {alertSpec.getUserId(),alertSpec.getAlertName(),alertSpec.getAlertId(),
                            DAOConstants.DELIVERY_TYPE,new Integer(1),alertSpec.getJobId(),DAOConstants.NOTIF_FREQ,
                            alertSpec.getStringCol1(),alertSpec.getStringCol2(),alertSpec.getStringCol3(),
                            alertSpec.getStringCol4(),alertSpec.getFloatCol1()};
                    int[] types = new int[]{Types.NUMERIC,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,
                    		Types.NUMERIC,Types.NUMERIC,Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    		Types.VARCHAR,Types.NUMERIC};
                    getJdbcTemplate().update(SQLConstants.INSERT_SMS_ALERT,paramInsert,types);
                    String branchName="";
                    if(alertSpec.getStringCol3() != null)
                         branchName = branchUtils.getBranchName(alertSpec.getStringCol3());
                    Object[] descriptArray = {alertSpec.getStringCol2(),branchName,alertSpec.getFloatCol1()};
                    String descriptionMsg = SMSAlertRowMapper.findDescription(alertSpec.getAlertName());
                    String description = MessageFormat.format(descriptionMsg,descriptArray);
                    alertSpec.setDescription(description);
                    logger.info("values inserted");
                    logger.info("findUserAlerts(String userName)"+LoggingConstants.METHODEND);
                    return alertSpec;
            }catch (DataAccessException ex)
            {
               logger.fatal(LoggingConstants.EXCEPTION, ex);
               DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
               logger.fatal(LoggingConstants.EXCEPTION, exception);
               throw exception;
    
            }
        }else {

            DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            logger.fatal(LoggingConstants.EXCEPTION, exception);
            throw exception;
        }
    }


    //Added by Venkatesh for CR 2403

    public int insertSMSDetails(String mobileNo, String message,String bankCode,String userName,String userRole) throws DAOException
    {
        logger.info("insertSMSDetails(String mobileNo, String message,String bankCode,String userName,String userRole) method begin");        
        String alertReference="SBI";
        String alertRefSeqNo="";
        String alertType="corp_sms";
        int result=0;
        Map outMap=null;
       if (message.toLowerCase().indexOf("password") != -1){
            message = message.substring(0,message.indexOf(":")+1).concat("xxxxxx");
            logger.info("updated message: "+message);
        }
        try
        {
            
            outMap =  getJdbcTemplate().queryForMap(GET_ALERT_REFERENCE_SEQUENCE);
            
            if( outMap.get("ALERT_REFERENCE") != null )
            {
                alertRefSeqNo = (String ) outMap.get("ALERT_REFERENCE");
                logger.info("Alert Reference Number from query is  "  + alertRefSeqNo);
            }         
                
            if(bankCode!=null && bankCode.equalsIgnoreCase("0"))
            {
                alertReference="SBI_"+alertRefSeqNo;
            }
            else
            {
                alertReference="ASSOCIATE_"+alertRefSeqNo;
            }
            
            logger.info("alertReference :"+alertReference);
            
            if(userRole!=null && userRole.equalsIgnoreCase("5"))
            {
                alertType="branch_sms";
            }
            else if(userRole!=null && userRole.equalsIgnoreCase("8"))
            {
                alertType="corpuser_sms";
            }
            // Added for CR- 2808 Begins
            else if(userRole!=null && userRole.equalsIgnoreCase("1"))
            {
                alertType="merchant_sms";
            }
            // Added for CR- 2808 Ends            
            if(mobileNo!=null && message!=null && bankCode!=null)
            {
                Object [] params={alertReference,userName,bankCode,mobileNo,message,alertType};        
                int[] types = new int[]{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                 result=getJdbcTemplate().update(INSERT_SMS_DETAILS,params,types); 
                
            }
        }
        catch (DataAccessException dataAccessException) {
            logger.info("Mobile NO:"+mobileNo+":Message:"+message+":BankCode:"+bankCode);
            dataAccessException.printStackTrace();
            DAOException.throwException("F001",new Object[] { }); //Due to Tech Problems
        }
        logger.info("insertSMSDetails(String mobileNo, String message,String bankCode,String userName,String userRole) method end");
        return result;
    }
    //End of CR 2403
     //Added for CR 248
	
	public int findRegisteredMobile(Integer userId) throws DAOException {
		logger.info("int findRegisteredMobile( Integer userId )METHODBEGIN");
        logger.info("UserId :" + userId);
        int count=0;
        String queryforCount;
        if (userId != null ){
        	Object[]  countparams = new Object[] {userId};
            queryforCount = "select count(1) from sbicorp_user_mobile_no where user_id=? AND status='Pending'";
            count = getJdbcTemplate().queryForInt(queryforCount,countparams);
            logger.info("count :"+count);
            
        }else{
			DAOException
			.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
        logger.info("int findRegisteredMobile( Integer userId )METHODEND");
		return count;
	}
	 //End of CR 248

    

    /**
     * @param branchUtils The branchUtils to set.
     */
    public void setBranchUtils(BranchUtils branchUtils)
    {
        this.branchUtils = branchUtils;
    }
    
}

class SMSAlertRowMapper implements RowMapper
{
    private BranchUtils branchUtils;
    public SMSAlertRowMapper( BranchUtils branchUtils)
    {
        this.branchUtils=branchUtils;       
    }
    public Object mapRow(ResultSet rs, int index) throws SQLException
    {
        SMSAlertSpec smsAlertSpec = new SMSAlertSpec();
        smsAlertSpec.setAlertId(new Integer(rs.getInt(SQLConstants.ALERT_ID)));
        smsAlertSpec.setAlertName(rs.getString(SQLConstants.ALERT_NAME));
        smsAlertSpec.setCreationDate(rs.getTimestamp(SQLConstants.CREATION_DATE));
        smsAlertSpec.setDateCol1(rs.getTimestamp(SQLConstants.DATECOL1));
        smsAlertSpec.setDateCol2(rs.getTimestamp(SQLConstants.DATECOL2));
        smsAlertSpec.setDateCol3(rs.getTimestamp(SQLConstants.DATECOL3));
        smsAlertSpec.setDeliveryType(rs.getString(SQLConstants.DLVY_TYPE));
        smsAlertSpec.setFloatCol1(new Double(rs.getDouble(SQLConstants.FLOATCOL1)));
        smsAlertSpec.setFloatCol2(new Double(rs.getDouble(SQLConstants.FLOATCOL2)));
        smsAlertSpec.setFloatCol3(new Double(rs.getDouble(SQLConstants.FLOATCOL3)));
        smsAlertSpec.setIntCol1(new Integer(rs.getInt(SQLConstants.INTCOL1)));
        smsAlertSpec.setIntCol2(new Integer(rs.getInt(SQLConstants.INTCOL2)));
        smsAlertSpec.setIntCol3(new Integer(rs.getInt(SQLConstants.INTCOL3)));
        smsAlertSpec.setJobId(rs.getLong(SQLConstants.JOB_ID));
        smsAlertSpec.setNotifyFrequency(new Integer(rs.getInt(SQLConstants.NOTIF_FREQ)));
        smsAlertSpec.setStringCol1(rs.getString(SQLConstants.STRINGCOL1));
        smsAlertSpec.setStringCol2(rs.getString(SQLConstants.STRINGCOL2));
        smsAlertSpec.setStringCol3(rs.getString(SQLConstants.STRINGCOL3));
        smsAlertSpec.setStringCol4(rs.getString(SQLConstants.STRINGCOL4));
        smsAlertSpec.setUserId(new Integer(rs.getInt(SQLConstants.USER_ID)));
        
        String branchName="";
        if(smsAlertSpec.getStringCol3() != null)
            branchName = branchUtils.getBranchName(smsAlertSpec.getStringCol3());
        Object[] descriptArray = {smsAlertSpec.getStringCol2(),branchName,smsAlertSpec.getFloatCol1()};
        String descriptionMsg = findDescription(smsAlertSpec.getAlertName());
        String description = MessageFormat.format(descriptionMsg,descriptArray);
        smsAlertSpec.setDescription(description);
        return smsAlertSpec;
    }   
    public static String findDescription(String alertName)
    {
        String constantType = new String();
        if(alertName.equalsIgnoreCase(SQLConstants.CUBAL)) 
                constantType=SQLConstants.CUBAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.CLBAL)) 
            constantType=SQLConstants.CLBAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.DUBAL)) 
            constantType=SQLConstants.DUBAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.DLBAL)) 
            constantType=SQLConstants.DLBAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.CIAL)) 
            constantType=SQLConstants.CIAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.DIAL)) 
            constantType=SQLConstants.DIAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.CRAL)) 
            constantType=SQLConstants.CRAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.DRAL)) 
            constantType=SQLConstants.DRAL_MESSAGE;
        if(alertName.equalsIgnoreCase(SQLConstants.BP)) 
            constantType=SQLConstants.BP_MESSAGE;
       
        return constantType;
    }
}
