/*
 * TradeAccountMasterDAOImpl.java 
 * Created on Sep 14, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */ 
//History
//Sep 14, 2006 Meena - Initial Creation

package com.sbi.common.dao;  

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;
import com.sbi.common.model.TradeAccountDetails;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

public class TradeAccountMasterDAOImpl extends JdbcDaoSupport implements TradeAccountMasterDAO
{
    protected final Logger logger = Logger.getLogger(getClass());
    public static final String TRADE_ACC_MASTER_DATA = "select a.*,b.last_updated_date from sbi_tf_acc_master a,sbi_branch_master b where a.account_no=? and a.branch_code=? and a.branch_code=b.branch_code and a.status=1 and b.status=1";

    private BankSystemDAO coreDAOImpl;

    public AccountDetails findAccountDetails(String accountNo, String branchCode)
    {
        return null;
    }

    public AccountDetails findAccountDetails(Account account) throws DAOException
    {
        logger.info("findAccountDetails(Account account) " + LoggingConstants.METHODBEGIN);
        logger.info("Account :" + account);
        

        if (account != null && account.getBankSystem() != null && account.getAccountNo() != null
                && !account.getAccountNo().trim().equalsIgnoreCase(DAOConstants.EMPTY)
                && account.getBranchCode() != null
                && !account.getBranchCode().trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {

            if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE))
            {
                logger.info("findAccountDetails(Account account) " + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromCore(account);
            }
            else
            {
                logger.info("findAccountDetails(Account account) " + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromDB(account);
            }

        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    private AccountDetails getTransactionAccountDetailsFromDB(Account account)
    {
        
        if (logger.isDebugEnabled())
        {
        	logger.info("getTransactionAccountDetailsFromDB(Account account) " + LoggingConstants.METHODBEGIN);
            logger.debug("Account :" + account);
        }
        try
        {
            Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode() };
            logger.info("parameters passed are: "+account.getAccountNo() + " " + account.getBranchCode());
            List resultList = getJdbcTemplate().query(TRADE_ACC_MASTER_DATA, parameters,
                    new DepositAccountClassRowMapper());
            if (resultList != null && resultList.size() > 0)
            {
                if (resultList.size() == 1)

                    return (AccountDetails) resultList.get(0);
                else if (resultList.size() > 1)
                {
                    DAOException.throwException(ErrorConstants.FATAL_ERROR3_CODE);
                }
            }
        }
        catch (DataAccessException ex)
        {
        	logger.error("DataAccessException :",ex);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;
    }

    class DepositAccountClassRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {

            TradeAccountDetails acc = new TradeAccountDetails();
            acc.setAccountDescription(rs.getString(SQLConstants.ACCOUNT_DESC));
            acc.setAccountShortName(rs.getString(SQLConstants.SHORT_NAME));
            //acc.setNomination(rs.getString(SQLConstants.NOMINATION));
            acc.setSanctionedAmount(new Double(rs.getFloat(SQLConstants.SANCTIONED_AMOUNT)));
            acc.setLastUpdatedDate(rs.getTimestamp("last_updated_date"));
            acc.setDrawingPower(new Double(rs.getFloat(SQLConstants.DRAWING_POWER)));
            acc.setAmountOutStanding(new Double(rs.getFloat(SQLConstants.AMOUNT_OUTSTANDING)));
            acc.setCurrencyCode(rs.getString(SQLConstants.CURRENCY));
            return acc;
        }
    }

    private AccountDetails getTransactionAccountDetailsFromCore(Account account) throws DAOException
    {
        
        if (logger.isDebugEnabled())
        {
        	logger.debug("getTransactionAccountDetailsFromCore(Account account) " + LoggingConstants.METHODBEGIN);
            logger.debug("Account :" + account);
        }
        String txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;

        Map requestParams = new HashMap();
        requestParams.put(DAOConstants.ACCOUNT_NO, (String) account.getAccountNo());
        requestParams.put(DAOConstants.TXNNO, txnno);
        String bankCode = account.getBankCode();
    	if(bankCode == null){
    		bankCode=account.getBranchCode().substring(0,1);
    	}
        requestParams.put("bankCode",bankCode);
        List responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
        HashMap coreDataHash = (HashMap) responseList.get(0);
        String branchName = null;
        int branchCodeLength ;
        String padZeroes = "";
        
        String status = null;
        String errorCode = null;
        
        if(coreDataHash.get("status") != null){
        	status = (String)coreDataHash.get("status");
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        if(coreDataHash.get("error_code") != null){
        	errorCode = (String)coreDataHash.get("error_code");
        	status = errorCode; 
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        
        if(status == null && errorCode == null){
        
        	TradeAccountDetails acc = new TradeAccountDetails();
        	acc.setBranchCode((String) coreDataHash.get("branch_code"));
        	String branchCode = acc.getBranchCode();
        	logger.info("branchCode from Core : "+branchCode);
        	logger.info("bankCode  : "+bankCode);
        	acc.setBranchCode(branchCode);
        	if(branchCode != null && branchCode.length()!= 5)
        	{
        		for(branchCodeLength= branchCode.length(); branchCodeLength < 5; branchCodeLength++)
        		{
        			padZeroes = padZeroes + '0';
        		}
        		branchCode = padZeroes + branchCode;
        		logger.info("branchCode after padding : "+branchCode);
        		acc.setBranchCode(branchCode);
        	}
        	else{
        		if( (bankCode!=null && "0|A|6|3|9".contains(bankCode) ) && 
							( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("1") ) )
        		{
		        	logger.info("branchCode before replace::"+ branchCode);
		        	branchCode = branchCode.replaceFirst("1", "A");
		        	logger.info("branchCode after replace::"+ branchCode);
		        }
        	}
        	
        	Object[] parameters = new Object[] {branchCode,branchCode};
          
        	String query ="select decode(nvl(a.branch_name,'*'),'*',(select branch_name from sbi_all_branches where branch_code = ?), " +
        			"a.branch_name) branch_name from (select branch_name from sbi_branch_master where branch_code = ?) a";
        	try
        	{
            	Map branchNameMap = getJdbcTemplate().queryForMap(query, parameters);
            	logger.info("***Branch Name selected from branch master/all branches table***");
            	branchName=(branchNameMap.get("BRANCH_NAME")).toString();
        	}
        	catch(EmptyResultDataAccessException e)
        	{
        		logger.info("***Brach Name not present in branch master/all branches table***");
        		branchName="NA";
        	}
        	
        	acc.setBranchName(branchName);
        	acc.setAccountDescription(account.getProductDescription());
        	acc.setCurrencyCode((String) coreDataHash.get(DAOConstants.CURRENCY_CODE));
        	acc.setAccountShortName((String) coreDataHash.get(DAOConstants.PROFILE_USER_NAME));
        	if (((String) coreDataHash.get(DAOConstants.NOMINATION)).equalsIgnoreCase(DAOConstants.YES))
        		acc.setNomination(DAOConstants.ONE);
        	else 
        		acc.setNomination(DAOConstants.ZERO);
        	       	
        	acc.setDrawingPower(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.DRAWING_POWER)));
        	acc.setCurrencyCode((String) coreDataHash.get(DAOConstants.CURRENCY_CODE));
        	acc.setAvailableBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.AVAIL_BAL)));
        	acc.setBookBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.BOOK_BALANCE)));
        	acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.INTEREST_RATE)));
        	acc.setHoldValue(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get("hold_value")));
            acc.setIfsCode(StringUtils.emptyCheck((String)coreDataHash.get("ifs_code")));
        	
        	if(logger.isDebugEnabled())
        		logger.debug("getTransactionAccountDetailsFromCore(Account account) " + LoggingConstants.METHODEND);
        	return acc;
        }else{        	
        	DAOException.throwException(status);
        }
        return null;
    } 

    /*private Timestamp coreDateToTimestamp(String coreDateString)
    {
    	if(logger.isDebugEnabled())
    		logger.debug("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODBEGIN);
        Timestamp timestamp = null;
        try
        { 

            if (coreDateString != null)
            {
                SimpleDateFormat ts = new SimpleDateFormat(DAOConstants.DATA_FORMAT);
                Date sqlToday = new java.sql.Date(ts.parse(coreDateString).getTime());
                timestamp = new Timestamp(sqlToday.getTime());
                if (logger.isDebugEnabled())
                {
                    logger.debug("timestamp :" + timestamp);
                    logger.debug("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODEND);
                }
                
                return timestamp;
            }

        }
        catch (ParseException e)
        {
            logger.info(LoggingConstants.EXCEPTION + e);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }

        return timestamp;

    }

    private Double emptyStringCheckForDouble(String responseString)
    {
    	if(logger.isDebugEnabled())
    		logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODBEGIN);
    	
        Double doubleValue = new Double(DAOConstants.ZERO_DOUBLE);
        if (responseString != null)
        {
            try
            {
                doubleValue = new Double(responseString);
            }
            catch (NumberFormatException nfx)
            {
                logger.fatal(LoggingConstants.EXCEPTION + nfx);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }
        if (logger.isDebugEnabled())
        {
            logger.debug("doubleValue :" + doubleValue);
            logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODEND);
        }
        
        return doubleValue;
    }

    private Integer emptyStringCheckForInteger(String responseString)
    {
    	if (logger.isDebugEnabled())
    		logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODBEGIN);
        Integer intValue = new Integer(DAOConstants.ZERO);
        if(responseString != null && responseString.trim().length()>0){	        
	        if (responseString != null)
	        {
	            try
	            {
	                intValue = new Integer(responseString);
	            }
	            catch (NumberFormatException nfx)
	            {
	                logger.fatal(LoggingConstants.EXCEPTION, nfx);
	                //DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	            }
	        }
        }
        if (logger.isDebugEnabled())
        {
            logger.debug("intValue :" + intValue);
            logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODEND);
        }
        
        return intValue;
    }
*/
    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl)
    {
        this.coreDAOImpl = coreDAOImpl;
    }
 
}
