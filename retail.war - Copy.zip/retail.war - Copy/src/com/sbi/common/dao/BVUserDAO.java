package com.sbi.common.dao;

public interface BVUserDAO {

    boolean validateLogin(String userName, String password);
    void changeLoginPassword(String userName, String oldPassword, String newPassword);
    void changeUserNamePassword(String userName, String oldUserName, String newPassword);
	//added for caadmin
    boolean addUser(String userName,String passWord);
    //added for first time login password change
    void changeLoginPassword(String userName,String password);
} 
