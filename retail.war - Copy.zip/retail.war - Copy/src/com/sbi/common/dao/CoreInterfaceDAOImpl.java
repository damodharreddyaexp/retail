/*
 * CoreInterfaceDAOImpl.java
 * Created on Oct 20, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 20, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
// DEC 28, 2005 BOOPATHI - EXCEPTION MODIFIED
//JAN 06, 2005 BOOPATHI - NEW METHOD ADDED
// JAN 18, 2005 BOOPATHI - NEW METHOD ADDED
package com.sbi.common.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.cache.CorePropertiesDataCache;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

public class CoreInterfaceDAOImpl extends JdbcDaoSupport implements	CoreInterfaceDAO {

	protected final Logger logger = Logger.getLogger(getClass());
 
	private CorePropertiesDataCache corePropertiesDataCache;

	
	/**
	 * Executes the query [select * from CoreInterface where txnid=? and
	 * type="REQ" order by txnid, order] and returns the output as list
	 */
	public List findCoreRequestData(String txnID) {
		
		if(logger.isDebugEnabled()){
			logger.debug("findCoreRequestData(String txnID) "+ LoggingConstants.METHODBEGIN);
			logger.debug("txnID :" + txnID);
		}

		List coreRequestDataList = null;

		if (txnID != null && !txnID.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
			
			String key = "core_req_" + txnID;
			
			List coreRequestData = (List)corePropertiesDataCache.getData(key);
			
			
			if (coreRequestData == null || coreRequestData.size() == 0) {
				//logger.info("From table.......");				
				coreRequestData = getCoreServerDatas(txnID, "req");
			}
			
			coreRequestDataList = new ArrayList(coreRequestData);//(List) coreRequestData.get("dataList");
			
			
			
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("coreRequestDataList :" + coreRequestDataList);
			logger.debug("findCoreRequestData(String txnID) "+ LoggingConstants.METHODEND);
		}
		

		return coreRequestDataList;
	}

	// method overloaded with bank code parameter for CR 5553
	/**
	 * Executes the query [select * from CoreInterface where txnid=? and
	 * type="REQ" order by txnid, order] and returns the output as list
	 */
	public List findCoreRequestData(String txnID,String bankCode) {
		
		if(logger.isDebugEnabled()){
			logger.debug("findCoreRequestData(String txnID,String bankCode) "+ LoggingConstants.METHODBEGIN);
		}
		logger.info("TXNNO :" + txnID+" "+"bankCode :" + bankCode);

		List coreRequestDataList = null;

		if (txnID != null && !txnID.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
			
			String key = "core_req_" + txnID+"_"+bankCode;
			
			List coreRequestData = (List)corePropertiesDataCache.getData(key);
			
			
			if (coreRequestData == null || coreRequestData.size() == 0) {
				//logger.info("From table.......");				
				coreRequestData = getCoreServerDatas(txnID, "req",bankCode);
			}
			
			coreRequestDataList = new ArrayList(coreRequestData);//(List) coreRequestData.get("dataList");
			
			
			
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("coreRequestDataList :" + coreRequestDataList);
			logger.debug("findCoreRequestData(String txnID) "+ LoggingConstants.METHODEND);
		}
		

		return coreRequestDataList;
	}
	
	
	/**
	 * Executes the query [select * from CoreInterface where txnid=? and
	 * type="RES" order by txnid, order] and returns the output as list
	 */
	public List findCoreResponseData(String txnID) {

		if(logger.isDebugEnabled()){
			logger.debug("findCoreResponseData(String txnID) "+ LoggingConstants.METHODBEGIN);
			logger.debug("txnID :" + txnID);
		}

		List coreResponseDataList = null;

		if (txnID != null && !txnID.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
		
			String key = "core_res_" + txnID;
			
			List coreResponseData = (List)corePropertiesDataCache.getData(key);
			
			if (coreResponseData == null || coreResponseData.size() == 0) {		
				//logger.info("From table.......");				
				coreResponseData = getCoreServerDatas(txnID, "res");
			}
			
			coreResponseDataList = coreResponseData;//(List) coreResponseData.get("dataList");
			
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("coreResponseDataList :" + coreResponseDataList);
			logger.debug("findCoreResponseData(String txnID) "+ LoggingConstants.METHODEND);
		}
		
		
		return coreResponseDataList;
	}

	private List getCoreServerDatas(String txnID, String type) {
		
		
		
		if(logger.isDebugEnabled())
			logger.debug("getCoreServerData(String txnID, String type) "+ LoggingConstants.METHODBEGIN);

		List dataList = null;

		String key = "core_" + type + "_" + txnID;

		try {
			Object[] params = { new Integer(txnID), type, new Integer(txnID) };
		
			String sql = SQLConstants.GET_CORE_SERVER_DATA;
			
			dataList = getJdbcTemplate().queryForList(sql, params);

		} catch (DataAccessException ex) {
			logger.error("DataAccessException :",ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}

		if (dataList != null && dataList.size() > 0) {

			//Map coreDatas = new HashMap(); 
			
			//coreDatas.put("dataList", dataList);
			
			corePropertiesDataCache.setData(key, dataList);
			
			if(logger.isDebugEnabled())
				logger.debug("getCoreServerData(String txnID, String type) "+ LoggingConstants.METHODBEGIN);
			
			return dataList;
			
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return null;
	}
	
// method overloaded with bank code parameter for CR 5553
private List getCoreServerDatas(String txnID, String type,String bankCode) {
	if(logger.isDebugEnabled())
			logger.debug("getCoreServerData(String txnID, String type, String bankcode) "+ LoggingConstants.METHODBEGIN);

		List dataList = null;

		String key = "core_" + type + "_" + txnID+"_"+bankCode;

		try {
			Object[] params = { new Integer(txnID), type, new Integer(txnID) };
		
			String sql = SQLConstants.GET_SBI_CORE_SERVER_DATA;
			
			dataList = getJdbcTemplate().queryForList(sql, params);

		} catch (DataAccessException ex) {
			logger.error("DataAccessException :",ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}

		if (dataList != null && dataList.size() > 0) {
			
			corePropertiesDataCache.setData(key, dataList);
			if(logger.isDebugEnabled())
				logger.debug("getCoreServerData(String txnID, String type, String bankCode) "+ LoggingConstants.METHODBEGIN);
			return dataList;
			
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return null;
	}
	
	public int getMessageID(){
		
		int msgID = 0;
		try{
			msgID = getJdbcTemplate().queryForInt(SQLConstants.GET_MESSAGE_ID);
		}catch (DataAccessException ex) {
			logger.error("DataAccessException :",ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		return msgID;		
	} 
	
	public void setCorePropertiesDataCache(CorePropertiesDataCache corePropertiesDataCache) {
		this.corePropertiesDataCache = corePropertiesDataCache;
	} 


	
 
}
