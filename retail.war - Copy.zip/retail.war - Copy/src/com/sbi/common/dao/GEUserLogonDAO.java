
/*
 * GEUserLogonDAO.java
 * Created on Feb 13, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 13, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.dao;

import com.sbi.common.exception.DAOException;

public interface GEUserLogonDAO
{
    /**
     * 
     * Find status for GE User.
     * @param userName
     * @param password
     * @return
     * @throws DAOException String
     */
    String findStatus(String userName, String password) throws DAOException;
    
    boolean updateStatus(String userName, String password) throws DAOException;
}
