/**
 * @(#) FavoritesDAO.java
 */

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;
 
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Favorite;

public interface FavoritesDAO
{
	/**
	 * This method will insert a record into table SBI_FAVORITES.
	 * 
	 *  USER_NAME              VARCHAR2(30) NOT NULL ,
	 *  FAVORITE_TYPE          VARCHAR2(25) NOT NULL ,
	 *  CREATION_TIME          DATE NOT NULL ,
	 *  STATUS                 NUMBER(38) NOT NULL ,
	 *  LAST_MOD_TIME          DATE NOT NULL ,
	 *  FRIENDLY_NAME          VARCHAR2(50) NOT NULL ,
	 *  DEBIT_ACCOUNT_NO       VARCHAR2(17) NOT NULL ,
	 *  DEBIT_BRANCH_CODE      VARCHAR2(5) NOT NULL ,
	 *  DEBIT_ACCOUNT_TYPE              VARCHAR2(5),
	 *  CREDIT_ACCOUNT_NO               VARCHAR2(17),
	 *  CREDIT_BRANCH_CODE              VARCHAR2(5),
	 *  CREDIT_ACCOUNT_TYPE             VARCHAR2(5),
	 *  DURATION                        NUMBER(38),
	 *  BIILERNICKNAME                  VARCHAR2(50),
	 *  REMARKS                         VARCHAR2(255),
	 *  AMOUNT                          NUMBER(14,2),
	 *  PARAMETER1                      VARCHAR2(50),
	 *  PARAMETER2                      VARCHAR2(50)
	 * 
	 */
	boolean insertFavorite( Favorite favorite );
	
	/**
	 * This method will retrieve the Favorites for the given username from the table SBI_FAVORITES and returns the List of Favorite object.
	 * 
	 * Query 
	 * select * from SBI_FAVORITES where user_name=? and status=1
	 */
	List findFavorites( String userName );
	
	/**
	 * This method will retrieve the Favorite record for the given username and nickname from the table SBI_FAVORITES and return the Favorite object.
	 * 
	 * Query 
	 * select * from SBI_FAVORITES where user_name=? and friendly_name=? and  status=1
	 */
	Favorite findFavorites( String userName, String nickName );
	
	/**
	 * Make the favorite record offline for username and nickname
	 * 
	 * Query:
	 * update sbi_favorites set status=0 where user_name=? and friendly_name=?
	 */
	boolean deleteFavorite( String nickName, String userName );
    
   
     /**
     * TODO Enter the description of the method here
     * @param userName
     * @return
     * @throws DAOException Map
     */
    public Map findFavoriteName(String userName)throws DAOException;
	
}
