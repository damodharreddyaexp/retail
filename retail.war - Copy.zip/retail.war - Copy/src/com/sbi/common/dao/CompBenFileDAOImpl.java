/*
 * CompBenFileDAOImpl.java
 * Created on Aug 6, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.model.CompBenDataModel;
import com.sbi.common.model.CompBenFileModel;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.model.CorporateFile;


public class CompBenFileDAOImpl extends JdbcDaoSupport implements CompBenFileDAO
{

    private Logger logger = Logger.getLogger(getClass());

    public final static String SELECT_FIXED_FILE_CONFIGURATION = "select * from sbicorp_fixed_config where oid=? order by start_index";

    public final static String SELECT_DELIMITED_FILE_CONFIGURATION = "select * from sbicorp_delimited_config where oid=? order by order_no";

    public final static String SELECT_FIXED_FILE_NEW_CONFIGURATION = "select * from sbicorp_fixed_config where comp_config_type=? order by start_index";

    public final static String SELECT_DELIMITED_FILE_NEW_CONFIGURATION = "select * from sbicorp_delimited_config where comp_config_type=? order by order_no";
    
  //  private static final String SELECT_UPLOADER = "select d.name,b.user_alias from   sbicorp_ca_user_map a,  bv_user b,  bv_user_role c,  bv_user_profile d  where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_id = d.user_id  and c.user_role='21'  and d.corporate_id = ?  and b.user_state = '0' and a.ca_user=? order by upper(d.name) asc";
    
    private static final String SELECT_UPLOADER_SFTPUPLO = "select * from ( select d.name name,b.user_alias user_alias  from   sbicorp_ca_user_map a,  bv_user b,  bv_user_role c,  bv_user_profile d  where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_id = d.user_id  and c.user_role='21'  and d.corporate_id = ?  and b.user_state = '0' and a.ca_user= ? " +
    			                                           "union all select d.name name,b.user_alias user_alias from    bv_user b,  bv_user_role c,  bv_user_profile d  where  b.user_id = c.user_id and b.user_id = d.user_id  and c.user_id = d.user_id  and c.user_role='21'  and d.corporate_id =  ?  and b.user_state = '0' and   b.user_alias like  '%sftpuploader%') order by upper(name) asc";
    
    static final String SELECT_CB_3P_PENDING_FILES = " select a.* from sbi_file_master a,bv_user_profile c,bv_user b"+
    	       " where a.username = b.user_alias and c.user_id = b.user_id" +
    	       " and c.created_by=?  and a.file_status='Processed'  and b.user_alias = ? and upper(a.additional_field5) ='3P'  and exists (select 1 from sbicorp_third_party where status  not in (1,2) and file_name = a.sno and product_code_status='processed') order by a.sno desc";
    
    static final String SELECT_CB_IBTP_PENDING_FILES = "select a.* from bv_user_profile c, bv_user b, sbi_file_master a where a.file_status = 'Processed' and b.user_alias =? "+ 
    			" and  upper(a.ADDITIONAL_FIELD5) ='IBTP' and a.username = b.user_alias and c.user_id = b.user_id and c.created_by=?  and exists (select 1 from sbi_rtgs_beneficiary "+
				" where  STATUS  in ('Pending','pending_approval') and file_sno = a.sno)   order by a.creation_time desc";
    
    static final String SELECT_CB_D3P_PENDING_FILES = "SELECT  a.* FROM bvsbi.sbi_file_master a,bv_user_profile c,bv_user b WHERE b.user_alias = ? and a.file_status = 'Processed' "+ 
				" and upper(a.additional_field5)='D3P' and c.created_by=? and a.username = b.user_alias AND c.user_id = b.user_id AND "+
	    		" a.sno IN (SELECT DISTINCT (SUBSTR (file_name,1,(INSTR (file_name, '.')) - 1)) "+
	    		" FROM bvsbi.sbi_delete_third_party dt WHERE upper(status) in ('UNAPPROVED') and "+
	    		" dt.file_name = substr(a.file_name,6,(INSTR (a.file_name, '.'))-1)) ORDER BY a.sno DESC";
    
    static final String SELECT_CB_DIBTP_PENDING_FILES = "SELECT a.* FROM bv_user_profile c, bv_user b, sbi_file_master a WHERE b.user_alias = ? and c.created_by = ? and a.file_status = 'Processed' AND "+ 
				" UPPER (a.additional_field5) = 'DIBTP' AND a.username = b.user_alias AND c.user_id = b.user_id AND  "+
				" EXISTS(select 1 from bvsbi.sbi_rtgs_beneficiary dt where deletion_file_no = a.sno and status not in 'inactive') "+
				" ORDER BY sno DESC";
    
    static final String SELECT_CB_COMPBEN_PENDING_FILES = "select a.* from sbi_file_master a,bv_user_profile b,bv_user c where a.file_status='Processed' and "+ 
				" a.username = c.user_alias and b.user_id = c.user_id and b.corporate_id=?  and a.additional_field5='COMPOSITE_BEN'"+
				" and b.created_by=?  and c.user_alias = ?  and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporate_id  " +
				"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
				"and source='COMPOSITE'	and ( (d.COMP_BEN_STATUS = 'Pending'  and d.request_type  = 'A' ) or (d.COMP_BEN_STATUS  ='Approved'  and d.request_type = 'D' ) " +
				"or (d.validation_status = 0 and d.file_status='failure' ))	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
				"and a.username = d.uploader_name) order by a.creation_time desc ";

    
    
    static final String SELECT_CB_ADMINSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
    		  	"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
    		  	" b.branch_code = c.branch_code and c.core_banking=0 and b.ca_user= ? and b.corporateid=  ? and  a.file_status='Processed' and a.additional_field5='COMPOSITE_BEN' and b.account_no = a.additional_field8 and a.username =  ?" +
    		  	" and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
 				"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
 				"and source='COMPOSITE'	and ( (d.COMP_BEN_STATUS = 'Pending'  and d.request_type  = 'A' ) or (d.COMP_BEN_STATUS  ='Approved'  and d.request_type = 'D' ) " +
 				"or (d.validation_status = 0 and d.file_status='failure' ))	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
 				"and a.username = d.uploader_name) order by a.creation_time desc ";
    
    
    static final String SELECT_CB_REGSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
		  	"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
		  	" b.branch_code = c.branch_code and c.core_banking=0  and b.corporateid=  ? and  a.file_status='Processed' and a.additional_field5='COMPOSITE_BEN' and b.account_no = a.additional_field8 and a.username =  ?" +
		  	" and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
			"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
			"and source='COMPOSITE'	and ( (d.COMP_BEN_STATUS = 'Pending'  and d.request_type  = 'A' ) or (d.COMP_BEN_STATUS  ='Approved'  and d.request_type = 'D' ) " +
			"or (d.validation_status = 0 and d.file_status='failure' ))	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
			"and a.username = d.uploader_name) order by a.creation_time desc ";
	    		
    
   private static final  String SELECT_BEN_3P_REC_COUNT = "select count(*) from sbicorp_third_party c where exists (select user_alias from bv_user a, bv_user_profile b where a.user_alias = c.uploader_username and a.user_id=b.user_id and created_by= ?) " +
			"and FILE_NAME= ? and product_code_status='processed' and corporate_id = ? and status not in (1,2)";
    
    private static final String   SELECT_BEN_D3P_REC_COUNT ="select count(*) from sbi_delete_third_party c" +
    		         " where  upper(c.status)='UNAPPROVED' and FILE_NAME LIKE ?";
    
    private static final String   SELECT_BEN_IBTP_REC_COUNT  = "select count(*) from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?   and rtgs.STATUS  in ('Pending','pending_approval')";
  
	private static final String  SELECT_BEN_DIBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ? and corporate_id = ? and " +
		           " DELETION_APPROVED_BY is null and rtgs.status='active'";
	
	private static final String SELECT_COMPBEN_3P_REC_COUNT = "select count(*) from sbicorp_third_party c where "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ? and status not in (1,2) and uploader_username=?";
    
    private static final String SELECT_COMPBEN_D3P_REC_COUNT = "select count(*) from sbicorp_third_party c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.status = 1 and c.uploader_username=?";
    
    private static final String SELECT_COMPBEN_IBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where  file_sno=? and rtgs.status = 'pending_approval' and corporate_id = ? and user_name=?";
    
    private static final String SELECT_COMPBEN_DIBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where  rtgs.deletion_file_no= ? and rtgs.status = 'active' and DELETION_APPROVED_BY is null "+
			" and rtgs.corporate_id = ? ";
    
    private static final String SELECT_COMPBEN_VALIDATION_FAILURE_COUNT = "select count(*) from sbi_beneficiary_file_master "+
			" where validation_status = '0' and file_name =? and corporate_id=? and file_status='failure' and source='COMPOSITE' "+
			" and uploader_name=?";
     
    private static final  String SELECT_BEN_3P_REC_DISPLAY = "select c.*,decode(STATUS,'Unapproved',0,'Approved',1) status from sbicorp_third_party c where exists (select user_alias from bv_user a, bv_user_profile b where a.user_alias = c.uploader_username and a.user_id=b.user_id and created_by= ?) " +
    		"and FILE_NAME= ? and product_code_status='processed' and corporate_id = ? and status not in (1,2,3) order by upper(c.name_third_party) asc";
    
    private static final String   SELECT_BEN_IBTP_REC_DISPLAY  = "select  rtgs.*,decode(STATUS,'active',1,'rejected',2,0)status_rtgs from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?   and rtgs.STATUS  in ('Pending','pending_approval') ORDER BY UPPER(rtgs.third_party_name) asc";
    
    private static final String   SELECT_BEN_D3P_REC_DISPLAY ="select c.*,decode(STATUS,'Unapproved',0,'Approved',1) status_d3p from sbi_delete_third_party c" +
	         " where  upper(c.status)='UNAPPROVED' and FILE_NAME LIKE ? order by upper(c.benificiary_name) asc";
    
    private static final String  SELECT_BEN_DIBTP_REC_DISPLAY = "select rtgs.*,decode(STATUS,'inactive',1,0) status_rtgs from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ?  and corporate_id = ? and  " +
		         " DELETION_APPROVED_BY is null  and status='active' ORDER BY upper(rtgs.third_party_name) asc";
   
    private static final String SELECT_COMPBEN_3P_REC_DISPLAY = "select * from sbicorp_third_party c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ? and status not in (1,2,3) and uploader_username=?  order by upper(c.name_third_party) asc";
    
    private static final String SELECT_COMPBEN_D3P_REC_DISPLAY = "select * from sbicorp_third_party c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.status = 1 and c.uploader_username=?  order by upper(c.name_third_party) asc";
    
    private static final String SELECT_COMPBEN_IBTP_REC_DISPLAY = "select rtgs.*,decode(STATUS,'active',1,'rejected',2,0) status_rtgs from sbi_rtgs_beneficiary rtgs where   file_sno=? and rtgs.status = 'pending_approval' and corporate_id = ? and user_name=?  ORDER BY UPPER(rtgs.third_party_name) asc";
    
    private static final String SELECT_COMPBEN_DIBTP_REC_DISPLAY = "select rtgs.*,decode(STATUS,'inactive',1,0) status_rtgs from sbi_rtgs_beneficiary rtgs where  rtgs.deletion_file_no= ? and rtgs.status = 'active'  and DELETION_APPROVED_BY is null"+
			" and rtgs.corporate_id = ?  ORDER BY upper(rtgs.third_party_name) asc";
    
    private static final String SELECT_COMPBEN_VALIDATION_FAILURE_REC_DISPLAY = "select * from sbi_beneficiary_file_master "+
			" where validation_status = '0' and file_name =? and corporate_id=? and file_status='failure' and source='COMPOSITE' "+
			" and uploader_name=? order by upper(beneficiary_name) asc";
    
	public static final String UPDATE_BEN_3P_APPROVED = "update sbicorp_third_party set  status =1, user_name =? ,LAST_MOD_TIME=sysdate where oid =?  and corporate_id = ?";

	private static final String UPDATE_BEN_IBTP_APPROVED = "update sbi_rtgs_beneficiary  set  status ='active', approved_by =? ,last_modified_time=sysdate where id =? and DELETION_APPROVED_BY is null and status != 'rejected' and CORPORATE_ID = ?";

	public static final String UPDATE_BEN_D3P_APPROVED = "Update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where row_id in ? and corp_id = ?";

    private static final String UPDATE_BEN_DIBTP_APPROVED = "update sbi_rtgs_beneficiary  set  status ='inactive', DELETION_APPROVED_BY =? ,last_modified_time=sysdate where id =? and CORPORATE_ID = ? ";

	public static final String UPDATE_BEN_FILE_3P_APPROVED = "update sbicorp_third_party set  status =1, user_name =? ,LAST_MOD_TIME=sysdate where file_name =?  and corporate_id = ? and status not in (1,2)";

	private static final String UPDATE_BEN_FILE_IBTP_APPROVED = "update sbi_rtgs_beneficiary  set  status ='active', approved_by =? ,last_modified_time=sysdate where file_sno =? and DELETION_APPROVED_BY is null and STATUS  in ('Pending','pending_approval') and CORPORATE_ID = ?";

	public static final String UPDATE_BEN_FILE_D3P_APPROVED = "update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where file_name like ? and corp_id = ? and upper(status)='UNAPPROVED'";

    private static final String UPDATE_BEN_FILE_DIBTP_APPROVED = "update sbi_rtgs_beneficiary  set  status ='inactive', DELETION_APPROVED_BY =? ,last_modified_time=sysdate where deletion_file_no =? and CORPORATE_ID = ? and STATUS ='active' ";
    
	public static final String UPDATE_BEN_3P_REJECTED = "update sbicorp_third_party set  status =2, user_name =? ,LAST_MOD_TIME=sysdate where oid =?  and corporate_id = ?";

	private static final String UPDATE_BEN_IBTP_REJECTED = "update sbi_rtgs_beneficiary  set  status ='rejected', approved_by =? ,last_modified_time=sysdate where id =? and DELETION_APPROVED_BY is null and status != 'rejected' and CORPORATE_ID = ?";

    private static final String INSERT_AUDIT_QUERY = "insert into wac_audit_trail values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";

	public static final String UPDATE_BEN_FILE_3P_REJECTED = "update sbicorp_third_party set  status =2, user_name =? ,LAST_MOD_TIME=sysdate where file_name =?  and corporate_id = ? and status not in (1,2)";

	private static final String UPDATE_BEN_FILE_IBTP_REJECTED = "update sbi_rtgs_beneficiary  set  status ='rejected', approved_by =? ,last_modified_time=sysdate where file_sno =? and DELETION_APPROVED_BY is null and STATUS  in ('Pending','pending_approval') and CORPORATE_ID = ?";

	public static final String UPDATE_COMPBEN_D3P_APPROVED = "update sbicorp_third_party " +
			" set  status ='3',deletion_approved_by=? , approval_status='Deleted', " +
			" last_mod_time=sysdate where oid in(?)  and status = '1' and corporate_id = ?";
			
	
	public static final String UPDATE_COMPBEN_FILE_D3P_APPROVED = "update sbicorp_third_party " +  
			" set  status ='3', deletion_approved_by=? ,approval_status='Deleted', " +
			" last_mod_time=sysdate where deletion_file_no =?  and status = '1' and corporate_id = ? ";
	
	public static final String UPDATE_BEN_D3P_REJECTED = "Update sbi_delete_third_party set status='Rejected'  where row_id in ? and corp_id = ?";

    private static final String UPDATE_BEN_DIBTP_REJECTED = "update sbi_rtgs_beneficiary  set  deletion_file_no ='' where id =? and CORPORATE_ID = ? ";
    
	public static final String UPDATE_BEN_FILE_D3P_REJECTED = "update sbi_delete_third_party set status='Rejected'  where file_name like ? and corp_id = ? and upper(status)='UNAPPROVED'";
	
    private static final String UPDATE_BEN_FILE_DIBTP_REJECTED = "update sbi_rtgs_beneficiary  set  deletion_file_no ='' where deletion_file_no =? and CORPORATE_ID = ? and STATUS ='active' ";
    
    public static final String UPDATE_COMPBEN_D3P_REJECTED = "update sbicorp_third_party " +
			" set deletion_file_no ='' where oid in(?)  and status = '1' and corporate_id = ?";
			
	
	public static final String UPDATE_COMPBEN_FILE_D3P_REJECTED = "update sbicorp_third_party " +  
			" set  deletion_file_no ='' where deletion_file_no =?  and status = '1' and corporate_id = ? ";

	
	
	
	
 static final String SELECT_CB_VIEW_3P_PENDING_FILES = " select a.* from sbi_file_master a,bv_user_profile c,bv_user b"+
  	       " where a.username = b.user_alias and c.user_id = b.user_id" +
  	       " and c.created_by=? and a.file_status='Processed'  and b.user_alias = ? and upper(a.additional_field5) ='3P'  and exists (select 1 from sbicorp_third_party where file_name = a.sno and product_code_status='processed') order by a.sno desc";
  
  static final String SELECT_CB_VIEW_IBTP_PENDING_FILES = "select a.* from bv_user_profile c, bv_user b, sbi_file_master a where a.file_status = 'Processed' and b.user_alias =? "+ 
  			" and  upper(a.ADDITIONAL_FIELD5) ='IBTP' and a.username = b.user_alias and c.user_id = b.user_id and c.created_by=?  and exists (select 1 from sbi_rtgs_beneficiary "+
				" where  file_sno = a.sno) order by a.creation_time desc";
  
  static final String SELECT_CB_VIEW_D3P_PENDING_FILES = "SELECT  a.* FROM bvsbi.sbi_file_master a,bv_user_profile c,bv_user b WHERE b.user_alias = ? and a.file_status = 'Processed' "+ 
				" and upper(a.additional_field5)='D3P' and c.created_by=? and a.username = b.user_alias AND c.user_id = b.user_id AND "+
	    		" a.sno IN (SELECT DISTINCT (SUBSTR (file_name,1,(INSTR (file_name, '.')) - 1)) "+
	    		" FROM bvsbi.sbi_delete_third_party dt WHERE "+
	    		" dt.file_name = substr(a.file_name,6,(INSTR (a.file_name, '.'))-1) and dt.STATUS != 'Rejected')  ORDER BY a.sno DESC";
  
  static final String SELECT_CB_VIEW_DIBTP_PENDING_FILES = "SELECT a.* FROM bv_user_profile c, bv_user b, sbi_file_master a WHERE b.user_alias = ? and c.created_by = ? and a.file_status = 'Processed' AND "+ 
				" UPPER (a.additional_field5) = 'DIBTP' AND a.username = b.user_alias AND c.user_id = b.user_id AND  "+
				" EXISTS(select 1 from bvsbi.sbi_rtgs_beneficiary dt where deletion_file_no = a.sno ) "+
				" ORDER BY sno DESC";
  
  static final String SELECT_CB_VIEW_COMPBEN_PENDING_FILES = "select a.* from sbi_file_master a,bv_user_profile b,bv_user c where a.file_status='Processed' and "+ 
				" a.username = c.user_alias and b.user_id = c.user_id and b.corporate_id=?  and a.additional_field5='COMPOSITE_BEN' "+
				" and b.created_by=? and  c.user_alias = ? and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporate_id  " +
				"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
				"and source='COMPOSITE'	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
				"and a.username = d.uploader_name) order by a.creation_time desc ";
  
  static final String SELECT_CB_VIEW_ADMINSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
			"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
			" b.branch_code = c.branch_code and c.core_banking=0 and b.ca_user= ? and b.corporateid=  ? and a.file_status='Processed' and  a.additional_field5='COMPOSITE_BEN' and b.account_no = a.additional_field8 and a.username =  ?" +		
			"and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
			"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
			"and source='COMPOSITE'	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
			"and a.username = d.uploader_name) order by a.creation_time desc ";
  
  static final String SELECT_CB_VIEW_REGSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
			"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
			" b.branch_code = c.branch_code and c.core_banking=0  and b.corporateid=  ? and a.file_status='Processed' and  a.additional_field5='COMPOSITE_BEN' and b.account_no = a.additional_field8 and a.username =  ?" +		
			"and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
			"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
			"and source='COMPOSITE'	and d.beneficiary_type in ('S','O') and d.uploader_name  = ? " +
			"and a.username = d.uploader_name) order by a.creation_time desc ";


	private static final String SELECT_COMPBEN_VIEW_3P_REC_COUNT = "select count(*) from sbicorp_third_party c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ?  and uploader_username=?";
    
    private static final String SELECT_COMPBEN_VIEW_D3P_REC_COUNT = "select count(*) from sbicorp_third_party c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ?  and c.uploader_username=?";
    
    private static final String SELECT_COMPBEN_VIEW_IBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where  file_sno=?  and corporate_id = ? and user_name=?";
    
    private static final String SELECT_COMPBEN_VIEW_DIBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where rtgs.deletion_file_no= ? "+
			" and rtgs.corporate_id = ? ";
    
    private static final  String SELECT_BEN_VIEW_3P_REC_COUNT = "select count(*) from sbicorp_third_party c where exists (select user_alias from bv_user a, bv_user_profile b where a.user_alias = c.uploader_username and a.user_id=b.user_id and created_by= ?) " +
 			"and FILE_NAME= ? and product_code_status='processed' and corporate_id = ? ";
     
    private static final String   SELECT_BEN_VIEW_D3P_REC_COUNT ="select count(*) from sbi_delete_third_party c" +
     		         " where  FILE_NAME LIKE ?  and STATUS != 'Rejected'";
     
    private static final String   SELECT_BEN_VIEW_IBTP_REC_COUNT  = "select count(*) from sbi_rtgs_beneficiary rtgs "
             + "where  FILE_SNO=? ";
   
 	private static final String  SELECT_BEN_VIEW_DIBTP_REC_COUNT = "select count(*) from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ?  and corporate_id = ?";
            
 	
 	private static final  String SELECT_BEN_VIEW_3P_REC_DISPLAY = "select * from sbicorp_third_party c where exists (select user_alias from bv_user a, bv_user_profile b where a.user_alias = c.uploader_username and a.user_id=b.user_id and created_by= ?) " +
    		"and FILE_NAME= ? and product_code_status='processed' and corporate_id = ?  order by upper(c.name_third_party) asc";
    
    private static final String   SELECT_BEN_VIEW_IBTP_REC_DISPLAY  = "select  rtgs.*,decode(STATUS,'active',1,'inactive',1,'rejected',2,0) status_rtgs from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?  order by upper(rtgs.third_party_name) asc";
    
    private static final String   SELECT_BEN_VIEW_D3P_REC_DISPLAY = "select c.*,decode(STATUS,'Unapproved',0,'Approved',1) status_d3p from sbi_delete_third_party c" +
	         " where   FILE_NAME LIKE ? and STATUS != 'Rejected' order by upper(c.benificiary_name) asc";
    
    private static final String  SELECT_BEN_VIEW_DIBTP_REC_DISPLAY = "select rtgs.*,decode(STATUS,'inactive',1,0) status_rtgs from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ?   and corporate_id = ?" +
		     " order by upper(rtgs.third_party_name) asc";
   
    private static final String SELECT_COMPBEN_VIEW_3P_REC_DISPLAY = "select * from sbicorp_third_party c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ?  and uploader_username=? order by upper(c.name_third_party) asc";
    
    private static final String SELECT_COMPBEN_VIEW_D3P_REC_DISPLAY = "select c.*,decode(STATUS,'1',0,'3',1) status_d3p from sbicorp_third_party c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.uploader_username=? order by upper(c.name_third_party) asc";
    
    private static final String SELECT_COMPBEN_VIEW_IBTP_REC_DISPLAY = "select rtgs.*,decode(STATUS,'active',1,'inactive',1,'rejected',2,0) status_rtgs from sbi_rtgs_beneficiary rtgs where  file_sno=? and corporate_id = ? and user_name=? order by upper(rtgs.third_party_name) asc";
    
    private static final String SELECT_COMPBEN_VIEW_DIBTP_REC_DISPLAY =  "select rtgs.*,decode(STATUS,'inactive',1,0) status_rtgs from sbi_rtgs_beneficiary rtgs where  rtgs.deletion_file_no= ? "+
			" and rtgs.corporate_id = ?  order by upper(rtgs.third_party_name) asc";
    
    private static final  String SELECT_BEN_3P_REC_DISPLAY_DOWNLOAD = "select * from sbicorp_third_party c where exists (select user_alias from bv_user a, bv_user_profile b where a.user_alias = c.uploader_username and a.user_id=b.user_id and created_by= ?) " +
    		"and FILE_NAME= ? and product_code_status='processed' and corporate_id = ?  order by upper(c.name_third_party) asc";
    
    private static final String   SELECT_BEN_IBTP_REC_DISPLAY_DOWNLOAD  = "select  rtgs.*,decode(STATUS,'active',1,'rejected',2,0) status_rtgs from sbi_rtgs_beneficiary rtgs "
            + "where  FILE_SNO=?   ORDER BY upper(rtgs.third_party_name) asc";
    
    private static final String   SELECT_BEN_D3P_REC_DISPLAY_DOWNLOAD = "select c.*,decode(STATUS,'Unapproved',0,'Approved',1) status_d3p from sbi_delete_third_party c" +
	         " where   FILE_NAME LIKE ? and STATUS != 'Rejected'  order by upper(c.benificiary_name) asc";
    
    private static final String  SELECT_BEN_DIBTP_REC_DISPLAY_DOWNLOAD = "select rtgs.*,decode(STATUS,'inactive',1,0) status_rtgs	 from sbi_rtgs_beneficiary rtgs where  deletion_file_no= ? and corporate_id = ?" +
           "  ORDER BY upper(rtgs.third_party_name) asc";
    
    private static final  String SELECT_BEN_COMPOSITE_BEN_REC_DISPLAY_DOWNLOAD = "select * from (select c.NAME_THIRD_PARTY name,c.OUTREF7 EMP_CODE,c.ACCOUNT_NO ACCOUNT_NO,'' IFS_CODE ,c.STATUS STATUS,'Same Bank' BANK_TYPE,'Add' ACTION_TYPE,'' error_desc,'Success' val_status from " +
    		" sbicorp_third_party c where  FILE_NAME= ? and product_code_status='processed' and corporate_id = ?" +
    		" union all " +
    		" select  rtgs.THIRD_PARTY_NAME name,rtgs.EMP_CODE EMP_CODE,rtgs.ACCOUNT_NUMBER ACCOUNT_NO,rtgs.IFSC_CODE_RECEIVER IFS_CODE,decode(rtgs.STATUS,'active',1,'inactive',1,'rejected',2,0) STATUS,'Other Bank' BANK_TYPE,'Add' ACTION_TYPE,'' error_desc,'Success' val_status  from sbi_rtgs_beneficiary rtgs " +
    		" where  FILE_SNO=? union all " +
    		" select   c.NAME_THIRD_PARTY name,c.OUTREF7 EMP_CODE,c.ACCOUNT_NO ACCOUNT_NO,'' IFS_CODE ,decode(c.STATUS,'1',0,'3',1) STATUS,'Same Bank' BANK_TYPE,'Delete' ACTION_TYPE,'' error_desc,'Success' val_status  from sbicorp_third_party c where " +
    		" c.deletion_file_no =? and c.product_code_status='processed' and c.corporate_id = ? " +
    		" union all " +
    		" select  rtgs.THIRD_PARTY_NAME name,rtgs.EMP_CODE EMP_CODE,rtgs.ACCOUNT_NUMBER ACCOUNT_NO,rtgs.IFSC_CODE_RECEIVER IFS_CODE,decode(STATUS,'inactive',1,0) STATUS,'Other Bank' BANK_TYPE,'Delete' ACTION_TYPE,'' error_desc,'Success' val_status from sbi_rtgs_beneficiary rtgs where  " +
    		" rtgs.deletion_file_no= ? and rtgs.corporate_id = ?" +
    		" union all" +
    		" select beneficiary_name name,beneficiary_code EMP_CODE,account_no ACCOUNT_NO,ifsc_code IFS_CODE,decode(validation_status,'0',4,4) STATUS,'' BANK_TYPE,'' ACTION_TYPE,validation_desc error_desc,'Failure' val_status from sbi_beneficiary_file_master " +
    		" where validation_status = '0' and file_name = ? and corporate_id= ? and file_status='failure' and source='COMPOSITE' )" +
    		" order by BANK_TYPE asc,ACTION_TYPE,upper(name) asc";

    private static final  String SELECT_BEN_AADHAR_BEN_REC_DISPLAY_DOWNLOAD = "select * from (select c.NAME_THIRD_PARTY name,c.OUTREF7 EMP_CODE,c.AADHAR_ID AADHAR_ID,c.BANK_IIN BANK_IIN,c.STATUS STATUS,'Same Bank' BANK_TYPE,'Add' ACTION_TYPE,'' error_desc,'Success' val_status from " +
    		" SBICORP_AADHAR_BENEFICIARY c where  FILE_NAME= ? and product_code_status='processed' and corporate_id = ?" +
    		" union all " +
    		" select   c.NAME_THIRD_PARTY name,c.OUTREF7 EMP_CODE,c.AADHAR_ID AADHAR_ID,c.BANK_IIN BANK_IIN,decode(c.STATUS,'1',0,'3',1) STATUS,'Same Bank' BANK_TYPE,'Delete' ACTION_TYPE,'' error_desc,'Success' val_status  from SBICORP_AADHAR_BENEFICIARY c where " +
    		" c.deletion_file_no =? and c.product_code_status='processed' and c.corporate_id = ? " +
    		" union all " +
    		" select beneficiary_name name,beneficiary_code EMP_CODE,AADHAR_ID AADHAR_ID,BANK_IIN BANK_IIN,decode(validation_status,'0',4,4) STATUS,'' BANK_TYPE,'' ACTION_TYPE,validation_desc error_desc,'Failure' val_status from sbi_beneficiary_file_master " +
    		" where validation_status = '0' and file_name = ? and corporate_id= ? and file_status='failure' and source='COMPOSITE' )" +
    		" order by BANK_TYPE asc,ACTION_TYPE,upper(name) asc";
    
    //Beleow code Changed For Aadhar
    
    static final String SELECT_AADHAR_COMPBEN_PENDING_FILES = "select a.* from sbi_file_master a,bv_user_profile b,bv_user c where a.file_status='Processed' and "+ 
			" a.username = c.user_alias and b.user_id = c.user_id and b.corporate_id=?  and a.additional_field5  = 'ABTP' "+
			" and b.created_by=?  and c.user_alias = ?  and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporate_id  " +
			"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
			"and source='COMPOSITE'	and ( (d.COMP_BEN_STATUS = 'Pending'  and d.request_type  = 'A' ) or (d.COMP_BEN_STATUS  ='Approved'  and d.request_type = 'D' ) " +
			"or (d.validation_status = 0 and d.file_status='failure' ))	and d.beneficiary_type = 'AA'  and d.uploader_name  = ? " +
			"and a.username = d.uploader_name) order by a.creation_time desc ";
    
    static final String SELECT_AADHAR_ADMINSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
		  	"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
		  	" b.branch_code = c.branch_code and c.core_banking=0 and b.ca_user= ? and b.corporateid=  ? and  a.file_status='Processed' and a.additional_field5 = 'ABTP' and b.account_no = a.additional_field8 and a.username =  ?" +
		  	" and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
				"and a.username like '%sftpuploader%' and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
				"and source='COMPOSITE'	and ( (d.COMP_BEN_STATUS = 'Pending'  and d.request_type  = 'A' ) or (d.COMP_BEN_STATUS  ='Approved'  and d.request_type = 'D' ) " +
				"or (d.validation_status = 0 and d.file_status='failure' ))	and d.beneficiary_type = 'AA' and d.uploader_name  = ? " +
				"and a.username = d.uploader_name) order by a.creation_time desc ";
    
	private static final String SELECT_AADHAR_3P_REC_COUNT = "select count(*) from SBICORP_AADHAR_BENEFICIARY c where "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ? and status not in (1,2) and uploader_username=?";
    
    private static final String SELECT_AADHAR_D3P_REC_COUNT = "select count(*) from SBICORP_AADHAR_BENEFICIARY c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.status = 1 and c.uploader_username=?";

    private static final String SELECT_AADHAR_VALIDATION_FAILURE_COUNT = "select count(*) from sbi_beneficiary_file_master "+
			" where validation_status = '0' and file_name =? and corporate_id=? and file_status='failure' and source='COMPOSITE' "+
			" and uploader_name=?";
    
    private static final String SELECT_AADHAR_3P_REC_DISPLAY = "select * from SBICORP_AADHAR_BENEFICIARY c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ? and status not in (1,2,3) and uploader_username=?  order by upper(c.name_third_party) asc";
    
    private static final String SELECT_AADHAR_D3P_REC_DISPLAY = "select * from SBICORP_AADHAR_BENEFICIARY c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.status = 1 and c.uploader_username=?  order by upper(c.name_third_party) asc";
    
    private static final String SELECT_AADHAR_VALIDATION_FAILURE_REC_DISPLAY = "select * from sbi_beneficiary_file_master "+
			" where validation_status = '0' and file_name =? and corporate_id=? and file_status='failure' and source='COMPOSITE' "+
			" and uploader_name=? order by upper(beneficiary_name) asc";
    
	public static final String UPDATE_AADHARBEN_3P_APPROVED = "update SBICORP_AADHAR_BENEFICIARY set  status =1, user_name =? ,LAST_MOD_TIME=sysdate where oid =?  and corporate_id = ?";
	
	public static final String UPDATE_AADHARBEN_D3P_APPROVED = "update SBICORP_AADHAR_BENEFICIARY " +
			" set  status ='3',deletion_approved_by=? , approval_status='Deleted', " +
			" last_mod_time=sysdate where oid in(?)  and status = '1' and corporate_id = ?";
	
	public static final String UPDATE_AADHARBEN_FILE_3P_APPROVED = "update SBICORP_AADHAR_BENEFICIARY set  status =1, user_name =? ,LAST_MOD_TIME=sysdate where file_name =?  and corporate_id = ? and status not in (1,2)";
	
	
	public static final String UPDATE_AADHARBEN_FILE_D3P_APPROVED = "update SBICORP_AADHAR_BENEFICIARY " +  
			" set  status ='3', deletion_approved_by=? ,approval_status='Deleted', " +
			" last_mod_time=sysdate where deletion_file_no =?  and status = '1' and corporate_id = ? ";

	public static final String UPDATE_AADHARBEN_3P_REJECTED = "update SBICORP_AADHAR_BENEFICIARY set  status =2, user_name =? ,LAST_MOD_TIME=sysdate where oid =?  and corporate_id = ?";

    
	public static final String UPDATE_AADHARBEN_D3P_REJECTED = "update SBICORP_AADHAR_BENEFICIARY " +
			" set deletion_file_no ='' where oid in(?)  and status = '1' and corporate_id = ?";
	
	
	public static final String UPDATE_AADHARBEN_FILE_3P_REJECTED = "update SBICORP_AADHAR_BENEFICIARY set  status =2, user_name =? ,LAST_MOD_TIME=sysdate where file_name =?  and corporate_id = ? and status not in (1,2)";
	
	
	public static final String UPDATE_AADHARBEN_FILE_D3P_REJECTED = "update SBICORP_AADHAR_BENEFICIARY " +  
			" set  deletion_file_no ='' where deletion_file_no =?  and status = '1' and corporate_id = ? ";
	
	  static final String SELECT_AADHAR_VIEW_COMPBEN_PENDING_FILES = "select a.* from sbi_file_master a,bv_user_profile b,bv_user c where a.file_status='Processed' and "+ 
				" a.username = c.user_alias and b.user_id = c.user_id and b.corporate_id=?  and a.additional_field5  = 'ABTP'  "+
				" and b.created_by=? and  c.user_alias = ? and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporate_id  " +
				"and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
				"and source='COMPOSITE'	and d.beneficiary_type = 'AA'  and d.uploader_name  = ? " +
				"and a.username = d.uploader_name) order by a.creation_time desc ";

static final String SELECT_AADHAR_VIEW_ADMINSFTP_PENDING_FILES = "select a.* from sbi_file_master a,sbicorp_ca_account_map b,sbi_branch_master c  " +
			"where b.verify_flag=0 and  b.status=1 and b.product_type is not null and c.status=1 and " +
			" b.branch_code = c.branch_code and c.core_banking=0 and b.ca_user= ? and b.corporateid=  ? and a.file_status='Processed' and  a.additional_field5  = 'ABTP' and b.account_no = a.additional_field8 and a.username =  ?" +		
			"and exists(select 1 from sbi_beneficiary_file_master d where  d.file_name=a.sno and d.corporate_id=b.corporateid  " +
			"and a.username like '%sftpuploader%' and d.corporate_id = ? and ( d.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or d.approved_status is null)  and file_status not in ('Pending') " +
			"and source='COMPOSITE'	and d.beneficiary_type = 'AA'  and d.uploader_name  = ? " +
			"and a.username = d.uploader_name) order by a.creation_time desc ";
	
	private static final String SELECT_AADHAR_VIEW_3P_REC_COUNT = "select count(*) from SBICORP_AADHAR_BENEFICIARY c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ?  and uploader_username=?";
	
	private static final String SELECT_AADHAR_VIEW_D3P_REC_COUNT = "select count(*) from SBICORP_AADHAR_BENEFICIARY c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ?  and c.uploader_username=?";
	
	private static final String SELECT_AADHAR_VIEW_3P_REC_DISPLAY = "select * from SBICORP_AADHAR_BENEFICIARY c where  "+ 
			"  FILE_NAME= ? and product_code_status='processed' "+
    		" and corporate_id = ?  and uploader_username=? order by upper(c.name_third_party) asc";
	
	private static final String SELECT_AADHAR_VIEW_D3P_REC_DISPLAY = "select c.*,decode(STATUS,'1',0,'3',1) status_d3p from SBICORP_AADHAR_BENEFICIARY c where  "+
			"  c.deletion_file_no =? and c.product_code_status='processed' "+
			" and c.corporate_id = ? and c.uploader_username=? order by upper(c.name_third_party) asc";
	


    
    public List getFileConfiguration(String corporateId,String fileType) throws DAOException {
		logger.info("getFileConfiguration(String corporateId,String fileType) - begin");
		List configList = null;
		List list = null;
		String query =null;
		Object[] params = new Object[] { corporateId };
		logger.info("Input param corporate Id ="+corporateId);
		try {

			query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and txn_type ='" + fileType + "' and status=1";
			logger.info("query::::"+query);
				
			configList = getJdbcTemplate().query(query, params,new ConfigurationMapper());
			logger.info("Result : "+configList);
			if ((configList != null) && (configList.size() > 0)) {

				CompBenFileModel configuration = (CompBenFileModel) configList.get(0);
				String txn_type=configuration.getTransactionType();
				logger.info("file Type:"+fileType);

				int format = configuration.getFormat();

				if (configuration.getFormat() != 0) {
					
					Object[] paramsfixed = new Object[] { configuration.getOid() };
					logger.info("OID:"+configuration.getOid());
					list = getJdbcTemplate().query(SELECT_FIXED_FILE_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
					logger.info("Fixed configuration :"+list);
					
					if ((list != null) && (list.size() > 0)) {
						CompBenFileModel configuration2 = (CompBenFileModel) list.get(0);
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
					
				} else {
					
					Object[] paramsdelimited = new Object[] { configuration.getOid() };
					logger.info("OID:" +configuration.getOid());
                   
					list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_CONFIGURATION,
                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
					
                  	logger.info("Delimited configuration ="+list);
					if ((list != null) && (list.size() > 0)) {
						CompBenFileModel configuration2 = (CompBenFileModel) list.get(0);
						configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
				}
			
			}
		} catch (DataAccessException e) {
			logger.error("Error occured :" , e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("getFileConfiguration(String corporateId,String fileType) - end");
		return list;
	}
    
    public List getNewFileConfiguration(String corporateId,String fileType) throws DAOException {
		logger.info("getNewFileConfiguration(String corporateId,String fileType) - begin");
		List configList = null;
		List list = null;
		String query =null;
		Object[] params = new Object[] { corporateId };
		logger.info("corporate Id :"+corporateId);
		try {

			query="select * from sbicorp_file_config_master where id =? and corporate_type='Corporate' and upper(stage) like '%IN%' and txn_type ='" + fileType + "' and status=1";
			logger.info("query::::"+query);
				
			configList = getJdbcTemplate().query(query, params,new ConfigurationMapper());
			logger.info("Result : "+configList);
			if ((configList != null) && (configList.size() > 0)) {

				CompBenFileModel configuration = (CompBenFileModel) configList.get(0);
				String txn_type=configuration.getTransactionType();
				logger.info("file Type:"+fileType);

				int format = configuration.getFormat();

				String compositeConfigType=(String)configuration.getCompConfigType();
				
				if (configuration.getFormat() != 0) {
					
					Object[] paramsfixed = new Object[] { compositeConfigType };
					logger.info("compositeConfigType :" +compositeConfigType);
					
					list = getJdbcTemplate().query(SELECT_FIXED_FILE_NEW_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
					logger.info("Fixed configuration :"+list);
					
					if ((list != null) && (list.size() > 0)) {
						CompBenFileModel configuration2 = (CompBenFileModel) list.get(0);
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
					
				} else {
					
					Object[] paramsdelimited = new Object[] { compositeConfigType };
					logger.info("compositeConfigType :" +compositeConfigType);
                   
					list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_NEW_CONFIGURATION,
                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
					
                  	logger.info("Delimited configuration ="+list);
					if ((list != null) && (list.size() > 0)) {
						CompBenFileModel configuration2 = (CompBenFileModel) list.get(0);
						configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					
					}
				}
			
			}
		} catch (DataAccessException e) {
			logger.error("Error occured :" , e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("getNewFileConfiguration(String corporateId,String fileType) - end");
		return list;
	}
    
    public int findConfigCount(String corporateId,String replacedString) throws DAOException {
		logger.info("findConfigCount(String corporateId,String replacedString) method begins");
		int  countVal = 0;
		try{
			if(corporateId != null && replacedString != null) {
				Object[] params={corporateId};
				String query="select count(*) from sbicorp_file_config_master where txn_type in (#tobereplaced#) and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate' and status=1";
				
				String finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
				logger.info("finalQuery :" +finalQuery);
				logger.info("corporateId :" +corporateId);
				countVal = getJdbcTemplate().queryForInt(finalQuery,params);
				logger.info("Count value for type"+replacedString+"is"+countVal);
			}
		    else
		    {
		    	DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findConfigCount(String corporateId,String replacedString)  method ends");
		return countVal;
   }
   
    public int deleteOldConfig(String corporateId) throws DAOException {
		logger.info("deleteOldConfig(String corporateId) method begins");
		int  delDelimtCount = 0;
		int  delFixedCount = 0;
		int  delConfigCount = 0;
		int  udpateCount = 0; 
		try{
			Object[] params={corporateId};
			/*String delDelimtquery ="Delete from SBICORP_DELIMITED_CONFIG where oid in (select oid from  sbicorp_file_config_master where txn_type in ('IBTP' ,'3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP') and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate')";
			String delFixedquery  ="Delete from SBICORP_FIXED_CONFIG where oid in (select oid from  sbicorp_file_config_master where txn_type in ('IBTP' ,'3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP') and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate')";
			String delConfigquery ="Delete from SBICORP_FILE_CONFIG_MASTER where  txn_type in ('IBTP' ,'3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP') and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate'";
			logger.info("corporateId :"+corporateId);
			delDelimtCount = getJdbcTemplate().update(delDelimtquery, params);
			logger.info("Deleted Count in SBICORP_DELIMITED_CONFIG table is"+delDelimtCount);
			delFixedCount = getJdbcTemplate().update(delFixedquery, params);
			logger.info("Deleted Count in SBICORP_FIXED_CONFIG table is"+delFixedCount);
			delConfigCount = getJdbcTemplate().update(delConfigquery, params);
			logger.info("Deleted Count in SBICORP_FILE_CONFIG_MASTER table is"+delConfigCount);*/
			
			String updateQuery ="update SBICORP_FILE_CONFIG_MASTER set status=2 where oid in (select oid from  sbicorp_file_config_master where txn_type in ('IBTP' ,'3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP') and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate')";
			
			logger.info("query:"+updateQuery);
			logger.info("parameters:"+params);
			udpateCount = getJdbcTemplate().update(updateQuery, params);
			logger.info("no of rows updated:"+udpateCount);
			
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("deleteOldConfig(String corporateId)  method ends");
		return udpateCount;
	}
    
    public boolean findFileStatusTP(String corporateID) throws DAOException {
        logger.info("findFileStatusTP( String corporateID)method begin");
        if(logger.isDebugEnabled())
            logger.debug("corporateID  : " + corporateID);

        boolean test = false;
        logger.info("corporateID :" + corporateID );

        if(corporateID != null && !corporateID.trim().equalsIgnoreCase(""))
        {	
            try
            {
                Object parameter[] = {
                    corporateID
                };
                List result = getJdbcTemplate().queryForList("select FILE_STATUS from sbi_file_master where additional_field3=? and file_status in ('Pending','Picked') and filetype in ('3P','C3P') and additional_field5 in ('IBTP','3P','IBTP|DIBTP','3P|D3P','D3P','DIBTP')", parameter);
                logger.info("result :" + result);
                if(result.size() >= 1)
                {
                    test = true;
                    return test;
                }
            }
            catch(DataAccessException exception)
            {
                DAOException.throwException("F001", exception);
            }
        }    
        else
            DAOException.throwException("CR002");
        logger.info("findFileStatusTP( String corporateID )method end");
        return test;
    }
    
    public int insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) throws DAOException
    {
    	int insertCount =0;
        logger.info("insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method begin");
         try
            {
			    Object params[] = {
                    corporateId,formatVal,fieldDelimter,compConfigType
                };
			    logger.info("corporateId :" + corporateId+" formatVal :" + formatVal+" fieldDelimter :" + fieldDelimter+"compConfigType :" + compConfigType);
                 insertCount = getJdbcTemplate().update("insert into SBICORP_FILE_CONFIG_MASTER(oid,id,store_id,creation_time, status,deleted,last_mod_time,corporate_type,stage,txn_type,mode_config,format,field_delimiter,record_delimiter,comp_config_type)values(oid_sequence.nextval,?,101,sysdate,1,0,sysdate,'Corporate','IN','COMPOSITE_BEN','File',?,?,'N',?)", params);
                logger.info("Record inserted For Composite Config:" + insertCount);
               
            }
            catch(DataAccessException exception)
            {
                DAOException.throwException("F001", exception);
            }
        logger.info("insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method end");
        return insertCount;
    } 
    
    public Map updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) throws DAOException
    {
    	Map updateVal = new HashMap();
    	int updateCount = 0;
    	int  countVal = 0;
        logger.info("updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method begin");
         try
            {
        	 
        	 Object[] parameter={corporateId,compConfigType};
    		 Object params[] = {
                    formatVal,fieldDelimter,compConfigType,corporateId
                };
			    
			    String query="select count(*) from sbicorp_file_config_master where   id = ? and COMP_CONFIG_TYPE=? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate'  and txn_type='COMPOSITE_BEN' and status=1";
			    logger.info("corporateId :" + corporateId+" compConfigType :" + compConfigType);
			    countVal = getJdbcTemplate().queryForInt(query,parameter);
			    
			    if(countVal == 0){
			    	logger.info("formatVal :" + formatVal+" fieldDelimter :" + fieldDelimter+"compConfigType :" + compConfigType+"corporateId :" + corporateId);
                updateCount = getJdbcTemplate().update("update sbicorp_file_config_master set format = ?,FIELD_DELIMITER=?,COMP_CONFIG_TYPE=? where id =? and txn_type='COMPOSITE_BEN'", params);
                logger.info("Record Updated For Composite Config:" + updateCount);
                }else if(countVal > 0){
			     updateVal.put("configPresentVal", "Yes");
			  	 logger.info("Configuration already present so configPresentVal is Yes"+countVal);
			    }
			    updateVal.put("updateCount",updateCount);
            }
            catch(DataAccessException exception)
            {
                DAOException.throwException("F001", exception);
            }
        logger.info("updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method end");
        return updateVal;
    }
    
    
    
    
     
    public List findUploader(String userName,String corporateId) throws DAOException {
		logger.info("findUploader(String userName,String corporateId) method begins");
		logger.info("userName: " + userName);
		logger.info("Corporate ID: " + corporateId);
		List uploaderList = null;
		try{
				Object[] params={corporateId,userName,corporateId};
				uploaderList = getJdbcTemplate().queryForList(SELECT_UPLOADER_SFTPUPLO,params);	
		}catch(DataAccessException exp){
			DAOException.throwException(exp,"SE010",new Object[]{corporateId});
		}
		logger.info("findUploader(String userName,String corporateId) method ends");
		return uploaderList;
	}
    
    public class ConfigurationMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CompBenFileModel configuration = new CompBenFileModel();
			configuration.setFormat(rs.getInt(DAOConstants.FORMAT));
			//logger.info("Format : " + configuration.getFormat());
			configuration.setFieldDelimiter(rs.getString(DAOConstants.FIELD_DELIMITER));
			configuration.setOid(rs.getLong(DAOConstants.OID));
			configuration.setTransactionType(rs.getString("TXN_TYPE"));
			configuration.setCompConfigType(rs.getString("comp_config_type"));
			return configuration;
		}
	}
    public class DelimitedFileConfigurationMapper implements RowMapper {

		String type=null;
		
		public DelimitedFileConfigurationMapper(String txnType) {
			this.type=txnType;
		}
		
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

			CompBenFileModel fileConfiguration = new CompBenFileModel();
			fileConfiguration.setFormat(0);	
			
			if(type!=null && (type.equalsIgnoreCase("3P")|| type.equalsIgnoreCase("IBTP") || type.equalsIgnoreCase("D3P")|| type.equalsIgnoreCase("DIBTP")))			
			{
				if(rs.getString("field_name").equalsIgnoreCase("OUTREF7")){
					fileConfiguration.setFieldName("Beneficiary Code");
				}
				else if(rs.getString("field_name").substring(0,3).equalsIgnoreCase("OUT")){
					fileConfiguration.setFieldName("OUTREF");
				}
				else
					fileConfiguration.setFieldName(rs.getString("field_name"));
			}
			else
			{
				if(rs.getString("field_name").substring(0,3).equalsIgnoreCase("OUT")){
					fileConfiguration.setFieldName("OUTREF");
				}
				else
					fileConfiguration.setFieldName(rs.getString("field_name"));
			}

			fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
			fileConfiguration.setOrderNumber(rs.getInt(DAOConstants.ORDER_NO));
			fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
			fileConfiguration.setMaxLength(rs.getString("FIELD_LENGTH"));
			if (type != null && type.equalsIgnoreCase("CJ")) {
				fileConfiguration.setFieldValue(rs.getString("DEFAULT_VALUE"));
			}
			fileConfiguration.setCompConfigType(rs.getString("comp_config_type"));
			return fileConfiguration;

		}

	}
    public class FixedFileConfigurationMapper implements RowMapper {
		
    	String type=null;
		
		public FixedFileConfigurationMapper(String txnType) {
			this.type=txnType;
		}
		 
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CompBenFileModel fileConfiguration = new CompBenFileModel();
			//fileConfiguration.setFormat(rs.getInt(DAOConstants.FORMAT));
			fileConfiguration.setFormat(1);			
			
			if(type!=null && (type.equalsIgnoreCase("3P")|| type.equalsIgnoreCase("IBTP") || type.equalsIgnoreCase("D3P")|| type.equalsIgnoreCase("DIBTP")))			
			{
				if(rs.getString(DAOConstants.FLD_NAME).equalsIgnoreCase("OUTREF7")){
					fileConfiguration.setFldName("Beneficiary Code");
				}
				else if(rs.getString(DAOConstants.FLD_NAME).substring(0,3).equalsIgnoreCase("OUT")){
					fileConfiguration.setFldName("OUTREF");
				}
				else
					fileConfiguration.setFldName(rs.getString(DAOConstants.FLD_NAME));
			}
			else{
			
				if(rs.getString(DAOConstants.FLD_NAME).substring(0,3).equalsIgnoreCase("OUT"))
					fileConfiguration.setFldName("OUTREF");
				else
					fileConfiguration.setFldName(rs.getString(DAOConstants.FLD_NAME));
			}
			
			fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
			fileConfiguration.setStartIndex(rs.getInt(DAOConstants.START_INDEX));
			fileConfiguration.setEndIndex(rs.getInt(DAOConstants.END_INDEX));
			fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
            fileConfiguration.setConstantValue(rs.getInt("CONST_VALUE"));
            fileConfiguration.setDefaultValue(rs.getInt("DEFAULT_VALUE"));
            fileConfiguration.setCompConfigType(rs.getString("comp_config_type"));
			return fileConfiguration;

		}

	}  
    public List findTPFiles(String userName,String uploaderName) throws DAOException {

		logger.info("findTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
		
		List result = new ArrayList();

		try {
			Object[] parameters = new Object[] {userName,uploaderName};
			logger.info("userName :" + userName +"uploaderName :"+uploaderName);
			result = getJdbcTemplate().query(SELECT_CB_3P_PENDING_FILES,parameters, new CorporateFileRowMapper());       
							
			if (result.size() > 0) 
			{
				logger.info("Result size in side if loop :"+result.size());
			}
		} catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODEND);
		return result;

	}
    public class CorporateFileRowMapper implements RowMapper {
		
    	public Object mapRow(ResultSet rs, int index) throws SQLException {
			
    		String fileName = rs.getString(DAOConstants.FILE_NAME);
			StringTokenizer st = new StringTokenizer(fileName,"/");
			
			st.nextToken();
			
			CorporateFile corporateFile = new CorporateFile();			  
			corporateFile.setSno((rs.getString(DAOConstants.SNO)));
			corporateFile.setFileName(st.nextToken());
			corporateFile.setUploaderName(rs.getString(DAOConstants.USERNAME));
			corporateFile.setUploadedDate(rs.getTimestamp(DAOConstants.CREATION_TIME));
			corporateFile.setFileType(rs.getString("additional_field5"));
			
			return corporateFile;
		}   
	}  
    public List findTPInterFiles(String userName, String uploaderName) throws DAOException
    {

       logger.info("findTPInterFiles(String userName, String uploaderName)"+ LoggingConstants.METHODBEGIN);
       logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
       List result = new ArrayList();
       CorporateFile[] corporateFileArray = null;
       
       try
	   {
    	   Object[] parameters = new Object[] { uploaderName,userName};
    	   result = getJdbcTemplate().query(SELECT_CB_IBTP_PENDING_FILES, parameters,new CorporateFileInterRowMapper());
	
		   if (result != null && result.size() > 0)
           {
               logger.info("Result size in side if loop:" + result.size());
           }
	   }
       catch (DataAccessException ex)
       {
           DAOException.throwException("F001", ex);
       }
		logger.info("findTPInterFiles(String userName, String uploaderName)"+ LoggingConstants.METHODEND);
		return result;

    }

	public class CorporateFileInterRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CorporateFile corporateFile = new CorporateFile();
            String fileName = rs.getString("FILE_NAME");
            StringTokenizer st = new StringTokenizer(fileName, "/");
            while (st.hasMoreTokens())
            {
                corporateFile.setSno((rs.getString("SNO")));
                corporateFile.setFileName(st.nextToken());
                corporateFile.setUploaderName(rs.getString("USERNAME"));
                corporateFile.setUploadedDate(rs.getTimestamp(DAOConstants.CREATION_TIME));
                corporateFile.setFileType(rs.getString("additional_field5"));
    			
            }
            return corporateFile;
        }
    }
	
	public List findTPDelFiles(String userName, String uploaderName) throws DAOException {
        
        logger.info("findTPDelFiles(String userName, String uploaderName)" + LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
       
        List result = new ArrayList();

        try {
      
            Object[] parameters = new Object[] {uploaderName,userName};
            result = getJdbcTemplate().query(SELECT_CB_D3P_PENDING_FILES,parameters, new CorporateFileRowMapper());
           
            logger.info("Result ::"+result);
            
            if (result.size() > 0 &&  result != null) {
                logger.info("Result size in side if :"+result.size());
            }
            
            
        } catch (DataAccessException ex) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("findTPDelFiles(String userName, String uploaderName)"+ LoggingConstants.METHODEND);
        return result;

    }
	public List findDIBTPFiles(String userName,String uploaderName) throws DAOException
    {

        logger.info("findDIBTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
        logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
        
        List result = new ArrayList();
        CorporateFile[] corporateFileArray = null;

        try
        {
        	Object[] parameters = new Object[] {uploaderName,userName}; 
            result = getJdbcTemplate().query(SELECT_CB_DIBTP_PENDING_FILES, parameters,new CorporateFileRowMapper());
           
            if (result != null && result.size() > 0)
            {
            	logger.info("Result size in side if loop:" + result.size());
            }
        }
        catch (DataAccessException ex)
        {
            DAOException.throwException("F001", ex);
        }
        
        logger.info("findDIBTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
        return result;

    }
	public List findCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException {

		logger.info("findCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODBEGIN);
		logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName + "benFileType :" +benFileType);
		
		List result = new ArrayList();
		if(corporateId != null &&  uploaderName != null && userName != null && benFileType != null) {
		try {
			if("3P".equals(benFileType)){
			Object[] parameters = new Object[] {corporateId,userName,uploaderName,corporateId,uploaderName};
			result = getJdbcTemplate().query(SELECT_CB_COMPBEN_PENDING_FILES,parameters, new CorporateFileRowMapper());       
			}else if("ABTP".equals(benFileType)){
			Object[] parameters = new Object[] {corporateId,userName,uploaderName,corporateId,uploaderName};
			result = getJdbcTemplate().query(SELECT_AADHAR_COMPBEN_PENDING_FILES,parameters, new CorporateFileRowMapper()); 	
			}
			if (result.size() > 0) 
			{
				logger.info("Result size in side if loop :"+result.size());
			}
		} catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		} else {
			DAOException.throwException("F001");
		}
		
		logger.info("findCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODEND);
		return result;

	}
	
	public List findAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException {

		logger.info("findAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODBEGIN);
		logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName+ "benFileType :" +benFileType);
		
		List result = new ArrayList();
		if(corporateId != null &&  uploaderName != null && userName != null && benFileType != null) {
		try {
			if("3P".equals(benFileType)){
			Object[] parameters = new Object[] {userName,corporateId,uploaderName,corporateId,uploaderName};
			result = getJdbcTemplate().query(SELECT_CB_ADMINSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper());       
			}else if("ABTP".equals(benFileType)){
			Object[] parameters = new Object[] {userName,corporateId,uploaderName,corporateId,uploaderName};
			result = getJdbcTemplate().query(SELECT_AADHAR_ADMINSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper());   	
			}
			if (result.size() > 0) 
			{
				logger.info("Result size in side if loop :"+result.size());
			}
		} catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		} 
		} else {
			DAOException.throwException("F001");
		}
		
		logger.info("findAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODEND);
		return result;

	}
	
	public List findRegSftpBenFiles(String corporateId,String userName,String uploaderName) throws DAOException {

		logger.info("findRegSftpBenFiles(String corporateId,String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
		logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName);
		
		List result = new ArrayList();

		try {
			Object[] parameters = new Object[] {corporateId,uploaderName,corporateId,uploaderName};
			result = getJdbcTemplate().query(SELECT_CB_REGSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper());       
							
			if (result.size() > 0) 
			{
				logger.info("Result size in side if loop :"+result.size());
			}
		} catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		
		logger.info("findRegSftpBenFiles(String corporateId,String userName,String uploaderName)"+ LoggingConstants.METHODEND);
		return result;

	}
	
	public int findBenRecCount(String fileName,String userName,String corporateId,String fileType) throws DAOException {
		logger.info("findBenRecCount(String fileName,String userName,String corporateId,String fileType) method begins");
		int  benRecCount = 0;
		try{
			if(corporateId != null && fileName != null && userName != null && fileType != null) {
				if("3P".equals(fileType))
				{
					Object[] params={userName,fileName,corporateId};
					logger.info("userName :" + userName +"fileName :" + fileName +"corporateId :"+corporateId);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_3P_REC_COUNT,params);
					logger.info("Count value for 3P file"+fileName+"is"+benRecCount);
				}
				else if("IBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName};
					logger.info("fileName :" + fileName +"userName :" + userName);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_IBTP_REC_COUNT,params);
					logger.info("Count value for IBTP file"+fileName+"is"+benRecCount);
				}
				else if("D3P".equals(fileType)){
					fileName = "%"+fileName+"%";
					Object[]	params = new Object[] {fileName};
					logger.info("fileName :" + fileName);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_D3P_REC_COUNT,params);
					logger.info("Count value for D3P file"+fileName+"is"+benRecCount);
				}
				else if("DIBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName,corporateId };
					logger.info("fileName :" + fileName +"userName :" + userName+"corporateId" + corporateId);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_DIBTP_REC_COUNT,params);
					logger.info("Count value for DIBTP file"+fileName+"is"+benRecCount);
				}
			}
		    else
		    {
		    	DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findBenRecCount(String fileName,String userName,String corporateId,String fileType) method ends");
		return benRecCount;
   }
	
   public Map findCompBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) throws DAOException {
		logger.info("findCompBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) method begins");
		
		int sameBankAddRecCount = 0;
		int sameBankDeleteRecCount = 0;
		int otherBankAddRecCount = 0;
		int otherBankDeleteRecCount = 0;
		int validationFailureCount = 0;
		Map countMap = new HashMap();
		
		try{
			logger.info("fileName :" + fileName+"userName :" + userName +"corporateId :" + corporateId+"uploaderName :" + uploaderName);
			
			if(corporateId != null && fileName != null && userName != null && fileType != null) {
				if(fileType.equals("COMPOSITE_BEN") || fileType.equals("validationFailure"))
				{
				Object[] sameBankAddParams={fileName,corporateId,uploaderName};
				sameBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_3P_REC_COUNT,sameBankAddParams);
				logger.info("Count value for sameBankAddRecCount file "+fileName+" is "+sameBankAddRecCount);
			
				Object[] otherBankAddParams = new Object[] {fileName,corporateId,uploaderName};
				otherBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_IBTP_REC_COUNT,otherBankAddParams);
				logger.info("Count value for otherBankAddRecCount file "+fileName+" is "+otherBankAddRecCount);
			 
				Object[] sameBankDeleteParams = new Object[] {fileName,corporateId,uploaderName};
				sameBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_D3P_REC_COUNT,sameBankDeleteParams);
				logger.info("Count value for sameBankDeleteRecCount file "+fileName+" is "+sameBankDeleteRecCount);

				Object[] otherBankDeleteParams = new Object[] {fileName,corporateId};
				otherBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_DIBTP_REC_COUNT,otherBankDeleteParams);
				logger.info("Count value for otherBankDeleteRecCount file "+fileName+" is "+otherBankDeleteRecCount);
				
				Object[]  validationFailureParams = new Object[] {fileName,corporateId,uploaderName};
				validationFailureCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VALIDATION_FAILURE_COUNT,validationFailureParams);
				logger.info("Count value for validationFailureCount file "+fileName+" is "+validationFailureCount);
				}
				else if (fileType.equals("ABTP") || fileType.equals("validationFailure_aadhar"))
				{
				Object[] sameBankAddParams={fileName,corporateId,uploaderName};
				sameBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_3P_REC_COUNT,sameBankAddParams);
				logger.info("Count value for sameBankAddRecCount file "+fileName+" is "+sameBankAddRecCount);
						
				Object[] sameBankDeleteParams = new Object[] {fileName,corporateId,uploaderName};
				sameBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_D3P_REC_COUNT,sameBankDeleteParams);
				logger.info("Count value for sameBankDeleteRecCount file "+fileName+" is "+sameBankDeleteRecCount);
							
				Object[]  validationFailureParams = new Object[] {fileName,corporateId,uploaderName};
				validationFailureCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_VALIDATION_FAILURE_COUNT,validationFailureParams);
				logger.info("Count value for validationFailureCount file "+fileName+" is "+validationFailureCount);	
    			}
				
				countMap.put("sameBankAddRecCount",sameBankAddRecCount) ;  
				countMap.put("sameBankDeleteRecCount",sameBankDeleteRecCount) ; 
				countMap.put("otherBankAddRecCount",otherBankAddRecCount) ; 
				countMap.put("otherBankDeleteRecCount",otherBankDeleteRecCount) ; 
				countMap.put("validationFailureCount",validationFailureCount) ;
				
				logger.info("countMap :" + countMap);
			}
		    else
		    {
		    	DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		
		logger.info("findCompBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) method ends");
		return countMap;
   }
    public CompBenDataModel[] findBenRecDisplay(String fileName,String userName,String corporateId,String fileType) throws DAOException {
		logger.info("findBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODBEGIN);
		
		logger.info("fileName :" + fileName + "userName :" + userName +"corporateId :" + corporateId + "filetype:"+fileType);
		List recResult = null;
		CompBenDataModel[] compBenDataModel = null;
		if (corporateId != null && fileName != null && userName != null && fileType != null) {
			try {
				if("3P".equals(fileType)) 
				{
					Object[] params = new Object[] { userName,fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("IBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_IBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("D3P".equals(fileType)){
					fileName = "%"+fileName+"%";
					Object[]	params = new Object[] {fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_D3P_REC_DISPLAY, params,new CompBenD3PDataModelRowMapper());
				}
				else if("DIBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_DIBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				if(recResult!=null && recResult.size()>0) {
					compBenDataModel = new CompBenDataModel[recResult.size()];
					for (int i = 0; i < recResult.size(); i++) {
						compBenDataModel[i] = (CompBenDataModel) recResult.get(i);
					}
				}
				logger.info("findBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODEND);
				return compBenDataModel;
    		} catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		logger.info("findBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"
				+ LoggingConstants.METHODEND);
		return null;
	}
    
    public CompBenDataModel[] findCompBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName) throws DAOException {
		logger.info("findCompBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"+ LoggingConstants.METHODBEGIN);
		
		logger.info("fileName :" + fileName + "userName :" + userName + "corporateId :" + corporateId +"specificFileType:"+specificFileType+ "uploaderName :" + uploaderName);
		List recResult = null;
		CompBenDataModel[] compBenDataModel = null;
		if (corporateId != null && fileName != null && userName != null && specificFileType != null) {
			try {
				if("3P".equals(specificFileType)) 
				{
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("IBTP".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_IBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("D3P".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_D3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("DIBTP".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_DIBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("validationFailure".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VALIDATION_FAILURE_REC_DISPLAY, params,new CompBenFileMasterRowMapper());
				}
				else if("AB3P".equals(specificFileType)) 
				{
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_AADHAR_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("ABD3P".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_AADHAR_D3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("validationFailure_aadhar".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_AADHAR_VALIDATION_FAILURE_REC_DISPLAY, params,new CompBenFileMasterRowMapper());
				} 
				if(recResult!=null && recResult.size()>0) {
					compBenDataModel = new CompBenDataModel[recResult.size()];
					for (int i = 0; i < recResult.size(); i++) {
						compBenDataModel[i] = (CompBenDataModel) recResult.get(i);
					}
				}
				logger.info("findCompBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"+ LoggingConstants.METHODEND);
				return compBenDataModel;
    		} catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		logger.info("findCompBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"
				+ LoggingConstants.METHODEND);
		return null;
	}
    
    public int updateBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId) throws DAOException{
    	logger.info("updateBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODBEGIN);
    	int approvedCount = 0;
    	
    	String benQuery = null;
    	logger.info("userName :" + userName + "fileType :" + fileType +"corporateId:"+corporateId);
    	
    	if(approveOid != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_3P_APPROVED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_IBTP_APPROVED;
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_D3P_APPROVED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_DIBTP_APPROVED;
    			}
    			for (int i = 0; i < approveOid.size(); i++) {
    				Long approverdIds = new Long((String) approveOid.get(i));
    				Object[] approveParams = new Object[] {userName,approverdIds,corporateId };
    				logger.info("id :" + approverdIds);
    				approvedCount += getJdbcTemplate().update(benQuery,approveParams);
    			}
    		logger.info("Total Beneficiary Records approved is "+ approvedCount +"for file type" +fileType);
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODEND);
       	return approvedCount;
    }
    
    public int updateBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName) throws DAOException{
    	logger.info("updateBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODBEGIN);
    	int rejectedCount = 0;
    	
    	String benQuery = null;
    	logger.info("userName :" + userName + "fileType :" + fileType + "corporateId:"+corporateId + "fileName:" + fileName);

    	if(rejectOid != null && userName != null && fileType != null && corporateId != null && fileName != null){
    		try{
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_3P_REJECTED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_IBTP_REJECTED;
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_D3P_REJECTED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_DIBTP_REJECTED;
    			}
    			for (int i = 0; i < rejectOid.size(); i++) {
    				Long rejectedIds = new Long((String) rejectOid.get(i));
    				Object[] approveParams = null;
    				if("3P".equals(fileType) || "IBTP".equals(fileType)){ 
    				approveParams = new Object[] {userName,rejectedIds,corporateId };
    				}else if("D3P".equals(fileType) || "DIBTP".equals(fileType)){
    				approveParams = new Object[] {rejectedIds,corporateId };
    				}
    				logger.info("id :" + rejectedIds);
    				rejectedCount += getJdbcTemplate().update(benQuery,approveParams);
    				if (rejectedCount <= 0) {
    					DAOException.throwException("BEN009");
    				} else {
    					try {
    	                 Object params[] = { "COMPB001", this.getClass().getName(), "updateBenStatusRejectConfirm", userName, fileName,fileType, corporateId,rejectedIds, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}; 
    	                 int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
    						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY, params, sqlTypes);
    						logger.info("Inserted count in audit"+count);
    					} catch (Exception e) {
    						logger.error("Failed to insert in wac_audit_trail for userName : " +userName +" and fileName :"+ fileName);
    					}

    				}
    				
    			}
    		logger.info("Total Beneficiary Records rejected  is "+ rejectedCount +"for file type" +fileType);
    		
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODEND);
       	return rejectedCount;
    }
    
    public int updateCompBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName) throws DAOException{
    	logger.info("updateCompBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODBEGIN);
    	int rejectedCount = 0;
    	
    	String benQuery = null;
    	logger.info("userName :" + userName + "fileType :" + fileType + "corporateId:"+corporateId + "fileName:" + fileName);

    	if(rejectOid != null && userName != null && fileType != null && corporateId != null && fileName != null){
    		try{
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_3P_REJECTED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_IBTP_REJECTED;
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_COMPBEN_D3P_REJECTED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_DIBTP_REJECTED;
    			}else if("AB3P".equals(fileType)){
    				benQuery = 	UPDATE_AADHARBEN_3P_REJECTED;			
    			}else if("ABD3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_AADHARBEN_D3P_REJECTED;
    			}
    			for (int i = 0; i < rejectOid.size(); i++) {
    				Long rejectedIds = new Long((String) rejectOid.get(i));
    				Object[] approveParams = null;
    				if("3P".equals(fileType) || "IBTP".equals(fileType) || "AB3P".equals(fileType)){ 
    				approveParams = new Object[] {userName,rejectedIds,corporateId };
    				}else if("D3P".equals(fileType) || "DIBTP".equals(fileType) || "ABD3P".equals(fileType)){
    				approveParams = new Object[] {rejectedIds,corporateId };
    				}
    				logger.info("id :" + rejectedIds);
    				rejectedCount += getJdbcTemplate().update(benQuery,approveParams);
    				if (rejectedCount <= 0) {
    					DAOException.throwException("BEN009");
    				} else {
    					try {
    	                 Object params[] = { "COMPB001", this.getClass().getName(), "updateCompBenStatusRejectConfirm", userName, fileName,fileType, corporateId,rejectedIds, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}; 
    	                 int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
    								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
    								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
    						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY, params, sqlTypes);
    						logger.info("Inserted count in audit"+count);
    					} catch (Exception e) {
    						logger.error("Failed to insert in wac_audit_trail for userName : " +userName +" and fileName :"+ fileName);
    					}

    				}
    				
    			}
    		logger.info("Total Beneficiary Records rejected  is "+ rejectedCount +"for file type" +fileType);
    		
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateCompBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODEND);
       	return rejectedCount;
    }
    
    public int updateCompBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException {
		logger.info("updateCompBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODBEGIN);
    	int rejectedCount = 0;
    	String benQuery = null;
    	logger.info("fileType :"+fileType);
    	if(fileName != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			Object[] approveParams = null;
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_FILE_3P_REJECTED;	
    			    approveParams = new Object[] {userName,fileName,corporateId };
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_IBTP_REJECTED;
    			    approveParams = new Object[] {userName,fileName,corporateId };
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_COMPBEN_FILE_D3P_REJECTED;
    			    approveParams = new Object[] {fileName,corporateId };
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_DIBTP_REJECTED;
    			    approveParams = new Object[] {fileName,corporateId };
    			}else  if("AB3P".equals(fileType)){
    				benQuery = 	UPDATE_AADHARBEN_FILE_3P_REJECTED;	
    			    approveParams = new Object[] {userName,fileName,corporateId };
    			}else if("ABD3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_AADHARBEN_FILE_D3P_REJECTED;
    			    approveParams = new Object[] {fileName,corporateId };
    			}
    			
				
				logger.info("userName :"+userName+"fileName :"+fileName+"corporateId :"+corporateId);
				rejectedCount = getJdbcTemplate().update(benQuery,approveParams);
				
				logger.info("Total Beneficiary Records rejected is "+ rejectedCount +"for file type" +fileType);
				
				if (rejectedCount <= 0) {
					DAOException.throwException("BEN009");
				} else {
					try {
	                 Object      params[] = { "COMPB001", this.getClass().getName(), "updateCompBenStatusRejectConfirm", userName, fileName,fileType, corporateId, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}; 
	                 int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY, params, sqlTypes);
						logger.info("Inserted count in audit"+count);
					} catch (Exception e) {
						logger.error("Failed to insert in wac_audit_trail for userName : " +userName +" and fileName :"+ fileName);
					}

				}
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateCompBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODEND);
       	return rejectedCount;
	}
	

	public class CompBen3PDataModelRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CompBenDataModel
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CompBenDataModel compBenDataModel = new CompBenDataModel();
			compBenDataModel.setOid(rs.getLong(DAOConstants.OID));
			compBenDataModel.setCorporateID(rs.getString(DAOConstants.CORPORATE_ID));
			compBenDataModel.setStatus(new Integer(rs.getInt(DAOConstants.STATUS)));
			compBenDataModel.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
			compBenDataModel.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
			compBenDataModel.setName(rs.getString(DAOConstants.NAME_THIRD_PARTY));
			compBenDataModel.setOutRef1(rs.getString(DAOConstants.OUT_REF1));
			compBenDataModel.setOutRef2(rs.getString(DAOConstants.OUT_REF2));
			compBenDataModel.setOutRef3(rs.getString(DAOConstants.OUT_REF3));
			compBenDataModel.setOutRef4(rs.getString(DAOConstants.OUT_REF4));
			compBenDataModel.setOutRef5(rs.getString(DAOConstants.OUT_REF5));
			compBenDataModel.setOutRef6(rs.getString(DAOConstants.OUT_REF6));
			compBenDataModel.setOutRef7(rs.getString(DAOConstants.OUT_REF7));
			compBenDataModel.setMobileNo(rs.getString(DAOConstants.MOBILE_NO));
            compBenDataModel.setEmailId(rs.getString("EMAIL_ID"));
            compBenDataModel.setAadharId(rs.getString("AADHAR_ID"));
            compBenDataModel.setBankIIN(rs.getString("BANK_IIN"));
			return compBenDataModel;
		}
	}
	
	public class CompBenD3PViewDataModelRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CompBenDataModel
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CompBenDataModel compBenDataModel = new CompBenDataModel();
			compBenDataModel.setOid(rs.getLong(DAOConstants.OID));
			compBenDataModel.setCorporateID(rs.getString(DAOConstants.CORPORATE_ID));
			compBenDataModel.setStatus(new Integer(rs.getInt("STATUS_D3P")));
			compBenDataModel.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
			compBenDataModel.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
			compBenDataModel.setName(rs.getString(DAOConstants.NAME_THIRD_PARTY));
			compBenDataModel.setOutRef1(rs.getString(DAOConstants.OUT_REF1));
			compBenDataModel.setOutRef2(rs.getString(DAOConstants.OUT_REF2));
			compBenDataModel.setOutRef3(rs.getString(DAOConstants.OUT_REF3));
			compBenDataModel.setOutRef4(rs.getString(DAOConstants.OUT_REF4));
			compBenDataModel.setOutRef5(rs.getString(DAOConstants.OUT_REF5));
			compBenDataModel.setOutRef6(rs.getString(DAOConstants.OUT_REF6));
			compBenDataModel.setOutRef7(rs.getString(DAOConstants.OUT_REF7));
			compBenDataModel.setMobileNo(rs.getString(DAOConstants.MOBILE_NO));
            compBenDataModel.setEmailId(rs.getString("EMAIL_ID"));
            compBenDataModel.setAadharId(rs.getString("AADHAR_ID"));
            compBenDataModel.setBankIIN(rs.getString("BANK_IIN"));
			return compBenDataModel;
		}
	}
	
	public class CompBenIBTPDataModelRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CompBenDataModel
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CompBenDataModel compBenDataModel = new CompBenDataModel();
            compBenDataModel.setOid(rs.getLong("ID"));
            compBenDataModel.setCorporateID(rs.getString("CORPORATE_ID"));
            compBenDataModel.setStatus(new Integer(rs.getInt("STATUS_RTGS")));
            compBenDataModel.setAccountNo(rs.getString("ACCOUNT_NUMBER"));
            compBenDataModel.setBranchCode(rs.getString("SENDER_BRANCH_CODE"));
            compBenDataModel.setName(rs.getString("THIRD_PARTY_NAME"));
            compBenDataModel.setOutRef1(rs.getString("BANK_RECEIVER"));
            compBenDataModel.setOutRef2(rs.getString("IFSC_CODE_RECEIVER"));
            compBenDataModel.setOutRef7(rs.getString("EMP_CODE"));
            compBenDataModel.setDeletionApprovedBy(rs.getString("DELETION_APPROVED_BY"));
            compBenDataModel.setDeletionFileNo(rs.getString("DELETION_FILE_NO"));
            compBenDataModel.setTpFileStatus(rs.getString("STATUS"));
            compBenDataModel.setAddress1(rs.getString("ADDRESS1"));
            compBenDataModel.setAddress2(rs.getString("ADDRESS2"));
            compBenDataModel.setAddress3(rs.getString("ADDRESS3"));
            compBenDataModel.setMobileNo(rs.getString("PHONE_NO"));
            compBenDataModel.setEmailId(rs.getString("EMAIL_ID"));
            compBenDataModel.setEmployeeCode(rs.getString("EMP_CODE"));
            return compBenDataModel;
        }
    }
	
	public class CompBenD3PDataModelRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CompBenDataModel compBenDataModel = new CompBenDataModel();
			compBenDataModel.setAccountNo(rs.getString("BENIFICIARY_ACCOUNT"));
			compBenDataModel.setStatus(new Integer(rs.getInt("STATUS_D3P")));
			compBenDataModel.setOutRef7(rs.getString("BENIFICIARY_CODE"));
			compBenDataModel.setName(rs.getString("BENIFICIARY_NAME"));
			compBenDataModel.setBranchCode(rs.getString("BENIFICIARY_BRANCH"));
			compBenDataModel.setOid(rs.getLong("ROW_ID"));
			return compBenDataModel;
		}
	}
	
	public class CompBenFileMasterRowMapper implements RowMapper
    {
       public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            CompBenDataModel compBenDataModel = new CompBenDataModel();
            compBenDataModel.setName(rs.getString("beneficiary_name"));
            compBenDataModel.setOutRef7(rs.getString("beneficiary_code"));
            compBenDataModel.setAccountNo(rs.getString("account_no"));
            compBenDataModel.setOutRef2(rs.getString("ifsc_code"));
            compBenDataModel.setOutRef1(rs.getString("validation_desc"));
            compBenDataModel.setAadharId(rs.getString("AADHAR_ID"));
            compBenDataModel.setBankIIN(rs.getString("BANK_IIN"));
            return compBenDataModel;
        }
    }
	
	
	
	
	public int updateBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException {
		logger.info("updateBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODBEGIN);
    	int rejectedCount = 0;
    	String benQuery = null;
    	logger.info("fileType :"+fileType);
    	if(fileName != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			Object[] approveParams = null;
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_FILE_3P_REJECTED;
    				approveParams = new Object[] {userName,fileName,corporateId };
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_IBTP_REJECTED;
    				approveParams = new Object[] {userName,fileName,corporateId };
    			}else if("D3P".equals(fileType))
    			{
    				fileName = "%"+fileName+"%";
    				benQuery = 	UPDATE_BEN_FILE_D3P_REJECTED;
    				approveParams = new Object[] {fileName,corporateId };
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_DIBTP_REJECTED;
    				approveParams = new Object[] {fileName,corporateId };
    			}
    			
				
				logger.info("userName :"+userName+"fileName :"+fileName+"corporateId :"+corporateId);
				rejectedCount = getJdbcTemplate().update(benQuery,approveParams);
				
				logger.info("Total Beneficiary Records rejected is "+ rejectedCount +"for file type" +fileType);
				
				if (rejectedCount <= 0) {
					DAOException.throwException("BEN009");
				} else {
					try {
	                 Object      params[] = { "COMPB001", this.getClass().getName(), "updateBenStatusRejectConfirm", userName, fileName,fileType, corporateId, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}; 
	                 int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, 
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
						int count = getJdbcTemplate().update(INSERT_AUDIT_QUERY, params, sqlTypes);
						logger.info("Inserted count in audit"+count);
					} catch (Exception e) {
						logger.error("Failed to insert in wac_audit_trail for userName : " +userName +" and fileName :"+ fileName);
					}

				}
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODEND);
       	return rejectedCount;
	}
	
	public int updateBenStatusConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException {
		logger.info("updateBenStatusConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODBEGIN);
    	int approvedCount = 0;
    	
    	String benQuery = null;
    	logger.info("fileType :"+fileType);
    	if(fileName != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_FILE_3P_APPROVED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_IBTP_APPROVED;
    			}else if("D3P".equals(fileType))
    			{
    				fileName = "%"+fileName+"%";
    				benQuery = 	UPDATE_BEN_FILE_D3P_APPROVED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_DIBTP_APPROVED;
    			}
    			
				Object[] approveParams = new Object[] {userName,fileName,corporateId };
				logger.info("userName :"+userName+"fileName :"+fileName+"corporateId :"+corporateId);
				
				approvedCount = getJdbcTemplate().update(benQuery,approveParams);
				
				
				logger.info("Total Beneficiary Records approved is "+ approvedCount +"for file type" +fileType);
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateBenStatusConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODEND);
       	return approvedCount;
	}
	public int updateCompBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId,String fileName) throws DAOException{
    	logger.info("updateCompBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODBEGIN);
    	int approvedCount = 0;
    	
    	String benQuery = null;
    	logger.info("userName :" + userName + "fileType :" + fileType +"corporateId:"+corporateId+"fileName:"+fileName);
    	
    	if(approveOid != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_3P_APPROVED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_IBTP_APPROVED;
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_COMPBEN_D3P_APPROVED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_DIBTP_APPROVED;
    			}else if("AB3P".equals(fileType)){
    				benQuery = 	UPDATE_AADHARBEN_3P_APPROVED;			
    			}else if("ABD3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_AADHARBEN_D3P_APPROVED;
    			}
    			Object[] approveParams = null;
    			for (int i = 0; i < approveOid.size(); i++) {
    				Long approverdIds = new Long((String) approveOid.get(i));
    				
					approveParams = new Object[] {userName,approverdIds,corporateId };
        			
    				logger.info("id :" + approverdIds);
    				approvedCount += getJdbcTemplate().update(benQuery,approveParams);
    			}
    		logger.info("Total Beneficiary Records approved is "+ approvedCount +"for file type" +fileType);
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateCompBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId,String fileName)"
				+ LoggingConstants.METHODEND);
       	return approvedCount;
    }
	public int updateCompBenStatusConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException {
		logger.info("updateCompBenStatusConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODBEGIN);
    	int approvedCount = 0;
    	
    	String benQuery = null;
    	logger.info("fileType :"+fileType);
    	if(fileName != null && userName != null && fileType != null && corporateId != null ){
    		try{
    			
    			int index = fileName.indexOf('.');
    			fileName = fileName.substring(0, index);
    			
    			if("3P".equals(fileType)){
    				benQuery = 	UPDATE_BEN_FILE_3P_APPROVED;			
    			}else if("IBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_IBTP_APPROVED;
    			}else if("D3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_COMPBEN_FILE_D3P_APPROVED;
    			}else if("DIBTP".equals(fileType))
    			{
    				benQuery = 	UPDATE_BEN_FILE_DIBTP_APPROVED;
    			}else if("AB3P".equals(fileType)){
    				benQuery = 	UPDATE_AADHARBEN_FILE_3P_APPROVED;			
    			}else if("ABD3P".equals(fileType))
    			{
    				benQuery = 	UPDATE_AADHARBEN_FILE_D3P_APPROVED;
    			}
    			
				Object[] approveParams = new Object[] {userName,fileName,corporateId };
    			logger.info("userName :"+userName+"fileName :"+fileName+"corporateId :"+corporateId);
				
				approvedCount = getJdbcTemplate().update(benQuery,approveParams);
				
				logger.info("Total Beneficiary Records approved is "+ approvedCount +"for file type" +fileType);
    			
    		}catch(DataAccessException exception)
                {
                    DAOException.throwException("F001", exception);
                }
       	}else
    	{
       		DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
    	}
    	logger.info("updateCompBenStatusConfirm(String fileName,String userName,String fileType,String corporateId)"
				+ LoggingConstants.METHODEND);
       	return approvedCount;
	}
	
	 public List viewTPFiles(String userName,String uploaderName) throws DAOException {

			logger.info("viewTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
			
			List result = new ArrayList();

			try {
				Object[] parameters = new Object[] {userName,uploaderName};
				logger.info("userName :" + userName +"uploaderName :"+uploaderName);
				result = getJdbcTemplate().query(SELECT_CB_VIEW_3P_PENDING_FILES,parameters, new CorporateFileRowMapper());       
								
				if (result.size() > 0) 
				{
					logger.info("Result size in side if loop :"+result.size());
				}
			} catch (DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
			logger.info("viewTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODEND);
			return result;

		}
	 
	 public List viewTPInterFiles(String userName, String uploaderName) throws DAOException
	    {

	       logger.info("viewTPInterFiles(String userName, String uploaderName)"+ LoggingConstants.METHODBEGIN);
	       logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
	       List result = new ArrayList();
	       CorporateFile[] corporateFileArray = null;
	       
	       try
		   {
	    	   Object[] parameters = new Object[] { uploaderName,userName};
	    	   result = getJdbcTemplate().query(SELECT_CB_VIEW_IBTP_PENDING_FILES, parameters,new CorporateFileInterRowMapper());
		
			   if (result != null && result.size() > 0)
	           {
	               logger.info("Result size in side if loop:" + result.size());
	           }
		   }
	       catch (DataAccessException ex)
	       {
	           DAOException.throwException("F001", ex);
	       }
	       logger.info("viewTPInterFiles(String userName, String uploaderName)"+ LoggingConstants.METHODEND);
	       return result;

	    }
	 
	 public List viewTPDelFiles(String userName, String uploaderName) throws DAOException {
	        
	        logger.info("viewTPDelFiles(String userName, String uploaderName)" + LoggingConstants.METHODBEGIN);
	        logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
	       
	        List result = new ArrayList();

	        try {
	      
	            Object[] parameters = new Object[] {uploaderName,userName};
	            result = getJdbcTemplate().query(SELECT_CB_VIEW_D3P_PENDING_FILES,parameters, new CorporateFileRowMapper());
	           
	            logger.info("Result ::"+result);
	            
	            if (result.size() > 0 &&  result != null) {
	                logger.info("Result size in side if :"+result.size());
	            }
	            
	            
	        } catch (DataAccessException ex) {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
	        logger.info("viewTPDelFiles(String userName, String uploaderName)"+ LoggingConstants.METHODEND);
	        return result;

	    }
	 
	 public List viewDIBTPFiles(String userName,String uploaderName) throws DAOException
	    {

	        logger.info("viewDIBTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
	        logger.info("userName  :" + userName +"uploaderName :"+uploaderName);
	        
	        List result = new ArrayList();
	        CorporateFile[] corporateFileArray = null;

	        try
	        {
	        	Object[] parameters = new Object[] {uploaderName,userName}; 
	            result = getJdbcTemplate().query(SELECT_CB_VIEW_DIBTP_PENDING_FILES, parameters,new CorporateFileRowMapper());
	           
	            if (result != null && result.size() > 0)
	            {
	                logger.info("Result size in side if loop:" + result.size());
	            }
	        }
	        catch (DataAccessException ex)
	        {
	            DAOException.throwException("F001", ex);
	        }
	        
	        logger.info("viewDIBTPFiles(String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
	        return result;

	    }
		public List viewCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException {

			logger.info("viewCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODBEGIN);
			logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName +"benFileType :" +benFileType);
			
			List result = new ArrayList();
			if(corporateId != null &&  uploaderName != null && userName != null && benFileType != null) {
			try {
				if("3P".equals(benFileType)){
				Object[] parameters = new Object[] {corporateId,userName,uploaderName,corporateId,uploaderName};
				result = getJdbcTemplate().query(SELECT_CB_VIEW_COMPBEN_PENDING_FILES,parameters, new CorporateFileRowMapper());     
				}else if("ABTP".equals(benFileType)){
				Object[] parameters = new Object[] {corporateId,userName,uploaderName,corporateId,uploaderName};
				result = getJdbcTemplate().query(SELECT_AADHAR_VIEW_COMPBEN_PENDING_FILES,parameters, new CorporateFileRowMapper());     	
				}
								
				if (result.size() > 0) 
				{
					logger.info("Result size in side if loop :"+result.size());
				}
			} catch (DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
			}
			else {
				DAOException.throwException("F001");
			}
			
			logger.info("viewCompBenFiles(String userName,String uploaderName)"+ LoggingConstants.METHODEND);
			return result;

		}
		
		public List viewAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException {

			logger.info("viewAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType)"+ LoggingConstants.METHODBEGIN);
			logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName + "benFileType :" +benFileType);
			
			List result = new ArrayList();
			if(corporateId != null &&  uploaderName != null && userName != null && benFileType != null) {
			try {
				if("3P".equals(benFileType)){
				Object[] parameters = new Object[] {userName,corporateId,uploaderName,corporateId,uploaderName};
				result = getJdbcTemplate().query(SELECT_CB_VIEW_ADMINSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper());       
				} else if("ABTP".equals(benFileType)){
				Object[] parameters = new Object[] {userName,corporateId,uploaderName,corporateId,uploaderName};
				result = getJdbcTemplate().query(SELECT_AADHAR_VIEW_ADMINSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper()); 	
				}
				if (result.size() > 0) 
				{
					logger.info("Result size in side if loop :"+result.size());
				}
			} catch (DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
			} else {
				DAOException.throwException("F001");
			}
			logger.info("viewAdminSftpBenFiles(String corporateId,String userName,String uploaderName)"+ LoggingConstants.METHODEND);
			return result;

		}
		
		public List viewRegSftpBenFiles(String corporateId,String userName,String uploaderName) throws DAOException {

			logger.info("viewRegSftpBenFiles(String corporateId,String userName,String uploaderName)"+ LoggingConstants.METHODBEGIN);
			logger.info("corporateId :" + corporateId +"userName :" + userName +"uploaderName :"+uploaderName);
			
			List result = new ArrayList();

			try {
				Object[] parameters = new Object[] {corporateId,uploaderName,corporateId,uploaderName};
				result = getJdbcTemplate().query(SELECT_CB_VIEW_REGSFTP_PENDING_FILES,parameters, new CorporateFileRowMapper());       
								
				if (result.size() > 0) 
				{
					logger.info("Result size in side if loop :"+result.size());
				}
			} catch (DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
			
			logger.info("viewRegSftpBenFiles(String corporateId,String userName,String uploaderName)"+ LoggingConstants.METHODEND);
			return result;

		}
	
	public Map findCompViewBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) throws DAOException {
		logger.info("findCompViewBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) method begins");
		
		int sameBankAddRecCount = 0;
		int sameBankDeleteRecCount = 0;
		int otherBankAddRecCount = 0;
		int otherBankDeleteRecCount = 0;
		int validationFailureCount = 0;
		Map countMap = new HashMap();
		
		try{
			logger.info("fileName :" + fileName+"userName :" + userName +"corporateId :" + corporateId+"uploaderName :" + uploaderName);
			
			if(corporateId != null && fileName != null && userName != null && fileType != null) {
				if(fileType.equals("COMPOSITE_BEN") || fileType.equals("validationFailure"))
				{
				Object[] sameBankAddParams={fileName,corporateId,uploaderName};
				sameBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VIEW_3P_REC_COUNT,sameBankAddParams);
				logger.info("Count value for sameBankAddRecCount file "+fileName+" is "+sameBankAddRecCount);
			
				Object[] otherBankAddParams = new Object[] {fileName,corporateId,uploaderName};
				otherBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VIEW_IBTP_REC_COUNT,otherBankAddParams);
				logger.info("Count value for otherBankAddRecCount file "+fileName+" is "+otherBankAddRecCount);
			 
				Object[] sameBankDeleteParams = new Object[] {fileName,corporateId,uploaderName};
				sameBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VIEW_D3P_REC_COUNT,sameBankDeleteParams);
				logger.info("Count value for sameBankDeleteRecCount file "+fileName+" is "+sameBankDeleteRecCount);

				Object[] otherBankDeleteParams = new Object[] {fileName,corporateId};
				otherBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VIEW_DIBTP_REC_COUNT,otherBankDeleteParams);
				logger.info("Count value for otherBankDeleteRecCount file "+fileName+" is "+otherBankDeleteRecCount);
				
				Object[]  validationFailureParams = new Object[] {fileName,corporateId,uploaderName};
				validationFailureCount = getJdbcTemplate().queryForInt(SELECT_COMPBEN_VALIDATION_FAILURE_COUNT,validationFailureParams);
				logger.info("Count value for validationFailureCount file "+fileName+" is "+validationFailureCount);
				} 
				else if(fileType.equals("ABTP") || fileType.equals("validationFailure_aadhar")) 
				{
				Object[] sameBankAddParams={fileName,corporateId,uploaderName};
				sameBankAddRecCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_VIEW_3P_REC_COUNT,sameBankAddParams);
				logger.info("Count value for sameBankAddRecCount file "+fileName+" is "+sameBankAddRecCount);
				
				Object[] sameBankDeleteParams = new Object[] {fileName,corporateId,uploaderName};
				sameBankDeleteRecCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_VIEW_D3P_REC_COUNT,sameBankDeleteParams);
				logger.info("Count value for sameBankDeleteRecCount file "+fileName+" is "+sameBankDeleteRecCount);
				
				Object[]  validationFailureParams = new Object[] {fileName,corporateId,uploaderName};
				validationFailureCount = getJdbcTemplate().queryForInt(SELECT_AADHAR_VALIDATION_FAILURE_COUNT,validationFailureParams);
				logger.info("Count value for validationFailureCount file "+fileName+" is "+validationFailureCount);
					
				}
				
				
				countMap.put("sameBankAddRecCount",sameBankAddRecCount) ;  
				countMap.put("sameBankDeleteRecCount",sameBankDeleteRecCount) ; 
				countMap.put("otherBankAddRecCount",otherBankAddRecCount) ; 
				countMap.put("otherBankDeleteRecCount",otherBankDeleteRecCount) ; 
				countMap.put("validationFailureCount",validationFailureCount) ;
				
				logger.info("countMap :" + countMap);
			}
		    else
		    {
		    	DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		
		logger.info("findCompViewBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) method ends");
		return countMap;
   }
	public int findViewBenRecCount(String fileName,String userName,String corporateId,String fileType) throws DAOException {
		logger.info("findViewBenRecCount(String fileName,String userName,String corporateId,String fileType) method begins");
		int  benRecCount = 0;
		try{
			if(corporateId != null && fileName != null && userName != null && fileType != null) {
				if("3P".equals(fileType))
				{
					Object[] params={userName,fileName,corporateId};
					logger.info("userName :" + userName +"fileName :" + fileName +"corporateId :"+corporateId);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_VIEW_3P_REC_COUNT,params);
					logger.info("Count value for 3P file"+fileName+"is"+benRecCount);
				}
				else if("IBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName};
					logger.info("fileName :" + fileName +"userName :" + userName);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_VIEW_IBTP_REC_COUNT,params);
					logger.info("Count value for IBTP file"+fileName+"is"+benRecCount);
				}
				else if("D3P".equals(fileType)){
					fileName = "%"+fileName+"%";
					Object[]	params = new Object[] {fileName};
					logger.info("fileName :" + fileName);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_VIEW_D3P_REC_COUNT,params);
					logger.info("Count value for D3P file"+fileName+"is"+benRecCount);
				}
				else if("DIBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName,corporateId};
					logger.info("fileName :" + fileName +"userName :" + userName);
					benRecCount = getJdbcTemplate().queryForInt(SELECT_BEN_VIEW_DIBTP_REC_COUNT,params);
					logger.info("Count value for DIBTP file"+fileName+"is"+benRecCount);
				}
			}
		    else
		    {
		    	DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findViewBenRecCount(String fileName,String userName,String corporateId,String fileType) method ends");
		return benRecCount;
   }
   
	public CompBenDataModel[] findViewBenRecDisplay(String fileName,String userName,String corporateId,String fileType) throws DAOException {
		logger.info("findViewBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODBEGIN);
		
		logger.info("fileName :" + fileName + "userName :" + userName +"corporateId :" + corporateId + "filetype:"+fileType);
		List recResult = null;
		CompBenDataModel[] compBenDataModel = null;
		if (corporateId != null && fileName != null && userName != null && fileType != null) {
			try {
				if("3P".equals(fileType)) 
				{
					Object[] params = new Object[] { userName,fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_VIEW_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("IBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_VIEW_IBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("D3P".equals(fileType)){
					fileName = "%"+fileName+"%";
					Object[]	params = new Object[] {fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_VIEW_D3P_REC_DISPLAY, params,new CompBenD3PDataModelRowMapper());
				}
				else if("DIBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_VIEW_DIBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				if(recResult!=null && recResult.size()>0) {
					compBenDataModel = new CompBenDataModel[recResult.size()];
					for (int i = 0; i < recResult.size(); i++) {
						compBenDataModel[i] = (CompBenDataModel) recResult.get(i);
					}
				}
				logger.info("findViewBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODEND);
				return compBenDataModel;
    		} catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		logger.info("findViewBenRecDisplay(String fileName,String userName,String corporateId,String fileType)"
				+ LoggingConstants.METHODEND);
		return null;
	}
    
    public CompBenDataModel[] findCompViewBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName) throws DAOException {
		logger.info("findCompViewBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"+ LoggingConstants.METHODBEGIN);
		
		logger.info("fileName :" + fileName + "userName :" + userName + "corporateId :" + corporateId +"specificFileType:"+specificFileType+ "uploaderName :" + uploaderName);
		List recResult = null;
		CompBenDataModel[] compBenDataModel = null;
		if (corporateId != null && fileName != null && userName != null && specificFileType != null) {
			try {
				if("3P".equals(specificFileType)) 
				{
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VIEW_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}
				else if("IBTP".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VIEW_IBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("D3P".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VIEW_D3P_REC_DISPLAY, params,new CompBenD3PViewDataModelRowMapper());
				}
				else if("DIBTP".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VIEW_DIBTP_REC_DISPLAY, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("validationFailure".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_COMPBEN_VALIDATION_FAILURE_REC_DISPLAY, params,new CompBenFileMasterRowMapper());
				}else if("AB3P".equals(specificFileType)) 
				{
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_AADHAR_VIEW_3P_REC_DISPLAY, params,new CompBen3PDataModelRowMapper());
				}else if("ABD3P".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};	
					recResult = getJdbcTemplate().query(SELECT_AADHAR_VIEW_D3P_REC_DISPLAY, params,new CompBenD3PViewDataModelRowMapper());
				}else if("validationFailure_aadhar".equals(specificFileType)){
					Object[] params = new Object[] {fileName,corporateId,uploaderName};
					recResult = getJdbcTemplate().query(SELECT_AADHAR_VALIDATION_FAILURE_REC_DISPLAY, params,new CompBenFileMasterRowMapper());
				}
				
				if(recResult!=null && recResult.size()>0) {
					compBenDataModel = new CompBenDataModel[recResult.size()];
					for (int i = 0; i < recResult.size(); i++) {
						compBenDataModel[i] = (CompBenDataModel) recResult.get(i);
					}
				}
				logger.info("findCompViewBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"+ LoggingConstants.METHODEND);
				return compBenDataModel;
    		} catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		logger.info("findCompViewBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName)"
				+ LoggingConstants.METHODEND);
		return null;
	}
    
    public CompBenDataModel[] downloadCompBenFiles(String fileName,String userName,String corporateId,String fileType) throws DAOException {
		logger.info("downloadCompBenFiles(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODBEGIN);
		
		logger.info("fileName :" + fileName + "userName :" + userName +"corporateId :" + corporateId + "filetype:"+fileType);
		List recResult = null;
		CompBenDataModel[] compBenDataModel = null;
		if (corporateId != null && fileName != null && userName != null && fileType != null) {
			try {
				if("3P".equals(fileType)) 
				{
					Object[] params = new Object[] { userName,fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_3P_REC_DISPLAY_DOWNLOAD, params,new CompBen3PDataModelRowMapper());
				}
				else if("IBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_IBTP_REC_DISPLAY_DOWNLOAD, params,new CompBenIBTPDataModelRowMapper());
				}
				else if("D3P".equals(fileType)){
					fileName = "%"+fileName+"%";
					Object[]	params = new Object[] {fileName};	
					recResult = getJdbcTemplate().query(SELECT_BEN_D3P_REC_DISPLAY_DOWNLOAD, params,new CompBenD3PDataModelRowMapper());
				}
				else if("DIBTP".equals(fileType)){
					Object[]	params = new Object[] { fileName,corporateId };
					recResult = getJdbcTemplate().query(SELECT_BEN_DIBTP_REC_DISPLAY_DOWNLOAD, params,new CompBenIBTPDataModelRowMapper());
				}else if("COMPOSITE_BEN".equals(fileType)){
					Object[]	params = new Object[] {fileName,corporateId,fileName,fileName,corporateId,fileName,corporateId,fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_COMPOSITE_BEN_REC_DISPLAY_DOWNLOAD, params,new DownloadCompBenDataModelRowMapper());
				}
                else if("ABTP".equals(fileType)){
					Object[]	params = new Object[] {fileName,corporateId,fileName,corporateId,fileName,corporateId};
					recResult = getJdbcTemplate().query(SELECT_BEN_AADHAR_BEN_REC_DISPLAY_DOWNLOAD, params,new DownloadAadharBenDataModelRowMapper());
				} 
				if(recResult!=null && recResult.size()>0) {
					compBenDataModel = new CompBenDataModel[recResult.size()];
					for (int i = 0; i < recResult.size(); i++) {
						compBenDataModel[i] = (CompBenDataModel) recResult.get(i);
					}
				}
				logger.info("downloadCompBenFiles(String fileName,String userName,String corporateId,String fileType)"+ LoggingConstants.METHODEND);
				return compBenDataModel;
    		} catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		logger.info("downloadCompBenFiles(String fileName,String userName,String corporateId,String fileType)"
				+ LoggingConstants.METHODEND);
		return null;
	}
    
    public class DownloadCompBenDataModelRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CompBenDataModel compBenDataModel = new CompBenDataModel();
			compBenDataModel.setAccountNo(rs.getString("ACCOUNT_NO"));
			compBenDataModel.setStatus(new Integer(rs.getInt("STATUS")));
			compBenDataModel.setOutRef7(rs.getString("EMP_CODE"));
			compBenDataModel.setName(rs.getString("name"));
			compBenDataModel.setOutRef2(rs.getString("IFS_CODE"));
			compBenDataModel.setOutRef1(rs.getString("error_desc"));
			compBenDataModel.setBankType(rs.getString("BANK_TYPE"));
			compBenDataModel.setActionType(rs.getString("ACTION_TYPE"));
			compBenDataModel.setValStatus(rs.getString("val_status"));
			return compBenDataModel;
		}
	}

public class DownloadAadharBenDataModelRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CompBenDataModel compBenDataModel = new CompBenDataModel();
			compBenDataModel.setAadharId(rs.getString("AADHAR_ID"));
			compBenDataModel.setStatus(new Integer(rs.getInt("STATUS")));
			compBenDataModel.setOutRef7(rs.getString("EMP_CODE"));
			compBenDataModel.setName(rs.getString("name"));
			compBenDataModel.setBankIIN(rs.getString("BANK_IIN"));
			compBenDataModel.setOutRef1(rs.getString("error_desc"));
			compBenDataModel.setBankType(rs.getString("BANK_TYPE"));
			compBenDataModel.setActionType(rs.getString("ACTION_TYPE"));
			compBenDataModel.setValStatus(rs.getString("val_status"));
			return compBenDataModel;
		}
	}
    
    
}

