package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.RegMobileNoDetails;

public interface RegisterMobileNoDAO {

	
	 public RegMobileNoDetails insertRegisterMobileNoDetails(Integer userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,int userRole,String cororateId,String userAlias,String friendlyName)throws  DAOException;
}
