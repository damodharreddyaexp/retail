/* 
 * AccountDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//Nov 24, 2005 NAVEEN - One Method added


package com.sbi.common.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;

import java.sql.Timestamp;
public interface AccountDAO
{ 

    /**
     * Call fetchAccounts(username) and return List of accounts
     * 
     * @param username
     * @return List [accounts]
     * @throws DAOException
     *             
     */
    List findAccounts(String username) throws DAOException;

    /**
     * Call fetchAccounts(username) and return List of accounts filtered by
     * accountType
     * 
     * @param username
     * @param type
     * @return List [accounts]
     * @throws DAOException
     *             
     */
    List findAccounts(String username, String accountType) throws DAOException;

    /**
     * -> fetchAccounts(username) return List of accounts if (core account) { ->
     * call -getCoreBalance(accounts) return Map -> update the account object
     * balance attribute. } -> return List [accounts]
     * 
     * @param username
     * @return List [accounts]
     * @throws DAOException
     *             
     */ 
    public List findAccountsWithBalance(String username,Boolean accountLimit) throws DAOException;

    /**
     * -> fetchAccounts(username) return List of accounts if (core account) { ->
     * call -getCoreBalance(accounts) return Map -> update the account object
     * filtered by accountType with balance attribute. } -> return List
     * [accounts]
     * 
     * @param username
     * @param accountType
     * @return List
     * @throws DAOException
     *             
     */
    List findAccountsWithBalance(String username, String accountType []) throws DAOException;

    /**
     * // Method to get PPFAccount or ThirdPartyAccount Execute query on
     * SBI_CUSTOMER_ACCOUNT_MAP table to fetch accounts matching the
     * accountNature Convert query output to accounts object List and return
     * List
     * 
     * @param userName
     * @param accountNature
     * @return List [accounts]
     * @throws DAOException
     *             
     */
    List findAccountsByNature(String userName, Integer accountNature) throws DAOException;

    /**
     * -> Call fetchAccounts(username) and return List of accounts return
     * account object filtered by branchCode and accountNo
     * 
     * @param accountNo
     * @param branchCode
     * @param userName
     * @return List [accounts]
     * @throws DAOException
     *            
     */ 
    Account findAccount(String accountNo, String branchCode, String userName) throws DAOException;
    
    /**  
     * -> Call fetchAccounts(username) and return List of accounts return
     * account object filtered by accessLevel 
     * 
     * @param userName
     * @param accountType
     * @return List [accounts]
     * @throws DAOException
     *            
     */
    List findTransactionAccount(String userName,String accountType);
    
    /**  
     * -> Call fetchAccounts(username) and return List of accounts return
     * account object filtered by accessLevel and accountType
     * 
     * @param userName
     * @param accountType
     * @param accessLevel
     * @return List [accounts]
     * @throws DAOException
     *            
     */
    /*Added by Kasi*/
    Map findAccounts(String username,  String corporateID, Integer accessLevel) throws DAOException;
    /*Added by Kasi*/
    
    
    //Added by Damodar for Account based MIS
    Map findUserAccountsForMIS(String username,  String corporateID, Integer accessLevel) throws DAOException;
    Map findAccountsForMIS(String username,  String corporateID, Integer accessLevel,Integer loginUserRole) throws DAOException;
    Map findAccountsApproverForMIS(String username,  String corporateID, Integer accessLevel,Integer loginUserRole) throws DAOException;
    //Added by Damodar for Account based MIS with ends

    List findAccounts(String username, String[] productType, Integer accessLevel) throws DAOException;
    
    //Access level check for corpuser for ipo
    List findAccounts(String username, String[] productType, Integer[] accessLevel) throws DAOException;
    // Auth Changes
    
    List findAccountsApprover(String username, String[] productType, Integer accessLevel) throws DAOException;

    List findLatestBalance(List accounts);
    /**
     * This method adds the account list provided as input in SBI_CUSTOMER_ACCOUNT_MAP. 
     * Values for the accounts to be added will be specified in the Account object.
     * @param Account userAccount
     * @return Account
     */
    Account insertAccount( Account userAccount );
    
    
    /**
     * This method deletes the record from SBI_CUSTOMER_ACCOUNT_MAP 
     * which matches the account number, username and account_nature combination provided in the Account object. 
     * @param userAccount
     * @return Account
     */
    Account deleteAccount( Account userAccount );
    
    
    
    /**
     * This methods updates the nickName of the account provided in the input in SBI_CUSTOMER_ACCOUNT_MAP table. 
     * @param userAccount
     * @return Account
     */
    public  List updateNickName( List userAccountList )throws DAOException;
    
    
    
    /**
     * This methods updates the Name_Third_Party and Transaction_Limit of the account provided in the input in SBI_CUSTOMER_ACCOUNT_MAP table. 
     * @param userAccount
     * @return Account
     */
   
    Account updateThirdParty( Account userAccount );
    
    
    /**
     * TODO Enter the description of the method here
     * @param productcode
     * @return
     * @throws DAOException String
     */
    public String getCreditable(String productcode) throws DAOException;
    
    /**
     * TODO Enter the description of the method here
     * @param account
     * @param actionFlag
     * @param oldValues
     * @return boolean
     */
    public boolean insertProfileAccountLog(Account account, String actionFlag, String oldValues);
    
    /**
     * TODO Enter the description of the method here
     * @param userName
     * @return
     * @throws DAOException List
     */
    public List findNonVerfiedAccounts(String userName) throws DAOException;
   
    /**
     * TODO Enter the description of the method here
     * @param userName
     * @return
     * @throws DAOException int
     */
    public int findAllAccountsCount(String userName) throws DAOException; 
    
    /**
     * TODO Get the maximum Transaction limit from Third Party Accounts for given userName
     * @param userName
     * @return Double value
     * @throws DAOException Double
     */ 
    public Double findMaximumTPAccountLimit(String userName) throws DAOException;
    
    /**
     * TODO Get the maximum findAccountByNature
     * @param userName
     * @return String accountNo
     * @return String branchCode
     * @return String username
     * @return Integer accountnature
     * @throws DAOException Double
     */
    public Account findAccountByNature(String userName, String accountNo, String branchCode, Integer accountnature) throws DAOException;
    
    public List getBMAccounts(String accountNo, String branchCode, Timestamp fromDate,String username) throws DAOException;//Added for CR 295
   
    public boolean upateCoreMessageStatus(String userName, String[] branchCode) throws DAOException;
    
    /**
     * TODO Update the ThirdParty Name only in SBI_CUSTOMER_ACCOUNT_MAP TABLE
     * @param userAccount Account
     * @return updated Account object
     * @throws DAOException 
     */
    public Account updateThirdPartyName(Account userAccount) throws DAOException;
    
    /**
     * Retrieves product description
     * @param productcode
     * @return
     */
    public String getProductDetails(String productcode);
    
//  Added for CR-2826
    public HashMap getCoreBalance(Account accounts) throws DAOException;
    //End CR-2826
    
    public boolean isValidRTGSCreditActNumber(String username,String corpId, String accountnumber, String ifscCode,String actNickName);//RTGS credit account number validation

    public List findAccountsWithoutBalance(String username, Boolean accountLimit) throws DAOException ;
    /**
     * Retrieves product code,product description product type and creditable
     * @param productCode
     * @param productCode2
     * @return
     */
    public Map getProductDesc(String productCode,String productCode2)throws DAOException;
	
    //CR-5390
    public List findTPAccounts(String userName) throws DAOException;
    
    public Account updateTPName(Account userAccount) throws DAOException;
    
    public Account deleteTPAccount( Account userAccount ) throws DAOException;
    //Added for CR 5507
    public List findAccountsWithBalance(String username) throws DAOException ;
    
    public  List findDepositAccountsWithBalance(String username, String productType[])throws DAOException;
    
    //Ends
  //added for CR 5679
    //IR71772 by Sulthan
    public List findAccountsMT940(String username, Boolean accountLimit) throws DAOException ;
    
    //IR 71227  
    public List findBrokerAccounts(String username) throws DAOException;
    
    public AccountDetails findAccountDetails(Account account) throws DAOException;

	public List modifyDeleteMT940(String username, Boolean accountLimit);
	
	// CR-CPSMS Beneficiary details display
   public List findAccountsApprover(String username,String corporateId) throws DAOException;
	//Added for eTDR/eSTDR -Start
	public boolean checkAccountForMasked(String accountno, String branchcode, String username)throws DAOException ;
	public List findAccountsByAccessLevel(String userName, String productType,int...accessLevel) throws DAOException;
	//Added for eTDR/eSTDR -End
	
	//Added for beneficiary revamp
	Account findAccountDtls(String accountNo, String benCode, String userName) throws DAOException;

	//Added by beneficiary revamp
	public boolean insertProfileAccountLogDtls(Account account, String actionFlag, String oldValues);
	public Account deleteTPAccountDtls( Account userAccount,String corporateId ) throws DAOException;
	
	
}
