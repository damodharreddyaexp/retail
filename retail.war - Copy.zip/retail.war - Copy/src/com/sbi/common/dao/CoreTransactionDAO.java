/*
 * CoreDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
package com.sbi.common.dao;

/**
 * CoreDAO extends BankSystemDAO
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public interface CoreTransactionDAO extends BankSystemDAO
{

}
