/*
 * CompBenFileDAO.java
 * Created on Aug 6, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CompBenDataModel;
import com.sbi.common.model.CorporateFile;



public interface CompBenFileDAO
{
	List getFileConfiguration(String corporateId,String fileType) throws DAOException;
	
	List getNewFileConfiguration(String corporateId,String fileType) throws DAOException;
	
	public int findConfigCount(String corporateId,String replacedString) throws DAOException;
	
	public int deleteOldConfig(String corporateId) throws DAOException ;
	
	public boolean findFileStatusTP(String corporateID) throws DAOException;
	
    public int insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) throws DAOException;
    
    public Map updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType)throws DAOException;

    List findUploader(String userName,String corporateId) throws DAOException;
    
    public List findTPFiles(String userName,String uploaderName) throws DAOException;
    
    public List findTPInterFiles(String userName,String uploaderName) throws DAOException;
    
    public List findTPDelFiles(String userName,String uploaderName) throws DAOException;
    
    public List findDIBTPFiles(String userName,String uploaderName) throws DAOException;
    
    public List findCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException;
    
    public List findAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException;
    
    public List findRegSftpBenFiles(String corporateId,String userName,String uploaderName) throws DAOException;
	
	public int findBenRecCount(String fileName,String userName,String corporateId,String fileType) throws DAOException;
	
	public Map findCompBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) throws DAOException;
    
	public CompBenDataModel[] findBenRecDisplay(String fileName,String userName,String corporateId,String fileType) throws DAOException;
	
	public CompBenDataModel[] findCompBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName) throws DAOException;
	
	public int updateBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId) throws DAOException;
	
	public int updateBenStatusConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException;
    
    public int updateBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName) throws DAOException;

    public int updateBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException ;
    
    public int updateCompBenStatusRejectConfirm(List rejectOid,String userName,String fileType,String corporateId,String fileName) throws DAOException;

    public int updateCompBenStatusRejectConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException ;
    
    public int updateCompBenStatusConfirm(List approveOid,String userName,String fileType,String corporateId,String fileName) throws DAOException;
    
    public int updateCompBenStatusConfirm(String fileName,String userName,String fileType,String corporateId) throws DAOException;
    
    public List viewCompBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException;
    
    public List viewAdminSftpBenFiles(String corporateId,String userName,String uploaderName,String benFileType) throws DAOException;
    
    public List viewRegSftpBenFiles(String corporateId,String userName,String uploaderName) throws DAOException;

    public List viewDIBTPFiles(String userName,String uploaderName) throws DAOException;		

    public List viewTPDelFiles(String userName, String uploaderName) throws DAOException;	
     
    public List viewTPInterFiles(String userName, String uploaderName) throws DAOException;

    public List viewTPFiles(String userName,String uploaderName) throws DAOException;
    
	public Map findCompViewBenRecCount(String fileName,String userName,String corporateId,String uploaderName,String fileType) throws DAOException;
	
	public int findViewBenRecCount(String fileName,String userName,String corporateId,String fileType) throws DAOException ;
	
	public CompBenDataModel[] findViewBenRecDisplay(String fileName,String userName,String corporateId,String fileType) throws DAOException ;
	
    public CompBenDataModel[] findCompViewBenRecDisplay(String fileName,String userName,String corporateId,String specificFileType,String uploaderName) throws DAOException ;
    
    public CompBenDataModel[] downloadCompBenFiles(String fileName,String userName,String corporateId,String fileType) throws DAOException; 

}
