/*  
 * LateProcessRequestDAO.java
 * Created on Set 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import wac.logger.WACDAOException;
import wac.logger.WACException;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;

/**
 * TODO LateProcessRequestDAO interface
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public interface LateProcessRequestDAO {

    /**
     * TODO 
     * @param account object 
     * @return List
     */
 List findLatestBalance(Account account) throws WACException;

 /**
  * TODO 
  * @param userName String 
  * @return List
  */
 List findCoreStatementTransaction(String userName) throws WACDAOException;

 /**
  * TODO 
  * @param requestId String
  * @return List
  */
 List findcoreAccountStatementdetails(String requestId, String userName,String orderByValue) throws WACDAOException;
 
 
String fetchRequestId(String userName, String accountNo, String branchCode, String fromDate,String toDate)throws WACDAOException;

 //Added For CR 5565 Starts
public List findMT940AccountStatement(String username,int days) throws DAOException;
 
 public void insertToLPR(Map lprAcctStmt) throws DAOException;
 //Added For CR 5565 Ends
 //Added For CR 5588
 public List getReconFilesbyDate(String corpId,String fromDate,String toDate) throws DAOException;
 // IR71227 BEGIN
 List findBrokerStatementTransaction(String userName) throws WACDAOException;
 
 List findBrokerAccountStatementdetails(String requestId, String userName,String orderByValue) throws WACDAOException;
 
 public String fetchRequestIdForBrokerAccount(String userName, String accountNo, String branchCode, String fromDate, String toDate)	throws DAOException;
// IR71227 END
}
 