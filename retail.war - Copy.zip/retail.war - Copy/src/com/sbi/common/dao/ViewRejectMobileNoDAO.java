package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;

public interface ViewRejectMobileNoDAO {

	
	 public List viewRejectMobileNoDetails(Map userAlias)throws  DAOException;
	
	 public int  rejectMobileNoConfirm(Map userAlias)throws  DAOException;
	 
	 public List viewRejectMobileNoDetailsUser(Map userAlias)throws  DAOException;
	 
	 public int cancelMobileNoUserConfirm(Map userAlias,String[] approveOIds_arr)throws  DAOException;
	 
	 
}
