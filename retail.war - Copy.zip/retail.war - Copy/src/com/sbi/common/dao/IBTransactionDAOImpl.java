/*
 * IBTransactionDAOImpl.java
 * Created on Oct 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 26, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
//DEC 28, 2005 BOOPATHI - EXCEPTION MODIFIED
//Jan 23, 2005 MURUGAN K- properties configuration add for Transaction Type and Status 
package com.sbi.common.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.StoredProcedure;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionLeg;
import com.sbi.common.model.TransactionResponse;
import com.sbi.common.utils.BranchUtils;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;

import com.sbi.common.service.ServiceConstant;

/**
 * TODO Enter the description of the class here
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class IBTransactionDAOImpl extends JdbcDaoSupport implements IBTransactionDAO {

    protected final Logger logger = Logger.getLogger(getClass());

    private ResourceBundleMessageSource transactionProperties;

    private BranchUtils branchUtils;

    public String createTransaction(Transaction transaction) {

        logger.info("createTransaction(Transaction transaction) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("transaction :" + transaction);
        }
        try {

            Object[] debit = null;
            List creditsList = new ArrayList();
            if (transaction.getDebit() != null) {
                debit = transaction.getDebit().toObject();
                if (logger.isDebugEnabled()) {
                    logger.debug(" Debit leg : " + debit);
                }

                for (int i = 0; i < debit.length; i++)
                    if (logger.isDebugEnabled()) {
                        logger.debug("Debit Leg value :" + debit[i]);
                    }
            }

            if (transaction.getCredit() != null) {

                if (logger.isDebugEnabled()) {
                    logger.debug("Credit Length :" + transaction.getCredit().length);
                }
                for (int i = 0; i < transaction.getCredit().length; i++) {
                    if (transaction.getCredit()[i] != null) {
                        creditsList.add(transaction.getCredit()[i].toObject());
                        if (logger.isDebugEnabled()) {
                            logger.debug(" Credit leg:" + creditsList.get(i));
                        }
                    }
                }
            }
            SumStoredProcedure sproc=null;
            //added for CR-2655
            if(transaction.isScheduled()){
             logger.info("Procedure to be called : "+ DAOConstants.JAVA_RETAIL_TRANSACTION_PROCESS_SCHEDULE_TRANSACTION_PROCNAME);
            sproc = new SumStoredProcedure(getJdbcTemplate(),
                         DAOConstants.JAVA_RETAIL_TRANSACTION_PROCESS_SCHEDULE_TRANSACTION_PROCNAME,true);
           }//end here
            else{
            sproc = new SumStoredProcedure(getJdbcTemplate(),
                   DAOConstants.JAVA_RETAIL_TRANSACTION_PROCESS_TRANSACTION_PROCNAME,false);
           }
            logger.info("created proc obj.."+sproc);
            Map procResult = sproc.execute(debit, creditsList, transaction);
            ///if (logger.isDebugEnabled()) {
            logger.info(" reference no : " + (String) procResult.get("p_referenceno"));
            //}

            String error = (String) procResult.get(DAOConstants.P_ERROR);
            logger.info("error" +error);
            if (error.equalsIgnoreCase(DAOConstants.ZERO)) {
                logger.info("createTransaction(Transaction transaction) " + LoggingConstants.METHODEND);
                return (String) procResult.get(DAOConstants.P_REFERENCE_NO);
            }
            else {
            	if (error.equalsIgnoreCase("Duplicate transaction"))
            		DAOException.throwException("MP006", new Object[] {error});
            	else
            		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }

        }
        catch (DataAccessException ex) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        catch (Exception ex) {
            logger.fatal(LoggingConstants.EXCEPTION, ex);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public boolean updateStatus(TransactionResponse transactionResponse, String refNo) {

        logger.info("updateStatus(TransactionResponse transactionResponse, String refNo) "
                + LoggingConstants.METHODBEGIN);
        logger.info("transactionResponse :" + transactionResponse);
        logger.info("refNo :" + refNo);
        
        if (transactionResponse != null && refNo.trim() != DAOConstants.EMPTY && refNo != null) {
            try {
                int[] types = new int[]
                { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
                getJdbcTemplate().update(
                        SQLConstants.UPDATE_IB_STATUS,
                        new Object[]
                        { transactionResponse.getStatusCode(), transactionResponse.getStatusDescription(),
                                transactionResponse.getResponseReference(), refNo }, types);
                if (logger.isDebugEnabled()) {
                    logger.debug("Return true");
                }
                return true;
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return false;
    }

    public List findDebits(String userName, String status) {
        logger.info("findDebits(String userName, String status) " + LoggingConstants.METHODBEGIN);

        
        logger.info("userName :" + userName);
        logger.info("status :" + status);
        
        
        if (userName != null && !userName.trim().equals(DAOConstants.EMPTY) && status != null
                && !status.trim().equals(DAOConstants.EMPTY)) {
            try {
                Object[] parameters = new Object[]
                { userName, status };
                List debitsList = getJdbcTemplate().query(SQLConstants.FIND_PENDING_DEBITS, parameters,
                        new TransactionLegRowMapper());
                if (debitsList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("debitsList :" + debitsList);
                    }
                    logger.info("findDebits(String userName, String status) " + LoggingConstants.METHODEND);
                    return debitsList;
                }
                else{
                	logger.info("findDebits(String userName, String status) " + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public List findDebits(String userName) {

        logger.info("findDebits(String userName) " + LoggingConstants.METHODBEGIN);

        logger.info("userName :" + userName);
        

        if (userName != null && !userName.trim().equals(DAOConstants.EMPTY)) {

            try {
                Object[] parameters = new Object[]
                { userName };
                List debitsList = getJdbcTemplate().query(SQLConstants.FIND_DEBITS, parameters,
                        new TransactionLegRowMapper());

                if (debitsList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("debitsList :" + debitsList);
                    }
                    logger.info("findDebits(String userName) " + LoggingConstants.METHODEND);
                    return debitsList;
                }
                else{
                	logger.info("findDebits(String userName) " + LoggingConstants.METHODEND);
                    return null;
                }

            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public TransactionLeg findDebit(String referenceNo) {

        logger.info("findDebit(String referenceNo) " + LoggingConstants.METHODBEGIN);
        
        logger.info("referenceNo :" + referenceNo);
        

        if (referenceNo != null && !referenceNo.trim().equals(DAOConstants.EMPTY)) {

            try {
                Object[] parameters = new Object[]
                { referenceNo };
                List debitsList = getJdbcTemplate().query(SQLConstants.FIND_DEBITS_BY_REFNO, parameters,
                        new TransactionLegRowMapper());
                if (debitsList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("debitsList :" + debitsList);
                    }
                    logger.info("findDebit(String referenceNo) " + LoggingConstants.METHODEND);
                    return (TransactionLeg) debitsList.get(0);
                }
                else
                    return null;
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

    public List findCredits(String referenceNo) {

        logger.info("findCredits(String referenceNo) " + LoggingConstants.METHODBEGIN);
        
        logger.info("referenceNo :" + referenceNo);
        

        if (referenceNo != null && !referenceNo.trim().equals(DAOConstants.EMPTY)) {

            try {
                String creditQuery = SQLConstants.FIND_CREDITS;
                String replacedQuery = creditQuery.replaceAll("refno", referenceNo);
                if(logger.isDebugEnabled())
                	logger.debug("query :" + replacedQuery);
                //Object[] parameters = new Object[]
                //{ referenceNo };
                List debitsList = getJdbcTemplate().query(replacedQuery, new TransactionLegRowMapper());
                if (debitsList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("debitsList :" + debitsList);
                    }
                    logger.info("findCredits(String referenceNo) " + LoggingConstants.METHODEND);
                    return debitsList;
                }
                else{
                	logger.info("findCredits(String referenceNo) " + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

    public Double findTodaysTxnAmount(String accountNo, String branchCode, Double amount) {

        logger.info("findTodaysTxnAmount(String accountNo, String branchCode, Double amount) "
                + LoggingConstants.METHODBEGIN);

        int amountLimit = 0;
        int scheduledAmt=0;
        int totalAmtLimit=0;

        if (accountNo != null && !accountNo.trim().equalsIgnoreCase(DAOConstants.EMPTY) && branchCode != null
                && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY) && amount != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("accountNo :" + accountNo);
                logger.debug("branchCode :" + branchCode);
                logger.debug("amount :" + amount.toString());
            }
            try {
                Object[] parameters = { amount, accountNo, branchCode };
                amountLimit = getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_TRANSACTION_AMOUNT_QUERY,
                        parameters);
                Object[] scheduledParameters = {accountNo, branchCode };
                scheduledAmt=getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_SCHEDULED_TRANSACTION_AMOUNT_QUERY,
                    		scheduledParameters);
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }

            totalAmtLimit=amountLimit+scheduledAmt;
            logger.info("amount + scheduledAmt:" + totalAmtLimit);

            
            logger.info("findTodaysTxnAmount(String accountNo, String branchCode, Double amount) "
                    + LoggingConstants.METHODEND);
            return new Double(totalAmtLimit);
        }
        else {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }
    //Added for CR 2921    
	public boolean updateUTRNo(String refNo, String utrNo, String commissionAmount) {
		boolean result = false;
		Object args[] = { utrNo.trim(), refNo };
		try {
			String sql = "update sbi_ib_credits set utr_no=? #COMMAMT# where debit_reference_no=?";
			String commAmtQuery = "";
			if(commissionAmount !=null){
				commAmtQuery = ",commission_amount = ?";
				args = new Object[]{ utrNo.trim(), commissionAmount, refNo };
			}
			int upd = getJdbcTemplate().update(sql.replaceAll("#COMMAMT#", commAmtQuery), args);
			if (upd > 0)
				result = true;
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured : ", dataAccessException);
			DAOException.throwException("CUD001", new Object[] { args });
		}
		return result;

	}
    


    public Double findTodaysGovtTxnAmount(String accountNo, String branchCode, Double amount) {

        logger.info("findTodaysTxnAmount(String accountNo, String branchCode, Double amount) "
                + LoggingConstants.METHODBEGIN);

        int amountLimit = 0;
        int scheduledAmt=0;
        int totalAmtLimit=0;

        if (accountNo != null && !accountNo.trim().equalsIgnoreCase(DAOConstants.EMPTY) && branchCode != null
                && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY) && amount != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("accountNo :" + accountNo);
                logger.debug("branchCode :" + branchCode);
                logger.debug("amount :" + amount.toString());
            }
            try {
                Object[] parameters = { amount, accountNo, branchCode };
                amountLimit = getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_TRANSACTION_AMOUNT_QUERY,
                        parameters);
                Object[] scheduledParameters = {accountNo, branchCode };
                scheduledAmt=getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_SCHEDULED_TRANSACTION_OLTAS_AMOUNT_QUERY,
                    		scheduledParameters);
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }

            totalAmtLimit=amountLimit+scheduledAmt;
            logger.info("amount + scheduledAmt:" + totalAmtLimit);

            
            logger.info("findTodaysTxnAmount(String accountNo, String branchCode, Double amount) "
                    + LoggingConstants.METHODEND);
            return new Double(totalAmtLimit);
        }
        else {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }
    
    public Double findTodaysTotalTxnAmount(String userName, Double amount,String refType , Date scheduledDate){
        double amountLimit=0 ;
        Double amountDouble =new Double(amountLimit);
         logger.debug("findTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
         logger.info("UserName :"+userName+" amount :"+amount +" refType :"+refType);

         if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null && refType != null
                 && !refType.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {

             try {
                 Object[] parameters =
                 { amount,userName,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
                 //logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
                	amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
                 amountLimit=amountDouble.doubleValue();
             }
             catch (DataAccessException ex) {
                 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
             }

             logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);

             logger.debug("findTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
             return new Double(amountLimit);
         }
         else {
             DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
         return null;
         }
    
  //Merchant Limit Changes - Start
    /**
     * @description Method to retrieve the total transactions made for the particular retail user.
     * @param userName
     * @param amount
     * @param refType
     * @param scheduledDate
     */
    public Double findRetailUsrTodaysTotalTxnAmount(String userName, Double amount, Date scheduledDate){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_RETAILUSR_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
    public Double findRetailUsrTodaysIGTotalTxnAmount(String userName, Double amount, Date scheduledDate){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findRetailUsrTodaysIGTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_IGCATEGORY_RETAILUSR_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findRetailUsrTodaysIGTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
    public Double findSaralUsrTodaysTotalTxnAmount(String userName, Double amount, Date scheduledDate){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_SARALUSR_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
    public Double findGovtRTLUsrTodaysTotalTxnAmount(String userName, Double amount, Date scheduledDate){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_GOVT_RTL_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
    public Double findGovtSaralUsrTodaysTotalTxnAmount(String userName, Double amount, Date scheduledDate){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findGovtSaralUsrTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_GOVT_SARAL_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findGovtSaralUsrTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
    public Double findGovtindependentTotalTxnAmount(String userName, Double amount, Date scheduledDate, String merchantCode){
    	double amountLimit=0 ;
    	Double amountDouble =new Double(amountLimit);
    	logger.debug("findTodaysTotalTxnAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
    	logger.info("UserName :"+userName+" amount :"+amount);
    	
    	if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null ) {
    		
    		try {
    			Object[] parameters =
    				{ amount,userName,scheduledDate,scheduledDate,scheduledDate,merchantCode}; // username added and refType removed -ponnusamy
    			//logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
    			amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_INDEPENDENT_TXN_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
    			amountLimit=amountDouble.doubleValue();
    		}
    		catch (DataAccessException ex) {
    			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
    		}
    		
    		logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);
    		
    		logger.debug("findTodaysTotalTxnAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
    		return new Double(amountLimit);
    	}
    	else {
    		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
    	}
    	return null;
    }
  //Merchant Limit Changes - End
    
    public Double findInterBranchAmount(String accountNo, String branchCode, Double amount, String refName) {

        int amountLimit = 0;
 
        logger.info("findInterBranchAmount(String accountNo, String branchCode, Double amount, String refName) "
                + LoggingConstants.METHODBEGIN);

        if (accountNo != null && !accountNo.trim().equalsIgnoreCase(DAOConstants.EMPTY) && branchCode != null
                && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY) && amount != null && refName != null
                && !refName.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {

            if (logger.isDebugEnabled()) {
                logger.debug("accountNo :" + accountNo);
                logger.debug("branchCode :" + branchCode);
                logger.debug("amount :" + amount.toString());
                logger.debug("refName :" + refName);
            }

            try {
                Object[] parameters =
                { amount, accountNo, branchCode, refName + DAOConstants.PERCENTAGE };
                amountLimit = getJdbcTemplate().queryForInt(SQLConstants.FIND_INTERBRANCH_AMOUNT_QUERY, parameters);
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }

            
            logger.info("amount :" + amountLimit);

            logger.info("findInterBranchAmount(String accountNo, String branchCode, Double amount, String refName) "
                    + LoggingConstants.METHODEND);
            return new Double(amountLimit);
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    private String getTransactionStatus(String key) {
        String transactionValue = DAOConstants.TXN_STATUS_UNKNOWN;
        try {
            transactionValue = transactionProperties.getMessage(key, null, null);
        }
        catch (NoSuchMessageException ex) {
           //logger.error("Exception occured" ,ex );
        }

        return transactionValue;
    }

    class TransactionLegRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            TransactionLeg tran = new TransactionLeg();

            tran.setReferenceNo(rs.getString(SQLConstants.REFERENCE_NO));
            String identifier = rs.getString(SQLConstants.REFERENCE_NO).substring(0, 2);
            String message = getTransactionStatus(DAOConstants.TXN_NAME_PROPERTY + identifier);
            tran.setType(message); 
            tran.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
            tran.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            tran.setBranchName(branchUtils.getBranchName(rs.getString(DAOConstants.BRANCH_CODE)));
            String statusCode = rs.getString(DAOConstants.STATUS_CODE);
           
            String tranCode = getTransactionStatus(DAOConstants.TXN_STATUS_PROPERTY + statusCode);
            tran.setStatusCode(tranCode);
            tran.setThirdPartyRef(rs.getString(DAOConstants.THIRD_PARTY_REF));
            tran.setAmount(new Double(rs.getDouble(SQLConstants.AMOUNT)));
            tran.setUserName(rs.getString(SQLConstants.USER_NAME));
            tran.setMerchantCode(rs.getString(SQLConstants.MERCHANT_CODE));
            tran.setStatusDescription(rs.getString(SQLConstants.STATUS_DESC));
            tran.setAdditionalParams(null);// check it
            tran.setCurrency(rs.getString(DAOConstants.CURRENCY));
            tran.setRemarks(rs.getString(SQLConstants.REMARKS));
            tran.setTransactionTime(rs.getTimestamp(SQLConstants.CREATION_TIME));
            tran.setProductType(identifier); // This is field using for store the above "identifier" ;
            return tran;
        }
    }

    private class SumStoredProcedure extends StoredProcedure {
        protected final Logger logger = Logger.getLogger(getClass());

        public SumStoredProcedure(JdbcTemplate jdbcTemplate, String name ,boolean scheduleStatus) {
            super(jdbcTemplate, name);
            setSql(name);
            declareParameter(new SqlParameter(DAOConstants.P_DEBITLEG, OracleTypes.STRUCT,
                    DAOConstants.OBJ_TRANSACTIONLEG));
            declareParameter(new SqlParameter(DAOConstants.P_CREDITLEG, OracleTypes.ARRAY, DAOConstants.TRANSACTIONLEG));
            declareParameter(new SqlParameter(DAOConstants.P_TRANSACTIONNAME, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(DAOConstants.P_TRANSACTIONPATH, OracleTypes.VARCHAR));
            if(scheduleStatus){
            	declareParameter(new SqlParameter(DAOConstants.P_SCHEDULED_DATE, OracleTypes.TIMESTAMP));
            	declareParameter(new SqlParameter(DAOConstants.P_COMMISSION, OracleTypes.VARCHAR));
            }
            declareParameter(new SqlOutParameter(DAOConstants.P_REFERENCE_NO, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(DAOConstants.P_ERROR, OracleTypes.VARCHAR));
            compile();

        }

        public Map execute(final Object[] debit, final List creditsList, final Transaction transaction) {
            return execute(new ParameterMapper() {
                public Map createMap(Connection conn) throws SQLException {

                    StructDescriptor sdesc1 = StructDescriptor.createDescriptor(DAOConstants.OBJ_TRANSACTIONLEG, conn);
                    if (logger.isDebugEnabled()) {
                        logger.debug("Create STRUCT : " + debit);
                    }
                    STRUCT param1 = new STRUCT(sdesc1, conn, debit);
                    if (logger.isDebugEnabled()) {
                        logger.debug(" Begin Credit : " + debit);
                    }

                    STRUCT[] objStruct = new STRUCT[creditsList.size()];
                    for (int i = 0; i < creditsList.size(); i++) {
                        objStruct[i] = new STRUCT(sdesc1, conn, (Object[]) creditsList.get(i));
                    }
                    ArrayDescriptor objAd = ArrayDescriptor.createDescriptor(DAOConstants.TRANSACTIONLEG, conn);
                    ARRAY array = new ARRAY(objAd, conn, objStruct);

                    Map params = new HashMap();
                    params.put(DAOConstants.P_DEBITLEG, param1);
                    params.put(DAOConstants.P_CREDITLEG, array);
                    params.put(DAOConstants.P_TRANSACTIONNAME, transaction.getName().trim());
                    params.put(DAOConstants.P_TRANSACTIONPATH, transaction.getPath());
                    if(transaction.isScheduled()){
                    	params.put(DAOConstants.P_SCHEDULED_DATE, transaction.getScheduledDate());
                    	DecimalFormat decimalFormat = new DecimalFormat("#############0.00");
                    	params.put(DAOConstants.P_COMMISSION,"0");
                    }
                    return params;
                }
            });

        }
        
 

    }
    //Method Added for Multiple Credit NEFT commission
    public boolean updateMultipleCreditsCommission(Double commissionAmount,String refNo,Double crAmount) {
		boolean result = false;
		Object args[] = {commissionAmount,refNo,crAmount };
		try {
			
			String commAmtQuery="update sbi_ib_credits set commission_amount=? where debit_Reference_no = ? and amount = ?";
			int upd = getJdbcTemplate().update(commAmtQuery,args);
			if (upd > 0)
				result = true;
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured : ", dataAccessException);
			DAOException.throwException("CUD001", new Object[] { args });
		}
		return result;

	}
    
    public Double findTodaysIndependentTxnAmount(String accountNo, String branchCode, Double amount,String merchantCode) {

        logger.info("findTodaysIndependentTxnAmount(String accountNo, String branchCode, Double amount) "
                + LoggingConstants.METHODBEGIN);

        int amountLimit = 0;
        int scheduledAmt=0;
        int totalAmtLimit=0;

        if (accountNo != null && !accountNo.trim().equalsIgnoreCase(DAOConstants.EMPTY) && branchCode != null
                && !branchCode.trim().equalsIgnoreCase(DAOConstants.EMPTY) && amount != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("accountNo :" + accountNo);
                logger.debug("branchCode :" + branchCode);
                logger.debug("amount :" + amount.toString());
            }
            try {
                Object[] parameters = { amount, accountNo, branchCode,merchantCode };
                amountLimit = getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_TRANSACTION_OLTAS_AMOUNT_QUERY,
                        parameters);
                Object[] scheduledParameters = {accountNo, branchCode };
                scheduledAmt=getJdbcTemplate().queryForInt(SQLConstants.FIND_TODAY_SCHEDULED_TRANSACTION_OLTAS_AMOUNT_QUERY,
                    		scheduledParameters);
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }

            totalAmtLimit=amountLimit+scheduledAmt;
            logger.info("amount + scheduledAmt:" + totalAmtLimit);

            
            logger.info("findTodaysGovtTxnAmount(String accountNo, String branchCode, Double amount) "
                    + LoggingConstants.METHODEND);
            return new Double(totalAmtLimit);
        }
        else {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    //E-suvidha
    
    // 	Added for KiosK - CR 2914 - Start 
	public int insertKioskDetails(String referenceNo, String kioskID,
			String userName,String bankCode) {
		
		// TODO Auto-generated method stub
		int insertCount=0;
		try{
    		Object[] parameters ={referenceNo,kioskID,userName,bankCode,bankCode};
    		insertCount = getJdbcTemplate().update("INSERT INTO SBI_KIOSK_TRANSACTION_DETAILS(REFERENCE_NO,KIOSK_ID,USER_NAME,CREATION_TIME,LAST_MOD_TIME,BANK_CODE) VALUES (?,?,?,SYSDATE,SYSDATE,DECODE(?,'A','0','6','0','3','0',?))", parameters);//modified for SBIE merger
    		logger.info("insertCount :"+insertCount);
    	}catch (DataAccessException ex) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }catch(Exception e){
    		e.printStackTrace();
    	}
		return insertCount;
	}
    
	 public List findDebits(String userName,String transactionType,String fromDate,String toDate) {

	        logger.debug("findDebits(String userName,String transactionType,String fromDate,String toDate) Begin" );             

	        if (userName != null && !userName.trim().equals(DAOConstants.EMPTY)) {
	           logger.info("test"+fromDate+"'"+toDate);
	            try {
	            	List debitsList=null;
	                Object[] parameters = new Object[]
	                { userName ,fromDate, toDate };
	                if(transactionType.equals(ServiceConstant.TXN_ENQ_ALL_STATUS))
	                {
	                debitsList = getJdbcTemplate().query(SQLConstants.FIND_DEBITS_WITH_RANGE_ALL, parameters,
	                        new TransactionLegRowMapper());
	                }
	                if(transactionType.equals("visaTransaction"))
	                {
	                debitsList = getJdbcTemplate().query(SQLConstants.FIND_DEBITS_WITH_RANGE_VISA, parameters,
	                            new TransactionLegRowMapper());	
	                }                

	                if (debitsList != null && debitsList.size() > 0) {
	                    if (logger.isDebugEnabled()) {
	                        logger.debug("findDebits(String userName) End debitsList :" + debitsList);
	                    }
	                    
	                    return debitsList;
	                }
	                else{
	                	logger.debug("findDebits(String userName,String fromDate,String toDate) End" );
	                    return null;
	                }

	            }
	            catch (DataAccessException ex) {

	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	            }
	        }
	        else {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }
	        return null;
	    }
    
	   public Double findTodaysTotalCategoryCAmount(String userName, Double amount , Date scheduledDate){
	       double amountLimit=0 ;
	       Double amountDouble =new Double(amountLimit);
	        logger.debug("findTodaysTotalCategoryCAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
	        logger.info("UserName :"+userName+" amount :"+amount);

	        if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null) {

	            try {
	                Object[] parameters =
	                { amount,userName,scheduledDate,scheduledDate,scheduledDate}; 
	               	amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_C_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
	                amountLimit=amountDouble.doubleValue();
	            }
	            catch (DataAccessException ex) {
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	            }

	            logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);

	            logger.debug("findTodaysTotalCategoryCAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
	            return new Double(amountLimit);
	        }
	        else {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }
	        return null;
	        }
	 
		 public boolean validateIcollectCreditAccountNo(String creditAccountNo,String categoryId) {
				logger.info("validateIcollectCreditAccountNo(..) Starts here");
				
				boolean isValid=false;
				String validationQuery = "select count(*) from bvsbi.sbi_institute_category where account_no = ? and category_id = ?"; 
				if(creditAccountNo!=null && categoryId!=null){
					logger.info("creditAccountNo"+creditAccountNo+"crefeo"+categoryId);
					try{
						final int sqlTypes[]={OracleTypes.VARCHAR,OracleTypes.VARCHAR};
						final Object[] obj=new Object[] {creditAccountNo,categoryId};
						int chkCount=getJdbcTemplate().queryForInt(validationQuery,obj,sqlTypes);
						logger.info("chkcount"+chkCount);
						if(chkCount>0){
							isValid=true;
						}
					} catch (DAOException exp) {
						logger.error("ERROR: Unable to execute the query:: "+ exp.getMessage(), exp);
						DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);
						
					}catch(DataAccessException exp){
						logger.error("ERROR: Unable to retrieve details from sbi_institute_category ::: "+ exp.getMessage(), exp);
						DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exp);
					}
				}
				logger.info("validateIcollectCreditAccountNo(..) Ends here");
				return isValid;
			}
		 public Double findTodaysTotalSubCategoryGroupBTxnAmount(String userName, Double amount , Date scheduledDate,String category){
		        logger.debug("findTodaysTotalSubCategoryGroupBTxnAmount(String userName, Double amount, Date scheduledDate,String category) Begin");
		        logger.info("UserName :"+userName+" amount :"+amount +" Category :"+ category);
		        Map categoryMap = new HashMap();
		   
		        double amountLimit=0 ;
		        String FIND_TODAYS_TOTAL_SUBCAT_TXN_AMOUNT_QUERY = " SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0) amount FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) in #tobereplaced# ) ))";
		        
		        String FIND_TODAYS_TOTAL_TXN_AMOUNT_QUERY_BP =" SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0)+ NVL (fn_get_bp_amount (?), 0) amount FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) in #tobereplaced# ) ))";;
		        
		        String FIND_SCHEDULE_BILL_PAYMENT_AMOUNT ="SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT NVL(SUM(A.AMOUNT),0) amount FROM SBI_BP_PAYMENT_SCHEDULE A WHERE A.USERNAME = ? AND A.STATUS = 1 AND A.DEBIT_REF_NO IS NULL AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))";
		        Double amountDouble =new Double(amountLimit);
		        Object[] parameters ={ amount,userName,scheduledDate,scheduledDate,scheduledDate}; 
		        
		        categoryMap.put("BillPayment", "('CB')");
		    	categoryMap.put("DemandDraft", "('CD')");
		    	
		    	
		        String queryString1 =(String)categoryMap.get(category);
		        logger.info("category>>>>>>>>>"+category);
		        String finalQuery="";
		        if(!"BillPayment".equalsIgnoreCase(category)){
			         /* finalQuery = FIND_TODAYS_TOTAL_SUBCAT_TXN_AMOUNT_QUERY.replaceFirst(
							DAOConstants.TO_BE_REPLACED, queryString1);*/
			          finalQuery = FIND_TODAYS_TOTAL_SUBCAT_TXN_AMOUNT_QUERY.replaceAll(
							DAOConstants.TO_BE_REPLACED, queryString1);
			          logger.info("finalQuery:::::"+finalQuery);
				     amountDouble = (Double)getJdbcTemplate().queryForObject(finalQuery	, parameters,Double.class);
			    }else if("BillPayment".equalsIgnoreCase(category)){
			    	 /*  finalQuery = FIND_TODAYS_TOTAL_TXN_AMOUNT_QUERY_BP.replaceFirst(
								DAOConstants.TO_BE_REPLACED, queryString1);*/
			    	if(scheduledDate.compareTo(new Date())>0){
		    			
		    			
		    			 logger.info("finalQuery:::::"+FIND_SCHEDULE_BILL_PAYMENT_AMOUNT);
		    			Object[]   parametersBpSchedule ={amount, userName,scheduledDate};
		    			amountDouble = (Double)getJdbcTemplate().queryForObject(FIND_SCHEDULE_BILL_PAYMENT_AMOUNT	, parametersBpSchedule,Double.class);
		    		}else{
				       finalQuery = FIND_TODAYS_TOTAL_TXN_AMOUNT_QUERY_BP.replaceAll(
								DAOConstants.TO_BE_REPLACED, queryString1);
				       logger.info("finalQuery:::::"+finalQuery);
				       Object[]   parametersBp ={ amount,userName,userName ,scheduledDate,scheduledDate,scheduledDate}; 
				        amountDouble = (Double)getJdbcTemplate().queryForObject(finalQuery	, parametersBp,Double.class);
			    }
		        
			    }
		        amountLimit=amountDouble.doubleValue();	            
		        logger.info("findTodaysTotalSubCategoryGroupBTxnAmount  "+category+" :" + amountLimit);
		        logger.debug("findTodaysTotalSubCategoryGroupBTxnAmount(String userName, Double amount, Date scheduledDate,String category) Ends");
		        return new Double(amountLimit);    
		 }
		   public Double findTodaysTotalCategoryBAmount(String userName, Double amount , Date scheduledDate){
		       double amountLimit=0 ;
		       Double amountDouble =new Double(amountLimit);
		        logger.debug("findTodaysTotalCategoryBAmount(String userName,String accountNo, String branchCode, Double amount, String refName) Begin");
		        logger.info("UserName :"+userName+" amount :"+amount);

		        if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)  && amount != null) {

		            try {
		                Object[] parameters =
		                { amount,userName,userName,scheduledDate,scheduledDate,scheduledDate}; // username added and refType removed -ponnusamy
		                //logger.info("FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY  :"+SQLConstants.FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY);
		               	amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_B_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
		                amountLimit=amountDouble.doubleValue();
		            }
		            catch (DataAccessException ex) {
		                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		            }

		            logger.info("amountLimit  :"+amountDouble+"TodaysTotalTxnAmount :" + amountLimit);

		            logger.debug("findTodaysTotalCategoryBAmount(String accountNo, String branchCode, Double amount, String refName) Ends");
		            return new Double(amountLimit);
		        }
		        else {
		            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		        }
		        return null;
		        }

	//Added for eTDR/eSTDR -Start
    public Double findTodaysTotalCategoryGAmount(String userName, Double amount , Date scheduledDate){
        logger.debug("findTodaysTotalCategoryGAmount(String userName, Double amount,String refType , Date scheduledDate) Begin");
        logger.info("UserName :"+userName+" amount :"+amount );
        double amountLimit=0 ;
	    Double amountDouble =new Double(amountLimit);
        Object[] parameters ={ amount,userName,scheduledDate,scheduledDate,scheduledDate}; 
        amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAY_CATEGORY_G_AMOUNT_QUERY, parameters,Double.class);//Added 'IJ' in the query for Make Donation Link
        amountLimit=amountDouble.doubleValue();	            
        logger.info("TodaysTotalTxnAmount for Category G :" + amountLimit);
        logger.debug("findTodaysTotalCategoryGAmount(String userName, Double amount,String refType , Date scheduledDate) Ends");
        return new Double(amountLimit);
        
        
    }
    public Double findTodaysFdAmount(Double debitAmount,String userName){
	       double amountLimit=0 ;
	       Double amountDouble =new Double(amountLimit);
	        logger.debug("findTodaysFdAmount(String userName) Begin");
	        logger.info("UserName :"+userName+" debit Amount ::"+debitAmount);

	        if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {

	            try {
	                Object[] parameters = {debitAmount,userName}; 
	                
	               	amountDouble = (Double)getJdbcTemplate().queryForObject(SQLConstants.FIND_TODAYS_FD_AMOUNT_QUERY, parameters,Double.class);
	                amountLimit=amountDouble.doubleValue();
	            }
	            catch (IncorrectResultSizeDataAccessException ex) {
	               //no FD transactions for the day .
	            }
	            catch (DataAccessException ex) {
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	            }

	            logger.info("amountLimit  :"+amountDouble.toString()+"TodaysFdAmount :" + amountLimit);

	            logger.debug("findTodaysFdAmount(String userName) End");
	           
	        }
	        else {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }
	        return new Double(amountLimit);
	        }
    //Added for eTDR/eSTDR -End

    public void setBranchUtils(BranchUtils branchUtils) {

        this.branchUtils = branchUtils;
    }

    public void setTransactionProperties(ResourceBundleMessageSource transactionProperties) {
        this.transactionProperties = transactionProperties;
    }

}
