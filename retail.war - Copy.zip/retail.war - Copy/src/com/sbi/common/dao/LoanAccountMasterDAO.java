
/*
 * AccountMasterDAO.java
 * Created on Oct 18, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 Sreenivasulu - Initial Creation

package com.sbi.common.dao;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;

public interface LoanAccountMasterDAO extends AccountMasterDAO {
	// CR 147 start
	public AccountDetails findLoanAccountDetails(Account account);
	// CR 147 end
}
