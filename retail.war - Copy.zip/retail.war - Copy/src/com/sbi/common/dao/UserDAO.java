/* 
 * UserDAOImpl.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//Oct 28,2005  MURNGAN K - method's implementation 

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;
 
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Address;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;

/**
 * TODO Enter the description of the class here
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */ 
public interface UserDAO {
 
    /**
     * TODO find valid username and password from Table
     * 
     * @param userName
     * @param passWord
     * @return User
     * @throws DAOException
     */
    public User findUser(String userName, String passWord) throws DAOException;

    public boolean activateDeactivateUser(String userName,Integer activate);
    
    public boolean activateDeactivateUser(String userName,Integer activate,String coprorateId);//shanta

    public String getCharityName(String donateId) throws DAOException;
    
    
	public boolean delete(String userName);
    /**
     * TODO find valid username from Table
     * 
     * @param userName
     * @return User
     * @throws DAOException
     */
    public User findUser(String userName) throws DAOException;

    /**
     * TODO find the User Address from BV_USER_PROFILE table
     * 
     * @param userName
     * @return
     * @throws DAOException
     *             Address
     */
    public Address findUserAddress(Integer userId) throws DAOException;

    /**
     * TODO find the User profile table
     * 
     * @param userName
     * @return
     * @throws DAOException
     *             UserProfile 
     */
    public UserProfile findUserProfile(String userName) throws DAOException;
    public UserProfile findUserProfile(String userName, String corporateId) throws DAOException;//shanta
    
    /**
     * TODO Enter the description of the method here
     * @param profileParamList
     * @param userName
     * @return
     * @throws DAOException UserProfile
     */  
    public UserProfile updateProfile( List profileParamList,User user )throws DAOException;
    
   //    public boolean validateLogin(String userName, String password) throws DAOException;    
    public boolean validateLogin(String userName, String password, String keyString) throws DAOException;//by nag
    public boolean validateLogin(String userName, String password, String keyString,String sha2Password, String hashingType ) throws DAOException;//by nag  //Added for SHA encryption algorithm
 
    public void changeLoginPassword(User user, String oldPassword, String newPassword) throws DAOException; 
    public String updateUserName(String oldUserName, String newUserName) throws DAOException;
    public void changeUserNamePassword(String userName, String oldUserName, String newPassword) throws DAOException;
     
    public String secretKeyGenerator(String randomNo) throws DAOException;
    
    // for ca admin 
    
    public boolean isUserExists(String userName);
     
    public Map addUser(UserProfile userProfile,String role, List AuditAccMap,String pwd) throws DAOException;
    
    public boolean findUserByEmpNo(String empNo) throws DAOException; 
    
    public boolean changeCorporateUserName(String userName, String oldUserName, String password) throws DAOException;
    
   // public void insertLoginTime(User user) throws DAOException;
    
    public String getPasswordType(String userName);
    ;
    public void insertLoginTime(User user, String sessionId, String loginStatus,String serverName);
    
    /**
     * TODO  find the availability of DDebit status from sbi_ddebit_supp_details,sbicorp_corporate_profile,sbicorp_ca_user_map
     * @param corporateId
     * @param userName
     * @return String will be corpuser,corpddebituser,ddebituser
     */
    void updateAccessRights(String caUser,String userName,String userType,String accRights)throws DAOException;
    
    //	CR 1808 - Reset login password using PPKIT - starts    
    public String getKModeUserName(String userName); 
    
     //public boolean kModeValidateLogin(String userName, String password, String kModeUsername) throws DAOException;
    public boolean kModeValidateLogin(String userName, String password, String kModeUsername,String keyString) throws DAOException; //by nag
    //	CR 1808 - Reset login password using PPKIT - ends
   public Map getUserRoleAndType(String userName)throws DAOException;//added for CR 2450
   
	
	//added for Anaklyn user Login check the user Active
    public boolean checkUserLogin(String s)
        throws DAOException;
    
    //Added for CR - 5110
    public void updateUserLock(String userName)throws DAOException; 
    
    public void updateUserUnlock(String userName)throws DAOException; 
    
    public Map getUserLockPWDType(String userName)throws DAOException;
    
    //Added for CR 5143
    
    public List getUserRefs (String userName)  throws DAOException;
    
    public int insertUserDispatchDetails(String seqNo,String message,String dispatchId,String module,String type) throws DAOException;

    public String getDispatchSerialNo(String appendChar,String type) throws DAOException;
    //For Dynamic Links 
    public int updateUserState(String userName,int userType);
    //Phishing changes -start
    public int getPhisingIPAddress(String ipAddress) throws DAOException;
    public void insertPhishingUserDetails(User user,String userRole);
    public void insertActiveUserLogin(Map inparamMap ) ;//Added For CR 5405
	public void deleteActiveUserLogin(String userName ) ;//Added For CR 5405
	//Phishing changes -end
	//Added For CR 5472 Starts
	public String addUserPrePrintKit(UserProfile userProfile, String role) throws DAOException;
	public boolean findUserByEmpNo(String empNo,String corpId) throws DAOException; 
	public boolean findUserByEmpNo(String empNo,String role,String caUser,String corpId) throws DAOException;
	public Map getUserDetails(String caUser, String roleID, String corpId) throws DAOException;
	public UserProfile getUserProfileDetails(String userName,String caUser) throws DAOException;
	public String updateProfileDetails( UserProfile userProfile)throws DAOException;
	//Added For CR 5472 Ends
	public int getPrevPassHistory(String userName, String password) throws DAOException;//Added for CR 5450
	 //  Added for CR 5550
    public void changeKLoginPassword(String userName, String newPassword, String ipAddress) throws DAOException;
    //  End of CR 5550
  	public List findPPKIT(String userName, String corporateID,String ppID,String flag) throws DAOException;//Added for CR 5552
  	
	public String getPPkitNumber( String userName)throws DAOException;

 	public void  insertMobileDetails(UserProfile userProfile,String role,String userId);
	
	/* Ramanan.M : Begin - Added to Lock and Unlock the Uploader */
 	public Map getDeactivatedUploaderDetails(String caUser, String roleID, String corpId) throws DAOException;
 	//Added for Merchant High Security
 	public int updateCorpProfile(String userName, String highSecurityStatus,String corporateID) throws DAOException;
 	
 	public String getMerchantMode(String corporateID) throws DAOException;
	
	public int findValidCorpUser(String ebrokingId,String corporateId,String corpAdmin,String userName) throws DAOException; //Added for DMAT corporate
    
    public String currencyTradeUser(String userName) throws DAOException; //Added for DMAT corporate

	public void insertMobileDetailsPPKit(UserProfile userProfile,
			String role, String userId) throws 	DAOException;
	
	public RegMobileNoDetails updateMobileNoDetails(Integer userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,String userRole,String cororateId,String userAlias,String friendlyName)throws  DAOException;
    
	public UserProfile findUserProfileDetails(String userName, String corporateId) throws DAOException;//Mobile No updation
//E-suvidha
	int  updateNewTPTransactions(String username, String creditAccountNo,String echequeNo,String branchCode,double amount,String transactionStatus,String module);
	public boolean updateBranchPFPassword(String userName, String password);
     public boolean updateCirlePFPassword(String userName,String password) throws DAOException; //Added for circlePF password change by KV   
	public boolean updateOTPDeliveryMode(String userName,String otpOption) throws DAOException;
}
