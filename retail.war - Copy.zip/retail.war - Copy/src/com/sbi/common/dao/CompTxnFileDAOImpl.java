/*
 * CompositeFileConfigDAOImpl.java
 * Created on SEP 18, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.model.CompTxnFileModel;


public class CompTxnFileDAOImpl extends JdbcDaoSupport implements CompTxnFileDAO
{

    private Logger logger = Logger.getLogger(getClass());

    public final static String SELECT_FIXED_FILE_CONFIGURATION = "select * from sbicorp_fixed_config where oid=? order by start_index";

    public final static String SELECT_DELIMITED_FILE_CONFIGURATION = "select * from sbicorp_delimited_config where oid=? order by order_no";

    public final static String SELECT_FIXED_FILE_NEW_CONFIGURATION = "select * from sbicorp_fixed_config where comp_config_type=? order by start_index";

    public final static String SELECT_DELIMITED_FILE_NEW_CONFIGURATION = "select * from sbicorp_delimited_config where comp_config_type=? order by order_no";
    
    public List getFileConfiguration(String corporateId,String fileType) throws DAOException {
		logger.info("getFileConfiguration(String corporateId,String fileType) - begin");
		List configList = null;
		List list = null;
		String query =null;
		Object[] params = new Object[] { corporateId };
		logger.info("Input param corporate Id ="+corporateId);
		try {

			if(DAOConstants.SAME_BANK.equalsIgnoreCase(fileType))
			{
				query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and txn_type like '%CT%'";
			}
			else if (DAOConstants.OTHER_BANK.equalsIgnoreCase(fileType))
			{
				query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and (txn_type like '%CR%' or txn_type like '%CN%' or txn_type like '%CZ%')";
			}
			
			else 
			{
				query="select * from sbicorp_file_config_master where id in ('default',?) and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and (txn_type like '%CT%' and txn_type like '%CR%' and txn_type like '%CN%' and txn_type like '%CZ%')";
			}
					
			logger.info("query::::"+query);
				
			configList = getJdbcTemplate().query(query, params,new ConfigurationMapper());
			logger.info("Result : "+configList);
			if ((configList != null) && (configList.size() > 0)) {

				CompTxnFileModel configuration = (CompTxnFileModel) configList.get(0);
				String txn_type=configuration.getTransactionType();
				logger.info("file Type:"+fileType);

				int format = configuration.getFormat();

				if (configuration.getFormat() != 0) {
					
					Object[] paramsfixed = new Object[] { configuration.getOid() };
					list = getJdbcTemplate().query(SELECT_FIXED_FILE_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
					logger.info("Fixed configuration :"+list);
					
					if ((list != null) && (list.size() > 0)) {
						CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
					
				} else {
					
					Object[] paramsdelimited = new Object[] { configuration.getOid() };
					logger.info("OID===" +configuration.getOid());
                   
					list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_CONFIGURATION,
                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
					
                  	logger.info("Delimited configuration ="+list);
					if ((list != null) && (list.size() > 0)) {
						CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
						configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
				}
			
			}
		} catch (DataAccessException e) {
			logger.error("Error occured :" , e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("getFileConfiguration(String corporateId,String fileType) - end");
		return list;
	}
    
    public List getNewFileConfiguration(String corporateId,String fileType) throws DAOException {
		logger.info("getNewFileConfiguration(String corporateId,String fileType) - begin");
		List configList = null;
		List configListBoth = null;
		List configListAny = null;
		List configListDefault = null;
		List list = null;
		String query =null;
		String query_both =null;
		String query_any =null;
		String query_default =null;
		String type = "Same and Other Only";
		Object[] params = new Object[] { corporateId };
		logger.info("Input param corporate Id ="+corporateId);
		try {

			query="select * from sbicorp_file_config_master where id =? and corporate_type='Corporate' and upper(stage) like '%IN%' and txn_type ='" + fileType + "' and status=1";
			logger.info("query::::"+query);
				
			configList = getJdbcTemplate().query(query, params,new ConfigurationMapper());
			logger.info("Result : "+configList);
			if ((configList != null) && (configList.size() > 0)) {

				CompTxnFileModel configuration = (CompTxnFileModel) configList.get(0);
				String txn_type=configuration.getTransactionType();
				logger.info("file Type:"+fileType);

				int format = configuration.getFormat();

				String compositeConfigType=(String)configuration.getCompConfigType();
				
				if (configuration.getFormat() != 0) {
					
					Object[] paramsfixed = new Object[] { compositeConfigType };
					logger.info("compositeConfigType ===" +compositeConfigType);
					
					list = getJdbcTemplate().query(SELECT_FIXED_FILE_NEW_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
					logger.info("Fixed configuration :"+list);
					
					if ((list != null) && (list.size() > 0)) {
						CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					}
					
				} else {
					
					Object[] paramsdelimited = new Object[] { compositeConfigType };
					logger.info("compositeConfigType ===" +compositeConfigType);
                   
					list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_NEW_CONFIGURATION,
                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
					
                  	logger.info("Delimited configuration ="+list);
					if ((list != null) && (list.size() > 0)) {
						CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
						configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
						configuration2.setFormat(format);
						list.remove(0);
						list.add(0, configuration2);
					
					}
				}
				list.add(list.size(),fileType);
			}
			else{
				query_both="select * from sbicorp_file_config_master where id=? and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and (txn_type like '%CT%' and txn_type like '%CR%' and txn_type like '%CN%' and txn_type like '%CZ%')";
				query_any="select * from sbicorp_file_config_master where id=? and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and (txn_type like '%CT%' or txn_type like '%CR%' or txn_type like '%CN%' or txn_type like '%CZ%')";
				query_default="select * from sbicorp_file_config_master where id in ('default', ?) and corporate_type='Corporate' and upper(stage) like '%IN%' and status=1 and (txn_type like '%CT%' and txn_type like '%CR%' and txn_type like '%CN%' and txn_type like '%CZ%')";
				configListBoth = getJdbcTemplate().query(query_both, params,new ConfigurationMapper());
				configListAny = getJdbcTemplate().query(query_any, params,new ConfigurationMapper());
				
				if ((configListBoth != null) && (configListBoth.size() > 0)) {
					
					logger.info("query::::"+query_both);
					logger.info("Result : "+configListBoth);
					CompTxnFileModel configuration = (CompTxnFileModel) configListBoth.get(0);
					String txn_type=configuration.getTransactionType();

					int format = configuration.getFormat();

					if (configuration.getFormat() != 0) {
						Object[] paramsfixed = new Object[] { configuration.getOid() };
						list = getJdbcTemplate().query(SELECT_FIXED_FILE_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
						logger.info("Fixed configuration :"+list);
						if ((list != null) && (list.size() > 0)) {
							CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
							configuration2.setFormat(format);
							list.remove(0);
							list.add(0, configuration2);
						}	
					} 
					else {
						Object[] paramsdelimited = new Object[] { configuration.getOid() };
						logger.info("OID===" +configuration.getOid());
						list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_CONFIGURATION,
	                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
						logger.info("Delimited configuration ="+list);
						if ((list != null) && (list.size() > 0)) {
							CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
							configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
							configuration2.setFormat(format);
							list.remove(0);
							list.add(0, configuration2);
						}
					}
					list.add(list.size(),"both_bank");
				}
				else if((configListAny.isEmpty()) && (configListAny.size() == 0)) {
					
					logger.info("query::::"+query_default);
					configListDefault = getJdbcTemplate().query(query_default, params,new ConfigurationMapper());
					logger.info("Result : "+configListDefault);
					CompTxnFileModel configuration = (CompTxnFileModel) configListDefault.get(0);
					String txn_type=configuration.getTransactionType();

					int format = configuration.getFormat();

					if (configuration.getFormat() != 0) {
						Object[] paramsfixed = new Object[] { configuration.getOid() };
						list = getJdbcTemplate().query(SELECT_FIXED_FILE_CONFIGURATION,paramsfixed, new FixedFileConfigurationMapper(txn_type));
						logger.info("Fixed configuration :"+list);
						if ((list != null) && (list.size() > 0)) {
							CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
							configuration2.setFormat(format);
							list.remove(0);
							list.add(0, configuration2);
						}	
					} 
					else {
						Object[] paramsdelimited = new Object[] { configuration.getOid() };
						logger.info("OID===" +configuration.getOid());
						list = getJdbcTemplate().query(SELECT_DELIMITED_FILE_CONFIGURATION,
	                                    paramsdelimited, new DelimitedFileConfigurationMapper(txn_type));
						logger.info("Delimited configuration ="+list);
						if ((list != null) && (list.size() > 0)) {
							CompTxnFileModel configuration2 = (CompTxnFileModel) list.get(0);
							configuration2.setFieldDelimiter(configuration.getFieldDelimiter());
							configuration2.setFormat(format);
							list.remove(0);
							list.add(0, configuration2);
						}
					}
					list.add(list.size(),"both_bank");
				}
				else{
					logger.info("No Composite or IntraInter Bank configuration exist");
				}
			}
		} catch (DataAccessException e) {
			logger.error("Error occured :" , e);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("getNewFileConfiguration(String corporateId,String fileType) - end");
		return list;
	}
    
    
    public int findConfigCount(String corporateId) throws DAOException {
		logger.info("findConfigCount(String corporateId,String replacedString) method begins");
		int  countVal = 0;
		try{
			if(corporateId != null) {
			Object[] params={corporateId};
			String query="select count(*) from sbicorp_file_config_master where id =? and STAGE='IN' " +
					"and MODE_CONFIG='File' and RECORD_DELIMITER='N'and CORPORATE_TYPE='Corporate'" +
					" and (txn_type like '%CT%' or txn_type like '%CR%' or txn_type like '%CN%'" +
					"or txn_type like '%CN%')";
			//String finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
			countVal = getJdbcTemplate().queryForInt(query,params);
			//logger.info("Count value for type"+replacedString+"is"+countVal);
			}
		    else   
		    {
            DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findConfigCount(String corporateId,String replacedString)  method ends");
		return countVal;
   }
   
    
    public int findConfigtxnCount(String corporateId,String replacedString) throws DAOException {
		logger.info("findConfigCount(String corporateId,String replacedString) method begins");
		int  countVal = 0;
		try{
			if(corporateId != null && replacedString != null) {
			Object[] params={corporateId};
			String query="select count(*) from sbicorp_file_config_master where txn_type in (#tobereplaced#) and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate'";
			String finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
			countVal = getJdbcTemplate().queryForInt(finalQuery,params);
			logger.info("Count value for type"+replacedString+"is"+countVal);
			}
		    else
		    {
            DAOException.throwException("F001");
		    }
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("findConfigCount(String corporateId,String replacedString)  method ends");
		return countVal;
   }
    
    public int deleteOldConfig(String corporateId,String format) throws DAOException {
		logger.info("deleteOldConfig(String corporateId) method begins");
		int  delCount = 0;
		int  delConfigCount = 0;
		try{
			Object[] params={corporateId};
			if(format.equalsIgnoreCase("Delimited")){
				String delDelimtquery ="Delete from SBICORP_DELIMITED_CONFIG where oid in (select oid from sbicorp_file_config_master where id =? " +
					"and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N'and CORPORATE_TYPE='Corporate'" +
					" and (txn_type like '%CT%' or txn_type like '%CR%' or txn_type like '%CN%'" +
					"or txn_type like '%CN%'))";
				delCount = getJdbcTemplate().update(delDelimtquery, params);
				logger.info("Deleted Count in SBICORP_DELIMITED_CONFIG table is"+delCount);
			}
			else if(format.equalsIgnoreCase("Fixed")){
			       String delFixedquery  ="Delete from SBICORP_FIXED_CONFIG where oid in (select oid from sbicorp_file_config_master where id =? " +
					"and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N'and CORPORATE_TYPE='Corporate'" +
					" and (txn_type like '%CT%' or txn_type like '%CR%' or txn_type like '%CN%'" +
					"or txn_type like '%CN%'))";
			       delCount = getJdbcTemplate().update(delFixedquery, params);
					logger.info("Deleted Count in SBICORP_FIXED_CONFIG table is"+delCount);
			}
			
				String delConfigquery ="Delete from SBICORP_FILE_CONFIG_MASTER where (txn_type like 'CT%' or txn_type like '%CR%' or txn_type like '%CN%'" +
					"or txn_type like '%CN%') and id = ? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate'";
				delConfigCount = getJdbcTemplate().update(delConfigquery, params);
			     logger.info("Deleted Count in SBICORP_FILE_CONFIG_MASTER table is"+delConfigCount);
			
		}
		catch (DataAccessException ex) {
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		logger.info("deleteOldConfig(String corporateId)  method ends");
		return delConfigCount;
	}
    
    public int insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType)throws DAOException
    {
    	int insertCount =0;
        logger.info("insertFileConfigComp(String corporateId,String format,String fieldDelimter,String compConfigType)method begin");
         try
            {
			    Object params[] = {
                    corporateId,formatVal,fieldDelimter,compConfigType
                };
               
                 insertCount = getJdbcTemplate().update("insert into SBICORP_FILE_CONFIG_MASTER(oid,id,store_id,creation_time, status,deleted,last_mod_time,corporate_type,stage,txn_type,mode_config,format,field_delimiter,record_delimiter,comp_config_type)values(oid_sequence.nextval,?,101,sysdate,1,0,sysdate,'Corporate','IN','COMPOSITE_TXN','File',?,?,'N',?)", params);
                logger.info("Record inserted For Composite Config:" + insertCount);
               
            }
            catch(DataAccessException exception)
            {
                DAOException.throwException("F001", exception);
            }
        logger.info("insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method end");
        return insertCount;
    } 
    
    public Map updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType)throws DAOException
    {
    	Map updateVal = new HashMap();
    	int updateCount = 0;
    	int  countVal = 0;
        logger.info("updateFileConfigComp(String corporateId,String format,String fieldDelimter,String compConfigType)method begin");
         try
            {
        	 
        	 Object[] parameter={corporateId,compConfigType};
    		 Object params[] = {
                    formatVal,fieldDelimter,compConfigType,corporateId
                };
			    
			    String query="select count(*) from sbicorp_file_config_master where   id = ? and COMP_CONFIG_TYPE=? and STAGE='IN' and MODE_CONFIG='File' and RECORD_DELIMITER='N' and CORPORATE_TYPE='Corporate'";
			    
			    countVal = getJdbcTemplate().queryForInt(query,parameter);
			    
			    if(countVal == 0){
                updateCount = getJdbcTemplate().update("update sbicorp_file_config_master set format = ?,FIELD_DELIMITER=?,COMP_CONFIG_TYPE=? where id =? and txn_type = 'COMPOSITE_TXN'", params);
                logger.info("Record Updated For Composite Config:" + updateCount);
                }else if(countVal > 0){
			     updateVal.put("configPresentVal", "Yes");
			  	 logger.info("Configuration already present so configPresentVal is Yes"+countVal);
			    }
			    updateVal.put("updateCount",updateCount);
            }
            catch(DataAccessException exception)
            {
                DAOException.throwException("F001", exception);
            }
        logger.info("updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) method end");
        return updateVal;
    }
     
    public class ConfigurationMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CompTxnFileModel configuration = new CompTxnFileModel();
			configuration.setFormat(rs.getInt(DAOConstants.FORMAT));
			logger.info("Format : " + configuration.getFormat());
			configuration.setFieldDelimiter(rs.getString(DAOConstants.FIELD_DELIMITER));
			configuration.setOid(rs.getLong(DAOConstants.OID));
			configuration.setTransactionType(rs.getString("TXN_TYPE"));
			configuration.setCompConfigType(rs.getString("comp_config_type"));
			return configuration;
		}
	}
    public class DelimitedFileConfigurationMapper implements RowMapper {

		String type=null;
		
		public DelimitedFileConfigurationMapper(String txnType) {
			this.type=txnType;
		}
		
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

			CompTxnFileModel fileConfiguration = new CompTxnFileModel();
			fileConfiguration.setFormat(0);	
			
			if(type!=null && (type.contains("CT")|| type.contains("CR") || type.contains("CN")|| type.contains("CZ")))			
			{
				if(rs.getString("FIELD_NAME").equalsIgnoreCase("OUTREF7")){
					logger.info("outref7");
					fileConfiguration.setFieldName("Beneficiary Code");
				}
				else if(rs.getString("FIELD_NAME").substring(0,3).equalsIgnoreCase("OUT")){
					logger.info("outref");
					fileConfiguration.setFieldName(rs.getString("FIELD_NAME").replaceFirst("o", "O"));
				}
				else if(rs.getString("FIELD_NAME").equalsIgnoreCase("DEBIT ACCOUNT NO")){
					logger.info("Debit Account Number");
					fileConfiguration.setFieldName("Debit Account Number");
				}
				else if(rs.getString("FIELD_NAME").equalsIgnoreCase("CREDIT ACCOUNT NO")){
					logger.info("Credit Account Number ");
					fileConfiguration.setFieldName("Credit Account Number");
				}
				else if(rs.getString("FIELD_NAME").equalsIgnoreCase("REFERENCE NO")){
					logger.info("Reference Number");
					fileConfiguration.setFieldName("Reference Number");
				}
				else if(rs.getString("FIELD_NAME").equalsIgnoreCase("PAYMENT_IDENTIFIER")){
					logger.info("Payment Identifier");
					fileConfiguration.setFieldName("Payment Identifier");
				}
				else
					fileConfiguration.setFieldName(rs.getString("FIELD_NAME"));
				
				if(rs.getString("FIELD_NAME").equalsIgnoreCase("DEBIT AMOUNT")){
					fileConfiguration.setTransactionCode("B");
				}
				else if(rs.getString("FIELD_NAME").equalsIgnoreCase("CREDIT AMOUNT")){
					fileConfiguration.setTransactionCode("B");
				}
				else{
					fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
				}	
			}
			else{
				fileConfiguration.setFieldName(rs.getString("FIELD_NAME"));
				fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
			}			
				
			fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
			fileConfiguration.setOrderNumber(rs.getInt(DAOConstants.ORDER_NO));
			fileConfiguration.setMaxLength(rs.getString("FIELD_LENGTH"));
			if (type != null && type.equalsIgnoreCase("CJ")) {
				fileConfiguration.setFieldValue(rs.getString("DEFAULT_VALUE"));
			}
			fileConfiguration.setCompConfigType(rs.getString("COMP_CONFIG_TYPE"));
			return fileConfiguration;
		}

	}
    public class FixedFileConfigurationMapper implements RowMapper {
		
    	String type=null;
		
		public FixedFileConfigurationMapper(String txnType) {
			this.type=txnType;
		}
		 
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			CompTxnFileModel fileConfiguration = new CompTxnFileModel();
			fileConfiguration.setFormat(1);			
			logger.info("Format : " + fileConfiguration.getFormat());
			
			if(type!=null && (type.contains("CT")|| type.contains("CR") || type.contains("CN")|| type.contains("CZ")))			
			{
				if(rs.getString("FLD_NAME").equalsIgnoreCase("OUTREF7")){
					logger.info("OUTREF7");
					fileConfiguration.setFldName("Beneficiary Code");
				}
				else if(rs.getString("FLD_NAME").substring(0,3).equalsIgnoreCase("OUT")){
					logger.info("outref");
					fileConfiguration.setFieldName(rs.getString("FLD_NAME").replaceFirst("o", "O"));
				}
				else if(rs.getString("FLD_NAME").equalsIgnoreCase("DEBIT ACCOUNT NO")){
					logger.info("Debit Account Number");
					fileConfiguration.setFldName("Debit Account Number");
				}
				else if(rs.getString("FLD_NAME").equalsIgnoreCase("CREDIT ACCOUNT NO")){
					logger.info("Credit Account Number ");
					fileConfiguration.setFldName("Credit Account Number");
				}
				else if(rs.getString("FLD_NAME").equalsIgnoreCase("REFERENCE NO")){
					logger.info("Reference Number");
					fileConfiguration.setFldName("Reference Number");
				}
				else if(rs.getString("FLD_NAME").equalsIgnoreCase("PAYMENT_IDENTIFIER")){
					logger.info("Payment Identifier");
					fileConfiguration.setFldName("Payment Identifier");
				}
				else
					fileConfiguration.setFldName(rs.getString("FLD_NAME"));
				
				if(rs.getString("FLD_NAME").equalsIgnoreCase("DEBIT AMOUNT")){
					fileConfiguration.setTransactionCode("B");
				}
				else if(rs.getString("FLD_NAME").equalsIgnoreCase("CREDIT AMOUNT")){
					fileConfiguration.setTransactionCode("B");
				}
				else{
					fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
				}
			}
			else{
				fileConfiguration.setFldName(rs.getString("FLD_NAME"));
				fileConfiguration.setTransactionCode(rs.getString("TXN_CODE"));
			}
			
			fileConfiguration.setFieldAlias(rs.getString("ALIAS_NAME"));
			fileConfiguration.setStartIndex(rs.getInt(DAOConstants.START_INDEX));
			fileConfiguration.setEndIndex(rs.getInt(DAOConstants.END_INDEX));
            fileConfiguration.setConstantValue(rs.getInt("CONST_VALUE"));
            fileConfiguration.setDefaultValue(rs.getInt("DEFAULT_VALUE"));
            fileConfiguration.setCompConfigType(rs.getString("COMP_CONFIG_TYPE"));
			return fileConfiguration;

		}

	}  
    
}

