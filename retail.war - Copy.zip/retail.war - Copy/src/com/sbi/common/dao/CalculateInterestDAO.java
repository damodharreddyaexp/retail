package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;

public interface CalculateInterestDAO {
	 /**
     * TODO Enter the description of the method here
     * @param account
     * @return List
     * @throws DAOException 
     */
    List findTransactionHistoryFirstRecord(Account account) throws DAOException;
    
	 /**
     * TODO Enter the description of the method here
     * @param account
     * @return List
     * @throws DAOException 
     */
    List findTransactionHistoryTxnDate(Account account) throws DAOException;    

	 /**
     * TODO Enter the description of the method here
     * @param account
     * @param count
     * @return List
     * @throws DAOException 
     */    
    List findTxnHistoryCount(Account account,String count)throws DAOException;
}
