/*
 * ProfileDAO.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 MURUGAN K - Initial Creation

package com.sbi.common.dao;

import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Query;

public interface ProfileDAO {
    
    public boolean linkAccounts( String userName, String linkedUserName);
    
    public Map findUserBranches(String userName, String bankSystem) throws DAOException;
    
    public boolean insertBranchMessage(String message, String branchCode) throws DAOException;
    
    public String insertPasswordCount(String userName, String branchCode) throws DAOException;
    
    public Map findCountryNameCodes() throws DAOException ;
    
    //CorpDynamicLink
    Map getLinkDetails(String userrole,String usertype,String banckcode,String moduleName) throws DAOException;
    Map getLinkDetails(String userrole,String usertype,String banckcode,String moduleName,String corporateId) throws DAOException;
    Map<String,Query> getQueries();
    
    String getQueryValue(String query, String userAlias,String corporateId);
    
    //Added for reset of transaction password -Start
    String getPasswordReferenceDetail(String userName,String branchCode,String type) throws DAOException;
    String insertPasswordCount(String userName, String branchCode,String type) throws DAOException;
    Boolean isTransactionPwdEmpty(String userName,String corporateId) throws DAOException;
   //Added for reset of transaction password -End
    
    //Added for lock user access starts 

    public Map lockAccountConfirm(String userName, String mobileNo,String bankCode,String corporateID) throws DAOException;
    public boolean userExist(String corporatId,String userName,String mobileNo) throws DAOException ;
	//Added for Voice OTP
    public Map findVoiceOTPMobileSeries() throws DAOException ;

	public Boolean getCorporateHasDisabledLinks(final String corporateId, final String moduleName);

}
