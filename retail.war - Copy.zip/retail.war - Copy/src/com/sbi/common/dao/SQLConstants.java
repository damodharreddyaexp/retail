/*
 * SQLConstants.java
 * Created on Oct 19, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $  
 */
//History
//Oct 19, 2005 BOOPATHI - Initial Creation
//Oct 28, 2005 MURUGAN  - LOGIN_SQL constants added.
// nov 23 , 2005 BOOPATHI - DATAS ADDED
//26 Nov 2005 Added by saravan N for Naveen ,DEPOSIT_RENEW_QUERY 
//28'Nov'05 Add by Saravanan for Naveen-INSERT_INTO_SBI_CHEQUE_REQUEST,RENEW_ACCOUNT_TYPE
//28'Nov'05 Add by Saravanan for Naveen-RENEW_MONTHS,RENEW_DAYS,FLAG
// Changed on 28-June-2006 for Paladion by Saravanan N
package com.sbi.common.dao;  
 
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.UtilsConstant;

/**  
 * TODO This class is used for Query and Storeprocedured Constants 
 *  
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */ 
public interface SQLConstants extends Constants {

    //IR71227
	final static String ACCOUNTS_BY_NATURE_QUERY = "select A.ACCOUNT_NO,A.BRANCH_CODE,B.BRANCH_NAME,nvl(A.NAME_THIRD_PARTY,'') ACCOUNT_NICKNAME,nvl(A.ACCESS_LEVEL,0)ACCESS_LEVEL ,B.CORE_BANKING COREFLAG,'INR' CURRENCY,TRANSACTION_LIMIT CLEAR_BALANCE, product_type ACCOUNTTYPE , product_desc,product_code,CORE_MESSAGE_STATUS,a.LOCK_FLAG, -1 limit,'' RTGS_IFSC_CODE ,'' NEFT_IFSC_CODE,'' BROKER_STMT_FLAG from SBI_CUSTOMER_ACCOUNT_MAP A, SBI_BRANCH_MASTER B where ACCOUNT_NATURE=? AND ACCOUNT_NO!='NONE' AND USER_NAME=? and A.STATUS=1 AND B.STATUS=1 AND A.BRANCH_CODE=B.BRANCH_CODE ORDER BY UPPER(ACCOUNT_NICKNAME) ASC";//CR 5058

    public final static String FIND_DEBITS = "select 'D' type, '' remarks, reason_failure status_description, 'INR' currency, reference_no, account_no, branch_code, status_code, third_party_ref, amount, user_name, merchant_code,creation_time from sbi_ib_status_view where user_name=? and status=1 order by creation_time desc";

    public final static String FIND_PENDING_DEBITS = "select 'D' type, '' remarks, reason_failure status_description, 'INR' currency, reference_no, account_no, branch_code, status_code, third_party_ref, amount, user_name, merchant_code,creation_time from sbi_ib_status where user_name=? and status=1 and status_code=? order by creation_time desc";

//  public final static String FIND_DEBITS_BY_REFNO = "select 'D' type, ''
    // remarks, reason_failure status_description, 'INR' currency, reference_no,
    // account_no, branch_code, status_code, third_party_ref, amount, user_name,
    // merchant_code,creation_time from sbi_ib_status where reference_no=?";
    // added username in where condn on june 28 2006 for paladion
    public final static String FIND_DEBITS_BY_REFNO ="select 'D' type, b.description remarks, a.reason_failure status_description,'INR' currency, a.reference_no, a.account_no,a.branch_code, a.status_code, a.third_party_ref,a.amount, a.user_name, a.merchant_code,a.creation_time from sbi_ib_status_view a,sbicorp_echeque_master b where a.reference_no=? and a.user_name=? and a.reference_no=b.echeque_no";

    public final static String FIND_CREDITS = "SELECT 'C' TYPE, narrative3 remarks, '' status_description, 'INR' currency,reference_no, account_no, branch_code, credit_status status_code,narrative1 third_party_ref, amount, user_name, '' merchant_code,creation_time FROM sbi_ib_transactions WHERE reference_no LIKE 'refno%' AND reference_no <> 'refno' || '00'";

    public final static String GET_CUSTOMER_BALANCES_PROC = "{call GETCUSTOMERALLBALANCES_NEW_C(?,?)}";

    public final static String LOGIN_SQL = "select USER_ID,USER_ALIAS,USER_STATE FROM BV_USER WHERE USER_ALIAS = ?";

    public final static String USER_ADDRESS_FINDER = "select   ADDRESS,CITY,STATE,ZIP,COUNTRY FROM BV_USER_PROFILE WHERE user_id = ?";

    public static final String USER_PROFILE_FINDER = "select name, FRIENDLY_NAME,address, city, state, zip, country, email, bus_phone, home_phone,last_login_date,last_tname_internet, last_tdate_internet,internet_bank_trans_limit, login_count, thirdparty_limit, branch_code, decode(bank_code,'','0','SBI','0',bank_code) bank_code, hint_question, hint_answer,   mobile_no, nvl(sms_security,1)sms_security, PROFILE_PASSWORD,user_type,nvl(corporate_id,0)corporate_id, PWD_CHANGED_DATE  FROM bv_user_profile,emp_no WHERE user_id in (select user_id from bv_user where user_alias=?)";
 
    /* Tables Related Constants */
    public static final String ACCOUNT_NO = "ACCOUNT_NO";

    public static final String BRANCH_CODE = "BRANCH_CODE";

    public static final String AMOUNT = "AMOUNT";

    public static final String CREATION_TIME = "CREATION_TIME";

    public static final String NARRATIVE1 = "NARRATIVE1";

    public static final String NARRATIVE2 = "NARRATIVE2";

    public static final String NARRATIVE3 = "NARRATIVE3";

    public static final String REFERENCE_NO = "REFERENCE_NO";

    public static final String TRANSACTION_COUNT = "TRANSACTION_COUNT";

    public static final String TRANSACTION_DATE = "TRANSACTION_DATE";

    public static final String TXN_TYPE_CODE = "TTYPE_CODE";

    public static final String DATE_VALUE = "DATE_VALUE";

    public static final String BALANCE = "BALANCE";

    // data added by boopathi

    public static final String FIND_ALL_STATES = "select distinct(state) from sbi_all_branches";

    public static final String FIND_LOCATION = "select distinct(location) from sbi_all_branches where state =?";

    public static final String FIND_BRANCHES = "select distinct(branch_name) from sbi_all_branches where location = ?";

    public static final String FIND_ALL_BRANCHES = "select * from sbi_branch_master";

    public static final String FIND_BRANCH_DETAILS = "select * from sbi_branch_master where branch_code = ?";
    
 
    public static final String FIND_BRANCHES_WITH_CODE ="select distinct branch_name, branch_code from sbi_all_branches where status=1 and ltrim(rtrim(location))=? and DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = ? order by branch_name";//mod for SBS merger 
        //"select distinct branch_name,branch_code from sbi_all_branches where status=1 and ltrim(rtrim(location))=? and substr(branch_code,0,1) in ('0','9') and bank_code='0' order by branch_name";
            //"select distinct(branch_name), branch_code from sbi_all_branches where location = ?";

    public static final String CORE_INTERFACE_REQ_PROPERTY = "select * from core_interface where txnno=? and type='req' order by ?,position";

    public static final String CORE_INTERFACE_RES_PROPERTY = "select * from core_interface where txnno=? and type='res' order by ?,position";

    public static final String DEPOSIT_ACC_MASTER_DATA = "select a.*,b.last_updated_date from sbi_deposit_acc_master a,sbi_branch_master b where a.account_no=? and a.branch_code=? and a.branch_code=b.branch_code and a.status=1 and b.status=1";

    public static final String ACCOUNT_DESC = "ACCOUNT_DESC";

    public static final String SHORT_NAME = "SHORT_NAME";

    public static final String NOMINATION = "NOMINATION";

    public static final String MATURITY_DATE = "MATURITY_DATE";

    public static final String MATURITY_AMOUNT = "MATURITY_AMOUNT";

    public static final String DRAWING_POWER = "DRAWING_POWER";

    public static final String CR_INT_RATE = "CR_INT_RATE";

    public static final String BALANCE_AS_DATE = "BALANCE_AS_DATE";

    public static final String PRINCIPAL = "PRINCIPAL";

    public static final String SBI_LOAN_ACC_MASTER_DATA = "select a.*,b.last_updated_date from sbi_loan_acc_master a,sbi_branch_master b where a.account_no=? and a.branch_code=? and a.branch_code=b.branch_code and a.status=1 and b.status=1";

    public static final String SANCTIONED_LIMIT = "SANCTIONED_LIMIT";

    public static final String INTEREST_RATE = "INTEREST_RATE";

    public static final String AMOUNT_OUTSTANDING = "AMOUNT_OUTSTANDING";

    public static final String SANCTIONED_AMOUNT = "SANCTIONED_AMOUNT";

    public static final String SBI_NAME_VALUE_MASTER_DATA ="select name,value from sbi_name_value_master ";//changed for CR2655 
    public static final String SBI_NAME_VALUE_PORT_NUMBER_DATA ="select name,value from sbi_name_value_master where name like ?";

    public static final String SBI_SWITCH_ERROR_DATA = "select error_code,error_desc from sbi_switch_error";

    public static final String SBI_CORE_ERROR_DATA = "select error_code,error_desc from sbi_core_error";

    public static final String SBI_ACC_MASTER_DATA = "select a.*,b.last_updated_date from sbi_acc_master a,sbi_branch_master b where a.account_no=? and a.branch_code=? and a.branch_code=b.branch_code and a.status=1 and b.status=1";

    public static final String CLEAR_BALANCE = "CLEAR_BALANCE";

    public static final String BOOK_BALANCE = "BOOK_BALANCE";

    public static final String SANCTIONED_DATE = "SANCTIONED_DATE";

    public static final String ACCUMULATED_INTEREST = "ACCUMULATED_INTEREST";

    public static final String OPENING_DATE = "OPENING_DATE";

    public static final String TENOR_DAYS = "TENOR_DAYS";

    public static final String TENOR_MONTH = "TENOR_MONTH";

    public static final String TENOR_YEAR = "TENOR_YEAR";

    public static final String PASSWORD_FLAG = "PASSWORD_FLAG";

    public static final String DORMANT_FLAG = "DORMANT_FLAG";

    static final String UPDATE_IB_STATUS = "update sbi_ib_status set status_code= ?, reason_failure = ?, payment_id=? where reference_no = ?";

 //   static final String FIND_TODAY_TRANSACTION_AMOUNT_QUERY = "select nvl(sum(amount),0)+? from sbi_ib_status where account_no=? and branch_code=? and trunc(creation_time)=trunc(sysdate) and status_code in ('00','08','LOG','F1')";
	static final String FIND_TODAY_TRANSACTION_OLTAS_AMOUNT_QUERY = "select nvl(sum(amount),0)+? from sbi_ib_status where account_no=? and branch_code=? and trim(merchant_code)=? and trunc(creation_time)=trunc(sysdate) and status_code in ('00','08','LOG.','F1','56') and SUBSTR(reference_no, 0, 2) != 'IE'"; // Changed by Ramasamy for CR 1404
	static final String FIND_TODAY_TRANSACTION_AMOUNT_QUERY = "select nvl(sum(amount),0)+? from sbi_ib_status where account_no=? and branch_code=? and trunc(creation_time)=trunc(sysdate) and status_code in ('00','08','LOG.','F1','56') and SUBSTR(reference_no, 0, 2) != 'IE'"; // Changed by Ramasamy for CR 1404
	
	static final String FIND_TODAY_SCHEDULED_TRANSACTION_AMOUNT_QUERY = "select nvl(sum(echeque_amount),0) from sbicorp_echeque_master where account_no=? and branch_code=?" +
			" and trunc(scheduled_date)=trunc(sysdate) and current_auth_level='50' and SUBSTR(echeque_no, 0, 2) != 'IE' ";
	
	static final String FIND_TODAY_SCHEDULED_TRANSACTION_OLTAS_AMOUNT_QUERY ="select nvl(sum(echeque_amount),0) from sbicorp_echeque_master where account_no=? and branch_code=?" +
			" and (trunc(creation_time)=trunc(sysdate) or(trunc(scheduled_date)=trunc(sysdate) or trunc(scheduled_date)=trunc(sysdate+1)))and current_auth_level='50' and SUBSTR(echeque_no, 0, 2) != 'IE'";

//    static final String FIND_INTERBRANCH_AMOUNT_QUERY = "select nvl(sum(amount),0)+? from sbi_ib_status where account_no=? and branch_code=? and trunc(creation_time)=trunc(sysdate) and status_code in ('00','08','LOG','F1') and (reference_no like ?) and status=1 and inter_branch=0";
    static final String FIND_INTERBRANCH_AMOUNT_QUERY = "select nvl(sum(amount),0)+? from sbi_ib_status where account_no=? and branch_code=? and trunc(creation_time)=trunc(sysdate) and status_code in ('00','08','LOG.','F1','56') and (reference_no like ?) and status=1 and inter_branch=0";   // Changed by Ramasamy for CR 1404
    
    static final String FIND_TODAY_INTER_BRANCH_TRANSACTION_AMOUNT_QUERY= "SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   DECODE (SUBSTR (echeque_no, 0, 2),'"+UtilsConstant.RTGS_CONSTANT+"', NVL (echeque_amount, 0)+ TO_NUMBER (NVL (rate_of_interest, 0)), '"+UtilsConstant.GRPT_CONSTANT+"', NVL (echeque_amount, 0)+ TO_NUMBER (NVL (rate_of_interest, 0)),NVL (echeque_amount, 0))+ NVL (fn_get_bp_amount (?), 0) amount "+
    	    " FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) "+
    		" OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) "+
    	    " OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) != 'II' and SUBSTR (a.echeque_no, 0, 2) != 'IE') OR (   SUBSTR (a.echeque_no, 0, 2) = 'II' AND EXISTS (SELECT 1 FROM SBI_IB_CREDITS B WHERE B.debit_reference_no = A.ECHEQUE_NO AND B.original_debit_branch != b.BRANCH_CODE AND B.credit_reference_no like '%01')))) ";
    static final String TYPE = "type";

    static final String USER_NAME = "user_name";

    static final String MERCHANT_CODE = "merchant_code";

    static final String STATUS_DESC = "status_description";

    static final String REMARKS = "remarks";

    static final String DEPOSIT_RENEW_QUERY = "select a.REFERENCE_NO, a.account_no,a.branch_code ,a.renew_months,a.renew_days , decode(a.renew_account_type,0,'NRE',1,'NRO',2,'NRNR',3,'FCNR',4,'Ordinary') as renew_account_type, decode(b.flag,0,'Captured',1,'InProcess',2,'Completed',3,'Pending', 4,'Cancelled')as flag  from sbi_deposit_account_renew a, sbi_ib_reference b where a.user_name = ? and a.reference_no = b.reference_no and a.user_name = b.user_name and flag in(0,1,3)";

    static final String INSERT_INTO_SBI_CHEQUE_REQUEST = "insert into SBI_CHEQUE_REQUEST values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    static final String RENEW_ACCOUNT_TYPE = "RENEW_ACCOUNT_TYPE";

    static final String RENEW_MONTHS = "RENEW_MONTHS";

    static final String RENEW_DAYS = "RENEW_DAYS";

    static final String FLAG = "FLAG";

    static final String REASON_STOPPAGE = "REASON_STOPPAGE";

    static final String BRANCH_CODE_NAME_QUERY = "select * from (select branch_code, branch_name, "+
    "decode(substr(branch_code,1,1),'A','0','6','0','3','0',substr(branch_code,1,1)) bank_code from sbi_branch_master ) "+
    " order by bank_code,branch_code";//mod for SBS merger

    static final String DATE_STOPPED = "DATE_STOPPED";

    //static final String CHECK_USER_BILLER_MAP = "select count(*) from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where b.STATUS=1 and a.STATUS=1 and b.presentment='0' and b.biller_id not in('IITC-Hostel','IITC-Semester') and a.biller_id = b.biller_id and a.biller_id=? and a.username =? order by Upper(b.biller_name) asc";

    static final String INSERT_INTO_SBI_DEPOSIT_ACCOUNT_RENEW = "insert into SBI_DEPOSIT_ACCOUNT_RENEW values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?)";

    static final String INSERT_INTO_SBI_SI = "insert into SBI_SI values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    static final String CHECK_BILLER_MASTER_DETAILS = "select count(*) from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where b.STATUS=1 and a.STATUS=1 and b.presentment='0' and b.biller_id not in('IITC-Hostel','IITC-Semester') and a.biller_id = b.biller_id and a.biller_id=? and a.username =? order by Upper(b.biller_name) asc"; 
    //    "select * from  SBI_BP_BILLER_MASTER a, SBI_BILLER_CREDIT_ACCOUNTS b where status=1 and parent_biller_id is null and a.oid=b.oid and substr(b.branch_code,0,1)=? and biller_id=? order by upper(biller_friendly_name)";

    static final String INSERT_INTO_SBI_APPLY_ACCOUNT = "insert into SBI_APPLY_ACCOUNT values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    static final String DELETE_FROM_SBI_CUSTOMER_ACCOUNT_MAP = "delete from SBI_CUSTOMER_ACCOUNT_MAP where user_name =? and account_no =? and account_nature =? and branch_code=?";
    static final String UPDATE_NICKNAME = "update SBI_CUSTOMER_ACCOUNT_MAP set ACCOUNT_NICKNAME = ? where USER_NAME = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ?";
    static final String UPDATE_THIRDPARTYNAME = "update SBI_CUSTOMER_ACCOUNT_MAP set NAME_THIRD_PARTY = ? ,TRANSACTION_LIMIT = ? where USER_NAME = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ?";
    static final String INSERT_INTO_SBI_CUSTOMER_ACCOUNT_MAP = "insert into SBI_CUSTOMER_ACCOUNT_MAP fields(oid,user_name,store_id,creation_time,status,deleted,last_mod_time,account_no,branch_code,old_username,transaction_limit,name_third_party,account_nature,access_level,verify_flag,branch_name,PRODUCT_CODE,PRODUCT_DESC) values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?)";
    static final String UPDATE_BV_USER_PROFILE = "update bv_user_profile set #tobereplaced# where user_id in (select user_id from bv_user where user_alias=?)";
    
    static final String INSERT_INTO_SBI_PASSWORD_COUNT =  "insert into sbi_password_count (oid,reference_no,store_id,creation_time,status,deleted,last_mod_time,user_name,password_requested_date,branch_code,password_type) values (oid_sequence.nextval,?,101,sysdate,1,1,sysdate,?,sysdate,?,1)";
//  CR -1559 modified by Ramachandran
    static final String PASSWORD_COUNT_REFERENCE =  "SELECT 'P' || lpad(SEQ_SBI_PASSWORD_COUNT.nextval,6,'0') from dual";
    
    static final String INSERT_INTO_SBI_BRANCH_MESSAGES = "insert into sbi_branch_messages (oid,message_id,store_id,creation_time,status,deleted,last_mod_time,branch_code,from_date,to_date,message,admin_name) values (oid_sequence.nextval,seq_forgot_pwd_refno.nextval,101,sysdate,1,1,sysdate,?,sysdate,(sysdate+7),?,'parsad')";
    
    static final String GET_USER_BRANCHES = "select distinct a.branch_code,b.branch_name from sbi_customer_account_map a, sbi_branch_master b where a.user_name=? and a.status=1 and a.account_nature=0 and a.verify_flag=0 and a.branch_code=b.branch_code and b.status=1 and (b.core_banking=? or b.core_banking=?) order by b.branch_name";

    //  Added for CR 1279
    static final String GET_USER_BRANCHES_UNDER_MIGRATION = "select distinct a.branch_code,b.branch_name from sbi_customer_account_map a, sbi_branch_master b, sbi_migration_status c where a.user_name=? and a.status=1 and a.account_nature=0 and a.verify_flag=0 and a.branch_code=b.branch_code and b.status=1 and a.branch_code = c.branch_code and c.migration_status != 'Live' and upper(c.migration_status) in (upper('Made_Offline'),upper('Process_Completed')) order by b.branch_name";  
    
    //static final String UPDATE_BV_USER_PROFILE = "update BV_USER_PROFILE" + queryString + "WHERE USER_NAME = ?";
    //    

    static final String FIND_COUNTRY_NAME_CODE = "SELECT  COUNTRY_CODE,COUNTRY_NAME FROM SBI_COUNTRY_CODE WHERE STATUS =1  order by COUNTRY_NAME";

    // Bill payment 

    static final String CHECK_BILL_EXISTS = "select  count(*) from sbi_bp_user_biller_map a, sbi_bp_bill_master b,sbi_bp_biller_master c where a.username = ? and a.biller_id=b.biller_id and b.biller_id=c.biller_id  and c.status=1 and  ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) )  and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )   and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) )  and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )   and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) )  and a.status=1 and b.status=1 and b.scheduled = 1 and b.BILL_NUMBER=? and a.BILLER_ID=?  and c.presentment=0 and (a.cust_reg_status='Accepted' or a.cust_reg_status is null) "; 
        //"select  b.bill_number,b.biller_id, a.biller_shortname,  b.bill_date, b.bill_due_date, b.bill_amount, b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c where a.username =? and a.biller_id=b.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and  ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and  ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and  ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and  ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and  a.status=1 and b.status=1 and b.scheduled = 1 and  b.BILL_NUMBER=? and b.BILLER_ID=? and b.bill_amount<=? and b.biller_id=c.biller_id and c.presentment=0 and a.cust_reg_status='Accepted'";

    static final String CHECK_PAYMENT_SCHEDULE = "select count(*) from sbi_bp_payment_schedule where status=1 and BILLER_ID=? and BILL_NUMBER=? and USERNAME=? and AMOUNT=?"; 
    //    "select amount from sbi_bp_payment_schedule where status=1 and BILLER_ID=? and BILL_NUMBER=? and USERNAME=? and AMOUNT==?";

    static final String CHECK_USER_BILLER_MAP_FORWITHOUT_BILL = "Select count(*) from sbi_bp_user_biller_map a, sbi_bp_biller_master b where a.status=1 and (a.cust_reg_status='Accepted' or a.cust_reg_status is null) and a.biller_id=b.biller_id and b.status=1 and (presentment=1 or (presentment=0 and payment_without_bill=0)) and a.username=? and b.biller_id=?"; 
        //"Select * from sbi_bp_user_biller_map a, sbi_bp_biller_master b where a.status=1 and a.cust_reg_status='Accepted' and a.biller_id=b.biller_id and b.status=1 and presentment=1 and a.username=? and b.biller_id=?";

       static final String CHECK_USER_BILLERMAP = "select count(*) from  SBI_BP_BILLER_MASTER a, SBI_BILLER_CREDIT_ACCOUNTS b where status=1 and a.oid=b.oid and substr(b.branch_code,0,1)=? and biller_id=? order by upper(biller_friendly_name)"; 
       //    "select a.*,b.* from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where b.STATUS=1 and a.STATUS=1 and b.presentment='0' and b.biller_id not in('IITC-Hostel','IITC-Semester') and a.biller_id = b.biller_id and a.biller_id=? and a.username =? order by Upper(b.biller_name) asc";
  
    //static final String INSERT_INTO_SBI_SI = "insert into SBI_SI values(oid_sequence.nextval,?,?,sysdate,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
  
    //Profile Module Start
    // Query for CREDITABLE validation
    public static final String CREDITABLE_RETRIEVE = "select creditable from sbi_product_desc where product_code = ?";

    public static final String FIND_INB_LOCATION = "select distinct(location) from sbi_branch_master where status=1 and ((live=0 and last_conn_time is not null) or core_banking=0) and DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1))= ? order by location";//mod for SBS merger

    public static final String FIND_INB_BRANCHES = "select distinct(branch_name) from sbi_all_branches where status=1 and ((live=0 and last_conn_time is not null) or core_banking=0) and ltrim(rtrim(location)) = ? order by branch_name";

    //public static final String FIND_INB_BRANCHES_WITH_CODE = "select distinct(branch_name), branch_code, core_banking from sbi_branch_master where status=1 and ((live=0 and last_conn_time is not null) or core_banking=0) and location = ? and DECODE(SUBSTR(branch_code,0,1),'A','0',SUBSTR(branch_code,0,1))=? order by branch_name";
    //Modified for regulator re-testing -CR 2436
   // public static final String FIND_INB_BRANCHES_WITH_CODE = "select distinct(branch_name), replace(branch_code,'A','1')branch_code, core_banking from sbi_branch_master where status=1 and ((live=0 and last_conn_time is not null) or core_banking=0) and location = ? and DECODE(SUBSTR(branch_code,0,1),'A','0',SUBSTR(branch_code,0,1))=? order by branch_name";
    //Modified by Sunjay S Galen
    public static final String FIND_INB_BRANCHES_WITH_CODE = "select distinct(branch_name),branch_code, core_banking from sbi_branch_master where status=1 and ((live=0 and last_conn_time is not null) or core_banking=0) and location = ? and DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1))=? order by branch_name";//mod for SBS merger
    
    public final static String PROFILE_LOG_QUERY = "insert into sbi_profile_changelog fields(user_name,ip_address,mod_time,mod_item,old_data,new_data) values(?,?,sysdate,?,?,?)";
    
    public final static String PROFILE_LOG_QUERY_ACCOUNT = "insert into sbi_profile_changelog fields(user_name,ip_address,mod_time,mod_item,old_data,new_data) values(?,?,sysdate,?,?,?)";
    
    //Query to fetch roles
   
    public static final String FIND_EDIT_THIRDPARTY_OLD_DETAILS = "select NAME_THIRD_PARTY,TRANSACTION_LIMIT from SBI_CUSTOMER_ACCOUNT_MAP where USER_NAME = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ? and account_nature = 1";

    public final static String USER_ROLE = "select user_role FROM BV_USER_ROLE WHERE user_id =?";
    //Profile Module End
    
//  added by krishna for sms
    public static final String FIND_USER_ALERT = "select * from BV_ALERT_SPEC where user_id in (select user_id from bv_user where user_alias=?)";
    
    public static final String USER_ID ="USER_ID";
    
    public static final String ALERT_NAME ="ALERT_NAME";
    
    public static final String ALERT_ID = "ALERT_ID";
    
    public static final String DLVY_TYPE ="DLVY_TYPE";
    
    public static final String STATUS="STATUS";
    
    public static final String JOB_ID="JOB_ID";
    
    public static final String CREATION_DATE="CREATION_DATE";
    
    public static final String MODIF_DATE="MODIF_DATE";
    
    public static final String NOTIF_DATE="NOTIF_DATE";
    
    public static final String NOTIF_FREQ="NOTIF_FREQ";
    
    public static final String STRINGCOL1="STRINGCOL1"; 
    
    public static final String STRINGCOL2="STRINGCOL2";   
    
    public static final String STRINGCOL3="STRINGCOL3";
    
    public static final String INTCOL1="INTCOL1";
    
    public static final String INTCOL2="INTCOL2";
    
    public static final String INTCOL3="INTCOL3";
    
    public static final String FLOATCOL1="FLOATCOL1";
    
    public static final String FLOATCOL2="FLOATCOL2";
    
    public static final String FLOATCOL3="FLOATCOL3";
    
    public static final String DATECOL1="DATECOL1";
    
    public static final String DATECOL2="DATECOL2";
    
    public static final String DATECOL3="DATECOL3";
    
    public static final String STRINGCOL4="STRINGCOL4";

    public static final String FIND_ALERT_SPEC = "select * from bv_alert_spec where user_id in (select user_id from bv_user where user_alias=?) and stringcol4=?";
    
    public static final String FIND_SMSALERT_OID = "select oid from BV_ALERTSCHED where job_name = ?";

    public static final String FIND_SMS_ALERTID = "select nvl((max(alert_id)+1),1) from BV_ALERT_SPEC where user_id=? and alert_name=?";

    public static final String DELTE_SMS_ALERT = "delete from BV_ALERT_SPEC where user_id in (select user_id from bv_user where user_alias=?) and alert_name=? and alert_id=? and stringcol4=?";

    public static final String INSERT_SMS_ALERT = "insert into bv_alert_spec fields( user_id,alert_name,alert_id,dlvy_type,status,job_id,notif_freq,stringcol1,stringcol2,stringcol3,stringcol4,floatcol1) values(?,?,?,?,?,?,?,?,?,?,?,?)";

    public static final String CUBAL_MESSAGE ="Alert me when credit balance in Account {0} in branch {1} becomes greater than {2}";

    public static final String CLBAL_MESSAGE = "Alert me when credit balance in Account {0} in branch {1} becomes less than {2}";

    public static final String DUBAL_MESSAGE = "Alert me when debit balance in Account {0} in branch {1} becomes greater than {2}";

    public static final String DLBAL_MESSAGE = "Alert me when debit balance in Account {0} in branch {1} becomes less than {2}";

    public static final String CIAL_MESSAGE = "Alert me when interest is credited to Account {0} in branch {1}";

    public static final String DIAL_MESSAGE = "Alert me when interest is debited from Account {0} in branch {1}";
 
    public static final String CRAL_MESSAGE = "Alert me when a credit transaction occurs in Account {0} in branch {1}";

    public static final String DRAL_MESSAGE = "Alert me when a debit transaction occurs in Account {0} in branch {1}";

    public static final String BP_MESSAGE = "Alert me when a bill is received";
    
    /****Customer Care Start*****/
    static final String FIND_ISSUES = "Select issue_code,issue_description from sbi_cs_issue_master where issue_code not in ('1','2','10') and status=1 order by to_number(issue_code)";

    static final String FIND_TICKETS_BY_USER_NAME = "(select sctm.oid,ticket_no,sctm.creation_time,sctm.status,scim.issue_code,claimant,cp_workflow_state,parameter1,parameter2,parameter3,parameter4,name,description,branch_code,username,date_closed,scim.issue_description from SBI_CS_TICKET_MASTER sctm,sbi_cs_issue_master scim where  username=? and sctm.issue_code not in ('1','2') and sctm.cp_workflow_state IN ({0}) and sctm.status=1 and sctm.issue_code = scim.issue_code) union all (select sctmh.oid, ticket_no,sctmh.creation_time,sctmh.status,sctmh.issue_code,claimant,cp_workflow_state,parameter1,parameter2,parameter3,parameter4,name,description,branch_code,username,date_closed,scim.issue_description  from sbi_Cs_ticket_master_history sctmh,sbi_cs_issue_master scim where username=? and sctmh.issue_code not in ('1','2') and cp_workflow_state IN ({0}) and sctmh.status=1 and sctmh.issue_code = scim.issue_code) order by creation_time desc";

    static final String UPDATE_TICKET_BY_WORKFLOW_STATE = "update sbi_cs_ticket_master set cp_workflow_state = ? where ticket_no = ? and username = ?";

    static final String UPDATE_FLAG = "update sbi_cs_ticket_master set read = ? where ticket_no=? and username=?";

    static final String TICKET_THREADS_BY_OID = "select * from sbi_cs_ticket_thread where oid = ?";

    static final String NON_VERIFIED_ACCOUNT_BY_USER_NAME = "select a.account_no,a.product_type, b.branch_name,b.branch_code from sbi_customer_account_map a, sbi_branch_master b, sbi_account_description c  where user_name=? and a.account_nature=0 and a.status=1 and a.branch_code=b.branch_code and substr(a.account_no,1,5)=micro_identifier(+) and b.status=1 and verify_flag=1 and lock_flag != 0";
    
    //06/01/06
    public static final String INSERT_TICKET = "PROC_INSERTTICKET";

    public static final String INSERT_TICKET_THREAD = "insert into sbi_cs_ticket_thread(oid,THREAD_DATE,THREAD_ORIGINATOR,THREAD) values(?,sysdate,?,?)";

    /****Customer Care End*****/
    /**********Mobile Payments*************/
    static final String UPDATE_USER_BILLER_MAP_MOBILE = "update sbi_bp_user_biller_map set DEBIT_ACCOUNT_NO=?,DEBIT_BRANCH_CODE=?,LAST_MOD_TIME=sysdate where username=? and biller_shortname=? and biller_id=?";

    static final String FIND_MOBILE_BILLERS = "SELECT a.serialno,a.biller_id,a.biller_shortname,a.reason,a.cust_reg_status, b.biller_friendly_name FROM sbi_bp_user_biller_map a, sbi_bp_biller_master b WHERE b.status = 1 AND a.status = 1AND a.biller_id = b.biller_id AND B.OID IN (SELECT OID FROM sbi_bp_biller_city_map WHERE UPPER (city_name) = UPPER ('MOBILE_PROVIDERS')) AND a.username = ? ORDER BY UPPER (b.biller_name) ASC";

    static final String FIND_ALERT_SPEC_BY_NAME = "select * from bv_alert_spec where user_id in (select user_id from bv_user where user_alias=?) and alert_name=?";
 
    static final String FIND_ALL_ACCOUNTS_COUNT = "select count(*) from SBI_CUSTOMER_ACCOUNT_MAP where user_name=? and account_nature=0 and status=1 order by verify_flag";
    static final String FIND_MAX_TP_LIMIT = "select nvl(max(TRANSACTION_LIMIT),0) TPlimit from  SBI_CUSTOMER_ACCOUNT_MAP A, SBI_BRANCH_MASTER B where ACCOUNT_NATURE=1 AND ACCOUNT_NO!='NONE' AND USER_NAME=? and A.STATUS=1 AND B.STATUS=1 AND A.BRANCH_CODE=B.BRANCH_CODE";
    
    // added by boopthi
    
    static final String BILLER_CREDIT_ACCOUNT_DETAILS = "select b.ACCOUNT_NO,b.BRANCH_CODE from sbi_bp_biller_master a ,sbi_biller_credit_accounts b where a.oid=b.oid and DECODE(SUBSTR(b.branch_code,0,1),'A','0','6','0','3','0',SUBSTR(b.branch_code,0,1))=? and biller_id=?"; //mod for SBS merger
    
    //Modified for Query tuning 
    //static final String FIND_BILLS_FOR_USER = "select  a.serialno, b.bill_number,b.biller_id, a.biller_shortname, c.biller_friendly_name, b.bill_date, b.bill_due_date, b.bill_amount, c.account_no, c.branch_code, c.presentment, c.partial_payment, c.excess_payment,b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info, c.payment_remarks, decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') allow_no, decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') allow_yes, sysdate thisdate, c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, a.autopay, a.cust_reg_status, a.reason from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c where a.username = ? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and b.biller_id=c.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and a.status=1 and b.status=1 and c.status=1 and b.scheduled <> 0 and (cust_reg_status ='Accepted' or cust_reg_status is null) and ( (trunc(decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'')) >= trunc(sysdate) and decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') is not null ) or (trunc(decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'')) >= trunc(sysdate) and decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') is not null) ) order by b.bill_due_date desc";

    static final String FIND_BILLS_FOR_USER = "SELECT  a.serialno, b.bill_number,b.biller_id, a.biller_shortname, c.biller_friendly_name, b.bill_date, b.bill_due_date, b.bill_amount, c.account_no, c.branch_code, c.presentment, c.partial_payment, c.excess_payment,b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info, c.payment_remarks, decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') allow_no, decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') allow_yes, sysdate thisdate, c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, a.autopay, a.cust_reg_status, a.reason from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c where a.username = ? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and b.biller_id=c.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and a.status=1 and b.status=1 and c.status=1 and b.scheduled <> 0 and (cust_reg_status ='Accepted' or cust_reg_status is null) and ( (trunc(decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'')) >= trunc(sysdate) and decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') is not null ) or (trunc(decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'')) >= trunc(sysdate) and decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') is not null) ) order by b.bill_due_date desc";

    static final String UPDATE_SCHEDULED_BILL = "update sbi_bp_bill_master set scheduled=? where bill_number = ? and biller_id = ?";

    static final String FIND_BILL_FOR_BILLERID_AND_NUMBER = "select * from sbi_bp_bill_master where bill_number = ? and biller_id = ?";

    static final String DELETE_EXPIRED_BILLS = "update sbi_bp_bill_master set deleted_by_user='0' where bill_number=?";

    static final String FIND_EXPIRED_BILLS = "select  a.serialno, b.bill_number,b.biller_id, a.biller_shortname, c.biller_friendly_name, b.bill_date, b.bill_due_date, b.bill_amount, c.account_no, c.branch_code, c.presentment, c.partial_payment, c.excess_payment,b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info, c.payment_remarks, decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') allow_no, decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') allow_yes, sysdate thisdate, c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, a.autopay, a.cust_reg_status, a.reason from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c where a.username = ? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and b.biller_id=c.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and a.status=1 and b.status=1 and c.status=1 and b.scheduled <> 0 and (cust_reg_status ='Accepted' or cust_reg_status is null) and deleted_by_user<>'0' and ( (trunc(decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'')) < trunc(sysdate) and decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') is not null ) or (trunc(decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'')) < trunc(sysdate) and decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') is not null) )";

    static final String BILLERDETAILS_FOR_BILLERID = "select * from  SBI_BP_BILLER_MASTER a, SBI_BILLER_CREDIT_ACCOUNTS b where status=1 and biller_id=? and parent_biller_id is null and a.oid=b.oid and DECODE(SUBSTR(b.branch_code,0,1),'A','0','6','0','3','0',SUBSTR(b.branch_code,0,1))=? order by upper(biller_friendly_name)";//mod for SBS merger
// Query changed by priya - order by included
    static final String BILLER_REGISTRATION_FOR_BILLERID = "select * from sbi_bp_biller_master a, sbi_bp_biller_params b where a.oid=b.oid and biller_id =? order by params_serialno";

    static final String FIND_BILLERS_FOR_USER = "select b.* from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where b.STATUS=1 and a.STATUS=1 and b.presentment='0' and b.biller_id not in('IITC-Hostel','IITC-Semester') and a.biller_id = b.biller_id and a.username =? order by Upper(b.biller_name) asc";

    static final String FIND_BILLER_NAME_AND_ID = "select a.biller_id, a.biller_friendly_name from SBI_BP_BILLER_MASTER a,SBI_BILLER_CREDIT_ACCOUNTS b  where status=1 and a.oid in (select oid from SBI_BP_BILLER_CITY_MAP where upper(CITY_NAME)=upper(?)) and PARENT_BILLER_ID is null and a.oid=b.oid and DECODE(SUBSTR(b.branch_code,0,1),'A','0','6','0','3','0',SUBSTR(b.branch_code,0,1))=? order by upper(BILLER_FRIENDLY_NAME)"; //mod for SBS merger

    static final String FIND_CHILD_BILLER = "select biller_id,BILLER_FRIENDLY_NAME from sbi_bp_biller_master where parent_biller_id=? and status=1 order by upper(BILLER_FRIENDLY_NAME)";

    static final String BILLERDETAILS_FOR_BILL = "select  c.oid, c.biller_category, c.city, c.biller_name, c.child, c.corp_flag, c.image,c.parent_biller_id, c.payment_without_bill, c.pincode, c.presentment, c.remarks, c.state,b.bill_number,b.biller_id, a.biller_shortname, c.biller_friendly_name, b.bill_date, b.bill_due_date, b.bill_amount, c.account_no, c.branch_code, c.presentment, c.partial_payment, c.excess_payment,b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info, c.payment_remarks, decode(c.allow_after_due_date,1,b.bill_due_date-c.days_before_due_date,'') allow_no, decode(c.allow_after_due_date,0,b.bill_due_date+c.bill_expiry_days,'') allow_yes, sysdate thisdate, c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, a.autopay, a.cust_reg_status, a.reason from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c where a.username = ? and a.biller_id = ? and bill_number = ? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and b.biller_id=c.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and a.status=1 and b.status=1 and c.status=1 and b.scheduled <> 0 and (cust_reg_status ='Accepted' or cust_reg_status is null) order by b.bill_due_date desc";
//   Query changed by priya - order by included
    static final String GET_BILLER_PARAMS_FOR_OID = "select * from sbi_bp_biller_params a where a.oid=? order by params_serialno ";
//   Query changed by priya - order by included
    static final String GET_PARAM_NAME_FOR_BILLERID = "select b.* from sbi_bp_biller_master a, sbi_bp_biller_params b where a.oid=b.oid and a.biller_id = ? and a.status=1 order by params_serialno";

    static final String FIND_BILL_PAYMENT_HISTORY_FOR_BILLNO_AND_ID = "select * from sbi_bp_bill_payment_history where bill_number =? and biller_id =? and username = ?";

//  Query change for CR 1251 -- Ambiguity in status display -- In Process has been decoded to success --By Basha
   //Modified for Query tuning
   // static final String FIND_BILL_PAYMENTS_FOR_USER = "select distinct a.CREATION_TIME, a.BILL_DATE, a.BILL_DUE_DATE, a.BILLER_ID, a.BILL_NUMBER, a.DEBIT_BRANCH_CODE, a.REMARKS, a.USERNAME, a.BILLER_SHORTNAME, BILLER_FRIENDLY_NAME, TRANSACTION_REFNO,AMOUNT, to_char(a.CREATION_TIME,'dd-mm-YYYY') paymentdate,decode(PAYMENT_STATUS,'In-Process','Success','In Process','Success','InProcess','Success',PAYMENT_STATUS)PAYMENT_STATUS,a.creation_time, THEIR_REFNO,a.DEBIT_ACCOUNT_NO from SBI_BP_BILL_PAYMENT_HISTORY a,sbi_bp_biller_master b,sbi_bp_user_biller_map c where a.biller_id =b.biller_id and b.biller_id = c.biller_id  and to_char(a.creation_time,'YYYY-mm-dd') >= (select to_char(sysdate,'yyyy')-1 || '-' || to_char(sysdate,'mm') || '-' || to_char(sysdate,'dd') sysdateminus12 from dual) and to_char(a.creation_time,'YYYY-mm-dd') <= to_char(sysdate,'YYYY-mm-dd')and a.status=1 and b.status=1 and a.username = ? and a.username = c.username and a.BILLER_SHORTNAME = c.BILLER_SHORTNAME order by a.biller_id ,a.BILLER_SHORTNAME, BILLER_FRIENDLY_NAME,a.creation_time desc";

    static final String FIND_BILL_PAYMENTS_FOR_USER = "select distinct a.CREATION_TIME, a.BILL_DATE, a.BILL_DUE_DATE, a.BILLER_ID, a.BILL_NUMBER,a.DEBIT_BRANCH_CODE, a.REMARKS, a.USERNAME, a.BILLER_SHORTNAME, BILLER_FRIENDLY_NAME,TRANSACTION_REFNO,AMOUNT, to_char(a.CREATION_TIME,'dd-mm-YYYY') paymentdate,decode(PAYMENT_STATUS,'In-Process','Success','In Process','Success','InProcess','Success',PAYMENT_STATUS)PAYMENT_STATUS,a.creation_time, THEIR_REFNO,a.DEBIT_ACCOUNT_NO from bvsbi.SBI_BP_BILL_PAYMENT_HISTORY a,bvsbi.sbi_bp_biller_master b,bvsbi.sbi_bp_user_biller_map c where a.biller_id =b.biller_id and b.biller_id = c.biller_id and trunc(a.creation_time) between trunc(add_months(sysdate, -12)) and trunc(sysdate) and a.status=1 and b.status=1 and a.username =? and a.username = c.username and a.BILLER_SHORTNAME = c.BILLER_SHORTNAME order by a.biller_id ,a.BILLER_SHORTNAME, BILLER_FRIENDLY_NAME,a.creation_time desc";
    

    static final String FIND_BP_HISTORY_DETAILS = "select * from SBI_BP_BILL_PAYMENT_HISTORY a, SBI_BP_BILLER_MASTER b, SBI_BP_USER_BILLER_MAP c where a.transaction_refno=? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and a.biller_shortname=c.biller_shortname and a.username=c.username";
    //mod for SBS merger
    static final String FIND_ALL_LOCATION = "SELECT DISTINCT (LOCATION) FROM sbi_all_branches WHERE DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = ?  AND status = 1 and location is not null ORDER BY LOCATION"; // Remove this string [or SUBSTR (branch_code, 0, 1) = '9'] by Murugan K 29th March 2006 
    
     
    //"select distinct(location) from sbi_branch_master where substr(branch_code,0,1) in ('0','9') and status=1 and bank_code = '0' order by location";
 
    static final String GET_ALL_CITIES = "select distinct(city_name) from SBI_BP_CITY_MASTER where status=1 and city_name is not null";

    static final String GET_CORE_SERVER_DATA = "select * from core_interface where txnno=? and type=? order by ?,position";
    
    // added for CR 5553
    static final String GET_SBI_CORE_SERVER_DATA = "select * from sbi_core_interface where txnno=? and type=? order by ?,position";

    static final String GET_MESSAGE_ID = "select cb_msg_id.NEXTVAL from dual";

    static final String LOAN_CLOSURE_UPDATE = "INSERT INTO sbi_ib_transactions FIELDS (OID, reference_no, store_id, creation_time, status, deleted, account_no, branch_code, amount, currency, narrative1, narrative2, narrative3, NAME, USER_NAME, LAST_MOD_TIME ) VALUES (oid_sequence.NEXTVAL, ?, 101, SYSDATE, 1, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE)";

    static final String FIND_SCHEDULED_BILLS = "(select  d.OID, d.bill_number,d.biller_id, a.biller_shortname, c.biller_friendly_name, sysdate bill_date, sysdate bill_due_date, 0 bill_amount, d.amount payment_amount, c.account_no, c.branch_code, d.scheduled_date, c.presentment, c.partial_payment, c.excess_payment, a.reference1, a.reference2, a.reference3, a.reference4, a.reference5, '' bill_reference_info, c.payment_remarks,  c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, d.debit_account_no, d.debit_branch_code, 'true' PFlag, d.remarks from sbi_bp_user_biller_map a,  sbi_bp_biller_master c, sbi_bp_payment_schedule d where a.username = ? and a.biller_id=d.biller_id and a.biller_id=c.biller_id and d.biller_id=c.biller_id and a.status=1 and d.status=1 and c.status=1 and a.username=d.username and d.bill_number like 'SCH-%' and d.biller_shortname=a.biller_shortname)union(select  d.OID, b.bill_number,b.biller_id, a.biller_shortname, c.biller_friendly_name, b.bill_date, b.bill_due_date, b.bill_amount, d.amount payment_amount, c.account_no, c.branch_code, d.scheduled_date, c.presentment, c.partial_payment, c.excess_payment,b.reference1, b.reference2, b.reference3, b.reference4, b.reference5, b.bill_reference_info, c.payment_remarks,  c.allow_after_due_date, c.days_before_due_date, c.bill_expiry_days, d.debit_account_no, d.debit_branch_code , 'false' PFlag, d.remarks from sbi_bp_user_biller_map a, sbi_bp_bill_master b, sbi_bp_biller_master c, sbi_bp_payment_schedule d where a.username = ? and a.biller_id=b.biller_id and a.biller_id=c.biller_id and b.biller_id=c.biller_id and ((a.reference1 = b.reference1) or (a.reference1 is null and  b.reference1 is null) ) and ((a.reference2 = b.reference2) or (a.reference2 is null and  b.reference2 is null) )  and ((a.reference3 = b.reference3) or (a.reference3 is null and  b.reference3 is null) ) and ((a.reference4 = b.reference4) or (a.reference4 is null and  b.reference4 is null) )  and ((a.reference5 = b.reference5) or (a.reference5 is null and  b.reference5 is null) ) and a.status=1 and b.status=1 and c.status=1 and b.scheduled = 0 and a.biller_id=d.biller_id and b.bill_number=d.bill_number and a.username=d.username)";

    static final String DELETE_SCHEDULED_PAYMENT = "delete from SBI_BP_PAYMENT_SCHEDULE where oid = ? and biller_id = ?";

    static final String INSERT_BP_PAYMENT_SCHEDULE = "insert into sbi_bp_payment_schedule (OID,BILLER_ID,STORE_ID,CREATION_TIME,STATUS,DELETED,LAST_MOD_TIME,BILL_NUMBER,REMARKS,BILLER_SHORTNAME,USERNAME,AMOUNT,DEBIT_ACCOUNT_NO,DEBIT_BRANCH_CODE,SCHEDULED_DATE)values(oid_sequence.nextval,?,101,sysdate, 1, 0, sysdate, ?,?,?,?,?,?,?,?)";

    static final String GET_SEQNO_FOR_WITHOUT_BILL = "select 'SCH-'||SBI_BP_SCHEDULE_NO.nextval from dual";

    static final String FIND_USER_BILLER_MAPS_FOR_USER = "select * from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where a.STATUS=1 and b.STATUS=1 and a.biller_id = b.biller_id and nvl(b.city,'null') not in('MOBILE PROVIDERS') and a.username = ? and a.bank_code = ? order by Upper(b.biller_friendly_name) asc";

    static final String FIND_USER_BILLER_FOR_USERNAME_AND_SERIALNO = "select * from sbi_bp_user_biller_map where username = ? and serialno = ? and bank_code = ?";

    static final String FIND_USER_BILLER_FOR_NAME = "select * from SBI_BP_USER_BILLER_MAP a ,SBI_BP_BILLER_MASTER b where a.STATUS=1 and b.STATUS=1 and a.biller_id = b.biller_id and a.username = ? order by Upper(b.biller_friendly_name) asc";

    static final String FIND_EDIT_BILLER_MAP = "SELECT  a.*, b.* FROM sbi_bp_user_biller_map a, sbi_bp_biller_master b WHERE b.status = 1 AND a.status = 1 AND b.presentment = '0' AND b.biller_id NOT IN ('IITC-Hostel', 'IITC-Semester') AND a.biller_id = b.biller_id AND a.username = ? AND bank_code = ? ORDER BY UPPER (b.biller_name) ASC";

    static final String FIND_USER_PARAMS = "select b.city,b.biller_id,b.biller_friendly_name,a.autopay,a.autopay_limit,a.bank_code,a.biller_shortname,a.serialno,a.cust_reg_status,a.debit_account_no,a.debit_branch_code,a.reason,a.reference1,a.reference2,a.reference3,a.reference4,a.reference5,a.username,a.serialno from sbi_bp_user_biller_map a, sbi_bp_biller_master b where a.USERNAME=? and a.BILLER_ID=? and a.BILLER_SHORTNAME=? and a.BANK_CODE=? and a.status=1 and a.biller_id=b.biller_id and b.status=1";

    static final String FIND_BILLERS ="SELECT  a.*, b.* FROM sbi_bp_user_biller_map a, sbi_bp_biller_master b WHERE b.status = 1 AND a.status = 1 AND b.presentment = ? AND b.biller_id NOT IN ('IITC-Hostel', 'IITC-Semester') AND a.biller_id = b.biller_id AND a.username = ? AND bank_code = ? AND (city is null or city <> 'MOBILE PROVIDERS') ORDER BY UPPER (b.biller_name) ASC";
    
    static final String FIND_WITHOUT_BILLS="SELECT  a.*, b.* FROM sbi_bp_user_biller_map a, sbi_bp_biller_master b WHERE b.status = 1 AND a.status = 1 AND (b.presentment = 1 or (b.presentment=0 and payment_without_bill=0)) AND b.biller_id NOT IN ('IITC-Hostel', 'IITC-Semester') AND a.biller_id = b.biller_id AND a.username = ? AND bank_code = ? AND (city is null or city <> 'MOBILE PROVIDERS') ORDER BY UPPER (b.biller_name) ASC";
   
    static final String LOCATORS_AGRICULTURAL_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and (category=15 or category=22 ) order by state";//mod for SBS merger

    static final String LOCATORS_NET_BANKING_BRANCH_CODES_ALL = "select BRANCH_CODE from sbi_branch_master where status=1  and upper(branch_name) not like '%TEST%' and DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = ?";//mod for SBS merger

    static final String LOCATORS_NET_BANKING_BRANCH_CODES = "select BRANCH_CODE from sbi_branch_master where status=1 and location=? and upper(branch_name) not like '%TEST%' and ((live=0 and LAST_UPDATED_DATE is not null ) or core_banking=0) and  DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1))= ? ";//mod for SBS merger

    static final String LOCATORS_NET_BANKING_BRANCH_DETAILS = "select branch_code,branch_name,location,address,pincode,phone1,phone2,email,fax ,state from sbi_all_branches where branch_code in ({0})";

    static final String LOCATORS_NET_BANKING_BRANCHES = "select distinct (location) from SBI_BRANCH_MASTER where ((live=0 and LAST_UPDATED_DATE is not null ) or core_banking=0) and status=1 and upper(location) not like '%TEST%' and  DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) =  ? order by upper(location)";//mod for SBS merger

    static final String LOCATORS_TELE_BANKING_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and tele_banking=0 order by state";//mod for SBS merger

    static final String LOCATORS_ATM_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and atm=0 order by state";//mod for SBS merger

    static final String LOCATORS_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0')";//mod for SBS merger

    static final String LOCATORS_COMMERCIAL_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and category=11 order by state";//mod for SBS merger

    static final String LOCATORS_FOR_EX_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and Forex='B' order by state";//mod for SBS merger

    static final String LOCATORS_INTERNET_BANKING_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and inb=0 order by state";//mod for SBS merger

    static final String LOCATORS_LOCATIONS = "Select distinct(upper(a.location)) location, b.area_required from SBI_ALL_BRANCHES a, SBI_CITY_MASTER b where a.status=1 and upper(a.state) = upper(?) and upper(b.state)= upper(?) and b.status=1 and b.main_center=0 and upper(a.location)=upper(b.city) and (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0')";//mod for SBS merger

    static final String LOCATORS_LOCATIONS_FOR_DISTRICT = "Select distinct(upper(district)) location from SBI_ALL_BRANCHES where status=1 and upper(state) = upper(?) and (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0')";//mod for SBS merger

    static final String LOCATORS_PBB_BRANCHES = "Select distinct(upper(state)) state from SBI_ALL_BRANCHES where (DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0') and status=1 and category=31 order by state";//mod for SBS merger

    static final String LOCATORS_BRANCH_DETAILS = "Select oid, branch_code, branch_name, address, location, pincode, phone1, phone2, fax, email, std_code,area ,nvl(atm,1) as atm,nvl(inb,1) as inb,nvl(tele_banking,1) as tele_banking, category,district, state, business_hours,nvl(sunday_banking ,1) as sunday_banking, sunday_hours, branch_manager, slo_code,circle_code from SBI_ALL_BRANCHES where status=1 and branch_code=?";

    static final String LOCATORS_LOCATION_DETAILS = "Select branch_code, branch_name, address, location, pincode, phone1, phone2,fax, email, a.state from SBI_ALL_BRANCHES a, SBI_CITY_MASTER b where a.status=1 and upper(a.state) = upper(?) and upper(location) = upper(?) and upper(b.state)= upper(?) and b.status=1 and b.main_center=0 and upper(a.location)=upper(b.city) and upper(a.state)=upper(b.state) and DECODE(SUBSTR(a.branch_code,0,1),'A','0','6','0','3','0',SUBSTR(a.branch_code,0,1)) = '0'";//mod for SBS merger

    static final String LOCATORS_LOCATION_DETAILS_FOR_DISTRICT = "Select  branch_code, branch_name, address, location, pincode, phone1, phone2,fax, email,  state from SBI_ALL_BRANCHES where status=1 and upper(state) = upper(?) and upper(district) = upper(?) and DECODE(SUBSTR(branch_code,0,1),'A','0','6','0','3','0',SUBSTR(branch_code,0,1)) = '0'";//mod for SBS merger

    static final String SECRET_KEY_GENERATOR = "select KEY from random_numbers where gno = ?";
    
    static final String PROFILE_LOGIN_PASSWORD_LOG= "insert into sbi_profile_changelog fields(user_name,ip_address,mod_time,mod_item) values(?,?,sysdate,?)";

     
    // added by krishna 
    
    static final String FIND_GE_USER_STATUS = "select status from sbi_ge_userdata where atm_card_no = ? and pin = ?";

    static final String UPDATE_GE_USER_STATUS ="update sbi_ge_userdata set status = 'registered' where atm_card_no = ? and pin = ?" ;
        
    // added by Velmurugan
    //static final String INSERT_LOGIN_TIME = "insert into sbi_user_login fields(user_name,login_time,ip_address,state) values(?,sysdate,?,?)";
    //Changed by Ramasamy for CR 951
    static final String INSERT_LOGIN_TIME = "insert into sbi_user_login fields(user_name,login_time,ip_address,state,session_id,login_status,engine_id) values(?,sysdate,?,?,?,?,?)";

    
    //IR71227
    final static String ACCOUNT_BY_NATURE_QUERY = "select A.ACCOUNT_NO,A.BRANCH_CODE,B.BRANCH_NAME,nvl(A.NAME_THIRD_PARTY,'') ACCOUNT_NICKNAME,nvl(A.ACCESS_LEVEL,0)ACCESS_LEVEL ,B.CORE_BANKING COREFLAG,'INR' CURRENCY,TRANSACTION_LIMIT CLEAR_BALANCE, product_type ACCOUNTTYPE , product_desc,product_code,CORE_MESSAGE_STATUS,-1 limit,'' RTGS_IFSC_CODE ,'' NEFT_IFSC_CODE,'' BROKER_STMT_FLAG from SBI_CUSTOMER_ACCOUNT_MAP A, SBI_BRANCH_MASTER B where A.ACCOUNT_NATURE=? AND A.ACCOUNT_NO=? AND A.BRANCH_CODE=?  AND USER_NAME=? and A.STATUS=1 AND B.STATUS=1 AND A.BRANCH_CODE=B.BRANCH_CODE";
    
    static final String GET_BM_ACCOUNTS = "select bm_account_no,bm_branch_code,b.user_name,b.product_type,c.clear_balance,c.account_description,c.branch_name from sbi_cb_bm_legacy_map a, sbi_customer_account_map b,sbi_all_master c where b.account_no = ? and b.branch_code = ? and cr_account_no = b.account_no and cr_branch_code = b.branch_code and b.user_name = ? and a.creation_time > ? and a.bm_account_no = c.account_no and a.bm_branch_code = c.branch_code"; //Added for CR 295
 
    // CR - 150 by Murugan
    static final String UPDATE_CORE_MESSAGE ="update sbi_customer_account_map set CORE_MESSAGE_STATUS='Noted' where USER_NAME = ? AND BRANCH_CODE in(#tobereplaced#)";
    
    //  CR-951 by Ramasamy RM
    public static final String FIND_FAILIRE_ATTEMPTS = "select count(*) as count from bv_user_profile where user_id in (select user_id from bv_user where user_alias=?) and lock_time+1 >= sysdate";

    //  CR - 1267 by Ponnusamy CR - 1267
    public static final String SQL_E_PAYORDER_TRANSACTIONS = "select param,value from sbicorp_echeque_supplier_param sesp,sbicorp_echeque_master sem where sem.echeque_no=? and sem.oid = sesp.oid";
    
    //added by Ponnusamy G
    public static final String SELECT_PRODUCT_DETAILS="select product_desc from sbi_product_desc where PRODUCT_CODE= ?";
    
      public static final String TRANSACTION_DATE_QUERY = " select to_date(transaction_date,'dd-mon-yy') transaction_date from sbi_txn_history where TTYPE_CODE in ('90','40','41') and account_no=? and branch_code=? and transaction_date is not null order by transaction_date desc";

    public static final String TXN_HISTORY_COUNT_QUERY="Select ACCOUNT_NO,BRANCH_CODE,TRANSACTION_COUNT,REFERENCE_NO,AMOUNT,CURRENCY,TTYPE_CODE,NARRATIVE1, NARRATIVE2,NARRATIVE3,to_date(DATE_VALUE),BALANCE,to_date(TRANSACTION_DATE) transaction_date,status from sbi_txn_history where account_no=? and branch_code=? and transaction_count=?";

    public final static String TXN_FIRST_RECORD = "select ACCOUNT_NO,BRANCH_CODE,TRANSACTION_COUNT,REFERENCE_NO,AMOUNT,CURRENCY,TTYPE_CODE,NARRATIVE1, NARRATIVE2,NARRATIVE3,to_date(DATE_VALUE),BALANCE,to_date(TRANSACTION_DATE) transaction_date,status from sbi_txn_history where    account_no=? and branch_code=? and amount=(select min(amount) from sbi_txn_history where account_no=? and  branch_code=? and ttype_code!='90')";
    
    //   Added by Sunjay S Galen
    
    static final String CORPORATE_DEL_FILE="SELECT   * FROM bvsbi.sbi_file_master t WHERE file_status = 'Processed'  AND UPPER (additional_field5) = 'D3P' AND EXISTS (SELECT 1 FROM bvsbi.bv_user a, bvsbi.bv_user_profile b WHERE a.user_id = b.user_id AND b.created_by_branch = ? AND a.user_alias = t.username)"+
    " AND sno IN (SELECT DISTINCT (SUBSTR (file_name,1,(INSTR (file_name, '.')) - 1)) FROM bvsbi.sbi_delete_third_party dt WHERE upper(status) in ('UNAPPROVED')and dt.file_name = substr(t.file_name,6,(INSTR (t.file_name, '.'))-1)) AND TRUNC (creation_time) BETWEEN TO_DATE (?, 'dd/mm/yyyy') AND TO_DATE (?, 'dd/mm/yyyy')ORDER BY t.sno DESC";
    
    static final String CORPORATE_DEL_FILE_APPR="SELECT  a.* FROM bvsbi.sbi_file_master a,bv_user_profile c,bv_user b WHERE a.file_status = 'Processed'  and upper(a.additional_field5)='D3P'"+
  " AND a.username = b.user_alias AND c.user_id = b.user_id AND ( EXISTS (SELECT 1 FROM bv_user_profile n, bv_user m WHERE m.user_alias =? AND m.user_id = n.user_id"+ 
 " AND n.created_by_branch = c.created_by_branch) OR EXISTS (SELECT 1 FROM sbicorp_ca_user_map WHERE user_name = ? AND ca_user = c.created_by_branch))"+
 " AND a.sno IN (SELECT DISTINCT (SUBSTR (file_name,1,(INSTR (file_name, '.')) - 1)) FROM bvsbi.sbi_delete_third_party dt WHERE upper(status) in ('UNAPPROVED')"+ 
 " and dt.file_name = substr(a.file_name,6,(INSTR (a.file_name, '.'))-1))  AND TRUNC (a.creation_time) BETWEEN TO_DATE (?, 'dd/mm/yyyy') AND TO_DATE (?, 'dd/mm/yyyy')ORDER BY a.sno DESC";

    static final String CORPORATE_DEL_FILE_VIEW=" select * from sbi_file_master f where exists (select 1 from bv_user a, bv_user_profile b  where a.user_id=b.user_id and b.created_by_branch=? and a.user_alias = f.username) and file_status='Processed' and ADDITIONAL_FIELD5 ='D3P'" +
    " and trunc(creation_time) between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') order by sno desc";
    
    static final String CORPORATE_DEL_FILE_VIEW_APPR="select a.* from sbi_file_master a,bvsbi.bv_user b,bvsbi.bv_user_profile c where a.file_status='Processed' and upper(a.additional_field5) ='D3P' "+
" AND a.username = b.user_alias AND c.user_id = b.user_id  AND ( EXISTS (SELECT 1 FROM bv_user_profile n, bv_user m "+
" WHERE m.user_alias =? AND m.user_id = n.user_id  AND n.created_by_branch = c.created_by_branch) OR EXISTS "+
 "(SELECT 1 FROM sbicorp_ca_user_map WHERE user_name = ?   AND ca_user = c.created_by_branch)) "+
" and trunc(a.creation_time) between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') order by a.sno desc";
    
    static final String FIND_DEL_TP_BY_FILE ="select * from sbi_delete_third_party c where  upper(c.status)='UNAPPROVED' and FILE_NAME LIKE ? order by c.benificiary_name";
    
    static final String FIND_DEL_TP_BY_FILE_STATUS ="select * from sbi_delete_third_party c where FILE_NAME LIKE ? and row_id in #tobereplaced# order by c.benificiary_name ";
    
    static final String FIND_DEL_TP_BY_FILE_VIEW ="select * from sbi_delete_third_party c where  FILE_NAME LIKE ?  order by c.benificiary_name ";
    
    public static final String UPDATE_DEL_TP_STATE_APPROVED = "Update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where row_id in ?";
    
    //Added For CR 5110
    
static final String UPDATE_USER_LOCK = "update bv_user_profile set layout_pref= nvl(layout_pref,0) + 1 ,lock_time = sysdate where user_id  in (select user_id from bv_user where user_alias=?)";
    
    static final String UPDATE_USER_UNLOCK = "update bv_user_profile set layout_pref= 0 where user_id  in (select user_id from bv_user where user_alias=?)";
  //Added For CR 5287 starts
    public static final String GET_DPIDS="select DEMAT_ID,channel from SBI_DMAT_CUST_ACCT_MAP WHERE USER_NAME=? and status=1 ORDER BY DEMAT_ID ";
    //Added For CR 5287 Ends
  //Added For CR 5390 starts
    //Commented for  beneficiary revamp changes with starts
  //  public static final String GET_APPROVE_TP="SELECT  a.oid,a.account_no,a.branch_code,a.name_third_party,a.added_by,a.product_code,a.product_desc,a.creation_time,a.remarks,a.approval_status,a.mobile_no,a.email_id,a.outref7 FROM   bvsbi.sbicorp_third_party a, bvsbi.sbicorp_ca_user_map b WHERE a.added_by = b.user_name AND a.approval_status = 'Pending' AND a.user_name IS NULL AND corporate_id =?  AND ca_user =?  ORDER BY a.creation_time DESC";
    public static final String GET_APPROVE_TP="SELECT  a.oid,a.account_no,a.branch_code,a.name_third_party,a.added_by,a.product_code,a.product_desc,a.creation_time,a.remarks,a.approval_status,a.mobile_no,a.email_id,a.outref7,(select c.branch_name  from SBI_BRANCH_MASTER c  where a.branch_code =c.branch_code and rownum <2)branch_name FROM   bvsbi.sbicorp_third_party a, bvsbi.sbicorp_ca_user_map b WHERE a.added_by = b.user_name AND a.approval_status = 'Pending' and a.status = '1' AND a.user_name IS NULL AND corporate_id =?  AND ca_user =? ORDER BY a.creation_time DESC";
    //Commented for  beneficiary revamp changes with ends
    //Commented for  beneficiary revamp changes with starts
  //  public static final String GET_APPROVE_RTGS="select A.id,A.account_number,A.ifsc_code_receiver,A.branch_receiver,A.bank_receiver,A.user_name,A.rejected_reason,A.registration_time,A.third_party_name,A.status,A.phone_no,email_id,emp_code from bvsbi.sbi_rtgs_beneficiary A,bvsbi.sbicorp_ca_user_map B where  A.user_name = B.user_name AND A.corporate_id=? and A.status='Pending' and A.file_sno is null AND ca_user=? ORDER BY A.registration_time DESC";    // modified by krishna for cr    
    public static final String GET_APPROVE_RTGS="select A.id,A.account_number,A.ifsc_code_receiver,A.branch_receiver,A.bank_receiver,A.user_name,A.rejected_reason,A.registration_time,A.third_party_name,A.status,A.phone_no,email_id,emp_code,BRANCH_RECEIVER branch_name from bvsbi.sbi_rtgs_beneficiary A,bvsbi.sbicorp_ca_user_map B where  A.user_name = B.user_name AND A.corporate_id=? and A.status='Pending' and A.file_sno is null AND ca_user=? ORDER BY A.registration_time DESC"; 
    //Commented for  beneficiary revamp changes with ends
    // Added for CR 5603(columns a.mobile_no,a.email_id,a.outref7,A.phone_no,email_id,emp_code in GET_APPROVE_TP,GET_APPROVE_RTGS respectively)
//    public static final String APPROVE_TP_BENEFICIARY="update bvsbi.sbicorp_third_party set approval_status=?, user_name=? ,remarks=? where oid in(#tobereplace#) and CORPORATE_ID = ?";	/* Ramanan M - Corp Admin Paladion Security Changes */
    
    public static final String APPROVE_TP_BENEFICIARY="update bvsbi.sbicorp_third_party set approval_status=?, user_name=? ,remarks=?,last_mod_time=sysdate where oid in(#tobereplace#) and CORPORATE_ID = ? and status = '1'";	/*  changed for Beneficiary Revamp form based  */

//    public static final String REJECT_TP_BENEFICIARY="update bvsbi.sbicorp_third_party set approval_status=?, user_name=? ,remarks=?,status=2 where oid in(#tobereplace#) and CORPORATE_ID = ?";	/* Ramanan M - Corp Admin Paladion Security Changes */
    
    public static final String REJECT_TP_BENEFICIARY="update bvsbi.sbicorp_third_party set approval_status=?, user_name=? ,remarks=?,status=2,last_mod_time=sysdate where oid in(#tobereplace#) and CORPORATE_ID = ? and status = '1' ";	  /*  changed for Beneficiary Revamp form based  */

 //   public static final String APPROVE_RTGS_BENEFICIARY="update bvsbi.sbi_rtgs_beneficiary set status=?, approved_by=? ,rejected_reason=? where id in(#tobereplace#) and CORPORATE_ID = ?";	/* Ramanan M - Corp Admin Paladion Security Changes */
    
    public static final String APPROVE_RTGS_BENEFICIARY="update bvsbi.sbi_rtgs_beneficiary set status=?, approved_by=? ,rejected_reason=?,LAST_MODIFIED_TIME=sysdate where id in(#tobereplace#) and CORPORATE_ID = ? and status = 'Pending'";	/*  changed for Beneficiary Revamp form based  */

    
    /* Ramanan M - Corp Admin Paladion Security Changes */
   // public static final String GET_TP_BENEFICIARY_BY_OID="select a.oid,a.account_no,a.branch_code,a.name_third_party,a.added_by,a.product_code,a.product_desc,a.creation_time,a.remarks,a.approval_status,a.mobile_no,a.email_id,a.outref7 from bvsbi.sbicorp_third_party a where a.oid in (#tobereplace#) and CORPORATE_ID = ? ";
    /* Ramanan M - Corp Admin Paladion Security Changes */
    // changes happen for  beneficairy revamp with starts 
    public static final String GET_TP_BENEFICIARY_BY_OID="select a.oid,a.account_no,a.branch_code,a.name_third_party,a.added_by,a.product_code,a.product_desc,a.creation_time,a.remarks,a.approval_status,a.outref7,(select c.branch_name  from SBI_BRANCH_MASTER c  where a.branch_code =c.branch_code and rownum <2)branch_name from bvsbi.sbicorp_third_party a where a.oid in (#tobereplace#) and CORPORATE_ID = ? ";
    // changes happen for download beneficairy revamp with ends 
    //Commented for  beneficiary revamp changes with starts
  //  public static final String GET_RTGS_BENEFICIARY_BY_OID="select * from bvsbi.sbi_rtgs_beneficiary where id in (#tobereplace#) and CORPORATE_ID = ? ";
    //Commented for  beneficiary revamp changes with ends
    // changes happen for  beneficairy revamp with starts 
    public static final String GET_RTGS_BENEFICIARY_BY_OID="select srb.*,(select sbm.branch_name  from SBI_BRANCH_MASTER sbm  where srb.sender_branch_code =sbm.branch_code and rownum <2) branch_name from bvsbi.sbi_rtgs_beneficiary srb where id in (#tobereplace#) and CORPORATE_ID = ? ";
    // changes happen for  beneficairy revamp with ends 
    public static final String GET_TP_ALREADYADDED_OIDS="select a.oid from bvsbi.sbicorp_third_party a, bvsbi.sbicorp_third_party b where a.oid in (#tobereplace#)  and a.account_no= b.account_no and  b.added_by is null and b.status=1 and ( b.user_name=? or (a.corporate_id = b.corporate_id and EXISTS(select 1 from bvsbi.bv_user c,bvsbi.bv_user_role d where c.user_alias=b.user_name and d.user_id=c.user_id and d.user_role=10)))";
    public static final String GET_RTGS_ALREADYADDED_OIDS="select a.id from bvsbi.sbi_rtgs_beneficiary a, bvsbi.sbi_rtgs_beneficiary b where a.id in (#tobereplace#) and a.account_number= b.account_number and a.ifsc_code_receiver= b.ifsc_code_receiver and b.status='active' and(b.user_name=? or (a.corporate_id = b.corporate_id and b.user_role=10))";
    //Added For CR 5390 Ends
    //Added For CR 5472 Starts
    static final String GET_PROFILE_DETAILS_USERNAME = "SELECT b.user_alias,c.NAME, c.address, c.city, c.district, c.department, c.zip, c.state,c.employee_no, c.friendly_name, c.designation, c.email, c.home_phone,c.country, c.user_id,d.user_type,d.ddebit_access_rights,c.branch_code,c.mobile_no FROM bv_user b, bv_user_profile c,sbicorp_ca_user_map d WHERE b.user_alias = d.user_name and d.user_name=? AND d.ca_user=? AND b.user_state = 0 AND b.user_id = c.user_id"; 
    static final String GET_USER_DETAILS_FLAG_NULL = "SELECT   NAME, user_alias FROM sbicorp_ca_user_map a, bv_user b, bv_user_role c, bv_user_profile d WHERE b.user_id = d.user_id AND ca_user = ? AND a.user_name = b.user_alias AND b.user_id = c.user_id AND c.user_role = ? AND a.status = 1 AND b.user_state = 0 and a.USER_TYPE != 'ddebituser' ORDER BY UPPER (NAME)";
    public final static String  UPDATE_USER_PROFILE =   "update  bv_user_profile  set NAME=?,ADDRESS =?,"+
                                                             "CITY =?,DISTRICT =?,ZIP=?,STATE =? ,COUNTRY =?,"+
                                                             "EMAIL =?,HOME_PHONE =?,FRIENDLY_NAME =?, DESIGNATION =?,"+
                                                             "DEPARTMENT =?,EMPLOYEE_NO =?,BRANCH_CODE =?, "+
                                                             "BANK_CODE =? ,CORPORATE_ID =?  where USER_id =? and corporate_id = ?";//shanta
    public static final String FIND_ENQUIRER_NAMES = "select c.name,a.user_alias from bv_user a,bv_user_role b,bv_user_profile c,sbicorp_ca_corporate_map t where a.user_id=b.user_id and a.user_id=c.user_id and b.user_role=? and a.user_alias=t.ca_user and t.status=1 and t.corporate_id=? and a.user_state=0 order by upper(c.name)";
    //Id-396
    //Added For CR 5472 Ends
    //Added For CR 5531 Starts
    public static final String PAGINATION_TEMPLATE_QRY="select *   from  ( select rownum rnum, a.*   from (#replaceQuery#)a where  rownum <=? ) where rnum > ?";
    //Added For CR 5531 Ends
    
    //Added for corporate customer care -Starts
    
    //public static final String FIND_CORP_ISSUES = "select issue_code,issue_description from sbicorp_cs_issue_master where issue_code in (select issue_code from sbicorp_cs_issue_role_map where user_type=? and bank_code=? and  user_role=?) and status='Active'  order by Issue_code";
    public static final String FIND_CORP_ISSUES = "select a.issue_code,a.issue_description from sbicorp_cs_issue_master a ,sbicorp_cs_issue_role_map b where a.issue_code = b.issue_code and b.user_type=? and b.bank_code= ? and  b.user_role=? and a.status='Active'  order by b.display_order";
    public static final String INSERT_CORP_TICKET_MASTER="INSERT INTO sbicorp_cs_ticket_master (TICKET_NO,ISSUE_CODE,USERNAME,NAME,PARAMETER1,"+
    													 "PARAMETER2,PARAMETER3,PARAMETER4,CLAIMANT,DESCRIPTION,CP_WORKFLOW_STATE,READ,BRANCH_CODE," +
    													 "BANK_CODE,RAISED_BY,LABEL_ID,CREATION_TIME,LAST_MOD_TIME)"+
    													 "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,sysdate)";

    public static final String INSERT_CORP_TICKET_THREAD="Insert into sbicorp_cs_ticket_thread (TICKET_NO,THREAD_DATE,THREAD_ORIGINATOR,THREAD) values (?,sysdate,?,?)";
    
    public static final String FIND_TICKETS = "select ticket_no,name,username, description,creation_time,cp_workflow_state,read from sbicorp_cs_ticket_master where username=? and cp_workflow_state!=110 ORDER BY creation_time DESC";
    
    public static final String FIND_CLOSED_TICKETS = "select ticket_no,name,username, description,creation_time,cp_workflow_state,read from sbicorp_cs_ticket_master where username=? and cp_workflow_state=110 ORDER BY creation_time DESC";

  //modified for  corpuser paladion 
    public static final String FIND_TICKET_THREADS = "select a.ticket_no, a.thread_originator, a.thread, a.thread_date from sbicorp_cs_ticket_thread a, sbicorp_cs_ticket_master b where a.ticket_no = b.ticket_no and a.ticket_no = ?  and b.username = ? ORDER BY thread_date";
    
    public static final String UPDATE_TICKET_MASTER="update sbicorp_cs_ticket_master set  cp_workflow_state=?,last_mod_time=sysdate #tobereplaced#  where ticket_no=? and username=?";
    
    public static final String DELETE_TICKET_MASTER = "delete from sbicorp_cs_ticket_master where ticket_no in (#tobereplaced#)";
    
    public static final String DELETE_TICKET_THREAD = "delete from sbicorp_cs_ticket_thread where ticket_no in (#tobereplaced#)";
    
    public static final String UPDATE_TICKET_UNREAD = "update sbicorp_cs_ticket_master set  READ=0 where ticket_no in (#tobereplaced#)";
    
    //Added for corporate customer care -Ends
    
    /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
    public static final String NRE_PRODUCT_CODE_QUERY = "select product_code as key, product_code as value from sbi_product_desc where account_type='NRE' order by product_code";
    
    public static final String INSERT_SBICORPUSER_MOBILE_NO_PPKIT ="INSERT INTO SBICORP_USER_MOBILE_NO(USER_ID,OLD_MOBILE_NO,NEW_MOBILE_NO,STATUS,CREATION_TIME,LAST_MOD_TIME,REFERENCE_NO,BRANCH_CODE,USER_ROLE,CORPORATE_ID,CREATED_BY, FRIENDLY_NAME,USER_CREATION_TYPE) values (?,?,?,'Pending', sysdate, sysdate,?,?,?,?,?,?,?)";
    
    
    public static final String INSERT_SBICORPUSER_MOBILE_NO ="INSERT INTO SBICORP_USER_MOBILE_NO(USER_ID,OLD_MOBILE_NO,NEW_MOBILE_NO,STATUS,CREATION_TIME,LAST_MOD_TIME,REFERENCE_NO,BRANCH_CODE,USER_ROLE,CORPORATE_ID,CREATED_BY, FRIENDLY_NAME,SMS_SECURITY_TYPE) values (?,?,?,'Pending', sysdate, sysdate,?,?,?,?,?,?,?)";
    
    //Added for reset of transaction password
    static final String INSERT_SBI_PASSWORD_COUNT =  "insert into sbi_password_count (oid,reference_no,store_id,creation_time,status,deleted,last_mod_time,user_name,password_requested_date,branch_code,password_type) values (oid_sequence.nextval,?,101,sysdate,1,1,sysdate,?,sysdate,?,?)";
    
    //Added for lock user access 
    public static final String lockAccountConfirmCount="select count(1) from bv_user a,bv_user_profile b,sbi_customer_account_map c  where a.user_alias = c.user_name  and a.user_id = b.user_id  and c.account_nature = 0 and a.user_state = 0  and c.status = 1  and b.user_type = 0 and a.user_alias = ?  and  c.account_no =LPAD (?, 17, '0')  and b.mobile_no =? and b.bank_code =? and not exists(select 1 from sbi_user_lock_account d where d.user_name =a.user_alias and locked_status ='Y')";
//Merchant Limit Changes - Start
    public static final String FIND_TODAY_CATEGORY_RETAILUSR_TXN_AMOUNT_QUERY=" SELECT NVL (SUM (amount), 0) + ?  FROM (SELECT  NVL (echeque_amount, 0) amount " +
    		"FROM sbicorp_echeque_master a WHERE a.maker = ?  AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) " +
    		"OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) " +
    		"OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND SUBSTR(a.echeque_no,0,2) in ('IT','IR','IZ','IV','IG','IH') AND a.MERCHANT_CODE not in ('SSL_SBH','SSL','SSL_NRI','NOW','NPS','BMRCL','SBILIFE_INB'))";
    public static final String FIND_TODAY_IGCATEGORY_RETAILUSR_TXN_AMOUNT_QUERY=" SELECT NVL (SUM (amount), 0) + ?  FROM (SELECT  NVL (echeque_amount, 0) amount " +
	"FROM vw_sbicorp_echeque_master a WHERE a.maker = ?  AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) " +
	"OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) " +
	"OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND SUBSTR(a.echeque_no,0,2) in ('IG') AND a.MERCHANT_CODE not in ('SSL_SBH','SSL','SSL_NRI','NOW','NPS','BMRCL','SBILIFE_INB'))";

    public static final String FIND_TODAY_CATEGORY_SARALUSR_TXN_AMOUNT_QUERY=" SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT  NVL (echeque_amount, 0) amount  FROM VW_SBICORP_ECHEQUE_MASTER a WHERE a.maker = ?  AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy')AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND SUBSTR(a.echeque_no,0,2) in ('CT','CR','CN','CZ','CH') AND a.MERCHANT_CODE not in ('SSL_SBH','SSL','SSL_NRI','NOW','NPS','BMRCL','SBILIFE_INB'))";
    
    //public static final String FIND_TODAY_CATEGORY_SARALUSR_TXN_AMOUNT_QUERY="  SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0) amount FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN  ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50'  AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) = 'CK')))";
    public static final String FIND_TODAY_CATEGORY_GOVT_RTL_TXN_AMOUNT_QUERY="  SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0) amount  FROM VW_SBICORP_ECHEQUE_MASTER a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN  ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50'  AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) = 'IK')) AND a.merchant_code not in ('OLTAS','CBEC','ICEGATE','ICEGATE_NEW'))";
    
    public static final String FIND_TODAY_CATEGORY_GOVT_SARAL_TXN_AMOUNT_QUERY=" SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT  NVL (echeque_amount, 0) amount FROM VW_SBICORP_ECHEQUE_MASTER a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) in ('CF','CK') ) ) and a.MERCHANT_CODE not in ('OLTAS','CBEC','ICEGATE','ICEGATE_NEW'))";
    public static final String FIND_TODAY_INDEPENDENT_TXN_AMOUNT_QUERY="SELECT NVL (SUM (amount), 0) + ?   FROM (  SELECT  NVL (echeque_amount, 0) amount  FROM VW_SBICORP_ECHEQUE_MASTER a WHERE  a.maker = ? "+
	" AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) "+
	" OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.'))"+ 
	" OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy')))"+ 
	" and trim(a.MERCHANT_CODE) = ?) ";
    
    //Added for Voice OTP
    public final static String FIND_VOICE_OTP_MOBILE_SERIES = "select STARTS_WITH as key, STARTS_WITH as value from sbi_mobile_series_master";
      
    
    //Merchant Limit Changes - Ends
    
    //Added for E-suvidha
    
	public final static String FIND_DEBITS_WITH_RANGE_ALL = "select 'D' type, '' remarks, reason_failure status_description, 'INR' currency, reference_no, account_no, branch_code, status_code, third_party_ref, amount, user_name, merchant_code,creation_time,'' RATE_OF_INTEREST,'' narrative2 from sbi_ib_status_view where user_name=? and status=1 and trunc(creation_time) >=to_date(?,'DD/MON/YYYY') and trunc(creation_time) <=to_date(?,'DD/MON/YYYY') and MERCHANT_CODE<>'VISA' order by creation_time desc";//added for cr-2975 by raja
	public final static String FIND_DEBITS_WITH_RANGE_VISA = "select 'D' type, '' remarks, status_description, 'INR' currency, echeque_no reference_no, account_no, branch_code, debit_status status_code, third_party_ref, echeque_amount amount, maker user_name, merchant_code,creation_time,'' RATE_OF_INTEREST,'' narrative2 from (SELECT * FROM sbicorp_echeque_master_view WHERE maker = ? and trunc(creation_time) >=to_date(?,'DD/MON/YYYY') and trunc(creation_time) <=to_date(?,'DD/MON/YYYY') and debit_status is not null and merchant_code='VISA' AND SUBSTR (echeque_no, 1, 2) IN ('IV') ORDER BY creation_time DESC ) a ";//added for cr-2975 by raja
	public static final String FIND_TODAY_CATEGORY_C_AMOUNT_QUERY="SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0) amount FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) = 'CU')))";
	 public static final String FIND_TODAY_CATEGORY_B_AMOUNT_QUERY="SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT   NVL (echeque_amount, 0)+ NVL (fn_get_bp_amount (?), 0) amount FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') )  OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy'))) AND ((SUBSTR (a.echeque_no, 0, 2) in ( 'CB' ,'CD') ) ) and a.merchant_code not in ('FOR'))";
	//Added for eTDR/eSTDR -Start
    public static final String FIND_TODAY_CATEGORY_G_AMOUNT_QUERY=" SELECT NVL (SUM (amount), 0) + ?   FROM (SELECT  NVL (echeque_amount, 0) amount "+
	" FROM sbicorp_echeque_master a WHERE a.maker = ? AND ((TRUNC (a.creation_time) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.') ) "+
	" OR (a.current_auth_level = '0' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy') AND a.debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')) "+
	" OR (a.current_auth_level = '50' AND TRUNC (a.scheduled_date) = TO_DATE (TO_CHAR (?, 'dd/mm/yyyy'), 'dd/mm/yyyy')))"+ 
	" AND ((SUBSTR (a.echeque_no, 0, 2) in ('IW')) OR (SUBSTR (a.echeque_no, 0, 2) in ('II') AND EXISTS (SELECT 1 FROM SBI_IB_CREDITS B WHERE B.debit_reference_no = A.ECHEQUE_NO "+
	" AND B.original_debit_branch = b.BRANCH_CODE AND B.credit_reference_no like '%01')))) ";
    
    static final String FIND_MASKED_ACCOUNTS_COUNT = "select count(*) from sbi_customer_account_map where status=1 and account_no=? and branch_code=? and user_name=? and access_level=4";
    public final static String FIND_TODAYS_FD_AMOUNT_QUERY = "SELECT NVL (SUM (echeque_amount)+?, 0) FROM sbicorp_echeque_master WHERE maker = ? AND TRUNC (creation_time) = TRUNC (SYSDATE) AND echeque_no LIKE 'IW%' AND debit_status IN ('00', '08', 'LOG.', 'F1', '56', 'REP.')";
	//Added for eTDR/eSTDR -End

   public static final String CONTEXTUAL_MESSAGE= "select user_name, transaction_rights, etdr_stdr, mobile_onlinesbi, visa_ben, demat_account, retail_bill_pay, "+
	                          "retail_tax_pay, virtual_card, gift_card, high_security, demand_draft, retail_payment_transfer,FLEXI_ERD,corp_bill_pay, corp_tax_pay, corp_payment_transfer, corp_epf,column_priority "+
	                          " from SBI_CONTEXTUAL_MSG_DTLS where user_name=?";
//Added for beneficiary revamp
   
   static final String COUNT_TP_SHARED = "select count(*) from sbicorp_third_party where  account_no = ?  and corporate_id =?  and status in (0,1)  and nvl(outref7,' ') = ? and nvl(PRODUCT_CODE_STATUS,0)  != 'ERR.'  ";

   static final String COUNT_TP_NOTSHARED = "select count(*) from sbicorp_third_party t where t.account_no = ? and t.corporate_id = ?  and t.status in (0,1)  and  nvl(t.outref7,' ') = ? and nvl(t.PRODUCT_CODE_STATUS,0)  != 'ERR.' "+
							" and ((t.user_name in (select a.user_alias from bv_user a,bv_user_role b where a.user_id = b.user_id  and a.user_state = '0' and (t.user_name=a.user_alias and b.user_role='10') or (t.user_name=? and t.user_name=a.user_alias and b.user_role='7'))) "+
							" or t.user_name in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='42' and b.user_state = '0' and a.ca_user= ?) "+
							" or (t.uploader_username in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='21' and b.user_state = '0' and a.ca_user in (?,(select a.user_alias from bv_user a, bv_user_role b, bv_user_profile c where a.user_id = b.user_id and b.user_id = c.user_id and b.user_role='10' and c.corporate_id = ? and a.user_state = '0'))) and  user_name is null) "+
							" or (t.added_by in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='8' and b.user_state = '0' and a.ca_user= ?) and user_name is null))";  

   static final String COUNT_IBTP_SHARED = "select count(*) from sbi_rtgs_beneficiary where account_number=? and corporate_id=? and status in ('active','Pending','pending_approval') and nvl(emp_code,' ')=?";
   
   static final String COUNT_IBTP_NOTSHARED = "select count(*) from sbi_rtgs_beneficiary r where r.account_number=? and r.corporate_id=?  and r.status in ('active','Pending','pending_approval') and nvl(r.emp_code,' ')=? "+
							" and ((r.user_name in (select a.user_alias from bv_user a,bv_user_role b where a.user_id = b.user_id  and a.user_state = '0' and (r.user_name=a.user_alias and b.user_role='10') or (r.user_name=? and r.user_name=a.user_alias and b.user_role='7'))) "+ 
							" or r.user_name in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='42' and b.user_state = '0' and a.ca_user= ?)  "+
							" or r.user_name in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='21' and b.user_state = '0' and a.ca_user in (?,(select a.user_alias from bv_user a, bv_user_role b, bv_user_profile c where a.user_id = b.user_id and b.user_id = c.user_id and b.user_role='10' and c.corporate_id = ? and a.user_state = '0')))  "+
							" or (r.user_name in (select b.user_alias from sbicorp_ca_user_map a,  bv_user b,  bv_user_role c where  a.user_name = b.user_alias  and b.user_id = c.user_id  and c.user_role='8' and b.user_state = '0' and a.ca_user= ?) and approved_by is null))";  
}
  
