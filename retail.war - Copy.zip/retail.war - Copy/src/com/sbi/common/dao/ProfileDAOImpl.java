/* 
 * ProfileDAOImpl.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 Naveen Kumar - Initial Creation and method Implemetations
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.utils.map.ConvertSpring3Util;

import com.sbi.common.bp.BPConstants;
import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.model.LinkDetails;
import com.sbi.common.model.Query;
//import com.sbi.dao.DAOConstants;
//import com.sbi.dao.ErrorConstants;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.dao.ErrorConstants;

public class ProfileDAOImpl extends JdbcDaoSupport implements ProfileDAO {

    protected final Logger logger = Logger.getLogger(getClass());

    private UserSessionCache userSessionCache;
    
    

	private String linkDisplayStatus;
    
	public void setLinkDisplayStatus(String linkDisplayStatus) {
		this.linkDisplayStatus = linkDisplayStatus;
	}
    public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}

	/**
     * This method calls a stored procedure linkaccounts that links the accounts
     * of the user passed as second parameter to the user passed as first user.
     * Also it deactivates the second user and maps all the bills of the second
     * user in SBI_BP_USER_BILLER_MAP to the first user
     * 
     * @param userName
     * @param linkedUserName
     * @return boolean
     * @throws DAOException
     */
    public boolean linkAccounts(String userName, String linkedUserName) throws DAOException {
        logger.info("linkAccounts(String userName, String linkedUserName)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
            logger.debug("username , linkedUserName : " + userName + " AND " + linkedUserName);
        logger.info("username , linkedUserName : " + userName + "AND" + linkedUserName);

        if (userName == null || linkedUserName == null || (userName.trim()).equals(DAOConstants.EMPTY)
                || (linkedUserName.trim()).equals(DAOConstants.EMPTY)) {
          DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else {

            Map inParams = new HashMap();
            inParams.put(DAOConstants.USER_NAME, userName);
            inParams.put(DAOConstants.LINKED_USER_NAME, linkedUserName);

            List parameterList = new ArrayList();
            parameterList.add(new SqlParameter(DAOConstants.USER_NAME, Types.VARCHAR));
            parameterList.add(new SqlParameter(DAOConstants.LINKED_USER_NAME, Types.VARCHAR));
            parameterList.add(new SqlOutParameter(DAOConstants.STATUS, Types.VARCHAR));

            CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(
                    "{call LINK_ACCOUNTS(?,?,?)}", parameterList);

            CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);

            Map result = getJdbcTemplate().call(callableStatement, parameterList);
            String linkAccountStatus = (String) result.get(DAOConstants.STATUS);
            logger.info("Value Returned by Procedure" + linkAccountStatus);

            if (linkAccountStatus.equalsIgnoreCase("true")) {
                logger.info("linkAccounts(String userName, String linkedUserName)" + LoggingConstants.METHODEND);
                return true;
            }
            else {
                logger.info("Exception occured :");
               DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }
       return false;
    }

    /**
     * This method will call the insertBranchMessage function with the branch
     * code passed as input to it. On receipt of succes from insertBranchMessage
     * this method will insert into SBI_PASSWORD_COUNT following values Oracle
     * Sequence number for reference_no Sysdate for password_requested_date 1
     * for Password type branchcode(input param) as branch_code
     * 
     * @param userName
     * @param branchCode
     * @return  boolean
     * @throws DAOException
     */
    public String insertPasswordCount(String userName, String branchCode) throws DAOException

    {
        boolean status = false;
        String referenceNo = null;
        logger.info("insertPasswordCount(String userName, String branchCode,String fullName)"
                + LoggingConstants.METHODBEGIN);

        if (logger.isDebugEnabled())
            logger.debug("username , linkedUserName, fullName : " + userName + " AND " + branchCode + " AND "
                    );

        logger.info("username , linkedUserName, fullName : " + userName + "AND" + branchCode + " AND "  );

        if (userName == null || branchCode == null || (userName.trim()).equals(DAOConstants.EMPTY)
                || (branchCode.trim()).equals(DAOConstants.EMPTY) ) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {

            referenceNo = (String) getJdbcTemplate().queryForObject(SQLConstants.PASSWORD_COUNT_REFERENCE,String.class);
            
            Object[] param =
            { referenceNo, userName, branchCode };

            for (int i = 0; i < param.length; i++) {
                logger.info("Parameters for Query is --> " + param[i]);
            }

            int sqlType[] =
            { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

            int noOfRowsInserted = getJdbcTemplate()
                    .update(SQLConstants.INSERT_INTO_SBI_PASSWORD_COUNT, param, sqlType);

            if (noOfRowsInserted <= 0) {
               DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);}
            String message = "Lost profile password request received from " + ". Username :" + userName
                    + ".";

            // Calling Method insertBranchMessage

            status = insertBranchMessage(message, branchCode);
        }

        logger.info("insertPasswordCount(String userName, String branchCode,String fullName)"
                + LoggingConstants.METHODEND);
        if (logger.isDebugEnabled())
            logger.debug("Value returned by Method is " + status);
        logger.info("Value returned by Method is " + status);
        return referenceNo;
    }

    /**
     * This inserts the message passed as input to the branch (another input
     * param) into SBI_BRANCH_MESSAGES. The unique_id will be a oracle sequence
     * and the last_date as 7 days from the current date
     * 
     * @param message
     * @param branchCode
     * @return boolean
     * @throws DAOException
     */
    public boolean insertBranchMessage(String message, String branchCode) throws DAOException {

        logger.info("insertBranchMessage(String message, String branchCode)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
            logger.debug("message , branchCode : " + message + " AND " + branchCode);
        logger.info("message , branchCode : " + message + "AND" + branchCode);

        if (message == null || branchCode == null || (message.trim()).equals(DAOConstants.EMPTY)
                || (branchCode.trim()).equals(DAOConstants.EMPTY)) {
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else {
            Object[] param =
            { branchCode, message };

            for (int i = 0; i < param.length; i++) {
                logger.info("Parameters for Query is --> " + param[i]);
            }

            int sqlType[] =
            { Types.VARCHAR, Types.VARCHAR };

            int noOfRowsInserted = getJdbcTemplate().update(SQLConstants.INSERT_INTO_SBI_BRANCH_MESSAGES, param,
                    sqlType);

            if (noOfRowsInserted <= 0) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }

        logger.info("insertBranchMessage(String message, String branchCode)" + LoggingConstants.METHODEND);

        if (logger.isDebugEnabled())
            logger.debug("Value returned by Method is True");
        logger.info("Value returned by Method is True");

        return true;
    }

    /**
     * Will pick all the branches in SBI_CUSTOMER_ACCOUNT_MAP for the user with
     * the bankysytem as passed in the input. The list of branches(branch name
     * and code) are returned as a 2 dimensioanal array
     * 
     * @param userName
     * @param bankSystem
     * @return String[][]
     * @throws DAOException
     */
    public Map findUserBranches(String userName, String bankSystem) throws DAOException {
        logger.info("getUserBranches (String userName, String bankSystem)" + LoggingConstants.METHODBEGIN);

        if (logger.isDebugEnabled())
            logger.debug("userName , bankSystem : " + userName + " AND " + bankSystem);
        logger.debug("username , bankSystem : " + userName + " AND " + bankSystem);

        if (userName == null || bankSystem == null || (userName.trim()).equals(DAOConstants.EMPTY)
                || (bankSystem.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        } 
        else {
            try {
                Object[] parameters = null;
                if (bankSystem.equalsIgnoreCase("C"))
                    parameters = new Object[] {userName, new Integer(0), new Integer(0)};
                else if (bankSystem.equalsIgnoreCase("NC"))
                    parameters = new Object[] {userName, new Integer(1), new Integer(1)};
                else if(bankSystem.equalsIgnoreCase("ALL"))
                    parameters = new Object[] {userName, new Integer(0), new Integer(1)};
                                    
                List branchCodeandBranchNameList = getJdbcTemplate().query(SQLConstants.GET_USER_BRANCHES, parameters,
                        new branchCodeandBranchNameRowMapper());

                if (branchCodeandBranchNameList != null && branchCodeandBranchNameList.size() > 0) {
                    Map data = (Map) branchCodeandBranchNameList.get(0);
                    userSessionCache.setData(userName+BPConstants.BRANCH_LIST_REFERENCE,data);
                    if (logger.isDebugEnabled()) {
                        logger.debug("branchCodeandBranchName" + data);
                    }
                    logger.info("getUserBranches (String userName, String bankSystem)" + LoggingConstants.METHODEND);

                    return data; 
                }
            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        return null;
    }

    class branchCodeandBranchNameRowMapper implements RowMapper {
        Map branchNameCodeData = new LinkedHashMap();

        public Object mapRow(ResultSet rs, int index) throws SQLException {
            branchNameCodeData.put(rs.getString(1), rs.getString(2));
            return branchNameCodeData;
        }
    }

    public Map findCountryNameCodes() throws DAOException {
        logger.info("findCountryNameCodes()" + LoggingConstants.METHODBEGIN);
          Map data =  new LinkedHashMap();
        try {
            List countryNameCodeDataList = getJdbcTemplate().query(SQLConstants.FIND_COUNTRY_NAME_CODE,
                    new CountryNameCodeRowMapperRowMapper());
            //logger.info(" countryNameCodeDataList size " + countryNameCodeDataList);

            if (countryNameCodeDataList != null && countryNameCodeDataList.size() > 0) {
                
               data = (Map) countryNameCodeDataList.get(0);
                if (logger.isDebugEnabled()) {
                    logger.debug("branchCodeandBranchName" + data);
                }
                logger.info("getUserBranches (String userName, String bankSystem)" + LoggingConstants.METHODEND);
                return data;
            }
            
            
            }
        catch (DataAccessException ex) {
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }

        return null;
    }

    class CountryNameCodeRowMapperRowMapper implements RowMapper {
        Map countryNameCodeData = new   LinkedHashMap();
       

        public Object mapRow(ResultSet rs, int index) throws SQLException {
            countryNameCodeData.put(rs.getString(1), rs.getString(2));
            return countryNameCodeData;
        }
    }

    /**
     * DESCRIPTION : Gets link details for the userRole,userType,bankCode,moduleName handled for CUG also..
     * If module name is identified as cug then normal links and cug links will be displayed for the cugapplication.
     */
    public Map getLinkDetails(String userrole,String usertype,String bankcode,String moduleName){
    	/*
    	 * <property name="linkDisplayStatus"><value>${linkDisplayStatus}</value> </property>
    	 */
        logger.info("getLinkDetails()" + LoggingConstants.METHODBEGIN);
        logger.info("userrole :"+userrole+" usertype :"+usertype+" bankcode :"+bankcode+" moduleName:"+moduleName);
        String displayStatus=StringUtils.convertINClauseFormat(linkDisplayStatus, ",");
        
        String FIND_LINK_DETAILS="select a.link_id,a.link_name,a.link_url,a.link_order_no,a.tab_name,a.tab_id,a.base_url,a.error_code,a.body_header,a.body_tab,a.body_tab_name,a.left_nav,a.query_id from sbi_link_details a, sbi_module_details b where user_role=? and user_type=? and bank_code=? and a.module_name =? and a.display_status in(#displayStatus#) and a.link_id = b.link_id and b.display_status='YES' order by a.tab_id, a.link_order_no,a.left_nav desc";
        String Final_Query=FIND_LINK_DETAILS.replaceAll("#displayStatus#",displayStatus);
        logger.info("repalced query:"+Final_Query);
        Object params[]={userrole,usertype,bankcode,moduleName};
        Map linkDetails=(Map)getJdbcTemplate().query(Final_Query,params,new LinkDetailExtractor());
        logger.info("getLinkDetails()" + LoggingConstants.METHODEND);
        return linkDetails;
    }
    public Map getLinkDetails(String userrole,String usertype,String bankcode,String moduleName,String corporateId){
        logger.info("getLinkDetails()" + LoggingConstants.METHODBEGIN);
        logger.info("userrole :"+userrole+" usertype :"+usertype+" bankcode :"+bankcode+" moduleName:"+moduleName+" corporateId:"+corporateId);
        String displayStatus=StringUtils.convertINClauseFormat(linkDisplayStatus, ",");
        String FIND_LINK_DETAILS=" SELECT A.LINK_ID,A.LINK_NAME,A.LINK_URL,A.LINK_ORDER_NO,A.TAB_NAME,A.TAB_ID,A.BASE_URL,A.ERROR_CODE,A.BODY_HEADER,A.BODY_TAB,A.BODY_TAB_NAME,A.LEFT_NAV,A.QUERY_ID FROM SBI_LINK_DETAILS A, SBI_MODULE_DETAILS B WHERE USER_ROLE=? AND USER_TYPE=? AND BANK_CODE=? AND A.MODULE_NAME =? AND A.DISPLAY_STATUS IN(#displayStatus#) AND A.LINK_ID = B.LINK_ID AND B.DISPLAY_STATUS='YES' AND A.LINK_NAME NOT IN (SELECT LINK_NAME FROM SBI_LINK_DISABLE_MASTER WHERE CORPORATE_ID =? AND LINK_DISABLE='YES' AND MODULE_NAME=A.MODULE_NAME ) ORDER BY A.TAB_ID, A.LINK_ORDER_NO,A.LEFT_NAV DESC ";
        String Final_Query=FIND_LINK_DETAILS.replaceAll("#displayStatus#",displayStatus);
        logger.info("repalced query:"+Final_Query);
        Object params[]={userrole,usertype,bankcode,moduleName,corporateId};
        Map linkDetails=(Map)getJdbcTemplate().query(Final_Query,params,new LinkDetailExtractor());
        logger.info("getLinkDetails()" + LoggingConstants.METHODEND);
        return linkDetails;
    }
    
    public class LinkDetailExtractor implements ResultSetExtractor{
        public Object extractData(ResultSet rs) throws SQLException, DataAccessException{
            Map linkDetailsMap = new LinkedHashMap();
            List<LinkDetails> tabs = new ArrayList<LinkDetails>();
            List<String> queryIds = new ArrayList<String>(); 
            while (rs.next()){
                LinkDetails linkDetails = new LinkDetails();
                linkDetails.setLinkID(rs.getString("LINK_ID"));
                linkDetails.setLinkName(rs.getString("LINK_NAME"));
                linkDetails.setLinkOrder(new Integer(rs.getInt("LINK_ORDER_NO")));
                linkDetails.setLinkURL(rs.getString("LINK_URL"));
                linkDetails.setTabID(new Integer(rs.getInt("TAB_ID")));
                linkDetails.setTabName(rs.getString("TAB_NAME"));
                linkDetails.setBaseURL(rs.getString("BASE_URL"));
                linkDetails.setErrorCode(rs.getString("ERROR_CODE"));
                linkDetails.setBodyHeader(rs.getString("BODY_HEADER"));
                linkDetails.setBodyTab(rs.getString("BODY_TAB"));
                linkDetails.setBodyTabName(rs.getString("BODY_TAB_NAME"));
                linkDetails.setLeftNav(rs.getString("LEFT_NAV"));
                linkDetails.setQueryId(rs.getString("QUERY_ID"));
                linkDetailsMap.put(linkDetails.getLinkURL(), linkDetails);
                if(linkDetails.getTabName() !=null && !tabs.contains(linkDetails))
                	tabs.add(linkDetails);
                if(linkDetails.getQueryId()!=null && !queryIds.contains(linkDetails.getQueryId())){
                	queryIds.add(rs.getString("QUERY_ID"));
                }
            }
            linkDetailsMap.put("tabs",tabs);
            linkDetailsMap.put("queryIds", queryIds);
            logger.info("Link Details : " + linkDetailsMap);
            return linkDetailsMap;
        }
    }
    
    /**
     * DESCRIPTION : Loads queries and returns a map of queryModel with key as queryId+role 
     */
    public Map<String,Query> getQueries(){
    	Map<String, Query> queries = null;
    	try{
    		queries = (Map<String, Query>)getJdbcTemplate().query("select query_id,query,query_type,object_name,function_name,matching_value,role from sbi_link_query_mapping",new QueryExtractor());
    	}catch (DataAccessException e) {
			e.printStackTrace();
		}
    	return queries;
    }
    
    class QueryExtractor implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map<String, Query> queries = new HashMap<String, Query>();
			while(rs.next()){
				Query query = new Query();
				query.setQuery(rs.getString("query"));
				query.setQueryType(rs.getString("query_type"));
				query.setMatchingValue(rs.getString("matching_value"));
				query.setObjectName(rs.getString("object_name"));
				query.setFunctionName(rs.getString("function_name"));
				queries.put(rs.getString("query_id")+"|"+rs.getString("role"), query);
			}
			return queries;
		}
    }
    
    /**
     * DESCRIPTION : Executes Query(for Handling previledged users) for the corresponding link which on returning YES will enable the link.
     *  Exception is caught and value returned is NO which automatically disables the link 
     */
    public String getQueryValue(String query, String userAlias,String corporateId){
    	String value="NO";
    	try{
    		value = (String)getJdbcTemplate().queryForObject(query, new Object[]{userAlias,corporateId},String.class);
    	}catch (Exception e) {
    		//e.printStackTrace();
    		logger.info("Exception>>>>"+e.getMessage());
		}
    	return value;
    }
    
    // Added for reset of transaction password -Start
    public String getPasswordReferenceDetail(String userName,String branchCode,String type) throws DAOException 
    {
		logger.debug("getPasswordReferenceDetail(String userName,String branchCode,String type) throws DAOException method starts");
		List<Map> referenceNoList=new ArrayList<Map>();
		String referenceNo="";
		Object[] params = {type, userName, branchCode };
		String sqlQuery="";
		try {
			sqlQuery="select reference_no from sbi_password_count where status=1 and password_type=? and user_name=? and branch_code=? and password_changed_date is null order by creation_time desc";
			//referenceNoList =getJdbcTemplate().queryForList(sqlQuery,params);
			referenceNoList = new ConvertSpring3Util().convertMap(getJdbcTemplate().queryForList(sqlQuery,params));
			if(referenceNoList.size()>0)
			{
				Map referenceNoMap=(Map)referenceNoList.get(0);
				referenceNo=(String)referenceNoMap.get(new String("reference_no"));
			}
			logger.info("referenceNoList ::::"+referenceNoList);
			logger.info("referenceNo ::::"+referenceNo);
		} catch (DataAccessException ex) {
			logger.error("Exception Occurred: ",ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}       
		logger.debug("getPasswordReferenceDetail(String userName,String branchCode,String type) throws DAOException method ends");
		return referenceNo;
	}
    
	public String insertPasswordCount(String userName, String branchCode,String type) throws DAOException
	{
		boolean status = false;
		String message="";
		String referenceNo = null;
		
		logger.info("insertPasswordCount(String userName, String branchCode,String type)"+ LoggingConstants.METHODBEGIN);
		logger.info("username , linkedUserName, fullName : " + userName + " AND " + branchCode + " AND ");
		
		if (userName == null || branchCode == null || (userName.trim()).equals(DAOConstants.EMPTY)|| (branchCode.trim()).equals(DAOConstants.EMPTY) ) {
		    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		else {
			referenceNo = (String) getJdbcTemplate().queryForObject(SQLConstants.PASSWORD_COUNT_REFERENCE,String.class);
			logger.info("Refernce No::"+referenceNo); 
			Object[] param ={referenceNo, userName, branchCode, type};
			
			for (int i = 0; i < param.length; i++) {
			    logger.info("Parameters for Query is --> " + param[i]);
			}
			
			int sqlType[] ={Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
			int noOfRowsInserted = getJdbcTemplate().update(SQLConstants.INSERT_SBI_PASSWORD_COUNT, param, sqlType);
			
			if (noOfRowsInserted <= 0) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
			
			//changed for TXN pwd by Siva
			if(type.equalsIgnoreCase("1")){
				message = "Lost profile password request received from " + ". Username :" + userName + ".";
			}
			
			if(type.equalsIgnoreCase("2")){
				message = "Lost transaction password request received from " + ". Username :" + userName + ".";
			}
			
			// Calling Method insertBranchMessage
			status = insertBranchMessage(message, branchCode);
		}
		logger.info("insertPasswordCount(String userName, String branchCode,String type)"+ LoggingConstants.METHODEND);
		logger.info("Value returned by Method is " + status);
		return referenceNo;
	}
	public Boolean isTransactionPwdEmpty(String userName,String corporateId) throws DAOException 
    {
		logger.debug("isTransactionPwdEmpty(String userName,String corporateId) throws DAOException method starts");
		List<Map> referenceNoList=new ArrayList<Map>();
		Object[] params = {userName,corporateId};
		String sqlQuery="";
		Boolean count=null;
		try {
			sqlQuery="select count(*) from bv_user_profile where user_id in(select user_id from bv_user where user_alias=? and transaction_password is null and corporate_id = ?)";
			count=(Boolean)getJdbcTemplate().queryForObject(sqlQuery, params, Boolean.class);
			logger.info("referenceNo ::::"+count);
		} catch (DataAccessException ex) {
			logger.error("Exception Occurred: ",ex);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}       
		logger.debug("isTransactionPwdEmpty(String userName,String corporateId) throws DAOException method ends");
		return count;
	}
    //Added for reset of transaction password -End

	//Added for lock user access starts 
	public Map lockAccountConfirm(String userName, String mobileNo ,String bankCode, String corporateID) {
		
		
		logger.info("lockAccountConfirm(String userName, String mobileNo ,String branchCode) method begin");
		logger.info("userName :" + userName + "mobileNo :" + mobileNo+ "branchCode :" + bankCode);

		Map outParam = new HashMap();
		Date creationTime = null;
		int status = 0;
		
		int status1 = 0;
		int lockAccountConfirmCount = 0;
		String referenceNo = null;
		String validUserQuery;
		String validRefNoCount;
		
		if (userName != null) {
			Object[] countparams = new Object[] { userName, mobileNo, bankCode };
			
			validUserQuery = "select count(1) from bv_user a,bv_user_profile b where a.user_alias = ? and a.user_id = b.user_id  and a.user_state = 0 and b.mobile_no =? and b.bank_code =? and not exists(select 1 from sbi_user_lock_account d where d.user_name =a.user_alias and locked_status ='Y')";
			lockAccountConfirmCount = getJdbcTemplate().queryForInt(validUserQuery, countparams);
			logger.info("count :" + lockAccountConfirmCount);
			if (lockAccountConfirmCount ==1) {
				try {
					
					String query = "select 'UL'||LPAD(ACCOUNT_LOCK_SEQ.NEXTVAL,8,0)reference_no from dual";
					referenceNo = (String) getJdbcTemplate().queryForObject(query,String.class);
					
					Object[] Parameter = new Object[] { referenceNo, userName,
							userName,mobileNo,corporateID};
					int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
							Types.VARCHAR,Types.VARCHAR };
					logger.info("referenceNo:::" + referenceNo + "mobileNo :"
							+ mobileNo);
					String query_for_user = "INSERT INTO sbi_user_lock_account(REFERENCE_NO,USER_NAME,ACCOUNT_NO,BRANCH_CODE,MOBILE_NO,LOCKED_STATUS,REACTIVATED_BY,CREATION_TIME,CORPORATE_ID) "
						+ "values(? ,?,null,(select branch_code from bv_user_profile "
						+ "where user_id in (select user_id from bv_user where user_alias=?)),?,'Y',NULL,SYSDATE,?)";
					status1 = getJdbcTemplate().update(query_for_user, Parameter,
							sqlTypes);
					
					logger.info("status " + status1);
					creationTime = new Date();
					// after insert user state to be 1
					if (status1 == 1) {
						String updateQuery = "UPDATE bv_user set user_state = '1' where user_alias = ?";
						int updateCount = 0;
						updateCount = getJdbcTemplate().update(updateQuery,	new Object[] { userName });
					}
					if (referenceNo != null) {
						logger.info("referenceNo :::" + referenceNo);
						outParam.put("reference_no", referenceNo);
						outParam.put("lockAccountConfirmCount", lockAccountConfirmCount);
						
						
					}
				} catch (DataAccessException dae) {
					DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dae);

				}

			}
			else {
				outParam.put("isUserLocked", "Yes");
			}
		} else {
			DAOException.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("status :" + status);
		}

		logger.info("lockAccountConfirm(String userName, String mobileNo ,String branchCode) method end");
		return outParam;
		
        //logger.info(" returning responseFlag:"+responseFlag);
            
		
	}

    public boolean userExist(String corporatId,String userName,String mobileNo) throws DAOException {
        logger.info(" userExist(String corporatId,String userName,String mobileNo) begin");
        boolean isUserExists=false;
        try {

            Object[] parameters = new Object[] { corporatId,userName,mobileNo }; 
            //List result = getJdbcTemplate().queryForList("select * from bv_user a ,bv_user_profile b where //a.user_id =b.user_id and b.corporate_id=? and a.user_alias=? and b.mobile_no=?",parameters);
			List result = new ConvertSpring3Util().convertMap(getJdbcTemplate().queryForList("select * from bv_user a ,bv_user_profile b where a.user_id =b.user_id and b.corporate_id=? and a.user_alias=? and b.mobile_no=?",parameters));
			
            logger.info("result"+result);
            if (result != null && result.size() > 0) {
                logger.info("valid User:" + result.get(0));
                logger.info("userExist(String corporatId,String userName,String mobileNo) method end");
                isUserExists= true;
             } else{
            	 isUserExists=false;
             }
        } catch (DataAccessException ex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
       return isUserExists;
    }
	
	 /*Added for Voice OTP */
    public Map findVoiceOTPMobileSeries() throws DAOException {
        logger.debug("findVoiceOTPMobileSeries()" + LoggingConstants.METHODBEGIN);
          Map data =  new LinkedHashMap();
        try {
           List  voiceOTPMobileList = getJdbcTemplate().query(SQLConstants.FIND_VOICE_OTP_MOBILE_SERIES, new MobileSeriesRowMapper());
            logger.info("voice OTP list from table :"+voiceOTPMobileList);
            data = (Map)voiceOTPMobileList.get(0);
            logger.info("data :" +data);
            return data;
            }
        catch (DataAccessException ex) {
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }

        return null;
    }
       class MobileSeriesRowMapper implements RowMapper
	    { 
	        HashMap data = new LinkedHashMap();

	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {
	            data.put(rs.getString(1), rs.getString(2));
	            return data;
	        }
	    }
    /* End of Voice OTP */

	public Boolean getCorporateHasDisabledLinks(final String corporateId, final String moduleName) {
		logger.debug("getCorporateHasDisabledLinks()" + LoggingConstants.METHODBEGIN);
		Boolean isCorporateHasDisabledLinks = Boolean.FALSE;
		final String query = "SELECT COUNT(DISTINCT LINK_NAME) FROM SBI_LINK_DISABLE_MASTER WHERE CORPORATE_ID=? AND MODULE_NAME=? AND LINK_DISABLE='YES' ";
		final int count = getJdbcTemplate().queryForInt(query,new Object[]{corporateId,moduleName});
		if(count>=1){
			isCorporateHasDisabledLinks = Boolean.TRUE;
			logger.info("isCorporateHasDisabledLinks:"+isCorporateHasDisabledLinks);
		}
		logger.debug("getCorporateHasDisabledLinks()" + LoggingConstants.METHODBEGIN);
		return isCorporateHasDisabledLinks;
	}
    
}
