/*   
 * UserDAOImpl.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History  
//Oct 18, 2005 BOOPATHI - Initial Creation
//Oct 28,2005  MURNGAN K - method's implementation 
//Dec 04,2005 krishna - business phone concatenation added
//Nov 23, 2009 LP49927 - ECS and Ddebit login related methods removed pertaining to CorpDynamic Links
package com.sbi.common.dao;
 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Address;
import com.sbi.common.model.AuditAccMap;
import com.sbi.common.model.Field;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.model.SPOutput;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.EncryptMD5;
import com.sbi.common.utils.ExecuteStoredProcedure;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.dao.ErrorConstants;
import org.springframework.jdbc.core.ResultSetExtractor; //5552
//Added for SHA encryption algorithm
import com.sbi.authentication.algorithm.*;
import com.sbi.authentication.user.RequestResponseService;


/**
 * TODO This class is used to find the information and profile of user
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class UserDAOImpl extends JdbcDaoSupport implements UserDAO {

    protected final Logger logger = Logger.getLogger(getClass());

    private UserSessionCache userSessionCache;
    
    private TransactionTemplate transactionTemplate;
    
    private RequestResponseService requestResponseService; //Added for SHA encryption algorithm
    
    private Sha512Hashing sha512Hashing;
    
    private User userObj;
    
    private String password;
    
    private String newUserName;
    
    private String oldUser;
    
    public static final String FIND_USER="select * from bv_user where user_alias=?";
    
    public static final String  UPDATE_USER_STATE="update bv_user set user_state=? where user_alias=?";
    
    public static final String  UPDATE_USER_STATES="update bv_user set user_state=? where user_alias = ? and user_id in (select user_id from bv_user_profile where corporate_id = ?)";//shanta
        
    //added for sha512
    
    public static final String UPDATE_BVUSER_PASSWORD ="update bv_user set PASSWORD=? where user_alias = ?"; 
    
    //public static final String UPDATE_USER_PROFILE ="update bv_user_profile set LOGIN_PASSWORD_HASHING=? where user_id = (select user_id from bv_user where user_alias = ?)";

    //End for sha512
    
    // query to insert into sbicorp_user_map_history
    
    public static final String INSERT_CORPUSER_MAP_HISTORY = "insert into sbicorp_user_map_history fields(oid,new_user_name,store_id,creation_time,status,deleted,last_mod_time,old_user_name,map_date,action)values(oid_sequence.nextval,?,101,sysdate,1,0,sysdate,?,sysdate,0)";
    
    public static final String USER_PROFILE_FINDER = "select NAME, friendly_name, news_preference2,designation, district, department, corporate_id, user_id, employee_no,created_by, address, city, state, zip, country, email, bus_phone, home_phone, last_login_date, last_tname_internet, last_tdate_internet, internet_bank_trans_limit, login_count, thirdparty_limit, branch_code,Source,DECODE (bank_code, '', '0', 'SBI', '0', bank_code) bank_code, hint_question, hint_answer, mobile_no, NVL (sms_security, 1) sms_security, profile_password, decode(user_type,null,0,user_type) user_type,TRANSACTION_PASSWORD,FIELD_OF_WORK, PASSWORD_MODE, PWD_CHANGED_DATE, NEWS_PREFERENCE5,sf_auth_provider,MERCHANT_OTP,login_password_hashing, profile_password_hashing,txn_password_hashing,otp_delivery_mode,irctc_enable,lock_time FROM bv_user_profile WHERE user_id IN (SELECT user_id FROM bv_user WHERE user_alias = ? and user_state=0)"; //cr-5550-iMMANUEL(fORCED LOGIN psw_mode)//PWD_CHANGED_DATE added by Siva , // Vasco Flag for Corporate Roles
    
    public static final String USER_PROFILE_FINDERS = "select NAME, friendly_name, news_preference2,designation, district, department, corporate_id, user_id, employee_no,created_by, address, city, state, zip, country, email, bus_phone, home_phone, last_login_date, last_tname_internet, last_tdate_internet, internet_bank_trans_limit, login_count, thirdparty_limit, branch_code, DECODE (bank_code, '', '0', 'SBI', '0', bank_code) bank_code, hint_question, hint_answer, mobile_no, NVL (sms_security, 1) sms_security, profile_password, decode(user_type,null,0,user_type) user_type,TRANSACTION_PASSWORD,FIELD_OF_WORK, PASSWORD_MODE, PWD_CHANGED_DATE, NEWS_PREFERENCE5,sf_auth_provider,MERCHANT_OTP,LOGIN_PASSWORD_HASHING,PROFILE_PASSWORD_HASHING,TXN_PASSWORD_HASHING,otp_delivery_mode,irctc_enable FROM bv_user_profile WHERE user_id IN (SELECT user_id FROM bv_user WHERE user_alias = ? and user_state=0) and corporate_id = ?"; //shanta , // Vasco Flag for Corporate Roles

//Added for Mobile No updation
//    public static final String FIND_USER_PROFILE_FINDERS ="select NAME, friendly_name, news_preference2,designation, district, department, corporate_id, user_id,employee_no,created_by, address, city, state, zip, country, email, bus_phone, home_phone,last_login_date, last_tname_internet, last_tdate_internet, internet_bank_trans_limit, login_count, thirdparty_limit, branch_code, DECODE (bank_code, '', '0', 'SBI', '0', bank_code) bank_code,hint_question, hint_answer, mobile_no, NVL (sms_security, 1) sms_security, profile_password,decode(user_type,null,0,user_type) user_type,TRANSACTION_PASSWORD,FIELD_OF_WORK,PASSWORD_MODE,PWD_CHANGED_DATE,(select e.new_mobile_no from sbicorp_user_mobile_no e where b.user_id = e.user_id(+) and e.status ='Pending') new_mobile_no  FROM bv_user_profile b WHERE user_id IN (SELECT user_id FROM bv_user WHERE user_alias = ? and user_state=0) and corporate_id = ?";
     public static final String FIND_USER_PROFILE_FINDERS ="select NAME, friendly_name, news_preference2,designation, district, department, corporate_id, user_id, employee_no,created_by, address, city, state, zip, country, email, bus_phone, home_phone,last_login_date,last_tname_internet, last_tdate_internet, internet_bank_trans_limit, login_count, thirdparty_limit,branch_code, DECODE (bank_code, '', '0', 'SBI', '0', bank_code) bank_code,hint_question, hint_answer,mobile_no, NVL (sms_security, 1) sms_security, profile_password,decode(user_type,null,0,user_type) user_type,TRANSACTION_PASSWORD,FIELD_OF_WORK,PASSWORD_MODE,PWD_CHANGED_DATE,nvl((select e.new_mobile_no from sbicorp_user_mobile_no e where b.user_id = e.user_id(+) and e.status ='Pending'),b.mobile_no) new_mobile_no  FROM bv_user_profile b WHERE user_id IN (SELECT user_id FROM bv_user WHERE user_alias = ? and user_state=0) and corporate_id = ?"; //chaged for c9 countrycode  
//  Added for CR 5143
    public static final String FIND_USER_REFS="select dispatch1_ref,dispatch2_ref from sbi_user_dispatch where user_name =?";
    //Added for CR 5552
    public static final String GET_PP_KIT_DETAILS="select emp_no, pp_id, name, designation, department," +
    		" address1, city, state, country, pincode, email, phone,user_type,status,userrole from SBI_CORP_PPKITS_USER_DETAIL " +
    		"where #tobereplaced#";
   /* public static final String GET_REISSUE_PWD_USR_DETAILS = "select user_id,EMPLOYEE_NO,NAME,Designation,Department,Address,City,State,Country,Zip,BUS_PHONE,Email from bv_user_profile where user_id=("+
    		"select user_id from bv_user where user_alias=?)";*/
    //5552 c7a
    public static final String GET_REISSUE_PWD_USR_DETAILS = " select a.user_id,a.EMPLOYEE_NO,a.NAME,a.Designation,a.Department,a.Address,a.City,a.State,a.Country,a.Zip,a.BUS_PHONE,a.Email,c.user_role,a.mobile_no "+
																" from bv_user_profile  a,bv_user b,bv_user_role c where "+
																" a.user_id = b.user_id "+
																" and b.user_id = c.user_id "+
																" and b.user_alias = ? ";
   // public static final String GET_REISSUE_PWD_DETAILS = "select user_name,password_status from sbicorp_resetpwd_ppkit where #tobereplaced#";
    public static final String GET_REISSUE_PWD_DETAILS = "select a.user_name,a.password_status,b.friendly_name " +
    " from sbicorp_resetpwd_ppkit a,bv_user_profile b ,bv_user c "+
    " where a.password_status='pending' and a.ca_user=? " +
    " and a.user_name=c.user_alias" +
    " and c.user_id = b.user_id";
    //C9 start
    public static final String LIST_C9_USR_DETAILS = "select user_id,friendly_name, reference_no, new_mobile_no,status from sbicorp_user_mobile_no where (created_by=? or user_id=?) and status ='Pending' order by reference_no desc";
    public static final String LIST_C9_INT_USR_DETAILS = "select b.user_id,b.corporate_id,b.new_mobile_no,b.reference_no,b.user_role, "+
    "b.Created_by,b.Friendly_name,a.emp_no from SBI_CORP_PPKITS_USER_DETAIL a, "+
    "sbicorp_user_mobile_no b where a.pp_id = b.user_id  and a.created_by = b.created_by and b.user_id=?  and b.status='Pending'"+
    "union "+
    "select b.user_id,b.corporate_id,b.new_mobile_no,b.reference_no,b.user_role, "+
    "b.Created_by,b.Friendly_name,a.employee_no emp_no from bv_user_profile a, "+
    "sbicorp_user_mobile_no b where a.user_id = b.user_id and a.corporate_id = b.corporate_id and b.user_id=? and b.status='Pending' order by reference_no desc";
    //C9 Ends
    //5552 ends
		    
    /* Ramanan.M : Begin - Added to Lock and Unlock the Uploader */
    public static final String GET_DEACTIVATED_UPLOADER_DETAILS = "SELECT   NAME, user_alias FROM sbicorp_ca_user_map a, bv_user b, bv_user_role c, bv_user_profile d WHERE b.user_id = d.user_id AND ca_user = ? AND a.user_name = b.user_alias AND b.user_id = c.user_id AND c.user_role = ? AND a.status = 1 AND b.user_state = 1 and a.USER_TYPE != 'ddebituser' ORDER BY UPPER (NAME)";
    	
	  //Added for Dmat corporate
    public static final String FIND_VALID_CORP_USER="select count(a.user_name) from sbi_customer_account_map a,sbicorp_ca_account_map b where a.account_no=b.account_no and a.corporate_id=b.corporateid and a.account_no=? and a.user_name=? and b.ca_user=? and a.corporate_id=? and a.STATUS=1 ";
   	
  //Added for vasco token request start
    public static final String LIST_C10_INT_USR_DETAILS = "select b.user_id,b.corporate_id,b.reference_no,b.user_role, "+
	"b.Created_by,b.Friendly_name,a.emp_no from SBI_CORP_PPKITS_USER_DETAIL a, "+
	"sbi_sf_auth_user_req_details b where a.pp_id = b.user_id  and a.created_by = b.created_by and b.user_id=?  and b.status='Pending'"+
	"union "+
	"select b.user_id,b.corporate_id,b.reference_no,b.user_role, "+
	"b.Created_by,b.Friendly_name,a.employee_no emp_no from bv_user_profile a, "+
	"sbi_sf_auth_user_req_details b where a.user_id = b.user_id and a.corporate_id = b.corporate_id and b.user_id=? and b.status='Pending'";
	
    //Added for vasco token request end
    
	public static final String LIST_C7B_DETAILS = "SELECT d.reference_no,d.user_name,b.name, decode(c.user_role,8,'Corp User','-') user_role ,decode(d.PASSWORD_CHANGED_DATE,null,'Pending','Processed') PASSWORD_CHANGED_DATE,"
			+ "b.EMPLOYEE_NO, b.designation, b.department, b.address,b.city, b.state, b.country, "
			+ " b.ZIP, b.HOME_PHONE, b.email FROM BV_USER A , BV_USER_PROFILE B , "
			+ "BV_USER_ROLE C , sbi_password_count d WHERE A.USER_ID = B.USER_ID "
			+ "AND B.USER_ID = C.USER_Id and a.user_alias=d.user_name "
			+ "AND A.USER_STATE=0 AND b.USER_TYPE=0 AND c.USER_ROLE=8 AND B.CREATED_BY=? AND password_type = 2 AND PASSWORD_CHANGED_DATE is null";

	public static final String LIST_C7B_DETAILS_WITH_REFERENCE = "SELECT d.reference_no,d.user_name,b.name, decode(c.user_role,8,'Corp User','-') user_role ,decode(d.PASSWORD_CHANGED_DATE,null,'Pending','Processed') PASSWORD_CHANGED_DATE,"
			+ "b.EMPLOYEE_NO, b.designation, b.department, b.address,b.city, b.state, b.country, "
			+ " b.ZIP, b.HOME_PHONE, b.email,b.mobile_no FROM BV_USER A , BV_USER_PROFILE B , "
			+ "BV_USER_ROLE C , sbi_password_count d WHERE A.USER_ID = B.USER_ID "
			+ "AND B.USER_ID = C.USER_Id and a.user_alias=d.user_name "
			+ "AND A.USER_STATE=0 AND b.USER_TYPE=0 AND c.USER_ROLE=8 AND B.CREATED_BY=? and reference_no=?";
	
    private String userName; //CR-5550
    private String ipAdd; //CR-5550
    public boolean activateDeactivateUser(String userName,Integer activate)
    {
        logger.info("activateDeactivateUser(String userName,Integer activate)"+LoggingConstants.METHODBEGIN);
        Object[] parameters;
        try{
                if(userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)
                        && activate != null)
                {
                    parameters = new Object[] {activate,userName}; 
                    int count =getJdbcTemplate().update(UPDATE_USER_STATE,parameters);
                    if(count >0){
                        logger.info("activateDeactivateUser(String userName,Integer activate)"+LoggingConstants.METHODEND); 
                        return true;
                    }
                    
                }       
            
        } catch (DataAccessException dex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dex);
        }catch(Exception ex){
            DAOException.throwException( ErrorConstants.FATAL_ERROR1_CODE,ex );
        }
        logger.info("activateDeactivateUser(String userName,Integer activate)"+LoggingConstants.METHODEND); 
        return false;
    }
    
    
    
    //shanta
    public boolean activateDeactivateUser(String userName,Integer activate,String corporateId)
    {
        logger.info("activateDeactivateUser(String userName,Integer activate,String corporateId)"+LoggingConstants.METHODBEGIN);
        Object[] parameters;
        try{
                if(userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY)
                        && activate != null)
                {
                    parameters = new Object[] {activate,userName,corporateId};
                    //shanta
                    for(int i=0;i<3;i++){
                    logger.info("parameters are : "+parameters[i]);
                    }
                    //shanta
                    int count =getJdbcTemplate().update(UPDATE_USER_STATES,parameters);
                    if(count >= 1){
                        logger.info("activateDeactivateUser(String userName,Integer activate)"+LoggingConstants.METHODEND); 
                        return true;
                    }
                    
                }       
            
        } catch (DataAccessException dex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dex);
        }catch(Exception ex){
            DAOException.throwException( ErrorConstants.FATAL_ERROR1_CODE,ex );
        }
        logger.info("activateDeactivateUser(String userName,Integer activate,String corporateId)"+LoggingConstants.METHODEND); 
        return false;
    }
    //shanta



public boolean delete(String userName){
        return false;
    }
    /**
     * TODO find valid username and password from Table
     * 
     * @param userName
     * @param passWord
     * @return User
     * @throws DAOException
     */
    public User findUser(String userName, String passWord) throws DAOException {
        User user = null;
        Object[] parameters = new Object[] { userName }; // passWord }; later will add the password...
        List result=null;
        try {
    
            result = getJdbcTemplate().query(SQLConstants.LOGIN_SQL,parameters, new UserRowMapper());
        }catch(DataAccessException dataAccessException) {
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG014",errorParams);//unabel to retrieve user information
        }
        if (result != null && result.size() == 1) {
            logger.info("valid User:" + result.get(0));
            user = ((User) result.get(0));
        }
        Object[] userid = new Object[] { user.getUserId() };
        List roles=null;
        try {
            roles = getJdbcTemplate().query(SQLConstants.USER_ROLE,userid, new RolesRowMapper());
        } catch (DataAccessException ex) {
            Object[] errorParams={userName};
            DAOException.throwException(ex,"LOG013",errorParams);//unabel to retrieve user role
        }
        if (roles != null && roles.size() > 0) {
            user.setRoles(roles);
        }
        return user;
    }
    
    public User findUser(String userName) throws DAOException {
        logger.info(" findUser(String userName) begin");
        User user = null;
        try {

            Object[] parameters = new Object[] { userName }; 
            List result = getJdbcTemplate().query(SQLConstants.LOGIN_SQL,
                    parameters, new UserRowMapper());
//changed for CR 2417
            if (result != null && result.size() > 0) {
                logger.info("valid User exists:" + result.get(0));
                logger
                        .info("findUser(String userName) method end");
                user = ((User) result.get(0));
             } else {
            	 logger.info("Inside else::::");
                 user = null;
            }
        } catch (DataAccessException ex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return user;
    }

    /**
     * TODO find the User Address from BV_USER_PROFILE table
     * 
     * @param userName
     * @return
     * @throws DAOException
     *             Address
     */
    public Address findUserAddress(Integer userID) throws DAOException {
        logger.info("findUserAddress(String userName)method begin");

        Address address = null;

        try {

            Object[] parameters = new Object[] { userID };
            // List result =null;
            List result = getJdbcTemplate().query(
                    SQLConstants.USER_ADDRESS_FINDER, parameters,
                    new AddressRowMapper());
            logger.info("Record size: " + result.size());

            if (result != null && result.size() == 1) {
                address = ((Address) result.get(0));
            }

        } catch (DataAccessException ex) {

            
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, ex);


        }
        if (logger.isDebugEnabled()) {
            logger.debug("Address :  " + address);
        }
        logger.info("findUserAddress(String userName): method");
        return address;
    }

    /**
     * TODO find the User profile table
     * 
     * @param userId
     * @return
     * @throws DAOException
     *             UserProfile
     */
    
    //shanta
    public UserProfile findUserProfile(String userName, String corporateId){
    	UserProfile userprofile = null;
        try {
            UserProfile profile = (UserProfile) userSessionCache.getData(userName + DAOConstants.USER_PROFILE);
            if (profile != null) {
                return profile;
            } else {
                logger.info("setting the username parameter for user:"+userName);
                Object[] parameters = new Object[] { userName ,corporateId };
                int sqlType[] = { Types.VARCHAR, Types.VARCHAR };//shanta
                logger.info("Corporate Id : " + corporateId);
                logger.info("executig query " + parameters);
                List result = getJdbcTemplate().query(
                        USER_PROFILE_FINDERS, parameters,
                        sqlType,new UserProfileRowMapper());
                logger.info("Record size : " + result.size());
                if (result != null && result.size() == 1) {
                    userprofile = (UserProfile) result.get(0);
                    userSessionCache.setData(userName+ DAOConstants.USER_PROFILE, userprofile);
                }
            }
        } catch (Exception ex) {
            Object[] errorParams={userName};
            DAOException.throwException(ex,"LOG015",errorParams);//unabel to get user profile details
        }
        if (logger.isDebugEnabled()) {
            logger.debug("User profile: " + userprofile);
        }
        return userprofile;
    }
    
    //shanta
    
     /*Mobile No updation - Start*/
    public UserProfile findUserProfileDetails(String userName, String corporateId){
    	UserProfile userprofile = null;
    	logger.info("findUserProfileDetails userName :"+userName+"corporateId :"+corporateId);
        try {
           
                logger.info("setting the username parameter for user:"+userName+"corporateId ::"+corporateId);
                Object[] parameters = new Object[] { userName ,corporateId };
                int sqlType[] = { Types.VARCHAR, Types.VARCHAR };//shanta
                logger.info("Corporate Id : " + corporateId+"userName :"+userName);
                logger.info("executig query " + parameters);
                List result = getJdbcTemplate().query(
                        FIND_USER_PROFILE_FINDERS, parameters,
                        sqlType,new ModifyUserProfileRowMapper());
                logger.info("Record size : " + result.size());
                if (result != null && result.size() == 1) {
                    userprofile = (UserProfile) result.get(0);
                    userSessionCache.setData(userName+ DAOConstants.USER_PROFILE, userprofile);
                }
          
        } catch (Exception ex) {
            Object[] errorParams={userName};
            DAOException.throwException(ex,"LOG015",errorParams);//unabel to get user profile details
        }
        if (logger.isDebugEnabled()) {
            logger.debug("User profile: " + userprofile);
        }
        return userprofile;
    }
    
    /*Mobile No updation - End*/

    
    public UserProfile findUserProfile(String userName) throws DAOException {
        UserProfile userprofile = null;
        try {
            UserProfile profile = (UserProfile) userSessionCache.getData(userName + DAOConstants.USER_PROFILE);
            if (profile != null) {
                return profile;
            } else {
                logger.info("setting the username parameter for user:"+userName);
                Object[] parameters = new Object[] { userName };
                logger.info("executig query " + parameters);
                List result = getJdbcTemplate().query(
                        USER_PROFILE_FINDER, parameters,
                        new UserProfileRowMapper());
                logger.info("Record size : " + result.size());
                if (result != null && result.size() == 1) {
                    userprofile = (UserProfile) result.get(0);
                    userSessionCache.setData(userName+ DAOConstants.USER_PROFILE, userprofile);
                }
            }
        } catch (Exception ex) {
            Object[] errorParams={userName};
            DAOException.throwException(ex,"LOG015",errorParams);//unabel to get user profile details
        }
        if (logger.isDebugEnabled()) {
            logger.debug("User profile: " + userprofile);
        }
        return userprofile;
    }

    public UserProfile updateProfile(List profileParamList, User user)
            throws DAOException {

        logger
                .info("updateProfile( List profileParamList,String userName )Method Begin ");
        if (logger.isDebugEnabled())
            logger.debug("profileParamList :" + profileParamList);
        logger.info("userName " + user);

        if (profileParamList == null || user == null) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        } else {
            int listSize = profileParamList.size();
            logger.info("List Size is " + listSize);
            Object[] param = new Object[listSize + 1];
            int[] sqlType = new int[listSize + 1];
            int counter = 0;
            String queryString = DAOConstants.EMPTY;
            boolean flag = true;
            String fieldName ="";
            for (counter = 0; counter < listSize; counter++) {
                Field dataForUpdateQuery = (Field) profileParamList
                        .get(counter);
                logger.info("Values in Field Object " + dataForUpdateQuery);
                 fieldName = dataForUpdateQuery.getFieldName();
                Object value = dataForUpdateQuery.getValue();
                int type = dataForUpdateQuery.getType();
                param[counter] = value;
                sqlType[counter] = type;
                if (flag) {
                    queryString = queryString + DAOConstants.EMPTY + fieldName
                            + DAOConstants.EQUAL + DAOConstants.BIND_VARIABLE;
                    flag = false;
                } else {
                    queryString = queryString + DAOConstants.COMA
                            + DAOConstants.SPACE + fieldName
                            + DAOConstants.EQUAL + DAOConstants.BIND_VARIABLE;
                }
            }

            queryString = queryString + ",LAST_MOD_TIME=sysdate";
 		// added for CR-106 
		if(fieldName.equals("transaction_password")) {
                queryString = queryString +",TRANS_PASSWORD_LAST_DATE=sysdate";
            }
            logger.info("Query String is " + queryString);
            param[counter] = user.getUserAlias();
            sqlType[counter] = Types.VARCHAR;
            String finalQuery = SQLConstants.UPDATE_BV_USER_PROFILE.replaceAll(
                    DAOConstants.TO_BE_REPLACED, queryString);
            logger.info("Final Query for Update is " + finalQuery);

            int noOfRowsUpdated = getJdbcTemplate().update(finalQuery, param,
                    sqlType);

            if (noOfRowsUpdated <= 0) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                
            }else{
                try
                {
                    insertProfileLog(user,profileParamList);
                }catch(Exception profilelogexception)
                {
                    logger.info("Exception occured while inserting into profile log",profilelogexception);
                }
            }
        }

        //Calling another method to get UserProfile Object   

        userSessionCache.removeData(user.getUserAlias()
                + DAOConstants.USER_PROFILE);
        UserProfile updatedUserProfile = findUserProfile(user.getUserAlias());
        if(updatedUserProfile != null)
        {
            updatedUserProfile.setUserIPaddress(user.getUserIPaddress());
        }

        logger
                .info("updateProfile( List profileParamList,String userName )Method End ");
        if (logger.isDebugEnabled())
            logger.debug("updatedUserProfile :" + updatedUserProfile);
        logger.info("Value returned by Method is true"+updatedUserProfile.getHomePhone());
        return updatedUserProfile;
    }

    /**
     * TODO Class for build the Row Mapper for User Profile Object
     * 
     * @version 1.0
     * @author Satyam Computer Services Ltd.,
     */
    class UserProfileRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            UserProfile profile = new UserProfile();
            Address address = new Address();
            profile.setNewspreference5(rs.getString("NEWS_PREFERENCE5"));	// Vasco Flag for Corporate Roles
            profile.setPasswordMode(rs.getString("PASSWORD_MODE")); //CR-5550-Immanuel
            profile.setName(rs.getString(DAOConstants.PROFILE_USER_NAME));
            profile.setBankCode(rs.getString(DAOConstants.BANK_CODE));
            profile.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            profile.setEmpNo(rs.getString(DAOConstants.EMP_NO));
            profile.setBusinessPhone(rs.getString(DAOConstants.BUS_PHONE));
            address.setCity(rs.getString(DAOConstants.CITY));
            address.setCountry(rs.getString(DAOConstants.COUNTRY));
            address.setPin(rs.getString(DAOConstants.ZIP));
            address.setAddress1(rs.getString(DAOConstants.ADDRESS));
            address.setState(rs.getString(DAOConstants.STATE));
            profile.setEmail(rs.getString(DAOConstants.EMAIL));
            profile.setHintAnswer(rs.getString(DAOConstants.HINT_ANSWER));
            profile.setHintQuestion(rs.getString(DAOConstants.HINT_QUESTION));
            profile.setHomePhone(rs.getString(DAOConstants.HOME_PHONE));
            profile.setLastLoginDate(rs
                    .getTimestamp(DAOConstants.LAST_LOGIN_DATE));
            profile.setLastTDateInternet(rs
                    .getTimestamp(DAOConstants.LAST_TDATE_INTERNET));
            profile.setPasswordChangeDate(rs
                    .getTimestamp(DAOConstants.PWD_CHANGED_DATE)); // Added By Siva
            profile.setLastTnameInternet(rs
                    .getString(DAOConstants.LAST_TNAME_INTERNET));
            profile.setLoginCount(new Integer(rs
                    .getInt(DAOConstants.LOGIN_COUNT)));
              profile.setSmsSecurity(new Integer(rs.getInt(DAOConstants.SMS_SECURITY)));
			 
            profile.setThirdPartyLimit(new Double(rs
                    .getDouble(DAOConstants.THIRDPARTY_LIMIT)));
            //Added for CR 2899 begins
            profile.setTaxTxnLimit(new Double(rs.getDouble("NEWS_PREFERENCE2")));
            //Added for CR 2899 ends
            profile.setTransactioLimit(new Double(rs
                    .getDouble(DAOConstants.INTERNET_BANK_TRANS_LIMIT)));
            profile.setProfilepassword(rs.getString(DAOConstants.PROFILE_PWD));
            profile.setUserType(new Integer(rs.getInt(DAOConstants.USER_TYPE)));
            profile.setFriendlyName(rs.getString(DAOConstants.FRIENDLY_NAME));
            profile.setCorporateId((rs.getString(DAOConstants.CORPORATE_ID)));
            profile.setSfAuthProvider(rs.getString("SF_AUTH_PROVIDER"));
            String mobileNumberCode = (rs.getString(DAOConstants.MOBILE_NO));
         
             //Added for SHA encryption algorithm - Start
            profile.setLoginHashing(rs.getString("LOGIN_PASSWORD_HASHING"));
            profile.setProfileHashing(rs.getString("PROFILE_PASSWORD_HASHING"));
            profile.setTransactionHashing(rs.getString("TXN_PASSWORD_HASHING"));
             //Added for SHA encryption algorithm - End
            String mobileNo = "";
            String coutryCode = "";
            String busContryCode="";
            if (mobileNumberCode != null && mobileNumberCode != ""
                    && mobileNumberCode.indexOf("|") > 0) {
                StringTokenizer token = new StringTokenizer(mobileNumberCode,
                        "|");
                if (token.hasMoreTokens())
                    coutryCode = token.nextToken();
                if (token.hasMoreTokens())
                    mobileNo = token.nextToken();
                profile.setMobileNumber(mobileNo);
            } else {
                profile.setMobileNumber(mobileNumberCode);
            }
            String businessPhoneCode = (rs.getString(DAOConstants.BUS_PHONE));
            String businessNo = "";
            if (businessPhoneCode != null && businessPhoneCode != ""
                && businessPhoneCode.indexOf("|") > 0) {
            StringTokenizer token = new StringTokenizer(businessPhoneCode,
                    "|");
            
            if (token.hasMoreTokens())
                busContryCode = token.nextToken();
            if (token.hasMoreTokens())
                businessNo = token.nextToken();
            profile.setBusinessPhone(businessNo);
            
            } else {
            profile.setBusinessPhone(businessPhoneCode);
            }
            profile.setCountryCode(coutryCode);
            profile.setBusinessPhoneCode(busContryCode);
            profile.setDesignation(rs.getString("DESIGNATION"));
            profile.setDistrict(rs.getString("DISTRICT"));
            profile.setDepartment(rs.getString("DEPARTMENT"));
            profile.setCorporateId(rs.getString("CORPORATE_ID"));
            profile.setUserId(new Integer(rs.getInt("USER_ID")));
            profile.setEmpNo(rs.getString("EMPLOYEE_NO"));
            profile.setCreatedBy(rs.getString("CREATED_BY"));
            profile.setAddress(address);
            profile.setTxnPassword(rs.getString("TRANSACTION_PASSWORD"));
            String fieldOfWork = rs.getString("FIELD_OF_WORK");
            if(fieldOfWork != null) {
            profile.setFieldOfWork(fieldOfWork);
            }
            profile.setMerchantOTP(rs.getString("MERCHANT_OTP"));
            profile.setSource(rs.getString("SOURCE"));
			//Added for SHA encryption algorithm -Start
            profile.setLoginHashing(rs.getString("LOGIN_PASSWORD_HASHING"));
            profile.setProfileHashing(rs.getString("PROFILE_PASSWORD_HASHING"));
            profile.setTransactionHashing(rs.getString("TXN_PASSWORD_HASHING"));
			//Added for SHA encryption algorithm -End
			
			//Added for Voice OTP
            if (rs.getString("otp_delivery_mode") != null ){
            	 profile.setOtpOption(rs.getString("otp_delivery_mode"));
            }else{
            	profile.setOtpOption("");
            } 
          //Added for Voice OTP
            
            profile.setIrctcEnable(rs.getString("IRCTC_ENABLE")); //Added for IRCTC OTP
            profile.setLastLoginfailureDate(rs.getTimestamp("LOCK_TIME"));
            
        
            return profile; 
        }
    }

 /**
     * TODO Class for build the Row Mapper for User Profile Object
     * 
     * @version 1.0
     * @author Satyam Computer Services Ltd.,
     */
    class ModifyUserProfileRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            UserProfile profile = new UserProfile();
            Address address = new Address();
            profile.setPasswordMode(rs.getString("PASSWORD_MODE")); //CR-5550-Immanuel
            profile.setName(rs.getString(DAOConstants.PROFILE_USER_NAME));
            profile.setBankCode(rs.getString(DAOConstants.BANK_CODE));
            profile.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            profile.setEmpNo(rs.getString(DAOConstants.EMP_NO));
            profile.setBusinessPhone(rs.getString(DAOConstants.BUS_PHONE));
            address.setCity(rs.getString(DAOConstants.CITY));
            address.setCountry(rs.getString(DAOConstants.COUNTRY));
            address.setPin(rs.getString(DAOConstants.ZIP));
            address.setAddress1(rs.getString(DAOConstants.ADDRESS));
            address.setState(rs.getString(DAOConstants.STATE));
            profile.setEmail(rs.getString(DAOConstants.EMAIL));
            profile.setHintAnswer(rs.getString(DAOConstants.HINT_ANSWER));
            profile.setHintQuestion(rs.getString(DAOConstants.HINT_QUESTION));
            profile.setHomePhone(rs.getString(DAOConstants.HOME_PHONE));
            profile.setLastLoginDate(rs
                    .getTimestamp(DAOConstants.LAST_LOGIN_DATE));
            profile.setLastTDateInternet(rs
                    .getTimestamp(DAOConstants.LAST_TDATE_INTERNET));
            profile.setPasswordChangeDate(rs
                    .getTimestamp(DAOConstants.PWD_CHANGED_DATE)); // Added By Siva
            profile.setLastTnameInternet(rs
                    .getString(DAOConstants.LAST_TNAME_INTERNET));
            profile.setLoginCount(new Integer(rs
                    .getInt(DAOConstants.LOGIN_COUNT)));
              profile.setSmsSecurity(new Integer(rs.getInt(DAOConstants.SMS_SECURITY)));
			 
            profile.setThirdPartyLimit(new Double(rs
                    .getDouble(DAOConstants.THIRDPARTY_LIMIT)));
            //Added for CR 2899 begins
            profile.setTaxTxnLimit(new Double(rs.getDouble("NEWS_PREFERENCE2")));
            //Added for CR 2899 ends
            profile.setTransactioLimit(new Double(rs
                    .getDouble(DAOConstants.INTERNET_BANK_TRANS_LIMIT)));
            profile.setProfilepassword(rs.getString(DAOConstants.PROFILE_PWD));
            profile.setUserType(new Integer(rs.getInt(DAOConstants.USER_TYPE)));
            profile.setFriendlyName(rs.getString(DAOConstants.FRIENDLY_NAME));
            profile.setCorporateId((rs.getString(DAOConstants.CORPORATE_ID)));
            String mobileNumberCode = (rs.getString(DAOConstants.MOBILE_NO));
            String newMobileNo = (rs.getString("new_mobile_no"));
            String mobileNo = "";
            String coutryCode = "";
            String busContryCode="";
            String tmpMobileNo = "";
            
            if (mobileNumberCode != null && mobileNumberCode != ""
                    && mobileNumberCode.indexOf("|") > 0) {
                StringTokenizer token = new StringTokenizer(mobileNumberCode,
                        "|");  
                if (token.hasMoreTokens())
                    coutryCode = token.nextToken();
                if (token.hasMoreTokens())
                    mobileNo = token.nextToken();
                
                profile.setMobileNumber(mobileNo);
            } else {
                profile.setMobileNumber(mobileNumberCode);
            }
            
            
            String tempNewMobileNo = rs.getString("NEW_MOBILE_NO");
            
            if(tempNewMobileNo != null && tempNewMobileNo != ""){
            String sptNewMobileNo[] = tempNewMobileNo.split("\\|");
            if(sptNewMobileNo.length == 2){
            	String newContryCode = sptNewMobileNo[0];
            	String newPhoneNo = sptNewMobileNo[1];
            	logger.info("newContryCode >>>"+newContryCode);
            	logger.info("newPhoneNo >>>>"+newPhoneNo);
            	profile.setNewMobileNumber(newPhoneNo);
            	profile.setNewCountryCode(newContryCode);
            }
            }
            
            logger.info("NewMobileNumber >>>"+profile.getNewMobileNumber());
            
            String businessPhoneCode = (rs.getString(DAOConstants.BUS_PHONE));
            String businessNo = "";
            if (businessPhoneCode != null && businessPhoneCode != ""
                && businessPhoneCode.indexOf("|") > 0) {
            StringTokenizer token = new StringTokenizer(businessPhoneCode,
                    "|");
            
            if (token.hasMoreTokens())
                busContryCode = token.nextToken();
            if (token.hasMoreTokens())
                businessNo = token.nextToken();
            profile.setBusinessPhone(businessNo);
           
           
            } else {
            profile.setBusinessPhone(businessPhoneCode);
            }
            profile.setCountryCode(coutryCode);
            profile.setBusinessPhoneCode(busContryCode);
            profile.setDesignation(rs.getString("DESIGNATION"));
            profile.setDistrict(rs.getString("DISTRICT"));
            profile.setDepartment(rs.getString("DEPARTMENT"));
            profile.setCorporateId(rs.getString("CORPORATE_ID"));
            profile.setUserId(new Integer(rs.getInt("USER_ID")));
            profile.setEmpNo(rs.getString("EMPLOYEE_NO"));
            profile.setCreatedBy(rs.getString("CREATED_BY"));
            profile.setAddress(address);
            profile.setTxnPassword(rs.getString("TRANSACTION_PASSWORD"));
            String fieldOfWork = rs.getString("FIELD_OF_WORK");
            if(fieldOfWork != null) {
            profile.setFieldOfWork(fieldOfWork);
            }
            return profile; 
        }
    }

    class UserRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            User user = new User();
            user.setUserAlias(rs.getString(DAOConstants.USER_ALIAS));
            user.setUserId(new Integer(rs.getInt(DAOConstants.USER_ID)));
            user.setUserState(Integer.toString(rs
                    .getInt(DAOConstants.USER_STATE)));

            return user;
        }
    }

    /**
     * TODO Class for build the Row Mapper for Address Object
     * 
     * @version 1.0
     * @author Satyam Computer Services Ltd.,
     */
    class AddressRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            Address address = new Address();
            address.setAddress1((String) rs.getString(DAOConstants.ADDRESS1));
            address.setCity((String) rs.getString(DAOConstants.CITY));
            address.setCountry((String) rs.getString(DAOConstants.COUNTRY));
            address.setState((String) rs.getString(DAOConstants.STATE));
            address.setPin((String) rs.getString(DAOConstants.PIN_CODE));
            return address;
        }
    }

    class RolesRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            return new Integer(rs.getInt(DAOConstants.USER_ROLE));
        }
    }

    public void setUserSessionCache(UserSessionCache userSessionCache) {
        this.userSessionCache = userSessionCache;
    }

    private String getUserProfileFieldValue(String dbFieldName,
            UserProfile profile) {
        logger.info("DBFieldName  = "+dbFieldName);
        if (dbFieldName.equalsIgnoreCase(Constants.EMAIL))
        {
            String oldEmail = profile.getEmail();
            if(oldEmail != null)
                return oldEmail.toString();
            else
                return "";
        }
        if (dbFieldName.equalsIgnoreCase(Constants.FRIENDLY_NAME))
            return profile.getFriendlyName();
        if (dbFieldName.equalsIgnoreCase(Constants.HOME_PHONE))
            return profile.getHomePhone();
        if (dbFieldName.equalsIgnoreCase(Constants.INTERNET_BANK_TRANSACTION_LIMIT))
        {
            Double ddLimit = profile.getTransactioLimit();
            String returnValue ;
            if(ddLimit != null)
                returnValue = ddLimit.toString();
            else
                returnValue = "0";
            return returnValue;
        }
        if (dbFieldName.equalsIgnoreCase(Constants.THIRDPARTY_LIMIT))
        {
            Double tpLimit = profile.getThirdPartyLimit();
            String returnValue ;
            if(tpLimit != null)
                returnValue = tpLimit.toString();
            else
                returnValue = "0";
            return returnValue;
        }
        if (dbFieldName.equalsIgnoreCase(Constants.MOBILE_NO))
        {
            logger.info("Profile = "+profile.getMobileNumber());
            return profile.getMobileNumber();
        }
        
        // TODO  - ashok Modified for GVF-forGot Password... start
        
        if(Constants.STATE.equalsIgnoreCase(dbFieldName)){
        	 return profile.getAddress().getState();
        }
        
		if (Constants.CITY.equalsIgnoreCase(dbFieldName)) {
			return profile.getAddress().getCity();
		}
        
        if(Constants.DISTRICT.equalsIgnoreCase(dbFieldName)){
        	return profile.getDistrict();
        }
        if(Constants.ADDRESS.equalsIgnoreCase(dbFieldName)){
        	return profile.getAddress().getAddress1();
        }
        
        if(Constants.ZIP.equalsIgnoreCase(dbFieldName)){
        	return profile.getAddress().getPin();
        }
        
        if(Constants.HINT_QUESTION.equalsIgnoreCase(dbFieldName)){
        	return profile.getHindQuestion();
        }
        
        if(Constants.HINT_ANSWER.equalsIgnoreCase(dbFieldName)){
        	return profile.getHintAnswer();
        }
        
     // TODO  - ashok Modified for GVF-forGot Password End...
        
        return DAOConstants.EMPTY;
    }

    private boolean insertProfileLog(User user, List profileParamList) {
        try{
            logger.info("insertProfileLog method begin");
            int listSize = profileParamList.size();
            logger.info("No of records to be inserted : " + listSize);
            logger.info("List Size is " + listSize);
            Object[] param = null;
            UserProfile profile = findUserProfile(user.getUserAlias());
            int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
            /*BatchSqlUpdate profileLogInsert = new BatchSqlUpdate(getDataSource(),
                    SQLConstants.PROFILE_LOG_QUERY);
            profileLogInsert.declareParameter(new SqlParameter("username",Types.VARCHAR));
            profileLogInsert.declareParameter(new SqlParameter("ip",Types.VARCHAR));
            profileLogInsert.declareParameter(new SqlParameter("fieldname",Types.VARCHAR));
            profileLogInsert.declareParameter(new SqlParameter("oldvalue",Types.VARCHAR));
            profileLogInsert.declareParameter(new SqlParameter("newvalue",Types.VARCHAR));
            profileLogInsert.setBatchSize(listSize);*/
            logger.info("profile object " + profile);
            for (int counter = 0; counter < listSize; counter++) {
                Field field = (Field) profileParamList.get(counter);
                param = new Object[] { user.getUserAlias(),
                        user.getUserIPaddress(), field.getFieldName(),
                        getUserProfileFieldValue(field.getFieldName(), profile),
                        field.getValue() };
            //    profileLogInsert.update(param);
           int status =   getJdbcTemplate().update("insert into sbi_profile_changelog fields(user_name,ip_address,mod_time,mod_item,old_data,new_data) values(?,?,sysdate,?,?,?)",param,sqlTypes);
           logger.info( " Row affected ***********" + status );      
            }
           // logger.info("No of records actually inserted : " + profileLogInsert.getRowsAffected());
        }catch(DataAccessException ex){
            
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, ex);
            
        }
        return true; 
    }
    
    	//public boolean validateLogin(String userName, String password) throws DAOException{ //by nag
    	public boolean validateLogin(String userName, String password, String keyString) throws DAOException{//by nag
        boolean loginStatus = false;
        try{
            Object[] params={userName};      
            String encPassword=(String)getJdbcTemplate().queryForObject("select password from bv_user where user_alias=? and user_state =0",params,String.class);
            
            //by nag start
            if(keyString != null && keyString.length()>0){
            loginStatus = EncryptMD5.verifyHash(encPassword+ "#" + keyString,password);//Nag
            //loginStatus = EncryptMD5.verifyHash( userName+ "#" + password ,encPassword);
            }
            else{
                loginStatus = EncryptMD5.verifyHash(userName+ "#" + password,encPassword);//Nag
            }
            //by nag end
            
            logger.info("loginStatus :"+loginStatus);
        }catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
            Object[] errorParams={userName};
            DAOException.throwException(incorrectResultSizeDataAccessException,"LOG016",errorParams);// Unable to get the password
        }
        catch(DataAccessException dataAccessException){
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG012",errorParams);// Unable to get the password
        }
        return loginStatus;
    }
    
    	//public boolean validateLogin(String userName, String password) throws DAOException{ //by nag
    	public boolean validateLogin(String userName, String password, String keyString,String sha2Password, String hashingType) throws DAOException{//by nag
        boolean loginStatus = false;
		//Added for SHA encryption algorithm
        String typeSha = "SHA-512";
        Object[] parameters={sha2Password, userName};  
        Object[] userprofileParam={typeSha, userName};
        try{
            Object[] params={userName};      
            String encPassword=(String)getJdbcTemplate().queryForObject("select password from bv_user where user_alias=? and user_state =0",params,String.class);
            
          // String encType =(String)getJdbcTemplate().queryForObject("select LOGIN_PASSWORD_HASHING from bv_user_profile where user_id in ( select user_id from bv_user where user_alias=? ) ",params,String.class);
            //added for sha2
            logger.info("hashingType>>>>>"+hashingType);
            logger.info("encPassword>>>>>"+encPassword);
            logger.info("sha2Password>>>>>"+sha2Password);
           if(hashingType!=null && hashingType.trim().equalsIgnoreCase("SHA-512"))
           {
	       	  if(keyString != null && keyString.length()>0){
					loginStatus =requestResponseService.validateHashSHA2(sha2Password,encPassword+ "#" + keyString);
	       	  }
	       	  else{
	                loginStatus = requestResponseService.validateHashSHA2(encPassword,userName+ "#" + password);//Nag
	       	  }
           }
           else  {	          	
	            //by nag start
	            if(keyString != null && keyString.length()>0){
	            loginStatus = EncryptMD5.verifyHash(encPassword+ "#" + keyString,password);//Nag
	            System.out.println("loginStatus"+ loginStatus);
	            }
	            else{
	                loginStatus = EncryptMD5.verifyHash(userName+ "#" + password,encPassword);//Nag
	            }
            }     
	                                 
            logger.info("loginStatus :"+loginStatus);
        }catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
            Object[] errorParams={userName};
            DAOException.throwException(incorrectResultSizeDataAccessException,"LOG016",errorParams);// Unable to get the password
        }
        catch(DataAccessException dataAccessException){
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG012",errorParams);// Unable to get the password
        }
        return loginStatus;
    }
    
    public void changeLoginPassword(User user, String oldPassword, String newPassword) throws DAOException{
        userObj=user;
        password=newPassword;
        try{
            transactionTemplate.execute(new TransactionCallback(){
                public Object doInTransaction(TransactionStatus transactionStatus){
                    try{
                        updatePassword(userObj.getUserAlias(),password,userObj.getUserIPaddress());
                    }catch(DataAccessException e){
                        transactionStatus.setRollbackOnly();
                        Object[] errorparams={userObj.getUserAlias(),userObj.getUserIPaddress()};
                        DAOException.throwException(e,"LOG008",errorparams);// unable to update the password.
                    }
                    return null;
                }
            }
            );
        }
        catch(DataAccessException dataAccessExcp){
            Object[] errorparams={userObj.getUserAlias(),userObj.getUserIPaddress()};
            DAOException.throwException(dataAccessExcp,"LOG008",errorparams);// unable to update the password.
        }
    } 
     
    public void changeUserNamePassword(String userName, String oldUserName, String newPassword) throws DAOException{
        newUserName=userName;
        oldUser=oldUserName;
        password=newPassword;
        try{
            transactionTemplate.execute(new TransactionCallback(){
                public Object doInTransaction(TransactionStatus transactionStatus){
                    try{
                        updateUserName(oldUser, newUserName);
                        updatePassword(newUserName,password," ");
                    }catch(DataAccessException e){
                        transactionStatus.setRollbackOnly();
                        Object[] errorparams={newUserName,oldUser};
                        DAOException.throwException(e,"LOG017",errorparams);// unable to update the username and password.
                    }
                    return null;
                }
            }
            );
        }
        catch(DataAccessException dataAccessExcp){
            Object[] errorparams={newUserName,oldUser};
            DAOException.throwException(dataAccessExcp,"LOG017",errorparams);// unable to update the username and password.
        }
    } 
    public String updateUserName(String oldUserName, String newUserName) throws DAOException{
        logger.info("updateUserName(String oldUserName, String newUserName)"+LoggingConstants.METHODBEGIN);
        
        Map inParams = new HashMap();
        
        inParams.put("OLD_USERNAME",oldUserName);
        inParams.put("NEW_USERNAME",newUserName);
        logger.info("inParams ="+inParams);
        List parameterList = new ArrayList();
        parameterList.add(new SqlParameter("OLD_USERNAME", Types.VARCHAR));
        parameterList.add(new SqlParameter("NEW_USERNAME", Types.VARCHAR));
        parameterList.add(new SqlOutParameter("RESULT", Types.VARCHAR));   
        Map result = null;
        String output=null;
        try{

            CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory("{call CHANGE_LOGIN.CHANGE_USERNAME(?,?,?)}", parameterList);
            CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);
            result = getJdbcTemplate().call(callableStatement, parameterList);
            output = (String) result.get("RESULT");
            logger.info("output ="+output);
                            
        }catch(Exception daoExp){
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, daoExp);
        }
        logger.info("updateUserName(String oldUserName, String newUserName)"+LoggingConstants.METHODEND);
        return output;
    }
    
    
    public String secretKeyGenerator(String randomNo) throws DAOException{
        logger.info("secretKeyGenerator(String randomNo) "+LoggingConstants.METHODBEGIN);
        
        logger.info("randomNo :"+randomNo);
        
        String secretKey = "";
        if(randomNo != null && randomNo.trim().length() > 0){       
            try{            
            
                Object[] params = new Object[] { randomNo };
            
                Map secretKeyMap = getJdbcTemplate().queryForMap(SQLConstants.SECRET_KEY_GENERATOR,params);
                
                if(logger.isDebugEnabled())
                    logger.debug("secretKeyMap :"+secretKeyMap);
                
                if(secretKeyMap.size() > 0){
                    secretKey = (String)secretKeyMap.get("KEY");
                }
                
                logger.info("secretKey :"+secretKey);           
            
            }catch(DataAccessException daoExp){
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, daoExp);
            }
        }else{
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        
        logger.info("secretKeyGenerator(String randomNo) "+LoggingConstants.METHODBEGIN);
        return secretKey;
    }
     
    // added for caadmin
    
    public boolean isUserExists(String userName){
        
        logger.info("findUser(String userName)"+LoggingConstants.METHODBEGIN);
        boolean test=true;
        try{
                if(userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY))
                {
                    Object[] parameters = new Object[] {userName}; 
                    List result =getJdbcTemplate().queryForList(FIND_USER,parameters);
                    if(result!=null && result.size()>0)
                        test=true;
                        else
                            test=false;
                        
                }
                
        } catch (DataAccessException dex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dex);
        }catch(Exception ex){
            DAOException.throwException( ErrorConstants.FATAL_ERROR1_CODE,ex );
        }
        logger.info("findUser(String userName)"+LoggingConstants.METHODEND);    
        return test;
        
    }
    

     
    public Map addUser(UserProfile userProfile,String role, List AuditAccMapList,String pwd)throws DAOException{
        logger.info("addUser(UserProfile userProfile,String role)"+LoggingConstants.METHODBEGIN);
        logger.info("userProfile ::"+userProfile.getName()+"|"+userProfile.getFriendlyName()+"|"+userProfile.getAddress().getAddress1()+"|"+userProfile.getAddress().getCity()+"|"+userProfile.getAddress().getState()+"|"+userProfile.getAddress().getCountry()+"|"+userProfile.getHomePhone()+"|"+userProfile.getEmail()+"|"+userProfile.getEmpNo()+"|"+userProfile.getDepartment()+"|"+userProfile.getDesignation()+"|"+userProfile.getBankCode()+"|"+userProfile.getBranchCode()+"|"+userProfile.getBranchCode()+"|"+userProfile.getCorporateId()+"|"+userProfile.getUserName()+"|"+userProfile.getCreatedBy()+"|"+userProfile.getCreatedBy()+"|"+userProfile.getCreatedBy()+"|"+userProfile.getSource());
        logger.info("role ::"+role);
        Map returnMap = new HashMap();
        List inparams = new ArrayList();
        List outparams = new ArrayList();
        Field userProfObj = new Field();
        Field corpAccount = new Field();
        Field corpAccount1 = new Field();
        Field output1 = new Field();
        Field output2 = new Field();
        Field output3 = new Field();
        HashMap h1 = new HashMap();
        if( role!=null )
        {
            try
            {   

               Object[] inp={new Integer(27),// not taken in proc
                       userProfile.getName(),
                       userProfile.getFriendlyName(),
                       userProfile.getAddress().getAddress1(),
                       userProfile.getAddress().getCity(),
                       userProfile.getAddress().getState(),
                       userProfile.getAddress().getCountry(),
                       userProfile.getAddress().getPin(),
                       userProfile.getHomePhone(),
                       userProfile.getEmail(),
                       userProfile.getEmpNo(),
                       userProfile.getDepartment(),
                       userProfile.getDesignation(),
                       userProfile.getBankCode(),
                       userProfile.getBranchCode(),
                       userProfile.getBranchCode(),//it accepts branch name since not available branch code is set 
                       userProfile.getCorporateId(),
                       userProfile.getUserName(), // randomly generated.
                       userProfile.getCreatedBy(),// from session user.getuseralias()
                       userProfile.getCreatedBy(),
                       userProfile.getCreatedBy(),
                       userProfile.getSource(),
					   //userProfile.getSmsSecurity(),//Added for mobile Registration Phase 2
                       };
               // SumStoredProcedure sproc = new SumStoredProcedure(getJdbcTemplate(), "PKG_ADDING_USER.PR_INSERT");
                //logger.info("SMSSECURITY"+userProfile.getSmsSecurity());                                
               userProfObj.setFieldName("OBJ_CORP_USER");
                        userProfObj.setType(UtilsConstant.ORACLE_OBJECT);
                        userProfObj.setValue(inp);
                 
                Field param2 = new Field();
                param2.setFieldName("P_ROLE");
                param2.setType(UtilsConstant.ORACLE_VARCHAR);
                param2.setValue(role);
                
                Field parampwd = new Field();
                parampwd.setFieldName("PWD");
                parampwd.setType(UtilsConstant.ORACLE_VARCHAR);
                parampwd.setValue(pwd);
                
                Object[] param3 = null;
                List param4 = new ArrayList();
                if(role.equals("9"))
                {
                    logger.info("size "+AuditAccMapList.size());
                    if (AuditAccMapList == null || AuditAccMapList.size() ==0)
                    {
                        Object[] paramTemp={"","","","",new Integer(1),new Integer(1),new Integer(1),"",new Integer(10),new Integer(1)};
                        param3 = paramTemp; 
                    }
                    else
                    {
                    for(int i=0;i<AuditAccMapList.size();i++ ){
                        logger.info("AuditAccMapList : " + AuditAccMapList + " i : " + i);
                        AuditAccMap auditAccMap = (AuditAccMap) AuditAccMapList.get(i); 
                        Object[] paramTemp = {auditAccMap.getAccountNo(),
                                auditAccMap.getBranchCode(),
                                auditAccMap.getCaUser(),
                                auditAccMap.getUserName(),
                                auditAccMap.getMaxUnauditedCount(),                                
                                auditAccMap.getMaxUnauditedAmount(),
                                new Integer("1"),
                                "",
                                new Integer("5"),
                                new Integer("0")
                                };   
                        param4.add(paramTemp);
                        auditAccMap=null;                        
                    }  
                    }
                }
                else{
                    Object[] paramTemp={"","","","","","","","","","",new Integer(10),""};
                    param3 = paramTemp;  
                    param4.add(param3);
                }
                
                
                logger.info("param4 :"+param4);
                if (role.equals("9"))
                {
                     
                    corpAccount1.setFieldName("COL_AUDIT_ACCOUNT");
                    corpAccount1.setType(UtilsConstant.ORACLE_TABLE);
                    corpAccount1.setValue(param4);
                    corpAccount1.setKey("OBJ_AUDIT_ACCOUNT_MAP");
                }
                else
                {
                corpAccount1.setFieldName("COL_CORP_ACCOUNT");
                corpAccount1.setType(UtilsConstant.ORACLE_TABLE);
                corpAccount1.setValue(param4);
                corpAccount1.setKey("OBJ_CORP_ACCOUNT");              
                
                corpAccount.setFieldName("COL_CORP_ACCOUNT");
                corpAccount.setType(UtilsConstant.ORACLE_TABLE);
                corpAccount.setValue(null);
                corpAccount.setKey("OBJ_CORP_ACCOUNT");                
                }
                inparams.add(userProfObj);
                if (!role.equals("9"))
                {
                    logger.info("insdie");
                    inparams.add(param2);
                }
                inparams.add(corpAccount1);
                inparams.add(parampwd);
                
                
                
                output1.setFieldName("P_ERR_MSG");
                output1.setType(UtilsConstant.ORACLE_VARCHAR);
                
                output2.setFieldName("P_ERR_CODE");
                output2.setType(UtilsConstant.ORACLE_VARCHAR);
                
                output3.setFieldName("P_LINE");
                output3.setType(UtilsConstant.ORACLE_VARCHAR);
                if (!role.equals("9"))
                {
                outparams.add(corpAccount);
                }
                outparams.add(output1);
                outparams.add(output2);
                outparams.add(output3);
                
                h1.put(UtilsConstant.SP_INPUT,inparams);
                h1.put(UtilsConstant.SP_OUTPUT,outparams);
                logger.info("outpata"+outparams.size());
                logger.info("inparams"+inparams.size());
                ExecuteStoredProcedure sproc;
                if (role.equals("9"))
                {
                	logger.info("procedure PKG_ADDING_USER.PR_CONST_AUDIT_ROLE calling");
                     sproc = 
                        new ExecuteStoredProcedure(getJdbcTemplate(),"PKG_ADDING_USER.PR_CONST_AUDIT_ROLE ", h1);
                }
                else
                {
                	logger.info("procedure PKG_ADDING_USER.PR_INSERT calling");
                    sproc = 
                    new ExecuteStoredProcedure(getJdbcTemplate(),"PKG_ADDING_USER.PR_INSERT", h1);
                }
                Map result = sproc.execute(inparams);
                SPOutput spOutput = new SPOutput();
                spOutput.setErrorCode((String) result.get("P_ERR_CODE"));
                spOutput.setErrorMessage((String) result.get("P_ERR_MSG"));
                String line = (String) result.get("P_LINE");
                logger.info("spOutput error code :" + spOutput.getErrorCode());
                if (logger.isDebugEnabled())
                {
                    logger.debug("spOutput :" + spOutput);
                }
                
                if(!(spOutput.getErrorCode().equalsIgnoreCase("SP999"))){
                    logger.info("insertBillSchedule(BillPaymentSchedule billPaymentSchedule, Timestamp scheduleDate) "+LoggingConstants.METHODEND);
                    returnMap.put("userProfile",userProfile);
                    returnMap.put("line",line);
                    logger.info("CA USER : "  + userProfile.getCreatedBy());
                    if(userProfile.getTypeOfUser() != null && (userProfile.getTypeOfUser().equalsIgnoreCase("ddebituser") || userProfile.getTypeOfUser().equalsIgnoreCase("corpddebituser"))){
                    	updateAccessRights(userProfile.getCreatedBy(),userProfile.getUserName(),userProfile.getTypeOfUser(),userProfile.getAccRights());
                    }
                    return returnMap;
                    
                }else{
                    logger.info(LoggingConstants.EXCEPTION + spOutput.getErrorCode());
                    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                }
            }
            catch(DataAccessException daexp){
            	logger.error("DataAccessException occured: "+daexp);
            	daexp.printStackTrace();
            }
            catch (Exception exception)
            {
            	exception.printStackTrace();
            	logger.fatal(LoggingConstants.EXCEPTION, exception);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
            }
            }else{
                
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
            return null; 
        }
    
    public boolean findUserByEmpNo(String empNo) throws DAOException {
        logger.info(" findUserByEmpNo(String empNo) begin");
        boolean test=false;
        try {

            Object[] parameters = new Object[] { empNo }; 
            List result = getJdbcTemplate().queryForList("select * from bv_user_profile where EMPLOYEE_NO=?",parameters);
            logger.info("result"+result);
            if (result != null && result.size() > 0) {
                logger.info("valid User:" + result.get(0));
                logger.info("findUserByEmpNo(String empNo) method end");
               test= true;
             } else{
                 test=false;
             }
        } catch (DataAccessException ex) {
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
       return test;
    }
    

    /*
     *  (non-Javadoc)
     * @see com.sbi.common.dao.UserDAO#changeCorporateUserName(java.lang.String, java.lang.String)
     * Method to change corporate username on first time login
     */
    public boolean changeCorporateUserName(String userName, String oldUserName, String password) throws DAOException{
        logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODBEGIN);
        boolean retVal = false;    
        Object[] inParameter = new Object[]{userName, oldUserName,};
        int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR};
       try{
           logger.info("old username = " + oldUserName + "  new username = " + userName);
           int status =  getJdbcTemplate().update(INSERT_CORPUSER_MAP_HISTORY,inParameter,sqlTypes);
           logger.info("Insert into sbicorp_user_map_history " + status);
           if(status == 1){
               updatePassword(userName,password,"");
               retVal = true;
           }
            
       }
       // added by KarthiK for CR NO:2013 - start
       catch (DataIntegrityViolationException dataIntegrityViolationException) 
       {
         dataIntegrityViolationException.printStackTrace();		
         logger.info("inside DataIntegrity Violation Exception");
         if (dataIntegrityViolationException.getMessage().toUpperCase().indexOf("UNIQUE") > 0)
         {
        	 logger.info("inside the if condition DataIntegrity Violation Exception");
        	 DAOException.throwException(ErrorConstants.UNIQUE_CONSTRAIN_EXCEPTION_ERRORCODE);
         }
       }
       // end 
       catch(DataAccessException dataAccessExcp)
       {
    	   logger.error("Exception occured during to insert the data into sbicorp_user_map_history **",dataAccessExcp);
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);           
       }
       logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODEND);
       return retVal;
    }
  
    public void insertLoginTime(User user, String sessionId, String loginStatus,String serverName){  //Changed for CR 951
        try{
            Object[] parameters = new Object[] {user.getUserAlias(),user.getUserIPaddress(),"Active", sessionId, loginStatus,serverName};
            int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
            getJdbcTemplate().update(SQLConstants.INSERT_LOGIN_TIME, parameters,sqlTypes);
            logger.info("Record inserted to sbi_user_login");
        }catch(DataAccessException daoExp){
            logger.error("Unable to insert to sbi_user_login for " + user.getUserAlias());
            logger.error("exception is " + daoExp);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
        }
     } 
     
     /**
      * This method will return true if the locked flag in the database is 1.
      * Otherwise it will return false.  
      */
    
     public boolean getLockStatus(String userName){
         //String query="select count(user_id) from bv_user_profile  where user_id in (select user_id from bv_user where user_alias=?) and (sysdate - decode(lock_time,'',sysdate-2,lock_time))>=1";
         String query="select count(user_id) from bv_user_profile  where user_id in (select user_id from bv_user where user_alias=?) and lock_flag='Y'";
         Object[] params={userName};
         try{
             int lockStatus=getJdbcTemplate().queryForInt(query,params);
             if(lockStatus > 0)
                 return true;
         }catch(DataAccessException dataAccessException){
             Object[] errorParams={userName};
             DAOException.throwException(dataAccessException,"LOG010",errorParams);//unable to ge the lock status.
         }
         return false;
     }
    
     /**
     * This method will throw exception if the password type in bv_user_profile is "J"(JAVA).
     * Other wise it return's false. 
     */
     
     public String getPasswordType(String userName){
         String passwordType="";
         Object[] params={userName};
         String query="select password_mode from bv_user_profile where user_id in (select user_id from bv_user where user_alias=?)";
         try{
             passwordType=(String)getJdbcTemplate().queryForObject(query,params,String.class);
         }catch(DataAccessException dataAccessException){
             Object[] errorParams={userName};
             DAOException.throwException(dataAccessException,"LOG009",errorParams);// Unable to get the password Type.
         }
         return passwordType;
     }
     
     /**
      * This method will throw exception if the Name not in tmp_bv_user_passwordchanged.
      * Other wise it return's integer count. 
      */
     
     public Integer validatePwdIssue(String userName){
         int count=0;
         Object[] params={userName};
         String query="select count(1) from tmp_bv_user_passwordchanged where user_alias =?"; 
         logger.info("query:"+query);
         try{
             count=getJdbcTemplate().queryForInt(query,params);
             
         }catch(DataAccessException dataAccessException){
             Object[] errorParams={userName};
             DAOException.throwException(dataAccessException,"LOG011",errorParams);// Unable to get the name.
         }
         return new Integer(count);
     }
     
     /**
      * Whenever the user sucessfully logged in through BroadVission,
      * this method will update the user password into bv_user and password type into bv_user_profile tables.
      */
     
     public void updatePassword(String name,String password,String ipAddress){
        String updatePassword="update bv_user set password=? where user_alias=?";
        String updatePasswordType="update bv_user_profile set password_mode='J',PWD_CHANGED_DATE=sysdate,LOGIN_PASSWORD_HASHING='SHA-512' where user_id in (select user_id from bv_user where user_alias=?)";//Modified for SHA encryption algorithm
        String encMD5Password=EncryptMD5.hashMessage(name + "#" + password);
        String encPassword=sha512Hashing.hashingSHA2(name + "#" + password);//Added for SHA encryption algorithm
        Object[] passwordParams={encPassword,name};
        getJdbcTemplate().update(updatePassword,passwordParams);
        
        //Added for SHA -Start
        Object tempParams[] = new Object[] {name, encMD5Password};
		int tempSqlTypes[] = {Types.VARCHAR, Types.VARCHAR};
		String tempSql = "insert into bv_user_temp_password(username, password,creation_time) values (?,?,sysdate)";
		int tempUpdateCount = getJdbcTemplate().update(tempSql, tempParams, tempSqlTypes);
		logger.info("no of rows inserted in bv_user_temp_password table"+tempUpdateCount);
        //Added for SHA -End
		
        Object[] typeParams={name};
       // immanuel 5550 
        getJdbcTemplate().update(updatePasswordType,typeParams);
        Object[] inParameter = new Object[]{name,ipAddress,new String("LOGIN_PASSWORD")};
        int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
        getJdbcTemplate().update(SQLConstants.PROFILE_LOGIN_PASSWORD_LOG,inParameter,sqlTypes);
     }
     //CR 5550- Immanuel
     /*public void updatePasswordMode(String name,String password,String ipAddress){
         String updatePassword="update bv_user set password=? where user_alias=?";
         String updatePasswordType="update bv_user_profile set password_mode='J',PWD_CHANGED_DATE=sysdate where user_id in (select user_id from bv_user where user_alias=?)";
         String encPassword=EncryptMD5.hashMessage(name + "#" + password);
         Object[] passwordParams={encPassword,name};
         getJdbcTemplate().update(updatePassword,passwordParams);
         Object[] typeParams={name};
         getJdbcTemplate().update(updatePasswordType,typeParams);
         Object[] inParameter = new Object[]{name,ipAddress,new String("LOGIN_PASSWORD")};
         int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
         getJdbcTemplate().update(SQLConstants.PROFILE_LOGIN_PASSWORD_LOG,inParameter,sqlTypes);
      }*/
     //End CR 5550
    /**
     * This method will throw exception if the password type in bv_user_profile is "J"(JAVA).
     * Other wise it return's false. 
     */
     
    
    /********* Added for Direct Debit **********/
    public void updateAccessRights(String caUser,String userName,String userType,String accRights)throws DAOException{
    	String updateCAUserQuery = "UPDATE SBICORP_CA_USER_MAP SET USER_TYPE =?,DDEBIT_ACCESS_RIGHTS =? WHERE CA_USER=? AND USER_NAME=?";
    	Object[] params = {userType,accRights,caUser,userName};
    	try{
    		getJdbcTemplate().update(updateCAUserQuery,params);
    	}catch (DataAccessException e) {
			DAOException.throwException("DDU001",e);
		}
    }
    /********* Added for Direct Debit **********/
    //	CR 1808 - Reset login password using PPKIT - starts
    public String getKModeUserName(String userName){
        String kModeUserName="";
        Object[] params={userName};
        String query="select tmpl_style from bv_user_profile where user_id in (select user_id from bv_user where user_alias=?)";
        try{
        	kModeUserName=(String)getJdbcTemplate().queryForObject(query,params,String.class);
        }catch(DataAccessException dataAccessException){
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG009",errorParams);// Unable to get the password Type.
        }
        return kModeUserName;
    }
    //public boolean kModeValidateLogin(String userName, String password, String kModeUsername) throws DAOException{
    public boolean kModeValidateLogin(String userName, String password, String kModeUsername,String keyString) throws DAOException{ //by nag
		boolean loginStatus = false;
		try{
			Object[] params={userName};	
			logger.info("kModeUsername :"+kModeUsername);
			String encPassword=(String)getJdbcTemplate().queryForObject("select password from bv_user where user_alias=?",params,String.class);
			
			//by nag start
			if(keyString != null && keyString.length()>0){
			loginStatus = EncryptMD5.verifyHash( encPassword+ "#" + keyString ,password);
			}
			else loginStatus = EncryptMD5.verifyHash( kModeUsername+ "#" + password ,encPassword);
			//by nag end
			logger.info("kmode loginStatus :"+loginStatus);
		}catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
			Object[] errorParams={userName};
			DAOException.throwException(incorrectResultSizeDataAccessException,"LOG016",errorParams);// Unable to get the password
		}
		catch(DataAccessException dataAccessException){
			Object[] errorParams={userName};
			DAOException.throwException(dataAccessException,"LOG012",errorParams);// Unable to get the password
		}
		return loginStatus;
	}
	//	CR 1808 - Reset login password using PPKIT - ends

  // CR 2450 - to get user role and type
    public Map getUserRoleAndType(String userName)throws DAOException {
      	 Map result = null;
      	 //String query ="select c.user_role,b.user_type from bv_user a, bv_user_profile b, bv_user_role c WHERE a.user_alias = ? AND a.user_id = b.user_id AND a.user_id = c.user_id";
    	 String query ="select c.user_role,b.user_type,b.tmpl_style,b.LOGIN_PASSWORD_HASHING from bv_user a, bv_user_profile b, bv_user_role c WHERE a.user_alias = ? AND a.user_id = b.user_id AND a.user_id = c.user_id"; //by nag      	 
      	 Object[] params={userName};
           try{       	
          	 result =getJdbcTemplate().queryForMap(query,params); 
          	 logger.info("Map result - user role and type:"+result);
           }catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
   			Object[] errorParams={userName};
   			DAOException.throwException(incorrectResultSizeDataAccessException,"LOG016",errorParams);// CR 1788 - preprinted kit user - user role not available
   		}
            catch(DataAccessException dataAccessException){
               Object[] errorParams={userName};
               DAOException.throwException(dataAccessException,"LOG010",errorParams);
           }
           return result;
       }
// CR 2450 end

	//added for Anaklyn user Login check the user Active
	
	 public boolean checkUserLogin(String userName)
      throws DAOException
  {
      boolean loginStatus = false;
      try
      {
          Object params[] = {
              userName
          };
          String userState = (String)getJdbcTemplate().queryForObject("select user_state from bv_user where user_alias=?", params, java.lang.String.class);
          logger.info("userState" + userState);
          if(userState.equals("0"))
              loginStatus = true;
          else
              loginStatus = false;
          logger.info("loginStatus :" + loginStatus);
      }
      catch(DataAccessException dataAccessException)
      {
          Object errorParams[] = {
              userName
          };
          DAOException.throwException(dataAccessException, "LOG012", errorParams);
      }
      return loginStatus;
  }
	
     //Added for CR 5110
     public void updateUserLock(String userName){
        try{
            Object[] params = {userName};
            getJdbcTemplate().update(SQLConstants.UPDATE_USER_LOCK, params);
            logger.info("inside user lock");
          }catch(DataAccessException dataAccessException){
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG010",errorParams);
            logger.error("Exception is " + dataAccessException);
        }
       } 
	
     public void updateUserUnlock(String userName){ 
        try{
            Object[] params = {userName};
            getJdbcTemplate().update(SQLConstants.UPDATE_USER_UNLOCK, params); 
            logger.info("Inside user unlock");
        }catch(DataAccessException dataAccessException){
            Object[] errorParams={userName};
            DAOException.throwException(dataAccessException,"LOG010",errorParams);
            logger.error("Exception is " + dataAccessException);
        }
       }  
    public Map getUserLockPWDType(String userName)throws DAOException {
         Map result = null;
         String query ="SELECT b.layout_pref FROM bv_user a, bv_user_profile b WHERE a.user_alias = ? AND a.user_id = b.user_id ";
         Object[] params={userName};
            try{        
             result =getJdbcTemplate().queryForMap(query,params); 
            }catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
                Object[] errorParams={userName};
                DAOException.throwException(incorrectResultSizeDataAccessException,"LOG016",errorParams);// CR 1788 - preprinted kit user - user role not available
            }
             catch(DataAccessException dataAccessException){
                Object[] errorParams={userName};
                DAOException.throwException(dataAccessException,"LOG010",errorParams);
            }
            return result;
        }
    
    //  Added for CR 5143
    
    public List getUserRefs(String userName)throws DAOException
        {
           logger.info("getUserRefs( String userName);" + LoggingConstants.METHODBEGIN);
           logger.info("userName : " + userName);
           
           List userDetailList = null;
           if(userName != null && !"".equals(userName))
           {
               Object[] parameters = new Object[]{ userName };
               int sqlTypes[] ={ Types.VARCHAR};
               try{
                   userDetailList = getJdbcTemplate().queryForList(FIND_USER_REFS, parameters,sqlTypes);
                   logger.info("userDetailList size: "+userDetailList.size());
               } catch (DataAccessException ex) {

                   ex.printStackTrace();
                   DAOException.throwException("CU0002",new Object [] {userName});
                 }                        
           }
           else
           {//Input values are null
            DAOException.throwException("CU0001",new Object [] {userName});
           }
           logger.info("getUserRefs( String userName ) method ends");
       return userDetailList; 
       }
    
    // 	Added to insert into SBI_DISPATCH_PRINTING_DETAILS -CR 5143
    
    public int insertUserDispatchDetails(String seqNo,String message,String dispatchId,String module,String type){
        logger.info("insertUserDispatchDetails(String seqNo,String message,String dispatchId,String module,String type)- method begins");
		logger.info("TYPE::" + type);
		int result = 0;
		if (message != null && dispatchId != null) {
			try {
				Object params[] = new Object[] { seqNo, dispatchId, message,module, type };
				int sqlTypes[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR };
				String sql = "INSERT INTO SBI_DISPATCH_PRINTING_DETAILS(SERIAL_NO,DISPATCH_ID,MESSAGE,CREATION_TIME,LAST_MOD_TIME,MODULE,STATUS,TYPE) "
						+ "VALUES(?,?,?,sysdate,sysdate,?,'PENDING',?)";
				result = getJdbcTemplate().update(sql, params, sqlTypes);
				logger.info("value of result SBI_DISPATCH_PRINTING_DETAILS:: "  + result);
				logger.info("insertUserDispatchDetails(String seqNo,String message,String dispatchId,String module,String type)-  method ends");
			} catch (DataAccessException e) {
				DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, e);
			}
		} else
			DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE);

		return result;    
    }
    
    //  Added for CR 5143
    
    public String getDispatchSerialNo(String appandChar,String type)throws DAOException {
    	logger.info("getDispatchSerialNo(String appandChar,String type)- method begins");
        String serialNo=null;  
        String query ="SELECT '" + appandChar+ "'||"+type+"_PRINT_SEQ.NEXTVAL from dual";
         try{        
        	 serialNo =(String)getJdbcTemplate().queryForObject(query,String.class);
         }catch(DataAccessException dataAccessException){
           	DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE);
         }
         logger.info("getDispatchSerialNo(String appandChar,String type)- method ends");
         return serialNo;
         
    }

public int updateUserState(String userName, int userType) {
		// TODO Auto-generated method stub
		logger.info("updateUserState(String userName, int userType)- method begins");
		logger.info("usernamr and usertype"+userName+""+userType);
		 int count=0;  
		 Object params[] = new Object[] {userType ,userName };
	        String query ="update bv_user_profile set user_type = ? where user_id in (select user_id from bv_user where user_alias = ?)";
	         try{        
	        	 count = getJdbcTemplate().update(query, params);
	        	 logger.info("Count updated"+count);
	         }catch(DataAccessException e){
	        	 e.printStackTrace();
	           	DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE);
	         }
		
		logger.info("updateUserState(String userName, int userType)- method begins");
		return count;
	}


//Added for CR 5392  
public int getPhisingIPAddress(String ipAddress) throws DAOException{
	logger.info("getPhisingIPAddress(Map inParams)" + LoggingConstants.METHODBEGIN);
		 int count = 0;
		  try{
			  if(ipAddress != null){
			  Object[] object={ipAddress};
			  count=getJdbcTemplate().queryForInt("select count(*) from sbi_phishing_ips where PHISHING_IP=?  and upper(LOGIN_RESTRICTION)='Y'",object);
			  }
		  }catch(DataAccessException e){
			  logger.info("DataAccessException:: ",e);
			  DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE);
		  }
	logger.info("getPhisingIPAddress(Map inParams)" + LoggingConstants.METHODEND);
	return count;
}

public void insertPhishingUserDetails(User user,String userRole) {
	logger.info("insertPhishingUserDetails(User user)" + userRole+" "+LoggingConstants.METHODBEGIN);		
	String sql="INSERT INTO sbi_phishing_login(USER_NAME,IP_ADDRESS,ROLE,CREATION_TIME) " +
  			"VALUES(?,?,?,sysdate)";
	Object[] params={user.getUserAlias(),user.getUserIPaddress(),userRole};         
	getJdbcTemplate().update(sql,params);	
	logger.info("insertPhishingUserDetails(User user)" + LoggingConstants.METHODEND);
}
	  //End of CR 5392
    
		//Added For CR-5405 starts
		public void insertActiveUserLogin(Map inParams ) {
			logger.info("insertActiveUserLogin(Map inparamMap )" + LoggingConstants.METHODBEGIN);		
            logger.info("inParams.....module name"+inParams.get("moduleName")+"session id ..."+inParams.get("sessionId"));
			String insSql="INSERT INTO sbi_loggedin_users(USER_NAME,IP_ADDRESS,SERVER_NAME,MODULE_NAME,SESSION_ID) " +
		  			" VALUES(?,?,?,?,?)";
			
			String updSql = "update sbi_loggedin_users set user_name=? where SESSION_ID=? AND trim(USER_NAME)<>? ";
			try{
				
			// Added to avoid ORA-00001 
			  Object param1[] = { (String)inParams.get("userName") }; 	
			  int userCount = getJdbcTemplate().queryForInt("select count(*) from sbi_loggedin_users where user_name = ? ", param1); 
			  logger.info("userCount : " + userCount); 
			  if (userCount > 0) {
				  logger.info("User Already Loggedin : " + inParams.get("userName")); 
				  Object[] updParams = { (String) inParams.get("userName"),
						(String) inParams.get("sessionId"),
						(String) inParams.get("userName") };
				  int updCount = getJdbcTemplate().update(updSql, updParams);
				  logger.info("updCount :" + updCount);
				  if (updCount <= 0)
					  DAOException.throwException("DUP001");
			  } else {
				
				Object[] params={(String)inParams.get("userName"),
				(String)inParams.get("ip_address"),
				(String)inParams.get("serverName"),
				(String)inParams.get("moduleName"),
				(String)inParams.get("sessionId")};
				int sqlTypes[]={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
				int inscount=getJdbcTemplate().update(insSql,params,sqlTypes);
				logger.info("inscount :"+inscount);
			  }
			}catch(DataIntegrityViolationException dive){
				logger.error("dive :"+dive);
				Object[] updParams={(String)inParams.get("userName"),(String)inParams.get("sessionId"),(String)inParams.get("userName")};
				int updCount=getJdbcTemplate().update(updSql,updParams);
				logger.info("updCount :"+updCount);
				if(updCount <=0)
				DAOException.throwException("DUP001");
			}
				
			logger.info("insertActiveUserLogin(Map inparamMap )" + LoggingConstants.METHODEND);
		}
		
		public void deleteActiveUserLogin(String userName ) {
			  logger.info("deleteActiveUserLogin(String userName )" + LoggingConstants.METHODBEGIN);
			  String sql="delete from sbi_loggedin_users where user_name=?";
			  Object[] params={userName};
			  getJdbcTemplate().update(sql,params);
			  logger.info("deleteActiveUserLogin(String userName )" + LoggingConstants.METHODEND);	
			  
		}
	   //Added For CR 5405 Ends
		
	  //Added For CR 5472 Starts only for corporates
	    public String addUserPrePrintKit(UserProfile userProfile, String role) throws DAOException
	    {
	        logger.info("addUserPrePrintKit(UserProfile userProfile)" + LoggingConstants.METHODBEGIN);
	        logger.info("userProfile ::" + userProfile);
	        List inparams = new ArrayList();
	        List outparams = new ArrayList();
	        Field userProfObj = new Field();
	        Field output1 = new Field();
	        Field output2 = new Field();
	        Field output3 = new Field();
	        HashMap h1 = new HashMap();
	        String pp_id = new String();
	        try
	        {
	            Address address = userProfile.getAddress();
	            Object[] inp = { userProfile.getEmpNo(), userProfile.getName(), address.getAddress1(), address.getCity(),
	                    userProfile.getDistrict(), address.getState(), address.getCountry(), address.getPin(),
	                    userProfile.getEmail(), userProfile.getHomePhone(), userProfile.getDesignation(),
	                    userProfile.getDepartment(), role, userProfile.getCorporateId(), userProfile.getCreatedBy(),
	                    userProfile.getBranchCode(), "Pending", userProfile.getTypeOfUser(), userProfile.getAccRights()
	                    //userProfile.getSmsSecurity()
	                    };
	            // SumStoredProcedure sproc = new SumStoredProcedure(getJdbcTemplate(), "PKG_ADDING_USER.PR_INSERT");
	            //logger.info("SMS_Security in PPKIT"+userProfile.getSmsSecurity());
	            userProfObj.setFieldName("OBJ_PPKITS_USER");
	            userProfObj.setType(UtilsConstant.ORACLE_OBJECT);
	            userProfObj.setValue(inp);

	            inparams.add(userProfObj);
	            output1.setFieldName("P_ERR_MSG");
	            output1.setType(UtilsConstant.ORACLE_VARCHAR);

	            output2.setFieldName("P_ERR_CODE");
	            output2.setType(UtilsConstant.ORACLE_VARCHAR);

	            output3.setFieldName("PP_ID");
	            output3.setType(UtilsConstant.ORACLE_VARCHAR);

	            outparams.add(output1);
	            outparams.add(output2);
	            outparams.add(output3);

	            h1.put(UtilsConstant.SP_INPUT, inparams);
	            h1.put(UtilsConstant.SP_OUTPUT, outparams);
	            logger.info("outpata" + outparams.size());
	            logger.info("inparams" + inparams.size());
	            ExecuteStoredProcedure sproc;
	            sproc = new ExecuteStoredProcedure(getJdbcTemplate(), "PROC_INSERT_PPKITS_USERDETAILS", h1);

	            Map result = sproc.execute(inparams);

	            logger.info("resultttttttttttttttttttt ==" + result);

	            SPOutput spOutput = new SPOutput();
	            spOutput.setErrorCode((String) result.get("P_ERR_CODE"));
	            spOutput.setErrorMessage((String) result.get("P_ERR_MSG"));
	            pp_id = (String) result.get("PP_ID");
	            if (logger.isDebugEnabled())
	            {
	                logger.info("spOutput :" + spOutput);
	            }
	            logger.info("spOutput :" + spOutput);
	            logger.info("error code :" + spOutput.getErrorCode());
	            logger.info("error message :" + spOutput.getErrorMessage());

	            if ((spOutput.getErrorCode().equalsIgnoreCase("SP999")))
	            {
	                logger.info(LoggingConstants.EXCEPTION + spOutput.getErrorCode());
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	            }
	        }
	        catch (Exception exception)
	        {
	            logger.fatal(LoggingConstants.EXCEPTION, exception);
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
	        }

	        return pp_id;
	    }
	    public boolean findUserByEmpNo(String empNo,String corpId) throws DAOException {
	        logger.info(" findUserByEmpNo(String empNo,String corpId) begin");
	        boolean flag=false;
	        try {
	            Object[] parameters = new Object[] { empNo,corpId }; 
	            List result = getJdbcTemplate().queryForList("select * from bv_user_profile where EMPLOYEE_NO=? and CORPORATE_ID=?",parameters);	           
	            if (result != null && result.size() > 0) {
	            	logger.info("User Already Present :");
	            	flag= true;	             
	                }
	            else
	            	 flag=false;
	             
	        } catch (DataAccessException ex) {
	            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
	       return flag;
	    }
	    public boolean findUserByEmpNo(String empNo,String role,String caUser,String corpId) throws DAOException {
	        logger.info(" findUserByEmpNo(String empNo,String corpId) begin");
	        boolean flag=false;
	        try {
	            Object[] parameters = new Object[] { empNo,caUser,corpId,role }; 
	            List result = getJdbcTemplate().queryForList("Select NAME,USER_ALIAS from BV_USER a, BV_USER_PROFILE b ,BV_USER_ROLE c , SBICORP_CA_USER_MAP d ,SBICORP_CA_CORPORATE_MAP e where trim(b.employee_no) =? AND a.USER_ALIAS= d.user_name AND d.ca_user=? AND e.ca_user=d.ca_user AND e.corporate_id=? AND  a.USER_ID=b.USER_ID AND b.USER_ID=c.USER_ID AND c.USER_ROLE=?",parameters);	           
	            if (result != null && result.size() > 0) {
	            	logger.info("User Already Present :");
	            	flag= true;	             
	                }
	            else
	            	 flag=false;
	             
	        } catch (DataAccessException ex) {
	            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	        }
	       return flag;
	    }
	    public Map getUserDetails(String caUser, String roleID, String corpId) throws DAOException

	    {
	        logger.info("getUserDetails(String caUser,String roleID,String corpId) method begin");
	        List userDetailsList = null;
	        String query=null;
	        Object[]  parameters =null;
	        try
	        {		
	        		if(roleID.equals("13")){
	        	    parameters = new Object[] { roleID,corpId};
	                query=SQLConstants.FIND_ENQUIRER_NAMES;
	        		}
	        		else{
		        	    parameters = new Object[] {  caUser ,roleID};
		                query=SQLConstants.GET_USER_DETAILS_FLAG_NULL;
	        		}

	                logger.info(query);
	                userDetailsList = getJdbcTemplate().query(query, parameters,
	                        new UserDetailsRowMapper());
	           
	            if (userDetailsList != null && userDetailsList.size() > 0)	            
	                return (HashMap) userDetailsList.get(0); 
	            else
	            {
	                logger.info("userNamesData is empty");
	                return null;
	            }
	        }
	        catch (DataAccessException exception)
	        {
	            DAOException.throwException("F001", exception);
	        }
	        return null;

	    }


	    class UserDetailsRowMapper implements RowMapper
	    {
	        Map userNames = new LinkedHashMap();
	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        { 
	            userNames.put(rs.getString("USER_ALIAS"), rs.getString("NAME"));
	            return userNames;
	        }
	    }	    
	    public UserProfile getUserProfileDetails(String userName,String caUser) throws DAOException
	    {
	        logger.info("getUserProfileDetails(String userName) method begin");
	        UserProfile userProfile = null;
	        logger.info("userName =" + userName);
	        logger.info("admin name :::"+caUser);
	        try
	        {
	            Object[] parameters = new Object[] { userName ,caUser};
	            List userProfileList = getJdbcTemplate().query(SQLConstants.GET_PROFILE_DETAILS_USERNAME, parameters,
	                    new UserProfileDetailsRowMapper());
	            logger.info("userProfileList " + userProfileList);
	            if (userProfileList != null && userProfileList.size() == 1)
	            {
	                logger.info("User Profile Details are:" + userProfileList.get(0));
	                logger.info("getProfileDetails(Integer empno, String corpID) method end");
	                userProfile = ((UserProfile) userProfileList.get(0));
	            }
	            else 
	            {
	            	 logger.info("userProfileList is null");
	            	 DAOException.throwException("F001");
	            }

	        }
	        catch (DAOException exception)
	        {
	            logger.info("exception occured ");
	            DAOException.throwException("F001", exception);
	        }
	        return userProfile;
	    }
	    class ProfileDetailsRowMapper implements RowMapper
	    {

	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {
	            Address address = new Address();
	            UserProfile userProfile = new UserProfile();
	            userProfile.setUserAlias(rs.getString("USER_ALIAS"));
	            userProfile.setName(rs.getString("NAME"));
	            address.setAddress1(rs.getString("ADDRESS"));
	            address.setCity(rs.getString("CITY"));
	            userProfile.setDistrict(rs.getString("DISTRICT"));
	            address.setPin(rs.getString("ZIP"));
	            address.setState(rs.getString("STATE"));
	            address.setCountry(rs.getString("COUNTRY"));
	            userProfile.setAddress(address);
	            userProfile.setEmail(rs.getString("EMAIL"));
	            userProfile.setHomePhone(rs.getString("HOME_PHONE"));
	            userProfile.setFriendlyName(rs.getString("FRIENDLY_NAME"));
	            userProfile.setDesignation(rs.getString("DESIGNATION"));
	            userProfile.setDepartment(rs.getString("DEPARTMENT"));
	            userProfile.setEmpNo(rs.getString("EMPLOYEE_NO"));
	            userProfile.setUserId(new Integer(rs.getInt("USER_ID")));
	            userProfile.setTypeOfUser(rs.getString("USER_TYPE"));
	            userProfile.setAccRights(rs.getString("DDEBIT_ACCESS_RIGHTS"));
	            userProfile.setBranchCode(rs.getString("BRANCH_CODE"));
	            return userProfile;
	        }
	    }
	  //Added for Update mobile No -Start
	   
	    class UserProfileDetailsRowMapper implements RowMapper
	    {

	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {
	            Address address = new Address();
	            UserProfile userProfile = new UserProfile();
	            userProfile.setUserAlias(rs.getString("USER_ALIAS"));
	            userProfile.setName(rs.getString("NAME"));
	            address.setAddress1(rs.getString("ADDRESS"));
	            address.setCity(rs.getString("CITY"));
	            userProfile.setDistrict(rs.getString("DISTRICT"));
	            address.setPin(rs.getString("ZIP"));
	            address.setState(rs.getString("STATE"));
	            address.setCountry(rs.getString("COUNTRY"));
	            userProfile.setAddress(address);
	            userProfile.setEmail(rs.getString("EMAIL"));
	            userProfile.setHomePhone(rs.getString("HOME_PHONE"));
	            userProfile.setFriendlyName(rs.getString("FRIENDLY_NAME"));
	            userProfile.setDesignation(rs.getString("DESIGNATION"));
	            userProfile.setDepartment(rs.getString("DEPARTMENT"));
	            userProfile.setEmpNo(rs.getString("EMPLOYEE_NO"));
	            userProfile.setUserId(new Integer(rs.getInt("USER_ID")));
	            userProfile.setTypeOfUser(rs.getString("USER_TYPE"));
	            userProfile.setAccRights(rs.getString("DDEBIT_ACCESS_RIGHTS"));
	            userProfile.setBranchCode(rs.getString("BRANCH_CODE"));
	           // userProfile.setMobileNumber(rs.getString("mobile_no"));
	            String tempMobileNo = rs.getString("mobile_no");
	            if(tempMobileNo != null){
	            String sptMobileNo[] =tempMobileNo.split("\\|");
	            
	            if(sptMobileNo.length == 2){
	            String countryCode = sptMobileNo[0];
	            String mobileNo = sptMobileNo[1];
	            userProfile.setMobileNumber(mobileNo); 
	            userProfile.setCountryCode(countryCode); 
	            }
	            }
	            return userProfile;
	        }
	    }
	    //Added for Update mobile No -End  
	    public String updateProfileDetails( UserProfile userProfile )throws DAOException
	    {
	        
	        logger.info("updateProfileDetails( UserProfile userProfile )Method Begin" );
	        Address address=new Address();
	        address=userProfile.getAddress();
	        String corpId=  userProfile.getCorporateId();
	        try{
	             Object[] parameter=new Object[]{ userProfile.getName(),
	                                             address.getAddress1(),
	                                             address.getCity(),
	                                              userProfile.getDistrict(),
	                                              address.getPin(),
	                                              address.getState(),
	                                              address.getCountry(),
	                                              userProfile.getEmail(),
	                                              userProfile.getHomePhone(),
	                                              userProfile.getFriendlyName(),
	                                              userProfile.getDesignation(),
	                                              userProfile.getDepartment(),
	                                              userProfile.getEmpNo(),
	                                              userProfile.getBranchCode(),
	                                              userProfile.getBankCode(),
	                                              userProfile.getCorporateId(),
	                                              userProfile.getUserId(),
	                                              userProfile.getCorporateId()
	                                              };//shanta
	                                                     
	             for(int i = 0; i < parameter.length; i++)
	                 System.out.println("parameters are  "+parameter[i]);
	             
	             
	             int sqlType[] = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
	                               Types.VARCHAR,Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
	                               Types.VARCHAR,Types.VARCHAR,   Types.VARCHAR,  Types.VARCHAR,  Types.INTEGER, Types.VARCHAR}; //shanta
	                         

	             int count= getJdbcTemplate().update(SQLConstants.UPDATE_USER_PROFILE,parameter,sqlType);
	             
	             logger.info("QueryExecuted Successfully  "+count);
	                        logger.info("username"+userProfile.getUserAlias());
	                        if(logger.isDebugEnabled()){
	                            logger.debug("result :"+count);
	                           }
	                        logger.info("updateProfileDetails(UserProfile userProfile )METHODEND");

	                        userSessionCache.removeData(userProfile.getUserAlias()
	                                + DAOConstants.USER_PROFILE);
	                        findUserProfile(userProfile.getUserAlias(),corpId);
	                        
	                        return "Success";
	                        }
	                      catch(DataAccessException dataAccessException){
	                          
	                      DAOException.throwException("FATAL_EXCEPTION_ERRORCODE",dataAccessException);
	                             }
	                         
	                    return "Failure";
	    
	}  
	  //Added For CR 5472 Ends
	  //added for CR 5450 - begin
		public int getPrevPassHistory(String userName, String password) throws DAOException{
			  logger.info("getPrevPassHistory(String userName, String password)" + LoggingConstants.METHODBEGIN);			 
				 int passwordHistCount = 0;
				  try{
					  if(userName != null){
						  Object[] object={userName, password};
						  String sql="select count(*) from (select password, rank() over(order by modified_time desc) rnk "+
							  		  "from bv_user_password_dtls where user_name = ? order by modified_time desc ) "+
							  		  "where rnk < 5 and password = ?"; 
						  passwordHistCount= getJdbcTemplate().queryForInt(sql, object);
						  logger.info("passwordHistCount :: "+passwordHistCount);
					  }
				  }catch(DataAccessException e){
					  logger.info("DataAccessException:: ",e);
					  DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
				  }
			logger.info("getPrevPassHistory(String userName, String password)" + LoggingConstants.METHODEND);
			return passwordHistCount; 
		}
		//added for CR 5450 - end
     public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }
    
		 //  Added for CR 5550
	    public void changeKLoginPassword(String uName, String newPassword, String ipAddress) throws DAOException{
	        userName = uName;
	        password = newPassword;
	        ipAdd = ipAddress;
	      //  password=EncryptMD5.hashMessage(userName+"#"+newPassword);(added for CR 5034./ Commented by Immanuel)
	        transactionTemplate.execute(new TransactionCallback(){
	            public Object doInTransaction(TransactionStatus transactionStatus){
	                try{
	                	updatePassword(userName,password,ipAdd);     
						//insertPasswordHistory(userName,password);//added for CR 5450
	                }catch(DataAccessException e){
	                    transactionStatus.setRollbackOnly();
	                    Object[] errorparams={userObj.getUserAlias(),userObj.getUserIPaddress()};
	                    DAOException.throwException(e,"LOG008",errorparams);// unable to update the password.
	                }
	                return null;
	            }
	        }
	        );
	        }
	    //  End of CR 5550
	    /*
		 * Added for CR 5552
		 *for getting the list of PP ID pending
		 */
	  	public List findPPKIT(String userName, String corporateID,String ppID,String flag) throws DAOException {
			List formList = null;
			 logger.info("findPPKIT(String userName, String corporateID)method begin");
			try {
				if(flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("listView"))
				{
				//String query =  "select emp_no, pp_id, name, designation, department, address1, city, state, country, pincode, email, phone,status from SBI_CORP_PPKITS_USER_DETAIL where created_by=? and corp_id=? and status='Pending' order by pp_id desc";
				String query =  GET_PP_KIT_DETAILS.replaceAll("#tobereplaced#", "created_by=? and corp_id=? and status='Pending' order by pp_id desc" );
				logger.info("findPPKIT query in DAO::"+query);
				Object[] param = {userName,corporateID};
				formList = (List) getJdbcTemplate().query(query,param,new PPKITExtractor());
				}
				else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("ppidDetails"))
				{
					String query =  GET_PP_KIT_DETAILS.replaceAll("#tobereplaced#", "pp_id=?" );
					
					logger.info("findPPKIT query in DAO::"+query+"ppID"+ppID);
					Object[] param = {ppID};
					formList = (List) getJdbcTemplate().query(query,param,new PPKITExtractor());	//change extractor name			
				
				} else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("listpendingreissuepwd")) //5552 imman
				{
					String query = GET_REISSUE_PWD_DETAILS;
					
					logger.info("find Reissue PWD query in DAO::"+query);
					logger.info("user name::::::"+userName);
					Object[] param = {userName};
					formList = (List) getJdbcTemplate().queryForList(query,param);	//change extractor name			
				
				}  else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("fromlistreissuepwdc7a")) //5552 imman
				{
					String query = GET_REISSUE_PWD_USR_DETAILS;
					
					logger.info("find Reissue PWD User Details in DAO::"+query);
					logger.info("user name::::::"+ppID);
					Object[] param = {ppID};
					formList = (List) getJdbcTemplate().query(query,param,new ReissuePwdExtractor());				
				} else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("listViewC9")) 		{
					String query = LIST_C9_USR_DETAILS;
					
					logger.info("find Reissue PWD query in DAO::"+query);
					logger.info("user name::::::"+userName);
					Object[] param = {userName,ppID};
					formList = (List) getJdbcTemplate().queryForList(query,param);		
				} else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("c9UserDetails")) //imman
				{
					String query = LIST_C9_INT_USR_DETAILS;
					
					logger.info("find Reissue PWD User Details in DAO::"+query);
					logger.info("user name::::::"+ppID);
					Object[] param = {ppID,ppID};
					formList = (List) getJdbcTemplate().query(query,param,new C9FormExtractor());				
				}else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("c10UserDetails")) //Added for vasco token request
				{
					String query = LIST_C10_INT_USR_DETAILS;
					
					logger.info("find Reissue PWD User Details in DAO::"+query);
					logger.info("user name::::::"+ppID);
					Object[] param = {ppID,ppID};
					formList = (List) getJdbcTemplate().query(query,param,new C10FormExtractor());				
				}else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("c7bView")) //Added for C7b form
				{
					String query = LIST_C7B_DETAILS;
					
					logger.info("reissue transactionpwd ::"+query);
					logger.info("caUser ::::::"+userName);
					Object[] param = {userName};
					formList = (List) getJdbcTemplate().query(query,param ,new C7bExtractor());				
				}else if (flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("c7bPrint"))//Added for C7b form
				{
					String query = LIST_C7B_DETAILS_WITH_REFERENCE;					
					logger.info("reissue transactionpwd ::"+query);
					logger.info("caUser ::::::"+userName);
					Object[] param = {userName,ppID};
					formList = (List) getJdbcTemplate().query(query,param ,new C7bPrintExtractor());				
				}

			} catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

			}
			logger.info("findPPKIT(String userName, String corporateID): method ends");
			return formList;
		}
	  	
	  	
		public class C7bExtractor implements ResultSetExtractor {

			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List c9List = new ArrayList();
				while (rs.next()) {
					Map c9Map = new HashMap();
					String referenceNo = rs.getString("reference_no");
					String userName = rs.getString("user_name");
					String name = rs.getString("name");
					String userRole = rs.getString("user_role");
					String pwdChangedDate = rs.getString("PASSWORD_CHANGED_DATE");					
					String empNo = rs.getString("EMPLOYEE_NO");					
					String designation = rs.getString("designation");					
					String department = rs.getString("department");					
					String address = rs.getString("address");					
					String city = rs.getString("city");					
					String state = rs.getString("state");					
					String country = rs.getString("country");					
					String ZIP = rs.getString("ZIP");					
					String HOME_PHONE = rs.getString("HOME_PHONE");					
					String email = rs.getString("email");					
					c9Map.put("referenceNo", referenceNo);
					c9Map.put("userName", userName);
					c9Map.put("name", name);
					c9Map.put("userRole", userRole);
					c9Map.put("pwdChangedDate", pwdChangedDate);
					c9Map.put("empNo", empNo);
					c9Map.put("designation", designation);
					c9Map.put("department", department);
					c9Map.put("address", address);
					c9Map.put("city", city);
					c9Map.put("state", state);
					c9Map.put("country", country);
					c9Map.put("ZIP", ZIP);
					c9Map.put("HOME_PHONE", HOME_PHONE);
					c9Map.put("email", email);					
					c9List.add(c9Map);
				}

				return c9List;
			}

		}
		public class C7bPrintExtractor implements ResultSetExtractor {

			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List c9List = new ArrayList();
				while (rs.next()) {
					Map c9Map = new HashMap();
					String referenceNo = rs.getString("reference_no");
					String userName = rs.getString("user_name");
					String name = rs.getString("name");
					String userRole = rs.getString("user_role");
					String pwdChangedDate = rs.getString("PASSWORD_CHANGED_DATE");					
					String empNo = rs.getString("EMPLOYEE_NO");					
					String designation = rs.getString("designation");					
					String department = rs.getString("department");					
					String address = rs.getString("address");					
					String city = rs.getString("city");					
					String state = rs.getString("state");					
					String country = rs.getString("country");					
					String ZIP = rs.getString("ZIP");					
					String HOME_PHONE = rs.getString("HOME_PHONE");					
					String email = rs.getString("email");					
					String mobileNo = rs.getString("mobile_no");					
					c9Map.put("referenceNo", referenceNo);
					c9Map.put("userName", userName);
					c9Map.put("name", name);
					c9Map.put("userRole", userRole);
					c9Map.put("pwdChangedDate", pwdChangedDate);
					c9Map.put("empNo", empNo);
					c9Map.put("designation", designation);
					c9Map.put("department", department);
					c9Map.put("address", address);
					c9Map.put("city", city);
					c9Map.put("state", state);
					c9Map.put("country", country);
					c9Map.put("ZIP", ZIP);
					c9Map.put("HOME_PHONE", HOME_PHONE);
					c9Map.put("email", email);					
					c9Map.put("mobileNo", mobileNo);					
					c9List.add(c9Map);
				}

				return c9List;
			}

		}
		
		
	  	private class PPKITExtractor implements ResultSetExtractor {
			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List ppkit = new ArrayList();
				while (rs.next()) {
					logger.info("Result set "+rs.getString("EMP_NO"));
					UserProfile userProfile = new UserProfile();
					Address address=new Address();
					userProfile.setHintQuestion(rs.getString("EMP_NO"));
					userProfile.setHintAnswer(rs.getString("PP_ID"));
					userProfile.setName(rs.getString("NAME"));					
					userProfile.setDesignation(rs.getString("DESIGNATION"));
					userProfile.setDepartment(rs.getString("DEPARTMENT"));
					address.setAddress1(rs.getString("ADDRESS1"));
					address.setCity(rs.getString("CITY"));
					address.setState(rs.getString("State"));
					address.setPin(rs.getString("PINCODE"));
					address.setCountry(rs.getString("COUNTRY"));
					userProfile.setAddress(address);
					userProfile.setHomePhone(rs.getString("PHONE"));
					userProfile.setEmail(rs.getString("EMAIL"));
					userProfile.setCreatedBy(rs.getString("USER_TYPE"));
					userProfile.setUserState(rs.getString("STATUS"));
					userProfile.setLoginCount(rs.getInt("userrole"));
					ppkit.add(userProfile);
				}
				return ppkit;
			}
		}
		private class ReissuePwdExtractor implements ResultSetExtractor {
			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List ppkit = new ArrayList();
				while (rs.next()) {

					UserProfile userProfile = new UserProfile();
					Address address=new Address();
					userProfile.setHintQuestion(rs.getString("EMPLOYEE_NO"));
					userProfile.setHintAnswer(rs.getString("USER_ID"));
					userProfile.setName(rs.getString("NAME"));					
					userProfile.setDesignation(rs.getString("DESIGNATION"));
					userProfile.setDepartment(rs.getString("DEPARTMENT"));
					address.setAddress1(rs.getString("ADDRESS"));
					address.setCity(rs.getString("CITY"));
					address.setState(rs.getString("STATE"));
					address.setPin(rs.getString("ZIP"));
					address.setCountry(rs.getString("COUNTRY"));
					userProfile.setAddress(address);
					userProfile.setHomePhone(rs.getString("BUS_PHONE"));
					userProfile.setEmail(rs.getString("EMAIL"));
					userProfile.setLoginCount(rs.getInt("USER_ROLE"));
					userProfile.setMobileNumber(rs.getString("MOBILE_NO"));
					//userProfile.setUserState(rs.getString("STATUS"));
					logger.info("Result Set Extractor:"+userProfile.toString());
					//logger.info("ppkit.get(0"+ppkit.get(0));
					ppkit.add(userProfile);
				}
				return ppkit;
			}
		}
		
		private class C9FormExtractor implements ResultSetExtractor {
			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List ppkit = new ArrayList();
				while (rs.next()) {

					UserProfile userProfile = new UserProfile();
					userProfile.setUserId(rs.getInt("user_id"));
					userProfile.setCorporateId(rs.getString("corporate_id"));
					userProfile.setMobileNumber(rs.getString("new_mobile_no"));
					userProfile.setCountryCode(rs.getString("reference_no"));
					userProfile.setLoginCount(rs.getInt("USER_ROLE"));
					userProfile.setCreatedBy(rs.getString("Created_by"));
					userProfile.setName(rs.getString("Friendly_name"));	
					userProfile.setEmpNo(rs.getString("emp_no"));
					logger.info("Result Set Extractor:"+userProfile.toString());
					ppkit.add(userProfile);
				}
				return ppkit;
			}
		}
	  	//5552 Ends
		/*
		 * Added on 6-3-2011
		 * Added for Registeration of Corporate Mobile Numbers
		 * 
		 */
		public void insertMobileDetails(UserProfile userProfile, String role, String userId){ 
	        try{
        	
	        	 String query="select 'CMR' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual"; 
	        	 String sequenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
	        	 userProfile.setMobileRegNo(sequenceNo);
	        	int seqid=getJdbcTemplate().queryForInt("select EHS_SEQUENCE.NEXTVAL from dual");
	            Object[] parameters = new Object[] {userId,userProfile.getMobileNumber(),userProfile.getMobileNumber(),userProfile.getMobileRegNo(),userProfile.getBranchCode(),role,userProfile.getCorporateId(),userProfile.getCreatedBy(),userProfile.getName(),userProfile.getSmsSecurity()};
	            int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC};
	            getJdbcTemplate().update(SQLConstants.INSERT_SBICORPUSER_MOBILE_NO, parameters,sqlTypes);
	            logger.info("Record inserted to SBICORP_USER_MOBILE_NO");
	        }catch(DataAccessException daoExp){
	            logger.error("Unable to insert to SBICORP_USER_MOBILE_NO for " + role);
	            logger.error("exception is " + daoExp);
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
	        }
	     } 
		
		public void insertMobileDetailsPPKit(UserProfile userProfile, String role, String ppktId){ 
	        try{
        	
	        	 String query="select 'CMR' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual"; 
	        	 String sequenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
	        	 userProfile.setMobileRegNo(sequenceNo);
	        	 String creationType="ppkit";
	        	//int seqid=getJdbcTemplate().queryForInt("select EHS_SEQUENCE.NEXTVAL from dual");
	            Object[] parameters = new Object[] {ppktId,userProfile.getMobileNumber(),userProfile.getMobileNumber(),userProfile.getMobileRegNo(),userProfile.getBranchCode(),role,userProfile.getCorporateId(),userProfile.getCreatedBy(),userProfile.getName(),creationType};
	            int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	            getJdbcTemplate().update(SQLConstants.INSERT_SBICORPUSER_MOBILE_NO_PPKIT, parameters,sqlTypes);
	            logger.info("Record inserted to SBICORP_USER_MOBILE_NO");
	        }catch(DataAccessException daoExp){
	            logger.error("Unable to insert to SBICORP_USER_MOBILE_NO for " + role);
	            logger.error("exception is " + daoExp);
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
	        }
	     } 
		

		// added for CR-5710
		public String getPPkitNumber( String userName) {
			logger.info("getPPkitNumber(String userName)-start");
			String ppkitNo= "";
			try{
		  		Object[] object={userName};
		  		ppkitNo = (String) getJdbcTemplate().queryForObject("select kit_no from sbi_pp_kits where user_name = ?",object,String.class);
		  		logger.info("ppkit Number: "+ppkitNo);	
		  			
		  	}
			catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
				logger.error("Unable to get the kitNo");
				ppkitNo = null;
			}catch(DataAccessException dataAccessException){		
		  		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		  	}catch(Exception exception){		
		  		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,exception);
		  	}
		  	logger.debug("getPPkitNumber(String userName)-" + LoggingConstants.METHODEND);
		  	return ppkitNo;

		  }
		  
 		/* Ramanan.M : Begin - Added to Lock and Unlock the Uploader */
		public Map getDeactivatedUploaderDetails(String caUser, String roleID, String corpId) throws DAOException
	    {
	        logger.info("getDeactivatedUploaderDetails(String caUser,String roleID,String corpId) method begin");
	        List userDetailsList = null;
			Object[] parameters = null;
			try {
				parameters = new Object[] { caUser, roleID };
				logger.info(GET_DEACTIVATED_UPLOADER_DETAILS);
				userDetailsList = getJdbcTemplate().query(GET_DEACTIVATED_UPLOADER_DETAILS, parameters, new UserDetailsRowMapper());
				if (userDetailsList != null && userDetailsList.size() > 0) {
					logger.info("getDeactivatedUploaderDetails(String caUser,String roleID,String corpId) method end");
					return (HashMap) userDetailsList.get(0);
				} else {
					logger.info("userNamesData is empty");
					logger.info("getDeactivatedUploaderDetails(String caUser,String roleID,String corpId) method end");
					return null;
				}
			} catch (DataAccessException exception) {
				DAOException.throwException("F001", exception);
			}
			return null;
	    }
//Added for Merchant High Security
		
		public int updateCorpProfile(String userName, String highSecurityStatus,String corporateID){ 
			 logger.info("updateCorpProfile(String userName, String highSecurityStatus,String corporateID) method begin");
		       int updatecount=0;
	        try{	        
	        	String merchantMode=null;
	        	if(highSecurityStatus.equalsIgnoreCase("yes"))
	        		merchantMode="0";
	        	if(highSecurityStatus.equalsIgnoreCase("no"))	
	        		merchantMode="1";
	            Object[] parameters = new Object[] {merchantMode,corporateID};
	            int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR};
	            getJdbcTemplate().update("update sbicorp_corporate_profile set merchant_mode=?,last_mod_time=sysdate where corporate_id=?", parameters,sqlTypes);
	            updatecount=1;
	            logger.info("Record updated to sbicorp_corporate_profile");
	        }catch(DataAccessException daoExp){
	        	updatecount=0;
	            logger.error("Unable to update merchant mode to sbicorp_corporate_profile for " );
	            logger.error("exception is " + daoExp);
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
	        }
	        return updatecount;
	     } 
		public String getMerchantMode( String CorporateId) {
			logger.info("getMerchantMode( String CorporateId)-start");
			String merchantMode= "";
			logger.info("========CorporateId========="+CorporateId);
			try{
		  		Object[] object={CorporateId};
		  		int[] sqlTypes = {Types.VARCHAR};
		  		merchantMode = (String) getJdbcTemplate().queryForObject("select merchant_mode from sbicorp_corporate_profile where corporate_id = ?",object,sqlTypes,String.class);
		  		logger.info("merchant mode: "+merchantMode);	
		  			
		  	}
			catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
				logger.error("Unable to get merchant mode");
				merchantMode = null;
			}catch(DataAccessException dataAccessException){		
		  		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		  	}catch(Exception exception){		
		  		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,exception);
		  	}
		  	logger.debug("getMerchantMode( String CorporateId)-" + LoggingConstants.METHODEND);
		  	return merchantMode;
		}
//Added for Dmat Corporate
    public int findValidCorpUser(String ebrokingId,String corporateId,String corpAdmin,String userName)throws DAOException
    {
       logger.info("findValidCorpUser(Dmat dmat, String userName);" + LoggingConstants.METHODBEGIN);       
       
       int count=0;
       if(userName != null && !"".equals(userName))
    	   
       {		
    	   try{    	
    	   Object[] params = new Object[]{ebrokingId,corpAdmin,userName };    	   
           int sqlTypes[] ={ Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};          
        	 String accountNo = (String) getJdbcTemplate()
   			.queryForObject("select distinct a.bank_account_no from sbi_dmat_reg_details a,sbi_branch_master b ,sbi_customer_account_map c where ebroking_id=? and a.ca_user=?  and a.merchant_code = 'NOW' and c.user_name=? and a.branch_code=b.branch_code and a.bank_account_no=c.account_no  AND C.STATUS=1 and account_nature in ('0','3') and a.branch_code=c.branch_code and c.access_level in ('6','7') and b.core_banking=0",
   					params,String.class); 
        	   Object[] parameters = new Object[]{ accountNo,userName,corpAdmin,corporateId };
        	   if(accountNo!=null){        	   
        	  count = getJdbcTemplate().queryForInt(FIND_VALID_CORP_USER, parameters,sqlTypes);
               logger.info("count: "+count);
        	   }
        	   else{
        		   count=0;
        	   }
    	   }catch(IncorrectResultSizeDataAccessException incorrectResultSizeDataAccessException) {
   			Object[] errorParams={userName};
   			DAOException.throwException(incorrectResultSizeDataAccessException,"DMATC001",errorParams);// Unable to get the password
   	
               
           } catch (DataAccessException ex) {

               ex.printStackTrace();
               DAOException.throwException("CU0002",new Object [] {userName});
             }                        
       }
       else
       {//Input values are null
        DAOException.throwException("CU0001",new Object [] {userName});
       }
       logger.info("findValidCorpUser(Dmat dmat, String userName) method ends");
   return count; 
   }
//  Added for Dmat Corporate
    public String currencyTradeUser(String userName)throws DAOException {
    	logger.info("currencyTradeUser(Dmat dmat,String userName)- method begins");
    	Object[] params = new Object[]{userName};
        String currencyTrade="";  
        String query ="select currency_trade from bv_user_profile where user_id in (select user_id from bv_user where user_alias=?)";
         try{        
        	 currencyTrade =(String)getJdbcTemplate().queryForObject(query,params,String.class);
         }catch(DataAccessException dataAccessException){
           	DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE);
         }
         logger.info("currencyTradeUser(Dmat dmat,String userName)- method ends");
         return currencyTrade;
         
    }
    
    public String getCharityName(String donateId) throws DAOException
    {
    	String query="select donate_name from sbi_donation_master where donate_id = ?";
 		String charityName=null;
 		if(donateId!=null){
 			try{
 			Object[] params={donateId};
 			charityName=(String)getJdbcTemplate().queryForObject(query,params,String.class);
 			logger.info("Charity Name for Donate Id: "+donateId+" is: "+charityName);
 			return charityName;
 			}catch(DataAccessException ex){
 				logger.error("charityName not found");
 				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
 			} 			
 		}
 		
    	return null;
    }
    
  //Added for vasco token request start
    private class C10FormExtractor implements ResultSetExtractor {
		public Object extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			List ppkit = new ArrayList();
			while (rs.next()) {

				UserProfile userProfile = new UserProfile();
				userProfile.setUserId(rs.getInt("user_id"));
				userProfile.setCorporateId(rs.getString("corporate_id"));
				//userProfile.setMobileNumber(rs.getString("new_mobile_no"));
				userProfile.setCountryCode(rs.getString("reference_no"));
				userProfile.setLoginCount(rs.getInt("USER_ROLE"));
				userProfile.setCreatedBy(rs.getString("Created_by"));
				userProfile.setName(rs.getString("Friendly_name"));	
				userProfile.setEmpNo(rs.getString("emp_no"));
				logger.info("Result Set Extractor:"+userProfile.toString());
				ppkit.add(userProfile);
			}
			return ppkit;
		}
	}  //Added for vasco token request end
/*Added for MobileNo updation - Start*/
    
    public RegMobileNoDetails updateMobileNoDetails(Integer userId,String contryCode,String updatMobileNo,String tmpMobileNo,String modifyUser,String branchCode,String userRole,String cororateId,String userAlias,String friendlyName) throws DAOException
    {
        logger.info("int updateMobileNoDetails( String corpID )METHODBEGIN");
        logger.info("UserId :" + userId+"ContryCode :"+contryCode+"updatMobileNo :"+updatMobileNo+"OldMobileNo :"+tmpMobileNo+"ModifyUser :"+modifyUser+"BranchCode :"+branchCode+"UserRole :"+userRole+"friendlyName :"+friendlyName);
        String newMobileNo = contryCode+"|"+updatMobileNo;
        String exMobileNo= tmpMobileNo;
        if(exMobileNo == null || exMobileNo == "" ){
        	exMobileNo ="";
        }
        if(friendlyName == null || friendlyName == "" ){
        	friendlyName ="";
        }
        
        int status =0;
        RegMobileNoDetails regMobileNoDetails =null;
        regMobileNoDetails = new RegMobileNoDetails();
        String query="select 'CMR' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual";
        String refferenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
        int count=0;
        String queryforCount;
        String queryforUpdate;
        logger.info("userId :"+userId);
        logger.info("exMobileNo :"+exMobileNo);
        logger.info("newMobileNo :"+newMobileNo);
        logger.info("refferenceNo :"+refferenceNo);
        logger.info("branchCode :"+branchCode);
        logger.info("userRole :"+userRole);
        logger.info("cororateId :"+cororateId);
        logger.info("userAlias :"+userAlias);
        logger.info("friendlyName :"+friendlyName);
        
        if (userId != null && newMobileNo !=null && !newMobileNo.trim().equalsIgnoreCase(""))
        {
            Object[] Parameter = new Object[] {userId,exMobileNo,newMobileNo,refferenceNo,branchCode,userRole,cororateId,userAlias,friendlyName};
            Object[]  countparams = new Object[] {userId};
            queryforCount = "select count(1) from sbicorp_user_mobile_no where user_id=? AND status='Pending'";
            count = getJdbcTemplate().queryForInt(queryforCount,countparams);
            logger.info("count :"+count);
            
            if(count >= 1){
            	queryforUpdate = "update sbicorp_user_mobile_no set status='Cancelled' where user_id=? and status='Pending'";
            	int updateStatus = getJdbcTemplate().update(queryforUpdate, countparams);
                logger.info("QueryExecuted Successfully  " + updateStatus);
                
            }      
           String queryforreg_mobile_no="INSERT INTO sbicorp_user_mobile_no (USER_ID,OLD_MOBILE_NO,NEW_MOBILE_NO,STATUS,CREATION_TIME,LAST_MOD_TIME,REFERENCE_NO,BRANCH_CODE,USER_ROLE,CORPORATE_ID,CREATED_BY,FRIENDLY_NAME)values(?,?,?,'Pending',sysdate,sysdate,?,?,?,?,?,?)";
           status = getJdbcTemplate().update(queryforreg_mobile_no,Parameter);
           logger.info("status " + status);
            if(status == 1){
       
        	   logger.info("refferenceNo :::"+refferenceNo);
        	   regMobileNoDetails.setReferenceNo(refferenceNo);
        	   regMobileNoDetails.setMobileNo(newMobileNo);
        	   regMobileNoDetails.setUserRole(String.valueOf(userRole));
           }
            if (logger.isDebugEnabled())
            {
                logger.debug("status :" + status);
            }

          
		}else{
			DAOException
			.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
		}
        logger.info("updateMobileNoDetails(int userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,int userRole,String cororateId,String userAlias)"+ LoggingConstants.METHODEND);
        return regMobileNoDetails;

    }
    /*Added for MobileNo updation - end*/

    //Added for SHA encryption algorithm -Start
    public void setRequestResponseService(
			RequestResponseService requestResponseService) {
		this.requestResponseService = requestResponseService;
	}
    public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}
	//Added for SHA encryption algorithm -End
    
    //E-suvidha
    
    public int updateNewTPTransactions(String username, String creditAccountNo,String echequeNo,String branchCode,double amount,String transactionStatus,String module){
		logger.info("updateNewTPTransactions(String username, String creditAccountNo,String echequeNo,String branchCode,double amount,String transactionStatus,String module) starts");
		int noOfRowsInserted =0;
		String inserttransaction = "insert into sbi_new_tp_transactions (user_name,echeque_no,account_no,branch_code,amount,transaction_status,creation_time) values(?,?,?,?,?,?,sysdate)";
		Object [] paramsForInsert= {username,echequeNo,creditAccountNo,branchCode,amount,transactionStatus};
		  noOfRowsInserted = getJdbcTemplate().update(inserttransaction, paramsForInsert);
		logger.info("updateNewTPTransactions(String username, String creditAccountNo,String echequeNo,String branchCode,double amount,String transactionStatus,String module) ends with noOfRowsInserted "+ noOfRowsInserted);
		return noOfRowsInserted;
	  }
 
    /*vijaya*/
    
    public boolean updateBranchPFPassword(String userName,  String password) throws DAOException{
        logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODBEGIN);
        boolean retVal = false;    
        String DELETE_USER_LOGGEDIN_="DELETE FROM SBI_LOGGEDIN_USERS WHERE USER_NAME=?";
        Object[] inParameter = new Object[]{userName,password};
        int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR};
       try{
           logger.info( "  new username = " + userName);
           Object[] param = new Object[]{userName};
           int sqlTypes1[] = {Types.VARCHAR};
           int status =  getJdbcTemplate().update(DELETE_USER_LOGGEDIN_,param,sqlTypes1);
           logger.info("update password in bvuser table " + status);
           if(status == 1){
               updatePassword(userName,password,"");
               retVal = true;
           }
            
       }
       
       catch (DataIntegrityViolationException dataIntegrityViolationException) 
       {
         dataIntegrityViolationException.printStackTrace();       
         logger.info("inside DataIntegrity Violation Exception");
         if (dataIntegrityViolationException.getMessage().toUpperCase().indexOf("UNIQUE") > 0)
         {
             logger.info("inside the if condition DataIntegrity Violation Exception");
             DAOException.throwException(ErrorConstants.UNIQUE_CONSTRAIN_EXCEPTION_ERRORCODE);
         }
       }
       // end 
       catch(DataAccessException dataAccessExcp)
       {
         logger.error("Exception occured during to insert the data into sbicorp_user_map_history **",dataAccessExcp);
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);           
       }
       logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODEND);
       return retVal;
    }
 public boolean updateCirlePFPassword(String userName,  String password) throws DAOException{
        logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODBEGIN);
        boolean retVal = false;    
        String DELETE_USER_LOGGEDIN_="DELETE FROM SBI_LOGGEDIN_USERS WHERE USER_NAME=?";
        Object[] inParameter = new Object[]{userName,password};
        int sqlTypes[] = {Types.VARCHAR,Types.VARCHAR};
       try{
           logger.info( "  new username = " + userName);
           Object[] param = new Object[]{userName};
           int sqlTypes1[] = {Types.VARCHAR};
           int status =  getJdbcTemplate().update(DELETE_USER_LOGGEDIN_,param,sqlTypes1);
           logger.info("update password in bvuser table " + status);
           if(status == 1){
               updatePassword(userName,password,"");
               retVal = true;
           }
            
       }
       
       catch (DataIntegrityViolationException dataIntegrityViolationException) 
       {
         dataIntegrityViolationException.printStackTrace();		
         logger.info("inside DataIntegrity Violation Exception");
         if (dataIntegrityViolationException.getMessage().toUpperCase().indexOf("UNIQUE") > 0)
         {
        	 logger.info("inside the if condition DataIntegrity Violation Exception");
        	 DAOException.throwException(ErrorConstants.UNIQUE_CONSTRAIN_EXCEPTION_ERRORCODE);
         }
       }
       // end 
       catch(DataAccessException dataAccessExcp)
       {
    	   logger.error("Exception occured during to insert the data into sbicorp_user_map_history **",dataAccessExcp);
           DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);           
       }
       logger.info("changeCorporateUserName(String userName, String oldUserName) "+LoggingConstants.METHODEND);
       return retVal;
    }



@Override
public boolean updateOTPDeliveryMode(String userId,String otpOption) throws DAOException {

	String updateCAUserQuery = "UPDATE BV_USER_PROFILE  SET otp_delivery_mode =?, sf_auth_provider='Mobile'  WHERE user_id= ?";
	Object[] params = {otpOption,userId};
	try{
		int count=getJdbcTemplate().update(updateCAUserQuery,params);
		if(count==1) {
			return true;
		}
	}catch (DataAccessException e) {
		DAOException.throwException("DDU001",e);
	}

	return false;
}
  


}   

