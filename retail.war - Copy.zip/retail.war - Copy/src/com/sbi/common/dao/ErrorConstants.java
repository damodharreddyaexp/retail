/* 
 * ErrorConstants.java
 * Created on Nov 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 09, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
//Dec 22, 2005 BOOPATHI - Constants Added
//JULY 3, 2006 SARAVANAN - Constants Added.
package com.sbi.common.dao;

import com.sbi.common.utils.Constants;

public interface ErrorConstants extends Constants
{

	String UNIQUE_CONSTRAIN_EXCEPTION_ERRORCODE = "DAOE010"; //added for CR NO:2013
//	 added to Rupee instant module
	String INVALID_DEBIT_ACCOUNT_NO="IV0001";
	
	String INVALID_CREDIT_ACCOUNT_NO="IV0002";
	
	String INVALID_CBRANCH_CODE="IV0004";
	
    String FATAL_EXCEPTION_DESCRIPTION = "Unable to process request";

    String FATAL_EXCEPTION_ERRORCODE = "F001";

    String DATA_NULL_DESCRIPTION = "Input data is empty";

    String DATA_NULL_ERROR_CODE = "E001";
    
    String CONNECTION_TIMEOUT = "Connection Timed Out";

    String STATEMENT = "statement";

    String TIMEOUT_ERROR_CODE = "F1";

    String CONNECTION_REFUSED_ERROR_CODE = "F2";

    //String CONNECTION_ERROR = "CONNECTION_ERROR";

    /* Added for UserDAO */

    String FATAL_ERROR1_CODE = "F001";

    //String FATAL_ERROR1_DESC = "Data Access Problem : ";

    String LOGON_ERROR1_CODE = "L001";

    String LOGON_ERROR1_DESC = "Invalid Logon";

    /* TransactionHistoryDAOImpl */
    String INPUT_ERROR1_CODE = "I001";

    //String INPUT_ERROR1_DESC = "Accounts data not available";

    String INPUT_ERROR2_CODE = "I002";

    //String INPUT_ERROR2_DESC = "Invalid input";

    /* TransactionAccountMasterDAOImpl */

    String FATAL_ERROR3_CODE = "F003";

    //String FATAL_ERROR3_DESC = "More than one AccountDetails found";

    //String DATA_NOT_FOUND_DESC = "Data not found for this Input";

    String DATA_NOT_FOUND_CODE = "I002";
    
    String INVALID_STRING_ERROR_CODE = "V105";

    // Data added by boopathi

    //public static final String TRANSACTION_NAME_NOT_VALID = "Transaction name is not valid";

    public static final String TRANSACTION_NAME_NOT_VALID_ERROR_CODE = "V013";

    //public static final String INTER_BRANCH_TRANSFER_NOT_VALID = "InterBank transfer is not allowed";

    public static final String INTER_BRANCH_TRANSFER_NOT_VALID_ERROR_CODE = "V001";

    //public static final String AMOUNT_LIMIT_EXCEEDS_SBI_LIMIT = "Amount limit exceeds SBI limit";

    //String TRAN_RIGHTS_NOT_AVIALABLE = "Transaction rights is not avilable for this Account";

    String TRAN_RIGHTS_NOT_AVIALABLE_ERROR_CODE = "V003";

    //String ACCOUNT_TYPE_NOT_VALID = "Account Type is not valid";

    String ACCOUNT_TYPE_NOT_VALID_ERROR_CODE = "V004";

    //String ACCOUNT_NATURE_NOT_VALID = "Account Nature is not valid";

    String ACCOUNT_NATURE_NOT_VALID_ERROR_CODE = "V006";

    //String TRAN_LIMIT_EXCEEDS_SBI_LIMIT = "Transaction limit exceeds SBI limit";

    String TRAN_LIMIT_EXCEEDS_SBI_LIMIT_ERROR_CODE = "V007";

    //String INTER_BRANCH_LIMIT_EXCEEDS = "Inter branch limit exceeds SBI limit";

    String INTER_BRANCH_LIMIT_EXCEEDS_ERROR_CODE = "V008";

    //String TRANSFER_NOT_VALID = "Transfer is not valid";

    String TRANSFER_NOT_VALID_ERROR_CODE = "V009";

    //String WRONG_TRANSFER_TYPE = "Wrong TransferType";

    String WRONG_TRANSFER_TYPE_ERROR_CODE = "V010";

   String AMOUNT_NOT_VALID_ERROR_CODE = "V015";
    
    String CHEQUE_LEAVES_ERROR_CODE = "V016";
    
    String INVALID_ACCOUNT_TYPE_TENOR_ERROR_CODE = "V017";
    
    String SAME_DEBIT_CREDIT_ACCOUNT_ERROR_CODE = "V018";
     
    String DATES_NOT_VALID_ERROR_CODE = "V019";
    
    //added by srujana..
    String VALIDATE_CHECK_USER_BILLERMAP_ERROR_CODE = "V025";
 
    String VALIDATE_CHECK_BILLER_MASTER_DETAILS_ERROR_CODE = "V026";

    String VALIDATE_VALIDATE_TXNRIGHTS_ERROR_CODE = "V027";

    String VALIDATE_CHECK_PAYMENT_SCHEDULE_ERROR_CODE = "V028";

    String VALIDATE_CHECK_BILL_EXISTS_ERROR_CODE = "V029";
    
    String VALIDATE_CHECKUSER_BILLERMAP_WITHOUR_BILL_ERROR_CODE="V030";

    String SCH_DATE_GREATER_THAN_ALLOW_DATE = "SE025";
    
    public static final String BILL_ALREADY_PAID = "V031"; 
    
    
    /*  Profile */ 

   
    public static final  String INVALID_PROFILE_PASSWORD_ERROR_CODE = "V0160";     
    
    //public static final  String INVALID_PROFILE_PASSWORD_ERROR_CODE = "V060";      

    public static final  String INVALID_USERBRANCH_ERROR_CODE = "V061";
    
    public static final  String INVALID_USERID_PASSWORD_CODE = "V062";
        
    public static final  String INVALID_USER_INACTIVE_CODE = "V063";    

    public static final  String INVALID_BANK_CODE = "V064";   
    
    public String INVALID_HINT_ANSWER_ERROR_CODE = "V065";

    public String INVALID_HINT_QUESTION_ERROR_CODE = "V066";
    
    public static final  String INVALID_ROLES_CODE = "V067";   

    public static final  String INVALID_ACCOUNT_LENGTH_CODE = "V068";    

    public static final  String INVALID_ACCOUNT_IDENTIFIER_CODE = "V069";    
 
    public static final  String DUPLICATE_ACCOUNT_CODE = "V070";    

    public static final  String DUPLICATE_TPNAME_CODE = "V071";
    
    public static final  String NON_CREDITABLE_CODE = "V072";        
    
    public static final  String INVALID_TP_ACCOUNT = "V073";
    
    public static final  String FAVORITES_LIMIT_VALID = "V080";
    
    public static final  String FAVORITES_DUPLICATE = "V081";
    
    public static final  String FAVORITES_NULL= "V082";
    
    public static final String INVALID_DD_LIMIT = "V073";//Demand draft limit is more than the SBI set limit.
    
    public static final String INVALID_THIRD_PARTY_LIMIT = "V074";//Third Party limit is more than the SBI set limit.

    public static final String CURRENT_USER_LINK_USER_MATCH_ERROR_CODE = "V075";//Linked user and mathced user are the same.
    
    public static final String OLDPASSWORD_NEWPASSWORD_MATCH = "V076";//Linked user and mathced user are the same.
     
    public static final  String INVALID_LOGIN_PASSWORD_ERROR_CODE = "V077"; //Old password is invalid    
    
/*** sms alert **/
    
    String SMS_ALERT_NAME_INVALID_ERROR_CODE = "V053";

    String SMS_ALERT_NICKNAME_INVALID_ERROR_CODE = "V054";

    
    
 //Customer Suport - Manikandan
    
    public static final String TICKETS_NOT_FOUND_CODE = "V100";
    
    public static final String INVALID_REFRENCE_NUMBER="V101";
    
    
    String ALERT_EXISTS_ERROR_CODE = "V102";

    String MAX_TP_ACCOUNT_LIMIT_ERROR_CODE = "V103"; //  Given Third Pary Limit is low compare with already defined TP Limit for your Third Party Account

    String INVALID_USERNAME_PASSWORD = "INVUN001";// changed for defect CR 2527

   // added by Murunga - Error code change for InterBranch transfer not allowed for Requests(StandingInstructions, LoanClousure)
    
   public static final  String INTER_BRANCH_TRANSFER_NOT_VALID_ERROR_CODE_REQUEST  = "V109"; // Inter bra
   public static final  String INVALID_ACCOUNT_NUMBER = "V110";
   
    public static final String ERROR_GENERATING_REFNO = "F002";
    
   // Added by srujana 25/01/06
    
    public static final String INPUT_VALUE_NULL_ERROR_CODE="F002";
    
    public static final String BRANCH_NOT_AVAILABLE_ERROR_CODE="SE021";    
    
    public static final String INITIAL_AMOUNT_NOT_VALID_ERROR_CODE="V106";
    
    public static final String DEPOSIT_PERIOD_NOT_VALID_ERROR_CODE="V107";
    
    // added for paladion on 3-july-06
    
    public static final String THIRD_PARTY_ACCT_LIMIT_ERROR_CODE="V111";
    
    public static final String USER_DD_LIMIT_ERROR_CODE="V112";
    
    public static final String DATA_NOT_FOUND = "CR001"; // Data Not Found
    
    public static final String INVALID_PASSWORD_1 = "PWD001";
    
	public static final String INVALID_PASSWORD_2 = "PWD002";
	
	//Added for CR-5550(nick name)/Immanuel
    public static final String NICK_NAME = "NIK";
   // Added for Mobile Registration -Start -->
 
    public static final String PENDINT_REQ_ERROR_CODE ="RM003";
    public static final String  INPUT_NULL_ERROR_CODE = "CR002";
   // Added for Mobile Registration -End -->
    public static final String  ERROR_CODE_VASCO = "VS001";
    
    //Added for eTDR/eSTDR -Start
    public static final String ACCOUNT_TEMPORARY_MASKED_CODE = "SAP002";
    public static final String AMOUNT_LIMIT_EXCEEDS_RTGS_LIMIT_ERROR_CODE = "CR0001";//RTGS Min Limit Check
    public static final String BLANK_MADATORY_FIELDS = "CR0004";//RTGS CREDIT ACOUNT NUMBER VALIDATION
    //Added for eTDR/eSTDR -End
}
