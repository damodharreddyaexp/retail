
package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;


public interface CorporateReportDAO{
	//modified for  corpuser paladion 
	  public List retrieveEcheques(String accountNo,String brCode,String fromDate,String toDate,String corporateId) throws DAOException;
	  public Map getPendingTransaction(Map inputParams) throws DAOException;
	  public List fileBasedEcheques(String fromDate,String toDate,String userName,String acountNo,String corpRole) throws DAOException;
	  public String generateRequestId(String fromDate,String toDate,String userName,String accountNo,String corpRole) throws DAOException;
	  public List viewEchequesDisplay(String userName) throws DAOException;
	 	//added for reissue challan cr
	    public List getTransactionsDetails(String userName,String date);
	public List getSARALTransactionsDetails(String userName,String fromDate,String toDate);
	  public String  generateRequestIdForDownloadFile(String fromDate,String toDate,String filename,String userName,String corporateId);//CR5564
	public String generateRequestIdForDownloadOltasFile(String fromDate,String toDate,String filename,String userName,String corporateId,String fileType);
	  public List viewDownloadFileRequestStatus(String userName) throws DAOException;//CR5564
	  public List getTransactionFiles(String userName,String requestId) throws DAOException;//CR5564
	  
	  public List getDownloadByExcelTransactionFiles(String userName,String requestId) throws DAOException;//CR5564
	  
	  //Added by Sairam for excel Report
	  public String generateExcelRequestId(String fromDate,String toDate,String userName,String formatType,String corporateId) throws DAOException;

	//Added for ddebit download file start
	  public String generateRequestIdForDDebitFile(String fromDate, String toDate,String filename,String userName) throws DAOException ;
	  
	// Added by Damodar
	  public String generateExcelRequestIdforMIS(String txnDate, String txnType, String accountNo,String userName,String formatType,String corporateId) throws DAOException;
	  public List MISviewEchequesDisplay(String userName) throws DAOException;
	  public List getMISDownloadByExcelTransactionFiles(String userName,String requestId) throws DAOException;
	  
	  
	  
	  public List viewDDebitFileRequestStatus(String userName) throws DAOException;
	  
	  public List getDDebitFiles(String userName,String requestId) throws DAOException;
	public String generateRequestIdForIB3PFileDownload(String fromDate,
			String toDate, String filename, String userName, String corporateId, String category);
	
	public List getBeneficiaryFiles(String userName,String requestId) throws DAOException;
  
	public List viewBenDownloadFileRequestStatus(String userName) throws DAOException;//CR5564

	//Added for ddebit download file end
	
	
	public String generateRequestIdForIMPStxnDownloadFile(String fromDate, String toDate,String filename, String userName,String corpId) throws DAOException;
	public List viewIMPStxnDownloadFileRequestStatus(String userName) throws DAOException;
	public List getIMPSTransactionFiles(String userName,String requestId) throws DAOException;
	
	public String generateRequestIdForIMPSbeneficiaryDownloadFile(String fromDate, String toDate,String filename, String userName,String corpId, String fileType) throws DAOException;
	public List viewIMPSbenDownloadFileRequestStatus(String userName) throws DAOException;
	public List getIMPSBeneficiaryFiles(String userName,String requestId) throws DAOException;
	
	public String  generateRequestIdForCompTxnFile(String fromDate,String toDate,String filename,String userName,String corporateId,String fileType);//CR5564
	//
	public String reqFailureTxn(Map inputParams) throws DAOException;
	public List downloadFailureTxnRequestStatus(String userName) throws DAOException;
	
}
