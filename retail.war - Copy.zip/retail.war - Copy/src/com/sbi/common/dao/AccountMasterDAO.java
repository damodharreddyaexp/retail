/*
 * AccountMasterDAO.java
 * Created on Oct 18, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 SK33412 - Initial Creation
package com.sbi.common.dao;

import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;

public interface AccountMasterDAO {
	public AccountDetails findAccountDetails(String accountNo, String branchCode);
    public AccountDetails findAccountDetails(Account account);
}
