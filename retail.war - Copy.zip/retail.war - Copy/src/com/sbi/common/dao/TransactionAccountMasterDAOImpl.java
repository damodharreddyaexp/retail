/*  
 * TransactionAccountMasterDAOImpl.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 SREENIVASULU - Initial Creation
// Nov 1, 2005 findAccountDetails(Account account) method added by BOOPATHI
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
// DEC 28, 2005 - BOOPATHI - EXCEPTION MODIFIED
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.dao.AccountDAOImpl.AccountRowMapper;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;
import com.sbi.common.model.TransactionAccountDetails;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

public class TransactionAccountMasterDAOImpl extends JdbcDaoSupport implements TransactionAccountMasterDAO
{

    protected final Logger logger = Logger.getLogger(getClass());

    private BankSystemDAO coreDAOImpl;

    public AccountDetails findAccountDetails(String accountNo, String branchCode)
    {
        return null;
    }

    public AccountDetails findAccountDetails(Account account) throws DAOException
    {

        logger.info("findAccountDetails(Account account) " + LoggingConstants.METHODBEGIN);

        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        if (account != null && account.getBankSystem() != null && account.getAccountNo() != null
                && !account.getAccountNo().trim().equalsIgnoreCase(DAOConstants.EMPTY)
                && account.getBranchCode() != null
                && !account.getBranchCode().trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {

            if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE))
            {
                logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromCore(account);
            }
            else
            {
                logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromDB(account);
            }

        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    private AccountDetails getTransactionAccountDetailsFromDB(Account account)
    {

        logger.info("getTransactionAccountDetailsFromDB(Account account) "+LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        try
        {

            Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode() };
            List resultList = getJdbcTemplate().query(SQLConstants.SBI_ACC_MASTER_DATA, parameters,
                    new AccountClassRowMapper());
            if (resultList != null && resultList.size() > 0)
            {
                if (resultList.size() == 1)
                {
                    return (AccountDetails) resultList.get(0);
                }
                else if (resultList.size() > 1)
                {
                    DAOException.throwException(ErrorConstants.FATAL_ERROR3_CODE);
                }
            }
        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;
    }

    class AccountClassRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            TransactionAccountDetails acc = new TransactionAccountDetails();

            acc.setAccountShortName(rs.getString(SQLConstants.SHORT_NAME));
            acc.setNomination(rs.getString(SQLConstants.NOMINATION));
            acc.setAccountDescription(rs.getString(SQLConstants.ACCOUNT_DESC));
            acc.setClearBalance(new Double(rs.getDouble(SQLConstants.CLEAR_BALANCE)));
            acc.setBookBalance(new Double(rs.getDouble(SQLConstants.BOOK_BALANCE)));
            acc.setDrawingPower(new Double(rs.getFloat(SQLConstants.DRAWING_POWER)));
            acc.setAmountOutStanding(new Double(rs.getFloat(SQLConstants.AMOUNT_OUTSTANDING)));
            acc.setSanctionedLimit(new Double(rs.getFloat(SQLConstants.SANCTIONED_LIMIT)));
            acc.setSanctionedDate(rs.getTimestamp(SQLConstants.SANCTIONED_DATE));
            acc.setCreditInterestRate(new Double(rs.getFloat(SQLConstants.CR_INT_RATE)));
            acc.setMaturityAmount(new Double(rs.getFloat(SQLConstants.MATURITY_AMOUNT)));
            acc.setMaturityDate(rs.getTimestamp(SQLConstants.MATURITY_DATE));
            acc.setPrincipal(new Double(rs.getFloat(SQLConstants.PRINCIPAL)));
            acc.setAccumulatedInterest(new Double(rs.getFloat(SQLConstants.ACCUMULATED_INTEREST)));
            acc.setOpeningDate(rs.getTimestamp(SQLConstants.OPENING_DATE));
            acc.setTenorDays(new Integer(rs.getInt(SQLConstants.TENOR_DAYS)));
            acc.setTenorMonth(new Integer(rs.getInt(SQLConstants.TENOR_MONTH)));
            acc.setTenorYear(new Integer(rs.getInt(SQLConstants.TENOR_YEAR)));
            acc.setPasswordFlag(rs.getBoolean(SQLConstants.PASSWORD_FLAG));
            acc.setDormantFlag(rs.getBoolean(SQLConstants.DORMANT_FLAG));
            acc.setLastUpdatedDate(rs.getTimestamp("last_updated_date"));
            return acc;
        }
    }

    private AccountDetails getTransactionAccountDetailsFromCore(Account account) throws DAOException
    {
        logger.info("getTransactionAccountDetailsFromCore(Account account)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        String txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;
        Map requestParams = new HashMap();
        requestParams.put(DAOConstants.ACCOUNT_NO, (String) account.getAccountNo());
        requestParams.put(DAOConstants.TXNNO, txnno);
        String bankCode = account.getBankCode();
    	if(bankCode == null){
    		bankCode=account.getBranchCode().substring(0,1);
    	}
        requestParams.put("bankCode",bankCode);
        List responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
        HashMap coreDataHash = (HashMap) responseList.get(0);
        String branchName = null;
        int branchCodeLength ;
        String padZeroes ="";
        
        String status = null;
        String errorCode = null; 
        
        
        if(coreDataHash.get("status") != null){
        	status = (String)coreDataHash.get("status");
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        if(coreDataHash.get("error_code") != null){
        	errorCode = (String)coreDataHash.get("error_code");
        	status = errorCode; 
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        
        if(status == null && errorCode == null){
        	
        	TransactionAccountDetails acc = new TransactionAccountDetails();
        	acc.setBranchCode((String) coreDataHash.get("branch_code"));
        	String branchCode = acc.getBranchCode();
        	logger.info("branchCode from Core : "+branchCode);
        	logger.info("bankCode  : "+bankCode);
        	acc.setBranchCode(branchCode);
        	if(branchCode != null && branchCode.length()!= 5)
        	{
        		for(branchCodeLength= branchCode.length(); branchCodeLength < 5; branchCodeLength++)
        		{
        			padZeroes = padZeroes + '0';
        		}
        		branchCode = padZeroes + branchCode;
        		logger.info("branchCode after padding : "+branchCode);
        		 acc.setBranchCode(branchCode);
        	}
        	else{
        		if( (bankCode!=null && "0|A|6|3|9".contains(bankCode) ) && 
							( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("1") ) )
        		{
		        	logger.info("branchCode before replace::"+ branchCode);
		        	branchCode = branchCode.replaceFirst("1", "A");
		        	logger.info("branchCode after replace::"+ branchCode);
		        }
        	}
        	
        	Object[] parameters = new Object[] {branchCode,branchCode};
          
            	String query ="select decode(nvl(a.branch_name,'*'),'*',(select branch_name from sbi_all_branches where branch_code = ?), " +
            			"a.branch_name) branch_name from (select branch_name from sbi_branch_master where branch_code = ?) a";
            	try
            	{
	            	Map branchNameMap = getJdbcTemplate().queryForMap(query, parameters);
	            	logger.info("***Branch Name selected from branch master/all branches table***");
	            	branchName=(branchNameMap.get("BRANCH_NAME")).toString();
            	}
            	catch(EmptyResultDataAccessException e)
            	{
            		logger.info("***Brach Name not present in branch master/all branches table***");
            		branchName="NA";
            	}
           /* if(result == 0)
            {
            	try
            	{
            		Map branchNameMap = getJdbcTemplate().queryForMap("select branch_name from sbi_all_branches where branch_code = ?", parameters);
	            	logger.info("***Branch code selected from all branches table***");
	            	branchName=(branchNameMap.get("BRANCH_NAME")).toString();
            	}
            	catch(EmptyResultDataAccessException e)
            	{
            		logger.info("***Brach code not present in all branches table***");
            		branchName="NA";
            	}
            }	*/
           
            acc.setBranchName(branchName);
            acc.setAccountDescription(account.getProductDescription());
        	acc.setCurrencyCode((String) coreDataHash.get(DAOConstants.CURRENCY_CODE));
        	acc.setAccountShortName((String) coreDataHash.get(DAOConstants.PROFILE_USER_NAME));
        	if (((String) coreDataHash.get(DAOConstants.NOMINATION)).trim().equalsIgnoreCase(DAOConstants.NO))
        		acc.setNomination(DAOConstants.ZERO);
        	else 
        		acc.setNomination(DAOConstants.ONE);
        	
        	
        	acc.setAvailableBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.AVAIL_BAL)));
        	acc.setBookBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.BOOK_BALANCE)));
        	acc.setDrawingPower(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.DRAWING_POWER)));
        	acc.setSanctionedLimit(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.LIMIT)));
        	acc.setCreditInterestRate(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.INTEREST_RATE)));
        	acc.setMaturityAmount(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.MATURITY_AMT)));
        	acc.setMaturityDate(coreDateToTimestamp((String) coreDataHash.get(DAOConstants.MATURITY_DATE)));
        	acc.setPrincipal(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.TERM_VALUE)));
        	acc.setAccumulatedInterest(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.ACCUMULATED_INTEREST)));
        	acc.setOpeningDate(coreDateToTimestamp((String) coreDataHash.get(DAOConstants.OPENING_DATE)));
        	acc.setTenorDays(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_DAYS)));
        	acc.setTenorMonth(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_MONTH)));
        	acc.setTenorYear(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_YEAR)));
        	//Added for CR-5171
        	acc.setHoldValue(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get("hold_value")));
        	String unClearBalance = (String)coreDataHash.get("unclear_balance");
        	acc.setUnClearBalance(StringUtils.emptyStringCheckForDouble(unClearBalance));
        	acc.setIfsCode(StringUtils.emptyCheck((String)coreDataHash.get("ifs_code")));
        		
        	logger.info("getTransactionAccountDetailsFromCore(Account account) +LoggingConstants.METHODEND");
        	return acc;
        }else{        	
        	DAOException.throwException(status);
        }
        return null;

    } 

    private Timestamp coreDateToTimestamp(String coreDateString)
    {
        logger.info("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODBEGIN);
        Timestamp timestamp = null;
        try
        {

            if (coreDateString != null && coreDateString.trim().length()>0)
            {
                SimpleDateFormat ts = new SimpleDateFormat(DAOConstants.DATA_FORMAT);
                Date sqlToday = new java.sql.Date(ts.parse(coreDateString).getTime());
                timestamp = new Timestamp(sqlToday.getTime());
                logger.info("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODEND);
                return timestamp;
            }

        }
        catch (ParseException e)
        {
            logger.fatal(LoggingConstants.EXCEPTION, e);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return timestamp;

    }

    private Integer emptyStringCheckForInteger(String responseString)
    {
        logger.info("emptyStringCheckForInteger(String responseString) " + LoggingConstants.METHODBEGIN);
        Integer intValue = new Integer(DAOConstants.ZERO);
        if (responseString != null && responseString.trim().length()>0)
        {
            try
            {
                intValue = new Integer(responseString);
            }
            catch (NumberFormatException nfx)
            {
                logger.fatal(LoggingConstants.EXCEPTION, nfx);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }
        if (logger.isDebugEnabled())
        {
            logger.debug("intValue :" + intValue);
        }
        logger.info("emptyStringCheckForInteger(String responseString) " + LoggingConstants.METHODEND);
        return intValue;
    }

    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl)
    {
        this.coreDAOImpl = coreDAOImpl;
    } 

}
