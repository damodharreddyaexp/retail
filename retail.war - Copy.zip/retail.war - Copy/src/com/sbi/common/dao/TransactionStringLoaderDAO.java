package com.sbi.common.dao;

import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.BankSystemComModel;

public interface TransactionStringLoaderDAO {
	void load( BankSystemComModel bankSystemComModel ) throws DAOException;
	void update(Map response,BankSystemComModel bankSystemComModel)throws DAOException;
}
