package com.sbi.common.dao;

import java.util.Map;

public interface CommissionDAO {

	Map getCommissionAmountForCorporate(String bankCode,String merchantCode,String corpId,Double debitAmount);
	Map getCommissionAmountForRetail(String bankCode,String type,Double debitAmount);
	/*	CR-5687 BEGIN - Ramanan	*/
	Map getCommissionAmountForCorporate(String bankCode,String merchantCode,String corpId,Double debitAmount, String productCode);
	Map getCommissionAmountForRetail(String bankCode,String type,Double debitAmount, String productCode);
	Map getDDCommissionAmountForCorporate(String bankCode,String merchantCode,Double debitAmount, String productCode);//DD Commission charge change CR 5774 - Sulthan
}
