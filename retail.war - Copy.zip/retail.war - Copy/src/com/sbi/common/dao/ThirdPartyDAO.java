/*
 * ThirdPartyDAO.java
 * Created on Dec 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 9, 2005 SG33414 - Initial Creation
package com.sbi.common.dao;

import java.util.ArrayList;
import java.util.List;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.ApproveDelTPModel;
import com.sbi.common.model.ApproveDelTPModelStatus;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.rtgs.model.CorporateTP;


public interface ThirdPartyDAO {
    


        public ApproveDelTPModel[] findDelTPsByFile(String userName, String fileName);

        // Modified by Sunjay S Galen
        
        public CorporateFile[] findTPDelFiles(String userName,String startDate,String endDate,Integer userRole);
        
        public CorporateFile[] findTPDelFilesView(String userName,String startDate,String endDate,Integer userRole);
        
        public ApproveDelTPModelStatus[] findDelTPsForView(String userName, String fileName);
        
        public ApproveDelTPModelStatus[] findDelTPsByStatus(String userName, String fileName, String[] approvedOIDs);
      
    public boolean updateDelTPState(String[] approvedOIDs, String userName);
    
    public String verify3PforDeletion( String corpID )throws  DAOException;
    //Added For CR 5390 Starts
    public List findApproveBeneficiary(String corpId,String userName,String type);
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public boolean approveBeneficiary(String userName,String approvedStatus,String remarks,String oids,String type, String corpID);
    
    public List getAlreadyAddedOids(String oids,String userName,String type);
    /* Ramanan M - Corp Admin Paladion Security Changes */
    public List getBeneficiaryByOid(String oids,String type, String corporateID);
  //Added For CR 5390 Ends
    
    //Added for eTDR
    public List getHolidaysList(String bankCode)throws DAOException;
    public List findCreditAccount(String userName,String corpId,String creditType) throws DAOException;
}
