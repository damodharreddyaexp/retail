package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.ChallanDetailsModel;
import com.sbi.common.service.ServiceErrorConstants;


public class DownloadChallanByDateDaoImpl extends JdbcDaoSupport implements DownloadChallanByDateDao {

    private final Logger logger = Logger.getLogger(getClass());

    //public final static String GET_CHALLAN_DETAILS = "select distinct(FILE_NAME) from sbicorp_echeque_master where corporate_id=? and  TRUNC (creation_time) = TO_DATE(?, 'dd/mm/yyyy') and file_name is not null AND MERCHANT_CODE IN ('CBEC','OLTAS')";
    
	  public final static String GET_CHALLAN_DETAILS = "select distinct(FILE_NAME) from sbicorp_echeque_master where trim(corporate_id)=:1 and  TRUNC (creation_time) = TO_DATE(:2, 'dd/mm/yyyy') and file_name is not null AND trim(MERCHANT_CODE) IN ('CBEC','OLTAS')";
	
	
    public final static String GET_FILE_STATUS = "select distinct  decode(current_auth_level,0,'Processed','PartiallyProcessed') file_status from sbicorp_echeque_master where corporate_id=? and file_name=? ";


    public List getChallanDetails(String corporateId,String startdate)throws DAOException {
    logger.info("getChallanDetails(String corporateId) method begins:  : "+corporateId+"startdate "+startdate);
    List challanDetailsList = null;
    try {
    Object[] params = {corporateId,startdate};
    challanDetailsList = getJdbcTemplate().query(GET_CHALLAN_DETAILS,params, new DownloadChallanMapper());
    if(challanDetailsList !=null)
    logger.info("inboxList size "+challanDetailsList.size());
    } catch (DataAccessException exp) {
    logger.error("Exception occured: " + exp.getMessage(),exp);
    DAOException.throwException(ServiceErrorConstants.SE003);
    }
    logger.info("getChallanDetails(String corporateId) method ends");
    return challanDetailsList;
    }

    public class DownloadChallanMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        	ChallanDetailsModel challanDetails = new ChallanDetailsModel();
            challanDetails.setFileName((rs.getString("FILE_NAME")));
            return challanDetails;
        }

    }
    
	public String getFileStatus(String corporateId,String fileName) {
		logger.info("getFileStatus(String corporateId,String fileName)-begin");
		Object[] params = new Object[] {corporateId,fileName};
		String stCode = null;
		try {
			List fileStatus = getJdbcTemplate().queryForList(GET_FILE_STATUS, params);
			if(fileStatus!=null && fileStatus.size()>0){
				Map stCodeMap=(Map)fileStatus.get(0);
				stCode=(String)stCodeMap.get("FILE_STATUS");
				logger.info(" stCode ="+stCode);
			}	
				
		} catch (DataAccessException e) {
			 logger.error("Error occured :" , e);
			DAOException.throwException(
					ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
		}
		logger.info("getFileStatus(String corporateId,String fileName)-end");
		return stCode;
	}


 
}
