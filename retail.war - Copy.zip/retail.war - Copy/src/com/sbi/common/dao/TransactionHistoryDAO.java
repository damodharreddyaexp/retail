/*  
 * TransactionHistoryDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18,2005  MURNGAN K - method's implementation 
package com.sbi.common.dao;

import java.util.List;
import java.util.Map;
import java.sql.Timestamp;
 
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;

/**
 * TODO TransactionHistoryDAO interface
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public interface TransactionHistoryDAO {


    /**
     * TODO Query to get data from TransactionHistory table filtering by date
     * @param account object 
     * @param fromDate
     * @param toDate
     * @param order
     * @return List
     * @return corporateId
     */

	List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order,String corporateId) throws DAOException;
	
	List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order,String corporateId, String timestamp, String type) throws DAOException;	
	
  	
    /**
     * TODO Query to get data from TransactionHistory table filtering by date
     * @param account object 
     * @param fromDate
     * @param toDate
     * @param order
     * @return List
     */

    List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order) throws DAOException;

    /**
     * TODO Query to get data from TransactionHistory table 
     * @param account
     * @param limit
     * @return List
     */
 
    /**
     * TODO Enter the description of the method here
     * @param account
     * @param limit
     * @return
     * @throws DAOException List
     */
    List findTransactionHistory(Account account, int limit) throws DAOException;

    /**
     * TODO Enter the description of the method here
     * @param accountNo
     * @param branchCode
     * @param chequeNumber
     * @return
     * @throws DAOException List
     */
    List findChequeStatus(String accountNo,String branchCode, Integer[] chequeNumber) throws DAOException;
    
    /**
     * TODO Enter the description of the method here
     * @param account
     * @param fromDate
     * @param toDate
     * @param toAmount
     * @param fromAmount
     * @param transactionType
     * @return
     * @throws DAOException List
     */
    List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, Double toAmount,Double fromAmount,String transactionType) throws DAOException;
    
    /** 
     * TODO Enter the description of the method here
     * @return String[][]
     */
    Map findTransctionTypeCode();

 List findLatestBalance(Account account) throws DAOException;
 
 Timestamp findUpdatedDateForNonCore(String branchCode); 
 
 /**
  * TODO IR 71227
  * @param account
  * @param fromDate
  * @param toDate
  * @param toAmount
  * @param fromAmount
  * @param transactionType
  * @return
  * @throws DAOException List
  */
 List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, String fromAmount, String toAmount) throws DAOException;
 
}
 