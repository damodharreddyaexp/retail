package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;

public interface SuvidhaMakePaymentDAO {

	 public List retrieveStateInstitutionType()  throws DAOException;
	 public List retrieveInstitutions(String state,String instType) throws DAOException;
	 public List retrieveFeePaymentDetails(String instID,String userRole) throws DAOException;
	 public List retrieveCategories(String instID,String userRole) throws DAOException;
	 public List retrieveCategoryParams(String categoryID) throws DAOException;
	 
	 public List findSuvidhaPaymentDetails(String userName,String fromDate,String toDate);
	 public Map findsuvidhaParamDetails(String categoryId);
	 public Map getServiceChargeDetails(String instituteId);
	 public Map getDescriptionDetails(String categoryID);//Dynamic Notification  - Imman
	 List findPenaltyDetails(String categoryId) throws DAOException; //iCollect Penalty
	 //Parameshwaran: Added for iCollect File Mode changes
	 public String retrieveFileModeCategoryParamValues(String selectedInstID,String serialNumber) throws DAOException;
	 public List retrieveFileModeCategoryParams(String categoryID) throws DAOException;
	 public List retrieveIncrementalCategorys(String corporateId) throws DAOException;
	//Added for SB Collect -uploader preview
	 public List retrieveCategoryParamsUploader(String categoryID) throws DAOException;
	 public List retrieveInstitutions(String state,String instType,String bankCode) throws DAOException;
	//Added for SB Collect -corpadmin manage institute by M_MANIKANDAN
	 public List suvidhaRetrieveStateInstitutionType(String bankCode) throws DAOException;
	 public String suvidhaRetrieveCorprate(String instituteId) throws DAOException;
	 public int suvidhaEnableInstitutes(String INSTITUTE_ID, String CORP_ID,String INSTITUTE_NAME,String USER_NAME,String STATUS,String state,String instType,String ADMIN_CORP_ID)throws DAOException;
	 public List suvidhaRetrieveEnabledInstitutionType(String USER_NAME) throws DAOException;
	 public List suvidhaRetrieveEnabledInstitutions(String state,String instType,String userName) throws DAOException;
	 public int suvidhaDisableInstitutes(String INSTITUTE_ID,String USER_NAME);
	 public List suvidhaRetrieveExistenabledInstitutions(String INSTITUTE_ID,String USER_NAME) throws DAOException;
	 public  int suvidhaReenableInstitutes(String INSTITUTE_ID,String USER_NAME)throws DAOException; 
	 public int suvidhaRetrievePendingEchques(String INSTITUTE_ID,String USER_NAME)throws DAOException; 
}
