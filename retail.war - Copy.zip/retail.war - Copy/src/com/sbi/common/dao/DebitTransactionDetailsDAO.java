package com.sbi.common.dao;

import com.sbi.common.model.CorpTransactionLeg;

public interface DebitTransactionDetailsDAO {
	
	CorpTransactionLeg getEcheque(String echequeNo);
	
	public String getCorpTransactionStatus(String key);
	
}
