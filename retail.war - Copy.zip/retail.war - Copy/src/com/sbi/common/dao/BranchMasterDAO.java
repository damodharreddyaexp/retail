/* 
 * BranchMasterDAO.java
 * Created on Oct 29, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 29, 2005 BOOPATHI - Initial Creation

package com.sbi.common.dao;

import java.util.List; 
import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Branch;

public interface BranchMasterDAO 
{
    List findAllBranches();
    Branch  findBranchDetails(String branchCode);
    String findBankSystem(String BranchCode);
    String[][] findBranchesWithCode(String location,String bankCode);    
    List findAllStates();
    List findLocation(String state);
    List findLocation();
    List findBranches(String location);
    List findINBLocation(String bankCode);
    List findINBBranches(String location);    
    String[][] findINBBranchesWithCode(String location,String bankCode);    
    List findAllLocations(String bankCode); 
    Map findAllBranchesWithCode()throws DAOException;
    String findBranchName(String branchCode)throws DAOException;
    
    //Added For CR-5602 by Shreya
    String[][] findBankName(String branch,String location);
    List findRTGSBankName();
    List findRTGState(String bankName);
    
    boolean findINBBranch(String branchCode );
    boolean findSBIBRanch(String branchCode);
    //CR 2879
    Map findAllBranchesWithCode(String bankCode)throws DAOException;
    String findBranchIOIEnabled(String branchCode) throws DAOException;//Added for DD IOI
    Branch getNeftbankName(String ifscCode) throws DAOException;//Added for 5552 temporary fix
}
