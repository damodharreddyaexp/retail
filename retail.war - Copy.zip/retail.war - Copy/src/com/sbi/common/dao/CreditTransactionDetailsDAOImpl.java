package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CorpTransactionLeg;

public class CreditTransactionDetailsDAOImpl extends JdbcDaoSupport implements CreditTransactionDetailsDAO{
	
	protected final Logger logger = Logger.getLogger(getClass());
//	private CorpUserDAO corpUserDAOImpl;
//	private static final String FindCreditDetails = "select * from sbi_ib_credits where debit_reference_no = ?";
	
	//added by Karthik
	private static final String FindCreditDetailsForCN = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from bvsbi.sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,(select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,( select transaction_status from sbi_utr_status f  where f.reference_no=a.utr_no and rownum <2 )utr_credit_status,a.* from bvsbi.sbi_ib_credits a  where debit_reference_no = ? ) WHERE RNO BETWEEN ? AND ?";
	
	private static final String FindCreditDetailsForCZ = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from bvsbi.sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,(select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,( select transaction_status from sbi_utr_status f  where f.reference_no=a.utr_no and rownum <2 )utr_credit_status,a.* from bvsbi.sbi_ib_credits a  where debit_reference_no = ? ) WHERE RNO BETWEEN ? AND ?";
	
	class CreditTransactionDetailsRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
      
        	CorpTransactionLeg  corpTransactionLeg = new CorpTransactionLeg();
        	corpTransactionLeg.setDebitReferenceNo(rs.getString("debit_reference_no"));        	
        	corpTransactionLeg.setCreditReferenceNo(rs.getString("credit_reference_no"));
        	corpTransactionLeg.setAccountNo(rs.getString("account_no"));
        	corpTransactionLeg.setBranchCode(rs.getString("branch_code"));
        	corpTransactionLeg.setAmount(new Double(rs.getDouble("amount")));
        	corpTransactionLeg.setOriginalDebitBranch(rs.getString("original_debit_branch"));
        	corpTransactionLeg.setCreditStatus(rs.getString("credit_status"));
        	corpTransactionLeg.setStatusDescription(rs.getString("status_description"));
        	corpTransactionLeg.setCreditDescription(rs.getString("credit_description"));
        	corpTransactionLeg.setCreditNarrative1(rs.getString("credit_narrative1"));
        	corpTransactionLeg.setCreditNarrative2(rs.getString("credit_narrative2"));
        	corpTransactionLeg.setCreditNarrative3(rs.getString("credit_narrative3"));
        	logger.info("credit_narrative3 value:::"+rs.getString("credit_narrative3"));
        	logger.info("credit_reference_no value:::"+rs.getString("credit_reference_no"));
        	        	 
        	try {
        		if(rs.getString("credit_narrative3") == null || rs.getString("credit_narrative3").equals("")){
        			corpTransactionLeg.setCreditNarrative3(rs.getString("credit_narrative7"));
        		}
			} catch (Exception e) {			}
        	
			corpTransactionLeg.setCorpRefNo(rs.getString("corp_ref_no"));
        	corpTransactionLeg.setRecoRequired(rs.getString("reco_required"));
        	corpTransactionLeg.setCreationTime(rs.getString("creation_time"));
        	corpTransactionLeg.setFileName(rs.getString("file_name"));
        	corpTransactionLeg.setCreditsCreated(rs.getString("credits_created")); 
        	corpTransactionLeg.setErrorCode(rs.getString("error_code"));
        	corpTransactionLeg.setName(rs.getString("name"));
        	corpTransactionLeg.setUserName(rs.getString("user_name"));
        	corpTransactionLeg.setProductType("product_type");
        	corpTransactionLeg.setLastModTime(rs.getTimestamp("last_mod_time"));
        	corpTransactionLeg.setType(rs.getString("CREDIT_TYPE"));
        	corpTransactionLeg.setNarrative1(rs.getString("credit_narrative1"));
        	corpTransactionLeg.setNarrative2(rs.getString("credit_narrative2"));
        	
        	           	
            logger.info("substring of credit reference NO :"+corpTransactionLeg.getCreditReferenceNo().substring(0,2));
            
            String merchCode="|CR||CN|CZ";
            if (merchCode.indexOf(corpTransactionLeg.getCreditReferenceNo().substring(0,2))>0)
            {
                 corpTransactionLeg.setUtrNo(rs.getString("utr_no"));
                 logger.info("utr no :::"+corpTransactionLeg.getUtrNo());
            }
            
            String merchNEFTCode="CN";
            if (merchNEFTCode.contains(corpTransactionLeg.getCreditReferenceNo().substring(0,2)))
            {
                 corpTransactionLeg.setUtrCreditStatus(rs.getString("utr_credit_status"));
                 //corpTransactionLeg.setUtrCreditStatus("PENDING");
                 logger.info("UtrCreditStatus :::"+corpTransactionLeg.getUtrCreditStatus());
            }
             merchNEFTCode="CZ";
            if (merchNEFTCode.contains(corpTransactionLeg.getCreditReferenceNo().substring(0,2)))
            {
                 corpTransactionLeg.setUtrCreditStatus(rs.getString("utr_credit_status"));
                 //corpTransactionLeg.setUtrCreditStatus("PENDING");
                 logger.info("UtrCreditStatus :::"+corpTransactionLeg.getUtrCreditStatus());
            }
        	return corpTransactionLeg; 
        }
    }
	public Map findCredits(String debitReferenceNumber,String pageNo, String limit) {
		
		logger.info("findCredits(String debitReferenceNumber) method begin");
		if (logger.isDebugEnabled()) {
            logger.debug("DebitReferenceNumber  : " + debitReferenceNumber);     
        }
		Map result = new HashMap();
		logger.info("findCredits(String debitReferenceNumber) method begin2..."+debitReferenceNumber);
		String pagenationQuery = "SELECT * FROM (select ROWNUM RNO, decode(nvl(CREDIT_NARRATIVE3,'*'),'*',(select NAME_THIRD_PARTY from bvsbi.sbicorp_third_party where account_no=a.account_no and branch_code=a.branch_code and corporate_id = a.corporate_id and status = 1 and rownum < 2 ), CREDIT_NARRATIVE3) CREDIT_NARRATIVE7,(select outref7 from bvsbi.sbi_ib_transactions where narrative1=a.account_no and substr(narrative2,0,5)=a.branch_code and corporate_id = a.corporate_id and substr(reference_no,0,10) = a.debit_reference_no and substr(reference_no,11,5) != '00000' and rownum < 2) beneficiary_code,a.* from bvsbi.sbi_ib_credits a  where debit_reference_no = ? ) WHERE RNO BETWEEN ? AND ?";
		String sqlCount = "select count(*) from sbi_ib_credits where debit_reference_no = ?";
		List pendingEhequeList = null;
		if(debitReferenceNumber!=null){
			try
			{ 
				Object[] params = {debitReferenceNumber,((Integer.parseInt(pageNo)*Integer.parseInt(limit))-Integer.parseInt(limit))+1,
						Integer.parseInt(pageNo)*Integer.parseInt(limit)};
				
				Object[] parametersCount = {debitReferenceNumber};
				
				int[]sqlTypesCount = {Types.VARCHAR};
				int count=getJdbcTemplate().queryForInt(sqlCount,parametersCount,sqlTypesCount);
				
				if(debitReferenceNumber.substring(0,2).equalsIgnoreCase("CN")){
					pendingEhequeList = (List)getJdbcTemplate().query(FindCreditDetailsForCN,params, new CreditTransactionDetailsRowMapper());
										
						if(pendingEhequeList!= null ){
							result.put("pendingEcheques", pendingEhequeList);
						}
				}
				else if (debitReferenceNumber.substring(0,2).equalsIgnoreCase("CZ")){
					pendingEhequeList = (List)getJdbcTemplate().query(FindCreditDetailsForCZ,params, new CreditTransactionDetailsRowMapper());
					
					if(pendingEhequeList!= null ){
						result.put("pendingEcheques", pendingEhequeList);
					}
			}
				else
				{
					 pendingEhequeList = (List)getJdbcTemplate().query(pagenationQuery,params, new CreditTransactionDetailsRowMapper());
					if(pendingEhequeList!= null){
						result.put("pendingEcheques", pendingEhequeList);
					}
				}
								
				result.put("totalCount", count);
				logger.info("findCredits(String debitReferenceNumber) method End");
				return result;
			}
			catch(DataAccessException dataAccessException)
			{
				dataAccessException.printStackTrace();
				DAOException.throwException("DTD002",new Object [] {debitReferenceNumber});
			}
		}else{
			 DAOException.throwException("DTD001",new Object [] {debitReferenceNumber});
		}
		 return result;
	}
//	public void setCorpUserDAOImpl(CorpUserDAO corpUserDAOImpl) {
//		this.corpUserDAOImpl = corpUserDAOImpl;
//	}
}
