/*
 * CompositeFileConfigDAO.java
 * Created on Aug 6, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;



public interface CompTxnFileDAO
{
	List getFileConfiguration(String corporateId,String fileType) throws DAOException;
	
	List getNewFileConfiguration(String corporateId,String fileType) throws DAOException;
	
	public int findConfigCount(String corporateId) throws DAOException;
	public int findConfigtxnCount(String corporateId,String replacedString) throws DAOException;
	
	public int deleteOldConfig(String corporateId,String format) throws DAOException ;
	
    public int insertFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType) throws DAOException;
    
    public Map updateFileConfigComp(int formatVal,String corporateId,String fieldDelimter,String compConfigType)throws DAOException;
     
}
