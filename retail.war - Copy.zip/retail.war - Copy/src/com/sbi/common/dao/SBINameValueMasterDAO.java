/*  
 * SBINameValueMasterDAO.java
 * Created on Nov 4, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Nov 4, 2005 BOOPATHI - Initial Creation

package com.sbi.common.dao;

import java.util.Map;

public interface SBINameValueMasterDAO
{

    Map getNameValueMasterData();
    Map getSBISwitchErrorData();
    Map getSBICoreErrorData();
    Map findAllBranchName();
    /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
    Map findAllNREProductCodes();
    Map getPortNumberData(String processorName);
}
