package com.sbi.common.dao;


import java.util.Map;


public interface CreditTransactionDetailsDAO {
	
	Map findCredits( String debitReferenceNumber,String pageNo, String limit);

}
