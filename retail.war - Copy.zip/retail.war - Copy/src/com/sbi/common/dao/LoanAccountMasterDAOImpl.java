/*
 * LoanAccountMasterDAOImpl.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 SREENIVASULU - Initial Creation
// Nov 1, 2005 findAccountDetails(Account account) method added by BOOPATHI
//NOV 23 2005 - BOOPATHI - CONSTANTS ADDED 
// DEC 28, 2005 - BOOPATHI - EXCEPTION MODIFIED
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;
import com.sbi.common.model.LoanAccountDetails;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

public class LoanAccountMasterDAOImpl extends JdbcDaoSupport implements LoanAccountMasterDAO
{

    protected final Logger logger = Logger.getLogger(getClass());

    private BankSystemDAO coreDAOImpl;

    public AccountDetails findAccountDetails(String accountNo, String branchCode)
    {
        logger.info("findAccountDetails(String accountNo, String branchCode) "+LoggingConstants.METHODBEGIN );
        return null;
    }

    public AccountDetails findAccountDetails(Account account) throws DAOException
    {

        logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        if (account != null && account.getBankSystem() != null && account.getAccountNo() != null
                && !account.getAccountNo().trim().equalsIgnoreCase(DAOConstants.EMPTY)
                && account.getBranchCode() != null
                && !account.getBranchCode().trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {

            if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE))
            {
                logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromCore(account);
            }
            else
            {
                logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
                return getTransactionAccountDetailsFromDB(account);
            }

        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    private AccountDetails getTransactionAccountDetailsFromDB(Account account)
    {
        logger.info("getTransactionAccountDetailsFromDB(Account account) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode() };
        try
        {
            List resultList = getJdbcTemplate().query(SQLConstants.SBI_LOAN_ACC_MASTER_DATA, parameters,
                    new LoanAccountClassRowMapper());
            if (resultList != null && resultList.size() > 0)
            {
                if (resultList.size() == 1)
                    return (AccountDetails) resultList.get(0);

                else if (resultList.size() > 1)
                {
                    DAOException.throwException(ErrorConstants.FATAL_ERROR3_CODE);
                }
            }
        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        return null;

    }

    class LoanAccountClassRowMapper implements RowMapper
    { 
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {

            LoanAccountDetails acc = new LoanAccountDetails();
            acc.setAccountDescription(rs.getString(SQLConstants.ACCOUNT_DESC));
            acc.setAccountShortName(rs.getString(SQLConstants.SHORT_NAME));
            acc.setSanctionedLimit(new Double(rs.getDouble(SQLConstants.SANCTIONED_LIMIT)));
            acc.setInterestRate(new Double(rs.getDouble(SQLConstants.INTEREST_RATE)));
            acc.setDrawingPower(new Double(rs.getDouble(SQLConstants.DRAWING_POWER)));
            acc.setAmountOutStanding(new Double(rs.getDouble(SQLConstants.AMOUNT_OUTSTANDING)));
            acc.setSanctionedAmount(new Double(rs.getDouble(SQLConstants.SANCTIONED_AMOUNT)));
            acc.setLastUpdatedDate(rs.getTimestamp("last_updated_date"));
            return acc;
        }
    }

    private AccountDetails getTransactionAccountDetailsFromCore(Account account) throws DAOException
    {

        logger.info("getTransactionAccountDetailsFromCore(Account account)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("account :" + account);
        }
        String txnno = DAOConstants.LONG_ENQ_LOANS;

        Map requestParams = new HashMap();
        requestParams.put(DAOConstants.ACCOUNT_NO, (String) account.getAccountNo());
        requestParams.put(DAOConstants.TXNNO, txnno);
        requestParams.put("bankCode",account.getBranchCode().substring(0,1));
        List responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
        HashMap coreDataHash = (HashMap) responseList.get(0);
        
        
        String status = null;
        String errorCode = null;
        
        if(coreDataHash.get("status") != null){
        	status = (String)coreDataHash.get("status");
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        if(coreDataHash.get("error_code") != null){
        	errorCode = (String)coreDataHash.get("error_code");
        	status = errorCode; 
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        
        if(status == null && errorCode == null){
        
        	LoanAccountDetails acc = new LoanAccountDetails();
        	acc.setAccountDescription(account.getProductDescription());
        	acc.setCurrencyCode((String) coreDataHash.get(DAOConstants.CURRENCYCODE));
        	acc.setAccountShortName((String) coreDataHash.get(DAOConstants.NAME));
        	acc.setDrawingPower(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.DRAWINGPOWER)));
        	acc.setAmountOutStanding(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.AMOUNTOUTSTANDING)));
        	acc.setSanctionedLimit(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.SACTIONED_LIMIT)));
        	acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.INTERESTRATE)));
        	acc.setIfsCode(StringUtils.emptyCheck((String)coreDataHash.get("ifs_code")));
        	
        	logger.info("getTransactionAccountDetailsFromCore(Account account) +LoggingConstants.METHODEND");
        	return acc;
        }else{        	
        	DAOException.throwException(status);
        }
        return null;

    }
 // CR 147 start
	public AccountDetails findLoanAccountDetails(Account account)
			throws DAOException {

		if (logger.isDebugEnabled()) {
			logger.debug("findLoanAccountDetails(Account account)"
					+ LoggingConstants.METHODBEGIN);
			logger.debug("Account :" + account);
		}
		if (account != null) {
			return getTransactionLoanAccountDetailsFromCore(account);

		} else {
			DAOException
					.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return null;
	}

	private AccountDetails getTransactionLoanAccountDetailsFromCore(
			Account account) throws DAOException {

		if (logger.isDebugEnabled()) {
			logger.debug("getTransactionAccountDetailsFromCore(Account account)"
					+ LoggingConstants.METHODBEGIN);
			logger.debug("account :" + account);
		}
		String txnno = "010400";

		Map requestParams = new HashMap();
		requestParams.put(DAOConstants.ACCOUNT_NO,
				(String) account.getAccountNo());
		logger.debug("account bankCode:" + account.getBankCode());
		String bankCode = account.getBankCode();
    	if(bankCode == null){
    		bankCode=account.getBranchCode().substring(0,1);
    	}
        requestParams.put("bankCode",bankCode);
		// associate banks - boopathi
		
		requestParams.put(DAOConstants.TXNNO, txnno);

		// commented for testing purpose
		List responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
		HashMap coreDataHash = (HashMap) responseList.get(0);
		String branchName = null;
		int branchCodeLength ;
        String padZeroes = "";
        
		String status = null;
		String errorCode = null;

		/*
		 * if (coreDataHash.get("status") != null) { status = (String)
		 * coreDataHash.get("status"); if (status.trim().length() == 0) status =
		 * "ERR."; } if (coreDataHash.get("error_code") != null) { errorCode =
		 * (String) coreDataHash.get("error_code"); status = errorCode; if
		 * (status.trim().length() == 0) status = "ERR."; }
		 */

		if (status == null && errorCode == null) {

			LoanAccountDetails acc = new LoanAccountDetails();
			acc.setBranchCode((String) coreDataHash.get("branch_code"));
			String branchCode = acc.getBranchCode();
			logger.info("branchCode from Core : "+branchCode);
        	logger.info("bankCode  : "+bankCode);
        	acc.setBranchCode(branchCode);
        	if(branchCode != null && branchCode.length()!= 5)
        	{
        		for(branchCodeLength= branchCode.length(); branchCodeLength < 5; branchCodeLength++)
        		{
        			padZeroes = padZeroes + '0';
        		}
        		branchCode = padZeroes + branchCode;
        		logger.info("branchCode after padding : "+branchCode);
        		acc.setBranchCode(branchCode);
        	}
        	else{
        		if( (bankCode!=null && "0|A|6|3|9".contains(bankCode) ) && 
							( branchCode!=null && branchCode.substring(0,1).equalsIgnoreCase("1") ) )
        		{
		        	logger.info("branchCode before replace::"+ branchCode);
		        	branchCode = branchCode.replaceFirst("1", "A");
		        	logger.info("branchCode after replace::"+ branchCode);
		        }
        	}
        	
        	Object[] parameters = new Object[] {branchCode,branchCode};
          
        	String query ="select decode(nvl(a.branch_name,'*'),'*',(select branch_name from sbi_all_branches where branch_code = ?), " +
        			"a.branch_name) branch_name from (select branch_name from sbi_branch_master where branch_code = ?) a";
        	try
        	{
            	Map branchNameMap = getJdbcTemplate().queryForMap(query, parameters);
            	logger.info("***Branch Name selected from branch master/all branches table***");
            	branchName=(branchNameMap.get("BRANCH_NAME")).toString();
        	}
        	catch(EmptyResultDataAccessException e)
        	{
        		logger.info("***Brach Name not present in branch master/all branches table***");
        		branchName="NA";
        	}
        	
        	acc.setBranchName(branchName);
			acc.setAccountDescription(account.getProductDescription());		
			acc.setCurrentYearInterest(StringUtils
					.emptyStringCheckForDouble((String) coreDataHash
							.get("cur_year_interest")));
			acc.setPreviousYearInterest(StringUtils
					.emptyStringCheckForDouble((String) coreDataHash
							.get("pre_year_interest")));

			if (logger.isDebugEnabled())
				logger.debug("getTransactionAccountDetailsFromCore(Account account)"
						+ LoggingConstants.METHODEND);
			return acc;
		} else {
			DAOException.throwException(status);
		}
		return null;

	}

	// CR 147 end
    
    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl)
    {
        this.coreDAOImpl = coreDAOImpl;
    } 
}
