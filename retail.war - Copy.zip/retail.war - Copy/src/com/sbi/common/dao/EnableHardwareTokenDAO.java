package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.HardwareTokenDetails;

public interface EnableHardwareTokenDAO {
	public HardwareTokenDetails insertUserDetails(Integer userId,String branchCode,Integer userRole,String corporateId,String userAlias,String friendlyName)throws  DAOException;
	  public List getC10Users(String userName, String corporateID,String ppID,String flag) throws DAOException ;
	  
	  public List getC10FormListDetails(String userId, String corporateID) throws DAOException;
		
	  public HardwareTokenDetails getC10FormDetails(String referenceNo) throws DAOException;

}
