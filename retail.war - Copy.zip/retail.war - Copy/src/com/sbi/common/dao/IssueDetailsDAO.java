package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Mail;

public interface IssueDetailsDAO {

	public List findIssues(Map inParams) throws DAOException;
	
	public Map insertTicketDetails(Map inParams) throws DAOException;
	
	public List findTickets(Map inParams) throws DAOException;
	
	public List findTicketThreadsDetails(Map inParams) throws DAOException;
	
	public void updateTicketDetails(Map inParams) throws DAOException;
	
	public void deleteTicketDetails(Map inParams) throws DAOException;
	
	public void markAsUnread(List  ticketList) throws DAOException;
	
	public List findMails(Map inParams) throws DAOException;
	
	public void updateMailBox(Map inParams) throws DAOException;
	
	public void markMailAsUnread(List  ticketList,String userName) throws DAOException;
	
	public String findMailDetails(String mailReference);
	
	public int getUnReadMails(Map inParams)throws DAOException;
	public List findMailsForAssociateBank(Map inParams) throws DAOException;
	
}
