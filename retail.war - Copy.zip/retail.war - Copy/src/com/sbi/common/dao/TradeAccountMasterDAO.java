/*
 * TradeAccountMasterDAO.java
 * Created on Sep 14, 2006
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Sep 14, 2006 Meena - Initial Creation

package com.sbi.common.dao;


public interface TradeAccountMasterDAO extends AccountMasterDAO 
{
	
}