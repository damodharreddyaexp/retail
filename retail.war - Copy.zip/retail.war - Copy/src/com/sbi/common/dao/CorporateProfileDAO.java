/**
 * @(#) CorporateProfileDAO.java
 */

package com.sbi.common.dao;

import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.SPOutput;
import com.sbi.common.model.UserProfile;

public interface CorporateProfileDAO {
	CorporateProfile findCorporateProfileDetails(String corporateID);
	
	//5472
	/* Ramanan M - Corp Admin Paladion Security Changes */
	public SPOutput resetLoginPassword(String userName,String passWord, String corporateID) throws DAOException;
	public UserProfile getUserProfileDetails(String userName) throws DAOException;//Changed For CR 5472 Defect
	String[][] getResetPassUserDetails(String caUser, String roleID, String corporateID) throws DAOException;
	public UserProfile insertResetPWDPPKit(Map inParams) throws DAOException;
	public boolean isRequestSubmitted(Map inParams) throws DAOException;
	/* Ramanan M - Corp Admin Paladion Security Changes */
	public boolean isValidUserForCorporate(String userName, String corporateID) throws DAOException;
}
