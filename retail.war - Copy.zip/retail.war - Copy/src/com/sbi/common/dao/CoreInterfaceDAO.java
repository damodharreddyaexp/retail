/*
 * CoreInterfaceDAO.java
 * Created on Oct 20, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 20, 2005 BOOPATHI - Initial Creation
//JAN  06, 2005 BOOPATHI - NEW METHOD ADDED
//JAN 18,  2005 BOOPATHI - NEW METHOD ADDED
package com.sbi.common.dao;

import java.util.List;

public interface CoreInterfaceDAO
{

    /**
     * Executes the query [select * from CoreInterface where txnid=? and
     * type="REQ" order by txnid, order] and returns the output as list
     */
    List findCoreRequestData(String transactionID);

    
    /**
     * Executes the query [select * from sbi_Core_Interface where txnid=? and
     * type="REQ" order by txnid, order] and returns the output as list
     */
    List findCoreRequestData(String transactionID,String bankCode);// added for CR 5553 
    
    /**
     * Executes the query [select * from CoreInterface where txnid=? and
     * type="RES" order by txnid, order] and returns the output as list
     */
    List findCoreResponseData(String transactionID);
    
    int getMessageID();
     
    
}
