/*
 * DematDAOImpl.java
 * Created on Aug 9, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 9, 2006 VS23778 � Initial Creation
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.DematLienEnquiry;
import com.sbi.common.service.ServiceErrorConstants;

public class DematDAOImpl extends JdbcDaoSupport implements DematDAO {
	

	//Map result;

	protected final Logger logger = Logger.getLogger(getClass());
	
	private String INSERT_SBI_EZTRADE_NRI_REG_DETAILS="insert into SBI_EZTRADE_NRI_REG_DETAILS (user_name,name,account_no,branch_code,address,contact_no,email_id,mobile_no,creation_time,last_mod_time)values(?,?,?,?,?,?,?,?,sysdate,sysdate)";
	
	private String GET_EBROKINGID="select ebroking_id from sbi_dmat_reg_details where user_name=? and merchant_code='NOW'";
	//private String GET_EBROKING_ID_CORP="select distinct(a.ebroking_id) from sbi_dmat_reg_details a,sbicorp_dmat_lien_details b where a.bank_account_no=b.account_no and b.maker=? and b.merchant_code='NOW'";
	
	private String GET_EBROKING_ID_CORP="select distinct( a.ebroking_id)from sbi_dmat_reg_details a,sbicorp_dmat_lien_details b " +
								  " where a.bank_account_no=b.account_no and b.ebroking_id= a.ebroking_id and b.corp_id = a.corporate_id " +
								  " and ( b.maker =? or b.AUTH1_NAME=? or b.auth2_name =? ) and b.merchant_code='NOW'";

	private String GET_EBROKINGID_LIEN_AMOUNT="select amount from sbi_dmat_permanent_lien where ebroking_id=? and merchant_code='NOW' and status='00'";
	private String  GET_CORPORATE_ID="select corporate_id from sbi_dmat_reg_details where ebroking_id=? ";
   private String GET_RELEASE_STATUS_DETAILS="select amount,reference_no,status,trunc(creation_time)creation_date from sbi_dmat_unmark where ebroking_id=? and merchant_code = 'NOW' and trunc(creation_time) between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') order by creation_time desc";

	private String INSERT_LIEN_RELEASE_AMOUNT="Insert into sbi_dmat_unmark (USERNAME,EBROKING_ID,REFERENCE_NO,MERCHANT_CODE,AMOUNT,STATUS,CREATION_TIME,LAST_MOD_TIME) values (?,?,?,'NOW',?,'pending',sysdate,sysdate)";
	private String INSERT_CORP_LIEN_RELEASE_AMOUNT="Insert into sbi_dmat_unmark (USERNAME,EBROKING_ID,REFERENCE_NO,MERCHANT_CODE,AMOUNT,STATUS,CREATION_TIME,LAST_MOD_TIME,CORPORATE_ID) values (?,?,?,'NOW',?,'pending',sysdate,sysdate,?)";
	//private String INSERT_LIEN_RELEASE_AMOUNT="Insert into sbi_dmat_unmark (USERNAME,EBROKING_ID,REFERENCE_NO,MERCHANT_CODE,AMOUNT,STATUS,CREATION_TIME,LAST_MOD_TIME) values ('vel76','ESBI111111','LR12124','NOW',1000,'pending',sysdate,sysdate)";
	
	private String GET_LIEN_REFERENCE_NO="select reference_no,amount from sbi_dmat_unmark where ebroking_id=? and status='pending'";
	
	private String GET_EBROKINGID_RELEASE_STATUS="select count(1) from sbi_dmat_unmark where ebroking_id=? and status not in ('pending','success','failure','rejected')";
	
	public List getDpIds(String userName) throws DAOException {
		List dpList = new ArrayList();
		try {
			Object[] parameters = new Object[] { userName };
			/*getting dpId's from SBI_CUSTOMER_DEMAT_ID_MAP FOR A USERNAME*/
			dpList = getJdbcTemplate().queryForList(SQLConstants.GET_DPIDS,
					parameters);			
			if (dpList != null && dpList.size() >0){
				
				return dpList;
			}
			
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		return null;
	}
	
	public String getNRIAccountsAvailability(String userName) throws DAOException{
    	logger.debug("getNRIAccountsAvailability(String userName) method begin");
		String NRIString="";
		int count=0;
		try
		{
		Object[] params = {userName};
		String query="select count(*) as count from sbi_customer_account_map where user_name=? and product_desc like '#tobereplaced#'";
		String replacedString="%PIS%";
		String finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
		count = getJdbcTemplate().queryForInt(finalQuery,params);
		if(count>0){
			NRIString="NRI_PIS_accounts";
			return NRIString;
		}
		
		 replacedString="%NRE%";
		 finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
		count = getJdbcTemplate().queryForInt(finalQuery,params);
		if(count>0){
			NRIString="NRE_accounts";
			return NRIString;
		}
		 replacedString="%NRO%";
		 finalQuery=query.replaceAll(DAOConstants.TO_BE_REPLACED,replacedString);
		count = getJdbcTemplate().queryForInt(finalQuery,params);
		if(count>0){
			NRIString="NRO_accounts";
			return NRIString;
		}
		else NRIString="Domestic_accounts";
		
		
		}
		catch(DataAccessException ex){
				logger.error("Error while getting NRI count from sbi_customer_account_map table");
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			} 
		logger.debug("getNRIAccountsAvailability(String userName) method end");
		return NRIString;
    }
	
	public int insertEZTradeNRIAccounts(Map NRIAccountDetails) throws DAOException{
		int result = 0;
		
		try{
			String address=(String)NRIAccountDetails.get("address");
			logger.info("userName:"+(String)NRIAccountDetails.get("userName"));
			logger.info("branch code:"+(String)NRIAccountDetails.get("branchCode"));
			logger.info("Account number:"+(String)NRIAccountDetails.get("accountNo"));
			logger.info("address :"+address);
			logger.info("contact no :"+(String)NRIAccountDetails.get("contactNo"));
			logger.info("email id :"+(String)NRIAccountDetails.get("emailId"));
			logger.info("mobile no :"+(String)NRIAccountDetails.get("mobileNo"));
									
			int[] types = {Types.VARCHAR,Types.VARCHAR,
					Types.VARCHAR,Types.VARCHAR,
					Types.VARCHAR,Types.VARCHAR,
					Types.VARCHAR,Types.NUMERIC};
			
			Object[] params = {(String)NRIAccountDetails.get("userName"),(String)NRIAccountDetails.get("name"),
					(String)NRIAccountDetails.get("accountNo"),(String)NRIAccountDetails.get("branchCode"),
					address.trim(),(String)NRIAccountDetails.get("contactNo"),
					(String)NRIAccountDetails.get("emailId"),Double.valueOf((String)NRIAccountDetails.get("mobileNo"))};
			
			 result = getJdbcTemplate().update(INSERT_SBI_EZTRADE_NRI_REG_DETAILS,params,types);
			
		
			logger.info("Inserted in to SBI_EZTRADE_NRI_REG_DETAILS -count :" + result);
		
		}
		catch (DataIntegrityViolationException exp) {
			logger.error("Unique Constriant Exception - " ,exp);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		} 
		catch (DAOException exp) {
			logger.error("DAO Exception - " ,exp);
			DAOException.throwException(exp.errorCode);
		}
		return result;
	}
	//added for NOW CR
	public List getEbrokingDetails(String userName) throws DAOException {
		logger.debug("getEbrokingDetails(String userName) method begin");
		List ebrokingList = new ArrayList();
		try {
			Object[] parameters = new Object[] { userName };
			ebrokingList = getJdbcTemplate().queryForList(GET_EBROKINGID,
					parameters);			
			if (ebrokingList != null && ebrokingList.size()>0){
				
				return ebrokingList;
			}
	
			
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.debug("getEbrokingDetails(String userName) method end");
		return null;
	}
	public int getAcccountCount(String userName) {
		int accCount=0;
		if (userName != null ) {
			try {
				logger.info("corpId : "+userName);
				Object params1[] = new Object[] { userName,userName,userName};
				//String sql = "select count(account_no) from sbicorp_dmat_lien_details where maker=? and merchant_code='NOW'";
				String sql = "select count(account_no) from sbicorp_dmat_lien_details where (maker=? or auth1_name=? or auth2_name=?) and merchant_code='NOW' and lien_status='00'";
				accCount = getJdbcTemplate().queryForInt(sql, params1);
				logger.info("accCount : "+accCount);
			}
			catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException("BU011");// select fails

			}

		} else {
			DAOException.throwException("BU001");// Input values are null
		}
        logger.info("The size of accCount: "+accCount);
	
		return accCount;
	}
	public List getEbrokingDetailsForCorp(String userName) throws DAOException {
		logger.debug("getEbrokingDetails(String userName) method begin");
		List ebrokingList = new ArrayList();
		try {
			Object[] parameters = new Object[] { userName,userName,userName};
			ebrokingList = getJdbcTemplate().queryForList(GET_EBROKING_ID_CORP,
					parameters);			
			if (ebrokingList != null && ebrokingList.size()>0){
				
				return ebrokingList;
			}
	
			
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.debug("getEbrokingDetails(String userName) method end");
		return null;
	}
	public int getEbrokingStatus(String eBrokingId) throws DAOException{
		int lienStatusCount=0;
		try {
			Object[] parameters = new Object[] {eBrokingId };
			logger.info("ebrokingId"+eBrokingId);
			lienStatusCount = getJdbcTemplate().queryForInt(GET_EBROKINGID_RELEASE_STATUS,parameters);			
			
		
		} 
		catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		catch (Exception ex) {
			ex.printStackTrace();
			
		}
		return lienStatusCount;
	}
	
	public Double getEbrokingLienAmount(String eBrokingId) throws DAOException {
		logger.info("getEbrokingLienAmount(String eBrokingId) method begin");
		//List lienAmountDetails = new ArrayList();
		
		Double lienAmount=0.0;
		try {
			Object[] parameters = new Object[] {eBrokingId };
			logger.info("ebrokingId"+eBrokingId);
			lienAmount = (Double)getJdbcTemplate().queryForObject(GET_EBROKINGID_LIEN_AMOUNT,parameters,java.lang.Double.class);
			logger.info("lienAmount"+lienAmount);
			if (lienAmount!=0.0){
				logger.info("inside lienAmountDetails loop"+lienAmount);
				return lienAmount;
			}
		
		} 
		catch(IncorrectResultSizeDataAccessException e){
			logger.error("unable to retrive the user details. Error occured : " + e.getMessage());
			lienAmount=0.0;
		}catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.info("getEbrokingLienAmount(String eBrokingId) method ends");
		return lienAmount;
	}
	public String getCorpId(String eBrokingId) throws DAOException {
		logger.info("getCorpId(String eBrokingId) method begin");
		//List lienAmountDetails = new ArrayList();
		 String ebrokeId=null;
		try {
			Object[] parameters = new Object[] {eBrokingId};
			int[] sqltype={Types.VARCHAR};
			logger.info("ebrokingId========="+eBrokingId);
			ebrokeId = (String)getJdbcTemplate().queryForObject(GET_CORPORATE_ID,parameters,String.class);
			logger.info("ebrokeId details"+ebrokeId);
			if (ebrokeId!=null){
				logger.info("inside lienAmountDetails loop"+ebrokeId);
				return ebrokeId;
			}
		
		} 
		catch(IncorrectResultSizeDataAccessException e){
			logger.error("unable to retrive the user details. Error occured : " + e.getMessage());
			ebrokeId=null;
		}catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.info("getCorpId(String eBrokingId) method ends");
		return ebrokeId;
	}
	
	public Map getLienReferenceNo(String eBrokingId) throws DAOException {
		logger.info("getLienReferenceNo(String eBrokingId) method begin");
		//List lienAmountDetails = new ArrayList();
		Map outParams=new HashMap();
		int lienAmount=0;
		try {
			Object[] parameters = new Object[] {eBrokingId };
			logger.info("ebrokingId"+eBrokingId);
			outParams = getJdbcTemplate().queryForMap(GET_LIEN_REFERENCE_NO,parameters);			
			if (outParams!=null){
				logger.info("inside lienAmountDetails loop"+outParams);
				return outParams;
			}

			
		} 
		catch(IncorrectResultSizeDataAccessException e){
			logger.error("unable to retrive the user details. Error occured : " + e.getMessage());
		
		}catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.info("getLienReferenceNo(String eBrokingId) method ends");
		return outParams;
	}
	public String insertLienReleaseAmount(String userName,String eBrokingId,double releaseAmt,String referenceNo,double amount) throws DAOException {
		logger.info("insertLienReleaseAmount(String eBrokingId) method begin");
		//List lienAmountDetails = new ArrayList();
		int count=0;
		
		try {
			
			
			logger.info("releaseAmt"+releaseAmt);
			logger.info("userName"+userName);
			logger.info("eBrokingId"+eBrokingId);
			logger.info("referenceNo"+referenceNo);
			logger.info("amount"+amount);
		
			if(userName !=null && eBrokingId!=null && referenceNo!=null && releaseAmt>=0.0 && amount>=0.0){
				
				releaseAmt=releaseAmt+amount;
				logger.info("added amount before updating"+releaseAmt);
				Object[] params=new Object[] {releaseAmt,userName,eBrokingId,referenceNo};
				count=getJdbcTemplate().update("update sbi_dmat_unmark set amount=?,status='pending',last_mod_time=sysdate where username=? and ebroking_id=? and status='pending' and reference_no=?",params);
				logger.info("after update query"+count);
			}
			
	
			if(count<1){
				logger.info("before insert query"+count);
				String REFERENCE_NO="select FN_GET_DMAT_REFNO('NR') from dual";
				referenceNo = (String) getJdbcTemplate().queryForObject(REFERENCE_NO,String.class);
				Object[] parameters = new Object[] {userName,eBrokingId,referenceNo,releaseAmt};
				logger.info(userName + "releaseAmt" +releaseAmt);
				int[] types = {Types.VARCHAR,Types.VARCHAR,
						Types.VARCHAR,Types.INTEGER};
				logger.info(count +  "Rows inserted into sbi_dmat_unmark");
				count = getJdbcTemplate().update(INSERT_LIEN_RELEASE_AMOUNT,parameters,types);
			}
				
			logger.info("after insert query count"+count);
			if (count != 0 ){
				logger.info("inside lienAmountDetails loop"+count);
				return referenceNo;
			}
			
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.info("insertLienReleaseAmount(String eBrokingId) method ends");
		return referenceNo;
	}
	public String insertCorpLienReleaseAmount(String userName,String eBrokingId,double releaseAmt,String referenceNo,double amount,String corpId) throws DAOException {
		logger.info("insertCorpLienReleaseAmount(String eBrokingId) method begin");
		//List lienAmountDetails = new ArrayList();
		int count=0;
		
		try {
			
			
			logger.info("releaseAmt"+releaseAmt);
			logger.info("userName"+userName);
			logger.info("eBrokingId"+eBrokingId);
			logger.info("referenceNo in demat"+referenceNo);
			logger.info("amount"+amount);
			logger.info("corpId"+corpId);
		
			if(userName !=null && eBrokingId!=null && referenceNo!=null && releaseAmt>=0.0 && amount>=0.0){
				
				releaseAmt=releaseAmt+amount;
				logger.info("added amount before updating"+releaseAmt);
				Object[] params=new Object[] {releaseAmt,eBrokingId,referenceNo};
				count=getJdbcTemplate().update("update sbi_dmat_unmark set amount=?,status='pending',last_mod_time=sysdate where  ebroking_id=? and status='pending' and reference_no=?",params);
				logger.info("after now for corp unmark update query"+count);
			}
			
	
			if(count<1){
				logger.info("before insert query in corporate now"+count);
				String REFERENCE_NO="select FN_GET_DMAT_REFNO('NR') from dual";
				referenceNo = (String) getJdbcTemplate().queryForObject(REFERENCE_NO,String.class);
				Object[] parameters = new Object[] {userName,eBrokingId,referenceNo,releaseAmt,corpId};
				logger.info(userName + "releaseAmt" +releaseAmt);
				int[] types = {Types.VARCHAR,Types.VARCHAR,
						Types.VARCHAR,Types.DOUBLE,Types.VARCHAR};
				logger.info(count +  "Rows inserted into sbi_dmat_unmark");
				count = getJdbcTemplate().update(INSERT_CORP_LIEN_RELEASE_AMOUNT,parameters,types);
			}
				
			logger.info("after insert query count"+count);
			if (count != 0 ){
				logger.info("inside lienAmountDetails loop"+count);
				return referenceNo;
			}
			
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		}
		logger.info("insertCorpLienReleaseAmount(String eBrokingId) method ends");
		return referenceNo;
	}
	
	public List getStatusDetails(String eBrokingId,String startDate,String endDate) throws DAOException {
		logger.debug("getStatusDetails(String eBrokingId) method begin");
		List lienStatusDetails = new ArrayList();
		try {
			if (eBrokingId!=null && startDate!=null && endDate!=null ){
			Object[] parameters = new Object[] {eBrokingId,startDate,endDate };
			logger.info("ebrokingId"+eBrokingId+"startDate"+startDate+"endDate"+endDate);
			lienStatusDetails =  getJdbcTemplate().query(GET_RELEASE_STATUS_DETAILS, parameters,new NowReleaseRowMapper());			
			logger.info("lienStatusDetails"+lienStatusDetails);
			if (lienStatusDetails != null && lienStatusDetails.size() >0){
				return lienStatusDetails;
			}
			}
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,
					dataAccessException);
		logger.debug("getStatusDetails(String eBrokingId) method ends");
		
	}	
		return null;
		}

	class NowReleaseRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int index) throws SQLException {
			DematLienEnquiry nowRelease = new DematLienEnquiry();
			if(rs.getString("reference_no") != null && rs.getString("reference_no").length() >0){
				nowRelease.setLienRefNo(rs.getString("reference_no"));
			}else{
				nowRelease.setLienRefNo("--");
			}
				
			if(rs.getString("amount") != null){
				nowRelease.setAmount(new Double(rs.getDouble("amount")));
			}else{
				nowRelease.setAmount(new Double("0.0"));
			}
					
			if(rs.getString("status")!=null && rs.getString("status").length()>0 ){
				
				nowRelease.setLienMarkStatus(rs.getString("status"));
			}
             if(rs.getString("creation_date") != null)
 				nowRelease.setCreationTime(rs.getTimestamp("creation_date"));
       
			
			return nowRelease;
		}
	//ends
 }
	//Added for CR DEV-338;
	public List getSSLeBrokingIds(String userName) throws DAOException {
		List eBrokingIDlist = new ArrayList();
		String GET_EBROKING_IDS = "select ebroking_id from sbi_dmat_reg_details where user_name = ? and dmat_account_no is null and merchant_code in ('SSL','SSL_NRI','SSL_SBH','SSL_SBBJ','SSL_SBP')";//Added for Dev 490 SSL Demat for SBH& other AB's
		try {
			Object[] parameters = new Object[] { userName };
			eBrokingIDlist = (List) getJdbcTemplate().query(GET_EBROKING_IDS,
					parameters,new EbrokingIDRowMapper());			
			if (eBrokingIDlist != null && eBrokingIDlist.size() >0){
				
				return eBrokingIDlist;
			}
			
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ServiceErrorConstants.SE002,dataAccessException);
		}
		return null;
	}
	class EbrokingIDRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int count) throws SQLException {
			String eBrokingId= rs.getString("EBROKING_ID");
			return eBrokingId;
		}
		
	}	
	//End;
	
}