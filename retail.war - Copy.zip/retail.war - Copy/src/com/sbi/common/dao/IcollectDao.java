package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;

public interface IcollectDao {
	public List findIcollectCategories(String corporateId) throws DAOException;
	//List getReportDetails(String categoryId,String startDate, String endDate)throws DAOException;
	int insertReportDetails(String requestID,String categoryId,String startDate, String endDate , String userName,String fileType,String paymentmode,String corporateId,String accountNO,String reportType)throws DAOException;  // -- All Category Report START	
	public List getReportRequest(String userName) throws DAOException;
	
	public List fetchAccountDetails(String corpid,String username)throws DAOException;
}
