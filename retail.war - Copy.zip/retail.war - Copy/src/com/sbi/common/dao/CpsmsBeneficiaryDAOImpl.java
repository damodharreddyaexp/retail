/*
 * ThirdPartyDAOImpl.java
 * Created on JAN '08 by Treesa
 *This class is common to Regulator,Admin and Approver
 * Copyright (c) 2008 by SBI All Rights Reserved.
 * 
 */
//History
//JAN '08  - Initial Creation
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.model.CpsmsBeneficiary;
import com.sbi.common.utils.LoggingConstants;



public class CpsmsBeneficiaryDAOImpl extends JdbcDaoSupport implements CpsmsBeneficiaryDAO
{

    protected final Logger logger = Logger.getLogger(getClass());

    
    
    public CorporateFile[] findTPFiles(String corporateId, String startDate,String endDate,String viewType, String bankCode,String adminAccNo)
    {

        logger.info("findTPFiles( String corporateId,String startDate,String endDate)"+ LoggingConstants.METHODBEGIN);
        logger.info("corporateId  :" + corporateId +"startDate :"+startDate+"endDate :"+endDate +"bankCode" +bankCode+ "adminAccNo :"+adminAccNo);
        
        List result = new ArrayList();
        CorporateFile[] corporateFileArray = null;
        
        String query_approve="select sno,file_name, a.creation_time, decode(file_processed_status,'Processed','Pending for approval')"+ 
        			" file_processed_status from sbi_xml_file_master a where a.corporate_id=? and a.file_processed_status='Processed'"+
        			" and exists(select 1 from sbi_beneficiary_file_master b where b.original_file_name =a.file_name and a.corporate_id= b.corporate_id and b.file_name=a.sno "+
        			" and ( b.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or b.approved_status is null) and file_status =2"+
        			" and trunc(a.creation_time) between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') and admin_acc_no=? )  and bank_code=? " +
        			"order by a.creation_time desc ";
        
        String query_view="select sno,file_name, a.creation_time,  'Approved' file_processed_status"+ 
				" from sbi_xml_file_master a where a.corporate_id=? and a.file_processed_status='Processed'"+
				" and exists(select 1 from sbi_beneficiary_file_master b where b.original_file_name =a.file_name and a.corporate_id= b.corporate_id and b.file_name=a.sno "+
				" and file_status =2 and b.approved_status  in ('ADDED','REJECTED','DELETED','ERROR')"+
				" and trunc(a.creation_time) between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') and admin_acc_no=? ) and bank_code=? " +
				"order by a.creation_time desc ";

        
        if (corporateId != null && corporateId.trim().length() > 0)
        {
        	logger.info("corporateId ---> :" + corporateId +"---- viewType--> :"+viewType);
            try
            {
                    Object[] parameters = new Object[] { corporateId,startDate,endDate,adminAccNo,bankCode};
                    if("approve".equals(viewType))
                    	result = getJdbcTemplate().query(query_approve,parameters,new CorporateInterBankAppFileRowMapper());
                    else if("view".equals(viewType))
                    	result = getJdbcTemplate().query(query_view,parameters,new CorporateInterBankAppFileRowMapper());
                    
                if (result != null && result.size() > 0)
                {

                    logger.info("Result size in side if loop:" + result.size());
                    corporateFileArray = new CorporateFile[result.size()];

                    for (int i = 0; i < result.size(); i++)
                    {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }

                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.debug("String userName,Integer userRole,String bankType,String startDate,String endDate,String functionType"+ LoggingConstants.METHODEND);
        return corporateFileArray;

    }
    
    @SuppressWarnings("unchecked")
	public Map findBenFiledetails(String corporateId,String fileName,String viewType, String adminAccNo){
    	Map fileDetails=new HashMap();
    	   
         fileDetails.put("intra_add", 0);
         fileDetails.put("intra_del", 0);
         fileDetails.put("inter_add", 0);
         fileDetails.put("inter_del", 0);
         fileDetails.put("validation_fail", 0);
         fileDetails.put("benrecordCount",0);
    	logger.info("findBenFiledetails( String corporateId,String fileName)"+ LoggingConstants.METHODBEGIN);
        logger.info("corporateId  :" + corporateId +"fileName :"+fileName+"viewType :"+viewType+"adminAccNo :"+adminAccNo);
        
        String query_approve= "(select request_type, beneficiary_type, file_status, count(1)+0 record_count from sbi_beneficiary_file_master a "+
				        " where beneficiary_type ='Intra' and request_type in ('ADD') and file_status = '2' and file_name =? and "+
				        " corporate_id=? and admin_acc_no=? and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and exists(select 1 from   sbicorp_third_party b where a.file_name=b.file_name and "+
				        " a.corporate_id=b.corporate_id and a.account_no =b.account_no and b.product_code_status='processed' and status =0) group by request_type, beneficiary_type,"+
				         " file_status )UNION ALL  (select request_type, beneficiary_type, file_status, count(1)+0  record_count from sbi_beneficiary_file_master a "+
				         " where beneficiary_type ='Intra' and request_type in ('DELETE') and file_status = '2' and file_name =? and corporate_id=? and admin_acc_no=? "+
				         " and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and exists(select 1 from   sbi_delete_third_party b where a.file_name=b.file_name and a.corporate_id=b.corp_id and "+
				         " a.account_no =b.benificiary_account and status ='UnApproved') group by request_type, beneficiary_type, file_status )UNION ALL "+
				         " (selecT request_type, beneficiary_type, file_status, count(1)+0  record_count from sbi_beneficiary_file_master a where beneficiary_type ='Inter' "+
				         " and request_type in ('ADD') and file_status = '2' and file_name =? and corporate_id=? and admin_acc_no=? and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and exists (select 1 from   sbi_rtgs_beneficiary c "+
				         " where a.file_name=c.file_sno and a.corporate_id=c.corporate_id and a.account_no =c.account_number and status ='pending_approval') "+
				         " group by request_type, beneficiary_type, file_status ) UNION ALL  (selecT request_type, beneficiary_type, file_status, count(1)+0  "+
				         " record_count from sbi_beneficiary_file_master a where beneficiary_type ='Inter' and request_type in ('DELETE') and file_status = '2'"+
				         " and file_name =? and corporate_id=? and admin_acc_no=? and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and exists (select 1 from   sbi_rtgs_beneficiary c where a.file_name=c.deletion_file_no and "+
				         " a.corporate_id=c.corporate_id and a.account_no =c.account_number and status ='active') group by request_type, beneficiary_type, "+
				         " file_status) UNION ALL (select ' 'request_type, ' ' beneficiary_type, '5' file_status, count(1)+0 record_count from sbi_beneficiary_file_master "+
				         " where file_status = '5' and file_name =? and corporate_id=? and admin_acc_no=? ) ";
				        
        
       /* String query_approve= "(selecT request_type, beneficiary_type, file_status, count(1)+0  record_count from sbi_beneficiary_file_master a where beneficiary_type ='Inter' "+
				         " and request_type in ('ADD') and file_status = '2' and file_name =? and corporate_id=? and admin_acc_no=? and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and exists (select 1 from   sbi_rtgs_beneficiary c "+
				         " where a.file_name=c.file_sno and a.corporate_id=c.corporate_id and a.account_no =c.account_number and status ='pending_approval') "+
				         " group by request_type, beneficiary_type, file_status )";*/
        
        
        
        String query_view= " selecT request_type,beneficiary_type, '2' file_status, count(1) record_count from sbi_beneficiary_file_master "+
					        " where beneficiary_type in ('Intra','Inter') and request_type in ('ADD','DELETE') and file_status = '2' "+
					        " and file_name = ? and corporate_id =? and admin_acc_no=? group by request_type, beneficiary_type, file_status "+
					        " union all selecT ' 'request_type, ' ' beneficiary_type, '5' file_status, count(1)  record_count "+
					        " from sbi_beneficiary_file_master where file_status = '5' and file_name = ? and corporate_id =? and admin_acc_no=? ";

			        
        
        if (corporateId != null && corporateId.trim().length() > 0)
        {

            try
            {		
            		SqlRowSet result=null;
            		 //List result = new ArrayList();
                   
                   
                   if("approve".equals(viewType)){
                       Object[] parameters = new Object[] {fileName, corporateId,adminAccNo,fileName,corporateId,adminAccNo,fileName,corporateId,adminAccNo,fileName,corporateId,adminAccNo,fileName,corporateId,adminAccNo};
                	//Object[] parameters = new Object[] {fileName,corporateId,adminAccNo};
                	   result = (SqlRowSet)getJdbcTemplate().queryForRowSet(query_approve,parameters);
                	   //result = getJdbcTemplate().queryForList(query_approve,parameters);
                   }

                   else if("view".equals(viewType))
                	   result = (SqlRowSet)getJdbcTemplate().queryForRowSet(query_view,new Object[] {fileName, corporateId,adminAccNo,fileName,corporateId,adminAccNo});
                   //result = getJdbcTemplate().queryForList(query_view,new Object[] {fileName, corporateId,adminAccNo,fileName,corporateId,adminAccNo});
                   
                if (result != null)
                {
                   while(result.next()){
                	  if(("5").equalsIgnoreCase(result.getString("FILE_STATUS"))){
                		  fileDetails.put("validation_fail", result.getInt("RECORD_COUNT"));
                		  
                	  }else if(result.getString("REQUEST_TYPE")!=null && result.getString("BENEFICIARY_TYPE")!=null){
                		  if("ADD".equalsIgnoreCase(result.getString("REQUEST_TYPE"))){
                			  
                			  if("Intra".equalsIgnoreCase(result.getString("BENEFICIARY_TYPE")))
                				  fileDetails.put("intra_add", result.getInt("RECORD_COUNT"));
                			  else
                				  fileDetails.put("inter_add", result.getInt("RECORD_COUNT"));
                		  }
                		  if("DELETE".equalsIgnoreCase(result.getString("REQUEST_TYPE"))){
                			  
                			  if("Intra".equalsIgnoreCase(result.getString("BENEFICIARY_TYPE")))
                				  fileDetails.put("intra_del", result.getInt("RECORD_COUNT"));
                			  else
                				  fileDetails.put("inter_del", result.getInt("RECORD_COUNT"));
                		  }
                		 // added by Damodar..for cpsms beneficiary approval
                		  if(("ADD".equalsIgnoreCase(result.getString("REQUEST_TYPE"))) ||("DELETE".equalsIgnoreCase(result.getString("REQUEST_TYPE"))))
                		  {
                			  fileDetails.put("benrecordCount", result.getInt("RECORD_COUNT"));
                			  logger.info("Record Count"+ result.getInt("RECORD_COUNT"));
                		  }
                		 
                	  } 

                  }
                	  

                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
     
    	return fileDetails;
    }
    
    public CpsmsBeneficiary[] findTPsByFile(String corporateId, String fileName, String beneficiaryType,String requestType,String viewType, String adminAccNo)
    {
        logger.info("findTPsByFile( String corporateId, String fileName,String beneficiaryType,String requestType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        CpsmsBeneficiary[] corporateTPArray = null;
        
        String INTRA_ADD_BEN="select * from  sbi_beneficiary_file_master a , sbicorp_third_party b where a.file_name = b.file_name"+
        					" and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and a.account_no = b.account_no and b.branch_code= (select c.branch_code from sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code)"+
        					" and a.file_status='2' and b.status='0' and b.product_code_status='processed' and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? "+
        					" and a.request_type=? and a.admin_acc_no=? ";
        
        String INTRA_ADD_VIEW="select * from  sbi_beneficiary_file_master a , sbicorp_third_party b where a.file_name = b.file_name"+
        					" and a.corporate_id = b.corporate_id and a.account_no = b.account_no and b.branch_code= (select c.branch_code from sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code)"+
        					" and a.file_status='2' and b.product_code_status='processed' and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? "+
        					" and a.request_type=? and a.admin_acc_no=? ";
        
        String INTRA_DEL_BEN="select * from  sbi_beneficiary_file_master a , sbi_delete_third_party b where a.file_name =b.file_name and"+
					        " a.corporate_id = b.corp_id and a.account_no=b.benificiary_account and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and b.benificiary_branch= (select c.branch_code"+
					        " from sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code) and a.file_status='2' and b.status in ('UnApproved')"+
					        " and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";
		
        String INTRA_DEL_VIEW="select * from  sbi_beneficiary_file_master a , sbi_delete_third_party b where a.file_name =b.file_name and"+
        					" a.corporate_id = b.corp_id and a.account_no=b.benificiary_account and b.benificiary_branch= (select c.branch_code"+
        					" from sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code) and a.file_status='2'"+
        					" and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";
        
        String INTER_ADD_BEN="select * from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.file_sno"+
        					" and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and a.account_no=b.account_number and"+
        					"  b.ifsc_code_receiver= (select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1)"+
        					" and a.file_status='2' and b.status='pending_approval' and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";
        
        String INTER_ADD_VIEW="select * from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.file_sno"+
							" and a.corporate_id = b.corporate_id  and a.account_no=b.account_number and"+
							"  b.ifsc_code_receiver= (select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1)"+
							" and a.file_status='2' and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";
        
        String INTER_DEL_BEN="select * from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.deletion_file_no and"+
					        " a.file_status='2' and a.corporate_id = b.corporate_id and a.account_no=b.account_number and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and  b.ifsc_code_receiver"+
					        " =(select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1) and b.status "+
					        " in('active') and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";
		
        String INTER_DEL_VIEW="select * from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.deletion_file_no and"+
        					" a.file_status='2' and a.corporate_id = b.corporate_id and a.account_no=b.account_number and  b.ifsc_code_receiver"+
        					" =(select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1) "+
        					" and a.corporate_id=? and a.file_name=? and a.beneficiary_type=? and a.request_type=? and a.admin_acc_no=? ";

        logger.info("fileName :" + fileName + " corporateId:" + corporateId + " beneficiaryType " + beneficiaryType + "requestType "+ requestType+ "adminAccNo "+adminAccNo);
     
        if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " corporateId:" + corporateId + " beneficiaryType " + beneficiaryType + "requestType "
                + requestType+ "adminAccNo "+adminAccNo);
         }
        if (fileName != null && corporateId != null)
        {

            try
            {
            	Object[] params=new Object[] { corporateId, fileName, beneficiaryType, requestType, adminAccNo};
            	
                if (beneficiaryType.equals("Intra"))
                {
                	if("ADD".equals(requestType))
                	{
                		 if("approve".equals(viewType))	
                			 result = getJdbcTemplate().query(INTRA_ADD_BEN, params, new CpsmsBeneficiaryRowMapper());
                		 else if("view".equals(viewType))
                			 result = getJdbcTemplate().query(INTRA_ADD_VIEW, params, new CpsmsBeneficiaryRowMapper());
                	}
                	if("DELETE".equals(requestType))
                	{
                		 if("approve".equals(viewType))
                			 result = getJdbcTemplate().query(INTRA_DEL_BEN, params, new CpsmsBeneficiaryDelRowMapper());
                		 else if("view".equals(viewType))
                			 result = getJdbcTemplate().query(INTRA_DEL_VIEW, params, new CpsmsBeneficiaryDelRowMapper());
                	}	
                }
                else if(beneficiaryType.equals("Inter"))
                {
                	if("ADD".equals(requestType))
                	{
                		if("approve".equals(viewType))	
                			result = getJdbcTemplate().query(INTER_ADD_BEN, params, new CpsmsBeneficiaryInterRowMapper());
                		else if("view".equals(viewType))
                			result = getJdbcTemplate().query(INTER_ADD_VIEW, params, new CpsmsBeneficiaryInterRowMapper());
                	}
                	if("DELETE".equals(requestType))
                	{
                		if("approve".equals(viewType))
                			result = getJdbcTemplate().query(INTER_DEL_BEN, params, new CpsmsBeneficiaryInterRowMapper());
                		else if("view".equals(viewType))
                			result = getJdbcTemplate().query(INTER_DEL_VIEW, params, new CpsmsBeneficiaryInterRowMapper());
                	}
                }
                else if(beneficiaryType.equals("validationFail")){
                	
                	params=new Object[] { corporateId, fileName, adminAccNo};
                	String query_validation_fail="select BENEFICIARY_NAME,ACCOUNT_NO,ENTITY_CODE,IFSC_CODE,REMARKS,AADHAR_ID,BANK_IIN from sbi_beneficiary_file_master where FILE_STATUS=5 AND CORPORATE_ID=? AND FILE_NAME=? AND ADMIN_ACC_NO=?";
                	result = getJdbcTemplate().query(query_validation_fail, params, new BeneficiaryValidationFailRowMapper());
                }
                	

                corporateTPArray = new CpsmsBeneficiary[result.size()];
                logger.info("corporateTPArray "+corporateTPArray);

                for (int i = 0; i < result.size(); i++)
                {
                    corporateTPArray[i] = (CpsmsBeneficiary) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.info("findTPsByFile( String corporateId, String fileName,String beneficiaryType,String requestType)"+ LoggingConstants.METHODEND);
        return corporateTPArray;
    }
    public boolean rejectTPState(String rejectedOIDs, String functionType, String userName, String beneficiaryType, String corporateID ,String selectAllcat,String fileName, String adminAccNo)
    {
        logger.info("rejectTPState(String rejectedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);
        
        String UPDATE_TP_STATE_REJECTED = "update sbicorp_third_party set  status ='2', user_name =?, LAST_MOD_TIME=SYSDATE where oid in(#tobereplaced#) and CORPORATE_ID = ?";
        
        String UPDATE_INTER_BANK_REJECTED="Update  sbi_rtgs_beneficiary set status= 'rejected', approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where  id in(#tobereplaced#) and CORPORATE_ID = ? ";
        
        String UPDATE_ALL_TP_STATE_REJECTED = "update sbicorp_third_party set  status ='2', user_name =?, LAST_MOD_TIME=SYSDATE where corporate_id =? and oid in( "+
        									  "	select b.oid from  bvsbi.sbi_beneficiary_file_master a , bvsbi.sbicorp_third_party b where a.file_name = b.file_name "+
        									  " and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') "+
        									   "	or a.approved_status is null) and a.account_no = b.account_no and b.branch_code= (select c.branch_code "+
        										" from bvsbi.sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code)"+
        										" and a.file_status='2' and b.status='0' and b.product_code_status='processed' and a.corporate_id=? "+
        										" and a.file_name=?and a.beneficiary_type='Intra' and a.request_type='ADD' and a.admin_acc_no=?) " ;

        		
        String UPDATE_ALL_INTER_BANK_REJECTED= "Update  sbi_rtgs_beneficiary set status= 'rejected', approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where CORPORATE_ID = ? and  id in( "+
        										" select b.id from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.file_sno "+
        										" and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR')  "+
        										" or a.approved_status is null) and a.account_no=b.account_number and "+ 
        										" b.ifsc_code_receiver= (select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1) "+ 
        										" and a.file_status='2' and b.status='pending_approval' and a.corporate_id=? and a.file_name=? "+
        										" and a.beneficiary_type='Inter' and a.request_type='ADD' and a.admin_acc_no=?) ";

        
        int rejectedCount = 0;
        
        if (selectAllcat != null )
        {
			 if(selectAllcat.equalsIgnoreCase("YES"))
    	   {

            try
            {
                
                Object[] rejectedBeneficiaryParams= new Object[] { userName, corporateID ,corporateID ,fileName,adminAccNo };
                if(beneficiaryType.equals("Intra")){
                	
                	rejectedCount=getJdbcTemplate().update(UPDATE_ALL_TP_STATE_REJECTED, rejectedBeneficiaryParams);
                }
                else{
                	
                	rejectedCount=getJdbcTemplate().update(UPDATE_ALL_TP_STATE_REJECTED, rejectedBeneficiaryParams);
                	 logger.info("rejectedCount REJECT"+rejectedCount);
                }
                
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
    	   }
        }  
        else
        if (rejectedOIDs != null && rejectedOIDs.trim().length() > 0)
        {

            try
            {
                Object[] rejectedBeneficiaryParams = new Object[] { userName, corporateID };
                if(beneficiaryType.equals("Intra")){
                	String finalQuery = UPDATE_TP_STATE_REJECTED.replaceAll("#tobereplaced#", rejectedOIDs);
                	rejectedCount=getJdbcTemplate().update(finalQuery, rejectedBeneficiaryParams);
                }
                else{
                	String finalQuery = UPDATE_INTER_BANK_REJECTED.replaceAll("#tobereplaced#", rejectedOIDs);
                	rejectedCount=getJdbcTemplate().update(finalQuery, rejectedBeneficiaryParams);
                	 logger.info("query for INTER REJECT"+finalQuery);
                }
                
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }     
        logger.info("rejectTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return true;
    }
    
    public boolean updateTPState(String approvedOIDs, String functionType, String userName, String beneficiaryType, String corporateID)
    {
        
    	logger.debug("updateTPState(String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);
        String UPDATE_TP_STATE_APPROVED = "update sbicorp_third_party set  status =1, user_name =?, LAST_MOD_TIME=SYSDATE where oid in(#tobereplaced#) and CORPORATE_ID = ?";
        
        String UPDATE_TP_DEL_APPROVED="Update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where row_id in(#tobereplaced#) and CORP_ID = ?";
        	
        String UPDATE_INTER_BANK_APPROVED="Update  sbi_rtgs_beneficiary set status= 'active' , approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where id in(#tobereplaced#) and CORPORATE_ID = ?"; 
        
        String UPDATE_INTER_DEL_APPROVED="Update  sbi_rtgs_beneficiary set status= 'inactive' , deletion_approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where id in(#tobereplaced#) and CORPORATE_ID = ? ";
        
        if (logger.isDebugEnabled())
        {
            logger.debug("approvedOIDs  :" + approvedOIDs + " functionType :" + functionType + "userName"+ userName + "bankType" + beneficiaryType + " corporateID :" + corporateID);
        }

        int approvedCount = 0;
        if (approvedOIDs != null && approvedOIDs.trim().length() > 0)
        {

            try
            {
                Object[] approvedParams= new Object[] { userName, corporateID };; 
                if (beneficiaryType.equals("Inter"))// modified  for DFC
                {
                	if(functionType.equals("ADD")){
                		
                		String finaldelapproveQuery = UPDATE_INTER_BANK_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                		approvedCount = getJdbcTemplate().update(finaldelapproveQuery, approvedParams);
                	}
                	if(functionType.equals("DELETE")){
                		
                		String finaldelapproveQuery = UPDATE_INTER_DEL_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                		approvedCount = getJdbcTemplate().update(finaldelapproveQuery, approvedParams);
                	}
                }
                else
                {
                	if(functionType.equals("ADD"))
                	{
                		String finalQuery = UPDATE_TP_STATE_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                		approvedCount = getJdbcTemplate().update(finalQuery, approvedParams);
                	}
                	else if(functionType.equals("DELETE"))
                	{
                		String finalQuery = UPDATE_TP_DEL_APPROVED.replaceAll("#tobereplaced#", approvedOIDs);
                		approvedCount = getJdbcTemplate().update(finalQuery, approvedParams);
                	}
                }
                if (logger.isDebugEnabled())
                {

                    logger.debug("updateTPState  :" + approvedCount);
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }

        logger.debug("updateTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return true;
    }
    
    
    //added by Damodar..FOR cpsms beneficiary approve..
    
    public boolean updateAllTPState(String approvedOIDs, String functionType, String userName, String beneficiaryType, String corporateID,String fileName, String adminAccNo)
    {
        
    	logger.info("updateAllTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODBEGIN);
    	logger.debug("updateAllTPState(String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID)"+ LoggingConstants.METHODBEGIN);
    	System.out.println(functionType);
    	System.out.println(userName);
    	System.out.println(corporateID);
    	System.out.println(adminAccNo);
    	System.out.println(fileName);
    	System.out.println(userName);
    	System.out.println(beneficiaryType);
    	
        
    	List result = new ArrayList();
    	Map returnMap=new HashMap();
    	
    	
    	

    	
    //	String UPDATE_ALL_TP_STATE_APPROVED = "update sbicorp_third_party set  status =1, user_name =?, LAST_MOD_TIME=SYSDATE where oid in(#tobereplaced#) and CORPORATE_ID = ?";
    	String UPDATE_ALL_TP_STATE_APPROVED = "update sbicorp_third_party set  status =1, user_name =?, LAST_MOD_TIME=SYSDATE where corporate_id =? and oid in( "+
    											" select b.oid from  bvsbi.sbi_beneficiary_file_master a , bvsbi.sbicorp_third_party b where a.file_name = b.file_name "+
    											" and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') "+
    											" or a.approved_status is null) and a.account_no = b.account_no and b.branch_code= (select c.branch_code "+
    											" from bvsbi.sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code or c.grpt_ifsc_code=a.ifsc_code) "+
    											" and a.file_status='2' and b.status='0' and b.product_code_status='processed' and a.corporate_id= ? "+
    											" and a.file_name= ? and a.beneficiary_type='Intra' and a.request_type='ADD' and a.admin_acc_no=?) ";

        
        //String UPDATE_ALL_TP_DEL_APPROVED="Update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where row_id in(#tobereplaced#) and CORP_ID = ?";
    	String UPDATE_ALL_TP_DEL_APPROVED="Update sbi_delete_third_party set status='Approved' ,APPROVED_BY=? where CORP_ID = ? and row_id in(  "+
    										" select b.row_id from  sbi_beneficiary_file_master a , sbi_delete_third_party b where a.file_name =b.file_name and "+
    										" a.corporate_id = b.corp_id and a.account_no=b.benificiary_account and ( a.approved_status "+
    										" not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) "+
    										" and b.benificiary_branch= (select c.branch_code "+
    										" from sbi_branch_master  c where c.rtgs_ifsc_code= a.ifsc_code or c.neft_ifsc_code=a.ifsc_code "+ 
    										" or c.grpt_ifsc_code=a.ifsc_code) and a.file_status='2' and b.status in ('UnApproved')"+
    										" and a.corporate_id=? and a.file_name=? and a.beneficiary_type='Intra' and a.request_type='DELETE' and a.admin_acc_no=?) ";

        	
        //String UPDATE_ALL_INTER_BANK_APPROVED="Update  sbi_rtgs_beneficiary set status= 'active' , approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where id in(#tobereplaced#) and CORPORATE_ID = ?";        
        String UPDATE_ALL_INTER_BANK_APPROVED=  "Update  sbi_rtgs_beneficiary set status= 'active' , approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where  CORPORATE_ID = ? and id in(select b.id from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.file_sno	and a.corporate_id = b.corporate_id and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') "+ 
        		 								" or a.approved_status is null) and a.account_no=b.account_number and "+
        		 								" b.ifsc_code_receiver = (select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1) "+
        		 								" and a.file_status='2' and b.status='pending_approval' and a.corporate_id=? and a.file_name=? and a.beneficiary_type='Inter' "+ 
        		 								"  and a.request_type='ADD' and a.admin_acc_no=?) ";

        
        
        //String UPDATE_ALL_INTER_DEL_APPROVED="Update  sbi_rtgs_beneficiary set status= 'inactive' , deletion_approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where id in(#tobereplaced#) and CORPORATE_ID = ? ";
        String UPDATE_ALL_INTER_DEL_APPROVED="Update  sbi_rtgs_beneficiary set status= 'inactive' , deletion_approved_by=?, LAST_MODIFIED_TIME=SYSDATE Where CORPORATE_ID = ? and id in( "+
        									  "	select b.id from  sbi_beneficiary_file_master a , sbi_rtgs_beneficiary  b where a.file_name =b.deletion_file_no and "+
        									  " a.file_status='2' and a.corporate_id = b.corporate_id and a.account_no=b.account_number "+
        									  " and ( a.approved_status not in ('ADDED','REJECTED','DELETED','ERROR') or a.approved_status is null) and  b.ifsc_code_receiver = "+
        										" (select c.ifsc_code  from sbi_rtgs_branch_master  c where c.ifsc_code= a.ifsc_code and rownum=1) and b.status "+
        										"in('active') and a.corporate_id=? and a.file_name=? and a.beneficiary_type='Inter' and a.request_type='DELETE' and a.admin_acc_no=? ) ";

        
        if (logger.isDebugEnabled())
        {
            logger.debug("approvedOIDs  :" + approvedOIDs + " functionType :" + functionType + "userName"+ userName + "bankType" + beneficiaryType + " corporateID :" + corporateID);
        }

        String 	approvedallOIDs ="";
        int approvedCount = 0;
        if (approvedOIDs != null && approvedOIDs.trim().length() > 0)
        {

            try
            {
                Object[] approvedParams= new Object[] { userName, corporateID ,corporateID ,fileName,adminAccNo };
               
                if (beneficiaryType.equals("Inter"))// modified  for DFC
                {
                	if(functionType.equals("ADD")){
                		logger.info("inside updateAllTPState" + approvedOIDs );                 		
                		
                		 approvedCount = getJdbcTemplate().update(UPDATE_ALL_INTER_BANK_APPROVED, approvedParams);
                		 logger.info("approvedCount" + approvedCount ); 
                		
                	}
                	if(functionType.equals("DELETE")){
                		
                		
                    		approvedCount = getJdbcTemplate().update(UPDATE_ALL_INTER_DEL_APPROVED, approvedParams);
                           
                        }
                		
                		
                	}
               
                else
                {
                	if(functionType.equals("ADD"))
                	{
                		
                		approvedCount = getJdbcTemplate().update(UPDATE_ALL_TP_STATE_APPROVED, approvedParams);
                		
                		
                	}
                	else if(functionType.equals("DELETE"))
                	{
                		
                		
                		approvedCount = getJdbcTemplate().update(UPDATE_ALL_TP_DEL_APPROVED, approvedParams);
                		
                	}
                }
                if (logger.isDebugEnabled())
                {

                    logger.debug("updateTPState  :" + approvedCount);
                }
            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }

        logger.debug("updateAllTPState( String approvedOIDs, String unapprovedOIDs, String userName,String bankType, String corporateID )"+ LoggingConstants.METHODEND);
        return true;
    }
    
    public CpsmsBeneficiary[] findTPdetails(String userName, String fileName, String apprIds, String beneficiaryType,String functionType)
    {
        logger.info("findTPdetails( String userName, String fileName,String apprIds,String bankType,String functionType )"+ LoggingConstants.METHODBEGIN);
        List result = new ArrayList();
        CpsmsBeneficiary[] corporateTPArray = null;
        Object[] params_appr;
        Object[] params;
        logger.info("fileName :" + fileName + " userName:" + userName + " bankType " + beneficiaryType + "functionType "+ functionType);
      if (logger.isDebugEnabled()) {
        logger.debug("fileName :" + fileName + " userName:" + userName + " bankType " + beneficiaryType + "functionType "
                + functionType);
         }
        if (fileName != null && userName != null)
        {

            try
            {
            	params = new Object[] { fileName, userName};
            	if(beneficiaryType.equals("Intra"))
            	{
                    if(functionType.equals("ADD")){
                    	
                   
                    String query="select * from sbi_beneficiary_file_master a , sbicorp_third_party b where a.file_name =b.file_name and a.corporate_id = b.corporate_id "+
                    				" and a.account_no=b.account_no and a.file_status='2' and b.file_name=? and b.user_name=? and oid in(#tobereplaced#) ";
                    query=query.replaceAll("#tobereplaced#", apprIds);
                    result = getJdbcTemplate().query(query, params, new CpsmsBeneficiaryRowMapper());
                    }
                    else{
                    	String query="select * from sbi_beneficiary_file_master a , sbi_delete_third_party b where a.file_name =b.file_name and a.corporate_id = b.corp_id "+
        				" and a.account_no=b.benificiary_account and a.file_status='2' and b.file_name=? and b.approved_by=? and row_id in(#tobereplaced#) ";
                    	query=query.replaceAll("#tobereplaced#", apprIds);
                    	result = getJdbcTemplate().query(query, params, new CpsmsBeneficiaryDelRowMapper());
                    	
                    }
                    
            	}
            	else{
            		
            		if(functionType.equals("ADD"))
            		{
            		 String query="select * from sbi_beneficiary_file_master a , sbi_rtgs_beneficiary b where a.file_name =b.file_sno and a.corporate_id = b.corporate_id "+
     						" and a.account_no=b.account_number and a.file_status='2' and b.file_sno=? and b.approved_by=? and id in(#tobereplaced#) ";
            		 	query=query.replaceAll("#tobereplaced#", apprIds);
            		 	result = getJdbcTemplate().query(query, params, new CpsmsBeneficiaryInterRowMapper());
            		}
            		else{
            			String query="select * from sbi_beneficiary_file_master a , sbi_rtgs_beneficiary b where a.file_name =b.deletion_file_no and a.corporate_id = b.corporate_id "+
 								" and a.account_no=b.account_number and a.file_status='2' and b.deletion_file_no=? and b.deletion_approved_by=? and id in(#tobereplaced#) ";
            			query=query.replaceAll("#tobereplaced#", apprIds);
            			result = getJdbcTemplate().query(query, params, new CpsmsBeneficiaryInterRowMapper());
            		}
            	}
                corporateTPArray = new CpsmsBeneficiary[result.size()];

                for (int i = 0; i < result.size(); i++)
                {
                    corporateTPArray[i] = (CpsmsBeneficiary) result.get(i);
                }

            }
            catch (DataAccessException ex)
            {
                DAOException.throwException("F001", ex);
            }
        }
        else
        {
            DAOException.throwException("CR002");
        }
        logger.info("findTPdetails( String userName, String fileName,String apprIds,String bankType,String functionType)"+ LoggingConstants.METHODEND);
        return corporateTPArray;
    }
    
    public class CorporateInterBankAppFileRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateFile
         */
           
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	logger.info("FILESTAT ::::"+rs.getString("file_processed_status"));
            CorporateFile corporateFile = new CorporateFile();
            corporateFile.setSno(rs.getString("SNO"));
            String fileName = rs.getString("FILE_NAME");
             	corporateFile.setFileName(fileName);             	
                corporateFile.setUploadedDate(rs.getTimestamp("CREATION_TIME"));
                corporateFile.setFileStatus(rs.getString("file_processed_status"));
            
            return corporateFile;
        }
    }
    
    public class CpsmsBeneficiaryRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            corporateTP.setCorporateId(rs.getString("CORPORATE_ID"));
            corporateTP.setOid(rs.getString("OID"));
            corporateTP.setBeneficiaryName(rs.getString("BENEFICIARY_NAME"));
            corporateTP.setAccountNo(rs.getString("ACCOUNT_NO"));
            corporateTP.setBranchCode(rs.getString("BRANCH_CODE"));
            corporateTP.setBeneficiaryCode(rs.getString("ENTITY_CODE"));
            corporateTP.setStatus(rs.getString("STATUS"));
            corporateTP.setAadharId(rs.getString("AADHAR_ID"));
            corporateTP.setBankIIN(rs.getString("BANK_IIN"));
            corporateTP.setOutref7("");
           
            
            return corporateTP;

        }
    }
    
    //added by Damodar for cpsms rowmapper
    
    public class CpsmsBeneficiaryAllRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            
            corporateTP.setOid(rs.getString("ID"));
            
           
            
            return corporateTP;

        }
    }
    
    public class CpsmsBeneficiaryAllIntraRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
           
            corporateTP.setOid(rs.getString("OID"));
            
           
            
            return corporateTP;

        }
    }
    
    public class CpsmsBeneficiaryDelRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            corporateTP.setCorporateId(rs.getString("CORPORATE_ID"));
            corporateTP.setOid(rs.getString("ROW_ID"));
            corporateTP.setBeneficiaryName(rs.getString("BENEFICIARY_NAME"));
            corporateTP.setAccountNo(rs.getString("ACCOUNT_NO"));
            corporateTP.setBranchCode(rs.getString("BENIFICIARY_BRANCH"));
            corporateTP.setBeneficiaryCode(rs.getString("ENTITY_CODE"));
            corporateTP.setStatus(rs.getString("STATUS"));
            corporateTP.setAadharId(rs.getString("AADHAR_ID"));
            corporateTP.setBankIIN(rs.getString("BANK_IIN"));
            corporateTP.setOutref7("");
           
            
            return corporateTP;

        }
    }
    
    
    //added by Damodar
    public class CpsmsBeneficiaryAllDelRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
           
            corporateTP.setOid(rs.getString("ROW_ID"));
            
           
            
            return corporateTP;

        }
    }
    
    
    
    public class CpsmsBeneficiaryInterRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            corporateTP.setCorporateId(rs.getString("CORPORATE_ID"));
            corporateTP.setOid(rs.getString("ID"));
            corporateTP.setBeneficiaryName(rs.getString("BENEFICIARY_NAME"));
            corporateTP.setAccountNo(rs.getString("ACCOUNT_NO"));
            corporateTP.setIfscCode(rs.getString("IFSC_CODE"));
            corporateTP.setBankName(rs.getString("BANK_RECEIVER"));
            corporateTP.setBeneficiaryCode(rs.getString("ENTITY_CODE"));
            corporateTP.setStatus(rs.getString("STATUS"));
            corporateTP.setAadharId(rs.getString("AADHAR_ID"));
            corporateTP.setBankIIN(rs.getString("BANK_IIN"));
            corporateTP.setOutref7("");
           
            
            return corporateTP;

        }
    }
    
    
    public class CpsmsBeneficiaryAllInterRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            
            corporateTP.setOid(rs.getString("ID"));
            
           
            
            return corporateTP;

        }
    }
    public class BeneficiaryValidationFailRowMapper implements RowMapper
    {
        /**
         * This method is used to map rows for CorporateTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
        	CpsmsBeneficiary corporateTP = new CpsmsBeneficiary();
        	
            corporateTP.setBeneficiaryName(rs.getString("BENEFICIARY_NAME"));
            corporateTP.setAccountNo(rs.getString("ACCOUNT_NO"));
            corporateTP.setIfscCode(rs.getString("IFSC_CODE"));
            corporateTP.setBeneficiaryCode(rs.getString("ENTITY_CODE"));
            corporateTP.setStatus(rs.getString("REMARKS"));
            corporateTP.setAadharId(rs.getString("AADHAR_ID"));
            corporateTP.setBankIIN(rs.getString("BANK_IIN"));
            corporateTP.setOutref7("");
           
            
            return corporateTP;

        }
    }
    
  
}
