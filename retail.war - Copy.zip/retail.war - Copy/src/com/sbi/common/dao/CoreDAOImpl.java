/*
 * CoreDAOImpl.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
//DEC 28, 2005 BOOPATHI - EXCEPTION MODIFIED
//MAR 26,2008 CR 2463 | DIRECT CREDIT TO GOVT ACCOUNTS- TAX PAYMENTS (CBEC,OLTAS) |  Balaji,Augustine

package com.sbi.common.dao;

import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Vector;
import java.util.Map;
import org.apache.log4j.Logger;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.IMessageProcessor;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.CoreClient;
import com.sbi.common.model.BankSystemComModel;
import com.sbi.common.dao.TransactionStringLoaderDAO;
import com.sbi.common.utils.CoreMapToBankSystemComModelConverter;

public class CoreDAOImpl implements CoreDAO
{
    protected final Logger logger = Logger.getLogger(getClass());

    IMessageProcessor coreMessageProcessor;

    CoreClient coreClient;
    
    
    private CoreInterfaceDAO coreInterfaceDAOImpl;
    private CoreMapToBankSystemComModelConverter coreMapToBankSystemComModelConverter;
    private TransactionStringLoaderDAO transactionStringLoaderDAOImpl;
    
    private static Set<String> txnLegTxns = new HashSet<String>(); 
    static{
    	txnLegTxns.add("001045");
    	txnLegTxns.add("021031");
    	txnLegTxns.add("11045");
    	txnLegTxns.add("020035");
    	txnLegTxns.add("020066");
    	txnLegTxns.add("020040");
    	txnLegTxns.add("001044");
    	txnLegTxns.add("000419");
		txnLegTxns.add("0010441");
    }
    private static Set<String> brokerAccountTxns = new HashSet<String>(); 
    static{
    	brokerAccountTxns.add("000455");
    }
    //( txnno.equals("001045") || txnno.equals("021031")||txnno.equals("11045") || 
     //		txnno.equals("020035") || txnno.equals("020066")|| txnno.equals("001044")||  txnno.equals("020040") ||txnno.equals("000419") ) 
	/** 
     * Call CoreMessageProcessor.convertRequest(request) and get Vector result
     * from that. Iterate the Vector data and add the data into a Map and return
     * it
     * 
     * @param Map
     *            [request datas for coreClient ]
     * @return List [reponseString from coreClient]
     * @throws DAOException
     * 
     */
    public List getDataFromBankSystem(Map request) throws DAOException
    {
        logger.info("getDataFromBankSystem(Map request) " + LoggingConstants.METHODBEGIN);

        if (request != null)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("request :" + request);
            }
            
            String txnno = (String)request.get("txnno");
           	logger.info("txnno::"+txnno);
            String bankCode = (String)request.get("bankCode"); 
            String requestString = coreMessageProcessor.convertRequest(request);
            
            logger.info("requestString :"+requestString);
            
            if(txnno.equalsIgnoreCase("0010441"))
        	
        		txnno="001044";
        	
            BankSystemComModel bankSystemComModel = null;
            if(txnno!=null && txnLegTxns.contains(txnno) ){ //Changed by marimuthu
			    bankSystemComModel = coreMapToBankSystemComModelConverter.convert(request,requestString);
	            transactionStringLoaderDAOImpl.load(bankSystemComModel);
            }
            List responseList = new ArrayList();
            Vector response = null;
            try
            {
            	logger.info("bankCode :"+bankCode);
//            	//IR 71227
//            	if(brokerAccountTxns.contains(txnno)){
//            		response = coreClient.processMsgString(requestString, bankCode);
//            	} else {
            		response = coreClient.processMsg(requestString, bankCode);
//            	}
                if (logger.isDebugEnabled())
                {
                    logger.debug("response :" + response);
                }
                
            }
            catch (Exception ex) 
            {
                logger.fatal(LoggingConstants.EXCEPTION, ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,ex);
            }

            List prop = coreInterfaceDAOImpl.findCoreResponseData(txnno);
            logger.info("response.size() ::::::::::::::: " + response.size());
            for (int count = 0; count < response.size(); count++)
            {
                String responseString = (String) response.get(count);
                
                if (!responseString.equals(null) && !responseString.equals(DAOConstants.EMPTY)){
                    Map hm = coreMessageProcessor.convertResponse(responseString, txnno, prop);
                    if(txnno!=null && txnLegTxns.contains(txnno)){ //Changed by marimuthu
                    	bankSystemComModel.setResponseString(responseString);
                    	if(txnno.equals("000419") && responseString.length()>12){
                    		boolean  isSuccessTransaction = responseString.charAt(12)=='1'?false:true;
                    		if(isSuccessTransaction)
                    			hm.put("status", "O.K.");
                    	}
                        transactionStringLoaderDAOImpl.update(hm,bankSystemComModel);
                    }
                    responseList.add(hm);
                    if (logger.isDebugEnabled())
                    {
                         logger.debug(hm + "is added into the List ");
                    }
    
                }
            }
            
			logger.info("responseList :"+responseList);
            logger.info("getDataFromBankSystem(Map request) " + LoggingConstants.METHODEND);

            return responseList;

        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public Map getDataFromBankSystem(String request)
    {
        return null;
    }

    /**
     * CoreMessageProcessor injection
     * 
     * @param coreMessageProcessor
     */
    public void setCoreMessageProcessor(IMessageProcessor coreMessageProcessor)
    {
        this.coreMessageProcessor = coreMessageProcessor;
    }

    /**
     * coreClient injection
     * 
     * @param coreClient 
     */
    public void setCoreClient(CoreClient coreClient)
    {
        this.coreClient = coreClient;

    }  

    public void setCoreInterfaceDAOImpl(CoreInterfaceDAO coreInterfaceDAOImpl) {
        this.coreInterfaceDAOImpl = coreInterfaceDAOImpl;
    }
 
	public void setCoreMapToBankSystemComModelConverter(
			CoreMapToBankSystemComModelConverter coreMapToBankSystemComModelConverter) {
		this.coreMapToBankSystemComModelConverter = coreMapToBankSystemComModelConverter;
	}

	public void setTransactionStringLoaderDAOImpl(
			TransactionStringLoaderDAO transactionStringLoaderDAOImpl) {
		this.transactionStringLoaderDAOImpl = transactionStringLoaderDAOImpl;
	}

	
} 
