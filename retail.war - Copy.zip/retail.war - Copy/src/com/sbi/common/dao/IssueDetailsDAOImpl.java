package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.sbi.common.exception.DAOException;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.SQLConstants;

import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.model.Issues;
import com.sbi.common.model.Mail;
import com.sbi.common.model.Ticket;
import com.sbi.common.model.TicketThread;

public class IssueDetailsDAOImpl extends JdbcDaoSupport implements IssueDetailsDAO {

	protected final Logger logger = Logger.getLogger(getClass());

	private TransactionTemplate transactionTemplate;
	private static final String getTicketNo = "select lpad(CORP_TICKET_SEQUENCE.nextval,8,'0') from dual";
	private static final String FIND_TICKETS = "select mail_reference,from_id,mail_subject  ,message,creation_time ,111 cp_workflow_state," +
											   "(select status from SBICORP_MAIL_DELETE_MAP where user_name=? and mail_reference = a.mail_reference) read from sbicorp_mail_box a" +
											   " where (receiver_info = 'All' OR receiver_info = ? OR receiver_info = ?)and  not exists (select * from SBICORP_MAIL_DELETE_MAP b " +
											   "WHERE a.mail_reference = b.mail_reference and b.user_name=? and status = 2) order by creation_time desc";
											   
	private static final String FIND_TICKETS_FOR_ASSOCIATE_BANK = "select mail_reference,from_id,mail_subject  ,message,creation_time ,111 cp_workflow_state," +
			   "(select status from SBICORP_MAIL_DELETE_MAP where user_name=? and mail_reference = a.mail_reference) read from sbicorp_mail_box a" +
			   " where (receiver_info = 'All' OR receiver_info = ? OR receiver_info = ?)and  not exists (select * from SBICORP_MAIL_DELETE_MAP b " +
			   "WHERE a.mail_reference = b.mail_reference and b.user_name=? and status = 2)  and a.bank_code=? order by creation_time desc";
	
	private static final String FIND_UNREAD_MAILS = "select count (*) from sbicorp_mail_box a where not exists (select mail_reference"+ 
		" from SBICORP_MAIL_DELETE_MAP b where user_name = ? and b.status in (1,2) and b.mail_reference = a.mail_reference)" +
		" and (receiver_info = 'All' OR receiver_info = ? OR receiver_info = ?) and bank_code=? and status = 'Active'";
	public List findIssues(Map inParams) throws DAOException {
		
		logger.info("findIssues()" + LoggingConstants.METHODBEGIN + inParams);
		List issueList=null;
		int userType = ((Integer) inParams.get("userType")).intValue();
		String bankCode = (String) inParams.get("bankCode");
		String SBIBankCodes="0|a|A|3|6";
		if(bankCode!=null && (SBIBankCodes.contains(bankCode)))//SBIInd Merger
			bankCode="0";
		int userRole = ((Integer) inParams.get("userRole")).intValue();
		Object[] params = { userType, bankCode, userRole };
		int[] types = { Types.NUMERIC, Types.VARCHAR, Types.NUMERIC };
		try {
				issueList = getJdbcTemplate().query(SQLConstants.FIND_CORP_ISSUES, params, types,new IssueDetailsDAOImplRowMapper());
				
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		logger.info("findIssues()" + LoggingConstants.METHODEND);

		return issueList;
	}

	class IssueDetailsDAOImplRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int count) throws SQLException {
			Issues issues = new Issues();
			issues.setKey(rs.getString("issue_code"));
			issues.setValue(rs.getString("issue_description"));
			return issues;
		}

	}

	public Map insertTicketDetails(final Map inParams) throws DAOException {
		logger.info("insertTicketDetails(Map inParams)"+ LoggingConstants.METHODBEGIN + inParams);
		Map outParams = new HashMap();
		
		try{
			if(inParams!=null){
			String ticketPrefix=(String)inParams.get("ticketPrefix");
			final String ticketNo = ticketPrefix+(String) getJdbcTemplate().queryForObject(getTicketNo, String.class);
			transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus transactionStatus) {
				try {
					Ticket ticket = (Ticket) inParams.get("ticket");
					if (ticket != null && ticketNo!=null && ticketNo.trim().length()>0) {
						ticket.setTicketNo(ticketNo);
						ticket.getTicketThread().setTicketNo(ticketNo);
						
						
						insertTicketMaster(ticket);
						insertTicketThread(ticket.getTicketThread());
						
					} else {
						logger.info(LoggingConstants.NULL_INPUT_PARAMS);
						DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
					}
				} catch (DAOException e) {
					transactionStatus.setRollbackOnly();
					e.printStackTrace();
					Object[] errorparams = { inParams };
					DAOException.throwException(e, "LOG008", errorparams);
				}
				return null;
			}
		});
		
		outParams.put("ticketNo",ticketNo);
			}
			else {
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}	
		}
		catch(DataAccessException e){
			e.printStackTrace();
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		logger.info("insertTicketDetails(Map inParams)"+ LoggingConstants.METHODEND);
		return outParams;
	}

	
	public void insertTicketMaster(Ticket ticket) throws DAOException {
		logger.info("insertTicketMaster(Ticket ticket)"	+ LoggingConstants.METHODBEGIN + ticket.toString());

		if (ticket != null) {
			try {
				Object[] params = { ticket.getTicketNo(),
						ticket.getIssueCode(), ticket.getUserName(),
						ticket.getName(), ticket.getParam1(),
						ticket.getParam2(), ticket.getParam3(),
						ticket.getParam4(), ticket.getClaimant(),
						ticket.getDescription(), ticket.getWorkFlowState(),
						ticket.getRead(), ticket.getBranchCode(),
						ticket.getBankCode(), ticket.getRaisedBy(),
						ticket.getLabelId() };
				int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
								Types.VARCHAR, Types.NUMERIC, Types.NUMERIC,
								Types.VARCHAR, Types.NUMERIC, Types.VARCHAR,
								Types.VARCHAR };
				getJdbcTemplate().update(SQLConstants.INSERT_CORP_TICKET_MASTER, params, types);
			} catch (DataAccessException dataAccessException) {
					dataAccessException.printStackTrace();
					DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		} else {
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}

		logger.info("insertTicketMaster(Ticket ticket)"+ LoggingConstants.METHODEND);
	}

	public void insertTicketThread(TicketThread ticketThread)throws DAOException {
		logger.info("insertTicketThread(TicketThread ticketThread)"+ LoggingConstants.METHODBEGIN + ticketThread.toString());
		if (ticketThread != null ) {
			try {
				Object[] params = { ticketThread.getTicketNo(),
									ticketThread.getThread_originator(),
									ticketThread.getThread() };
				int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
				if(ticketThread.getThread() != null && ticketThread.getThread().trim().length()>0)
				getJdbcTemplate().update(SQLConstants.INSERT_CORP_TICKET_THREAD, params, types);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		} else {
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("insertTicketThread(TicketThread ticketThread)"+ LoggingConstants.METHODEND);
	}
	
	public List findTickets(Map inParams) throws DAOException {
		
		logger.info("findTickets(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		List ticketsList=null;
		if(inParams!=null){
			String userName = (String) inParams.get("userName");
			String ticketType = (String) inParams.get("ticketType");
			if (userName != null) {
			Object[] params = {userName};
			int[] types = { Types.VARCHAR };
			try {
				if("closedTickets".equalsIgnoreCase(ticketType)){
					ticketsList = getJdbcTemplate().query(SQLConstants.FIND_CLOSED_TICKETS, params, types,new TicketsDAOImplRowMapper());
				}else{
					ticketsList = getJdbcTemplate().query(SQLConstants.FIND_TICKETS, params, types,new TicketsDAOImplRowMapper());
				}
		
				} catch (DataAccessException dataAccessException) {
					dataAccessException.printStackTrace();
					DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
				}
			}
			else {
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}else{
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findTickets(Map inParams)" + LoggingConstants.METHODEND);

		return ticketsList;
	}
	
	class TicketsDAOImplRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int count) throws SQLException {
			Ticket ticket=new Ticket();
			ticket.setTicketNo(rs.getString("ticket_no"));
			ticket.setName(rs.getString("name"));
			ticket.setUserName(rs.getString("username"));
			ticket.setDescription(rs.getString("description"));
			ticket.setCreationTime(rs.getTimestamp("creation_time"));
			int workflowState=rs.getInt("cp_workflow_state");
			ticket.setWorkFlowState(workflowState);
			if(workflowState==106)
				ticket.setTicketStatus("In Queue");
			else if(workflowState==107)
				ticket.setTicketStatus("In Process");
			else if(workflowState==109)
				ticket.setTicketStatus("In Discussion");
			else if(workflowState==108)
				ticket.setTicketStatus("Actioned");
			else if(workflowState==110)
				ticket.setTicketStatus("Closed");
				ticket.setRaisedBy("Customer Care");
			ticket.setRead(rs.getInt("read"));
			if(ticket.getRead() == null){
				ticket.setRead(new Integer(0));
			}
			return ticket;
		}

	}
	
public List findMails(Map inParams) throws DAOException {
		
		logger.info("findMails(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		List mailList=null;
		
		String userName = (String) inParams.get("userName");
		String corp_id = (String) inParams.get("coprorateID");
		String corp_type = "Vyappar";
		Integer smallFlag = (Integer)inParams.get("smallFlag");	
		if(smallFlag.intValue() == 1){
			corp_type = "Vistaar";
		}else if(smallFlag.intValue() == 4)
			corp_type = "saral";
		if (userName != null) {
		Object[] params = {userName, corp_type, corp_id,userName};
		int[] types = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR };
		try {
			mailList = getJdbcTemplate().query(FIND_TICKETS, params, types,new MailsDAOImplRowMapper());
				//logger.info("Mail :" + mailList);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findMails(Map inParams)" + LoggingConstants.METHODEND);

		return mailList;
	}
	
class MailsDAOImplRowMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int count) throws SQLException {
		Mail mail=new Mail();
		mail.setMailReference(rs.getString("mail_reference"));
		mail.setFromId(rs.getString("from_id"));
		mail.setMailSubject(rs.getString("mail_subject"));
		mail.setMessage(rs.getString("message"));
		mail.setCreationTime(rs.getTimestamp("creation_time"));
		int workflowState=rs.getInt("cp_workflow_state");
		mail.setWorkFlowState(workflowState);
		mail.setRead(rs.getInt("read"));
		
			
		
		return mail;
	}

}
public List findTicketThreadsDetails(Map inParams) throws DAOException {
		
		logger.info("findTicketThreadsDetails(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		//modified for  corpuser paladion 
		String updateTicketMaster="update sbicorp_cs_ticket_master set  read=1 where ticket_no=? and username=? ";
		List threadList=null;
		String ticketNo = (String) inParams.get("ticketNo");
		String workFlowState = (String) inParams.get("workFlowState");

		//modified for  corpuser paladion 
		String userName = (String) inParams.get("userName");
		int updateCount=0;
		if (ticketNo != null) {

			//modified for  corpuser paladion 
		Object[] params = {ticketNo,userName};
		int[] types = { Types.VARCHAR ,Types.VARCHAR };
		try {
		
			
				threadList = getJdbcTemplate().query(SQLConstants.FIND_TICKET_THREADS, params, types,new TicketDetailsDAOImplRowMapper());
				updateCount = getJdbcTemplate().update(updateTicketMaster, params, types);
			if(updateCount<=0){
				logger.info("updatecount.size is <= 0");
				DAOException.throwException("SE002");
			}
						
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
			
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findTicketThreadsDetails(Map inParams)" + LoggingConstants.METHODEND);

		return threadList;
	}
	
	class TicketDetailsDAOImplRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int count) throws SQLException {
			TicketThread ticketThread=new TicketThread();
			ticketThread.setTicketNo(rs.getString("ticket_no"));
			ticketThread.setThread_originator(rs.getString("thread_originator"));
			ticketThread.setThread(rs.getString("thread"));
			ticketThread.setThread_date(rs.getTimestamp("thread_date"));
			return ticketThread;
		}

	}
	
	public void updateTicketDetails(final Map inParams) throws DAOException
	{
		logger.info("updateTicketDetails(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		int updatecount=0;
		try{
			if(inParams!=null){
			transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus transactionStatus) {
				try {
					Ticket ticket = (Ticket) inParams.get("ticket");
					if (ticket != null ) {
						
						int updateCount=updateTicketMaster(ticket);
						if(updateCount>0)
						insertTicketThread(ticket.getTicketThread());
						else
						{
							logger.info("The ticket master table is not updated");
							DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
						}
							
						
					} else {
						logger.info(LoggingConstants.NULL_INPUT_PARAMS);
						DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
					}
				} catch (DAOException e) {
					transactionStatus.setRollbackOnly();
					e.printStackTrace();
					Object[] errorparams = { inParams };
					DAOException.throwException(e, "LOG008", errorparams);
				}
				return null;
			}
		});
		
		}
			else {
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}	
		}
		catch(DataAccessException e){
			e.printStackTrace();
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		
		logger.info("updateTicketDetails(Map inParams)" + LoggingConstants.METHODEND);
	
		
	}
	public int updateTicketMaster(Ticket ticket) throws DAOException {
		
		logger.info("updateTicketMaster(Map inParams)" + LoggingConstants.METHODBEGIN + ticket);
		int updateCount =0;
		if(ticket!=null){
		String ticketNo = ticket.getTicketNo();
		int workFlowState=ticket.getWorkFlowState();
		String userName=ticket.getUserName();
		String queryChange="";
		Object[] params = {workFlowState,ticketNo ,userName};
		int[] types = {Types.NUMERIC, Types.VARCHAR,Types.VARCHAR };
		try {
			
			if(workFlowState==110)
				queryChange=DAOConstants.COMA +"date_closed=sysdate";
			String finalQuery = SQLConstants.UPDATE_TICKET_MASTER.replaceAll(DAOConstants.TO_BE_REPLACED, queryChange);
		
			updateCount = getJdbcTemplate().update(finalQuery, params, types);
		
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("updateTicketMaster(Map inParams)" + LoggingConstants.METHODEND);

		return updateCount;
	}
	
	public void deleteTicketDetails(final Map inParams) throws DAOException
	{
		logger.info("deleteTicketDetails(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		try{
			if(inParams!=null){
				int updatecount=0;
				String UPDATE_MAIL_DELETE = "update sbicorp_mail_delete_map set  status=2 where mail_reference in (#tobereplaced#) and user_name = ?";
				// Defect Unread mail Not getting Deleted
				String insertMailReadStatus = "insert into SBICORP_MAIL_DELETE_MAP (MAIL_REFERENCE, USER_NAME, STATUS) VALUES (?,?,?) ";
				String checkReadStatus = "select count(*) from SBICORP_MAIL_DELETE_MAP where MAIL_REFERENCE = ? and USER_NAME =?"; 
				int updateCount=0;
				
				String queryString = DAOConstants.EMPTY;
				List ticketList = (List) inParams.get("ticketList");
				String userName = (String) inParams.get("userName");
				if(ticketList != null && ticketList.size() > 0 && userName!= null){
				try {
					for (int i = 0; i < ticketList.size(); i++) {
						// Defect Unread mail Not getting Deleted Begin
						Object[] params1 = {ticketList.get(i), userName,new Integer(2)};	
						Object[] params2 = {ticketList.get(i), userName};
					
						int[] types1 = { Types.VARCHAR,Types.VARCHAR,Types.INTEGER};
						int[] types2 = { Types.VARCHAR,Types.VARCHAR};
						
						int insertCount = getJdbcTemplate().queryForInt(checkReadStatus, params2, types2);
						if (insertCount == 0){
							updateCount = getJdbcTemplate().update(insertMailReadStatus, params1, types1);
						}
						// Defect Unread mail Not getting Deleted End
			            if (i==0) {
			                queryString = queryString + DAOConstants.EMPTY +"'"+ticketList.get(i)+"'";
			            } else {
			                queryString = queryString + DAOConstants.COMA +"'"+ticketList.get(i)+"'";
			            }
					}
					Object[] params = {userName};
					String finalQuery = UPDATE_MAIL_DELETE.replaceAll(
			                DAOConstants.TO_BE_REPLACED, queryString);
					
					updatecount = getJdbcTemplate().update(finalQuery,params);
				
					} catch (DataAccessException dataAccessException) {
						dataAccessException.printStackTrace();
						DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
					}
				}
				else {
					logger.info(LoggingConstants.NULL_INPUT_PARAMS);
					DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
				}
			}else{
				logger.info(LoggingConstants.NULL_INPUT_PARAMS);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
		}
		catch(DataAccessException e){
			e.printStackTrace();
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
	
		logger.info("deleteTicketDetails(Map inParams)" + LoggingConstants.METHODEND);
	}
	
	public void markAsUnread(List ticketList) throws DAOException {
	
	logger.info("markAsUnread((String[] ticketList))" + LoggingConstants.METHODBEGIN + ticketList);
	int updateCount =0;
	if(ticketList!=null){
	String queryString = DAOConstants.EMPTY;
	 boolean flag = true;
	for (int i = 0; i < ticketList.size(); i++) {
           
            if (flag) {
                queryString = queryString + DAOConstants.EMPTY +"'"+ticketList.get(i)+"'";
                flag = false;
            } else {
                queryString = queryString + DAOConstants.COMA +"'"+ticketList.get(i)+"'";
            }
        }
	
			
	try {
		String finalQuery = SQLConstants.UPDATE_TICKET_UNREAD.replaceAll(
                DAOConstants.TO_BE_REPLACED, queryString);
		
		updateCount = getJdbcTemplate().update(finalQuery);
		
		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
	}
	else {
		logger.info(LoggingConstants.NULL_INPUT_PARAMS);
		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	}	
	logger.info("markAsUnread((String[] ticketList))" + LoggingConstants.METHODEND);

	}
	
	public void updateMailBox(Map inParams) throws DAOException {
		
		logger.info("updateMailBox(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		String insertMailReadStatus = "insert into SBICORP_MAIL_DELETE_MAP (MAIL_REFERENCE, USER_NAME, STATUS) VALUES (?,?,?) ";
		String checkReadStatus = "select count(*) from SBICORP_MAIL_DELETE_MAP where MAIL_REFERENCE = ? and USER_NAME =?"; 
		String updateReadStatus = "update SBICORP_MAIL_DELETE_MAP set status = 1 where MAIL_REFERENCE = ? and USER_NAME =?";
		String mailReference = (String) inParams.get("mailReference");
		String userName = (String) inParams.get("userName");
		int updateCount=0;
		if (mailReference != null) {
		Object[] params1 = {mailReference, userName,new Integer(1)};	
		Object[] params2 = {mailReference, userName};
	
		int[] types1 = { Types.VARCHAR,Types.VARCHAR,Types.INTEGER};
		int[] types2 = { Types.VARCHAR,Types.VARCHAR};
		
		try {
				
				int insertCount = getJdbcTemplate().queryForInt(checkReadStatus, params2, types2);
				if (insertCount == 0){
					updateCount = getJdbcTemplate().update(insertMailReadStatus, params1, types1);
				}else{
					updateCount = getJdbcTemplate().update(updateReadStatus, params2, types2);
				}
			
			
			
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
			
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("updateMailBox(Map inParams)" + LoggingConstants.METHODEND);

	
	}
	
	public void markMailAsUnread(List ticketList,String userName) throws DAOException {
		
		logger.info("markMailAsUnread((String[] ticketList))" + LoggingConstants.METHODBEGIN + ticketList);
		String UPDATE_MAIL_UNREAD = "update sbicorp_mail_delete_map set  status=0 where mail_reference in (#tobereplaced#) and user_name = ?";
		int updateCount =0;
		if(ticketList!=null){
		String queryString = DAOConstants.EMPTY;
		 boolean flag = true;
		for (int i = 0; i < ticketList.size(); i++) {
	        
	            if (flag) {
	                queryString = queryString + DAOConstants.EMPTY +"'"+ticketList.get(i)+"'";
	                flag = false;
	            } else {
	                queryString = queryString + DAOConstants.COMA +"'"+ticketList.get(i)+"'";
	            }
	        }
		
				
		try {
			Object[] params = {userName};
			String finalQuery = UPDATE_MAIL_UNREAD.replaceAll(
	                DAOConstants.TO_BE_REPLACED, queryString);
			
			updateCount = getJdbcTemplate().update(finalQuery,params);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}	
		logger.info("markMailAsUnread((String[] ticketList))" + LoggingConstants.METHODEND);

		}
	
	public String findMailDetails(String mailReference)throws DAOException {
		logger.info("findMailDetails(String mailReference)"+ LoggingConstants.METHODBEGIN );
		String GET_MAIL_DESCRIPTION = "select message from sbicorp_mail_box where mail_reference = ?";
		String mailDescription = null;
		try {
				Object[] params = {mailReference};
				mailDescription = (String) getJdbcTemplate().queryForObject(GET_MAIL_DESCRIPTION,params,String.class);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
			logger.info("findMailDetails(String mailReference)"+ LoggingConstants.METHODEND);
		return 	mailDescription;
	} 

	
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}


	public int getUnReadMails(Map inParams) throws DAOException {
		logger.info("getUnReadMails(Map inParams)" + LoggingConstants.METHODBEGIN);
		int count = 0;
		String userName = (String) inParams.get("userName");
		String corp_id = (String) inParams.get("corporateID");
		String corp_type = "Vyappar";
		Integer smallFlag = (Integer) inParams.get("smallFlag");
		String bankCode = (String) inParams.get("bankCode");
		if (smallFlag.intValue() == 1) {
			corp_type = "Vistaar";
		} else if (smallFlag.intValue() == 4)
			corp_type = "saral";
		if (userName != null) {
			Object[] params = { userName, corp_type, corp_id, bankCode };
			int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
			try {
				count = getJdbcTemplate().queryForInt(FIND_UNREAD_MAILS, params, types);
				logger.info("unread Mail count :" + count);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
			}
		} else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getUnReadMails(Map inParams)" + LoggingConstants.METHODEND);
		return count;
	}
	
	public List findMailsForAssociateBank(Map inParams) throws DAOException {
		
		logger.info("findMails(Map inParams)" + LoggingConstants.METHODBEGIN + inParams);
		List mailList=null;
		
		String userName = (String) inParams.get("userName");
		String corp_id = (String) inParams.get("coprorateID");
		String corp_type = "Vyappar";
		Integer smallFlag = (Integer)inParams.get("smallFlag");	
		/*..For Associate Bank MailBox Enable..start*/
		String bankCode=(String)inParams.get("bankCode");
		/*..For Associate Bank MailBox Enable..end*/
		if(smallFlag.intValue() == 1){
			corp_type = "Vistaar";
		}else if(smallFlag.intValue() == 4)
			corp_type = "saral";
		if (userName != null) {
		/*Object[] params = {userName, corp_type, corp_id,userName};
		int[] types = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR };*/
			/*..For Associate Bank MailBox Enable..start*/
			Object[] params = {userName, corp_type, corp_id,userName,bankCode};
			int[] types = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR };
			/*..For Associate Bank MailBox Enable..end*/
		try {
			mailList = getJdbcTemplate().query(FIND_TICKETS_FOR_ASSOCIATE_BANK, params, types,new MailsDAOImplRowMapper());
				//logger.info("Mail :" + mailList);
			} catch (DataAccessException dataAccessException) {
				dataAccessException.printStackTrace();
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
			}
		}
		else {
			logger.info(LoggingConstants.NULL_INPUT_PARAMS);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findMails(Map inParams)" + LoggingConstants.METHODEND);

		return mailList;
	}

}
