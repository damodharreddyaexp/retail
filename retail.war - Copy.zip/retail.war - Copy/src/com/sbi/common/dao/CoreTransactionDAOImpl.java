/*
 * CoreDAOImpl.java 
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
//DEC 28, 2005 BOOPATHI - EXCEPTION MODIFIED
//JAN 06, 200 BOOPATHI - EXCEPTION MODIFIED
package com.sbi.common.dao;

import java.util.List;
import java.util.ArrayList;
import java.util.Vector;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.BankSystemComModel;
import com.sbi.common.utils.CoreMapToBankSystemComModelConverter;
import com.sbi.common.utils.IMessageProcessor;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.CoreClient;

public class CoreTransactionDAOImpl implements CoreTransactionDAO
{
    protected final Logger logger = Logger.getLogger(getClass());

    IMessageProcessor coreMessageProcessor;

    CoreClient coreClient;
    
    String connectToPort;
    
    private CoreInterfaceDAO coreInterfaceDAOImpl;
    private CoreMapToBankSystemComModelConverter coreMapToBankSystemComModelConverter;
    private TransactionStringLoaderDAO transactionStringLoaderDAOImpl;
	
	/** 
     * Call CoreMessageProcessor.convertRequest(request) and get Vector result
     * from that. Iterate the Vector data and add the data into a Map and return
     * it
     * 
     * @param Map
     *            [request datas for coreClient ]
     * @return List [reponseString from coreClient]
     * @throws DAOException
     * 
     */
    public List getDataFromBankSystem(Map request) throws DAOException
    {
        logger.debug("getDataFromBankSystem(Map request) Begin" );
        
        if (request != null)
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("request :" + request);
            }
            
            String txnno = (String)request.get("txnno");
            String bankCode = (String)request.get("bankCode");
            
            logger.info("bankCode :"+bankCode);
            
            String requestString = coreMessageProcessor.convertRequest(request);
            
            logger.info("requestString :"+requestString);
            BankSystemComModel bankSystemComModel = null;
            //txn no :001044 is added for cbec direct credit by siva
 			// txn no :000419 is added for DD Commission by Megavannan for getting commission amount from core
			if (txnno.equals("000419") || txnno.equals("001045") || txnno.equals("021031")
					|| txnno.equals("11045") || txnno.equals("020035") || txnno.equals("020066")
					|| txnno.equals("020040") || txnno.equals("001044") || txnno.equals("003045") || "021051".equals(txnno)) {// Added for RTGS/NEFT,'003045' added for e-TDR
				bankSystemComModel = coreMapToBankSystemComModelConverter.convert(request, requestString);
				transactionStringLoaderDAOImpl.load(bankSystemComModel);
			}
            List responseList = new ArrayList();
            Vector response = null;
            try
            {
            	logger.info("connectToPort :"+connectToPort);
                response = coreClient.processMsg(requestString, bankCode);
 
                if (logger.isDebugEnabled())
                {
                    logger.debug("response :" + response);
                }
                
            }
            catch (Exception ex) 
            {
                logger.fatal(LoggingConstants.EXCEPTION, ex);
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,ex);
            }

            List prop = coreInterfaceDAOImpl.findCoreResponseData(txnno);
            
            for (int count = 0; count < response.size(); count++)
            {
                String responseString = (String) response.get(count);
                if (!responseString.equals(null) && !responseString.equals(DAOConstants.EMPTY))
                {
                        Map hm = coreMessageProcessor.convertResponse(responseString, txnno, prop);
                        //txn no :001044 is added for cbec direct credit by siva
 
					// txn no :000419 is added for DD Commission by Megavannan for update core response
					// added for e-TDR
					if (txnno.equals("003045") ||txnno.equals("000419") || txnno.equals("001045") || txnno.equals("021031")
							|| txnno.equals("11045") || txnno.equals("020035") || txnno.equals("020066") || "021051".equals(txnno)
							|| txnno.equals("020040") || txnno.equals("001044")) {// Added for RTGS/NEFT
						bankSystemComModel.setResponseString(responseString);
						transactionStringLoaderDAOImpl.update(hm, bankSystemComModel);
					}
                        responseList.add(hm);
                        if (logger.isDebugEnabled())
                        {
                             logger.debug(hm + "is added into the List ");
                        }
                    
                }
            }
            
			logger.info("responseList :"+responseList);
            logger.debug("getDataFromBankSystem(Map request) Ends");

            return responseList;

        }
        else
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public Map getDataFromBankSystem(String request)
    {
        return null;
    }

    /**
     * CoreMessageProcessor injection
     * 
     * @param coreMessageProcessor
     */
    public void setCoreMessageProcessor(IMessageProcessor coreMessageProcessor)
    {
        this.coreMessageProcessor = coreMessageProcessor;
    }

    /**
     * coreClient injection
     * 
     * @param coreClient 
     */
    public void setCoreClient(CoreClient coreClient)
    {
        this.coreClient = coreClient;

    }  
    
    public void setConnectToPort(String connectToPort) {
		this.connectToPort = connectToPort;
	}

    public void setCoreInterfaceDAOImpl(CoreInterfaceDAO coreInterfaceDAOImpl) {
        this.coreInterfaceDAOImpl = coreInterfaceDAOImpl;
    } 
    public void setCoreMapToBankSystemComModelConverter(
			CoreMapToBankSystemComModelConverter coreMapToBankSystemComModelConverter) {
		this.coreMapToBankSystemComModelConverter = coreMapToBankSystemComModelConverter;
	}
    public void setTransactionStringLoaderDAOImpl(
			TransactionStringLoaderDAO transactionStringLoaderDAOImpl) {
		this.transactionStringLoaderDAOImpl = transactionStringLoaderDAOImpl;
	}
} 
