/* 
 * IBTransactionDAO.java
 * Created on Oct 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 26, 2005 BOOPATHI - Initial Creation

package com.sbi.common.dao;

import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionLeg;
import com.sbi.common.model.TransactionResponse; 

import java.util.Date;
import java.util.List; 

public interface IBTransactionDAO
{

    String createTransaction( Transaction transaction );
    
    List findDebits( String userName, String status );
    
    boolean updateStatus( TransactionResponse transactionResponse,String refNo );
     
    List findDebits( String userName );
     
    TransactionLeg findDebit( String referenceNo ); 
      
    List findCredits( String refernceNo );
    
    Double findTodaysTxnAmount(String accountNo, String branchCode, Double amount);
    
    Double findTodaysGovtTxnAmount(String accountNo, String branchCode, Double amount);
    
    Double findInterBranchAmount(String accountNo, String branchCode, Double amount, String refName);
    
    Double findTodaysTotalTxnAmount(String userName, Double amount,String refType,Date scheduledDate);
    
    //Merchant Limit Changes - Start
    Double findRetailUsrTodaysTotalTxnAmount(String userName, Double amount,Date scheduledDate);
    
    Double findRetailUsrTodaysIGTotalTxnAmount(String userName, Double amount,Date scheduledDate);
    
    Double findSaralUsrTodaysTotalTxnAmount(String userName, Double amount,Date scheduledDate);
    
    Double findGovtRTLUsrTodaysTotalTxnAmount(String userName, Double amount,Date scheduledDate);
    Double findGovtSaralUsrTodaysTotalTxnAmount(String userName, Double amount,Date scheduledDate);
    
    Double findGovtindependentTotalTxnAmount(String userName, Double amount, Date scheduledDate, String merchantCode);
    //Added for CR 2921
    boolean updateUTRNo(String refNo,String utrNo,String commissionAmount);
    
    //Added for NEFT multiple credit commsion
    
    public boolean updateMultipleCreditsCommission(Double commAmount,String refNo,Double crAmount);
     
    //E-suvidha
	int insertKioskDetails(String referenceNo, String kioskID, String userName, String bankCode); // Added for KiosK - CR 2914
	//Added for E-suvidha
	List findDebits(String userName,String transactionType,String fromDate,String toDate);//Added for CR 2975
	
	public Double findTodaysTotalCategoryCAmount(String userName, Double amount , Date scheduledDate);
	
	public boolean validateIcollectCreditAccountNo(String creditAccountNo,String categoryId);
	
	public Double findTodaysTotalSubCategoryGroupBTxnAmount(String userName, Double amount , Date scheduledDate,String category);
	
	 public Double findTodaysTotalCategoryBAmount(String userName, Double amount , Date scheduledDate);

	//Added for eTDR/eSTDR
    Double findTodaysTotalCategoryGAmount(String userName, Double amount , Date scheduledDate);
    public Double findTodaysFdAmount(Double debitAmount,String userName);

}
