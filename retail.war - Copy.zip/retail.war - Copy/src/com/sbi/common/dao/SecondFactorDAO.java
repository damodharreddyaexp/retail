package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

public interface SecondFactorDAO {

	String isAuthenticationEnabled(String userName);

	String getTokenDetails(String serialNo,String authCode);
	
	String getTokenDetails(String serialNo);

	int updateDPData(String serialNo, String tokenDetails);
	
	int updateDPData(String serialNo, String tokenDetails, String authCode);
	
	String getSwTokenDetails(String serialNo,String authCode); //added for software token Implementation
	
	int updateDPDataOfSwToken(String serialNo, String tokenDetails, String authCode); //added for software token Implementation

	List getDpdataOfSerialNo(String userName,String serialNo);
	
	Map getSerialNoandDpdata(String userName,String serialNo);
	
	int checkULBlobCount(String serialNo);
}
