/*
 * TransactionAccountMasterDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 SK33412 - Initial Creation

package com.sbi.common.dao;

public interface TransactionAccountMasterDAO extends AccountMasterDAO 
{

}