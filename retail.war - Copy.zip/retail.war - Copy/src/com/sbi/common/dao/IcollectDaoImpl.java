package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

public class IcollectDaoImpl extends JdbcDaoSupport implements IcollectDao {
	protected static Logger logger = Logger.getLogger(IcollectDaoImpl.class);
/*	private static final String FIND_ICOLLECT_CATEGORIES = "select * from sbi_institute_category where institute_id in "+ 
														   "(select institute_id from sbi_institute_master where  corp_id = ?) "+ 
														   "and approved_status = 'approved' and circle_approved_status = 'approved' "+
														   "and status ='Active'";*/
	private static final String FIND_ICOLLECT_CATEGORIES = "select distinct b.* from bvsbi.sbi_institute_master a, bvsbi.sbi_institute_category b , bvsbi.SB_COLLECT_ADVICE c Where a.Corp_Id=? and a.Status='Active' and A.Institute_Id=B.Institute_Id and C.Institution_Id=A.Institute_Id and B.Category_Id=C.Category_Id and Substr(C.Reference_No,1,2)='DU'"; //04-11-2014
	
	private static final String GET_REPORT_DETAILS       = " SELECT b.echeque_no,b.echeque_date,b.status_description,b.echeque_amount,a.outref9,a.outref10 FROM bvsbi.GENERAL_OUTREF_VIEW a,bvsbi.sbicorp_echeque_master b WHERE "+
													       " a.oid = b.oid AND b.MERCHANT_CODE = 'FEE' AND b.DEBIT_STATUS = '00' AND A.OUTREF6 = ?  AND "+
													       " trunc(b.reco_generated_time) between TO_DATE(?, 'dd/mm/yyyy') and TO_DATE(?, 'dd/mm/yyyy')";
	 
	private static final String INSERT_REPORT_DETAILS    = "insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME,PARAM7,PARAM8) " +
															"values(?,?,'Pending',?,?,?,?,?,?,sysdate,sysdate,(select institute_id from bvsbi.sbi_institute_master where corp_id=? and status='Active'),?)";
	
	
	private static final  String VIEW_ICOLLECT_DETAILS   = "select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,PARAM4 from  bvsbi.sbi_lpr_input where user_name=? and request_type in('icollectReport','SBCollectReconReport') and trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
	
  //  private static final String FIND_CA_ACCOUNT_DETAILS ="select a.account_no,a.product_type,a.branch_code,b.branch_name from sbicorp_ca_account_map A, SBI_BRANCH_MASTER B where corporateid=? and a.ca_user=? and a.status = 1 and a.product_type in ('A1','A2','A3') AND a.BRANCH_CODE = B.BRANCH_CODE ORDER BY ACCOUNT_NICKNAME, ACCOUNT_NO";
	  private static final String FIND_CA_ACCOUNT_DETAILS ="select distinct b.account_no from bvsbi.sbi_institute_master a, bvsbi.sbi_institute_category b , bvsbi.SB_COLLECT_ADVICE c where a.corp_id=? and a.status='Active' and a.institute_id=b.institute_id and c.institution_id=a.institute_id and b.category_id=c.category_id and Substr(C.Reference_No,1,2)='DU'"; // 04-11-2014

    private static final String INSERT_ACCOUNTNO_REPORT_DETAILS = "insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM6,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','SBCollectReconReport',?,?,?,?,?,sysdate,sysdate)";
    
	public List findIcollectCategories(String corporateId) throws DAOException {
		logger.info("findIcollectCategories(String corporateId) method begins");
		logger.info("Corporate ID: " + corporateId);
		List categoryList = null;
		try{
			Object[] params={corporateId};
			categoryList = getJdbcTemplate().queryForList(FIND_ICOLLECT_CATEGORIES,params);
			if(categoryList!=null && categoryList.size()>0){
				return categoryList;
			}else{
				DAOException.throwException("SUV001");
			}
		}catch(DataAccessException exp){
			DAOException.throwException(exp,"SUV001",new Object[]{corporateId});
		}
		logger.info("findIcollectCategories(String corporateId) method ends");
		return categoryList;
	}
	
	/* Modified for SB Collect Recon Report URD  06-10-14*/
	public int insertReportDetails(String requestId,String categoryId,String startDate, String endDate, String userName,String fileType,String paymentmode,String corporateId,String accountNO,String reportType)throws DAOException {
		int count=0;
		try{
				if("POSTLOGIN".equalsIgnoreCase(paymentmode) || "SBCollectReconReport".equals(reportType))
				{
					paymentmode="";
				}
				
				Object[] params = {requestId,userName,reportType,startDate,endDate,categoryId,fileType,paymentmode,corporateId,corporateId};
				if("SBCollectReconReport".equals(reportType))
					params = new Object[]{requestId,userName,reportType,startDate,endDate,accountNO,fileType,paymentmode,corporateId,corporateId};
				
				count = getJdbcTemplate().update(INSERT_REPORT_DETAILS,params);
				
		}catch(DataAccessException exp){
			DAOException.throwException(exp,"SUV022",new Object[]{requestId});
		}
		 return count;
	}

	/*public List getReportDetails(String categoryId,String startDate, String endDate)throws DAOException {
	    logger.info("getReportDetails(String categoryId) method begins:  : "+categoryId+"startdate "+startDate +"endDate "+endDate);
	    List reportList = null;
	    try {
	    Object[] params = {categoryId,startDate,endDate};
	    reportList = getJdbcTemplate().queryForList(GET_REPORT_DETAILS,params);
	    if(reportList !=null)
	    logger.info("reportList size "+reportList.size());
	    } catch (DataAccessException exp) {
	    logger.error("Exception occured: " + exp.getMessage(),exp);
	    DAOException.throwException(ServiceErrorConstants.SE003);
	    }
	    logger.info("getReportDetails(String categoryId) method ends");
	    return reportList;
	}*/
	
	public List getReportRequest(String userName) throws DAOException{
        logger.info("getReportRequest(String username) method begins");
        logger.info("username::::"+userName);
        List reportList=null;
        if( userName != null ){
            Object[] params;
            try{ 
            	params = new Object[] {userName};
            	reportList = (List)getJdbcTemplate().query(VIEW_ICOLLECT_DETAILS,params, new ViewStatusListExtractor());
            }catch (DataAccessException exception) {
                DAOException.throwException("SUV022",new Object[] {userName});
            }
        }else {
            DAOException.throwException("SUV022",new Object [] {userName});//input params are null
            logger.info("Null Input");// Exception to be added
        }
        logger.info("getReportRequest(String fromDate,String toDate,String username) method ends");
        return reportList;
}
    private class ViewStatusListExtractor implements ResultSetExtractor{
    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
    		List dataList = new ArrayList();
    		while(rs.next()){
	    		Map result=new HashMap();
    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
    			SimpleDateFormat sdf=new SimpleDateFormat();
    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
    			result.put("STATUS",rs.getString("STATUS"));
    			result.put("PARAM1",rs.getString("PARAM1"));
    			result.put("PARAM2",rs.getString("PARAM2"));
    			result.put("PARAM4",rs.getString("PARAM4"));
    			dataList.add(result);
    		}
    		return dataList;
    	}
    }
    
    /* Added for SB Collect Recon Report URD  06-10-14*/
    
    public List fetchAccountDetails(String corpId,String userName) throws DAOException {

        logger.debug("fetchAccountDetails(String username)" + LoggingConstants.METHODBEGIN);

        List accountDetails = null;
        if (userName != null && !(userName.trim()).equals("")) {
        	
    	//	Object params[] = {corpId,userName}; // 04-11-2014
        	Object params[] = {corpId};
    		try{
    			accountDetails = getJdbcTemplate().queryForList(FIND_CA_ACCOUNT_DETAILS,params);
    		}catch(DataAccessException daoexp){
    			logger.error("Exception occured: "+daoexp);
    			daoexp.printStackTrace();
    			DAOException.throwException(daoexp,"",params);
    		}
        }
        else {
        	logger.info("fetchAccountDetails method::: user name is null");
            DAOException.throwException("F001");
        }
        logger.debug("fetchAccountDetails(String username)" + LoggingConstants.METHODEND);
        return accountDetails;
    }

}
