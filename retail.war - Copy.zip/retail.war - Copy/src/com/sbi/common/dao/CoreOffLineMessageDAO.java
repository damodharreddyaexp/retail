//CR-1884 SN27223
package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

public interface CoreOffLineMessageDAO {

    List getCoreOffLineMessage(String bankCode, String role);
    	
    List getTickerMessage(Map inputParams);
	
} 
