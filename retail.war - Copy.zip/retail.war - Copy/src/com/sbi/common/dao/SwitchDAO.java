/*
 * SwitchDAO.java
 * Created on Oct 22, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 22, 2005 BOOPATHI - Initial Creation

package com.sbi.common.dao;

public interface SwitchDAO extends BankSystemDAO 
{

}
