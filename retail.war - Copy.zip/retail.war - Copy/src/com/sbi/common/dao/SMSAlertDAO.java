
/*
 * SMSAlertDAO.java
 * Created on Dec 31, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 31, 2005 KRISHNA KUMAR - Initial Creation
//Jan 19, 2006 MURUGAN K - method added

 
package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.SMSAlertSpec;

public interface SMSAlertDAO
{
    /**
     * Returns list of SMSAlertSpec objects by querying the table BV_ALERT_SPEC
     * 
     * Query : select * from BV_ALERT_SPEC where user_id in (select user_id from bv_user where user_alias=?)
     * 
     */
    public List findUserAlerts( String userName ) throws DAOException;
    
    
    /**
     * Insert a record into table BV_ALERT_SPEC using the values from the model object SMSAlertSpec.
     * 
     * Get jobid from the table BV_ALERTSCHED using the field SMSAlertSpec.alertName
     * 
     * select jobid from BV_ALERTSCHED where job_name = ?
     * 
     * Set the jobid in the SMSAlertSpec object.
     * 
     * Get the max(alert_id+1) for the user and alert_name from BV_ALERT_SPEC table. If table has zero records, set the alert_id as 1.
     * 
     * Set the alertId in the SMSAlertSpec object
     * 
     * insert into bv_alert_spec fields( user_id,alert_name,alert_id,dlvy_type,status,job_id,notif_freq,stringcol1,stringcol2,stringcol3,stringcol4,floatcol1) values(?,?,?,?,?,?,?,?,?,?,?,?)
     * 
     * On sucess return the SMSAlertSpec object.
     */
    public SMSAlertSpec insertAlertSpec( SMSAlertSpec alertSpec )throws DAOException;
    
    
    /**
     * Delete the alert record for the given user, nickName ,alertName,alertId from the table BV_ALERT_SPEC. 
     * 
     * Query : delete from BV_ALERT_SPEC where userid in (select user_id from bv_user where user_alias=?) and alertName=? and alertId=? and stringcol4=?
     */
    public SMSAlertSpec deleteAlertSpec( String userName, String nickName, String alertName, Integer alertId )throws DAOException;
   
    
    /**
     * Get the alert record for the given username and nickname.
     * 
     * Query : select * from bv_alert_spec where user_id in (select user_id from bv_user where user_alias=?) and stringcol4=?
     * 
     * Return SMSAlertSpect object
     */
    public SMSAlertSpec findAlertSpec( String userName, String nickName ) throws DAOException;
    
    /**
     * TODO Get the alert record for  the given username and alertname
     * @param userName
     * @param nickName
     * @return
     * @throws DAOException SMSAlertSpec
     */
    public SMSAlertSpec findAlertSpecByName(String userName, String alertName) throws DAOException;
//  Added by Venkatesh for CR 2403

    /**
     * TODO insert the sms details into sbi_system_alert_history table
     * @param mobileNo
     * @param message
     * @param bankCode
     * @param userName
     * @param userRole
     * @return
     * @throws DAOException SMSAlertSpec
     */
    public int insertSMSDetails(String mobileNo, String message,String bankCode,String userName,String userRole) throws DAOException;
    
   //CR 2403 - end
    
   //  Added for CR 248
	public int findRegisteredMobile(Integer userId) throws DAOException;
	 //End of CR 248
    
    
}

