package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CategoryDetails;
import com.sbi.common.model.FormControl;
import com.sbi.common.model.InstitutionDetails;
import com.sbi.common.model.SuvidhaPaymentDetails;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.model.CategoryPenalty;



public class SuvidhaMakePaymentDAOImpl extends JdbcDaoSupport implements SuvidhaMakePaymentDAO{


	protected final Logger logger = Logger.getLogger(getClass());
	
	
	private String SELECT_STATE_INSTITUTION_TYPE = "select distinct(state),INSTITUTE_TYPE,INSTITUTE_ID from sbi_institute_master where  status = 'Active' and approved_status = 'fullyapproved' order by state";
	
	//private String SELECT_INSTITUTIONS ="SELECT INSTITUTE_ID,CORP_NAME, INSTITUTE_NAME  FROM SBI_INSTITUTE_MASTER "+ 
	//" WHERE  STATE=? AND INSTITUTE_TYPE =? and STATUS = 'Active' and APPROVED_STATUS = 'approved' ORDER BY INSTITUTE_NAME ";
	
	//Queries Changed by marimuthu.
	
	private String SELECT_INSTITUTIONS = "SELECT A.INSTITUTE_ID,A.CORP_NAME, A.INSTITUTE_NAME, TRIM(B.CORPORATE_ADDRESS1 || ', ' || B.CORPORATE_ADDRESS2 || ', ' || B.CORPORATE_CITY || '-' || B.CORPORATE_PINCODE) ADDRESS " +  
    "FROM SBICORP_CORPORATE_PROFILE B,SBI_INSTITUTE_MASTER A WHERE  B.CORPORATE_ID = A.CORP_ID AND A.STATE= ? AND A.INSTITUTE_TYPE = ? and A.STATUS = 'Active' and "+
    "A.APPROVED_STATUS = 'fullyapproved' ORDER BY INSTITUTE_NAME ";
	
	private String SELECT_FEE_PAYMENT_DETAILS = "SELECT A.CORPORATE_ID,A.CORPORATE_NAME,B.INSTITUTE_ID,B.INSTITUTE_NAME,B.INSTITUTE_IMAGE_PATH, "+
	"TRIM(A.CORPORATE_ADDRESS1 || ', ' || A.CORPORATE_ADDRESS2 || ', ' || A.CORPORATE_CITY || '-' || A.CORPORATE_PINCODE) ADDRESS,B.APPROVED_STATUS " +
	"FROM SBICORP_CORPORATE_PROFILE A, SBI_INSTITUTE_MASTER B " +
	"WHERE  B.INSTITUTE_ID=? AND A.CORPORATE_ID = B.CORP_ID and B.STATUS = 'Active' and APPROVED_STATUS = 'fullyapproved'";
	
	private String SELECT_FEE_PAYMENT_DETAILS_OTHERROLES = "SELECT A.CORPORATE_ID,A.CORPORATE_NAME,B.INSTITUTE_ID,B.INSTITUTE_NAME,B.INSTITUTE_IMAGE_PATH, "+
	"TRIM(A.CORPORATE_ADDRESS1 || ', ' || A.CORPORATE_ADDRESS2 || ', ' || A.CORPORATE_CITY || '-' || A.CORPORATE_PINCODE) ADDRESS,B.APPROVED_STATUS " +
	"FROM SBICORP_CORPORATE_PROFILE A, SBI_INSTITUTE_MASTER B " +
	"WHERE  B.INSTITUTE_ID=? AND A.CORPORATE_ID = B.CORP_ID and B.STATUS = 'Active' ";


	private String SELECT_CATEGORIES = "SELECT INSTITUTE_ID, CATEGORY_ID, CATEGORY_NAME, ACCOUNT_NO, BRANCH_CODE,FEE_STRUC_DOC_PATH " +
			" FROM SBI_INSTITUTE_CATEGORY WHERE  INSTITUTE_ID=? and STATUS = 'Active' and APPROVED_STATUS='approved' and circle_approved_status = 'approved' and "+
			 "trunc(sysdate) between trunc(nvl(start_date,sysdate)) and trunc(nvl(last_date,sysdate))";
	
	private String SELECT_CATEGORIES_OTHERROLES = "SELECT INSTITUTE_ID, CATEGORY_ID, CATEGORY_NAME, ACCOUNT_NO, BRANCH_CODE,FEE_STRUC_DOC_PATH " +
	" FROM SBI_INSTITUTE_CATEGORY WHERE  INSTITUTE_ID=? and STATUS in ('Active','Inactive')";
	
	
	private String SELECT_CATEGORY_PARAMS = " SELECT CATEGORY_ID,OUTREF, PARAM_ID,PARAM_NAME,PARAM_TYPE, OPTION_VALUE,AMOUNT,MANDATORY, STATUS "+ 
											" FROM SBI_INSTITUTE_PARAM_DETAILS WHERE CATEGORY_ID = ? and STATUS = 'Active' order by description desc, display_order";
	//added for  SBcollect --uploader preview change 
	private String SELECT_CATEGORY_PARAMS_UPLOADER = " SELECT A.CATEGORY_ID,OUTREF, PARAM_ID,PARAM_NAME,decode(user_display_order_seq,'999',decode(param_type,'Options','naoptions','natext'),param_type) PARAM_TYPE,DESCRIPTION, OPTION_VALUE,AMOUNT,MANDATORY, A.STATUS " +    
	" FROM SBI_INSTITUTE_PARAM_DETAILS a WHERE A.CATEGORY_ID = ?  and A.STATUS = 'Active' order by user_display_order_seq asc,param_name asc ";
	
	// Modified query for iCollect File Mode changes  
	private String SELECT_CATEGORY_PARAMS_FILEMODE = " SELECT CATEGORY_ID,OUTREF, PARAM_ID,PARAM_NAME,PARAM_TYPE, OPTION_VALUE,AMOUNT,MANDATORY, STATUS,description,display_order, user_display_order_seq " +
	" FROM SBI_INSTITUTE_PARAM_DETAILS WHERE CATEGORY_ID = ? and STATUS = 'Active' " +
	" order by user_display_order_seq asc,param_name asc ";
	 
	
	private static final String GET_PAYMENT_DETAILS = 	"SELECT a.echeque_no, a.reference_no, a.echeque_amount, a.echeque_date,b.institute_name, a.debit_status  "+
	"FROM sbicorp_echeque_master a, sbi_institute_master b WHERE a.maker = ? AND a.echeque_date BETWEEN TO_DATE(?,'dd/mm/yyyy') AND TO_DATE(?,'dd/mm/yyyy') + .99999 "+
	"AND a.supplier_id = b.institute_id AND substr(echeque_no,1,2) = 'IU' order by a.echeque_no desc";
	
	private static final String PARAM_DETAILS ="select outref,param_name from SBI_INSTITUTE_PARAM_DETAILS where  status ='Active' AND CATEGORY_ID=? ";
	
	private static final String GET_COMM_DETAILS = "SELECT COMM_REQD,RECOVERED_FROM from SBI_INSTITUTE_MASTER WHERE INSTITUTE_ID = ? ";
	
	//Parameshwaran : Added for iCollect File Mode changes.
	private static final String SELECT_FILE_MODE_RECORDS="select RECORDS from SBI_ICOLLECT_PARAM_KEY where FILE_TYPE = 'ICM' "+
	" and FILE_NAME IN (select SNO from SBI_FILE_MASTER where FILETYPE ='ICM' and ADDITIONAL_FIELD4=? and SNO = ? )";
	
	private String AMOUNT_VALIDATION="(^(\\d{1,8})(\\.[0-9][0-9])?$)";
	private String TEXT_VALIDATION="(^[0-9a-zA-Z&_. /]{1,30}$)";
	
	private String DATE_VALIDATION_DDMMYYY="^([1-9]|[12][0-9]|3[01])[- /.]([1-9]|1[012])[- /.](19|20)\\d\\d$";
	private String DATE_VALIDATION_MMDDYYY="^([1-9]|1[012])[- /.]([1-9]|[12][0-9]|3[01])[- /.](19|20)\\d\\d$";
	//IcOLLECT pENALTY
	private static final String FIND_PENALTY_DETAILS = "select a.PENALTY_FROM_DATE,a.PENALTY_TO_DATE,a.AMOUNT_TYPE,a.AMOUNT,a.PENALTY_ORDER from sbi_icollect_penalty a, SBI_INSTITUTE_CATEGORY b where a.category_id=b.category_id and a.category_id=? and a.penalty_status='Active' ";
	//iCollect penalty Ends
	private static final String INCREMENTAL_CATEGORY="SELECT DISTINCT(A.CATEGORY_ID),A.CATEGORY_NAME,A.INSTITUTE_ID FROM SBI_INSTITUTE_CATEGORY A,SBI_FILE_MASTER B " +
													 "WHERE A.FILE_STATUS='ACTUAL_RETAIL_READY' AND  A.FILE_MODE='Y' AND A.STATUS='Active' AND " +
													 "A.INSTITUTE_ID=(SELECT INSTITUTE_ID FROM SBI_INSTITUTE_MASTER WHERE CORP_ID=? AND STATUS='Active' AND APPROVED_STATUS='fullyapproved') " +
													 "AND A.APPROVED_STATUS='approved' AND A.CIRCLE_APPROVED_STATUS='approved' AND " +
													 "TRUNC(SYSDATE) BETWEEN TRUNC(NVL(A.START_DATE,SYSDATE)) AND TRUNC(NVL(A.LAST_DATE,SYSDATE))";
	
	private static final String SELECT_EXISTING_CATEGORIES="select distinct(a.file_name),b.category_name ,c.file_status  from " +
														   "sbi_icollect_param_key a, sbi_institute_category b, sbi_file_master c " +
														   "where a.FILE_TYPE = 'ICM' AND a.category_id=b.category_id AND b.file_status='ACTUAL_RETAIL_READY'" +
														   "AND b.file_mode='Y' AND a.status='Processed'AND a.file_name=c.sno AND c.filetype='ICM'  " +
														   "AND c.additional_field5='icollect'and a.category_id=?";
	private String SELECT_STATE_INSTITUTION_CORP_TYPE = "select distinct c.state,a.INSTITUTE_TYPE from bvsbi.sbi_institute_master a,bvsbi.sbicorp_corporate_profile b , "+
			"bvsbi.sbi_institute_category c where a.status = 'Active' and a.approved_status = 'fullyapproved' and c.circle_approved_status='approved' and c.approved_status='approved' and "+
			"c.institute_id=a.institute_id and a.corp_id = b.corporate_id  and  substr(c.branch_code,1,1) in ('0','A','3','6') order by c.state,a.INSTITUTE_TYPE";
	
	private String SUVIDHA_SELECT_INSTITUTIONS =  "SELECT distinct A.INSTITUTE_ID,A.CORP_NAME, A.INSTITUTE_NAME, TRIM(B.CORPORATE_ADDRESS1 || ',' || B.CORPORATE_ADDRESS2 || ', ' || B.CORPORATE_CITY || '-' || B.CORPORATE_PINCODE) ADDRESS "+ 
			"FROM SBICORP_CORPORATE_PROFILE B,SBI_INSTITUTE_MASTER A , sbi_institute_category c WHERE B.CORPORATE_ID = A.CORP_ID AND  c.state=? and  c.institute_id=a.institute_id and A.INSTITUTE_TYPE = ? and A.STATUS = 'Active' and A.APPROVED_STATUS = 'fullyapproved' "+ 
			"and c.circle_approved_status='approved' and substr(c.branch_code,1,1) in ('0','A','3','6') ORDER BY INSTITUTE_NAME";
	private String SUVIDHA_SELECT_CORPARATE="SELECT CORP_ID FROM SBI_INSTITUTE_MASTER WHERE INSTITUTE_ID=?";
	
	private String ENABLE_INSTITUTE="Insert into SBI_PRELOGIN_CORPORATE_MAP (INSTITUTE_ID,CORP_ID,INSTITUTE_NAME,USER_NAME,STATUS,STATE,INSTITUTE_TYPE,CREATION_TIME,LAST_MOD_TIME,ADMIN_CORP_ID) values (?,?,?,?,?,?,?,sysdate,sysdate,?)";
	
	private String RETERIEVE_ACTIVE_INSTITUTE="SELECT distinct A.INSTITUTE_ID,A.CORP_NAME, A.INSTITUTE_NAME, TRIM(B.CORPORATE_ADDRESS1 || ',' || B.CORPORATE_ADDRESS2 || ', ' || B.CORPORATE_CITY || '-' || B.CORPORATE_PINCODE) ADDRESS FROM SBICORP_CORPORATE_PROFILE B," +
											  "SBI_INSTITUTE_MASTER A,SBI_INSTITUTE_CATEGORY C,SBI_PRELOGIN_CORPORATE_MAP D WHERE B.CORPORATE_ID = A.CORP_ID AND C.INSTITUTE_ID=A.INSTITUTE_ID AND A.INSTITUTE_ID=D.INSTITUTE_ID AND C.STATE=D.STATE AND  D.STATUS='0' AND " +
											  "D.STATE=? AND A.INSTITUTE_TYPE =? AND A.STATUS = 'Active' AND A.APPROVED_STATUS = 'fullyapproved' AND C.CIRCLE_APPROVED_STATUS='approved' AND D.USER_NAME=? AND SUBSTR(C.BRANCH_CODE,1,1) in ('0','A','3','6') ORDER BY INSTITUTE_NAME";
	
	private String RETERIEVE_ENABLED_INSTITUTE="SELECT * FROM SBI_PRELOGIN_CORPORATE_MAP WHERE USER_NAME=? AND STATUS='0' order by STATE asc";
	private String DISABLE_INSTITUTE="UPDATE SBI_PRELOGIN_CORPORATE_MAP SET STATUS='1',LAST_MOD_TIME=SYSDATE WHERE INSTITUTE_ID=? AND USER_NAME=? ";
	
	private String REENABLE_INSTITUTE="UPDATE SBI_PRELOGIN_CORPORATE_MAP SET STATUS='0',LAST_MOD_TIME=SYSDATE WHERE INSTITUTE_ID=? AND USER_NAME=?";
	
	private String RETERIEVE_EXIST_ENABLED_INSTITUTE="SELECT STATUS FROM SBI_PRELOGIN_CORPORATE_MAP WHERE INSTITUTE_ID=? and user_name=? ";
	
	private String RETERIEVE_PENING_ECHEQUES="select /*+ ordered */ count(*) from bvsbi.sbicorp_bulk_inbox l,bvsbi.sbicorp_echeque_master b,bvsbi.sbi_prelogin_echeque_master a,bvsbi.sbi_prelogin_corporate_map c,bvsbi.sbicorp_ca_account_map d " +
											 "where l.echeque_no like 'CH%' and b.echeque_no = l.echeque_no and b.merchant_code='SBCOLLECT' and b.current_auth_level in('1','2','-5') and b.corp_ref_no=a.echeque_no and a.narrative1=c.institute_id " +
											 "and a.online_debit_status='P' and d.corporateid=c.admin_corp_id  and d.ca_user=c.user_name  and c.institute_id=? and c.user_name=? and c.status='0'";
	
	public List retrieveStateInstitutionType() throws DAOException{
		if(logger.isDebugEnabled())
		logger.debug("retrieveStateInstitutionType () begins");
		List stateinstitutionList= new ArrayList();
		
			try {
			
			stateinstitutionList = (List)getJdbcTemplate().query(SELECT_STATE_INSTITUTION_TYPE,new StateInstitutionTypeRowMapper());
	
			logger.info("state wise institution List size:"+ stateinstitutionList.size());
			if(logger.isDebugEnabled())
				logger.debug("state wise institution List:"+stateinstitutionList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
		
		if(logger.isDebugEnabled())
		logger.debug("retrieveStateInstitutionType () ends");
		
		return stateinstitutionList;	
	}
	public List suvidhaRetrieveStateInstitutionType(String bankCode) throws DAOException{
		if(logger.isDebugEnabled())
		logger.debug("suvidhaRetrieveStateInstitutionType () begins");
		List stateinstitutionList= new ArrayList();
		Object[] param={};
			try {
			
			stateinstitutionList = (List)getJdbcTemplate().query(SELECT_STATE_INSTITUTION_CORP_TYPE,param,new StateInstitutionTypeRowMapper());
			
			logger.info("state wise institution List size:"+ stateinstitutionList.size());
			if(logger.isDebugEnabled())
				logger.debug("state wise institution List:"+stateinstitutionList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
		
		if(logger.isDebugEnabled())
		logger.debug("suvidhaRetrieveStateInstitutionType () ends");
		
		return stateinstitutionList;	
	}
	
	public List retrieveInstitutions(String state,String instType) throws DAOException{
		if(logger.isDebugEnabled())
		logger.debug("retrieveInstitutions (String state,String instType) -  beginss");
		List institutionsList= new ArrayList();
		Object[] inparam={state,instType};
		
			try {
			
			institutionsList = (List)getJdbcTemplate().queryForList(SELECT_INSTITUTIONS,inparam);
			logger.info("institutions List(for the selected state and type) size:"+ institutionsList.size());
			if(logger.isDebugEnabled())
				logger.debug("institutions List(for the selected state and type):"+institutionsList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
			if(logger.isDebugEnabled())
				logger.debug("retrieveInstitutions (String state,String instType) ends");
		
		return institutionsList;	
	}	
	
	public List retrieveFeePaymentDetails(String instID,String userRole) throws DAOException {
		if(logger.isDebugEnabled())
		logger.debug("retrieveFeePaymentDetails (String instID,String userRole) begins");
		List institutionsList= new ArrayList();
		Object[] inparam={instID};
		
			try {
				if(userRole!=null && userRole.equalsIgnoreCase("1"))
					institutionsList = (List)getJdbcTemplate().query(SELECT_FEE_PAYMENT_DETAILS,inparam, new FeePaymentDetailsRowMapper());
				else
					institutionsList = (List)getJdbcTemplate().query(SELECT_FEE_PAYMENT_DETAILS_OTHERROLES,inparam, new FeePaymentDetailsRowMapper());
				logger.info("Fee Payment Details List size for the selected category:"+ institutionsList.size());
			if(logger.isDebugEnabled())
				logger.debug("Fee Payment Details List for the selected category:"+ institutionsList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
		
			if(logger.isDebugEnabled())
				logger.debug("retrieveFeePaymentDetails (String instID,String userRole) ends");
		
		return institutionsList;	
	}

	public List retrieveCategories(String instID,String userRole) throws DAOException {
		if(logger.isDebugEnabled())
		logger.debug("retrieveCategories (String instID,String userRole) begins");
		List categoryList= new ArrayList();
		Object[] inparam={instID};
		
			try {
				if(userRole!=null && userRole.equalsIgnoreCase("1"))
					categoryList = (List)getJdbcTemplate().query(SELECT_CATEGORIES,inparam, new CategoryRowMapper());				
				else
					categoryList = (List)getJdbcTemplate().query(SELECT_CATEGORIES_OTHERROLES,inparam, new CategoryRowMapper());
					
			logger.info("category params List(for the selected institutiton) size :"+ categoryList.size());
			if(logger.isDebugEnabled())
				logger.debug("category params List(for the selected institutiton) :"+categoryList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
			if(logger.isDebugEnabled())
				logger.debug("retrieveCategories (String instID,String userRole) ends");
		
		return categoryList;
		
	}
	
	public List retrieveCategoryParams(String categoryId) throws DAOException{
		if(logger.isDebugEnabled())
		logger.debug("retrieveCategoryParams(String categoryID) begins");
		List categoryList= new ArrayList();
		logger.info("corporateId-daoimpl"+categoryId);
		Object[] inparam={categoryId};
		
			try {
			
			categoryList = (List)getJdbcTemplate().query(SELECT_CATEGORY_PARAMS,inparam, new ControlTypeRowMapper());
			logger.info("category params(outref values) list size :"+ categoryList.size());
			if(logger.isDebugEnabled())
				logger.debug("category params(outref values) list:"+categoryList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
			if(logger.isDebugEnabled())
				logger.debug("retrieveCategoryParams(String categoryID) ends");
		
		return categoryList;
	}
	//Added for SB collect uploader preview change
	public List retrieveCategoryParamsUploader(String categoryId) throws DAOException{
		if(logger.isDebugEnabled())
		logger.debug("retrieveCategoryParamsUploader(String categoryID) begins");
		List categoryList= new ArrayList();
			logger.info("corporateId-daoimpl"+categoryId);
		    Object[] inparam={categoryId};
		
			try {
			
			categoryList = (List)getJdbcTemplate().query(SELECT_CATEGORY_PARAMS_UPLOADER,inparam, new ControlTypeRowMapper());
			logger.info("category params(outref values) list size :"+ categoryList.size());
			if(logger.isDebugEnabled())
				logger.debug("category params(outref values) list:"+categoryList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				 DAOException.throwException("SUV001", dataAccessException);
			}
			if(logger.isDebugEnabled())
				logger.debug("retrieveCategoryParamsUploader(String categoryID) ends");
		
		return categoryList;
	}
//iCollect Penalty Starts
	
	public List findPenaltyDetails(String categoryId) throws DAOException {
		logger.debug(" findPenaltyDetails(String instId) method begin");
		List penaltyDetails = null;
		logger.info("category id:::"+categoryId);
		Object params[] = {categoryId};
		try{
			penaltyDetails = (List)getJdbcTemplate().query(FIND_PENALTY_DETAILS,params,new CategoryPenaltyDetailsRowmapper());
			if(penaltyDetails != null)
				logger.info("penaltyDetails size: "+penaltyDetails.size());
		}catch(DataAccessException daoexp){
			logger.error("Exception occured: "+daoexp);
			daoexp.printStackTrace();
			DAOException.throwException(daoexp,"",params);
		}
		logger.debug(" findPenaltyDetails(String instId) method end");
		return penaltyDetails;
	}
	
    class CategoryPenaltyDetailsRowmapper implements RowMapper {
    	//List penaltyDetailsList = new ArrayList();
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            CategoryPenalty penaltyDetailsCatg = new CategoryPenalty();
            List penaltyDetailsList = new ArrayList();
            penaltyDetailsCatg.setFromDate(rs.getDate("PENALTY_FROM_DATE"));
            penaltyDetailsCatg.setToDate(rs.getDate("PENALTY_TO_DATE"));
            penaltyDetailsCatg.setPenaltyOrder(rs.getInt("PENALTY_ORDER"));
            penaltyDetailsCatg.setPenaltyAmtType(rs.getString("AMOUNT_TYPE"));
            penaltyDetailsCatg.setPenaltyAmount(rs.getInt("AMOUNT"));
            penaltyDetailsList.add(penaltyDetailsCatg);
            return penaltyDetailsList;
        } 
    }

	//iCollect Penalty Ends
	
	public List findSuvidhaPaymentDetails(String userName, String fromDate, String toDate) {
		
		if(logger.isDebugEnabled())
		logger.debug("findSuvidhaPaymentDetails method begins");
		List paymentList = new ArrayList();	
		Timestamp startDate = null;
		Timestamp endDate = null;
		if (userName != null && fromDate != null && toDate != null)
			{			
			startDate=StringUtils.stringToTimestamp(fromDate);
			endDate=StringUtils.stringToTimestamp(toDate);
			if(logger.isDebugEnabled())
			{
			logger.debug("startDate"+startDate);
			logger.debug("endDate"+endDate);
			}
			logger.info("Before Converting:"+fromDate+":"+toDate);
			logger.info("After Converting:"+startDate+":"+endDate);			
			try
			{
			Object params[] = {userName,fromDate,toDate};
			paymentList=getJdbcTemplate().query(GET_PAYMENT_DETAILS, params,
					new paymentDetailsRowMapper());		
			logger.info("paymentList size:"+paymentList.size());
			if(logger.isDebugEnabled())
				logger.debug("paymentList:"+paymentList);
			
			}catch (DataAccessException dataAccessException) {
				logger.error("Exception occured :" + dataAccessException);
				DAOException.throwException("SUV001");
			}
		 
		 }else
			DAOException.throwException("SUV002");
		if(logger.isDebugEnabled())
		logger.debug("findSuvidhaPaymentDetails method ends");
		return paymentList;	
	}   
	
	 public Map findsuvidhaParamDetails(String categoryId) 
	    {
		 if(logger.isDebugEnabled())
		 logger.debug("findsuvidhaParamDetails( String categoryId ) method begin");
	        Map paramDetailsMap=null;
	        
	        if (categoryId != null)
	        {                
	            try
	            {	            	
	                Object params[]={categoryId};               
	                paramDetailsMap=(Map)getJdbcTemplate().query(PARAM_DETAILS,params,new suvidhaParamDetailsExtractor());
	                
	                logger.info("paramDetailsMap size:"+paramDetailsMap.size());
	                
	                if(logger.isDebugEnabled())
	                	logger.debug("paramDetailsMap:"+paramDetailsMap);
	            
	        	}catch (DataAccessException dataAccessException) {
				logger.error("Exception occured :" + dataAccessException);
				DAOException.throwException("SUV001");
	        	}      
	        }
	        else
				DAOException.throwException("SUV002");
	            
	        if(logger.isDebugEnabled())
	        logger.debug("findsuvidhaParamDetails( String categoryId ) method ends");
	        return paramDetailsMap;
	        
	    }
	 public Map  getServiceChargeDetails(String instituteId)
	 {
		 if(logger.isDebugEnabled())
			 logger.debug("getServiceChargeDetails( String instituteId ) method begin");
		        Map serviceChargeMap=null;
		        
		        if (instituteId != null)
		        {                
		            try
		            {	            	
		                Object params[]={instituteId};               
		                serviceChargeMap = getJdbcTemplate().queryForMap(GET_COMM_DETAILS,params);
		                
		                logger.info("serviceChargeMap size:"+serviceChargeMap.size());
		                
		                if(logger.isDebugEnabled())
		                	logger.debug("serviceChargeMap:"+serviceChargeMap);
		            
		        	}catch (DataAccessException dataAccessException) {
					logger.error("Exception occured :" + dataAccessException);
					DAOException.throwException("SUV001");
		        	}      
		        }
		        else
					DAOException.throwException("SUV002");
		            
		        if(logger.isDebugEnabled())
		        logger.debug("getServiceChargeDetails( String instituteId ) method ends");
		        return serviceChargeMap; 
	 }
	 
	 // Parameshwaran : Added for iCollect File Mode changes
	 public String retrieveFileModeCategoryParamValues(String categoryID,String serialNumber) {
			logger.info("retrieveFileModeCategoryParamValues(String categoryID, String registerNo) begins");
			logger.info("categoryID : " + categoryID);
			String records = "";
			Object[] inparam = { categoryID, serialNumber };
			try {
				List list = getJdbcTemplate().queryForList(SELECT_FILE_MODE_RECORDS, inparam);
				records = (String)((Map)(list.get(0))).get("RECORDS");
				logger.info("Records : " + records);
			} catch (DataAccessException dataAccessException) {
				logger.error("Exception occured :" + dataAccessException);
				DAOException.throwException("SUV001");
				// DAOException.throwException("SUV010", dataAccessException);
			} catch (DAOException incorrectResultSizeDataAccessException) {
				logger.error("Exception occured :"
						+ incorrectResultSizeDataAccessException);
				// DAOException.throwException("SUV010",
				// incorrectResultSizeDataAccessException);
			}
			logger.info("retrieveFileModeCategoryParamValues(String categoryID, String registerNo) ends");
			return records;
		}
	 
private class StateInstitutionTypeRowMapper implements RowMapper {
		
		
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			
			InstitutionDetails institution = new InstitutionDetails();
			
			institution.setState(rs.getString("STATE"));
			institution.setInstitutionType(rs.getString("INSTITUTE_TYPE"));
			institution.setInstituteId("INSTITUTE_ID");
		
			return institution;
		}
	}


private class FeePaymentDetailsRowMapper implements RowMapper {
	
	
	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
		
		InstitutionDetails institution = new InstitutionDetails();
		
		institution.setCorpID(rs.getString("CORPORATE_ID"));
		institution.setCorpName(rs.getString("CORPORATE_NAME"));
		institution.setInstituteId(rs.getString("INSTITUTE_ID"));		
		institution.setInstitutionName(rs.getString("INSTITUTE_NAME"));
		institution.setLogoPath(rs.getString("INSTITUTE_IMAGE_PATH"));
		institution.setAddress(rs.getString("ADDRESS"));
		institution.setStatus(rs.getString("APPROVED_STATUS"));
	
		return institution;
	}
}

private class CategoryRowMapper implements RowMapper {
	
	
	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
		
		CategoryDetails categories = new CategoryDetails();
	
		categories.setCategoryID(rs.getString("CATEGORY_ID"));
		categories.setCategoryName(rs.getString("CATEGORY_NAME"));
		categories.setInstituteId(rs.getString("INSTITUTE_ID"));		
		categories.setAccountNo(rs.getString("ACCOUNT_NO"));
		categories.setBranchCode(rs.getString("BRANCH_CODE"));
		categories.setDocPath(rs.getString("FEE_STRUC_DOC_PATH"));
		return categories;
	}
}

class ControlTypeRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int index) throws SQLException {
    	
        FormControl controlType = new FormControl();
        controlType.setLabel(rs.getString("PARAM_NAME"));
        controlType.setControlType(rs.getString("PARAM_TYPE"));
        controlType.setRequestVarname(rs.getString("OUTREF"));
        
        if("Fixed".equalsIgnoreCase(rs.getString("PARAM_TYPE")) || "Variable".equalsIgnoreCase(rs.getString("PARAM_TYPE"))|| "Option".equalsIgnoreCase(rs.getString("PARAM_TYPE"))){ 
        	controlType.setFieldSize(new Integer(10));
        }else{
        	controlType.setFieldSize(new Integer(30));	
        }
        if(rs.getString("MANDATORY")!=null && rs.getString("MANDATORY").equalsIgnoreCase("Y"))        
        	controlType.setMandatory("0");        
        else        
        	controlType.setMandatory("S");
        
        String optionValues = rs.getString("OPTION_VALUE");
        
        Map controlValues=new LinkedHashMap();
        if(optionValues!=null){
            StringTokenizer st = new StringTokenizer(optionValues,",");
            int i=0;
            while( st.hasMoreTokens() ) {
            	controlValues.put("controlValues"+i,st.nextToken());
            	i++;
            }
        }
        
        controlType.setControlValues(controlValues);
        String defaultValue=rs.getString("AMOUNT");
        String defVal="";
        if (defaultValue!=null)
        {    
            controlType.setDefaultValue(defaultValue);
        }
        else
        {
            controlType.setDefaultValue(defVal);
        }
       
        if(controlType.getControlType()!=null && 
        		( controlType.getControlType().equalsIgnoreCase("fixed") || 
        				controlType.getControlType().equalsIgnoreCase("Variable") ) ) {
        	
        	if((controlType.getControlType().equalsIgnoreCase("fixed") && controlType.getMandatory().equalsIgnoreCase("0")) || controlType.getControlType().equalsIgnoreCase("variable"))
        	{
	        	controlType.setErrorMessage(controlType.getLabel() + " Should be valid amount");
	            controlType.setFormat(AMOUNT_VALIDATION);
        	}
        	else if(controlType.getControlType().equalsIgnoreCase("fixed") && !controlType.getMandatory().equalsIgnoreCase("0"))
        	{
        		controlType.setErrorMessage(controlType.getLabel() + " should be equal to "+controlType.getDefaultValue()+" or Zero");
                controlType.setFormat("^(0|"+controlType.getDefaultValue()+")$");
        	}
          
           
            
        }else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("text") ) {
        	
        	controlType.setErrorMessage(controlType.getLabel() + " Should be valid.");
            controlType.setFormat(TEXT_VALIDATION);
            
        	
        }
        else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("Date")){
        	if("ddmmyyyy".equalsIgnoreCase(optionValues))
        	{
    	    
        		controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
    		 	controlType.setFormat(DATE_VALIDATION_DDMMYYY);
        	}
    		else
    		{
    			controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
        		controlType.setFormat(DATE_VALIDATION_MMDDYYY);
    		}
    			
    		
    	}
        /*else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("date"))
        {
        	controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
    		controlType.setFormat(optionValues);
        }*/
        else if(controlType.getControlType()!=null /*&& "S".equals(controlType.getMandatory())*/&& controlType.getControlType().equalsIgnoreCase("natext") ){
        	logger.info("test natext");
        		String nonFileModeParamType=rs.getString("DESCRIPTION");
        		controlType.setFormat(AMOUNT_VALIDATION);
        		controlType.setErrorMessage(controlType.getLabel() + " Should be valid amount");
        		if(nonFileModeParamType !=null && "PARAMETER".equals(nonFileModeParamType)){
        			controlType.setFormat(TEXT_VALIDATION);
        			controlType.setErrorMessage(controlType.getLabel() + " Should be valid.");
        		}
        }
        return controlType;
    }
  }


class paymentDetailsRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int index) throws SQLException {
        SuvidhaPaymentDetails paymentDetails = new SuvidhaPaymentDetails();                
        paymentDetails.setRefenceNo(rs.getString("REFERENCE_NO"));
        paymentDetails.setAmount(new Double(rs.getDouble("ECHEQUE_AMOUNT")));
        paymentDetails.setInstituteName(rs.getString("INSTITUTE_NAME"));
        paymentDetails.setTransactionDate(rs.getTimestamp("ECHEQUE_DATE"));
        paymentDetails.setStatus(rs.getString("DEBIT_STATUS"));
        return paymentDetails;
    }
}

class suvidhaParamDetailsExtractor implements ResultSetExtractor{

	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map result=new HashMap();
		while(rs.next())			
		{
			result.put(rs.getString("outref"),rs.getString("param_name"));            				
		}
		return result;
	}
	
}
//show notification details - Imman


public Map getDescriptionDetails(String categoryID) {
	if(logger.isDebugEnabled())
		logger.debug("getDescriptionDetails(String categoryID, String registerNo) begins");
		Map descDetails =  new HashMap();
		Object[] inparamdesc={categoryID};
		
			try {	
				descDetails = getJdbcTemplate().queryForMap("select description1, description2 from SBI_INSTITUTE_CATEGORY WHERE category_id=?",inparamdesc);
				logger.info("iCollect Description NOTE details :"+ descDetails);				
			}
			catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				DAOException.throwException("SUV001");
			}catch(DAOException incorrectResultSizeDataAccessException) {
				logger.error("Exception occured :"+incorrectResultSizeDataAccessException);
			}
			if(logger.isDebugEnabled()){
				logger.debug("getDescriptionDetails(String categoryID, String registerNo) ends");
			}
		
		return descDetails;
	}
//show notification details Ends- Imman

public List retrieveFileModeCategoryParams(String categoryID) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("retrieveCategoryParams(String categoryID) begins");
	List categoryList= new ArrayList();
	Object[] inparam={categoryID};
	
		try {
		
		categoryList = (List)getJdbcTemplate().query(SELECT_CATEGORY_PARAMS_FILEMODE,inparam, new FileModeControlTypeRowMapper());
		logger.info("category params(outref values) list size :"+ categoryList.size());
		if(logger.isDebugEnabled())
			logger.debug("category params(outref values) list:"+categoryList);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("retrieveCategoryParams(String categoryID) ends");
	
	return categoryList;
}

class FileModeControlTypeRowMapper  implements RowMapper  {
	public Object mapRow(ResultSet rs, int index) throws SQLException {
		
		FormControl controlType = new FormControl();
		controlType.setLabel(rs.getString("PARAM_NAME"));
		controlType.setControlType(rs.getString("PARAM_TYPE"));
		controlType.setRequestVarname(rs.getString("OUTREF"));
		if("Fixed".equalsIgnoreCase(rs.getString("PARAM_TYPE")) || "Variable".equalsIgnoreCase(rs.getString("PARAM_TYPE"))){ 
			controlType.setFieldSize(new Integer(10));
		}else{
			controlType.setFieldSize(new Integer(30));	
		}
		if(rs.getString("MANDATORY")!=null && rs.getString("MANDATORY").equalsIgnoreCase("Y"))        
			controlType.setMandatory("0");        
		else        
			controlType.setMandatory("1");
		
		String optionValues = rs.getString("OPTION_VALUE");
		
		Map controlValues=new LinkedHashMap();
		if(optionValues!=null){
			StringTokenizer st = new StringTokenizer(optionValues,",");
			int i=0;
			while( st.hasMoreTokens() ) {
				controlValues.put("controlValues"+i,st.nextToken());
				i++;
			}
		}
		
		controlType.setControlValues(controlValues);
		String defaultValue=rs.getString("AMOUNT");
		String defVal="";
		if (defaultValue!=null)
		{    
			controlType.setDefaultValue(defaultValue);
		}
		else
		{
			controlType.setDefaultValue(defVal);
		}
		
		if(controlType.getControlType()!=null && 
				( controlType.getControlType().equalsIgnoreCase("fixed") || 
						controlType.getControlType().equalsIgnoreCase("Variable") ) ) {
			
			if((controlType.getControlType().equalsIgnoreCase("fixed") && controlType.getMandatory().equalsIgnoreCase("0")) || controlType.getControlType().equalsIgnoreCase("variable"))
			{
				controlType.setErrorMessage(controlType.getLabel() + " Should Be Numeric");
				controlType.setFormat(AMOUNT_VALIDATION);
			}
			else if(controlType.getControlType().equalsIgnoreCase("fixed") && !controlType.getMandatory().equalsIgnoreCase("0"))
			{
				controlType.setErrorMessage(controlType.getLabel() + " should be equal to "+controlType.getDefaultValue()+" or empty");
				controlType.setFormat("^("+controlType.getDefaultValue()+")$");
			}
			
			
			
		}else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("text") ) {
			
			controlType.setErrorMessage(controlType.getLabel() + " Should Be AlphaNumeric");
			controlType.setFormat(TEXT_VALIDATION);
		}
		
		//Added by N/A value display in display params	
		controlType.setExceptionCode(rs.getString("USER_DISPLAY_ORDER_SEQ"));
		
		
		return controlType;
	}
}
public List retrieveIncrementalCategorys(String corporateId) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("retrieveIncrementalCategorys(String categoryID) begins");
	logger.info("DAOImpl-corporateId="+corporateId);
	List categoryList= new ArrayList();
	Object[] inparam={corporateId};
	try {
		categoryList = (List)getJdbcTemplate().query(INCREMENTAL_CATEGORY,inparam,new ExistingCategoryRowMapper());
		logger.info("IncrementalCategorys list size :"+ categoryList.size());
		if(logger.isDebugEnabled())
			logger.debug("IncrementalCategorys list:"+categoryList);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("retrieveIncrementalCategorys(String categoryID) ends");
	
	return categoryList;
}
public List retrieveInstitutions(String state,String instType,String bankCode) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("retrieveInstitutions (String state,String instType) -  beginss");
	logger.info("retrieveInstitutions (String state,String instType) -  begins:::state::"+state+"instType::"+instType+"bankCode::"+bankCode);
	List institutionsList= new ArrayList();
	Object[] inparam={state,instType};
	
		try {
		
		institutionsList = (List)getJdbcTemplate().queryForList(SUVIDHA_SELECT_INSTITUTIONS,inparam);
		logger.info("institutions List(for the selected state and type) size:"+ institutionsList.size());
		if(logger.isDebugEnabled())
			logger.debug("institutions List(for the selected state and type):"+institutionsList);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("retrieveInstitutions (String state,String instType) ends");
	
	return institutionsList;	
}	
public String suvidhaRetrieveCorprate(String instituteId) {
	logger.info("suvidhaRetrieveCorprate(String instituteId)");
	logger.info("instituteId : " + instituteId);
	String corporateId = "";
	Object[] inparam = { instituteId};
	try {
			corporateId = (String)getJdbcTemplate().queryForObject(SUVIDHA_SELECT_CORPARATE, inparam, String.class);
			logger.info("corporateId : " + corporateId);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :" + dataAccessException);
			DAOException.throwException("SUV001");
		} 
	logger.info("suvidhaRetrieveCorprate(String instituteId) ends");
	return corporateId;
}
public int suvidhaEnableInstitutes(String INSTITUTE_ID, String CORP_ID,String INSTITUTE_NAME,String USER_NAME,String STATUS,String STATE,String INSTITUTE_TYPE,String ADMIN_CORP_ID) {
	logger.info("suvidhaRetrieveCorprate(String instituteId)");
	logger.info("instituteId : " + INSTITUTE_ID);
	int insRows=0;
	Object[] inparam = { INSTITUTE_ID,CORP_ID,INSTITUTE_NAME,USER_NAME,STATUS,STATE,INSTITUTE_TYPE,ADMIN_CORP_ID};
	int []argTypes={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	try {
			insRows=getJdbcTemplate().update(ENABLE_INSTITUTE, inparam, argTypes);
			logger.info("corporateId : " + insRows);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :" + dataAccessException);
			DAOException.throwException("SUV001");
		} 
	logger.info("suvidhaRetrieveCorprate(String instituteId) ends");
	return insRows;
}
public List suvidhaRetrieveEnabledInstitutions(String state,String instType,String userName) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("suvidhaRetrieveEnabledInstitutions(String state,String instType,String userName) -  beginss");
	List institutionsList= new ArrayList();
	Object[] inparam={state,instType,userName};
	
		try {
		
		institutionsList = (List)getJdbcTemplate().queryForList(RETERIEVE_ACTIVE_INSTITUTE,inparam);
		logger.info("institutions List(for the selected state and type) size:"+ institutionsList.size());
		if(logger.isDebugEnabled())
			logger.debug("institutions List(for the selected state and type):"+institutionsList);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("suvidhaRetrieveEnabledInstitutions(String state,String instType,String userName) ends");
	
	return institutionsList;	
}
public List suvidhaRetrieveEnabledInstitutionType(String USER_NAME) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("suvidhaRetrieveEnabledInstitutionType(String USER_NAME) -  beginss");
	List institutionsList= new ArrayList();
	Object[] inparam={USER_NAME};
	
		try {
		
		institutionsList = (List)getJdbcTemplate().queryForList(RETERIEVE_ENABLED_INSTITUTE,inparam);
		logger.info("institutions List(for the selected state and type) size:"+ institutionsList.size());
		if(logger.isDebugEnabled())
			logger.debug("institutions List(for the selected state and type):"+institutionsList);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("suvidhaRetrieveEnabledInstitutionType(String USER_NAME) ends");
	
	return institutionsList;	
}		
public  int suvidhaDisableInstitutes(String INSTITUTE_ID,String USER_NAME) {
	logger.info("suvidhaDisableInstitutes(String INSTITUTE_ID,String USER_NAME) - Starts");
	logger.info("INSTITUTE_ID : " + INSTITUTE_ID);
	logger.info("USER_NAME : " + USER_NAME);
	int upRows=0;
	Object[] inparam = {INSTITUTE_ID,USER_NAME};
	int []argTypes={Types.VARCHAR,Types.VARCHAR};
	try 
    {  
            upRows = getJdbcTemplate().update(DISABLE_INSTITUTE, inparam,argTypes);
            
            logger.info("count : "+upRows); 
    } catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :" + dataAccessException);
			DAOException.throwException("SUV001");
	} 
	logger.info("suvidhaDisableInstitutes(String INSTITUTE_ID,String USER_NAME) -  ends");
	return upRows;
}
public  int suvidhaReenableInstitutes(String INSTITUTE_ID,String USER_NAME) {
	logger.info("suvidhaDisableInstitutes(String queryValue)");
	logger.info("queryValue : " + INSTITUTE_ID);
	int upRows=0;
	Object[] inparam={INSTITUTE_ID,USER_NAME};
	try 
    { 
            
            upRows = getJdbcTemplate().update(REENABLE_INSTITUTE,inparam); 
            
            logger.info("count : "+upRows); 
    } catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :" + dataAccessException);
			DAOException.throwException("SUV001");
	} 
	logger.info("suvidhaDisableInstitutes(String queryValue) ends");
	return upRows;
}
public List suvidhaRetrieveExistenabledInstitutions(String INSTITUTE_ID,String USER_NAME) throws DAOException{
	if(logger.isDebugEnabled())
	logger.debug("suvidhaRetrieveExistenabledInstitutions(String INSTITUTE_ID) -  beginss");
	List<String> existstatus= new ArrayList<String>();;
	
	Object[] inparam={INSTITUTE_ID,USER_NAME};
	
		try {
		
			existstatus = (List<String>)getJdbcTemplate().queryForList(RETERIEVE_EXIST_ENABLED_INSTITUTE,inparam,String.class);
			
		logger.info("institutions List(for the selected state and type) size:"+ existstatus);
		if(logger.isDebugEnabled())
			logger.debug("institutions List(for the selected state and type):"+existstatus);
		
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			 DAOException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("suvidhaRetrieveExistenabledInstitutions(String INSTITUTE_ID) ends");
	
	return existstatus;	
}
public int suvidhaRetrievePendingEchques(String INSTITUTE_ID,String USER_NAME)throws DAOException{
	logger.info("suvidhaRetrievePendingEchques(String INSTITUTE_ID,String USER_NAME) - Starts");
	logger.info("queryValue : " + INSTITUTE_ID);
	int pendingEcheuqes=0;
	Object[] inparam={INSTITUTE_ID,USER_NAME};
	try 
    { 
            
		pendingEcheuqes = (int)getJdbcTemplate().queryForInt(RETERIEVE_PENING_ECHEQUES,inparam); 
            
            logger.info("count : "+pendingEcheuqes); 
    } catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :" + dataAccessException);
			DAOException.throwException("SUV001");
	} 
	logger.info("suvidhaRetrievePendingEchques(String INSTITUTE_ID,String USER_NAME) - Ends");
	return pendingEcheuqes;
}

class ExistingCategoryRowMapper implements ResultSetExtractor {
	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
    	List CategoryList= new ArrayList();
    	while(rs.next()){
    	
    	Map CategoryMap = new HashMap();
    	CategoryMap.put("CATEGORY_ID",rs.getString("CATEGORY_ID"));
    	CategoryMap.put("INSTITUTE_ID",rs.getString("INSTITUTE_ID"));
    	CategoryMap.put("CATEGORY_NAME",rs.getString("CATEGORY_NAME"));
    	CategoryList.add(CategoryMap);
    	}
        return CategoryList;
    }
}

}
