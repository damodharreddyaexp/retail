/*
 * FavoritesDAOImpl.java
 * Created on Dec 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 08, 2005 VELMURUGAN K - Initial Creation
//NOV 09, 2005 MURUGAN K  - Implementation
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.model.Favorite;
import com.sbi.common.utils.BranchUtils;

/**
 * TODO Manipulates user's favorite data which are related to SBI_FAVORITES table 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class FavoritesDAOImpl extends JdbcDaoSupport implements FavoritesDAO {
	
    protected final Logger log = Logger.getLogger(getClass());
    
   private BranchUtils  branchUtils;
   
   private final static String FIND_FAVORITES_NAMES_QUERY = "SELECT FRIENDLY_NAME FROM SBI_FAVORITES WHERE USER_NAME =? AND STATUS=1"; 

    private final static String FIND_FAVORITES_QUERY = "SELECT * FROM SBI_FAVORITES WHERE USER_NAME =? AND STATUS=1";

    private final static String FIND_FAVORITE_BY_NICKNAME_QUERY = "SELECT * FROM SBI_FAVORITES WHERE USER_NAME =? AND FRIENDLY_NAME=? AND STATUS=1";

    private final static String INSERT_FAVORITE_QUERY = "INSERT INTO SBI_FAVORITES FIELDS"
            + "(USER_NAME,FRIENDLY_NAME,FAVORITE_TYPE,ALLOWEDIT,STATUS,DEBIT_ACCOUNT_NO,"
            + "DEBIT_BRANCH_CODE,DEBIT_ACCOUNT_TYPE,CREDIT_ACCOUNT_NO,"
            + "CREDIT_BRANCH_CODE,CREDIT_ACCOUNT_TYPE,PARAMETER1,PARAMETER2," 
            + "PARAMETER3,PARAMETER4,PARAMETER5) "
            + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private final static String DELETE_FAVORITE_QUERY = "DELETE FROM SBI_FAVORITES WHERE USER_NAME =? AND FRIENDLY_NAME=?";
    

    /**
     * This method will insert a record into table SBI_FAVORITES.
     * 
     */
    public boolean insertFavorite(Favorite favorite) {
        log.info("insertFavorite( Favorite favorite) method begin" + favorite);
        int result = 0;
        
        log.info(" Favourite  ********** " +favorite );
        if (favorite != null) {
            try {
                Object[] parameters =
                { favorite.getUserName(), favorite.getNickName(), favorite.getFavoriteType(), favorite.getAllowEdit(),
                        new Integer(1), favorite.getDebitAccountNo(), favorite.getDebitBranchCode(),
                        favorite.getDebitAccountType(), favorite.getCreditAccountNo(), favorite.getCreditBranchCode(),
                        favorite.getCreditAccountType(), favorite.getParam1(), favorite.getParam2(),
                        favorite.getParam3(), favorite.getParam4(), favorite.getParam5() };
                int[] types = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.NUMERIC,Types.VARCHAR,
                        Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                        Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                result = getJdbcTemplate().update(INSERT_FAVORITE_QUERY, parameters,types);
                log.info("insertFavorite method end " + result);
            }
            catch (DataAccessException ex) {
                handleException(ex, ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        }
        return result > 0 ? true : false;
    }

    /**
     * This method will retrieve the Favorites for the given username from the
     * table SBI_FAVORITES and returns the List of Favorite object.
     * 
     * Query select * from SBI_FAVORITES where user_name=? and status=1
     */
    public List findFavorites(String userName) {
        log.info("findFavorites( String userName ) method begin" + userName);
        List favorites = null;
        try {
            if (userName != null) {
                favorites = getJdbcTemplate().query(FIND_FAVORITES_QUERY, new Object[]
                { userName }, new FavoritesRowMapper());
                log.info("findFavorites method end returning List :" + favorites);
            }
        }
        catch (DataAccessException ex) {
            handleException(ex, ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return favorites;
    }

    /**
     * This method will retrieve the Favorite record for the given username and
     * nickname from the table SBI_FAVORITES and return the Favorite object.
     * 
     * Query select * from SBI_FAVORITES where user_name=? and friendly_name=?
     * and status=1
     */
    public Favorite findFavorites(String userName, String nickName) {
        log.info("findFavorites( String userName ) method begin");
        List favorites = null;
        Favorite favorite = null;
        try {
            if (userName != null && nickName != null) {
                favorites = getJdbcTemplate().query(FIND_FAVORITE_BY_NICKNAME_QUERY, new Object[]
                { userName, nickName }, new FavoritesRowMapper());
                if (favorites != null && favorites.size() > 0)
                    favorite = (Favorite) favorites.get(0);
                log.info("findFavorites method end returning Favorite object :" + favorite);
            }
        }
        catch (DataAccessException ex) {
            handleException(ex, ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return favorite;
    }

    /**
     * Make the favorite record offline for username and nickname
     * 
     * Query: update sbi_favorites set status=0 where user_name=? and
     * friendly_name=?
     */
    public boolean deleteFavorite(String nickName, String userName) {
        log.info("deleteFavorite( String nickName, String userName ) method begin");
        log.info("deleteFavorite( String nickName, String userName )" + nickName + "|" + userName);
        
        int result = 0;
        try {
            if (userName != null && nickName != null) {
                result = getJdbcTemplate().update(DELETE_FAVORITE_QUERY, new Object[]
                { userName, nickName });
                log.info("deleteFavorite method end " + result);
            }

        }
        catch (DataAccessException ex) {
            handleException(ex, ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return result > 0 ? true : false;

    }
    
    
  
    

    class FavoritesRowMapper implements RowMapper {
    	
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            Favorite favorite = new Favorite();
            favorite.setUserName(rs.getString("USER_NAME"));
            favorite.setNickName(rs.getString("FRIENDLY_NAME"));
            favorite.setCreationTime(rs.getTimestamp("CREATION_TIME"));
            favorite.setFavoriteType(rs.getString("FAVORITE_TYPE"));
            favorite.setDebitAccountNo(rs.getString("DEBIT_ACCOUNT_NO"));
            favorite.setDebitBranchCode(rs.getString("DEBIT_BRANCH_CODE"));
            favorite.setDebitAccountType(rs.getString("DEBIT_ACCOUNT_TYPE"));
            favorite.setCreditAccountNo(rs.getString("CREDIT_ACCOUNT_NO"));
            favorite.setCreditBranchCode(rs.getString("CREDIT_BRANCH_CODE"));
            favorite.setCreditAccountType(rs.getString("CREDIT_ACCOUNT_TYPE"));
            favorite.setAllowEdit(rs.getString("ALLOWEDIT"));
            favorite.setParam1(rs.getString("PARAMETER1"));
            favorite.setParam2(rs.getString("PARAMETER2"));
            favorite.setParam3(rs.getString("PARAMETER3"));
            favorite.setParam4(rs.getString("PARAMETER4"));
            favorite.setParam5(rs.getString("PARAMETER5"));
            if (rs.getString("FAVORITE_TYPE").equalsIgnoreCase("Quick Look")  )
            { 
            favorite.setDescription(rs.getString("FAVORITE_TYPE") + " statement for " + rs.getString("DEBIT_ACCOUNT_NO"));
            }
            if(rs.getString("FAVORITE_TYPE").equalsIgnoreCase("Funds Transfer") )
                favorite.setDescription(rs.getString("FAVORITE_TYPE") + " from " + rs.getString("DEBIT_ACCOUNT_NO") + " of " + branchUtils.getBranchName(rs.getString("DEBIT_BRANCH_CODE"))+ " branch to "+ rs.getString("CREDIT_ACCOUNT_NO")+ "of"+ branchUtils.getBranchName(rs.getString("CREDIT_BRANCH_CODE")));
            if(rs.getString("FAVORITE_TYPE").equalsIgnoreCase("Third Party Funds Transfer") )
                favorite.setDescription(rs.getString("FAVORITE_TYPE") + " from " + rs.getString("DEBIT_ACCOUNT_NO") + " of " + branchUtils.getBranchName(rs.getString("DEBIT_BRANCH_CODE"))+ " branch to "+ rs.getString("CREDIT_ACCOUNT_NO")+ "of"+ branchUtils.getBranchName(rs.getString("CREDIT_BRANCH_CODE")));
            if(rs.getString("FAVORITE_TYPE").equalsIgnoreCase("Account Statement"))
                favorite.setDescription(rs.getString("FAVORITE_TYPE") + " for " + rs.getString("DEBIT_ACCOUNT_NO") + " account for Last " + rs.getString("PARAMETER1")+ " days");
            return favorite;
        }
    }

    class FavoritesNamesMapper implements RowMapper {
    	public Object mapRow(ResultSet rs, int index) throws SQLException {
            Favorite favorite = new Favorite();
            favorite.setNickName(rs.getString("FRIENDLY_NAME"));
            return favorite;
        }
    }

    
//Created by Naveen Kumar(10.1.2006)
    
    public Map findFavoriteName(String userName)throws DAOException
    {
    	log.info("findFavoriteName()" + LoggingConstants.METHODBEGIN);
        Map favoritesNamesMap =  new HashMap();
        try {
          Object[] parameter = {userName};
          List favoriteNameList = getJdbcTemplate().query(FIND_FAVORITES_NAMES_QUERY,parameter,
                  new favoriteNameRowMapper());

          if (favoriteNameList != null && favoriteNameList.size() > 0) {
              
              favoritesNamesMap = (Map) favoriteNameList.get(0);
              if (log.isDebugEnabled()) {
            	  log.debug("favoriteName" + favoritesNamesMap);
              }
              log.info("findFavoriteName() (String userName)" + LoggingConstants.METHODEND);
          }
          
          
          }
      catch (DataAccessException ex) {
         DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
      }

      return favoritesNamesMap;
  }

  class favoriteNameRowMapper implements RowMapper {
      Map favoriteNameMap = new HashMap();

      public Object mapRow(ResultSet rs, int index) throws SQLException {
          favoriteNameMap.put(rs.getString(1), rs.getString(1));
          return favoriteNameMap;
      }
  }
 

    private void handleException(Exception ex, String errorCode) {
        log.error("Exception " + ex.toString());
        DAOException.throwException(ex.getMessage());
        
    }

    public void setBranchUtils(BranchUtils branchUtils) {
        this.branchUtils = branchUtils;
    }



}


