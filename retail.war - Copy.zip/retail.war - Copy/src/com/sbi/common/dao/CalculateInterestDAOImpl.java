package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.model.TransactionHistory;

public class CalculateInterestDAOImpl extends JdbcDaoSupport implements CalculateInterestDAO {
	
    protected final Logger logger = Logger.getLogger(getClass());
     
    public List findTransactionHistoryFirstRecord(Account account) throws DAOException {
        logger.info("findTransactionHistoryFirstRecord(Account account) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
        }		
		if(account !=null){
			try {
				Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode(), account.getAccountNo(), account.getBranchCode() };
				List resultList = getJdbcTemplate().query(SQLConstants.TXN_FIRST_RECORD, parameters,
	                    new TransactionHistoryClassRowMapper());	
				if(resultList !=null && resultList.size()>0){
					logger.info("findTransactionHistoryFirstRecord(Account account) method end");
					return resultList;
				}
			}catch(DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
		}else {
			if(logger.isDebugEnabled()){
			   logger.debug("Input Parameter Account" + account);
			}
			 DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
		}
		return null;
	}

	public List findTransactionHistoryTxnDate(Account account) throws DAOException {
		logger.info("findTransactionHistoryTxnDate(Account account) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
        }		
		if(account !=null){
			try {
				Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode() };
				List resultList = getJdbcTemplate().query(SQLConstants.TRANSACTION_DATE_QUERY, parameters,
	                    new TransactionHistoryDateRowMapper());	
				if(resultList !=null && resultList.size()>0){
					logger.info("findTransactionHistoryFirstRecord(Account account) method end");
					return resultList;
				}				
			}catch(DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
		}else {
			if(logger.isDebugEnabled()){
			   logger.debug("Input Parameter Account" + account);
			}
			 DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
		}		
		logger.info("findTransactionHistoryTxnDate(Account account) method end");
		return null;
	}

	public List findTxnHistoryCount(Account account,String count) throws DAOException {
		logger.info("findTxnHistoryCount(Account account,String count) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
        }		
		if(account !=null){
			try {
				Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode(),count };
				List resultList = getJdbcTemplate().query(SQLConstants.TXN_HISTORY_COUNT_QUERY, parameters,
	                    new TxnHistoryRowMapper());	
				if(resultList !=null && resultList.size()>0){
					logger.info("findTxnHistoryCount(Account account,String count) method end");
					return resultList;
				}				
			}catch(DataAccessException ex) {
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
			}
		}else {
			if(logger.isDebugEnabled()){
			   logger.debug("Input Parameter Account" + account);
			}
			 DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
		}		
		return null;
	}
	
	 class TransactionHistoryClassRowMapper implements RowMapper
	    {
	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {

	            TransactionHistory acc = new TransactionHistory();
	            acc.setTransactionDate(rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
	            return acc;
	        }
	    }	
	
	 class TransactionHistoryDateRowMapper implements RowMapper
	    {
	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {

	            TransactionHistory acc = new TransactionHistory();
	            acc.setTransactionDate(rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
	            return acc;
	        }
	    }

	 class TxnHistoryRowMapper implements RowMapper
	    {
	        public Object mapRow(ResultSet rs, int index) throws SQLException
	        {
	        	logger.info("transaction_date***="+rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
	        	logger.info("rs.getDouble(SQLConstants.AMOUNT)***="+rs.getDouble(SQLConstants.AMOUNT));
	            TransactionHistory acc = new TransactionHistory();
	            acc.setTransactionDate(rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
	            acc.setAmount(new Double(rs.getDouble(SQLConstants.AMOUNT)));
	            return acc;
	        }
	    }
	 
	
}
