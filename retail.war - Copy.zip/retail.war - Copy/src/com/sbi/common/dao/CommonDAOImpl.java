package com.sbi.common.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.sbi.common.dao.CommonDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.service.ServiceErrorConstants;

public class CommonDAOImpl extends JdbcDaoSupport implements CommonDAO {
	
	 protected final Logger logger = Logger.getLogger(getClass());
	 private static final String MERCHANT_BILLDESK_PAYMENT = "select PAYMENT_MODE, ONLINE_DEBIT_STATUS from (select PAYMENT_MODE, ONLINE_DEBIT_STATUS from BVSBI.SBI_PRELOGIN_ECHEQUE_MASTER where CORP_REF_NO = ? and merchant_code = ? order by last_mod_time desc ) where ROWNUM = 1"; // Changes for Other Banks Internet Banking
	 
	public boolean execute(String query, Object[] params){
		boolean status=false;
		if(query!=null && query.length()>0 && params!=null && params.length>0){
			try{
				/*DriverManagerDataSource dataSource = new DriverManagerDataSource();
				dataSource.setDriverClassName( "oracle.jdbc.driver.OracleDriver");
				dataSource.setUrl("jdbc:oracle:thin:@172.18.7.57:1521:BVDB6");
				dataSource.setUsername("dbone");
				dataSource.setPassword("dbone");
				JdbcTemplate jdbcTemplate=new JdbcTemplate();
				jdbcTemplate.setDataSource(dataSource);*/
				int result=getJdbcTemplate().queryForInt(query,params);
				if(result>0){
					status=true;
				}
			}catch(DataAccessException dataAccessException){
				dataAccessException.printStackTrace();
				DAOException.throwException(ServiceErrorConstants.SE002,dataAccessException);
			}
		}
		return status;
	}
	
	//Added for IR71772
	public String getRegisteredCreatedUser(String accountNo, String userName) {
		String regUserName=null;
		logger.info("accountNo"+accountNo);
		logger.info("userName"+userName);
		String selectQuery="select user_name from SBI_MT940_ACCOUNT_STATEMENT where registration_status='Processed' and account_number=? ";//and user_name=?
			
		try{
			logger.info("Executing query-before");
			Object params[]= {accountNo};
			
			regUserName = (String) getJdbcTemplate().queryForObject(selectQuery, params,String.class);
			logger.info("RegUserName::::"+regUserName);
		}		
		catch (DataAccessException dataAccessException) {
			//DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);			
			return regUserName;
		
        }
		return regUserName;
	}
	
	public Map getPaymentMode(String refNo, String merchantCode) {
		Map resultsetMap=new HashMap();
		
		try{
			logger.info("getPaymentMode Method");
			Object params[]= {refNo, merchantCode};
			
			resultsetMap = (Map) getJdbcTemplate().queryForMap(MERCHANT_BILLDESK_PAYMENT, params);			
		}
		catch (IncorrectResultSizeDataAccessException e) {
			 logger.info(e);
			 return resultsetMap;
		 } 
		catch (DataAccessException dataAccessException) {
			//DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);			
			return resultsetMap;
		
        }
		return resultsetMap;
	}
}
