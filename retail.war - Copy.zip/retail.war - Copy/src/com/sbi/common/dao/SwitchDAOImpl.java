/*  
 * SwithDAOImpl.java
 * Created on Oct 22, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 22, 2005 BOOPATHI - Initial Creation
// DEC 28, 2005 - BOOPATHI - EXCEPTION MODIFIED
// JAN 02, 2005 - BOOPATHI - SWITCH CLIENT ADDED
package com.sbi.common.dao;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.DataParser;
import com.sbi.common.utils.IMessageProcessor;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.SwitchClient;
import com.sbi.common.dao.TransactionStringLoaderDAO;
import com.sbi.common.utils.SwitchMapToBankSystemComModelConverter;
import com.sbi.common.model.BankSystemComModel;

public class SwitchDAOImpl implements SwitchDAO
{

    IMessageProcessor switchMessageProcessor;
    DataParser dataParser;
    SwitchClient switchClient; 
    private TransactionStringLoaderDAO transactionStringLoaderDAOImpl;
    private SwitchMapToBankSystemComModelConverter switchMapToBankSystemComModelConverter;
    protected final Logger logger = Logger.getLogger(getClass());

    public List getDataFromBankSystem(Map request) throws DAOException
    {
        logger.info("getDataFromBankSystem(Map request) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("request :" + request);
        }
        
        try{
            String requestData=null;
        	String txnno = (String)request.get("txnno");
            BankSystemComModel bankSystemComModel=null;
            requestData = switchMessageProcessor.convertRequest(request);
            if(! txnno.equalsIgnoreCase("333333"))
            {
        	 bankSystemComModel = switchMapToBankSystemComModelConverter.convert(request,requestData);
        	transactionStringLoaderDAOImpl.load(bankSystemComModel);
            }
        	if (logger.isDebugEnabled())
        	{
        		logger.debug("requestData :" + requestData);
        	}
        
        	String response = switchClient.processMsg(requestData);
        	
        	if(txnno.equalsIgnoreCase("333333")){
        		List parserResponseList = null;
        		if(response.equalsIgnoreCase(ErrorConstants.TIMEOUT_ERROR_CODE) || response.equalsIgnoreCase(ErrorConstants.CONNECTION_REFUSED_ERROR_CODE)){
        			
        			parserResponseList = new ArrayList();
        			Map data = new HashMap();
            		
            		data.put("TXN_DATE","");
            		data.put("TXN_REF","");
            		data.put("TXN_WEF","");
            		data.put("TXN_AMT","");
            		data.put("TXN_NAR1","");
            		data.put("TXN_NAR2","");
            		data.put("TXN_NAR3","");
            		data.put("BAL","");
            		data.put("status",response);
            		
            		parserResponseList.add(data);
        		
        		
        		}
        		else{        			
        			parserResponseList = dataParser.getBalance(response);        			
        		}
        		return parserResponseList;
        	}
        	
        	
        	if(response.equalsIgnoreCase(ErrorConstants.TIMEOUT_ERROR_CODE)){
        		response = "<TXN><REF> </REF><STATUS>F1</STATUS><PAY-ID> </PAY-ID></TXN>";
        	}
        	else if(response.equalsIgnoreCase("F2")){
        		response = "<TXN><REF> </REF><STATUS>F2</STATUS><PAY-ID> </PAY-ID></TXN>";
        	}
        	
        	String parseData = dataParser.getTxnResponse(response);        	        
        
        	Map responseData = switchMessageProcessor.convertResponse(parseData, txnno, new ArrayList());
            
            // other than Txn: 333333 - get LatestBalance from Switch 
            if(! txnno.equalsIgnoreCase("333333"))
            {
        	bankSystemComModel.setResponseString(response);
            transactionStringLoaderDAOImpl.update(responseData,bankSystemComModel);
            }
        	List responseDataList = new ArrayList();
        	responseDataList.add(responseData);
        	if (responseDataList.size() > 0)
        	{ 
        		if (logger.isDebugEnabled())
        		{
        			logger.debug("responseDataList :" + responseDataList);
        		}
        		return responseDataList;
        	}
        	else 
        	{
        		DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        	}
        	
        }catch(Exception excep){
        	logger.info(LoggingConstants.EXCEPTION+excep);
        	DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,excep);
        }
        return null;
    }

    public Map getDataFromBankSystem(String request)
    {
        return null; 
    }

    /**
     * SwitchMessageProcessor injection
     * 
     * @param switchMessageProcessor
     */
    public void setSwitchMessageProcessor(IMessageProcessor switchMessageProcessor)
    {
        this.switchMessageProcessor = switchMessageProcessor;
    }

	public void setDataParser(DataParser dataParser) {
		this.dataParser = dataParser;
	}

	public void setSwitchClient(SwitchClient switchClient) {
		this.switchClient = switchClient;
	}

	public void setSwitchMapToBankSystemComModelConverter(
			SwitchMapToBankSystemComModelConverter switchMapToBankSystemComModelConverter) {
		this.switchMapToBankSystemComModelConverter = switchMapToBankSystemComModelConverter;
	}

	public void setTransactionStringLoaderDAOImpl(
			TransactionStringLoaderDAO transactionStringLoaderDAOImpl) {
		this.transactionStringLoaderDAOImpl = transactionStringLoaderDAOImpl;
	} 

}
