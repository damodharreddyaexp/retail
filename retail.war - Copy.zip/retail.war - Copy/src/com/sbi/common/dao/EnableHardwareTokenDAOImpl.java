package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.DSCDetails;
import com.sbi.common.model.HardwareTokenDetails;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ErrorConstants;

public class EnableHardwareTokenDAOImpl extends JdbcDaoSupport implements EnableHardwareTokenDAO {
	protected final Logger logger = Logger.getLogger(getClass());

    public static final String VASCO_USER_DETAILS = "select friendly_name, reference_no,user_role,corporate_id,created_by from sbicorp_user_mobile_no where reference_no=? and created_by=? and status ='Pending' ";
    public static final String GET_C10_FORM_LIST_DETAILS = "select b.user_id,b.corporate_id,b.reference_no,b.user_role, b.created_by,b.friendly_name,a.employee_no emp_no,b.status,b.creation_time from bv_user_profile a, "+
															"sbi_sf_auth_user_req_details b where a.user_id = b.user_id and a.corporate_id = b.corporate_id and b.user_id=? and a.corporate_id=? and b.status='Pending' order by b.creation_time desc";
    public static final String GET_C10_FORM_DETAILS = "select b.user_id,b.corporate_id,b.reference_no,b.user_role, b.created_by,b.friendly_name,a.employee_no emp_no,b.status,b.creation_time from bv_user_profile a, "+
															"sbi_sf_auth_user_req_details b where a.user_id = b.user_id and a.corporate_id = b.corporate_id and b.reference_no=? and b.status='Pending'";    

	  public HardwareTokenDetails insertUserDetails(Integer userId,String branchCode, Integer userRole,String corporateId, String userAlias, String friendlyName)throws DAOException 
	  {
		 logger.info("int insertRegisterMobileNoDetails( String corpID )METHODBEGIN");
	     logger.info("UserId :" + userId+"BranchCode :"+branchCode+"UserRole :"+userRole+"corporateId" +corporateId+ "friendlyName :"+friendlyName);
	     int status =0;
	     Date creationTime=null;
	     HardwareTokenDetails hardwareTokenDetails = new HardwareTokenDetails();
        
         int count=0;
         String referenceNo = null;
         String queryforCount;
	        if (userId != null  )
	        {
	            Object[]  countparams = new Object[] {userId,branchCode};
	            //queryforCount = "select count(1) from sbicorp_user_mobile_no where user_id=? AND status='Pending'";
	            queryforCount=" select count(reference_no) from sbi_sf_auth_user_req_details a, SBI_AUTHENTICATION_USER_MAP b " +  
	            			  " where a.user_id = ? AND a.branch_code = ? "+ 
	            			  " AND a.created_by = b.user_alias AND a.branch_code = b.branch_code "+
	            			  "	AND a.status = 'Processed' AND b.status in (0,1) "; 

	            count = getJdbcTemplate().queryForInt(queryforCount,countparams);
	            logger.info("count :"+count);
	            
	            if(count == 0){
	            	//Pending Logic
	            	queryforCount=" select REFERENCE_NO,CREATION_TIME from sbi_sf_auth_user_req_details " +
	            				" where user_id = ? AND status='Pending'"; 
	            	
	            	countparams = new Object[] {userId};
	            	
	            	Map referenceMap=null;
	            	try {
	            			referenceMap=getJdbcTemplate().queryForMap(queryforCount,countparams);
	            	}catch(DataAccessException dae) {
	            		
	            	}
	            	
	            	if(referenceMap != null) {
	            		// If its Pending .. Get the creation time of the existing record
	            		referenceNo=(String)referenceMap.get("reference_no");	            		
	            		status = 1;
			            creationTime=(Date)referenceMap.get("creation_time");
	            	}	            	
	            	else {
					// Insert a new record.. treat it as the First time record
					// insert if it is unmapped by the branch	            		
	            		String query="select 'CMR' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual";
	                    referenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
	                    
			            Object[] Parameter = new Object[] {userId,referenceNo,branchCode,userRole,corporateId,userAlias,friendlyName};
			            int sqlTypes[] = {Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.INTEGER,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
			            logger.info("UserId:::" + userId+"referenceNo:::" +referenceNo+ "BranchCode :"+branchCode+"UserRole :"+userRole+"corporateId" +corporateId+ "userAlias :"+userAlias);
			            String query_for_user="Insert into sbi_sf_auth_user_req_details (USER_ID,STATUS,CREATION_TIME,REJECT_REASON,LAST_MOD_TIME,MODIFY_BY,REFERENCE_NO,BRANCH_CODE,USER_ROLE,CORPORATE_ID,CREATED_BY,FRIENDLY_NAME) values (?,'Pending',sysdate,null,sysdate,null,?,?,?,?,?,?)";
			            
			            status = getJdbcTemplate().update(query_for_user, Parameter, sqlTypes);
			            
			            creationTime=new Date();
			            
			            logger.info("status " + status);
	            	}
	            	
	            }else{	            	
	            	DAOException.throwException(ErrorConstants.ERROR_CODE_VASCO);
	            }	                
             if(status == 1 && referenceNo != null){
          	   logger.info("referenceNo :::"+referenceNo);
          	   hardwareTokenDetails.setReferenceNo(referenceNo);
          	   hardwareTokenDetails.setUserRole(String.valueOf(userRole));
          	   hardwareTokenDetails.setRequestDate(creationTime);
             }
              if (logger.isDebugEnabled())
              {
                  logger.debug("status :" + status);
              }

	          
			}else{
				DAOException
				.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
			}
	        logger.info("insertRegisterMobileNoDetails(int userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,int userRole,String cororateId,String userAlias)"+ LoggingConstants.METHODEND);
	        return hardwareTokenDetails;
	
}
	  public List getC10Users(String userName, String corporateID,String ppID,String flag) throws DAOException {
			List formList = null;
			 logger.info("getC10Users(String userName, String corporateID)method begin");
			try {
				if(flag!=null && !"".equalsIgnoreCase(flag) && flag.equalsIgnoreCase("listView"))
				{
					String query = VASCO_USER_DETAILS;					
					logger.info("query is......"+query);
					logger.info("user name::::::"+ppID);
					Object[] param = {ppID,userName};
					formList = (List) getJdbcTemplate().query(query,param,new C10FormExtractor());	
				}
				

			} catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

			}
			logger.info("getC10Users(String userName, String corporateID): method ends");
			return formList;
		}
	  
	  private class C10FormExtractor implements ResultSetExtractor {
			public Object extractData(ResultSet rs) throws SQLException,
					DataAccessException {
				List c10List = new ArrayList();
				while (rs.next()) {

					UserProfile userProfile = new UserProfile();
					userProfile.setName(rs.getString("FRIENDLY_NAME"));	
					userProfile.setCountryCode(rs.getString("REFERENCE_NO"));
					userProfile.setLoginCount(rs.getInt("USER_ROLE"));
					userProfile.setCorporateId(rs.getString("CORPORATE_ID"));
					userProfile.setCreatedBy(rs.getString("CREATED_BY"));
					logger.info("Result Set Extractor:"+userProfile.toString());
					c10List.add(userProfile);
				}
				return c10List;
			}
		}
	  public List getC10FormListDetails(String userId, String corporateID) throws DAOException {
			
			logger.info("getC10FormListDetails(String userName, String corporateID) method begin");
			List hardwareTokenList = null;
			
			try {
				
				String query =  GET_C10_FORM_LIST_DETAILS;
				logger.info("userid :"+userId+",corporateID :"+corporateID);
				logger.info("query :"+query);
				Object[] param = {userId,corporateID};
				hardwareTokenList = (List) getJdbcTemplate().query(query,param,new C10FormRowMapper());
		
			} catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
			logger.info("getC10FormListDetails(String userName, String corporateID) method ends");
			return hardwareTokenList;
		}
	  public HardwareTokenDetails getC10FormDetails(String referenceNo) throws DAOException {
			logger.info("getC10FormDetails(String referenceNo) method begin");
			
			List formList = null;
			HardwareTokenDetails hardwareTokenDetails=null;
			try {
				
				String query = GET_C10_FORM_DETAILS;
				logger.info("referenceNo:"+referenceNo);
				logger.info("query:"+query);
				Object[] param = {referenceNo};
				
				formList = (List) getJdbcTemplate().query(query,param,new C10FormRowMapper());
				
				if(formList!=null && formList.size()>0)
				{
					hardwareTokenDetails=(HardwareTokenDetails)formList.get(0);
				}
				
			} catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

			}
			logger.info("getC10FormDetails(String referenceNo) method ends");
			return hardwareTokenDetails;
		}
	  
	  private class C10FormRowMapper implements ResultSetExtractor {
		  
			public Object extractData(ResultSet rs) throws SQLException,DataAccessException {
				
				List list = new ArrayList();
				while (rs.next()) {

					HardwareTokenDetails hardwareTokenDetails =new HardwareTokenDetails();
					hardwareTokenDetails.setUserId(String.valueOf(rs.getInt("user_id")));
					hardwareTokenDetails.setReferenceNo(rs.getString("reference_no"));
					hardwareTokenDetails.setModifyUser(rs.getString("created_by"));
					hardwareTokenDetails.setRequestDate(rs.getTimestamp("creation_time"));
					hardwareTokenDetails.setStatus(rs.getString("status"));
					list.add(hardwareTokenDetails);
				}
				return list;
			}
		}
}
