package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;

 

public class PasswordProfileDAOImpl extends JdbcDaoSupport {
	protected final Logger logger = Logger.getLogger(getClass());

	public List getUserPPSymbols(String userName){
		logger.info("getUserPPSymbols in PasswordProfileDAOImpl begins " );
		Object parameters[] = { userName };
		
		List result = null;
	        try{
	            result = getJdbcTemplate().query("select a.USER_ID,a.USER_ALIAS,a.USER_STATE,a.PASSWORD,b.user_type, b.PROFILE_PWD_IMG_LIST FROM BV_USER a,BV_USER_PROFILE b WHERE a.user_id=b.user_id and a.USER_ALIAS = ?", parameters, new ProfSymRowMapper());
	            logger.info("result"+ result);
	        }
	        catch(DataAccessException dataAccessException){
	            Object errorParams[] = { userName };
	            DAOException.throwException(dataAccessException, "LOG014", errorParams);
	        }
	    	logger.info("getUserPPSymbols in PasswordProfileDAOImpl ends " );
	   return result;     
	}
	
	
	
	
	class ProfSymRowMapper implements RowMapper {
		
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			return rs.getString("PROFILE_PWD_IMG_LIST");
		}
	}

}
