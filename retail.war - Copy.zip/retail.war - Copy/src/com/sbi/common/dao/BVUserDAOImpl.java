package com.sbi.common.dao;

import org.apache.log4j.Logger;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.HttpMessage; 
import com.sbi.common.utils.EncryptMD5;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.exception.SBIApplicationException;



public class BVUserDAOImpl  extends JdbcDaoSupport implements BVUserDAO {

    private HttpMessage httpMessage;
    
    private String urlString;
    
    protected final Logger logger = Logger.getLogger(getClass());
    
    public boolean validateLogin(String userName, String password) {
      
   String str[][]=new String[3][2];
        try {
            str[0][0] = "username";
            str[0][1] = userName;
            str[1][0] = "password";
            str[1][1] = password;
            str[2][0] = "mode";
            str[2][1] = "1";
            String reqString = httpMessage.sendMessage(str,urlString);
            logger.info("login " + reqString);
            if(reqString.equals("SUCCESS")){
            	 logger.info("validateLogin(String userName, String password) method end with success" );
                return true;
            }else{
                return false;
            }
                            
        } catch (Exception exception) {   
        	logger.error("Exception :",exception);                                      
            DAOException.throwException("F010",exception);  
        }

        logger.info("validateLogin(String userName, String password) method end" );
        return false;
    }

    public void changeLoginPassword(String userName, String oldPassword, String newPassword) {
        
        String str[][]=new String[4][2];
        try {
            str[0][0] = "username";
            str[0][1] = userName;
            str[1][0] = "password";
            str[1][1] = newPassword;
            str[2][0] = "oldpassword";
            str[2][1] = oldPassword;
            str[3][0] = "mode";
            str[3][1] = "2";
            String reqString = httpMessage.sendMessage(str,urlString);
            logger.info("change password " + reqString);
            if(!reqString.equals("SUCCESS")){
                DAOException.throwException("F010");
            }
                
        } catch (Exception exception) {      
        	logger.error("Exception :",exception);                                   
            DAOException.throwException("F010",exception);  
        }
    }

    public void changeUserNamePassword(String userName, String oldUserName, String newPassword) {
        
        String str[][]=new String[4][2];
        try { 
            str[0][0] = "username";
            str[0][1] = userName;
            str[1][0] = "password";
            str[1][1] = newPassword;
            str[2][0] = "oldusername";
            str[2][1] = oldUserName;
            str[3][0] = "mode";
            str[3][1] = "3";
            String reqString = httpMessage.sendMessage(str,urlString);
            logger.info("change password " + reqString);
            if(!reqString.equals("SUCCESS")){
                DAOException.throwException("F010");
            }
                
        } catch (Exception exception) {
	        logger.error("Exception :",exception);                                         
            DAOException.throwException("F010",exception);  
        }
    }
    // Added for corporate admin
    
    //Added by Saravanaselvan
    public boolean addUser(String userName, String password) {
         logger.info("addUser(String userName, String password)method begin");
              String encPassword=null;
        int status_account =0;
        int status_user=0;
        
        encPassword=EncryptMD5.hashMessage(userName+"#"+password);
        
        String queryforbv_user="INSERT INTO BV_USER(USER_ID,ACCOUNT_ID,USER_ALIAS,PASSWORD,USER_STATE,MODIF_TIME) VALUES(?,?,?,?,?,SYSDATE)";
        String queryforbv_account="INSERT INTO BV_ACCOUNT VALUES(?,?,?,SYSDATE)";
        try
		{
		    if(userName!=null && password !=null)
				{
			        int seqid=getJdbcTemplate().queryForInt("select user_idseq.NEXTVAL from dual");
        
					Object[] parameters_bvuser=new Object[] {new Integer(seqid),new Integer(seqid),userName,encPassword,new Integer(0)}; 
			        Object[] parameters_bvaccount=new Object[] {new Integer(seqid),new Integer(seqid),new Integer(0)};
        
					status_account =  getJdbcTemplate().update(queryforbv_account,parameters_bvaccount);
			
					if(status_account>0)
						status_user =  getJdbcTemplate().update(queryforbv_user,parameters_bvuser);
        
					logger.info("Insert Status for bv_Account  ::::"+status_account +" Insert Status for bvuser :"+status_user);
					if(status_account >0 && status_user>0)
						 return true;
					else
			             return false;
				}
			else
				 SBIApplicationException.throwException("SE002");
        }
        catch(DataAccessException ex)
        {
            logger.error("Exception occured during inserting into bv_user or bv_account ::"+ex);
            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            
        }
        catch(Exception e)
        {
            logger.error("Error :"+e);
        }
            
        return false;
    }
    // added for coporate admin

    public void setHttpMessage(HttpMessage httpMessage) {
        this.httpMessage = httpMessage;
    } 
    
    public void setUrlString(String urlString) {
        this.urlString = urlString;
    } 
    
    //added for corporate first time login
    public void changeLoginPassword(String userName, String password) {
        
        String str[][]=new String[3][2];
        try {
            str[0][0] = "username";
            str[0][1] = userName;
            str[1][0] = "password";
            str[1][1] = password;            
            str[2][0] = "mode";
            str[2][1] = "5";
            String reqString = httpMessage.sendMessage(str,urlString);
            logger.info("change password " + reqString);
            if(!reqString.equals("SUCCESS")){
                DAOException.throwException("F010");
            }
                
        } catch (Exception exception) {                                         
            DAOException.throwException("F010",exception);  
        }
    }
}
