package com.sbi.common.dao;

import java.util.List;

import com.sbi.common.exception.DAOException;

public interface DownloadBenificiariesListDAO {
	
public String generateRequestIdForDownload3PFile(String userName,String banktype,String corpId,String requestedBy,String formatType) throws DAOException;
	
	public List viewBenDownload3PFileRequestStatus(String userName) throws DAOException;
	

	List getRegulators(String corporateID); 
	List getAdmins(String corporateID); 
	int checkApproverEligible(String corporateID); 
	int checkEligibilityForRegulator(String corporateID) throws DAOException;
	List getApprovers(String corporateID,String userName); 
}
