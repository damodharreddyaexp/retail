/*
 * ThirdPartyDAO.java
 * Created on Dec 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 9, 2005 SG33414 - Initial Creation
package com.sbi.common.dao;


import java.util.Map;

import com.sbi.common.model.CorporateFile;
import com.sbi.common.model.CpsmsBeneficiary;


public interface CpsmsBeneficiaryDAO { 
	public CorporateFile[] findTPFiles(String corporateId, String startDate,String endDate, String viewType ,String bankCode,String adminAccNo);
	public Map findBenFiledetails(String corporateId,String fileName, String viewType,String adminAccNo);
	public CpsmsBeneficiary[] findTPsByFile(String corporateId, String fileName, String beneficiaryType,String requestType, String viewType, String adminAccNo );
	public boolean rejectTPState(String rejectedOIDs, String functionType, String userName, String beneficiaryType, String corporateID,String selectallcat,String filename, String Adminaccno);
	public boolean updateTPState(String approvedOIDs, String functionType, String userName, String beneficiaryType, String corporateID);
	//ADDED BY DAMODAR
	public boolean updateAllTPState(String approvedOIDs, String functionType, String userName, String beneficiaryType, String corporateID,String filename, String Adminaccno);
	public CpsmsBeneficiary[] findTPdetails(String userName, String fileName, String apprIds, String beneficiaryType,String functionType);
}
