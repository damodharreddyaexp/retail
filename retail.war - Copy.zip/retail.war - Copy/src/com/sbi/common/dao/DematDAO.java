
/*
 * DematDAO.java
 * Created on Aug 9, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Aug 9, 2006 VS23778 � Initial Creation

package com.sbi.common.dao;

import java.util.List;
import java.util.Map;


import com.sbi.common.exception.DAOException;

/**
 * TODO Enter the description of the class here 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public interface DematDAO {
    
    List getDpIds(String userName) throws DAOException;
    String getNRIAccountsAvailability(String userName) throws DAOException;
    int insertEZTradeNRIAccounts(Map NRIAccountDetails) throws DAOException;
    int getAcccountCount(String userName)throws DAOException;
    List getEbrokingDetails(String userName) throws DAOException;//added for NOW CR
    List getEbrokingDetailsForCorp(String userName) throws DAOException;//added for NOW CR
    Double getEbrokingLienAmount(String eBrokingId) throws DAOException;//added for NOW CR
    String insertLienReleaseAmount(String userName,String eBrokingId,double releaseAmt,String referenceNo,double amount) throws DAOException;//added for NOW CR
    String insertCorpLienReleaseAmount(String userName,String eBrokingId,double releaseAmt,String referenceNo,double amount,String corpId) throws DAOException;//added for NOW CR Corp
    String  getCorpId(String ebrokingId)throws DAOException;
    Map getLienReferenceNo(String eBrokingId) throws DAOException;
    int getEbrokingStatus(String eBrokingId) throws DAOException;
	List getStatusDetails(String eBrokingId,String startDate,String endDate) throws DAOException;//added for NOW CR
	List getSSLeBrokingIds(String userName) throws DAOException;//Added for CR DEV-338;
}
