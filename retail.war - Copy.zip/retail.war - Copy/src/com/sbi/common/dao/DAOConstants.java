/* 
 * DAOConstants.java
 * Created on Oct 19, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 19, 2005 BOOPATHI - Initial Creation
//Oct 25, 2005 MURUGAN  K -  Added two constants TXN_ENQUIRY_LOAN, TXN_ENQUIRY_DEPOSIT
//Oct 04, 2005 MURUGAN K  - added constants for  BV_USER_PROFILE TABLE  which are  used with Address Object
//nov 23, 2005 BOOPATHI - added constants
//Nov 28,2005 added by saravanan for Naveen- REFERENCE_NO,CHEQUE_REQUEST,QUERY_FOR_REFERENCENO,
//Nov 28, 2005 added by saravanan for Naveen-REFERENCE_NUMBER

package com.sbi.common.dao;

import com.sbi.common.utils.Constants;

/**
 * TODO Constansts declaretion for com.sbi.dao classes 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public interface DAOConstants extends Constants
{

    

    public final static String USERNAME = "username";

    public final static String OUTDATA = "outdata";

    public final static String BALANCE = "balance";

    public final static String ACCNO = "account_no";

    public final static String AVAIL_BAL = "avail_balance";

    public final static String ACCOUNT_NO = "account_no";

    public final static String BRANCH_CODE = "branch_code";

    public final static String BRANCH_NAME = "branch_name";

    public final static String CLEAR_BALANCE = "clear_balance";
    

    public final static String ACCOUNT_NICKNAME = "account_nickname";

    public final static String ACCESS_LEVEL = "access_level";

    public final static String CORE_FLAG = "coreflag";

    public final static String ACCOUNT_TYPE = "accounttype";

    
    
    public final static String CORE = "Core";

    public final static String BANK_MASTER = "NonCore";

    public final static String DATA_NULL_ERROR = "data null";

    public final static String DATA_NULL_ERROR_CODE = "E001";

    public final static String DATA_NULL_DESCRIPTION = "input data is null";

    public final static String DATA_NOT_FOUND = "Accounts not available"; // changes

    // //"result
    // data
    // not
    // found";

    public final static String DATA_NOT_FOUND_ERROR_CODE = "E002";

    public final static String DATA_NOT_FOUND_ERROR_DESCRIPTION = "Result data not found";

    public static final String TXN_ENQUIRY_LOAN = "010450"; // 010440 - LONG

    // ENQUIRY

    public static final String TXN_ENQUIRY_DEPOSIT = "000450"; // 000440 - LONG

    // ENQUIRY

    public static final String USER_ALIAS = "user_alias";

    public static final String USER_ID = "user_id";

    public static final String USER_STATE = "user_state";

    public static final String BRANCH_DETAILS = "branchDetails";

    /* Constants for BV_USER_PROFILE for Address Object */
    public static final String ADDRESS1 = "address";

    public static final String CITY = "city";

    public static final String COUNTRY = "country";

    public static final String STATE = "state";

    public static final String PIN_CODE = "zip";

    public static final String ADDRESS = "address";

    public static final String BANK_CODE = "bank_code";

    public static final String BUS_PHONE = "bus_phone";

    public static final String EMAIL = "email";
    
    public static final String PROFILE_USER_NAME = "name";

    public static final String HINT_ANSWER = "hint_answer";

    public static final String HINT_QUESTION = "hint_question";

    public static final String HOME_PHONE = "home_phone";

    public static final String LAST_LOGIN_DATE = "last_login_date";

    public static final String LAST_TDATE_INTERNET = "last_tdate_internet";

    public static final String LAST_TNAME_INTERNET = "last_tname_internet";
    
    public static final String PWD_CHANGED_DATE="pwd_changed_date"; //Added by Siva

    static final String LOGIN_COUNT = "login_count";

    static final String MOBILE_NO = "mobile_no";

    static final String SMS_SECURITY = "sms_security";

    static final String THIRDPARTY_LIMIT = "thirdparty_limit";

    static final String INTERNET_BANK_TRANS_LIMIT = "internet_bank_trans_limit";

    static final String ZIP = "zip";

    static final String USER_PROFILE = "_Profile";

    static final String USER_ACCOUNTS = "_Accounts";

    static final String FROM_DATE = "from_Date";

    static final String TO_DATE = "to_Date";

    static final String GET_TRANSACTION_BY_DATE_PROC = "getTransactionsByDate"; // store

    // procedure
    // name
 
    static final String TOAMOUNT = "to_amount";

    /* Constants for Core Transaction */

    static final String CORE_TXN_NO = "txnno";

    static final String CORE_FIN_TXN_TYPE = "fin_txn_type";

    static final String CORE_ACCOUNT_NO = "account_no";

    static final String TXN_IDENTIFIER = "txn_identifier";

    static final String CORE_START_DATE = "start_date";

    static final String CORE_END_DATE = "end_date";

    static final String CORE_FROM_AMOUNT = "from_amt";

    static final String CORE_TO_AMOUNT = "to_amt";
    

    static final String CORE_NARRATIVE = "narrative";

    static final String USER_NARRATIVE = "user_narrative";

    static final String CORE_DATE = "date";

    static final Object CORE_VALUE_DATE = "valuedate";

    static final String CORE_BALANCE = "balance";

    // data added by boopathi nov 22, 2005 3.50 pm

    public static final String EMPTY = "";

    public static final String CURRENCY_CODE = "currency_code";

    public static final String PRODUCT_DESC = "product_desc";

    public static final String CORE_BANKING = "core_banking";

    public static final String CORE_SYMBOL = "C";

    public static final String NONCORE_SYMBOL = "NC";

    public static final String USER_COUNT = "user_count";

    public static final String NOMINATION = "nomination";

    public static final String YES = "Y";

    public static final String NO = "N";

    public static final String BOOK_BALANCE = "book_balance";

    public static final String DRAWING_POWER = "drawing_power";

    public static final String LIMIT = "limit";

    public static final String INTEREST_RATE = "interest_rate";

    public static final String MATURITY_AMT = "maturity_amt";

    public static final String MATURITY_DATE = "maturity_date";

    public static final String TERM_VALUE = "term_value";

    public static final String ACCUMULATED_INTEREST = "accumulated_interest";

    public static final String OPENING_DATE = "opening_date";

    public static final String TENOR_DAYS = "tenor_days";

    public static final String TENOR_MONTH = "tenor_month";

    public static final String TENOR_YEAR = "tenor_year";

    public static final String DATA_FORMAT = "dd/MM/yyyy";

    public static final String ZERO_DOUBLE = "0.0";

    public static final String LONG_ENQ_LOANS = "010440";

    public static final String CURRENCYCODE = "CurrencyCode";

    public static final String NAME = "Name";

    public static final String DRAWINGPOWER = "DrawingPower";

    public static final String AMOUNTOUTSTANDING = "AmountOutstanding";

    public static final String SACTIONED_LIMIT = "Limit";

    public static final String INTERESTRATE = "InterestRate";

    public static final String CORE_ERRORS = "CORE_ERRORS";

    public static final String SWITCH_ERRORS = "SWITCH_ERRORS";

    public static final String OBJ_TRANSACTIONLEG = "OBJ_TRANSACTIONLEG";

    public static final String TRANSACTIONLEG = "TRANSACTIONLEG";

    public static final String P_DEBITLEG = "p_DebitTLeg";

    public static final String P_CREDITLEG = "p_CreditTLeg";

    public static final String P_TRANSACTIONNAME = "p_transactionName";

    public static final String JAVA_RETAIL_TRANSACTION_PROCESS_TRANSACTION_PROCNAME = "java_retail_transaction.processTransaction";
    //added for CR-2655 begin
    
    public static final String JAVA_RETAIL_TRANSACTION_PROCESS_SCHEDULE_TRANSACTION_PROCNAME = "java_retail_transaction.processScheduleTransaction";
    
    public static final String P_SCHEDULED_DATE = "p_scheduledDate";
    
    public static final String P_COMMISSION = "p_commission";
    //End CR-2655

    public static final String P_ERROR = "p_error";

    public static final String P_REFERENCE_NO = "p_referenceno";

    public static final String PERCENTAGE = "%";

    public static final String STATUS_CODE = "status_code";

    public static final String THIRD_PARTY_REF = "third_party_ref";

    public static final String ACCOUNTNAME_KEY = "accountNameKey";

    public static final String NC_DEBIT_ACCOUNT_DATA = "010|011|016|017";
    
    public static final String ACCRIG_DISP_ACC = "010|011|016|017|012|013|015|096|01C";

    public static final String NC_CREDIT_ACCOUNT_DATA = "010|011|016|017|015";

    public static final String NC_CREDIT_ACCOUNT_DATA1 = "01294";
    
    public static final String  REFERENCE_NO = "reference_no";
    
    public static final String CHEQUE_REQUEST = "CHQ";
    
    public static final String QUERY_FOR_REFERENCENO = "select java_retail_transaction.generateReferenceNo(?) refNo from dual";
    
    public static final String REFERENCE_NUMBER = "REFNO";

    public static final String TXN_STATUS_PROPERTY = "status.";
    
    public static final String TXN_NAME_PROPERTY  = "transactionName.";
    
   public static final String STANDING_INSTRUCTIONS = "SI";

    public static final String APPLY_NEW_ACCOUNT = "AA";
    
    public static final String SAVINGS = "Savings Account";
    
    public static final String CURRENT = "Current Account";
    
    public static final String TERM_DEPOSIT = "Term Deposit";
    
    public static final String RECURRING_DEPOSIT = "Recurring Deposit";
        
    public static final String CUMULATIVE = "Cumulative";
    
    public static final String NON_CUMULATIVE = "Non-Cumulative";      
    
    public static final String NRO = "NRO";
    
    public static final String NRE = "NRE";
    
    public static final String RESIDENT = "RES";
    
    public static final String NRNR = "NRNR";

    public static final String DEPOSIT_RENEW_DETAILS = "DR";
  
   /* added by Murugan K 14-12-05 */
    public static final String FROMAMOUNT = "from_amount";

    public static final String TTYPE = "transactionType";

    public static final String PROFILE_PWD = "PROFILE_PASSWORD";
    
//ADDED BY NAVEEN KUMAR 16/12/2005
    
    public static final String TO_BE_REPLACED = "#tobereplaced#";
    
    public static final String SPACE = " ";
    
    public static final String BIND_VARIABLE = "?";
    
    public static final String EQUAL = "=";
    
    public static final String COMA = ",";
     
    public static final String USER_NAME = "USER_NAME";
    
    public static final String LINKED_USER_NAME = "LINKED_USER_NAME";
    
    public static final String STATUS = "STATUS";

    public static final String COUNTRY_NAME_CODE ="countryNameCode";  //used to put the Country name and code in ReferenceDataCache

   /* 26/12/2005 */
    public static final String USER_ROLE = "USER_ROLE";
    
    public static final String THIRD_PARTY_ENQ_TXNNO = "069400";
    
    public static final String PRODUCT_CODE = "product_code";
  
    public static final String IB_REF_NO = "ref_no";
   
    public static final String DELIVERY_TYPE="bv_inbox_delivery"; 
    
    public static final Integer NOTIF_FREQ=new Integer(2);
    
    public static final String ISSUE_LIST = "issueList";
    
    public static final String P_TRANSACTIONPATH = "p_transactionpath";
    
    public static final String TXN_STATUS_UNKNOWN = "Unknown"; // instead of status "Unknown";
    
    public static final String USER_TYPE="USER_TYPE";
    
    //Added by srujana AppUploader on 28-03-06
    public final static String  EMP_NO = "employee_no";
    
    public static final String CORPORATE_ID ="corporate_id";
    
  public static final String CORPORATEID = "CORPORATE_ID";
  
    public static final String TRANSACTION_PRODUCT_TYPES = "A2|A3|A4";
    
    public static final String DEPOSIT_PRODUCT_TYPES = "A5";
    
    public static final String PPF_PRODUCT_TYPES = "B1";
    
    public static final String TRADE_PRODUCT_TYPES = "A8|A9";

    public static final String LOAN_PRODUCT_TYPES = "A6";

    public static final String SAVINGS_PRODUCT_TYPES = "A1"; 
    
    public static final String CORE_BM_ACCOUNT_NATURE = "BM_CORE";

	public static final String CORE_MIGRATION_DISPLAY = "CORE_MESSAGE_STATUS";

	public static final String FIELD_NAME = "FLD_NAME";
	 
	public static final String START_INDEX = "START_INDEX";
	 
	public static final String END_INDEX = "END_INDEX";

	
	public static final String CORPORATE_NAME="corporate_name";
	
	 public static final String CORPORATE_DD_LIMIT="corporate_dd_limit"; 
	    
	    public static final String AUDIT_USER="audit_user";
	        
	    public static final String NEXT_ECHEQUE_NO="next_echeque_no";
	    
	    public static final String UNAUDITED_COUNT="unaudited_count";
	    
	    public static final String MAX_UNAUDITED_AMOUNT="max_unaudited_amount";
	    
	    public static final String CREATED_BY_BRANCH="created_by_branch";
	     
	    public static final String MAKER_AUTH_PREF="maker_auth_pref";
	    
	    public static final String SMALL_FLAG="small_flag";
	        
	    public static final String USER_ADD_3P="user_add_3p";
	    
	    public static final String IGNORE_TRANSACTION="ignore_transaction";
	    
	    public static final String ADMIN_ADD_3P="admin_add_3p";
	    
	    public static final String TRANSACTION_MODE="transaction_mode";
	    
	    public static final String APPROVER_LEVEL="approver_level";
	    
	    public static final String NAME_THIRD_PARTY ="name_third_party";
	   
	    public static final String UPLOADER_USERNAME ="uploader_username";
	    
	    public static final String FILE_NAME="file_name";
	  
	    public static final String CORPORATE_TP_LIMIT = "corporate_tp_limit";
	    
	    public static final String CORPORATE_GOVT_LIMIT = "corporate_govt_limit"; //added for CR5269
        //Added by Sunjay S Galen
        
        public static final String SNO="sno";
        
        public static final String CREATION_TIME="creation_time";
		  //Added for CR 2921
        
        public static final String COMMISSION_TYPE="commission_type";

        /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
        public static final String NRE_PRODUCT_CODES ="nreProductCodes";
        
		//--5603
	    
		public static final String EMAIL_ID = "email_id";	

	    public static final String EMPLOYEE_CODE = "outref7";

		//--5603
	    
	    public static final String TRANSACTION_DATE = "transaction_date";
	    
	    // IR71227
	    
	    public static final String CLEARING_DATE = "clearing_date";
	    public static final String TRANSACTING_BRANCH = "transacting_branch";
	    public static final String TRANSACTION_AMOUNT = "transaction_amount";
	    public static final String CHEQUE_NO = "cheque_no";
	    public static final String NARRATION = "narration";
	    public static final String CLIENT_CODE = "client_code";
	    public static final String CLIENT_NAME = "client_name";
	    public static final String DRAWEE_BANK = "drawee_bank";
	    public static final String DEPOSIT_SLIP_NO = "deposit_slip_no";
	    public static final String DRAWEE_ACCOUNT = "drawee_account";
	    public static final String TRANSACTION_DESC = "transaction_desc";
	    public static final String FILENAME = "filename";
	    //CLTD/MOD
	    public static final String MOD_BALANCE="mod_balance";
	  //Added for Voice OTP
	    public static final String VOICE_OTP_SERIES ="voiceOTPSeries";
	     //E-suvidha
	    static final String PIS_ACCOUNTS = "_PISAccounts";
	    
	    //Added for eTDR/eSTDR
		public static final String TENOR_IN_DAYS = "tenureInDays";
		
		//Added for Benificiary file revamp -Start
		public static final String MODE_CONFIG="mode_config";
	    
	    public static final String FORMAT="format";
	    
	    public static final String FIELD_DELIMITER="field_delimiter"; 
	    
	    public static final String RECORD_DELIMITER="record_delimiter";
	    
	    public static final String OID="oid";
	    
	    public static final String ID="id";
	    
	    public static final String CORPORATE_TYPE="corporate_type";
	    
		public static final String ORDER_NO = "order_no";
		
		public static final String FLD_NAME = "fld_name";
		
		public static final String OUT_REF1 = "outref1";

		public static final String OUT_REF2 = "outref2";

		public static final String OUT_REF3 = "outref3";

		public static final String OUT_REF4 = "outref4";

		public static final String OUT_REF5 = "outref5";

		public static final String OUT_REF6 = "outref6";

		public static final String OUT_REF7 = "outref7";
		
		//Added for Benificiary file revamp -End

//Added for Transaction file revamp -Start
		
		public static final String SAME_BANK = "same_bank";
		
		public static final String OTHER_BANK = "other_bank";
		
		public static final String BOTH_BANK = "both_bank";
		
		
		
		//Added for Transaction file revamp -End
		//Issued cheque details constants start
	    public static final String ACC_NO = "ACCOUNT_NO";	  
	    public static final String CHEQUE_DATE = "CHEQUE_DATE";
	    public static final String AMT = "AMOUNT";
	    public static final String BEN_NAME = "BENEFICIARY_NAME";
	    public static final String REQ_TYPE = "REQUEST_TYPE";
	    public static final String STATUS_DESC = "STATUS_DESC";   
	    //Issued chequedetails constants end

} 
