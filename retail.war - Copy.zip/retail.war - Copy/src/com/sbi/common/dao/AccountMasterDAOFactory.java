
/*
 * AccountMasterDAOFactory
 * Created on Oct 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 16, 2005 MURUGAN K - Initial Creation
//Jan 18, 2005 KRISHNA KUMAR - transactionAccountMasterDAOImpl is called for type other than A5 and A6

package com.sbi.common.dao;

import org.apache.log4j.Logger;

/**
 * TODO AccountMasterDAOFactory
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class AccountMasterDAOFactory
{
    protected final Logger log = Logger.getLogger(getClass());   
    /**
         * 
         */
    private AccountMasterDAO transactionAccountMasterDAOImpl;   
    private AccountMasterDAO loanAccountMasterDAOImpl;
    private AccountMasterDAO depositAccountMasterDAOImpl;
    private AccountMasterDAO tradeAccountMasterDAOImpl;
    
    /**
     * TODO Returns the child instance of AccountMasterDAO based on the parameter passed
     * @param accountmaster
     * @return AccountMasterDAO
     */
    
    public AccountMasterDAO getInstance( String accountType)
        {
              
         
        if(accountType.equals("A5")) 
               {
            
            
                return depositAccountMasterDAOImpl;  
                
               }
             else
                 if(accountType.equals("A6"))
                 {
                     return loanAccountMasterDAOImpl;
                 
                 }
                 else if (accountType.equals("A8")||accountType.equals("A9"))
                 {
                	 return tradeAccountMasterDAOImpl;
                 }
                 else{   
                         return transactionAccountMasterDAOImpl;
                     }
        
        }
  /**
 * TODO TransactionAccountMasterDAOImpl object injection
 * @param transactionMasterDAOimpl void
 */

public void setTransactionAccountMasterDAOImpl(AccountMasterDAO transactionMasterDAOimpl)        
  {
      
   this.transactionAccountMasterDAOImpl=transactionMasterDAOimpl ;
  }

/**
 * TODO DepositAccountMasterDAOImpl object injection
 * @param depositAccountDAOImpl void
 */

public void setDepositAccountMasterDAOImpl(AccountMasterDAO depositAccountDAOImpl)
  {
    this.depositAccountMasterDAOImpl = depositAccountDAOImpl;  
  }
 
 /**
 * TODO LoanAccountMasterDAOImpl object injection
 * @param loanAccountMasterDAOImpl void
 */
public void setLoanAccountMasterDAOImpl(AccountMasterDAO loanAccountMasterDAOImpl)
 {
   this.loanAccountMasterDAOImpl = loanAccountMasterDAOImpl;
  }
public void setTradeAccountMasterDAOImpl(
		AccountMasterDAO tradeAccountMasterDAOImpl) {
	this.tradeAccountMasterDAOImpl = tradeAccountMasterDAOImpl;
}
}
