/*
 * CorporateProfileDAOImpl.java
 * Created on Dec 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 8, 2005 SG33414 - Initial Creation
/**
 * @(#) CorporateProfileDAO.java
 */

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.authentication.algorithm.Sha512Hashing;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Address;
import com.sbi.common.model.CorporateProfile;
import com.sbi.common.model.SPOutput;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.EncryptMD5;
import com.sbi.common.utils.LoggingConstants;

   
/**
 * TODO Enter the description of the class here
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class CorporateProfileDAOImpl extends JdbcDaoSupport implements
		CorporateProfileDAO {

	private Sha512Hashing sha512Hashing; //Added for sha
	
	protected final Logger logger = Logger.getLogger(getClass());
  
	static final String CORPORATE_DETAILS = "select * from sbicorp_corporate_profile where corporate_id=?";
	//5472
	static final String GET_PROFILE_DETAILS_USERNAME = "SELECT b.user_alias,c.NAME, c.address, c.city, c.district, c.department, c.zip, c.state,c.employee_no,c.friendly_name, c.designation, c.email, c.home_phone,c.country, c.user_id,c.branch_code, c.mobile_no FROM bv_user b, bv_user_profile c WHERE b.user_alias=? and b.user_id = c.user_id";//Changed For Defect CR 5472 
	static final String INSERT_RESET_PWD_PPKIT= "Insert into sbicorp_resetpwd_ppkit " +
		"(STATUS,USER_NAME,CA_USER,USER_ROLE,CREATION_TIME,LAST_MOD_TIME,PASSWORD_STATUS,BRANCH_CODE,ISSUED_BY) " +
 		"values (1,?,?,?,sysdate,sysdate,'pending',null,null)";
	/**
	 * executes Query to display Corporate Profile Details Select * from
	 * SBICORP_CORPORATE_PROFILE where CorporateID =
	 * 
	 * CorporateID should be added in .....Corporate ID from UserSession Cache
	 * ...as UserProfile details are available in UserSessioncache
	 */
	/**
	 * This Method is used for find the corporateprofile Details Form sbicorp_corporate_profile
	 * and returns CorporateProfile Object
	 */
	public CorporateProfile findCorporateProfileDetails(String corporateID) {
		logger.info("findCorporateProfileDetails( String corporateID )"
				+ LoggingConstants.METHODBEGIN);
		logger.info("corporateID :" + corporateID);

		if (logger.isDebugEnabled())
			logger.debug("corporateID :" + corporateID);

		List result = new ArrayList();

		List maxLimit = new ArrayList();

		CorporateProfile corporateProfile = null;

		if (corporateID != null
				&& !corporateID.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
			try {
				Object[] parameters = new Object[] { corporateID };

				result = getJdbcTemplate().query(
						CORPORATE_DETAILS, parameters,
						new CorporateRowMapper());
				logger.info("Max Limit corporateProfile :" + corporateProfile);
				logger.info("MaxLimit :" + maxLimit);
				logger.info("Result :" + result);
				if (logger.isDebugEnabled()) {
					logger.debug("Result :" + result);
					logger.debug("MaxLimit :" + maxLimit);
				}
				logger.info("findCorporateProfileDetails( String corporateID )"
						+ LoggingConstants.METHODEND);
				if (result.size() > 0) {
					corporateProfile = ((CorporateProfile) result.get(0));
					logger.info("corporateProfile result :"+ corporateProfile);
				} else {
					DAOException.throwException(ErrorConstants.DATA_NOT_FOUND);
				}

			} catch (DataAccessException exception) {
				DAOException.throwException(
						ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
			}
		} else {
			DAOException
					.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("findCorporateProfileDetails( String corporateID )"
				+ LoggingConstants.METHODEND);
		return corporateProfile;
	}

	class CorporateRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CorporateProfile 
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			CorporateProfile corporateProfile = new CorporateProfile();
			corporateProfile.setCorporateID(rs
					.getString(DAOConstants.CORPORATE_ID));
			corporateProfile.setCorporateName(rs
					.getString(DAOConstants.CORPORATE_NAME));
			corporateProfile.setCorporateDDLimit(new Double(rs
					.getDouble(DAOConstants.CORPORATE_DD_LIMIT)));
			corporateProfile.setCorporateTPLimit(new Double(rs
					.getDouble(DAOConstants.CORPORATE_TP_LIMIT)));
			corporateProfile.setAuditUser(new Integer(rs
					.getInt(DAOConstants.AUDIT_USER)));
			corporateProfile.setNextEchequeNo(rs
					.getString(DAOConstants.NEXT_ECHEQUE_NO));
			corporateProfile.setUnauditedCount(new Integer(rs
					.getInt(DAOConstants.UNAUDITED_COUNT)));
			corporateProfile.setMaxUnauditedAmount(new Double(rs
					.getDouble(DAOConstants.MAX_UNAUDITED_AMOUNT)));
			corporateProfile.setCreatedByBranch(rs
					.getString(DAOConstants.CREATED_BY_BRANCH));
			corporateProfile.setMakerAuthPreference(new Integer(rs
					.getInt(DAOConstants.MAKER_AUTH_PREF)));
			corporateProfile.setSmallFlag(new Integer(rs
					.getInt(DAOConstants.SMALL_FLAG)));
			corporateProfile.setUserAddThirdParty(new Integer(rs
					.getInt(DAOConstants.USER_ADD_3P)));
			corporateProfile.setIgnoreTransaction(new Integer(rs
					.getInt(DAOConstants.IGNORE_TRANSACTION)));
			corporateProfile.setAdminAddThirdParty(new Integer(rs
					.getInt(DAOConstants.ADMIN_ADD_3P)));
			corporateProfile.setTransactionMode(new Integer(rs
					.getInt(DAOConstants.TRANSACTION_MODE)));
			corporateProfile.setApproverLevel(new Integer(rs.getInt(DAOConstants.APPROVER_LEVEL)));
			corporateProfile.setBulkAuthNeeded(new Integer (rs.getInt("BULK_AUTH_NEEDED")));
			corporateProfile.setDdebitRequired(rs.getString("DDEBIT_REQUIRED"));
			corporateProfile.setDdebitEchequeApprovel(rs.getString("DDEBIT_ECHEQUE_APPROVAL"));
			corporateProfile.setDdebitDealerVerification(rs.getString("DDEBIT_DEALER_VERIFICATION"));
			//  Added for CR 2108
            corporateProfile.setFileAuth(rs.getString("FILE_AUTHORIZE"));
            //  End of CR 2108		
            //added for RTGS/NEFT
            corporateProfile.setAddress1(rs.getString("corporate_address1"));
            corporateProfile.setAddress2(rs.getString("corporate_address2"));
            corporateProfile.setCity(rs.getString("corporate_city"));
            corporateProfile.setState(rs.getString("corporate_state"));
            corporateProfile.setZip(rs.getString("corporate_pincode"));
             //Added for CR 2302
            corporateProfile.setValidateCreditAccount(rs.getString("VALIDATE_CREDIT_ACCOUNT"));
            //End of CR 2302
            // CR2435
            corporateProfile.setApproverLevel3p(rs.getString("approver_level_3p"));
           //Added for Cr 2921
            //Added for Cr 2921
            corporateProfile.setCommissionType(rs.getString(DAOConstants.COMMISSION_TYPE));
			corporateProfile.setCorporateGovtLimit(new Double(rs.getDouble(DAOConstants.CORPORATE_GOVT_LIMIT)));
			//added for nab
			corporateProfile.setCorporateType(rs.getString("CORPORATE_TYPE"));
			corporateProfile.setReconFlag(rs.getString("RECON_FLAG"));//Added For CR 5588
			
			/* Added by Sairam Mobile Registration Phase2 - Start */
			corporateProfile.setEhsEnable(rs.getString("EHS_ENABLED"));
			corporateProfile.setEhsType(rs.getString("EHS_TYPE"));
			corporateProfile.setMcaEnable(rs.getString("MCA_ENABLED"));
			
			/* Added by Sairam Mobile Registration Phase2 - End */
			
			// Added by Sairaj for CRN Validation Status

			corporateProfile.setcrnValidationStatus(rs.getString("CRN_VALIDATION_STATUS"));
			
			// The below statement should be removed in Prod
			
			//corporateProfile.setcrnValidationStatus(rs.getString("DDEBIT_REQUIRED"));

			//Below code added for BEneficiary revamp form based
			
			corporateProfile.setBeneficiaryFlag(rs.getString("BENEFICIARY_FLAG"));
			
			return corporateProfile;
		}
	}
	//5472
	public String[][] getResetPassUserDetails(String caUser, String roleID, String corporateID) throws DAOException
    {
		//query changed for CR5552
        String GET_USER_DETAILS_FLAG_NULL = "SELECT   NAME || '-' || user_alias NAME, user_alias || '|' || a.user_type user_alias FROM sbicorp_ca_user_map a, bv_user b, bv_user_role c, bv_user_profile d WHERE b.user_id = d.user_id AND ca_user = ? AND a.user_name = b.user_alias AND b.user_id = c.user_id AND c.user_role = ? AND a.status = 1 AND b.user_state = 0 ORDER BY UPPER (NAME)";
        logger.info("getUserDetailssss(String caUser,String roleID,String lockFlag) method begin");
        List userDetailsList = null;
        String[][] userNamesData = null;
        if (caUser == null || roleID == null || (caUser.trim()).equals("") || (roleID.trim()).equals(""))
        {
            DAOException.throwException("CR011");
        }
        logger.info("causer =" + caUser);
        logger.info("roleId =" + roleID);
        try
        {

            Object[] parameters = new Object[] { caUser, roleID};
            logger.info(SQLConstants.GET_USER_DETAILS_FLAG_NULL);
            String querytobeExecuted=GET_USER_DETAILS_FLAG_NULL;
            if(roleID.equals("13")){
            	parameters = new Object[] { roleID, corporateID};
            	querytobeExecuted="select c.name|| '-' || a.user_alias NAME,a.user_alias from bv_user a,bv_user_role b,bv_user_profile c," +
            			"sbicorp_ca_corporate_map t where a.user_id=b.user_id and a.user_id=c.user_id " +
            			"and b.user_role=? and a.user_alias=t.ca_user and t.status=1 and t.corporate_id=? order by upper(c.name)";
            }
            userDetailsList = getJdbcTemplate().query(querytobeExecuted, parameters,
                    new UserDetailsRowMapper());
            if (userDetailsList != null && userDetailsList.size() > 0)
            {

                HashMap data = (HashMap) userDetailsList.get(0);
                userNamesData = new String[data.size()][2];
                int i = 0;
                String tempKey = null;
                for (Iterator iterate = data.keySet().iterator(); iterate.hasNext(); i++)
                {
                    tempKey = (String) iterate.next();
                    userNamesData[i][1] = tempKey;
                    userNamesData[i][0] = (String) data.get(tempKey);
                }
            }
        }
        catch (DataAccessException exception)
        {
            DAOException.throwException("F001", exception);
        }
        return userNamesData;
    }
	 
	/* Ramanan M - Corp Admin Paladion Security Changes */
	 public SPOutput resetLoginPassword(String userName,String passWord, String corporateID) throws DAOException
	    {
	        logger.info("resetLoginPassword(String userName,String passWord, String corporateID) method start");
	        SPOutput spOutput = new SPOutput();
	        int updateCount;
	        logger.info("userName==" + userName+" && CorporateID==" + corporateID );
	        if (userName != null)
	        {
	            try
	            {
	                logger.info("userName::" + userName);
	                //String passWord = generator.generateRandomWord(8); //Commented for CR 5143
	                /* Ramanan M - Corp Admin Paladion Security Changes */
//	                String updatePassword="update bv_user set password=? where user_alias=?";
	                String updatePassword="update bv_user set password=? where user_alias =? and user_id in (select user_id from bv_user_profile where corporate_id = ?)";	                 //Modified for CR 2885                 
	                 String encMD5Password=EncryptMD5.hashMessage(userName + "#" + passWord);
	                String encPassword =null;
	                encPassword = sha512Hashing.hashingSHA2(userName+ "#" + passWord); //SHA-512 Changes
	                logger.info("encPassword>>>>>>>>>>>>####>"+encPassword);
	                Object[] Params={encPassword,userName, corporateID};
	                updateCount =  getJdbcTemplate().update(updatePassword,Params);
	                logger.info("update Count:: "+updateCount);
	                
	                
	                //Added for SHA -Start
	                Object tempParams[] = new Object[] {userName, encMD5Password};
	        		int tempSqlTypes[] = {Types.VARCHAR, Types.VARCHAR};
	        		String tempSql = "insert into bv_user_temp_password(username, password,creation_time) values (?,?,sysdate)";
	        		int tempUpdateCount = getJdbcTemplate().update(tempSql, tempParams, tempSqlTypes);
	        		logger.info("no of rows inserted in bv_user_temp_password table"+tempUpdateCount);
	              
	        	    
	                logger.info("Succesffully updatePassword::"+updatePassword);
	                
	                if(updateCount >= 1) {
		                List parameterList = new ArrayList();
		                Map inParams = new HashMap();
		                inParams.put("USER_NAME", userName);
		                inParams.put("PWD", passWord);
		                inParams.put("PWD1", passWord);
		                parameterList.add(new SqlParameter("USER_NAME", Types.VARCHAR));
		                parameterList.add(new SqlParameter("PWD", Types.VARCHAR));
		                parameterList.add(new SqlParameter("PWD1", Types.VARCHAR));
		                parameterList.add(new SqlOutParameter("P_ERR_MSG", Types.VARCHAR));
		                parameterList.add(new SqlOutParameter("P_ERR_CODE", Types.VARCHAR));
	
		                CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(
		                        "{call PKG_CORPORATE_ADMIN.PR_GEN_PASSWORD(?,?,?,?,?)}", parameterList);
		                CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);
		                Map result = getJdbcTemplate().call(callableStatement, parameterList);
	
		                String errorMsg = (String) result.get("P_ERR_MSG");
		                String errorCode = (String) result.get("P_ERR_CODE");
		              
		                //Changed for SHA -512
		                if(errorCode.equalsIgnoreCase("SP001")){
		                
		                	String updateLoginHashing="update bv_user_profile set LOGIN_PASSWORD_HASHING='SHA-512' where user_id in (select user_id from bv_user where user_alias = ?)";
		                	 Object[] HashingParams={userName};
		 	                updateCount =  getJdbcTemplate().update(updateLoginHashing,HashingParams);
		 	                logger.info("update Count in BV_user_profile:: "+updateCount);
		 	              
		                }
	
		                logger.info("result :" + result);
		                logger.info("P_ERR_MSG :" + errorMsg);
		                logger.info("P_ERR_CODE :" + errorCode);
	
		                spOutput.setErrorCode(errorCode);
		                spOutput.setErrorMessage(errorMsg);
	                } else {
	                	/* Ramanan M - Corp Admin Paladion Security Changes */
	                	spOutput.setErrorCode("SP999");
	                }

	            }
	            catch (Exception excep)
	            {
	                logger.info(LoggingConstants.EXCEPTION + excep);
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, excep);
	            }

	            logger.info("spOutput :" + spOutput);

	            if (spOutput.getErrorCode().equalsIgnoreCase("SP999"))
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

	            logger.info("resetLoginPassword(String userName)" + LoggingConstants.METHODEND);

	            return spOutput;

	        }
	        else
	        {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }

	        return null;

	    }
	
	//shanta
	   
	 public SPOutput resetLoginPassword(String userName,String passWord) throws DAOException
	    {
	        logger.info("resetLoginPassword(String userName,String passWord) method start");
	        SPOutput spOutput = new SPOutput();
	        logger.info("userName==" + userName);
	        if (userName != null)
	        {
	            try
	            {
	                logger.info("userName::" + userName);
	                //String passWord = generator.generateRandomWord(8); //Commented for CR 5143
	                String updatePassword="update bv_user set password=? where user_alias=?";
	                 //Modified for CR 2885                 
	                 String encPassword=EncryptMD5.hashMessage(userName + "#" + passWord);
	                 Object[] Params={encPassword,userName};
	                 getJdbcTemplate().update(updatePassword,Params);
	                 logger.info("Succesffully updatePassword::"+updatePassword);
	                 
	                List parameterList = new ArrayList();
	                Map inParams = new HashMap();
	                inParams.put("USER_NAME", userName);
	                inParams.put("PWD", passWord);
	                inParams.put("PWD1", passWord);
	                parameterList.add(new SqlParameter("USER_NAME", Types.VARCHAR));
	                parameterList.add(new SqlParameter("PWD", Types.VARCHAR));
	                parameterList.add(new SqlParameter("PWD1", Types.VARCHAR));
	                parameterList.add(new SqlOutParameter("P_ERR_MSG", Types.VARCHAR));
	                parameterList.add(new SqlOutParameter("P_ERR_CODE", Types.VARCHAR));

	                CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(
	                        "{call PKG_CORPORATE_ADMIN.PR_GEN_PASSWORD(?,?,?,?,?)}", parameterList);
	                CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);
	                Map result = getJdbcTemplate().call(callableStatement, parameterList);

	                String errorMsg = (String) result.get("P_ERR_MSG");
	                String errorCode = (String) result.get("P_ERR_CODE");

	                logger.info("result :" + result);
	                logger.info("P_ERR_MSG :" + errorMsg);
	                logger.info("P_ERR_CODE :" + errorCode);

	                spOutput.setErrorCode(errorCode);
	                spOutput.setErrorMessage(errorMsg);

	            }
	            catch (Exception excep)
	            {
	                logger.info(LoggingConstants.EXCEPTION + excep);
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, excep);
	            }

	            logger.info("spOutput :" + spOutput);

	            if (spOutput.getErrorCode().equalsIgnoreCase("SP999"))
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

	            logger.info("resetLoginPassword(String userName)" + LoggingConstants.METHODEND);

	            return spOutput;

	        }
	        else
	        {
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	        }

	        return null;

	    }
	 public UserProfile getUserProfileDetails(String userName) throws DAOException
	    {
	        logger.info("getUserProfileDetails(String userName) method begin");
	        UserProfile userProfile = null;
	        logger.info("userName =" + userName);
	        if (userName == null || (userName.trim()).equals("") )
	        {
	            logger.info("input null");
	            DAOException.throwException("CR011");
	        }
	        try
	        {
	            Object[] parameters = new Object[] { userName };
	            List userProfileList = getJdbcTemplate().query(GET_PROFILE_DETAILS_USERNAME, parameters,
	                    new ProfileDetailsRowMapper()); //added for revamp
	            logger.info("userProfileList " + userProfileList);
	            /* Ramanan M - Corp Admin Paladion Security Changes */ // Changed the condition userProfileList.size() == 1 as userProfileList.size() >= 1
	            if (userProfileList != null && userProfileList.size() >= 1)
	            {
	                logger.info("User Profile Details are:" + userProfileList.get(0));
	                logger.info("getProfileDetails(Integer empno, String corpID) method end");
	                userProfile = ((UserProfile) userProfileList.get(0));
	            }
	            else 
	            {
	            	 logger.info("userProfileList is null");
	            	 DAOException.throwException("F001");
	            }

	        }
	        catch (DAOException exception)
	        {
	            logger.info("exception occured ");
	            DAOException.throwException("F001", exception);
	        }
	        logger.info("getUserProfileDetails(String userName) method ends");
	        return userProfile;
	    }
	 public UserProfile insertResetPWDPPKit(Map inParams) throws DAOException{
		 logger.info("insertResetPWDPPKit(Map inParams)  method begin");
		 String userName=(String) inParams.get("userName");
		 String caUser=(String) inParams.get("caUser");
		 String userRole=(String) inParams.get("userRole");
		 UserProfile userProfile=null;
	        logger.info("userName =" + userName);
	        logger.info("admin name :::"+caUser);
	        logger.info("User Role  :::"+userRole);
	        if (userName == null || (userName.trim()).equals("") || caUser == null || (caUser.trim().equals("")) || userRole == null || (userRole.trim().equals(""))) 
	        {
	            logger.info("input null");
	            DAOException.throwException("CR011");
	        }
	        try
	        {           
		        	Object[] parameters = new Object[] {userName ,caUser,Integer.parseInt(userRole)};
		            int rowsInserted = getJdbcTemplate().update(INSERT_RESET_PWD_PPKIT, parameters);
		            logger.info("rowsInserted: " + rowsInserted);
		            if (rowsInserted > 0)
		            {
		            	userProfile=getUserProfileDetails(userName);
		                logger.info("Inserted successfully to sbicorp_resetpwd_ppkit");
		                return userProfile;
		            }
	        }
	        catch (DAOException exception)
	        {
	            logger.info("exception occured ");
	            DAOException.throwException("F001", exception);
	        }
	        logger.info("insertResetPWDPPKit(Map inParams)  method end");
	        return null;
		}
	 public boolean isRequestSubmitted(Map inParams) throws DAOException{
		 logger.info("isRequestSubmitted(Map inParams) method begin");
		 String userName=(String) inParams.get("userName");
		 String caUser=(String) inParams.get("caUser");
		 String userRole=(String) inParams.get("userRole");
		 boolean isExists=false;
	        logger.info("userName =" + userName);
	        logger.info("admin name :::"+caUser);
	        logger.info("User Role  :::"+userRole);
	        if (userName == null || (userName.trim()).equals("") || caUser == null || (caUser.trim().equals("")) || userRole == null || (userRole.trim().equals(""))) 
	        {
	            logger.info("input null");
	            DAOException.throwException("SE003");
	        }
	        String query="select count(0) from sbicorp_resetpwd_ppkit where user_name=? and ca_user=? and password_status='pending'";
	        try
	        {
	            //check for duplication
	        	Object[] params1={userName,caUser};
				if(getJdbcTemplate().queryForInt(query,params1) > 0){
					logger.info("Request has been Registered already. ");
					isExists=true;
				}
	        }
	        catch (DAOException exception)
	        {
	            logger.info("exception occured ");
	            DAOException.throwException("F001", exception);
	        }
	        logger.info("isRequestSubmitted(Map inParams) method end");
	        return isExists;
		}
	 /* Ramanan M - Corp Admin Paladion Security Changes */
	 public boolean isValidUserForCorporate(String userName, String corporateID) throws DAOException{
		 logger.info("isValidUserForCorporate(String userName, String corporateID) method begin");
		 boolean isExists=false;
	        logger.info("userName =" + userName);
	        logger.info("corporateID :::"+corporateID);
	        if (userName == null || (userName.trim()).equals("") || corporateID == null || (corporateID.trim().equals(""))) 
	        {
	            logger.info("input null");
	            DAOException.throwException("SE003");
	        }
	        String query="select count(*) as count from bv_user_profile where user_id in ( select user_id from bv_user where user_alias = ? ) and corporate_id = ?";
	        try
	        {
	            //check for duplication
	        	Object[] params1={userName, corporateID};
				if(getJdbcTemplate().queryForInt(query,params1) > 0){
					logger.info("Valid User : " +userName +" for the CorporateID : " + corporateID);
					isExists=true;
				}
	        }
	        catch (DAOException exception)
	        {
	            logger.info("exception occured ");
	            DAOException.throwException("F001", exception);
	        }
	        logger.info("isValidUserForCorporate(String userName, String corporateID) method end");
	        return isExists;
		}
	 
	class UserDetailsRowMapper implements RowMapper
    {
        Map userNames = new LinkedHashMap();
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            userNames.put(rs.getString("USER_ALIAS"), rs.getString("NAME"));
            return userNames;
        }
    }
	
	class ProfileDetailsRowMapper implements RowMapper
    {

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            Address address = new Address();
            UserProfile userProfile = new UserProfile();
            userProfile.setUserAlias(rs.getString("USER_ALIAS"));
            userProfile.setName(rs.getString("NAME"));
            address.setAddress1(rs.getString("ADDRESS"));
            address.setCity(rs.getString("CITY"));
            userProfile.setDistrict(rs.getString("DISTRICT"));
            address.setPin(rs.getString("ZIP"));
            address.setState(rs.getString("STATE"));
            address.setCountry(rs.getString("COUNTRY"));
            userProfile.setAddress(address);
            userProfile.setEmail(rs.getString("EMAIL"));
            userProfile.setHomePhone(rs.getString("HOME_PHONE"));
            userProfile.setFriendlyName(rs.getString("FRIENDLY_NAME"));
            userProfile.setDesignation(rs.getString("DESIGNATION"));
            userProfile.setDepartment(rs.getString("DEPARTMENT"));
            userProfile.setEmpNo(rs.getString("EMPLOYEE_NO"));
            userProfile.setUserId(new Integer(rs.getInt("USER_ID")));
            userProfile.setBranchCode(rs.getString("BRANCH_CODE"));
            userProfile.setMobileNumber(rs.getString("MOBILE_NO"));            
            return userProfile;
        }
    }
	//	Added for sha
	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}
}

			  
			
			
			
			
			