/*
 * LocatorsDAO.java
 * Created on Jan 31, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 31, 2006 MANIKANDAN - Initial Creation


package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;

public interface LocatorsDAO {
	String[] findBranch() throws DAOException;
	String[] findPBBBranches() throws DAOException;
	String[] findForexBranches() throws DAOException;
	String[] findInternetBankingBranches()throws DAOException;
	String[] findATMBranches()throws DAOException;
	Map findBranchDetails(String branchCode)throws DAOException;
	String[] findComerialBranches()throws DAOException;
	String[] findAgriculturalBranches()throws DAOException;
	List findNetBankingBranchDetails(String location) throws DAOException;
	String[] findNetBankingBranches(String bankCode,String bankCode1)throws DAOException;
	String[] findLocations(String state,String type)throws DAOException;
	String[] findLocationsForDistrict(String state,String type)throws DAOException;
	List findLocationDetails(String state,String location,String type) throws DAOException;
	String[] findTeleBankingBranches() throws DAOException;
	List findLocationDetailsForDistrict(String state,String location,String type)throws DAOException;

}
 