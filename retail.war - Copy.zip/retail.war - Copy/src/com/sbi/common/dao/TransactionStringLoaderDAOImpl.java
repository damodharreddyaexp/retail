/**
 * @(#) TransactionStringLoaderCommand.java
 */

package com.sbi.common.dao;

import java.sql.Types;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.BankSystemComModel;

public class TransactionStringLoaderDAOImpl extends JdbcDaoSupport implements TransactionStringLoaderDAO 
{
	private Logger logger = Logger.getLogger(getClass());
	public void load( BankSystemComModel bankSystemComModel ) throws DAOException
	{
		logger.info("BankSystemComModel : " + bankSystemComModel);
		String updateQuery="insert into sbi_transaction_legs(REFERENCE_NO,STEP_ID,DEBIT_ACCOUNT_NO,DEBIT_BRANCH_CODE,CREDIT_ACCOUNT_NO,CREDIT_BRANCH_CODE,AMOUNT,REQUEST_STRING,TRANSACTION_TYPE,BANK_SYSTEM,ORIGINAL_DEBIT_REFERENCE_NO,TXNNO,TRANSACTION_STATUS)  values(?,?,?,?,?,?,?,?,?,?,?,?,'F4')";
		try{
			
			logger.info("REFERENCE_NO :::::::::::: "+bankSystemComModel.getReferenceNo());
			logger.info("STEP_ID :::::::::::: "+bankSystemComModel.getStepId());
			logger.info("DEBIT_ACCOUNT_NO :::::::::::: "+bankSystemComModel.getDebitAcccountNo());
			logger.info("DEBIT_BRANCH_CODE :::::::::::: "+bankSystemComModel.getDebitBranchCode());
			logger.info("CREDIT_ACCOUNT_NO :::::::::::: "+bankSystemComModel.getCreditAccountNo());
			logger.info("CREDIT_BRANCH_CODE :::::::::::: "+bankSystemComModel.getCreditBranchCode());
			logger.info("AMOUNT :::::::::::: "+bankSystemComModel.getAmount());
			logger.info("REQUEST_STRING :::::::::::: "+bankSystemComModel.getRequestString());
			logger.info("TRANSACTION_TYPE :::::::::::: "+bankSystemComModel.getTransactionLeg());
			
			logger.info("BANK_SYSTEM :::::::::::: "+bankSystemComModel.getBankSystem());
			logger.info("ORIGINAL_DEBIT_REFERENCE_NO :::::::::::: "+bankSystemComModel.getOriginalDebitReferenceNo());
			logger.info("TXNNO :::::::::::: "+bankSystemComModel.getTxnNo());
			
			
			logger.debug("Setting values for "+bankSystemComModel.getReferenceNo());
			logger.debug("BankSystemComModel:" + bankSystemComModel);
				Object[] params={bankSystemComModel.getReferenceNo(),
								bankSystemComModel.getStepId(),
								bankSystemComModel.getDebitAcccountNo(),
								bankSystemComModel.getDebitBranchCode(),
								bankSystemComModel.getCreditAccountNo(),
								bankSystemComModel.getCreditBranchCode(),
								bankSystemComModel.getAmount(),
								bankSystemComModel.getRequestString(),
								bankSystemComModel.getTransactionLeg(),
								bankSystemComModel.getBankSystem(),
								bankSystemComModel.getOriginalDebitReferenceNo(),
								bankSystemComModel.getTxnNo()
								};
				int[] types={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.DOUBLE,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
			getJdbcTemplate().update(updateQuery,params,types);
			logger.debug("Inserting into SBI_TRANSACTION_LEGS");
		}catch(DataAccessException dataAccessException){
			Object[] errorParams={bankSystemComModel.getReferenceNo(),bankSystemComModel.getStepId()};
			DAOException.throwException(dataAccessException,"TXNSL001",errorParams);
		}
	}
	public void update(Map response,BankSystemComModel bankSystemComModel)throws DAOException{
		String query = "update sbi_transaction_legs set RESPONSE_STRING = ? ,TRANSACTION_STATUS=?, STATUS_DESCRIPTION=?, ERROR_CODE=? where REFERENCE_NO = ? and STEP_ID=?";
		if(response != null && response.size() > 0 ){
			String transactionStatus = "";
			String errorDescription = (String)response.get("statement");
			String errorCode = (String)response.get("error_code");
			if(bankSystemComModel.getBankSystem().equalsIgnoreCase("Core")){
				transactionStatus = (String)response.get("status");
				//if the bank system is core and status = 'ERR.' and error_code 
				//in ('0155','0112','0160','a','b') status = 'REP.'
				Set set = new HashSet();
				set.add("0155");
				set.add("0112");
				set.add("0160");
				if(transactionStatus != null && transactionStatus.trim().length() > 0){
					if(transactionStatus.equals("O.K."))
						transactionStatus = "00";
					else if( set.contains(errorCode) && transactionStatus.equalsIgnoreCase( "ERR." ))
						transactionStatus = "REP.";
					else if( transactionStatus.equalsIgnoreCase("U"))
						transactionStatus="LOG.";
					else if(transactionStatus.equalsIgnoreCase("P"))
						transactionStatus="00";
				}else
					transactionStatus = "F1";
			}
			if(bankSystemComModel.getBankSystem().equalsIgnoreCase("Non-Core")){
				String status = (String)response.get("STATUS");
				logger.info("Transaction Status : " + status);
				if(status != null && status.trim().length() > 0){
					if(status.equals("00") || status.equals("F1") || status.equals("F2") || status.equals("08"))
						transactionStatus = status;
					else{
						transactionStatus="ERR.";
						errorCode=status;
					}
				}else
					transactionStatus = "F1";
			}
			try{
				Object[] params = {bankSystemComModel.getResponseString(),transactionStatus,errorDescription,errorCode,bankSystemComModel.getReferenceNo(),bankSystemComModel.getStepId()};
				int[] types={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
				getJdbcTemplate().update(query,params,types);
			}catch(DataAccessException dataAccessException){
				logger.info("Unable to update the response into SBI_TRANSACTION_LEGS for the transaction: " + bankSystemComModel.getReferenceNo() + "#" + bankSystemComModel.getStepId());
				logger.info("Error Message : " + dataAccessException.getMessage());
				logger.error("Error occured :" , dataAccessException);
				dataAccessException.printStackTrace();
			}
		}
		
	}
}
