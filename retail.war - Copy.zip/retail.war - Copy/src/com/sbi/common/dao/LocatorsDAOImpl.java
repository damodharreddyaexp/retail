/*
 * LocatorsDAOImpl.java
 * Created on Feb 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 1, 2006 MANIKANDAN - Initial Creation


package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

public class LocatorsDAOImpl extends JdbcDaoSupport implements LocatorsDAO {
	protected final Logger logger=Logger.getLogger(getClass());
	public String[] findAgriculturalBranches() throws DAOException {
		logger.info("findAgriculturalBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_AGRICULTURAL_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findAgriculturalBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public List findNetBankingBranchDetails(String location) throws DAOException {
		logger.info("findNetBankingBranchDetails(String location)" + LoggingConstants.METHODBEGIN);
		String branchCode=null;
		List branchList=null;
		try{
			if(location.equalsIgnoreCase("ALL")){
				branchCode=(String)getJdbcTemplate().query(SQLConstants.LOCATORS_NET_BANKING_BRANCH_CODES_ALL,new BranchCodeExtractor());
			}	
			else{
				Object[] params={location};
				branchCode=(String)getJdbcTemplate().query(SQLConstants.LOCATORS_NET_BANKING_BRANCH_CODES,params,new BranchCodeExtractor());
			}
			String[] arr={branchCode};
		    String description = MessageFormat.format(SQLConstants.LOCATORS_NET_BANKING_BRANCH_DETAILS,arr);
			branchList=(List)getJdbcTemplate().query(description,new LocationDetailsResultSetExtractor());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findNetBankingBranchDetails(String location)" + LoggingConstants.METHODEND);
		return branchList;
	}

	public String[] findNetBankingBranches(String bankCode,String bankCode1) throws DAOException {
		logger.info("findNetBankingBranches(String bankCode,String bankCode1)" + LoggingConstants.METHODBEGIN);
		Object[] params={bankCode,bankCode1};
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_NET_BANKING_BRANCHES,params,new LocatorsResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findNetBankingBranches(String bankCode,String bankCode1)" + LoggingConstants.METHODEND);
		return branches;
	}
	public String[] findTeleBankingBranches() throws DAOException {
		logger.info("findTeleBankingBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_TELE_BANKING_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findTeleBankingBranches()" + LoggingConstants.METHODEND);
		return branches;
	}
	
	public String[] findATMBranches() throws DAOException {
		logger.info("findATMBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_ATM_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findATMBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public String[] findBranch() throws DAOException {
		logger.info("findBranch()" +LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findBranch()" + LoggingConstants.METHODEND);
		return branches;
	}

	public String[] findComerialBranches() throws DAOException {
		logger.info("findComerialBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_COMMERCIAL_BRANCHES,new BranchesResultSetExtractior());
		}catch (DataAccessException dataAccessException) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findComerialBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public String[] findForexBranches() throws DAOException {
		logger.info("findForexBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_FOR_EX_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findForexBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public String[] findInternetBankingBranches() throws DAOException {
		logger.info("findInternetBankingBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_INTERNET_BANKING_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findInternetBankingBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public String[] findLocations(String state,String type) throws DAOException {
		logger.info("findLocations(String state)" + LoggingConstants.METHODBEGIN);
		logger.info("State :" + state + "Type :" + type);
		Object[] params={state,state};
		String[] locations=null;
		String query="";
		try{
			if(state!=null && state.length()>0 && type!=null && type.length()>0){
				if(type.equalsIgnoreCase("AG"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and (category=15 or category=22 ) order by location";
				else if(type.equalsIgnoreCase("C"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and category=11 order by location";
				else if(type.equalsIgnoreCase("F"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and forex='B' order by location";
				else if(type.equalsIgnoreCase("I"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and inb=0 order by location";
				else if(type.equalsIgnoreCase("P"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and category=31 order by location";
				else if(type.equalsIgnoreCase("T"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and tele_banking=0 order by location";
				else if(type.equalsIgnoreCase("AT"))
					query=SQLConstants.LOCATORS_LOCATIONS + " and atm=0 order by location";
				else if(type.equalsIgnoreCase("B"))
					query=SQLConstants.LOCATORS_LOCATIONS;
				
				List locationsList=(List)getJdbcTemplate().query(query,params,new LocatorsResultSetExtractior());
				if(locationsList.size()<=0){
					return null;
				}
				locations=new String[locationsList.size()];
				locationsList.toArray(locations);
			}
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findLocations(String state)" + LoggingConstants.METHODEND);
		return locations;
	}

	public String[] findLocationsForDistrict(String state,String type) throws DAOException {
		logger.info("findLocationsForDistrict(String state)" + LoggingConstants.METHODBEGIN);
		Object[] params={state};
		String[] locations=null;
		String query="";
		try{
			if(state!=null && state.length()>0 && type!=null && type.length()>0){
				if(type.equalsIgnoreCase("AG"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and (category=15 or category=22 ) order by location";
				else if(type.equalsIgnoreCase("C"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and category=11 order by location";
				else if(type.equalsIgnoreCase("F"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and forex='B' order by location";
				else if(type.equalsIgnoreCase("I"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and inb=0 order by location";
				else if(type.equalsIgnoreCase("P"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and category=31 order by location";
				else if(type.equalsIgnoreCase("T"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and tele_banking=0 order by location";
				else if(type.equalsIgnoreCase("AT"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT + " and atm=0 order by location";
				else if(type.equalsIgnoreCase("B"))
					query=SQLConstants.LOCATORS_LOCATIONS_FOR_DISTRICT;
				List locationsList=(List)getJdbcTemplate().query(query,params,new LocatorsResultSetExtractior());
				locations=new String[locationsList.size()];
				locationsList.toArray(locations);
			}
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findLocationsForDistrict(String state)" + LoggingConstants.METHODEND);
		return locations;
		
	}

	public String[] findPBBBranches() throws DAOException {
		logger.info("findPBBBranches()" + LoggingConstants.METHODBEGIN);
		List branchList=null;
		try{
			branchList=(List)getJdbcTemplate().query(SQLConstants.LOCATORS_PBB_BRANCHES,new BranchesResultSetExtractior());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		String[] branches=new String[branchList.size()];
		branchList.toArray(branches);
		logger.info("findPBBBranches()" + LoggingConstants.METHODEND);
		return branches;
	}

	public Map findBranchDetails(String branchCode) throws DAOException {
		logger.info("findBranchDetails(String branchCode)" + LoggingConstants.METHODBEGIN);
		Map outParam=null;
		Object[] params={branchCode};
		try{
			outParam=(Map)getJdbcTemplate().query(SQLConstants.LOCATORS_BRANCH_DETAILS,params,new BranchDetailsResultSetExtractor());
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findBranchDetails(String branchCode)" + outParam);
		logger.info("findBranchDetails(String branchCode)" + LoggingConstants.METHODEND);
		return outParam;
	}

	public List findLocationDetails(String state,String location,String type)throws DAOException{
		logger.info("findLocationDetails(String state,String location)" + LoggingConstants.METHODBEGIN);
		Object[] params={state,location,state};
		List locationDetails=null;
		String query="";
		try{
			if(state!=null && state.length()>0 && type!=null && type.length()>0){
				if(type.equalsIgnoreCase("AG"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and (category=15 or category=22 ) order by branch_name";
				else if(type.equalsIgnoreCase("C"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and category=11 order by branch_name";
				else if(type.equalsIgnoreCase("F"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and forex='B' order by branch_name";
				else if(type.equalsIgnoreCase("I"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and inb=0 order by branch_name";
				else if(type.equalsIgnoreCase("P"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and category=31 order by branch_name";
				else if(type.equalsIgnoreCase("T"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and tele_banking=0 order by branch_name";
				else if(type.equalsIgnoreCase("AT"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS + " and atm=0 order by branch_name";
				else if(type.equalsIgnoreCase("B"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS;
			locationDetails=(List)getJdbcTemplate().query(query,params,new LocationDetailsResultSetExtractor());
			logger.info("findLocationDetails(String state,String location)" +locationDetails);
			}
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findLocationDetails(String state,String location)" + LoggingConstants.METHODEND);
		return locationDetails;
	}
	
	public List findLocationDetailsForDistrict(String state,String location,String type)throws DAOException{
		logger.info("findLocationDetailsForDistrict(String state,String location)" + LoggingConstants.METHODBEGIN);
		Object[] params={state,location};
		List locationDetails=null;
		String query="";
		try{
			if(state!=null && state.length()>0 && type!=null && type.length()>0){
				if(type.equalsIgnoreCase("AG"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and (category=15 or category=22 ) order by branch_name";
				else if(type.equalsIgnoreCase("C"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and category=11 order by branch_name";
				else if(type.equalsIgnoreCase("F"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and forex='B' order by branch_name";
				else if(type.equalsIgnoreCase("I"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and inb=0 order by branch_name";
				else if(type.equalsIgnoreCase("P"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and category=31 order by branch_name";
				else if(type.equalsIgnoreCase("T"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and tele_banking=0 order by branch_name";
				else if(type.equalsIgnoreCase("AT"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT + " and atm=0 order by branch_name";
				else if(type.equalsIgnoreCase("B"))
					query=SQLConstants.LOCATORS_LOCATION_DETAILS_FOR_DISTRICT;
				locationDetails=(List)getJdbcTemplate().query(query,params,new LocationDetailsResultSetExtractor());
				logger.info("findLocationDetailsForDistrict(String state,String location)" +locationDetails);
			}
		}catch(DataAccessException dataAccessException){
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,dataAccessException);
		}
		logger.info("findLocationDetailsForDistrict(String state,String location)" + LoggingConstants.METHODEND);
		return locationDetails;
	}
	
	private class BranchesResultSetExtractior implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		List branches=new ArrayList();	
		while(rs.next()){
			branches.add(rs.getString("STATE"));
		}
			return branches;
		}
		
	}
	private class LocatorsResultSetExtractior implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		List branches=new ArrayList();	
		while(rs.next()){
			branches.add(rs.getString("LOCATION"));
		
		}
			return branches;
		}
		
	}
	private class LocationDetailsResultSetExtractor implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			List locationDetails=new ArrayList();
			while(rs.next()){
				Map details=new HashMap();
				details.put("BRANCH_CODE",rs.getString("BRANCH_CODE"));
				details.put("BRANCH_NAME",rs.getString("BRANCH_NAME"));
				details.put("ADDRESS",rs.getString("ADDRESS"));
				details.put("PINCODE",rs.getString("PINCODE"));
				details.put("PHONE1",rs.getString("PHONE1"));
				details.put("PHONE2",rs.getString("PHONE2"));
				details.put("EMAIL",rs.getString("EMAIL"));
				details.put("STATE",rs.getString("STATE"));
				details.put("LOCATION",rs.getString("LOCATION"));
				locationDetails.add(details);
			}
			return locationDetails;
		}
	}
	private class BranchDetailsResultSetExtractor implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map branchDetails=new HashMap();
			while(rs.next()){
				branchDetails.put("BRANCH_CODE",rs.getString("BRANCH_CODE"));
				branchDetails.put("BRANCH_NAME",rs.getString("BRANCH_NAME"));
				branchDetails.put("ADDRESS",rs.getString("ADDRESS"));
				branchDetails.put("PINCODE",rs.getString("PINCODE"));
				branchDetails.put("PHONE1",rs.getString("PHONE1"));
				branchDetails.put("PHONE2",rs.getString("PHONE2"));
				branchDetails.put("EMAIL",rs.getString("EMAIL"));
				branchDetails.put("STATE",rs.getString("STATE"));
				branchDetails.put("LOCATION",rs.getString("LOCATION"));
				branchDetails.put("FAX",rs.getString("FAX"));
				branchDetails.put("STD_CODE",rs.getString("STD_CODE"));
				branchDetails.put("AREA",rs.getString("AREA"));
				branchDetails.put("ATM",rs.getString("ATM"));
				branchDetails.put("INB",rs.getString("INB"));
				branchDetails.put("TELE_BANKING",rs.getString("TELE_BANKING"));
				branchDetails.put("CATEGORY",rs.getString("CATEGORY"));				
				branchDetails.put("DISTRICT",rs.getString("DISTRICT"));
				branchDetails.put("STATE",rs.getString("STATE"));
				branchDetails.put("SUNDAY_HOURS",rs.getString("SUNDAY_HOURS"));
				branchDetails.put("BRANCH_MANAGER",rs.getString("BRANCH_MANAGER"));
				branchDetails.put("DISTRICT",rs.getString("DISTRICT"));
			}
			return branchDetails;
		}
	}
	
	private class BranchCodeExtractor implements ResultSetExtractor{
		String branchCode=null;
		int i=0;
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			while(rs.next()){
				if(i==0)
					branchCode="'" + rs.getString("BRANCH_CODE") + "'";
				else
					branchCode = branchCode + ",'" + rs.getString("BRANCH_CODE") + "'";
				i++;
			}
			return branchCode;
		}
		
	}
}
 