/*    
 * LateProcessRequestDAOImpl.java
 * Created on Sep 1, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * Sep 01, 2006 RAVIKUMAR KATHIRVEL - Initial Creation
 */
//History
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import wac.logger.WACException;
import wac.logger.WACExceptionHandler;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.BrokerAccountDetails;
import com.sbi.common.model.CoreAccountStatement;
import com.sbi.common.model.TransactionHistory;
import com.sbi.common.utils.StringUtils;
/**
 * TODO this class used to fetch the data from sbi_lpr_input and sbi_lpr_output table for core account statement
 * 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class LateProcessRequestDAOImpl extends JdbcDaoSupport implements
		LateProcessRequestDAO {

	public final static boolean coreFlag = true;

	private final Logger logger = Logger.getLogger(getClass());

	private BankSystemDAO coreDAOImpl;

	private BankSystemDAO switchDAOImpl;

	/* CONSTANTS */
    static final String FIND_CORE_ACCOUNT_STATEMENT = "select Request_Id, ltrim(rtrim(status))as status1, param1, param2, param4, creation_time,param6,param3,param5,param7 from sbi_lpr_input where user_name=? and request_type = 'account_statement'  order by creation_time desc";//Modified based on client comment
    
	//Modified By Aruna(CR 2765)
     static final String FIND_CORE_ACCOUNT_STATEMENT_DETAIL = "select a.param1 as startdate, a.param2 as enddate, a.param4 as ACCOUNT_NO, ltrim(rtrim(a.param5)) as description, b.param3 as Transaction_Date,  b.param4 as Date_Value,ltrim(rtrim(a.param3)) as BRANCH_CODE,ltrim(rtrim(b.param12)) as PARAM12,decode(ltrim(rtrim(b.param11)),'CREDIT',b.param5,0) - decode(ltrim(rtrim(b.param11)),'DEBIT',b.param5,0) as Amount, trim(b.param7) || '-'|| TRIM (b.param8) ||'-'|| TRIM (b.param10) as NARRATIVE2,b.param10 AS REFERENCE_NO,b.param9 as NARRATIVE3, b.param6 as balance,a.creation_time,b.param13 as post_time from sbi_lpr_input a, sbi_lpr_output b where a.request_id = b.request_id and a.request_type = 'account_statement' and b.request_type = 'account_statement' and a.request_id =? and user_name=? order by to_number(b.param1) #sort_by# ";
   
     static final String FIND_BROKER_ACCOUNT_STATEMENT = "select Request_Id, ltrim(rtrim(status))as status1, param1, param2, param4, creation_time,param6,param3,param5 from sbi_lpr_input where user_name=? and request_type = 'broker_account_stmt'  order by param6,creation_time";
     
//     static final String FIND_BROKER_ACCOUNT_STATEMENT_DETAIL = "select a.param1 as startdate, a.param2 as enddate, a.param4 as ACCOUNT_NO, ltrim(rtrim(a.param5)) as description, b.param3 as Transaction_Date, b.param4 as Date_Value,ltrim(rtrim(a.param3)) as BRANCH_CODE,ltrim(rtrim(b.param12)) as PARAM12,decode(ltrim(rtrim(b.param11)),'CREDIT',b.param5,0) - decode(ltrim(rtrim(b.param11)),'DEBIT',b.param5,0) as Amount, trim(b.param7) || '-'|| TRIM (b.param8) ||'-'|| TRIM (b.param10) as NARRATIVE2,b.param10 AS REFERENCE_NO,b.param9 as NARRATIVE3, b.param6 as balance,a.creation_time from sbi_lpr_input a, sbi_lpr_output b where a.request_id = b.request_id and a.request_type = 'broker_account_stmt' and b.request_type = 'broker_account_stmt' and a.request_id =? and user_name=? order by to_number(b.param1) #sort_by# ";
     static final String FIND_BROKER_ACCOUNT_STATEMENT_DETAIL = "select b.param2 as STARTDATE, b.param3 as ENDDATE, ltrim(rtrim(b.param4)) as BRANCH_CODE, ltrim(rtrim(b.param12)) as DESCRIPTION, ltrim(rtrim(b.param5))  as AMOUNT, ltrim(rtrim(b.param9))  as CLIENTNAME, ltrim(rtrim(b.param6))  as ECHEQUENO from sbi_lpr_input a, sbi_lpr_output b where a.request_id = b.request_id and a.request_type = 'broker_account_stmt' and b.request_type = 'broker_account_stmt' and a.request_id = ? and user_name = ? order by to_number(b.param1) #sort_by# ";
    
    static final String REQUEST_ID = "REQUEST_ID";
    
    static final String LPR_STATUS = "STATUS1";

    static final String PARAM1 = "PARAM1";
    
    static final String PARAM2 = "PARAM2";
          
    static final String PARAM4 = "PARAM4";

    static final String LPR_CREATION_TIME = "CREATION_TIME";
    
    static final String PARAM6 = "PARAM6";
    
    static final String PARAM3 = "PARAM3";
     
    static final String PARAM5 = "PARAM5";
    
    static final String STARTDATE = "STARTDATE";
    
    static final String ENDDATE = "ENDDATE";
    
    static final String DESCRIPTION = "DESCRIPTION";
	
    static final String FATAL_ERROR1_CODE="F1";
    
    static final String FIND_REQUEST_ID = "select max(request_id) from sbi_lpr_input where user_name=? and status='Pending' and param1 =? and param2=? and param3=? and param4=? and request_type='account_statement'";
	//Added For CR 5565
    static final String FIND_MT940_ACCOUNT_STATEMENT = "select request_id, status, param1,param2,param3,param4,param5,creation_time from sbi_lpr_input where user_name=? and request_type = 'MT940' and creation_time >= sysdate-?  order by creation_time desc";
  //Added For CR 5588
    static final String GET_RECON_FILE_BY_DATE = "select request_id,param1,param3,param4,param5,param6  from bvsbi.sbi_lpr_input where request_type = 'corp_recon' and status='Processed' and param2=? and TO_DATE (param1,'dd/mm/yyyy') between to_date(?,'dd/mm/yyyy') and to_date(?,'dd/mm/yyyy') order by creation_time desc";
    
    static final String FIND_BROKER_ACCOUNT_REQUEST_ID = "select max(request_id) from sbi_lpr_input where user_name=? and status='Pending' and param1 =? and param2=? and param3=? and param4=? and request_type='broker_account_stmt'";
    
	/**
	 * TODO Get the latest Balance form the account object
	 * 
	 * @param accountNo Object
	 *            
	 * @return List 	CoreAccountStatement
	 */

	public List findLatestBalance(Account account) throws WACException {
		
		List transactionHistoryList = new ArrayList();
		Map inParameters = new HashMap();
		String sequenceNumber = null;
		
		logger.info("findLatestBalance(Account account) method begin");
		
		if (account != null) {

			try {
			
			
			if (account.getBankSystem().equalsIgnoreCase(
					DAOConstants.BANK_MASTER)) {

				inParameters.put("ACC_NO", account.getAccountNo());
				inParameters.put("BR_CODE", account.getBranchCode());
				inParameters.put("LAST_BUT", "0");
				inParameters.put("NO_TXN", "5");
				inParameters.put("txnno", "333333");
				int sequenceNo = getJdbcTemplate().queryForInt(
						"select CURRBALREF.NEXTVAL from dual");
				sequenceNumber = "" + sequenceNo;
				inParameters.put("BREF", sequenceNumber.trim());
				logger.info("Sequence Number : " + sequenceNumber);
				// logger.info("Get the TransactionHistory from SwitchDAOImpl");
				transactionHistoryList = getTransactionsFromSwitch(
						inParameters, account);

			} else if (account.getBankSystem().equalsIgnoreCase(
					DAOConstants.CORE)) {
				if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
					inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_LOAN);
				} else {
					inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_DEPOSIT);
					inParameters.put("fin_txn_type", "");
				}
				// logger.info("Get the TransactionHistory from Bank System : "
				// + account.getBankSystem());
				inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account
						.getAccountNo());
				inParameters.put(DAOConstants.TXN_IDENTIFIER, "0");
				inParameters.put(DAOConstants.CORE_START_DATE, "");
				inParameters.put(DAOConstants.CORE_END_DATE, "");
				inParameters.put(DAOConstants.CORE_FROM_AMOUNT, "");
				inParameters.put(DAOConstants.CORE_TO_AMOUNT, "");

				// associate banks
				inParameters.put("bankCode", String.valueOf(account
						.getBranchCode().charAt(0)));

				transactionHistoryList = getTransactionsFromCore(inParameters,
						account);
				if (logger.isDebugEnabled())
					logger.debug("Get the TransactionHistory from Core "
							+ transactionHistoryList);
			}
			logger.info("findLatestBalance(Account account) method  end");
			
		}
		catch(DAOException exceptin)
		{
			WACExceptionHandler.handleDAOException(exceptin,"CU0004",  new Object[] {transactionHistoryList} );
		}
		 
	}else {
			WACExceptionHandler.handleDAOException("CU0003", new Object [] {account});
		}
		
		return transactionHistoryList;
	}

	/**
	 * TODO Get the account transactions form core
	 * 
	 * @param request Map
	 * @param account Object
	 * @return List 
	 */	
	private List getTransactionsFromCore(Map request, Account account)
			throws DAOException {
		logger.info("getTransactionsFromCore(Map request, Account account) begin");
		// BankSystemDAO bankSystemDAO = new CoreDAOImpl();
		List responseList = coreDAOImpl.getDataFromBankSystem(request);
		Map transactionMap = null;
		List transactionHistoryList = null;
		boolean insertToLprInparams = false;
		if (responseList != null && responseList.size() > 0) {
			transactionHistoryList = new ArrayList();
			for (int i = 0; i < responseList.size(); i++) {

				transactionMap = (Map) responseList.get(i);

				String status = null;
				String errorCode = null;
				// added for cr-5322
				String branchCode =account.getBranchCode();
	            String bankCode =branchCode.substring(0, 1);
	            
				if (transactionMap.get("status") != null)
					status = (String) transactionMap.get("status");
				if (transactionMap.get("error_code") != null) {
					errorCode = (String) transactionMap.get("error_code");
					status = errorCode;
				}

				if (status == null && errorCode == null) {

					TransactionHistory transactionHistory = new TransactionHistory();

					/*
					 * setting values from Core response to TransactionHistory
					 * object
					 */
					if (logger.isDebugEnabled())
						logger.debug("core Date :"
								+ transactionMap.get(DAOConstants.CORE_DATE));
					transactionHistory.setAmount(StringUtils
							.emptyStringCheckForDouble(((String) transactionMap
									.get(DAOConstants.CORE_AMOUNT)))); // "amount"
					String narrative1 = (String) transactionMap
							.get(DAOConstants.CORE_NARRATIVE);
					if (narrative1 != null) {
						if (narrative1.equals(":::::"))
							insertToLprInparams = true;
						transactionHistory.setNarrative1(narrative1); // "narrative"
					}
					String narrative2 = (String) transactionMap
							.get(DAOConstants.USER_NARRATIVE);
					if (narrative2 != null)
						transactionHistory.setNarrative2(narrative2.replaceAll(
								"\n", "")); // "user_narrative"
					transactionHistory.setTransactionDate((StringUtils
							.coreDateToTimestamp((String) transactionMap
									.get(DAOConstants.CORE_DATE)))); // "date"
					transactionHistory.setValueDate(StringUtils
							.coreDateToTimestamp((String) transactionMap
									.get(DAOConstants.CORE_VALUE_DATE))); // "valuedate"
					transactionHistory.setBalance(StringUtils
							.emptyStringCheckForDouble((String) transactionMap
									.get(DAOConstants.CORE_BALANCE))); // "balance"
					if (transactionMap.get(DAOConstants.IB_REF_NO) != null)
						transactionHistory
								.setReferenceNo(((String) transactionMap
										.get(DAOConstants.IB_REF_NO)).trim());

					if (transactionMap.get(DAOConstants.REFERENCE_NO) != null)
						transactionHistory
								.setNarrative3(((String) transactionMap
										.get(DAOConstants.REFERENCE_NO)).trim());
					// modified for cr-5322
					/* if(!(bankCode.equalsIgnoreCase("0") ||bankCode.equalsIgnoreCase("6")|| bankCode.equalsIgnoreCase("A") )){		                
						if(transactionMap.get("ref_no_1") != null)	                		
	                    	transactionHistory.setReferenceNo(((String) transactionMap.get("ref_no_1")).trim());
						    logger.info("ref_no_1"+transactionMap.get("ref_no_1"));
	                }
	               		*/			
					
					if (insertToLprInparams == true) {
						insetIntoLprInparam(transactionHistory.getNarrative3(),
								(Timestamp) request.get("fromDate"),
								(Timestamp) request.get("toDate"), account);
					}
					/* setting the value from Account object */
					transactionHistory.setAccountNo(account.getAccountNo());
					transactionHistory.setBranchCode(account.getBranchCode());
					transactionHistoryList.add(i, transactionHistory);
				}
			}
		}
		if (logger.isDebugEnabled())
			logger.debug("Result List : " + transactionHistoryList);
		logger.info("getTransactionsFromCore(Map request, Account account) method end");
		return transactionHistoryList;
	}
	/**
	 * TODO Get the transactions form the switch
	 * 
	 * @param request Map
	 * @param account Object
	 * @return List 
	 */	
	private List getTransactionsFromSwitch(Map request, Account account)
			throws DAOException

	{
		logger.info("getTransactionsFromSwitch(Map request, Account account) begin");
		List responseList = switchDAOImpl.getDataFromBankSystem(request);
		Map transactionMap = null;
		List transactionHistoryList = null;
		if (responseList != null && responseList.size() > 0) {
			transactionHistoryList = new ArrayList();
			for (int i = 0; i < responseList.size(); i++) {
				TransactionHistory transactionHistory = new TransactionHistory();
				transactionMap = (Map) responseList.get(i);

				/*
				 * setting values from swit response to TransactionHistory
				 * object
				 */

				String status = (String) transactionMap.get("status");

				if (status.equalsIgnoreCase("00")) {

					transactionHistory.setAmount(StringUtils
							.emptyStringCheckForDouble(((String) transactionMap
									.get("TXN_AMT"))));
					transactionHistory.setNarrative1((String) transactionMap
							.get("TXN_NAR1"));
					transactionHistory.setNarrative2((String) transactionMap
							.get("TXN_NAR2"));
					transactionHistory.setTransactionDate((StringUtils
							.responseStringToTimestamp((String) transactionMap
									.get("TXN_DATE"))));
					transactionHistory.setBalance(StringUtils
							.emptyStringCheckForDouble((String) transactionMap
									.get("BAL")));
					transactionHistory.setReferenceNo(((String) transactionMap
							.get("TXN_REF")).trim());
					/* setting the value from Account object */
					transactionHistory.setAccountNo(account.getAccountNo());
					transactionHistory.setBranchCode(account.getBranchCode());
					transactionHistoryList.add(i, transactionHistory);
				} else
					DAOException.throwException(status);

			}
		}
		if (logger.isDebugEnabled())
			logger.debug("Result List : " + transactionHistoryList);
		
		logger.info("getTransactionsFromCore(Map request, Account account) method end");
		return transactionHistoryList;
	}

	/**
	 * TODO Get the transactions form the core
	 * 
	 * @param 	username 	String
	 * @return 	List 
	 */	
	public List findCoreStatementTransaction(String username)
			throws DAOException {

		logger.info("findCoreStatementTransaction(String username) method begin");
		List resultList = null;
		try {

			Object[] parameters = new Object[] { username };
			resultList = getJdbcTemplate().query(
					FIND_CORE_ACCOUNT_STATEMENT, parameters,
					new CoreAccountStatementRowMapper());
			logger.info(" Retrieve successfully ");
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			DAOException.throwException(FATAL_ERROR1_CODE,
					daoExp);
		}

		logger.info("findCoreStatementTransaction(String username) method end");
		return resultList;
	}

	/**
	 * TODO Get the account statement details from core
	 * 
	 * @param requestId 	String
	 * @param userName  	String
	 * @param orderByValue 	String
	 * @return List 
	 */		
	   public List findcoreAccountStatementdetails(String requestId, String userName,String orderByValue) throws DAOException
	     {
		   logger.info("findcoreAccountStatementdetails(String requestId,String userName,String orderByValue) method begin");
		   List resultList = null;
	       try {

	          Object[] parameters = new Object[] { requestId, userName};
	         
	     	  resultList = getJdbcTemplate().query( FIND_CORE_ACCOUNT_STATEMENT_DETAIL.replaceAll("#sort_by#",orderByValue),parameters,new CoreAccountStatementDetailRowMapper());
	     	  logger.info(" Retrieve successfully ");
	    }
	    catch (DataAccessException daoExp) {
	    	logger.error("Exception occured query: " + daoExp);
	    	DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, daoExp);
	    }
	 
	    logger.info("findcoreAccountStatementdetails(String requestId,String userName,String orderByValue) method end");
	    return resultList;
	     }
		 
	   
	   public String fetchRequestId(String userName, String accountNo, String branchCode, String fromDate,String toDate)throws DAOException  
	   {
		   logger.info("fetchRequestId(String userName, String accountNo, String branchCode, String fromDate,String toDate) method begin");
		   String resultId = null;
	       try {
	    	   logger.info("userName:"+userName);
	    	   logger.info("accountNo:"+accountNo);
	    	   logger.info("branchCode:"+branchCode);
	    	   logger.info("fromDate:"+fromDate);
	    	   logger.info("toDate:"+toDate);
	    	   
	          Object[] parameters = new Object[] {userName,fromDate,toDate,branchCode,accountNo};
	          resultId = (String)getJdbcTemplate().queryForObject(FIND_REQUEST_ID,parameters,java.lang.String.class);
	     	  logger.info(" Retrieve successfully "+resultId);
	    }
	    catch (DataAccessException daoExp) {
	    	logger.error("Exception occured query: " + daoExp);
	    	//DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, daoExp);
	    	return null;
	    }
	 
	    logger.info("fetchRequestId(String userName, String accountNo, String branchCode, String fromDate,String toDate) method end");
	    return resultId;
	     }  

	   
	   
	    class CoreAccountStatementRowMapper implements RowMapper {

	        public Object mapRow(ResultSet rs, int index) throws SQLException {

	            CoreAccountStatement coreAccountStatement = new CoreAccountStatement();
	             
	              coreAccountStatement.setRequest_Id(rs.getString(REQUEST_ID));
	              coreAccountStatement.setParam4(rs.getString(PARAM4));
	              
	            /*  String date = rs.getString(PARAM1);
	              String dd = date.substring(0,2);
	              String month = date.substring(2,4);
	              String year =date.substring(4,8);
	              String toDate= dd+"/"+month+"/"+year; 
	              coreAccountStatement.setParam1(toDate);
	              
	                            
	              String eDate = rs.getString(PARAM2);
	              String edd = eDate.substring(0,2);
	              String emonth = eDate.substring(2,4);
	              String eyear =eDate.substring(4,8);
	              String endDate= edd+"/"+emonth+"/"+eyear;              
	              coreAccountStatement.setParam2(endDate); */
	                        
	              coreAccountStatement.setParam1(rs.getString(PARAM1));
                  coreAccountStatement.setParam2(rs.getString(PARAM2));
                  
	              coreAccountStatement.setCreation_time(rs.getTimestamp(LPR_CREATION_TIME));
	              coreAccountStatement.setStatus(rs.getString(LPR_STATUS));
	              coreAccountStatement.setParam5(rs.getString(PARAM5));
	              coreAccountStatement.setParam7(rs.getString("param7"));
	              logger.info ("Time stamp value::"+coreAccountStatement.getParam7());
	              String strproductType = rs.getString(PARAM6);
	              if (strproductType != null && strproductType.equalsIgnoreCase("ca"))
	            	  strproductType = "A1";
	              if (strproductType != null && strproductType.equalsIgnoreCase("cc"))
	            	  strproductType = "A3";
	              if (strproductType != null && strproductType.equalsIgnoreCase("td"))
	            	  strproductType = "A5";
	              if (strproductType != null && strproductType.equalsIgnoreCase("tl"))
	            	  strproductType = "A6";
	                    
	              coreAccountStatement.setProductType(strproductType);
	              
	              String branchCode = rs.getString(PARAM3);
	              coreAccountStatement.setBranchCode(branchCode);
	                         
	            return coreAccountStatement;
	        }
	    }
	    
	    class CoreAccountStatementDetailRowMapper implements RowMapper {

	        public Object mapRow(ResultSet rs, int index) throws SQLException {
	        	
	        	TransactionHistory transactionHistory = new TransactionHistory();
	        	transactionHistory.setStartdate(rs.getString(STARTDATE));        
	        	transactionHistory.setEnddate(rs.getString(ENDDATE));        	
	            transactionHistory.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));            
	            transactionHistory.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));           
	            transactionHistory.setDescription(rs.getString(DESCRIPTION));
	            String postTime;
	            
	            String transactionDate = rs.getString(SQLConstants.TRANSACTION_DATE);
	            if(transactionDate.length() ==8){
	            String dd = transactionDate.substring(0,2);
	            String month = transactionDate.substring(2,4);
	            String year =transactionDate.substring(4,8);
	            String toDate= dd+"/"+month+"/"+year;
	            transactionDate=toDate;
	            } 
	            transactionHistory.setTransactionDate(StringUtils.stringToTimestamp(transactionDate));
	          
	            String valueDate = rs.getString(SQLConstants.DATE_VALUE);
	            transactionHistory.setValueDate(StringUtils.stringToTimestamp(valueDate));
	                     
	            String amount = rs.getString(SQLConstants.AMOUNT);
	            transactionHistory.setAmount(StringUtils.emptyStringCheckForDouble(amount));
	                       
	            String balance = rs.getString(SQLConstants.BALANCE);
	            transactionHistory.setBalance(StringUtils.emptyStringCheckForDouble(balance));
	                    
	            //transactionHistory.setNarrative1(rs.getString(SQLConstants.NARRATIVE1)); // "NARRATIVE1"
	            transactionHistory.setNarrative2(rs.getString(SQLConstants.NARRATIVE2)); // "description"
	            transactionHistory.setNarrative3(rs.getString(SQLConstants.NARRATIVE3)); // "checkno"
                //Added by Aruna
                transactionHistory.setReferenceNo(rs.getString(SQLConstants.REFERENCE_NO));//"referenceno"
                
                //For CR 2765
                transactionHistory.setBranchCodeFromCore(rs.getString("PARAM12"));
                if(rs.getString("post_time") != null)
            	{
	                postTime = ((rs.getString("post_time")).trim()).substring(0,6);
	        		postTime = postTime.substring(0,2)  +":"+  postTime.substring(2,4)  +":"+  postTime.substring(4,6);
	        		transactionHistory.setPosttime(postTime);
	        		logger.info("post time:::" + transactionHistory.getPosttime());
	            }    
	           
	            return transactionHistory;

	        } 
	    }
	  
	private void insetIntoLprInparam(String refNo, Timestamp fromDate,
			Timestamp toDate, Account account) {
		logger.info("insetIntoLprInparam(String refNo, Timestamp fromDate, Timestamp toDate, Account account) - method begin");
		String query = "insert into sbi_lpr_input (request_id, user_name, status, request_type, param1, param2, param3, param4, param5, param6, creation_time) values(?,?, 'pending','account_statement',to_char(to_date(substr(?,1,8),'mm/dd/yy'),'dd/mm/yyyy'), to_char(to_date(substr(?,1,8),'mm/dd/yy'),'dd/mm/yyyy'),?,?,?,?,sysdate)";
		if (refNo != null && account != null) {
			Object[] params = { refNo, account.getUserName(), fromDate, toDate,
					account.getBranchCode(), account.getAccountNo(),
					"need to ask", account.getProductType() };
			try {
				getJdbcTemplate().update(query, params);
			} catch (DataAccessException dataAccessException) {
				DAOException.throwException("SE003", dataAccessException);
			}
		} else
			DAOException.throwException("SE003");
		
		logger.info("insetIntoLprInparam(String refNo, Timestamp fromDate, Timestamp toDate, Account account) - method end");
	}


	public Timestamp responseStringToTimestamp(String dateString) {
		Timestamp timestamp = null;
		logger.info("responseStringToTimestamp(String dateString) - method begin");
		try {
			if (dateString != null) {
				SimpleDateFormat ts = new SimpleDateFormat("yyyy-dd/MM/yy");
				Date sqlToday = new java.sql.Date(ts.parse(dateString).getTime());
				timestamp = new Timestamp(sqlToday.getTime());
				return timestamp;
			} else {
				logger.info("core retuning date is null");

			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		logger.info("responseStringToTimestamp(String dateString) - method end");		
		return timestamp;

	}
	//Added For CR 5565 Starts
	public List findMT940AccountStatement(String username,int days ) throws DAOException {
	logger.info("findMT940AccountStatement(String username,int days) method begin");
	List resultList = null;
	try {	
		Object[] parameters = new Object[] { username,days };
		resultList = getJdbcTemplate().queryForList(FIND_MT940_ACCOUNT_STATEMENT, parameters);
		logger.info(" Retrieve successfully "+resultList.size());
	} catch (DataAccessException daoExp) {
		logger.error("Exception occured query: " + daoExp);
		DAOException.throwException(FATAL_ERROR1_CODE,daoExp);
	}	
	logger.info("findMT940AccountStatement(String username,int days) method end");
	return resultList;
	}
	public void insertToLPR(Map lprAcctStmt) throws DAOException {
		logger.info("void insertToLPR(Map lprAcctStmt) throws DAOExceptionmethod begin");
		List resultList = null;
		try {	
			Object[] parameters = new Object[] { lprAcctStmt.get("requestId"),lprAcctStmt.get("userName"),lprAcctStmt.get("status"),
					  lprAcctStmt.get("requestType"),lprAcctStmt.get("param1"),lprAcctStmt.get("param2"),lprAcctStmt.get("param3"),lprAcctStmt.get("param4"),lprAcctStmt.get("param5"),lprAcctStmt.get("param6")};
			int sqlType[] = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR, Types.VARCHAR};
			int ackmt = getJdbcTemplate().update("insert into bvsbi.sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,PARAM6,CREATION_TIME) values (?,?,?,?,?,?,?,?,?,?,sysdate)", parameters,sqlType);
			if(ackmt==0)
				DAOException.throwException("SE002");
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			DAOException.throwException(FATAL_ERROR1_CODE,daoExp);
		}	
		logger.info("void insertToLPR(Map lprAcctStmt) throws DAOException method end");
		}
	//Added For CR 5565 Ends
	//Added For CR 5588 Starts
	public List getReconFilesbyDate(String corpId,String fromDate,String toDate) throws DAOException {
		logger.info("getReconFilesbyDate(String corpId,String fromDate,String toDate) method begin");
		List resultList = null;
		try {	
			Object[] parameters = new Object[] { corpId,fromDate,toDate };
			resultList = getJdbcTemplate().queryForList(GET_RECON_FILE_BY_DATE, parameters);
			logger.info(" Retrieve successfully "+resultList.size());
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			DAOException.throwException(FATAL_ERROR1_CODE,daoExp);
		}	
		logger.info("getReconFilesbyDate(String corpId,String fromDate,String toDate) method end");
		return resultList;
		}
	//Added For CR 5588 Ends
	
//	IR71227 begin
	public List findBrokerStatementTransaction(String username) throws DAOException {
		logger.info("findBrokerStatementTransaction(String username) method begin");
		List resultList = null;
		try {
			Object[] parameters = new Object[] { username };
			resultList = getJdbcTemplate().query(FIND_BROKER_ACCOUNT_STATEMENT, parameters, 
					new CoreAccountStatementRowMapper());
			logger.info(" Retrieve successfully ");
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			DAOException.throwException(FATAL_ERROR1_CODE, daoExp);
		}
		logger.info("findBrokerStatementTransaction(String username) method end");
		return resultList;
	}
	
	public List findBrokerAccountStatementdetails(String requestId, String userName, String orderByValue) throws DAOException {
		logger.info("findBrokerAccountStatementdetails(String requestId,String userName,String orderByValue) method begin");
		List resultList = null;
		try {

			Object[] parameters = new Object[] { requestId, userName };

			resultList = getJdbcTemplate().query(FIND_BROKER_ACCOUNT_STATEMENT_DETAIL.replaceAll("#sort_by#",
							orderByValue), parameters, new BrokerAccountStatementDetailRowMapper());
			logger.info(" Retrieve successfully ");
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, daoExp);
		}

		logger.info("findBrokerAccountStatementdetails(String requestId,String userName,String orderByValue) method end");
		return resultList;
	}
	
	public String fetchRequestIdForBrokerAccount(String userName, String accountNo, String branchCode, String fromDate, String toDate)
			throws DAOException {
		logger.info("fetchRequestIdForBrokerAccount(String userName, String accountNo, String branchCode, String fromDate,String toDate) method begin");
		String resultId = null;
		try {
			logger.info("userName: " + userName + ", accountNo: " + accountNo + ", branchCode: " + branchCode + ", fromDate: " + fromDate + ", toDate: " + toDate);
			Object[] parameters = new Object[] { userName, fromDate, toDate, branchCode, accountNo };
			resultId = (String) getJdbcTemplate().queryForObject(
					FIND_BROKER_ACCOUNT_REQUEST_ID, parameters, java.lang.String.class);
			logger.info(" Retrieve successfully " + resultId);
		} catch (DataAccessException daoExp) {
			logger.error("Exception occured query: " + daoExp);
			return null;
		}

		logger.info("fetchRequestIdForBrokerAccount(String userName, String accountNo, String branchCode, String fromDate,String toDate) method end");
		return resultId;
	}
	
	class BrokerAccountStatementDetailRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {
        	
        	BrokerAccountDetails transactionHistory = new BrokerAccountDetails();       	
            transactionHistory.setTransactionDate(StringUtils.stringToTimestamp(rs.getString("STARTDATE")));
            transactionHistory.setClearingDate(StringUtils.stringToTimestamp(rs.getString("ENDDATE")));
            transactionHistory.setTransactingBranch(rs.getString("BRANCH_CODE"));
            transactionHistory.setTransactionDesc(rs.getString("DESCRIPTION"));
            transactionHistory.setClientName(rs.getString("CLIENTNAME"));
            transactionHistory.setTransactionAmount(rs.getString("AMOUNT"));                    
            transactionHistory.setChequeNo(rs.getString("ECHEQUENO"));                    
            return transactionHistory;

        } 
    }
	
	
//	IR71227 end	
	/**
	 * TODO
	 * 
	 * @param BankSystemDAO
	 *            type object injection done here
	 */
	public void setCoreDAOImpl(BankSystemDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}

	public void setSwitchDAOImpl(BankSystemDAO switchDAOImpl) {
		this.switchDAOImpl = switchDAOImpl;
	}

}
