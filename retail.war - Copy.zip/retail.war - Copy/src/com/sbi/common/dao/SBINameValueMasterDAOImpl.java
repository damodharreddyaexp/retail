/*
 * SBINameValueMasterDAOImpl.java
 * Created on Nov 4, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $ 
 */
//History
//Nov 4, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
//DEC 2, 2005 BOOPATHI - Added branch details
// DEC 28, 2005 - BOOPATHI - EXCEPTION MODIFIED
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

public class SBINameValueMasterDAOImpl extends JdbcDaoSupport implements SBINameValueMasterDAO
{

    protected final Logger logger = Logger.getLogger(getClass());

    public Map getNameValueMasterData()
    {

        logger.info("getNameValueMasterData() " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List l = getJdbcTemplate().query(SQLConstants.SBI_NAME_VALUE_MASTER_DATA,
                    new NameValueMasterDataRowMapper());
            data = (Map) l.get(0);
            if (logger.isDebugEnabled())
            {
                logger.debug("data :" + data);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("getNameValueMasterData() " + LoggingConstants.METHODEND);
        return data;
    }

    public Map getSBISwitchErrorData()
    {

        logger.info("getSBISwitchErrorData() " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List l = getJdbcTemplate().query(SQLConstants.SBI_SWITCH_ERROR_DATA, new NameValueMasterDataRowMapper());
            data = (Map) l.get(0);
            if (logger.isDebugEnabled())
            {
                logger.debug("data :" + data);
            }
        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("getSBISwitchErrorData() " + LoggingConstants.METHODEND);
        return data;
    }

    public Map getSBICoreErrorData()
    {

        logger.info("getSBICoreErrorData() " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List l = getJdbcTemplate().query(SQLConstants.SBI_CORE_ERROR_DATA, new NameValueMasterDataRowMapper());
            data = (Map) l.get(0);
            if (logger.isDebugEnabled())
            {
                logger.debug("data :" + data);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("getSBICoreErrorData() " + LoggingConstants.METHODEND);
        return data;
    }
    
    
    public Map findAllBranchName()
    {

        logger.info("findAllBranchName() " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List branchData = getJdbcTemplate().query(SQLConstants.BRANCH_CODE_NAME_QUERY, new NameValueMasterDataRowMapper());
            data = (Map) branchData.get(0);
            if (logger.isDebugEnabled())
            {
                logger.debug("data :" + data);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("findAllBranchName() " + LoggingConstants.METHODEND);
        return data;
    }
    
    /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
    public Map findAllNREProductCodes()
    {

        logger.info("findAllNREProductCodes " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List nreProductCodeData = getJdbcTemplate().query(SQLConstants.NRE_PRODUCT_CODE_QUERY, new NameValueMasterDataRowMapper());
            if(nreProductCodeData != null && nreProductCodeData.size() > 0) {
            	data = (Map) nreProductCodeData.get(0);
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("FindAll NRE ProductCodes Data :" + data);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("findAllNREProductCodes " + LoggingConstants.METHODEND);
        return data;
    }
    /*	CR-5655 Ramanan M - END - NRE check through Product Code	*/
    
    public Map getPortNumberData(String processorName)
    {

        logger.info("getPortNumberData(String processorName) " + LoggingConstants.METHODBEGIN);
        Map data = null;
        try
        {
            List l = getJdbcTemplate().query(SQLConstants.SBI_NAME_VALUE_PORT_NUMBER_DATA,new Object[]{processorName+"%"},
                    new NameValueMasterDataRowMapper());
            data = (Map) l.get(0);
            if (logger.isDebugEnabled())
            {
                logger.debug("data :" + data);
            }

        }
        catch (DataAccessException ex)
        {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        logger.info("getPortNumberData(String processorName)" + LoggingConstants.METHODEND);
        return data;
    }

    class NameValueMasterDataRowMapper implements RowMapper
    { 
        HashMap data = new LinkedHashMap();

        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            data.put(rs.getString(1), rs.getString(2));
            return data;
        }
    }

}
