package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.sbi.common.dao.SQLConstants;
import com.sbi.common.exception.DAOException;

import com.sbi.common.model.EchequeDetails;
import com.sbi.common.model.TransactionLeg;
import com.sbi.common.utils.StringUtils;




public class CorporateReportDAOImpl extends JdbcDaoSupport implements CorporateReportDAO{

	private Logger logger = Logger.getLogger(getClass());
	 private ResourceBundleMessageSource transactionProperties;
	 //5057
	 //Modified for CR 5615
	 private static final String ECHEQUE_DETAILS_TEMP="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," +
    "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ," +
    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO ,'-'  UTR_CREDITED_TIME ,'-' UTR_STATUS FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND A.ACCOUNT_NO=? AND A.BRANCH_CODE=? AND STATUS =1 AND A.FILE_NAME is null " +
    "AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY') AND  A.CORPORATE_ID= ?";
    
	/* private final String ECHEQUE_DETAILS_FILE="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
	    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," + "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ,"+
	    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
	    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND A.MAKER=? AND STATUS =1 AND A.FILE_NAME is not null "+"AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY')";*/
	 
	 private final String ECHEQUE_DETAILS_FILE_MAKER_TEMP="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
	    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," + "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ,"+
	    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO ,'-'  UTR_CREDITED_TIME ,'-' UTR_STATUS FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
	    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND (A.MAKER=? or A.AUTH1_NAME=? or A.AUTH2_NAME=?)AND A.ACCOUNT_NO=? AND STATUS =1 AND A.FILE_NAME is not null "+"AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY')";
	 
	 private final String ECHEQUE_DETAILS_FILE_UPLOAD_TEMP="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
	    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," + "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ,"+
	    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO  ,'-'  UTR_CREDITED_TIME ,'-' UTR_STATUS FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
	    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND (A.MAKER=? or A.AUTH1_NAME=? or A.AUTH2_NAME=?) AND STATUS =1 AND A.FILE_NAME is not null "+"AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY')";
	 
	//added for Cr 5615
	//modified for  corpuser paladion 
	    /*private static final String ECHEQUE_DETAILS="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
	    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," +
	    "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ," +
	    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO,"+
	    "DECODE(A.merchant_code,'GRPT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')   FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO)   ,'NEFT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'-') UTR_CREDITED_TIME , "+ 
	    "DECODE(A.merchant_code,'GRPT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO) ,'NEFT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'-') UTR_STATUS "+ 
	    "FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
	    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND A.ACCOUNT_NO=? AND A.BRANCH_CODE=? AND STATUS =1 AND A.FILE_NAME is null " +
	    "AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY') AND A.CORPORATE_ID = ?";*/
	 
	 private static final String ECHEQUE_DETAILS="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
			    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," +
			    "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,decode(B.CREDIT_STATUS,'CMP','Transaction Reversed Due to Invalid credit Account','ERR.','Failure'," +
			    "'RFN','Failure','REP.','Pending','F1','Pending','F2','Failure','F4','Falilure','LOG.','Unknown','RTM','Reversal In Process','00','Success','PROS','Success','RETU','Failure','Pending') CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ," +
			    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO,"+
			    "DECODE(A.merchant_code,'GRPT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')   FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO)  " +
			    ",'NEFT',(SELECT decode(C.TRANSACTION_STATUS,'Credited to Beneficiary Account',TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY'),'Fund settled by RBI with beneficiary Bank',TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY'),'-') FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'-') UTR_CREDITED_TIME , "+ 
			    "DECODE(A.merchant_code,'GRPT',decode(b.credit_status,'00',nvl((SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'Pending'),'-') ,'NEFT',decode(b.credit_status,'00',nvl((SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'Pending'),'-'),'-')  UTR_STATUS  "+ 
			    "FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
			    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND A.ACCOUNT_NO=? AND A.BRANCH_CODE=? AND STATUS =1 AND A.FILE_NAME is null " +
			    "AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY') AND A.CORPORATE_ID = ?";
	    
		 private final String ECHEQUE_DETAILS_FILE_MAKER="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
		    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," + "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ,"+
		    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO ,"+
		    "DECODE(A.merchant_code,'GRPT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO)   ,'NEFT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'') UTR_CREDITED_TIME , "+ 
		    "DECODE(A.merchant_code,'GRPT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO) ,'NEFT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'-') UTR_STATUS"+ 
		    " FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
		    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND (A.MAKER=? or A.AUTH1_NAME=? or A.AUTH2_NAME=?)AND A.ACCOUNT_NO=? AND STATUS =1 AND A.FILE_NAME is not null "+"AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY')";
		 
		 private final String ECHEQUE_DETAILS_FILE_UPLOAD="SELECT A.ECHEQUE_NO DEBIT_REF_NO,A.ACCOUNT_NO DEBIT_ACCOUNT,TO_CHAR(A.FIRST_AUTH_DATE,'dd/mm/yyyy  hh:mm:ss') FIRST_AUTH_DATE,TO_CHAR(A.SECOND_AUTH_DATE,'dd/mm/yyyy hh:mm:ss') SECOND_AUTH_DATE,A.BRANCH_CODE DEBIT_BRANCH ," +
		    "B.CREDIT_REFERENCE_NO CREDIT_REF_NO,DECODE(A.MERCHANT_CODE,'RTGS',B.CREDIT_NARRATIVE1,'NEFT',B.CREDIT_NARRATIVE1,B.ACCOUNT_NO) CREDIT_ACCOUNT," + "B.BRANCH_CODE CREDIT_BRANCH,B.AMOUNT DEBIT_AMOUNT,NVL(B.COMMISSION_AMOUNT,0) COMMISSION,A.MAKER TXN_MAKER,A.AUTH1_NAME AUTHORIZER1,A.AUTH2_NAME AUTHORIZER2,B.CREDIT_STATUS,B.STATUS_DESCRIPTION CREDIT_STATUS_DESCRIPTION ,"+
		    "A.DESCRIPTION CUSTOMER_DESCRIPTION ,A.CORP_REF_NO ,DECODE(A.merchant_code,'RTGS',B.UTR_NO,'GRPT',B.UTR_NO,'NEFT',B.UTR_NO,'') UTR_NO,"+
		    "DECODE(A.merchant_code,'GRPT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO)   ,'NEFT',(SELECT  TO_CHAR(C.POSTING_DATE,'DD/MM/YYYY')  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'') UTR_CREDITED_TIME , "+ 
		    "DECODE(A.merchant_code,'GRPT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO) ,'NEFT',(SELECT C.TRANSACTION_STATUS  FROM BVSBI.SBI_UTR_STATUS C WHERE C.REFERENCE_NO = B.UTR_NO),'-') UTR_STATUS"+ 
		    " FROM SBICORP_ECHEQUE_MASTER A,BVSBI.SBI_IB_CREDITS B " +
		    "WHERE A.ECHEQUE_NO = B.DEBIT_REFERENCE_NO AND (A.MAKER=? or A.AUTH1_NAME=? or A.AUTH2_NAME=?) AND STATUS =1 AND A.FILE_NAME is not null "+"AND A.DEBIT_STATUS = '00' AND TRUNC(RECO_GENERATED_TIME) BETWEEN TO_DATE(?,'DD/MM/YYYY') AND TO_DATE(?,'DD/MM/YYYY')";
		 
	    private static final String INSERT_REPORT_DETAILS="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_report_excel',?,?,'8',?,sysdate,sysdate)";
	    
	    private static final String INSERT_REPORT_DETAILS_UPLOAD="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_report_excel',?,?,'21',sysdate,sysdate)";
	    
	    private static final  String VIEW_ECHEQUE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2 from  bvsbi.sbi_lpr_input where user_name=? and request_type='corp_report_excel'and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
	    
	  //added for reissue challan
	    private final static String FIND_TRANSACTION_DETAILS="select 'D' type, '' remarks, reason_failure status_description, 'INR' currency, reference_no, account_no, branch_code, status_code, third_party_ref, amount, a.user_name, a.merchant_code,a.creation_time,'' narrative2,b.challan_required from sbi_ib_status_view a,sbi_merchant_master b where a.merchant_code=b.merchant_code and a.user_name=:1 and a.status=1 and trunc(a.creation_time) >=to_date(:2,'DD/MM/YYYY') and trunc(a.creation_time) <=to_date(:3,'DD/MM/YYYY') and a.MERCHANT_CODE<>'VISA' and status_code='00' and b.challan_required='0' and reference_no like 'IK%' order by a.creation_time desc";
	    private static final String INSERT_REQUEST_DOWNLOAD_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_down_file',?,?,'21',?,?,sysdate,sysdate)";//Cr5564
	    private static final String INSERT_REQUEST_BENEFICIARY_DOWNLOAD_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending',?,?,?,'21',?,?,sysdate,sysdate)";//Cr5564

	    //Added by devaraj for IMPS Starts
	    private static final String INSERT_REQUEST_IMPSTRANSACTION_DOWNLOAD_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','imps_txn_file',?,?,'21',?,?,sysdate,sysdate)";//Cr5564
	    private static final String INSERT_REQUEST_IMPSBENEFICIARY_DOWNLOAD_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME,REQUEST_TYPE) values(?,?,'Pending',?,?,'21',?,?,sysdate,sysdate,?)";//Cr5564
	    private static final String VIEW_IMPS_TXN_DOWNLOADFILE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,request_type from bvsbi.sbi_lpr_input where user_name=? and (request_type='imps_txn_file') and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564 //Modified for OLTAS changes and CR119
	    private static final String VIEW_IMPS_BEN_DOWNLOADFILE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,request_type from bvsbi.sbi_lpr_input where user_name=? and request_type in ('IMPSTP','IMPSDTP','IMPSP2ATP') and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564 //Modified for OLTAS changes and CR119
	    private static final String DISPLAY_IMPS_TXN_VAL_CRA_FILES="select REQUEST_ID,CREATION_TIME,PARAM6 from bvsbi.sbi_lpr_input where user_name=? and (request_type='imps_txn_file') AND REQUEST_ID =? and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564 //Modified for OLTAS changes
	    private static final String DISPLAY_IMPS_BEN_VAL_CRA_FILES="select lpr.REQUEST_ID,lpr.CREATION_TIME,lpr.PARAM6,nvl(fm.additional_field1,0) valfailcount,fm.sno from bvsbi.sbi_lpr_input lpr , sbi_file_master fm where lpr.user_name= ? and lpr.request_type in ('IMPSTP','IMPSDTP','IMPSP2ATP') AND lpr.REQUEST_ID = ? and fm.sno = lpr.param5 and  trunc(lpr.creation_time)>=trunc(sysdate-14) order by lpr.CREATION_TIME desc ";//CR5564 //Modified for OLTAS changes
	    //Added by devaraj for IMPS Ends
	    
	    // Added for Reprint Challan SARAL
		private final static String FIND_TRANSACTION_DETAILS_SARAL="select 'D' type, '' remarks, reason_failure status_description, 'INR' currency, reference_no, account_no, branch_code, status_code, third_party_ref, amount, a.user_name, a.merchant_code,a.creation_time,'' narrative2,b.challan_required from sbi_ib_status_view a,sbi_merchant_master b where a.merchant_code=b.merchant_code and a.user_name=? and a.status=1 and trunc(a.creation_time) >=to_date(?,'DD/MM/YYYY') and trunc(a.creation_time) <=to_date(?,'DD/MM/YYYY') and a.MERCHANT_CODE<>'VISA' and status_code='00' and b.challan_required='0' and  reference_no like 'CK%' order by a.creation_time desc";
	  
  // Added by sairam for OLTAS changes
	    private static final String INSERT_REQUEST_DOWNLOAD_OLTAS_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_down_oltas_file',?,?,'21',?,?,sysdate,sysdate)";//Cr5564//Modified the Query for OLTAS changes
	    																						  
	    //private static final  String VIEW_DOWNLOADFILE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-mon-yyyy:HH24:mi:SS'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-mon-yyyy:HH24:mi:SS'),'dd-mon-YY')PARAM2 from bvsbi.sbi_lpr_input where user_name=? and request_type='corp_down_file' and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564
	    private static final  String VIEW_DOWNLOADFILE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,request_type from bvsbi.sbi_lpr_input where user_name=? and (request_type='corp_down_file' OR request_type='corp_down_oltas_file' or request_type='comp_txn_down_file' ) and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564 //Modified for OLTAS changes
	    private static final  String VIEW_BENEFICIARY_DOWNLOADFILE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,request_type from bvsbi.sbi_lpr_input where user_name=? and (request_type='IB3P_down_file' OR request_type='COMPOSITE_down_file')and  trunc(creation_time)>=trunc(sysdate-30) order by CREATION_TIME desc";//CR119
	    private static final  String DISPLAY_TXN_VAL_CRA_FILES="select REQUEST_ID,CREATION_TIME,PARAM6 from bvsbi.sbi_lpr_input where user_name=? and (request_type='corp_down_file' OR request_type='corp_down_oltas_file' or request_type='comp_txn_down_file') AND REQUEST_ID =? and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";//CR5564 //Modified for OLTAS changes
	    
	    //Sairam Added for Report to Excel
	    private static final  String DOWNLOAD_BENEFICIARY_FILES="select lpr.REQUEST_ID,lpr.CREATION_TIME,lpr.PARAM6,nvl(fm.additional_field1,0) valfailcount,fm.sno from bvsbi.sbi_lpr_input lpr , sbi_file_master fm where lpr.user_name= ? and lpr.request_type in ('IB3P_down_file','COMPOSITE_down_file') AND lpr.REQUEST_ID = ? and fm.sno = lpr.param5 and  trunc(lpr.creation_time)>=trunc(sysdate-30) order by lpr.CREATION_TIME desc";//CR119
	    private static final  String DOWNLOAD_EXCEL_TXN_FILES="select REQUEST_ID,CREATION_TIME,PARAM6 from bvsbi.sbi_lpr_input where user_name=? and request_type='corp_report_excel' AND REQUEST_ID =? and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
	    
	    private static final String INSERT_EXCEL_REPORT_DETAILS_UPLOAD="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_report_excel',?,?,'21',?,?,sysdate,sysdate)";
		static int field=0;
		
		//Added for ddebit download file start 
		private static final String INSERT_REQUEST_DOWNLOAD_DDEBIT_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','ddebit_dealer_reg',?,?,'5','XLS',?,sysdate,sysdate)";
																																																
		private static final  String VIEW_DOWNLOAD_DDEBIT_FILE="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,request_type from bvsbi.sbi_lpr_input where user_name=? and request_type='ddebit_dealer_reg' and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
	    
		private static final String DISPLAY_DDEBIT_FILES  ="select REQUEST_ID,CREATION_TIME,PARAM6 from bvsbi.sbi_lpr_input where user_name=? and request_type='ddebit_dealer_reg' AND REQUEST_ID =? and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
		
		   //Added for Generate Comp Txn Report - Start
		  private static final String INSERT_REQUEST_DOWNLOAD_COMP_TXN_FILE="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','comp_txn_down_file',?,?,'21',?,?,sysdate,sysdate)";//Cr5564
			    

//Added by Damodar for Account based MIS reports
		//private static final String INSERT_MIS_EXCEL_REPORT_DETAILS_UPLOAD="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','account_mis',?,?,'21',?,?,sysdate,sysdate)";
		private static final String INSERT_MIS_EXCEL_REPORT_DETAILS_UPLOAD="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','account_mis',?,?,?,?,?,sysdate,sysdate)";
		
		
		//private static final  String MIS_VIEW_ECHEQUE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2 from  bvsbi.sbi_lpr_input where user_name=? and request_type='account_mis' and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
		private static final  String MIS_VIEW_ECHEQUE_DETAILS="select REQUEST_ID,CREATION_TIME,STATUS, PARAM1,PARAM2 from  bvsbi.sbi_lpr_input where user_name=? and request_type='account_mis' and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
		
		private static final  String MIS_DOWNLOAD_EXCEL_TXN_FILES="select REQUEST_ID,CREATION_TIME,PARAM6 from bvsbi.sbi_lpr_input where user_name=? and request_type='account_mis' AND REQUEST_ID =? and  trunc(creation_time)>=trunc(sysdate-14) order by CREATION_TIME desc";
			
		private static final String LPR_INPUT_FAILURE_TXN="insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS,REQUEST_TYPE,PARAM1,PARAM2,PARAM3,PARAM4,CREATION_TIME,PROCESS_TIME) values(?,?,'Pending','corp_failtxn_report',?,?,'10',?,sysdate,sysdate)";
		
		//Added for ddebit download file end
	 public Map getPendingTransaction(Map inputParams) throws DAOException
	    {
	    	logger.info("getPendingTransaction(String fromDate,String toDate,String userName) method begin");
	    	String userName=(String)inputParams.get("userName");
	        String fromDate = (String) inputParams.get("fromDate");
	        String toDate = (String) inputParams.get("toDate");
	        String branchCode=(String) inputParams.get("branchCode");
	        String limit=(String) inputParams.get("limit");
	        String pageNo=(String) inputParams.get("pageNo");
	        String corpRole=(String) inputParams.get("corpRole");
	        HashMap result=new HashMap();
	        String query=null;
	        String queryForCount=null;
	        if(corpRole!=null && corpRole.equals("admin")){
		        query="SELECT  a.account_no, a.branch_code, a.echeque_amount, a.auth1_name,a.auth2_name,a.creation_time,a.echeque_no, NAME, a.current_auth_level,DECODE (a.current_auth_level,'1', 'Pending with First Level Authorizer','2',  'Pending with Second Level Authorizer','-5', 'Pending with Approver','--') pending FROM sbicorp_echeque_master a, bv_user e,bv_user_profile f WHERE a.maker in(select user_name from sbicorp_ca_user_map where ca_user=?)  AND a.status = 1 AND e.user_id = f.user_id AND e.user_alias = a.maker AND nvl(a.current_auth_level,'0') in ('1','2','-5') AND TO_DATE (a.echeque_date, 'dd/mm/yy')  between TO_DATE (?, 'dd/mm/yy') and  TO_DATE (?, 'dd/mm/yy')  ORDER BY a.creation_time desc";
		        queryForCount="SELECT  count(*) FROM sbicorp_echeque_master a, bv_user e,bv_user_profile f WHERE a.maker in(select user_name from sbicorp_ca_user_map where ca_user=?) AND a.status = 1 AND e.user_id = f.user_id AND e.user_alias =a.maker AND nvl(a.current_auth_level,'0') in ('1','2','-5') AND TO_DATE(a.echeque_date, 'dd/mm/yy')  between TO_DATE (?, 'dd/mm/yy') and  TO_DATE (?, 'dd/mm/yy')";		        
		     }
	        else{
	        	 logger.info(" corpRole:" + corpRole);
	        	query="SELECT  a.account_no, a.branch_code, a.echeque_amount, a.auth1_name,a.auth2_name,a.creation_time,a.echeque_no, NAME, a.current_auth_level,DECODE (a.current_auth_level,'1', 'Pending with First Level Authorizer','2',  'Pending with Second Level Authorizer','-5', 'Pending with Approver','--') pending FROM sbicorp_echeque_master a, bv_user e,bv_user_profile f WHERE a.maker =? AND a.status = 1 AND e.user_id = f.user_id AND e.user_alias = a.maker AND nvl(a.current_auth_level,'0') in ('1','2','-5') AND TO_DATE (a.echeque_date, 'dd/mm/yy')  between TO_DATE (?, 'dd/mm/yy') and  TO_DATE (?, 'dd/mm/yy')  ORDER BY a.creation_time desc";
		        queryForCount="SELECT  count(*) FROM sbicorp_echeque_master a, bv_user e,bv_user_profile f WHERE a.maker=? AND a.status = 1 AND e.user_id = f.user_id AND e.user_alias =a.maker AND nvl(a.current_auth_level,'0') in ('1','2','-5') AND TO_DATE(a.echeque_date, 'dd/mm/yy')  between TO_DATE (?, 'dd/mm/yy') and  TO_DATE (?, 'dd/mm/yy')";		        
	        }
	        logger.info(" query:" + query);
	        logger.info(" queryForCount:" + queryForCount);	
	        String pagenationQuery=SQLConstants.PAGINATION_TEMPLATE_QRY.replaceFirst("#replaceQuery#", query);
	        if(fromDate == null || toDate==null || userName == null)            
	        {
	            DAOException.throwException("F001");
	        }
	        int[]sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.INTEGER,Types.INTEGER};
	        int[]sqlTypesCount = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	        try
	        {
	            Object[] parameters = {userName,fromDate,toDate,Integer.parseInt(pageNo)*Integer.parseInt(limit),(Integer.parseInt(pageNo)*Integer.parseInt(limit))-Integer.parseInt(limit)};
	            Object[] parametersCount = {userName,fromDate,toDate};
	            int count=getJdbcTemplate().queryForInt(queryForCount,parametersCount,sqlTypesCount);
	            if (count>0){
	            List pendingEhequeList = getJdbcTemplate().query(pagenationQuery, parameters,sqlTypes,new ReportRowMapperForPending());
	            result.put("pendingEcheques", pendingEhequeList);
	            result.put("totalCount", count);
	            
	            return result;
	           
	            }
	            logger.info("No Pending Transactions");
	            logger.info(" result:" + result);
	            
	              
	        }catch(DAOException exception)
	        {
	        	
	            DAOException.throwException("F001", exception);
	        }
	  logger.info("findPendingEcheques(String fromDate,String toDate,String userName) method end");
	        return null;
	    }


	class ReportRowMapperForPending implements RowMapper{
		 public Object mapRow(ResultSet rs, int index) throws SQLException {
			   EchequeDetails details = new EchequeDetails();
        
			   details .setAccountNo(rs.getString("ACCOUNT_NO"));
			   details .setBranchCode(rs.getString("BRANCH_CODE"));
			   details .setEchequeAmount(new Double(rs.getDouble("ECHEQUE_AMOUNT")));
       // echequeMaster.setEchequeDate(rs.getDate("CREATION_TIME"));
			   details .setEchequeNo(rs.getString("ECHEQUE_NO"));
			   details .setMaker(rs.getString("name"));
			   details .setCurrentAuthLevel(rs.getString("CURRENT_AUTH_LEVEL"));
			   details .setDescription(rs.getString("PENDING"));
			   details .setDate(rs.getDate("CREATION_TIME"));
			   details .setFirstauth(rs.getString("auth1_name")); 
			   details .setSecondauth(rs.getString("auth2_name"));
        return details ;
			 
		  } 
	 }
	 
	 //CR 5057 starts
	//modified for  corpuser paladion 
	    public List retrieveEcheques(String accountNo,String brCode,String fromDate,String toDate,String corporateId) throws DAOException{
	        logger.info("retrieveEcheques(String brCode, String accountNo,String fromDate,String toDate)corporateId method begins");
	        logger.info("accountNo,brCode,fromDate,toDate,corporateId" +accountNo+brCode+fromDate+toDate+corporateId );
	        
	        List echequeList=null;
	        if(accountNo != null && brCode != null && fromDate != null && toDate != null && corporateId != null){
	        	//modified for  corpuser paladion 
	            Object[] params={accountNo,brCode,fromDate,toDate,corporateId};
	            String startDate =  fromDate ;
	            try{ 
	            	if (checkDate(startDate)){  // ADded for Cr 5615
	            		logger.info("from date greater than  Nov 1st");
	            	  echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS,params, new TransactionReportRowMapper());
	            	}
	            	else{
	            		logger.info("from date less than  Nov 1st");
	            		echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS_TEMP,params, new TransactionReportRowMapper());
	            	}
	            }catch (DataAccessException exception) {
	            	logger.info("here");
	            	exception.printStackTrace();
	                DAOException.throwException("CUS006",new Object[] {accountNo,brCode,fromDate,toDate});
	            } 
	        }else {
	            DAOException.throwException("CUS006",new Object [] {accountNo,brCode,fromDate,toDate});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("retrieveEcheques(String brCode, String accountNo,String fromDate,String toDate) corporateId method ends");
	        return echequeList;
	    }
	 public List fileBasedEcheques(String fromDate,String toDate,String userName,String accountNo,String corpRole) throws DAOException{
	        logger.info("fileBasedEcheques(String fromDate,String toDate,String username) method begins");
	        logger.info("corpRole1:"+corpRole);
	        List echequeList=null;
	        if( fromDate != null && toDate != null  ){
	            Object[] params={userName,userName,userName,fromDate,toDate};
	            try{
	            	
	            	if(corpRole!=null && corpRole.equals("corpuser")){
	            		 if(accountNo != null){
	            		  logger.info("corpRole:"+corpRole+"accountNo:"+accountNo);
	            		  params=new Object[]{userName,userName,userName,accountNo,fromDate,toDate};
	            		  if (checkDate(fromDate)) // ADded for Cr 5615
	            		  {
	            		  echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS_FILE_MAKER,params, new TransactionReportRowMapper());
	            		  }
	            		  else
	            		  {
	            			  echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS_FILE_MAKER_TEMP,params, new TransactionReportRowMapper());
	            		  }
	            	  }
	            	else
	            	{
		            		 DAOException.throwException("CUS006",new Object [] {fromDate,toDate});//input params are null
			     	            logger.info("Null Input");// Exception to be added
			        }
	            	}else
	            	  {
	            		  logger.info("corpRole1:"+corpRole);
	            		  logger.info("accountNo:"+accountNo);
	            		  if (checkDate(fromDate)) // ADded for Cr 5615
	            		  {
	            		  echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS_FILE_UPLOAD,params, new TransactionReportRowMapper());
	            		  }
	            		  else {
	            			  echequeList = getJdbcTemplate().query(ECHEQUE_DETAILS_FILE_UPLOAD_TEMP,params, new TransactionReportRowMapper());
	            		  }
	            	  }
	            	 
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {fromDate,toDate});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("fileBasedEcheques(String fromDate,String toDate,String username) method ends");
	        return echequeList;
	    }
	 class  TransactionReportRowMapper implements RowMapper {
		         public Object mapRow(ResultSet rs, int index) throws SQLException {
		        	 
	        	   EchequeDetails details = new EchequeDetails();
	        	   details.setDebit_ref_no(rs.getString("debit_ref_no"));
	        	   details.setDebit_account(rs.getString("debit_account"));
	        	   details.setDebit_branch(rs.getString("debit_branch"));
	        	   details.setCredit_ref_no(rs.getString("credit_ref_no"));
	        	   details.setCreditAccountNo(rs.getString("credit_account"));
	        	   details.setCreditBranchName(rs.getString("credit_branch"));
	        	   details.setDebit_amount(rs.getString("debit_amount"));
	        	   details.setCommission(rs.getString("commission"));
	        	   details.setCreditStatus(rs.getString("credit_status"));
	        	 //  rs.getString("CREDIT_STATUS_DESCRIPTION")
	        	  //added for CR 5615
	        	   String utrCredit ="CR".contains((rs.getString("debit_ref_no")).substring(0,2)) ? rs.getString("CREDIT_STATUS_DESCRIPTION"):(rs.getString("UTR_STATUS"));
	        	   details.setUtr_status(utrCredit);
	        	   //String  statusDesc= "CR|CZ".contains((rs.getString("debit_ref_no")).substring(0,2)) ? "-" :rs.getString("CREDIT_STATUS_DESCRIPTION");
	        	   // GRBT enabled CZ transaction 
	        	   String  statusDesc= "CR".contains((rs.getString("debit_ref_no")).substring(0,2)) ? "-" :rs.getString("CREDIT_STATUS_DESCRIPTION");
	        	   
	        	   details.setCredit_status_description(statusDesc);
	        	 //added for CR 5615 ends
	        	   details.setDescription(rs.getString("customer_description"));
	        	   details.setCorpRefNo(rs.getString("corp_ref_no"));
	        	   details.setUtr_no(rs.getString("utr_no"));
	        	   details.setMaker(rs.getString("TXN_MAKER"));
	        	   details.setFirstauth(rs.getString("AUTHORIZER1"));
	        	   details.setSecondauth(rs.getString("AUTHORIZER2"));
	            //Added For CR 5531 Starts
	        	   details.setAuth1_date(rs.getString("FIRST_AUTH_DATE"));
	        	   details.setAuth2_date(rs.getString("SECOND_AUTH_DATE"));
	            //Added For CR 5531 Ends
	            //echequeMaster.setUtr_status(rs.getString("utr_status"));
	        	   //added for Cr 5615
	        	   details.setUtr_posted_time(rs.getString("UTR_CREDITED_TIME"));
	            return details;
	        }
	        
	 }
	 
	 
	 private class ViewListExtractor implements ResultSetExtractor{
	    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
	    		List dataList = new ArrayList();

	    		while(rs.next()){
		    		Map result=new HashMap();
	    			logger.info("request id: "+rs.getString("REQUEST_ID"));
	    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
	    			SimpleDateFormat sdf=new SimpleDateFormat();
	    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
	    			logger.info("STATUS : "+sdf.format(rs.getTimestamp("CREATION_TIME")));
	    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
	    		
	    			logger.info("STATUS : "+rs.getString("STATUS"));
	    			result.put("STATUS",rs.getString("STATUS"));
	    			
	    			logger.info("from date : "+rs.getString("PARAM1"));
	    			result.put("PARAM1",rs.getString("PARAM1"));
	    			logger.info("to date : "+rs.getString("PARAM2"));
	    		
	    
	    			
	    			result.put("PARAM2",rs.getString("PARAM2"));
	    			dataList.add(result);
	    		}
	    		return dataList;
	    	}
	    }
	        public String generateRequestId(String fromDate, String toDate,
	    			String userName,String accountNo,String corpRole) throws DAOException {
	    	 logger.info("generateRequestId(String fromDate,String toDate,String usernameString accountNo,String userRole) method begins");
	    	  String requestId=null;
	    	  if(fromDate == null || toDate==null || userName == null)            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  Object[] insertParams={requestId,userName,fromDate,toDate};
	            	  if(corpRole!=null && corpRole.equals("corpuser")){
	            		  logger.info("corpRole1:"+corpRole);
	            		  insertParams=new Object[]{requestId,userName,fromDate,toDate,accountNo};
	            		  getJdbcTemplate().update(INSERT_REPORT_DETAILS,insertParams);	
	            	  }
	            	  else{
	            		  logger.info("corpRole1:"+corpRole);
	            		  getJdbcTemplate().update(INSERT_REPORT_DETAILS_UPLOAD,insertParams);	
	            	  }
	              logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	    	 return requestId;
	    	 
	    }
	       /* 
	        public String generateRequestId(String fromDate, String toDate,
	    			String userName,String accountNo,Integer count,String userRole) throws DAOException {
	    	 logger.info("generateRequestId(String fromDate,String toDate,String username) method begins");
	    	 try{
	            	  String requestId=null;       	  
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  Object[] insertParams={requestId,userName,fromDate,toDate,userRole};
	            	  getJdbcTemplate().update(INSERT_REPORT_DETAILS,insertParams);
	             
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	    	 return requestId;
	    	 
	    }*/
	        
    	public List viewEchequesDisplay(String userName) throws DAOException{
	        logger.info("viewEchequesDisplay(String username) method begins");
	        List echequeList=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName};
	                echequeList = (List)getJdbcTemplate().query(VIEW_ECHEQUE_DETAILS,params, new ViewListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("viewEchequesDisplay(String fromDate,String toDate,String username) method ends");
	        return echequeList;
	}
    	
    	//added by Damodar for Account Based MIS
    	
    	public List MISviewEchequesDisplay(String userName) throws DAOException{
	        logger.info("MISviewEchequesDisplay(String username) method begins");
	        List echequeList=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName};
	                echequeList = (List)getJdbcTemplate().query(MIS_VIEW_ECHEQUE_DETAILS,params, new MISViewListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("MISviewEchequesDisplay(String fromDate,String toDate,String username) method ends");
	        return echequeList;
	}
	    
    	private class MISViewListExtractor implements ResultSetExtractor{
	    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
	    		List dataList = new ArrayList();

	    		while(rs.next()){
		    		Map result=new HashMap();
	    			logger.info("request id: "+rs.getString("REQUEST_ID"));
	    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
	    			SimpleDateFormat sdf=new SimpleDateFormat();
	    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
	    			logger.info("CREATION_TIME : "+sdf.format(rs.getTimestamp("CREATION_TIME")));
	    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
	    		
	    			logger.info("STATUS : "+rs.getString("STATUS"));
	    			result.put("STATUS",rs.getString("STATUS"));
	    			
	    			logger.info("Transaction type : "+rs.getString("PARAM1"));
	    			result.put("PARAM1",rs.getString("PARAM1"));
	    			logger.info("Transaction Date : "+rs.getString("PARAM2"));
	    		
	    
	    			
	    			result.put("PARAM2",rs.getString("PARAM2"));
	    			dataList.add(result);
	    		}
	    		return dataList;
	    	}
	    }
    	
	    
	  //Added for reissue challan cr
	     public List getTransactionsDetails(String userName,String date) {

	         logger.info("findDebits(String userName,String date) Begin " );             

	         if (userName != null && !userName.trim().equals(DAOConstants.EMPTY)) {
	                  try {
		             	 List debitsList=null;
		                 Object[] parameters = new Object[]
		                 { userName ,date,date };
		                 debitsList = getJdbcTemplate().query(FIND_TRANSACTION_DETAILS, parameters,
		                         new TransactionLegRowMapper());
		                 if (debitsList != null && debitsList.size() > 0) {
		                     if (logger.isDebugEnabled()) {
		                         logger.debug("findDebits(String userName) End debitsList :" + debitsList);
		                     }
		                     
		                     return debitsList;
	                 }
	                 else{
	                 	logger.debug("findDebits(String userName,String fromDate,String toDate) End" );
	                     return null;
	                 }

	             }
	             catch (DataAccessException ex) {

	                 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	             }
	         }
	         else {
	             DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	         }
	         return null;
	     }
	    
	  //Added for  Reprint Challan SARAL Starts
	     public List getSARALTransactionsDetails(String userName,String fromDate,String toDate) {

	         logger.info("getSARALTransactionsDetails(String userName,String fromDate,String toDate) Begin" );             

	         if (userName != null && !userName.trim().equals(DAOConstants.EMPTY)) {
	            logger.info("test"+fromDate+"'"+toDate);
	             try {
	             	List debitsList=null;
	                 Object[] parameters = new Object[]
	                 { userName ,fromDate, toDate };
	               
	                 
	                	 debitsList = getJdbcTemplate().query(FIND_TRANSACTION_DETAILS_SARAL, parameters, new TransactionLegRowMapper());
	                 
	                 
	                               
	                 if (debitsList != null && debitsList.size() > 0) {
	                     if (logger.isDebugEnabled()) {
	                         logger.debug("findDebits(String userName) End debitsList :" + debitsList);
	                     }
	                     
	                     return debitsList;
	                 }
	                 else{
	                 	logger.debug("findDebits(String userName,String fromDate,String toDate) End" );
	                     return null;
	                 }

	             }
	             catch (DataAccessException ex) {

	                 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
	             }
	         }
	         else {
	             DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	         }
	         return null;
	     }
	     
	   //Added for SARAL Reprint Challan Ends
	     
	     class TransactionLegRowMapper implements RowMapper {
	         public Object mapRow(ResultSet rs, int index) throws SQLException {
	             TransactionLeg tran = new TransactionLeg();

	             tran.setReferenceNo(rs.getString(SQLConstants.REFERENCE_NO));
	             logger.info("identifier inside rowmapper"+rs.getString(SQLConstants.REFERENCE_NO).substring(0, 2));
	             String identifier = rs.getString(SQLConstants.REFERENCE_NO).substring(0, 2);
	             logger.info("key value"+DAOConstants.TXN_NAME_PROPERTY + identifier);
	             String message = getTransactionStatus(DAOConstants.TXN_NAME_PROPERTY + identifier);
	             tran.setType(message); 
	             tran.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
	             tran.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
	             tran.setBranchName(getBranchName(rs.getString(DAOConstants.BRANCH_CODE)));
	           String statusCode = rs.getString(DAOConstants.STATUS_CODE);
	           String tranCode = getTransactionStatus("status." + statusCode);
	           tran.setStatusCode(tranCode);        
	             tran.setThirdPartyRef(rs.getString(DAOConstants.THIRD_PARTY_REF));
	             tran.setAmount(new Double(rs.getDouble(SQLConstants.AMOUNT)));
	             tran.setUserName(rs.getString(SQLConstants.USER_NAME));
	             tran.setMerchantCode(rs.getString(SQLConstants.MERCHANT_CODE));
	             tran.setStatusDescription(rs.getString(SQLConstants.STATUS_DESC));
	             tran.setAdditionalParams(null);// check it
	             tran.setCurrency(rs.getString(DAOConstants.CURRENCY));
	             tran.setRemarks(rs.getString(SQLConstants.REMARKS));
	             tran.setTransactionTime(rs.getTimestamp(SQLConstants.CREATION_TIME));
	             tran.setProductType(identifier); // This is field using for store the above "identifier" ;
	 				
	             return tran;
	         }
	     }private String getTransactionStatus(String key) {
	         String transactionValue = DAOConstants.TXN_STATUS_UNKNOWN;
	         try {
	             transactionValue = transactionProperties.getMessage(key, null, null);
	             logger.info("transactionValue inside row mapper"+transactionValue);
	         }
	         catch (NoSuchMessageException ex) {
	            //logger.error("Exception occured" ,ex );
	         }

	         return transactionValue;
	     }
	     public String getBranchName(String branchCode) throws DAOException

	     {    
	         String branchName = null;
	         Object[] parameters = new Object[] {branchCode};
	         if (branchCode != null && ! branchCode.trim().equals("")) {
	             branchName = (String) (String) getJdbcTemplate().queryForObject("SELECT BRANCH_NAME FROM SBI_BRANCH_MASTER WHERE BRANCH_CODE= ? AND STATUS='1'",parameters,String.class);
	         }
	         if (logger.isDebugEnabled()) {
	         logger.debug("getBranchName(String branchCode) method end");
	         }
	         return branchName;
	     }
	     public void setTransactionProperties(ResourceBundleMessageSource transactionProperties) {
	         this.transactionProperties = transactionProperties;
	     }
	     
	     //ends
	  // ADded for Cr 5615
	     private boolean checkDate (String startDate){
	    	 logger.info("private boolean checkDate (String fromDate) method begin");
	    	 logger.info("startDate" + startDate);
	    	 String maxDate="31/10/2010";
	    	 boolean  status = false;
			try {
			    DateFormat  formatter = new SimpleDateFormat("dd/MM/yyyy");
				Date date = (Date)formatter.parse(maxDate);
				logger.info("date" +date);
				Timestamp initialDate = new Timestamp(formatter.parse( startDate ).getTime());
				logger.info("startDate" +startDate);
					if (initialDate.after(date) )
						status = true ; 
	         	
			} catch (ParseException e) {
				e.printStackTrace();
			}
	    	 logger.info("startDate" + startDate);

			logger.info("private boolean checkDate (String fromDate) method ends");
            return status;
         
	     }

  //CR5564
		   public String generateRequestIdForDownloadFile(String fromDate, String toDate,String filename,
	    			String userName,String corpId) throws DAOException {
	    	 logger.info("generateRequestIdForDownloadFile(String fromDate,String toDate,String username,String userRole) method begins");
	    	  String requestId=null;
	    	  if(fromDate == null || filename==null || userName == null)            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  logger.info("requestId.substring(3, 17);;;;"+requestId);
	            	  requestId = requestId.substring(2);
	            	  logger.info("requestId.substring(2);;;;"+requestId);
	            	  String rid="DF";
	            	  requestId = rid.concat(requestId);
	            	  logger.info("final requestId .."+requestId);
	            	  logger.info("final fromDate .."+fromDate);
	            	  logger.info("final toDate .."+toDate);
	            	  logger.info("final userName .."+userName);
	            	  logger.info("final corpId .."+corpId);
	            	  logger.info("final filename .."+filename);
	            	  
	            	  Object[] insertParams={requestId,userName,fromDate,toDate,corpId,filename};
	            	  getJdbcTemplate().update(INSERT_REQUEST_DOWNLOAD_FILE,insertParams);	
	            	  
	              logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	    	 return requestId;
	    	 
	    }
		   /*Added by Sairam for OLTAS Changes - Start*/
		   
		   public String generateRequestIdForDownloadOltasFile(String fromDate, String toDate,String filename,
	    			String userName,String corpId,String fileType) throws DAOException {
	    	 logger.info("generateRequestIdForDownloadOltasFile(String fromDate,String toDate,String username,String userRole,String fileType) method begins");
	    	  String requestId=null;
	    	  if(fromDate == null || filename==null || userName == null)            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId  :"+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  requestId = requestId.substring(2);
	            	  String rid="DF";
	            	  requestId = rid.concat(requestId);
	            	  logger.info("final requestId :"+requestId);
	            	  logger.info("final fromDate :"+fromDate);
	            	  logger.info("final toDate :"+toDate); 
	            	  logger.info("final userName :"+userName);
	            	  logger.info("final corpId :"+corpId);
	            	  logger.info("final filename :"+filename);
	            	  logger.info("file type :"+fileType);
	            	  Object[] insertParams={requestId,userName,fromDate,toDate,corpId,filename};
	            	  getJdbcTemplate().update(INSERT_REQUEST_DOWNLOAD_OLTAS_FILE,insertParams);	
	            	 
	              logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	    	 return requestId;
	    	 
	    }
		   
		   /*Added by Sairam for OLTAS Changes - End*/

// CR 119 
		   public String generateRequestIdForIB3PFileDownload(String fromDate, String toDate,String filename,
	    			String userName,String corpId,String category) throws DAOException {
	    	  String requestId=null;
	    	  String requestType=null;
	    	  if(fromDate == null || filename==null || userName == null)            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	        	  	Date d = new Date();
					String dateString=String.valueOf(d.getTime());
					logger.info( " dateString "+ dateString );
			  	  if(field>9999)
			  		  field=1;
			  	  else field+=1;
			  	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
			  	  requestId=dateString+padChar;
			  	  requestId=requestId.substring(3, 17);
			  	  requestId = requestId.substring(2);
			  	  String rid="";
			  	  logger.info( " category "+ category );
			  	  if(category != "" && category != null)
			  	  {
				  	  if("3P".equalsIgnoreCase(category) )
				  	  {
				  		 rid="A3P";
				  		requestType="IB3P_down_file";
				  	  }
				  	  if("D3P".equalsIgnoreCase(category) )
				  	  {
				  		  rid="D3P";
				  		requestType="IB3P_down_file";
				  	  }
				  	  else if("IBTP".equalsIgnoreCase(category) )
				  	  {
				  		  rid="AIB";
				  		requestType="IB3P_down_file";
				  	  }
				  	  else if("DIBTP".equalsIgnoreCase(category))
				  	  {
				  		  rid="DIB";
				  		requestType="IB3P_down_file";
				  	  }
				  	else if("COMPOSITE_BEN".equalsIgnoreCase(category))
				  	{
				  		  rid="CB";
				  	requestType="COMPOSITE_down_file";
			  	  }
				  	  
				  	  
				  	  //added by Damodar for Aadar benficiary upload
				  	else if("ABTP".equalsIgnoreCase(category))
				  	{
				  		  rid="CB";
				  	requestType="COMPOSITE_down_file";
			  	  }
				  	else if("ABTXN".equalsIgnoreCase(category))
				  	{
				  		  rid="CB";
				  	requestType="COMPOSITE_down_file";
			  	  }
				  	  
				  	  
			    }
			  	  logger.info( " rid :  "+ rid );
			  	  requestId = rid.concat(requestId);
			  	  
			  	  logger.info( " requestId "+ requestId );
			  	  
	            	  Object[] insertParams={requestId,userName,requestType,fromDate,toDate,corpId,filename};
	            	  getJdbcTemplate().update(INSERT_REQUEST_BENEFICIARY_DOWNLOAD_FILE,insertParams);

			  	  logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	          logger.info("generateRequestIdForDownloadFile(String fromDate,String toDate,String username,String userRole,String category) method end");
	    	 return requestId;
	    	 
	    }
// CR 119	   
		   public List viewDownloadFileRequestStatus(String userName) throws DAOException{
		        logger.info("viewDownloadFileRequestStatus(String username) method begins");
		        logger.info("username::::"+userName);
		        List echequeList=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName};
		                echequeList = (List)getJdbcTemplate().query(VIEW_DOWNLOADFILE_DETAILS,params, new ViewStatusListExtractor());
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("fileBasedEcheques(String fromDate,String toDate,String username) method ends");
		        return echequeList;
		}
		   public List viewBenDownloadFileRequestStatus(String userName) throws DAOException{
			   logger.info("viewDownloadFileRequestStatus(String username) method begins");
			   logger.info("username::::"+userName);
			   List echequeList=null;
			   if( userName != null ){
				   Object[] params;
				   try{
					   params = new Object[] {userName};
					   echequeList = (List)getJdbcTemplate().query(VIEW_BENEFICIARY_DOWNLOADFILE_DETAILS,params, new ViewStatusListExtractor());
				   }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("fileBasedEcheques(String fromDate,String toDate,String username) method ends");
		        return echequeList;
		}
		    private class ViewStatusListExtractor implements ResultSetExtractor{
		    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		    		List dataList = new ArrayList();

		    		while(rs.next()){
			    		Map result=new HashMap();
		    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
		    			SimpleDateFormat sdf=new SimpleDateFormat();
		    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
		    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
		    		
		    			result.put("STATUS",rs.getString("STATUS"));
		    			
		    			result.put("PARAM1",rs.getString("PARAM1"));
		    			
		    		
		    
		    			
		    			result.put("PARAM2",rs.getString("PARAM2"));
		    			dataList.add(result);
		    		}
		    		return dataList;
		    	}
		    }
		    
		    
		    public List getTransactionFiles(String userName,String requestId) throws DAOException{
		        logger.info("getTransactionFiles(String username) method begins");
		        logger.info("username::::***"+userName);
		        logger.info("requestId::::"+requestId);
		        List txnfilelist=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName,requestId};
		            	txnfilelist = (List)getJdbcTemplate().query(DISPLAY_TXN_VAL_CRA_FILES,params, new getTxnListListExtractor());
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("getTransactionFiles(String username) method ends");
		        return txnfilelist;
		}
		    private class getTxnListListExtractor implements ResultSetExtractor{
		    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		    		List dataList = new ArrayList();

		    		while(rs.next()){
			    		Map result=new HashMap();
		    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
		    			SimpleDateFormat sdf=new SimpleDateFormat();
		    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
		    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
		    			result.put("PARAM6",rs.getString("PARAM6"));
		    			dataList.add(result);
		    		}
		    		return dataList;
		    	}
		    }
		    private class getBenListExtractor implements ResultSetExtractor{
		    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		    		List dataList = new ArrayList();
		    		
		    		while(rs.next()){
		    			Map result=new HashMap();
		    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
		    			SimpleDateFormat sdf=new SimpleDateFormat();
		    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
		    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
		    			result.put("PARAM6",rs.getString("PARAM6"));
		    			result.put("valfailcount",rs.getString("valfailcount"));
		    			result.put("sno",rs.getString("sno"));
		    			dataList.add(result);
		    		}
		    		return dataList;
		    	}
		    }
		    public List getBeneficiaryFiles(String userName,String requestId) throws DAOException{
		    	logger.info("getTransactionFiles(String username) method begins");
		    	logger.info("username::::***"+userName);
		    	logger.info("requestId::::"+requestId);
		    	List txnfilelist=null;
		    	if( userName != null ){
		    		Object[] params;
		    		try{
		    			params = new Object[] {userName,requestId};
		    			txnfilelist = (List)getJdbcTemplate().query(DOWNLOAD_BENEFICIARY_FILES,params, new getBenListExtractor());
		    			logger.info("txnfilelist : "+txnfilelist);
		    		}catch (DataAccessException exception) {
		    			DAOException.throwException("CUS006",new Object[] {userName});
		    		}
		    	}else {
		    		DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		    		logger.info("Null Input");// Exception to be added
		    	}
		    	logger.info("getTransactionFiles(String username) method ends");
		    	return txnfilelist;
		    }
		    
		/*Added by Sairam for CINB Report - start */    
		    
		    public List getDownloadByExcelTransactionFiles(String userName,String requestId) throws DAOException{
		        logger.info("getDownloadByExcelTransactionFiles(String username) method begins");
		        logger.info("username :"+userName+"requestId :"+requestId);
		        
		        List txnfilelist=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName,requestId};
		            	txnfilelist = (List)getJdbcTemplate().query(DOWNLOAD_EXCEL_TXN_FILES,params, new getTxnListListExtractor());
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("getDownloadByExcelTransactionFiles(String username) method ends");
		        return txnfilelist;
		}  
		    
     /*Added by Sairam for CINB Report - end*/
	     
		    
  /*Added by Sairam for excel report - Start*/

		    
		    public String generateExcelRequestId(String fromDate, String toDate,
	    			String userName,String formatType,String corporateId) throws DAOException {
	    	 logger.info("generateExcelRequestId(String fromDate,String toDate,String usernameString accountNo,String userRole) method begins");
	    	  String requestId=null;
	    	  
	    	  logger.info("formatType="+formatType+"corporateId="+corporateId);
	    	  if(fromDate == null || toDate==null || userName == null || formatType == null || corporateId == null )            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  logger.info("requestId ="+requestId+": userName ="+userName+": fromDate ="+fromDate+": toDate ="+toDate+": formatType ="+formatType+": corporateId ="+corporateId);
	            	  Object[] insertParams={requestId,userName,fromDate,toDate,formatType,corporateId};
	            	  getJdbcTemplate().update(INSERT_EXCEL_REPORT_DETAILS_UPLOAD,insertParams);	
	            	 
	              logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
	    	 return requestId;
	    	 
	    }
		    /*Added by Sairam for excel report - End*/
		    
		    
		    
		    
		    /*Added by Damodar for Account based MIS reports*/
		    
		    public String generateExcelRequestIdforMIS(String txnDate, String txnType,String accountNo,String userName,String formatType,String corporateId) throws DAOException {
		    	
	    	 logger.info("generateExcelRequestIdforMIS(String fromDate,String toDate,String usernameString accountNo,String userRole) method begins");
	    	  String requestId=null;
	    	  
	    	  logger.info("formatType="+formatType+"corporateId="+corporateId);
	    	  logger.info("account No"+accountNo+"formatType"+formatType);
	    	  if(txnDate == null || accountNo==null || userName == null || formatType == null || corporateId == null )            
	          {
	              DAOException.throwException("F001");
	          }
	    	
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  logger.info("requestId ="+requestId+": userName ="+userName+": txnDate ="+txnDate+": accountNo ="+accountNo+": formatType ="+formatType+": corporateId ="+corporateId);
	            	  //Object[] insertParams={requestId,userName,fromDate,toDate,formatType,corporateId};
	            	  Object[] insertParams={requestId,userName,txnType,txnDate,accountNo,formatType,corporateId};
	            	  getJdbcTemplate().update(INSERT_MIS_EXCEL_REPORT_DETAILS_UPLOAD,insertParams);	
	            	 
	              logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {txnDate,accountNo});
	          }
	    	 return requestId;
	    	 
	    }
		    
		    public List getMISDownloadByExcelTransactionFiles(String userName,String requestId) throws DAOException{
		        logger.info("getMISDownloadByExcelTransactionFiles(String username) method begins");
		        logger.info("username :"+userName+"requestId :"+requestId);
		        
		        List txnfilelist=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName,requestId};
		            	txnfilelist = (List)getJdbcTemplate().query(MIS_DOWNLOAD_EXCEL_TXN_FILES,params, new getTxnListListExtractor());
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("getMISDownloadByExcelTransactionFiles(String username) method ends");
		        return txnfilelist;
		}  
		    
		    //Added for ddebit download file start
		    public String generateRequestIdForDDebitFile(String fromDate, String toDate,String filename,
	    			String userName) throws DAOException {
		    	 logger.info("generateRequestIdForDDebitFile(String fromDate, String toDate,String filename,String userName,String Type) method begins");
		    	  String requestId=null;
		    	  if(fromDate == null || filename==null || userName == null)            
		          {
		              DAOException.throwException("F001");
		          }
		    	
		          try{
		            	  Date d = new Date();
		            	  String dateString=String.valueOf(d.getTime());
		            	  if(field>9999)
		            		  field=1;
		            	  else field+=1;
		            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
		            	  logger.info("requestId  :"+dateString+padChar);
		            	  requestId=dateString+padChar;
		            	  requestId=requestId.substring(3, 17);
		            	  requestId = requestId.substring(2);
		            	  String rid="DDR";
		            	  requestId = rid.concat(requestId);
		            	  logger.info("final requestId :"+requestId);
		            	  logger.info("final fromDate :"+fromDate);
		            	  logger.info("final toDate :"+toDate); 
		            	  logger.info("final userName :"+userName);	            	  
		            	  logger.info("final filename :"+filename);
		            	  
		            	  Object[] insertParams={requestId,userName,fromDate,toDate,filename};
		            	  getJdbcTemplate().update(INSERT_REQUEST_DOWNLOAD_DDEBIT_FILE,insertParams);	
		            	 
		              logger.info("Insert into sbi_lpr_input ");
		              
		          }catch (DataAccessException exception) {
		              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
		          }
		    	 return requestId;
	    	 
	 }
		    
		    public List viewDDebitFileRequestStatus(String userName) throws DAOException{
		        logger.info("viewDownloadFileRequestStatus(String username) method begins");
		        logger.info("username::::"+userName);
		        List echequeList=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName};
		                echequeList = (List)getJdbcTemplate().query(VIEW_DOWNLOAD_DDEBIT_FILE,params, new ViewDownloadFileExtractor());
		            
		                logger.info("echequeList ::::"+echequeList);
		                
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("fileBasedEcheques(String fromDate,String toDate,String username) method ends");
		        return echequeList;
		}
		    private class ViewDownloadFileExtractor implements ResultSetExtractor{
		    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		    		List dataList = new ArrayList();

		    		while(rs.next()){
			    		Map result=new HashMap();
		    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
		    			SimpleDateFormat sdf=new SimpleDateFormat();
		    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
		    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));    		
		    			result.put("STATUS",rs.getString("STATUS"));		    			
		    			result.put("PARAM1",rs.getString("PARAM1"));		    			
		    			result.put("PARAM2",rs.getString("PARAM2"));
		    			dataList.add(result);
		    		}
		    		return dataList;
		    	}
		    }
		    
		    public List getDDebitFiles(String userName,String requestId) throws DAOException{
		        logger.info("getDDebitFiles(String username) method begins");
		        logger.info("username::::***"+userName);
		        logger.info("requestId::::"+requestId);
		        List ddebitfilelist=null;
		        if( userName != null ){
		            Object[] params;
		            try{
		            	params = new Object[] {userName,requestId};
		            	ddebitfilelist = (List)getJdbcTemplate().query(DISPLAY_DDEBIT_FILES,params, new getDdebitListExtractor());
		            }catch (DataAccessException exception) {
		                DAOException.throwException("CUS006",new Object[] {userName});
		            }
		        }else {
		            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
		            logger.info("Null Input");// Exception to be added
		        }
		        logger.info("getDDebitFiles(String username) method ends");
		        return ddebitfilelist;
		}
		    private class getDdebitListExtractor implements ResultSetExtractor{
		    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		    		List dataList = new ArrayList();

		    		while(rs.next()){
			    		Map result=new HashMap();
		    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
		    			SimpleDateFormat sdf=new SimpleDateFormat();
		    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
		    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
		    			result.put("PARAM6",rs.getString("PARAM6"));
		    			dataList.add(result);
		    		}
		    		return dataList;
		    	}
		    }
		    
		    //Added for ddebit download file end
		
		
		  //Added by devaraj for IMPS starts
		    public String generateRequestIdForIMPStxnDownloadFile(String fromDate, String toDate,String filename,
	    			String userName,String corpId) throws DAOException {
	    	 logger.info("generateRequestIdForDownloadFile(String fromDate,String toDate,String username,String userRole) method begins");
	    	  String requestId=null;
	    	  if(fromDate == null || filename==null || userName == null)            
	          {
	              DAOException.throwException("F001");
	          }
	          try{
	            	  Date d = new Date();
	            	  String dateString=String.valueOf(d.getTime());
	            	  if(field>9999)
	            		  field=1;
	            	  else field+=1;
	            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
	            	  logger.info("requestId .."+dateString+padChar);
	            	  requestId=dateString+padChar;
	            	  requestId=requestId.substring(3, 17);
	            	  requestId = requestId.substring(2);
	            	  String rid="DF";
	            	  requestId = rid.concat(requestId);
	            	  logger.info("final requestId .."+requestId);
	            	  logger.info("final fromDate .."+fromDate);
	            	  logger.info("final toDate .."+toDate);
	            	  logger.info("final userName .."+userName);
	            	  logger.info("final corpId .."+corpId);
	            	  logger.info("final filename .."+filename);
	            	  
	            	  Object[] insertParams={requestId,userName,fromDate,toDate,corpId,filename};
	            	  getJdbcTemplate().update(INSERT_REQUEST_IMPSTRANSACTION_DOWNLOAD_FILE,insertParams);	
	            	  
	            	  logger.info("Insert into sbi_lpr_input ");
	              
	          }catch (DataAccessException exception) {
	              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
	          }
		     logger.info("generateRequestIdForDownloadFile(String fromDate,String toDate,String username,String userRole) method ends");
	    	 return requestId;
	    	 
	    }
		    
		    
	    public String generateRequestIdForIMPSbeneficiaryDownloadFile(String fromDate, String toDate,String filename,
    			String userName,String corpId, String fileType) throws DAOException {
    	 logger.info("generateRequestIdForIMPSbeneficiaryDownloadFile(String fromDate,String toDate,String username,String userRole) method begins");
    	  String requestId=null;
    	  if(fromDate == null || filename==null || userName == null)            
          {
              DAOException.throwException("F001");
          }
          try{
            	  Date d = new Date();
            	  String dateString=String.valueOf(d.getTime());
            	  if(field>9999)
            		  field=1;
            	  else field+=1;
            	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
            	  logger.info("requestId .."+dateString+padChar);
            	  requestId=dateString+padChar;
            	  requestId=requestId.substring(3, 17);
            	  requestId = requestId.substring(2);
            	  String rid="DF";
            	  
            	  if (fileType.equalsIgnoreCase("IMPSTP")) {
  					rid = "TP";
              	  } else if (fileType.equalsIgnoreCase("IMPSDTP")) {
  					rid = "DTP";
              	  } else if (fileType.equalsIgnoreCase("IMPSP2ATP")) {
    				rid = "P2ATP";
              	  } 		   		  
            	  
            	  requestId = rid.concat(requestId);
            	  logger.info("final requestId .."+requestId);
            	  logger.info("final fromDate .."+fromDate);
            	  logger.info("final toDate .."+toDate);
            	  logger.info("final userName .."+userName);
            	  logger.info("final corpId .."+corpId);
            	  logger.info("final filename .."+filename);
            	  logger.info("final fileType .."+fileType);
            	  
            	  Object[] insertParams={requestId,userName,fromDate,toDate,corpId,filename,fileType};
            	  getJdbcTemplate().update(INSERT_REQUEST_IMPSBENEFICIARY_DOWNLOAD_FILE,insertParams);	
            	  
            	  logger.info("Insert into sbi_lpr_input ");
              
          } catch (DataAccessException exception) {
              DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
          }
	      logger.info("generateRequestIdForIMPSbeneficiaryDownloadFile(String fromDate,String toDate,String username,String userRole) method ends");
    	 return requestId;
    	 
	  }
	    
	   public List viewIMPStxnDownloadFileRequestStatus(String userName) throws DAOException{
	        logger.info("viewIMPStxnDownloadFileRequestStatus(String username) method begins");
	        logger.info("username::::"+userName);
	        List echequeList=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName};
	                echequeList = (List)getJdbcTemplate().query(VIEW_IMPS_TXN_DOWNLOADFILE_DETAILS,params, new ViewStatusListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("viewIMPStxnDownloadFileRequestStatus(String username) method ends");
	        return echequeList;
	   }
	   
	   public List viewIMPSbenDownloadFileRequestStatus(String userName) throws DAOException{
	        logger.info("viewIMPSbenDownloadFileRequestStatus(String username) method begins");
	        logger.info("username::::"+userName);
	        List echequeList=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName};
	                echequeList = (List)getJdbcTemplate().query(VIEW_IMPS_BEN_DOWNLOADFILE_DETAILS,params, new ViewStatusListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("viewIMPSbenDownloadFileRequestStatus(String username) method ends");
	        return echequeList;
	   }

	   public List getIMPSTransactionFiles(String userName,String requestId) throws DAOException{
	        logger.info("getTransactionFiles(String username) method begins");
	        logger.info("username::::***"+userName);
	        logger.info("requestId::::"+requestId);
	        List txnfilelist=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName,requestId};
	            	txnfilelist = (List)getJdbcTemplate().query(DISPLAY_IMPS_TXN_VAL_CRA_FILES,params, new getTxnListListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        } else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("getTransactionFiles(String username) method ends");
	        return txnfilelist;
	   }
	    
	   public List getIMPSBeneficiaryFiles(String userName,String requestId) throws DAOException{
	        logger.info("getIMPSBeneficiaryFiles(String username) method begins");
	        logger.info("username::::***"+userName);
	        logger.info("requestId::::"+requestId);
	        List benfilelist=null;
	        if( userName != null ){
	            Object[] params;
	            try{
	            	params = new Object[] {userName,requestId};
	            	benfilelist = (List)getJdbcTemplate().query(DISPLAY_IMPS_BEN_VAL_CRA_FILES,params, new getBenListExtractor());
	            }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        } else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("getIMPSBeneficiaryFiles(String username) method ends");
	        return benfilelist;
	   }
	   //Added by devaraj for IMPS ends	    
	    
		
	  //Added for Generate Comp Txn Report - Start 
	   public String generateRequestIdForCompTxnFile(String fromDate, String toDate,String filename,
   			String userName,String corpId,String fileType) throws DAOException {
   	 logger.info("generateRequestIdForCompTxnFile(String fromDate,String toDate,String username,String userRole) method begins");
   	  String requestId=null;
   	  if(fromDate == null || filename==null || userName == null)            
         {
             DAOException.throwException("F001");
         }
   	
         try{
           	  Date d = new Date();
           	  String dateString=String.valueOf(d.getTime());
           	  if(field>9999)
           		  field=1;
           	  else field+=1;
           	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
           	  logger.info("requestId .."+dateString+padChar);
           	  requestId=dateString+padChar;
           	  requestId=requestId.substring(3, 17);
           	  logger.info("requestId.substring(3, 17);;;;"+requestId);
           	  requestId = requestId.substring(2);
           	  logger.info("requestId.substring(2);;;;"+requestId);
           	  String rid="DF";
           	  requestId = rid.concat(requestId);
           	  logger.info("final requestId .."+requestId);
           	  logger.info("final fromDate .."+fromDate);
           	  logger.info("final toDate .."+toDate);
           	  logger.info("final userName .."+userName);
           	  logger.info("final corpId .."+corpId);
           	  logger.info("final filename .."+filename);
           	  
           	  Object[] insertParams={requestId,userName,fromDate,toDate,corpId,filename};
           	  getJdbcTemplate().update(INSERT_REQUEST_DOWNLOAD_COMP_TXN_FILE,insertParams);	
           	  
             logger.info("Insert into sbi_lpr_input ");
             
         }catch (DataAccessException exception) {
             DAOException.throwException("CUS006",new Object[] {fromDate,toDate});
         }
   	 return requestId;
   	 
   }
	   
	   
	   //Added for Generate Comp Txn Report - End
	   
	   public String reqFailureTxn(Map inputParams) throws DAOException {
		   logger.info("reqFailureTxn(Map inputParams) method begins");
		   
		   String requestId=null;
		   String startDate=(String)inputParams.get("startDate");
		   String endDate=(String)inputParams.get("endDate");
		   String userName=(String)inputParams.get("userName");
		   String corporateId=(String)inputParams.get("corporateId");
		   
		   if(startDate == null || endDate==null || userName == null || corporateId == null)            
		   {
			   DAOException.throwException("F001");
		   }
   	
		   try {
           	  Date d = new Date();
           	  String dateString=String.valueOf(d.getTime());
           	  
           	  if(field>9999)
           		  field=1;
           	  else 
           		  field+=1;
           	  
           	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
           	  logger.info("requestId .."+dateString+padChar);
           	  requestId=dateString+padChar;
           	  requestId=requestId.substring(3, 17);
           	  
           	  Object[] insertParams={requestId,userName,startDate,endDate,corporateId};
           	  int count=getJdbcTemplate().update(LPR_INPUT_FAILURE_TXN,insertParams);	
           	  
           	  if(count==0)
           		requestId=null;
           	  logger.info("No of rows inserted into sbi_lpr_input:"+count);
             
	         } catch (DataAccessException exception) {
	             DAOException.throwException("F001",new Object[] {startDate,endDate});
	         }
		   
		     logger.info("reqFailureTxn(Map inputParams) method ends");
		     return requestId;
		   	 
	   }
	   public List downloadFailureTxnRequestStatus(String userName) throws DAOException{
		   logger.info("downloadFailureTxnRequestStatus(String username) method begins");
		   logger.info("username::::"+userName);
		   List echequeList=null;
		   if(userName != null){
			   
			   try{
				   Object[] params = new Object[] {userName};
				   String sql="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,PARAM3,PARAM4,PARAM5,request_type  from bvsbi.sbi_lpr_input where user_name=? and request_type in ('corp_failtxn_report') and  trunc(creation_time)>=trunc(sysdate-30) order by CREATION_TIME desc";
				   echequeList = (List)getJdbcTemplate().query(sql,params, new DownloadStatusListExtractor());
			   }catch (DataAccessException exception) {
	                DAOException.throwException("F001",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("F001",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
		   	logger.info("downloadFailureTxnRequestStatus(String username) method ends");
		   	return echequeList;
	   }
	   private class DownloadStatusListExtractor implements ResultSetExtractor{
	    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
	    		List dataList = new ArrayList();

	    		while(rs.next()){
		    		Map result=new HashMap();
	    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
	    			SimpleDateFormat sdf=new SimpleDateFormat();
	    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
	    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
	    			result.put("STATUS",rs.getString("STATUS"));
	    			result.put("PARAM1",rs.getString("PARAM1"));
	    			result.put("PARAM2",rs.getString("PARAM2"));
	    			result.put("PARAM3",rs.getString("PARAM3"));
	    			result.put("PARAM4",rs.getString("PARAM4"));
	    			result.put("filename",rs.getString("PARAM5"));
	    			dataList.add(result);
	    		}
	    		return dataList;
	    	}
	    }
}
	    



