//CR-1884 SN27223
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.model.CoreOffLineMessage;
import com.sbi.common.model.TickerMessageDisplayModel;

public class CoreOffLineMessageDAOImpl extends JdbcDaoSupport implements CoreOffLineMessageDAO{

	protected final Logger logger = Logger.getLogger(getClass());
	public List getCoreOffLineMessage(String bankCode, String role){
		
		logger.info("getCoreOffLineMessage(String bankCode, String role) begin");
		String query = "select * from sbi_site_message where lower(role) = lower(?) and "+
					   "sysdate >= nvl(display_from,sysdate) and sysdate <= nvl(display_to,sysdate) and bank_code = ? and lower(status) = 'y'";
			
		List coreOffLineMsgList=null;  
	    Object[] params={role,bankCode};   		
   		coreOffLineMsgList = getJdbcTemplate().query(query, params,new CoreOffLineMessageRowMapper());   
   		if (coreOffLineMsgList != null  && coreOffLineMsgList.size() > 0){
   			logger.info("getCoreOffLineMessage(String bankCode, String role) end");
   			return coreOffLineMsgList;	
   		}
   		logger.info("getCoreOffLineMessage(String bankCode, String role) end");
   		return null;	
    
    	
    }
    	
	class CoreOffLineMessageRowMapper implements RowMapper {

		public Object mapRow(ResultSet rs, int index) throws SQLException {
			CoreOffLineMessage colmsg = new CoreOffLineMessage();
			colmsg.setRole(rs.getString("ROLE")); 
			if(rs.getString("MESSAGE") != null){
				colmsg.setMessage(rs.getString("MESSAGE").trim());
			}else{
				colmsg.setMessage("");
			}
			
			colmsg.setDisplayFrom(rs.getTimestamp("DISPLAY_FROM")); 
			colmsg.setDisplayTo(rs.getTimestamp("DISPLAY_TO")); 
			colmsg.setMessageNature(rs.getString("MESSAGE_NATURE")); 
			colmsg.setBankCode(rs.getString("BANK_CODE"));	
			colmsg.setStatus(rs.getString("STATUS"));
			return colmsg;
		}
	}

		public List getTickerMessage(Map inputParams){
			
			logger.info("getTickerMessage(Map inputParams) begin");
			logger.info("inputParams::::"+inputParams);
			Integer userRole = (Integer)inputParams.get("userRole");
			Integer userType = (Integer)inputParams.get("userType");
			String bankCode = (String)inputParams.get("bankCode");
			String role_type =userRole+"_"+userType;
			logger.info("role_type::::"+role_type);
			String query = "select * from state_bank_ticker_msg_display where role_type=? and "+
						   "sysdate >= nvl(START_DATE,sysdate) and sysdate <= nvl(END_DATE,sysdate) and bank_code in (?,'All') and status = 1";
			
				
			List tickerMessageList=null;  
		    Object[] params={role_type,bankCode};   		
		    tickerMessageList = getJdbcTemplate().query(query, params,new TickerMessageRowMapper());   
	   		if (tickerMessageList != null  && tickerMessageList.size() > 0){
	   			logger.info("getTickerMessage(String bankCode, String role) end");
	   			logger.info("tickerMessageList:::::"+tickerMessageList);
	   			return tickerMessageList;	
	   		}
	   		logger.info("getTickerMessage(Map inputParams) end");
	   		return null;	
	    
	    	
	    }
		class TickerMessageRowMapper implements RowMapper {

			public Object mapRow(ResultSet rs, int index) throws SQLException {
				TickerMessageDisplayModel ticker = new TickerMessageDisplayModel();
				ticker.setRoleType(rs.getString("ROLE_TYPE")); 
				if(rs.getString("MESSAGE") != null){
					ticker.setMessage(rs.getString("MESSAGE").trim());
				}else{
					ticker.setMessage("");
				}
				
				ticker.setStartTime(rs.getTimestamp("START_DATE")); 
				ticker.setEndTime(rs.getTimestamp("END_DATE")); 
				ticker.setFontColor(rs.getString("FONT_COLOR")); 
				ticker.setBankCode(rs.getString("BANK_CODE"));	
				ticker.setStatus(rs.getString("STATUS"));
				ticker.setApplication(rs.getString("APPLICATION"));
				return ticker;
			}
		}
} 
