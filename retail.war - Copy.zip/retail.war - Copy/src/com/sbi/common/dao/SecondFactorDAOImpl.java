package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class SecondFactorDAOImpl extends JdbcDaoSupport  implements SecondFactorDAO {
	protected final Logger logger = Logger.getLogger(getClass());
	public String isAuthenticationEnabled(String userName) {
		// TODO Auto-generated method stub
		logger.info("isAuthenticationEnabled method - begin");
		try{
		
		boolean sg=false;
		boolean ro=false;
		Object[] parameters = new Object[] {userName};
		String count="0";
		Map mapAuthCode=null;
		List lstAtuhCode=getJdbcTemplate().queryForList("select auth_code from bv_user a, bv_user_profile b, SBI_SECOND_AUTHENTICATION_DTLS c where a.user_id=b.user_id and a.user_alias=? and b.news_preference5 is not null and trim(b.news_preference5)=trim(c.serial_no)",parameters);
		logger.info("lstAtuhCode::"+lstAtuhCode);
		if(lstAtuhCode!=null && lstAtuhCode.size()>0){
			for(int i=0; i<lstAtuhCode.size();i++){
				mapAuthCode=(Map) lstAtuhCode.get(i);
				if(mapAuthCode.get("auth_code").toString().equalsIgnoreCase("SG"))
				{
					sg=true;
				}
				if(mapAuthCode.get("auth_code").toString().equalsIgnoreCase("RO"))
				{
					ro=true;
				}
			} // end of loop
			
			if(sg && ro){
				count="3";
			}
			if(sg && !ro)
				count="2"; // merchant may use e-signature only for transaction 
			if(!sg && ro){
				count="1";
			}
		}
		logger.info("isAuthenticationEnabled method - End");
			return count;
			
			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "0";
		}
	
		
	}

	public String getTokenDetails(String serialNo) {
		// TODO Auto-generated method stub
		try{	
			
			Object[] parameters = new Object[] {serialNo};
			return (String)getJdbcTemplate().queryForObject("select dp_data from sbi_second_authentication_dtls where trim(serial_no)=trim(?) ",parameters, String.class);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return null;
			}
		
	}
	public String getTokenDetails(String serialNo, String authCode) {
		// TODO Auto-generated method stub
		try{	
			if(authCode == null){
				authCode = "RO";
			}
			Object[] parameters = new Object[] {serialNo,authCode};
			return (String)getJdbcTemplate().queryForObject("select dp_data from sbi_second_authentication_dtls where trim(serial_no)=trim(?) and auth_code=? ",parameters, String.class);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return null;
			}
		
	}
	public int updateDPData(String serialNo, String tokenDetails) {
		// TODO Auto-generated method stub
		try{
			Object[] parameters = new Object[] {tokenDetails,serialNo};
			return getJdbcTemplate().update("update sbi_second_authentication_dtls set dp_data=? where trim(serial_no)=trim(?) and Auth_Code='RO'",parameters);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return 0;
			}
		//return 0;
	}
	public int updateDPData(String serialNo, String tokenDetails,String authCode) {
		logger.info("<<<<<===== startupdateDPData(String serialNo, String tokenDetails,String authCode)>>>>");
		try{
			if(authCode == null){
				authCode = "RO";				
			}
			Object[] parameters = new Object[] {tokenDetails,serialNo,authCode};
			return getJdbcTemplate().update("update sbi_second_authentication_dtls set dp_data=? where trim(serial_no)=trim(?) and Auth_Code=? ",parameters);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return 0;
			}
		//return 0;
	}
	
	//Newly Added for Software Token Implementation
	public String getSwTokenDetails(String serialNo, String authCode) {
		// TODO Auto-generated method stub
		try{	
			if(authCode == null){
				authCode = "RO";
			}
			Object[] parameters = new Object[] {serialNo,authCode};
			return (String)getJdbcTemplate().queryForObject("select dp_data from state_bank_secure_master where trim(serial_no)=trim(?) and auth_code=? ",parameters, String.class);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return null;
			}
		
	}
	//Newly Added for Software Token Implementation
	public int updateDPDataOfSwToken(String serialNo, String tokenDetails,String authCode) {
		logger.info("<<<<<===== startupdateDPData(String serialNo, String tokenDetails,String authCode)>>>>");
		try{
			if(authCode == null){
				authCode = "RO";				
			}
			logger.info("auth code::::"+authCode);
			Object[] parameters = new Object[] {tokenDetails,serialNo,authCode};
			return getJdbcTemplate().update("update state_bank_secure_master set dp_data=?,last_mod_time=sysdate where trim(serial_no)=trim(?) and Auth_Code=? ",parameters);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				return 0;
			}
		//return 0;
	}
	
	public List getDpdataOfSerialNo(String userName,String serialNo){
		logger.info("getDpdataOfSerialNo - method begins");
		List dpDataList=null;
		String sql = "select DP_DATA from state_bank_secure_user_map a, "+
					  "STATE_BANK_SECURE_MASTER b where a.serial_no = b.serial_no "+
					  "and a.user_name = ?  and b.serial_no=?";
		Object param[] = {userName,serialNo};
		
		 dpDataList = getJdbcTemplate().query(sql,param, new DpdataRowMapper());
		logger.info("DP DATA LIST::::"+dpDataList);
		logger.info("getDpdataOfSerialNo - method ends");
		return dpDataList;
	}

	class DpdataRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			
		 	return new String(rs.getString("DP_DATA"));
		 	
		}
	}
	
	
	public Map getSerialNoandDpdata(String userName,String serialNo){
		logger.info("getDpdataOfSerialNo - method begins");
		Map dpDataMap=new HashMap();
		
		String sql = "select DP_DATA,auth_code from state_bank_secure_user_map a, "+
					  "STATE_BANK_SECURE_MASTER b where a.serial_no = b.serial_no "+
					  "and a.user_name = ?  and b.serial_no=?";
		Object param[] = {userName,serialNo};
		
		List dataList = getJdbcTemplate().queryForList(sql,param);
		logger.info("dataList:::::"+dataList);
		if(dataList!=null && dataList.size()>0){
			for(int i=0;i<dataList.size();i++){
				Map	dataMap = (Map)dataList.get(i);
				dpDataMap.put(dataMap.get("AUTH_CODE"), dataMap.get("DP_DATA"));
				
			}
			logger.info("dpDataMap:::::"+dpDataMap);  
		}	
		
		logger.info("getDpdataOfSerialNo - method ends");
		return dpDataMap;
	}
	
	public int checkULBlobCount(String serialNo){
		int checkULBlobCount=0;
		logger.info("serial number :::::"+checkULBlobCount);
		String sql ="select count(1) from state_bank_secure_master where serial_no=? and auth_code='UL'";
		Object param[] = {serialNo}; 
		checkULBlobCount = getJdbcTemplate().queryForInt(sql, param);
		logger.info("UL blob existence count:::::"+checkULBlobCount);
		return checkULBlobCount;
	}
	
}
