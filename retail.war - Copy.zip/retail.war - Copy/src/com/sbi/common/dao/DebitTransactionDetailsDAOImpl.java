package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.CorpTransactionLeg;
import com.sbi.common.utils.UtilsConstant;



public class DebitTransactionDetailsDAOImpl extends JdbcDaoSupport implements DebitTransactionDetailsDAO{
	
	protected final Logger logger = Logger.getLogger(getClass());
	
	
	private ResourceBundleMessageSource corpTransactionProperties;
	
	 public void setCorpTransactionProperties(
			ResourceBundleMessageSource corpTransactionProperties) {
		this.corpTransactionProperties = corpTransactionProperties;
	}

	private static final String GET_ECHEQUE_FOR_BY_ACCOUNT= "Select a.*,g.utr_no,'' product_type , b.RESPONSE_STATUS,c.description cancel_description, (select count(f.debit_reference_no) from sbi_ib_credits_view f where f.debit_reference_no = a.echeque_no and f.credit_status= '00') credits_success, "+
	 															"(select nvl(SUM (commission_amount),0) commission_amount from sbi_ib_credits_view f  where f.debit_reference_no = a.echeque_no ) commission_amount from SBICORP_ECHEQUE_MASTER_view a, sbicorp_bu_txn_status b, sbicorp_cancel_history c,"+
	 														"sbi_ib_credits_view g where  a.echeque_no=g.debit_reference_no AND  a.status=1 and a.echeque_no= ? and substr(a.echeque_no,0,2) != 'CB' and a.Echeque_no=b.REFERENCE_NO(+) and a.echeque_no = c.echeque_no(+)";
 
	
	public CorpTransactionLeg getEcheque(String echequeNo) {

		logger.info("CorpTransactionLeg getEcheque(String echequeNo) method begin");
		CorpTransactionLeg debitleg = new CorpTransactionLeg();
		if (echequeNo != null) {
			try {
				debitleg = findEcheque(echequeNo);
				if (debitleg != null) {
					debitleg = setEchequePropeties(debitleg);
				}
			 }catch (DAOException daoException) {
				SBIApplicationException.throwException(daoException
						.getErrorCode(), daoException);
			}
		}
		logger.info("CorpTransactionLeg getEcheque(String echequeNo) method ends");
		return debitleg;
	}
	
	
	private	CorpTransactionLeg findEcheque(String echequeNumber)
	{
		logger.info("findEcheque(String echequeNumber) method begins");
		CorpTransactionLeg corpTransactionLeg = new CorpTransactionLeg();
		if(echequeNumber != null )
		{
			Object[] parameters = {echequeNumber};
			try{
				List echequeList = getJdbcTemplate().query(GET_ECHEQUE_FOR_BY_ACCOUNT, parameters ,new DebitTransactionDetailsRowMapper());
				if ( echequeList != null && echequeList.size() > 0 )
				{
					corpTransactionLeg = (CorpTransactionLeg)echequeList.get(0);
				}else{
					DAOException.throwException("DTD002",new Object[]{echequeList});
				}
			} catch (DataAccessException ex) {
	            ex.printStackTrace();
				 DAOException.throwException("CIRS040",new Object [] {});
			}
		}else{
			 DAOException.throwException("DTD001",new Object [] {});
		}
		logger.info("findEcheque( String echequeNumber) method ends");
		return corpTransactionLeg;
	}
	
	private CorpTransactionLeg setEchequePropeties(CorpTransactionLeg corpTransactionLeg) {

		int curAuthLevel = Integer.parseInt(corpTransactionLeg
				.getCurrentAuthLevel());

		Date currentDate;
		currentDate = new Date(System.currentTimeMillis());

		String debitstatusmessage = "";

		if (curAuthLevel == 50
				&& (Integer.parseInt(corpTransactionLeg.getScheduled()) == 0)
				&& (Integer.parseInt(corpTransactionLeg.getProcessed()) == 1)) {

			debitstatusmessage = getCorpTransactionStatus("debitStatus"
					+ curAuthLevel);

		} else if ((curAuthLevel != 50) && (curAuthLevel > 0)
				&& (Integer.parseInt(corpTransactionLeg.getScheduled()) == 0)
				&& (Integer.parseInt(corpTransactionLeg.getProcessed()) == 1)
				) {
			debitstatusmessage = getCorpTransactionStatus("debitStatusSPA");
		} else if ((curAuthLevel != 50) && (curAuthLevel > 0)) {

			debitstatusmessage = getCorpTransactionStatus("debitStatus"
					+ curAuthLevel);

		} else if (curAuthLevel == -1 || curAuthLevel == -2
				|| curAuthLevel == -3 || curAuthLevel == -5
				|| curAuthLevel == -6 || curAuthLevel == -9) { 
			debitstatusmessage = getCorpTransactionStatus("debitStatus"
					+ curAuthLevel);
		}

		// current auth level check end.
		// checking with status code.
		else {

			String debitStatus = corpTransactionLeg.getDebitStatus();
			logger.info("getting status code " + debitStatus);
			String codesString = "00|F1|08|57|REP.";
			if (debitStatus != null
					&& (!debitStatus.trim().equalsIgnoreCase("")))
			{
				if (codesString.indexOf(debitStatus) >= 0) {
					debitstatusmessage = getCorpTransactionStatus("statusCode"
							+ debitStatus);
				} else {
					//if statcode != 00|F1|08|57.
					debitstatusmessage = getCorpTransactionStatus("statusCodeElse");
				}
				if (debitstatusmessage.equalsIgnoreCase("pending")) {
					debitstatusmessage = getCorpTransactionStatus("debitStatusAPD");
				}
			}

		}// end of else

		if (debitstatusmessage.equalsIgnoreCase("unknown"))
			debitstatusmessage = getCorpTransactionStatus("debitStatusUnknown");

		corpTransactionLeg.setStatus(debitstatusmessage);

		if (corpTransactionLeg.getStatus().equalsIgnoreCase("failure"))
			corpTransactionLeg.setCreditStatusCode("Rejected");

		String transactiontypemessage = null;
		transactiontypemessage = getCorpTransactionStatus("transactionType"
				+ corpTransactionLeg.getEchequeNo().charAt(1));

		// for RTGS
		if(corpTransactionLeg.getMerchantCode()!= null && corpTransactionLeg.getMerchantCode().equalsIgnoreCase(UtilsConstant.RTGS)) {
			transactiontypemessage = getCorpTransactionStatus("transactionTypeRTGS");
		} else if(corpTransactionLeg.getMerchantCode()!= null && corpTransactionLeg.getMerchantCode().equalsIgnoreCase(UtilsConstant.NEFT)) {
			transactiontypemessage = getCorpTransactionStatus("transactionTypeNEFT");
 			//Added for GRPT
		}else if(corpTransactionLeg.getMerchantCode()!= null && corpTransactionLeg.getMerchantCode().equalsIgnoreCase(UtilsConstant.GRPT)) {
			transactiontypemessage = getCorpTransactionStatus("transactionTypeGRPT");
		}
		if (transactiontypemessage.equalsIgnoreCase("unknown"))
			transactiontypemessage = getCorpTransactionStatus("transactionTypeFT");
		corpTransactionLeg.setTransactionType(transactiontypemessage);

		String auth1Name = getAuthorizerName(corpTransactionLeg
				.getAuth1Name());
		corpTransactionLeg.setAuth1Name(auth1Name);
		if (curAuthLevel == -1) {
			corpTransactionLeg.setAuth1Name("CANCELLED");
		}
		String auth2Name = getAuthorizerName(corpTransactionLeg
				.getAuth2Name());
		corpTransactionLeg.setAuth2Name(auth2Name);

		String makerName = getAuthorizerName(corpTransactionLeg
				.getMaker());
		corpTransactionLeg.setMaker(makerName);
		
		// CR- Approver Name Should be Name
		String approverName = getAuthorizerName(corpTransactionLeg
				.getApprover());
		corpTransactionLeg.setApprover(approverName);
		
		if (corpTransactionLeg.getEchequeNo() != null) {
			corpTransactionLeg.setType(corpTransactionLeg.getEchequeNo()
					.substring(0, 2));
		}

		return corpTransactionLeg;
	}
	
	 class DebitTransactionDetailsRowMapper implements RowMapper {

		 public Object mapRow(ResultSet rs, int index) throws SQLException {
			 
	        	CorpTransactionLeg corpTransactionLeg = new CorpTransactionLeg();
	        	
	        	corpTransactionLeg.setEchequeNo(rs.getString("echeque_no"));
	        	corpTransactionLeg.setAccountNo(rs.getString("account_no"));
	        	corpTransactionLeg.setBranchCode(rs.getString("branch_code"));
	        	corpTransactionLeg.setMerchantCode(rs.getString("merchant_code"));
	        	corpTransactionLeg.setReferenceNo(rs.getString("reference_no"));
	        	corpTransactionLeg.setAmount(new Double(rs.getDouble("echeque_amount")));
	        	corpTransactionLeg.setScheduledDate(rs.getTimestamp("scheduled_date"));
	            corpTransactionLeg.setDescription(rs.getString("description"));
	            corpTransactionLeg.setMaker(rs.getString("maker"));
	            corpTransactionLeg.setMakerUserName(rs.getString("maker"));
	            corpTransactionLeg.setBeneficiary(rs.getString("beneficiary"));
	            corpTransactionLeg.setApprover(rs.getString("approver"));
	            corpTransactionLeg.setAuthType(rs.getString("auth_type"));
	            corpTransactionLeg.setCurrentAuthLevel(rs.getString("current_auth_level"));
	            corpTransactionLeg.setAuth1Name(rs.getString("auth1_name"));
	            corpTransactionLeg.setAuth1UserName(rs.getString("auth1_name"));
	            corpTransactionLeg.setAuth2Name(rs.getString("auth2_name"));
	            corpTransactionLeg.setAuth2UserName(rs.getString("auth2_name"));
	            corpTransactionLeg.setScheduled(rs.getString("scheduled"));
	            corpTransactionLeg.setProcessed(rs.getString("processed"));
	            corpTransactionLeg.setBusinessLineId(rs.getString("businessline_id"));
	            corpTransactionLeg.setCorpRefNo(rs.getString("corp_ref_no"));
	            corpTransactionLeg.setDebitStatus(rs.getString("debit_status"));
	            corpTransactionLeg.setTxnCount(rs.getInt("CREDITS_COUNT"));
	            corpTransactionLeg.setOid(rs.getDouble("oid"));
	            corpTransactionLeg.setBankTType(rs.getString("bank_ttype"));
	            corpTransactionLeg.setProductType(rs.getString("product_type"));
	            corpTransactionLeg.setLastModTime(rs.getTimestamp("last_mod_time"));
	            
                if (corpTransactionLeg.getMerchantCode()!=null && corpTransactionLeg.getMerchantCode().equalsIgnoreCase("OLTAS"))
                {
                if (rs.getTimestamp("reco_generated_time") != null)
                     corpTransactionLeg.setLastModTime(rs.getTimestamp("reco_generated_time"));
                }
                
                corpTransactionLeg.setResponseStatus(rs.getString("response_status"));
	            corpTransactionLeg.setCreditStatusCode(rs.getString("credit_status_code"));
	            corpTransactionLeg.setRemarks(rs.getString("description"));
	            corpTransactionLeg.setThirdPartyRef(rs.getString("corp_ref_no"));
	            corpTransactionLeg.setSupplierId(rs.getString("supplier_id"));
	            corpTransactionLeg.setEchequeDate(rs.getTimestamp("echeque_date"));
	            corpTransactionLeg.setFileName(rs.getString("file_name")); // 
                corpTransactionLeg.setStatusDescription(rs.getString("status_description"));
                corpTransactionLeg.setRateOfInterest(rs.getString("rate_of_interest"));
             
                return corpTransactionLeg;
	        }
	 }

		public String getCorpTransactionStatus(String key) {
			String transactionValue = DAOConstants.TXN_STATUS_UNKNOWN;
			try {
				transactionValue = corpTransactionProperties.getMessage(key, null,
						null);
			} catch (NoSuchMessageException ex) {
				// logger.error("Exception occured" ,ex );
			}
			return transactionValue;
		}
		public String getAuthorizerName(String authName) throws DAOException {
			//logger.info("getAuthorizerName(String authName) - begin");
			String query="select name from bv_user a, bv_user_profile b where a.user_id = b.user_id and a.user_alias = ?";
			String authorizerName="";
			String authquery = "select name from corp_bv_user_arch a, corp_bv_user_profile_arch b where a.user_id = b.user_id and  a.user_alias = ?";
			if(authName!=null && authName.length()>0){
				try{
				Object[] params={authName};
				List authList=getJdbcTemplate().queryForList(query,params);
				if(authList!=null && authList.size()>0){
					Map authMap=(Map)authList.get(0);
					if(authMap!=null && authMap.size()>0 && authMap.get("NAME")!=null)
						authorizerName=authMap.get("NAME").toString();
				}else{
					List archauthList = getJdbcTemplate().queryForList(authquery,params);
					if(archauthList != null && archauthList.size() > 0){
						Map archauthMap = (Map) archauthList.get(0);
						if(archauthMap != null && archauthMap.size()>0 && archauthMap.get("NAME")!=null)
							authorizerName = archauthMap.get("NAME").toString();
					}
				}
				}catch(DataAccessException dataAccessException){
					logger.info("Authorizer name not found");
				}
			}
			logger.info("getAuthorizerName(String authName) - end");
			return authorizerName;
		}
}
