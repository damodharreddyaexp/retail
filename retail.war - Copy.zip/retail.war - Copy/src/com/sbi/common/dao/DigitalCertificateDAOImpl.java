/*
 * DigitalCertificateDAOImpl.java
 * Created on March 29, 2013
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.model.CertificateDetails;
import com.sbi.common.model.DSCDetails;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.DAOConstants;


public class DigitalCertificateDAOImpl extends JdbcDaoSupport implements DigitalCertificateDAO
{

    private Logger logger = Logger.getLogger(getClass());
    
    public static final String UPDATE_REGISTRATION_DETAILS = "update bv_user_profile set SF_AUTH_PROVIDER = ?,last_mod_time=sysdate where user_id = (select user_id from bv_user where user_alias = ?)";

    private static final String INSERT_DSC_REG_DETAILS="insert into SBICORP_DSC_REG_DETAILS(REFERENCE_NO,USER_NAME,BRANCH_CODE,DSC_STATUS,BRANCH_STATUS,CREATION_TIME,CORPORATE_ID,CORPORATE_NAME,SERIAL_NO,MODULE_NAME,REQUEST_TYPE,last_mod_time) values(?,?,?,'Active','Pending',sysdate,?,?,?,?,?,sysdate)";
    
    private static final String DSC_REG_DETAILS_QUERY="select REFERENCE_NO,USER_NAME,DSC_STATUS,BRANCH_STATUS,AUTH1_NAME,AUTH2_NAME,BRANCH_CODE,BRANCH_NAME,CORPORATE_ID,CORPORATE_NAME,SERIAL_NO,REQUEST_TYPE from SBICORP_DSC_REG_DETAILS where REFERENCE_NO=?";
    
    //private static final String DSC_DEACTIVATE_DETAILS_QUERY="select * from SBICORP_DSC_REG_DETAILS where user_name=? and branch_status='Approved' and DSC_STATUS='Active'";
    
    public static final String DEACTIVATE_DSCERTIFICATE = "update SBICORP_DSC_REG_DETAILS set branch_status = 'Deactivated',request_type='deactivation',last_mod_time=sysdate where reference_no=? and user_name=?";
   
    public static final String UPDATE_DEACTIVATE_DETAILS = "update bv_user_profile set news_preference5 = '' , sf_auth_provider = 'Mobile',last_mod_time=sysdate where user_id in (select user_id from sbi_user where user_name = ? )";
    
    public static final String GET_C11_REG_LIST_DETAILS="select a.REFERENCE_NO,a.USER_NAME,a.DSC_STATUS,a.BRANCH_STATUS,a.AUTH1_NAME,a.AUTH2_NAME,a.BRANCH_CODE,a.BRANCH_NAME,a.CORPORATE_ID,a.CORPORATE_NAME,b.issuercommonname as issuer_name,c.expirydate as expiry_date,a.request_type,a.branch_status,a.serial_no from SBICORP_DSC_REG_DETAILS a,EMASTRANSACTIONCERTIFICATE b,EMAS_DS_DETAILS c where a.serial_no=b.certserialno and b.certserialno= c.certserialno and a.user_name=? and a.corporate_id=? and a.branch_status='Pending' order by a.creation_time desc";
    public static final String GET_C11_REREG_LIST_DETAILS="select a.REFERENCE_NO,a.USER_NAME,a.DSC_STATUS,a.BRANCH_STATUS,a.AUTH1_NAME,a.AUTH2_NAME,a.BRANCH_CODE,a.BRANCH_NAME,a.CORPORATE_ID,a.CORPORATE_NAME,b.issuername as issuer_name,b.expirydate as expiry_date,a.request_type,a.serial_no from SBICORP_DSC_REG_DETAILS a,EMAS_DS_DETAILS_TEMP b where a.serial_no=b.certserialno and a.user_name=? and  a.corporate_id=? and a.branch_status='Pending' order by a.creation_time desc";
     
	//public static final String UPDATE_REGISTRATION_DETAILS = "update bv_user_profile set SF_AUTH_PROVIDER = ? where user_id = (select user_id from bv_user where user_alias = ?)";
//	private static final String DSC_REG_DETAILS_QUERY="select REFERENCE_NO,USER_NAME,DSC_STATUS,BRANCH_STATUS,AUTH1_NAME,AUTH2_NAME,BRANCH_CODE,BRANCH_NAME,CORPORATE_ID,CORPORATE_NAME from SBICORP_DSC_REG_DETAILS where REFERENCE_NO=?";
	
    private static final String GET_DSC_REG_FORM_DETAILS="select a.REFERENCE_NO,a.USER_NAME,a.DSC_STATUS,a.BRANCH_STATUS,a.AUTH1_NAME,a.AUTH2_NAME,a.BRANCH_CODE,a.BRANCH_NAME,a.CORPORATE_ID,a.CORPORATE_NAME,b.issuercommonname as issuer_name,c.expirydate as expiry_date,a.request_type,a.branch_status,a.serial_no from SBICORP_DSC_REG_DETAILS a,EMASTRANSACTIONCERTIFICATE b,EMAS_DS_DETAILS c where a.serial_no=b.certserialno and b.certserialno= c.certserialno and a.reference_no=? and a.branch_status='Pending'";
    private static final String GET_DSC_REREG_FORM_DETAILS="select a.REFERENCE_NO,a.USER_NAME,a.DSC_STATUS,a.BRANCH_STATUS,a.AUTH1_NAME,a.AUTH2_NAME,a.BRANCH_CODE,a.BRANCH_NAME,a.CORPORATE_ID,a.CORPORATE_NAME,b.issuername as issuer_name,b.expirydate as expiry_date,a.request_type,a.branch_status,a.serial_no from SBICORP_DSC_REG_DETAILS a,EMAS_DS_DETAILS_TEMP b where a.serial_no=b.certserialno and a.reference_no=? and a.branch_status='Pending'";
    
    private static final String DSC_REG_HIST_DETAILS_QUERY="select * from SBICORP_DSC_REG_DETAILS where user_name=? and corporate_id=? and branch_status='Approved' and DSC_STATUS='Active'";
    
   /* private static final String DSC_DEACTIVATE_DETAILS_QUERY="select a.user_name , a.dsc_status , a.reference_no, " +
    		"a.auth1_name, a.corporate_id ,a.branch_code,a.corporate_name ,c.commonname," +
    		"c.issuercommonname as issuer_name,c.organisationunit as role_in_inb, " +
    		"d.expirydate as expiry_date, a.serial_no from SBICORP_DSC_REG_DETAILS a, EMASTRANSACTIONCERTIFICATE c," +
    		" EMAS_DS_DETAILS d where user_name=? and serial_no=? and c.certserialno=? " +
    		"and d.certserialno=? and dsc_status='Active' and branch_status='Approved'";*/
  
    private static final String DSC_DEACTIVATE_DETAILS_QUERY="select distinct a.user_name , a.dsc_status ," +
    		" a.reference_no,a.auth1_name, a.corporate_id ,a.branch_code,a.corporate_name ,b.commonname," +
    		"b.issuercommonname as issuer_name,b.organisationunit as role_in_inb,c.expirydate as expiry_date," +
    		"a.serial_no from SBICORP_DSC_REG_DETAILS a, EMASTRANSACTIONCERTIFICATE b,EMAS_DS_DETAILS c " +
    		"where user_name=? " +
    		"and serial_no=? " +
    		"AND  a.serial_no=b.certserialno " +
    		"and b.certserialno= c.certserialno " +
    		"and dsc_status='Active'" +
    		"and branch_status='Approved'";
    
    
 /*   private static final String GET_DSC_DETAILS_QUERY="select  c.commonname,c.issuercommonname as issuer_name," +
    		"c.organisationunit as role_in_inb,d.expirydate as expiry_date " +
    		"from EMASTRANSACTIONCERTIFICATE c, " +
    		"EMAS_DS_DETAILS d where " +
    		"c.certserialno=? " +
    		"and d.certserialno=?";*/

    private static final String GET_DSC_DETAILS_QUERY="select distinct  c.commonname," +
    		"c.issuercommonname as issuer_name,c.organisationunit as role_in_inb," +
    		"d.expirydate as expiry_date from EMASTRANSACTIONCERTIFICATE c,EMAS_DS_DETAILS d " +
    		"where c.certserialno= d.certserialno " +
    		"and c.certserialno=?";   	
    
    private static final String REREGISTER_DSCERTIFICATE = "update emas_ds_details set (certserialno, commonname, createddate, enabled, 	expirydate, issuername, subjectserialnumber, x500isspncplb64e, x500pricipalbase64encoded, auth_id) = (select certserialno, commonname, createddate, enabled, expirydate, issuername, subjectserialnumber, x500isspncplb64e, x500pricipalbase64encoded, 	dsroll_id from emas_ds_details_temp where dsroll_id = (select id FROM emas_customer where uniqueid=?))";
    
    private static final String GET_DSC_CERT_DTLS = "select commonname, issuername, expirydate from emas_ds_details_temp where certserialno=?"; 
    
	private static final String UPDATE_SFA_MODE_CHANGE_QUERY ="update bv_user_profile set SF_AUTH_PROVIDER = ?,last_mod_time=sysdate " +
    		"where user_id = (select user_id from bv_user where user_alias = ?)";	
    	
    
    private static final String GET_MODE_DETAILS="select SF_AUTH_PROVIDER,Mobile_no from bv_user_profile" +
    		" where user_id = (select user_id from bv_user where user_alias = ?)";
    
    private static final String IS_DSC_REG_QUERY="select count(*) "+
			  " from SBICORP_DSC_REG_DETAILS a, EMASTRANSACTIONCERTIFICATE b,EMAS_DS_DETAILS c "+
			  " where user_name=? AND  a.serial_no=b.certserialno and b.certserialno= c.certserialno and dsc_status='Active' "+
			  " and branch_status in ('Approved','delete','Deactivated','Rejected')";
    
    	public String updateRegistrationDetails(String userName,String branchCode, String serialNo,String corporateId,String corpName,String moduleName) throws DAOException {
    	logger.info("updateRegistrationDetails Method Starts ");
    	String referenceNo= null;
    	int status =0;
    	int pendingCount=0;
    	int updateCount=0;
    	 try{
   	  	  logger.info("userName ="+userName+": branchCode ="+branchCode+"serialNo :"+serialNo);
   	  	Object[] params={userName};
   	  	  String pendingDsc = "select count(*) from SBICORP_DSC_REG_DETAILS where " +
   	  	  		"user_name=? " +
   	  	  		"and branch_status='Pending' " +
   	  	  		"and request_type='registration'" +
   	  	  		" order by reference_no desc";
   	  	pendingCount =	getJdbcTemplate().queryForInt(pendingDsc,params);
   	  	 // pendingCount = (String) getJdbcTemplate().queryForObject(pendingDsc,params,String.class);		  
   	  	  logger.info("pendingCount>>>>>"+pendingCount);
   	  	  
       	  String query="select 'DSC' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual";
          referenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
          
          logger.info("refferenceNo =:::::"+referenceNo);
       	  Object[] insertParams={referenceNo,userName,branchCode,corporateId,corpName,serialNo,moduleName,"registration"};
       	  
       	  logger.info("INSERT_DSC_REG_DETAILS >>>>"+INSERT_DSC_REG_DETAILS);
       	if(pendingCount > 0){
       		Object[] params1={userName};
       		String UPDATE_PENDING_DETAILS ="update SBICORP_DSC_REG_DETAILS set branch_status='delete' where user_name=? and request_type='registration'";
       		updateCount = getJdbcTemplate().update(UPDATE_PENDING_DETAILS,params1);
       		if(updateCount != 0){
       			status = getJdbcTemplate().update(INSERT_DSC_REG_DETAILS,insertParams);
       		}
       	}else{
       		status = getJdbcTemplate().update(INSERT_DSC_REG_DETAILS,insertParams);
       	}
       	
       	if(status == 1){
       		logger.info("INSERT_DSC_REG_DETAILS Inserted... ");
       		return referenceNo;
       	}
       	 
         
       }catch (DataAccessException exception) {
       	DAOException.throwException("SE002",new Object[] {userName,referenceNo});
       }
       logger.info("updateRegistrationDetails - End ");
       return referenceNo;	
	  }    
    
    
    
 
    
    public List getc11FormDetails(String referenceNo,String dscFunction) {
		logger.info("getc11FormDetails( String referenceNo,String dscFunction )"+ LoggingConstants.METHODBEGIN);
		
		logger.info("input- referenceNo :" + referenceNo);
				
		List result = new ArrayList();
		List certDetails = new ArrayList();

		DSCDetails dscDetails = null;
		CertificateDetails cerftDetails = null;
		String userName ="";
		String serialNo="";
		List dscDetailsList = new ArrayList();
		if (referenceNo != null
				&& !referenceNo.trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
			try {
				Object[] parameters = new Object[] { referenceNo };

				result = getJdbcTemplate().query(DSC_REG_DETAILS_QUERY, parameters,new DigitalSigCerRowMapper());
				
				if (logger.isDebugEnabled()) {
					logger.debug("Result :" + result);
				}
				if (result.size() > 0) {
					dscDetails = (DSCDetails) result.get(0);
					userName = dscDetails.getUserName();
					serialNo= dscDetails.getSerialNo();
					if("reregister".equalsIgnoreCase(dscFunction)) {
						Object[] parameters1 = new Object[] {serialNo };
						certDetails =getJdbcTemplate().query(GET_DSC_CERT_DTLS,parameters1 ,new DigitalCertificateDtlsRowMapper());
					}
					else{
						Object[] parameters1 = new Object[] {serialNo };
						certDetails =getJdbcTemplate().query(GET_DSC_DETAILS_QUERY,parameters1 ,new DigitalCertificateDetailsRowMapper());
					}
					dscDetailsList.add(dscDetails);					
					logger.info("dscDetails result :"+ dscDetails);
					logger.info("certDetails result :"+ certDetails);
				} else {
					DAOException.throwException(ErrorConstants.DATA_NOT_FOUND);
				}
				
				if(certDetails.size()> 0){
					cerftDetails = (CertificateDetails) certDetails.get(0);
					dscDetailsList.add(cerftDetails);
				}

			} catch (DataAccessException exception) {
				DAOException.throwException(
						ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
			}
		} else {
			DAOException
					.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getc11FormDetails(String referenceNo,String dscFunction)"	+ LoggingConstants.METHODEND);
		
		return dscDetailsList;
	}
    
    
    
 
    
    public DSCDetails getDeactivationDetails(String userName,String serialNo,String securityOption) {
		logger.info("getDeactivationDetails( String userName )"	+ LoggingConstants.METHODBEGIN);
		
		logger.info("input- userName :" + userName+"serialNo :"+serialNo+"securityOption :"+securityOption);		
		List result = new ArrayList();
		DSCDetails dscDetails = null;

			try {
				Object[] parameters = new Object[] { userName,serialNo };

				result =getJdbcTemplate().query(DSC_DEACTIVATE_DETAILS_QUERY,parameters,new DeactivateDigiSigCerRowMapper());

				if (result.size() > 0) {

					dscDetails = (DSCDetails) result.get(0);
					logger.info("dscDetails result :"+ dscDetails);
				}
				
			} catch (DataAccessException dex) {
	            DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dex);
	        }catch(Exception ex){
	            DAOException.throwException( ErrorConstants.FATAL_ERROR1_CODE,ex );
	        }
	        
	        
	        logger.info("getDeactivationDetails( String corporateID )"+ LoggingConstants.METHODEND);
			
			return dscDetails;
		} 
		
	
    
    
    public boolean getDeactivationDSCertificate(String userName,String referenceNo) throws DAOException {
    	logger.info("getDeactivationDSCertificate Method Starts ");
    	
    	int count =0;
    	int updateCount =0;
    	String status;
    	 try{
   	  	  logger.info("userName ="+userName+": referenceNo ="+referenceNo);

       	 
       	  Object[] insertParams={referenceNo,userName};
       	  Object[] params={userName};
       	
       	  count = getJdbcTemplate().update(DEACTIVATE_DSCERTIFICATE,insertParams);	
       	logger.info("count -->"+count);
       	if(count == 1){
       		updateCount = getJdbcTemplate().update(UPDATE_DEACTIVATE_DETAILS,params);	
       	}
        if(updateCount >0){
            logger.info("activateDeactivateUser(String userName,Integer activate)"+LoggingConstants.METHODEND); 
            return true;
        }
       	  logger.info("Update into DEACTIVATE_DSCERTIFICATE ");
         
       }catch (DataAccessException exception) {
       	DAOException.throwException("SE002",new Object[] {userName,referenceNo});
       }
       return false;	
	  }    
    
	public DSCDetails getDSCFormDetails(String referenceNo,String requestType) throws DAOException {
		logger.info("getDSCFormDetails(String referenceNo,String requestType) method begin");
		
		List formList = null;
		DSCDetails dscDetails=null;
		try {
			
			//String query =  GET_DSC_FORM_DETAILS;
			String query =  "";
			
			if("reregistration".equalsIgnoreCase(requestType)){
				query =  GET_DSC_REREG_FORM_DETAILS;
			}
			else {
				query =  GET_DSC_REG_FORM_DETAILS;
			}
			logger.info("query in DAO::"+query+"referenceNo::"+referenceNo+"requestType::"+requestType);
			Object[] param = {referenceNo};
			
			formList = (List) getJdbcTemplate().query(query,param,new DigitalSigCerReprintRowMapper());
			
			if(formList!=null && formList.size()>0)
			{
				dscDetails=(DSCDetails)formList.get(0);
			}
			
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

		}
		logger.info("getDSCFormDetails(String referenceNo,String requestType) method ends");
		return dscDetails;
	}

	public String updateReRegistrationDetails(String userName,String branchCode, String serialNo,String corporateId,String corpName,String moduleName) throws DAOException {
		logger.info("updateReRegistrationDetails(String userName,String branchCode, String serialNo,String corporateId,String corpName,String corpAddress): method begin");
    	String referenceNo= null;
    	int status =0;
    	
    	try{
    		int pendingCount=0;
        	int updateCount=0;
   	  		logger.info("userName ="+userName+": branchCode ="+branchCode+"serialNo :"+serialNo);
   	   	Object[] params={userName};
 	  	  String pendingDsc = "select count(*) from SBICORP_DSC_REG_DETAILS where " +
 	  	  		"user_name=? " +
 	  	  		"and branch_status='Pending' " +
 	  	  		"and request_type='reregistration'" +
 	  	  		" order by reference_no desc";
 	  	pendingCount =	getJdbcTemplate().queryForInt(pendingDsc,params);
 	  	 // pendingCount = (String) getJdbcTemplate().queryForObject(pendingDsc,params,String.class);		  
 	  	  logger.info("pendingCount>>>>>"+pendingCount);
 	  	  
   	  		String query="select 'DSC' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual";
   	  		referenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
          
   	  		logger.info("refferenceNo :"+referenceNo);
	       	Object[] insertParams={referenceNo,userName,branchCode,corporateId,corpName,serialNo,moduleName,"reregistration"};
	       	 
	       	logger.info("SBICORP_DSC_REG_DETAILS insert query:"+INSERT_DSC_REG_DETAILS);
	    	if(pendingCount > 0){
	       		Object[] params1={userName};
	       		String UPDATE_PENDING_DETAILS ="update SBICORP_DSC_REG_DETAILS set branch_status='delete' where user_name=? and request_type='reregistration'";
	       		updateCount = getJdbcTemplate().update(UPDATE_PENDING_DETAILS,params1);
	       		if(updateCount != 0){
	       			status = getJdbcTemplate().update(INSERT_DSC_REG_DETAILS,insertParams);
	       		}
	       	}else{
	       		status = getJdbcTemplate().update(INSERT_DSC_REG_DETAILS,insertParams);
	       	}
	       	
	       	
	      // 	status = getJdbcTemplate().update(INSERT_DSC_REG_DETAILS,insertParams);	
       	
	    	if(status == 1){
	       		logger.info("insert into SBICORP_DSC_REG_DETAILS table done successfully. ");
	       		return referenceNo;
	       	}
	    	else
	    		referenceNo="";
         
       }catch (DataAccessException exception) {
    	   DAOException.throwException("SE002",new Object[] {userName,referenceNo});
       }
    	
    	logger.info("updateReRegistrationDetails(String userName,String branchCode, String serialNo,String corporateId,String corpName,String corpAddress): method ends");
       return referenceNo;
       
	  }    
public DSCDetails getSFAModeChangeDetails(String userName) throws DAOException {
		logger.info("getSFAModeChangeDetails(String userName, String corporateID)method begin");
		
		List formList = null;
		DSCDetails dscDetails=null;
		try {
			
			String query =  GET_MODE_DETAILS;
			logger.info("query in DAO::"+query+",userName::"+userName);
			Object[] param = {userName};
			formList = (List) getJdbcTemplate().query(query,param,new SFADetailsRowMapper());
			
			if(formList!=null && formList.size()>0)
			{
				dscDetails=(DSCDetails)formList.get(0);
			}
			
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

		}
		logger.info("getDSCFormDetails(String userName, String corporateID): method ends");
		return dscDetails;
	}

	
	
	public boolean updateSFAModeChangeDetails(Map inparams) throws DAOException {
		logger.info("updateSFAModeChangeDetails (String userName, String corporateID)method begin");
		
		int updateCount = 0;
		boolean modeFlag = false; 
		try {
				String userName = (String) inparams.get("userName");
				String sfaMode = (String) inparams.get("sfaMode");
				String query =  UPDATE_SFA_MODE_CHANGE_QUERY;
				logger.info("userName :"+userName);
				logger.info("sfaMode :"+sfaMode);
				logger.info("query in DAO::"+query+",userName::"+userName+"sfaMode ::"+sfaMode);
				Object[] param = {sfaMode,userName};
				updateCount = getJdbcTemplate().update(query,param);
					if(updateCount>0)
					{
						modeFlag = true;
					}
			
	    	}catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	  		}
		logger.info("updateSFAModeChangeDetails(String userName, String corporateID): method ends");
		return modeFlag;
	}
	public List getC11FormRegListDetails(String userName, String corporateID) throws DAOException {
		
		logger.info("getC11FormRegListDetails(String userName, String corporateID) method begin");
		List regList = null;
		
		try {
			
			String regQuery =  GET_C11_REG_LIST_DETAILS;
			logger.info("userName :"+userName+",corporateID :"+corporateID);
			logger.info("regQuery :"+regQuery);
			Object[] param = {userName,corporateID};
			regList = (List) getJdbcTemplate().query(regQuery,param,new DigitalSigCerReprintRowMapper());
	
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getC11FormRegListDetails(String userName, String corporateID) method ends");
		return regList;
	}
	public List getC11FormReRegListDetails(String userName, String corporateID) throws DAOException {
		
		logger.info("getC11FormListDetails(String userName, String corporateID) method begin");
		List reRegList = null;
		
		try {
			
			String reRegQuery =  GET_C11_REREG_LIST_DETAILS;
			logger.info("userName :"+userName+",corporateID :"+corporateID);
			Object[] param = {userName,corporateID};
			logger.info("reRegQuery :"+reRegQuery);
			reRegList = (List) getJdbcTemplate().query(reRegQuery,param,new DigitalSigCerReprintRowMapper());
			
		
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception Occured :", dataAccessException);
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("getC11FormListDetails(String userName, String corporateID) method ends");
		return reRegList;
	}
	
	public int getRegisterPendingDetails(Map inparams) throws DAOException {
		logger.info("getRegisterPendingDetails (Map inparams)method begin");
		
		int selectCount = 0;
		boolean modeFlag = false; 
		try {
				String userName = (String) inparams.get("userName");
			
				String query =  "select count(*) from SBICORP_DSC_REG_DETAILS where user_name=? and branch_status='Pending' and request_type='registration'";
				logger.info("userName :"+userName);
				
				Object[] param = {userName};
				selectCount = getJdbcTemplate().queryForInt(query,param);
					
			
	    	}catch (DataAccessException dataAccessException) {
				logger.error("Exception Occured :", dataAccessException);
				DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	  		}
		logger.info("getRegisterPendingDetails(Map inparams) method ends");
		return selectCount;
	}
	
	public boolean isDSCRegistered(String userName) throws DAOException {
		 
		logger.info("isDSCRegistered(String userName)"	+ LoggingConstants.METHODBEGIN);
		
		logger.info("userName :" + userName);
		int registeredCount=0;
		boolean isDSCRegistered=false;
		
		try {
		
			Object[] parameters = new Object[] {userName};
			registeredCount =getJdbcTemplate().queryForInt(IS_DSC_REG_QUERY,parameters);
		
			if (registeredCount > 0) {
				isDSCRegistered=true;
			}
			logger.info("registeredCount :"+ registeredCount);
			logger.info("isDSCRegistered :"+ isDSCRegistered);
			
		} catch (DataAccessException dex) {
		    DAOException.throwException( ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dex);
		}catch(Exception ex){
		    DAOException.throwException( ErrorConstants.FATAL_ERROR1_CODE,ex );
		}
		
		logger.info("isDSCRegistered(String userName)"+ LoggingConstants.METHODEND);
		return isDSCRegistered;
	} 
	 
    class DigitalSigCerRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CorporateProfile 
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			DSCDetails dscDetails = new  DSCDetails();
			
			dscDetails.setCorporateId(rs.getString("CORPORATE_ID"));
			dscDetails.setCorporateName(rs.getString("CORPORATE_NAME"));
			dscDetails.setUserName(rs.getString("USER_NAME"));
			dscDetails.setReferenceNo(rs.getString("REFERENCE_NO"));
			dscDetails.setBranchCode(rs.getString("BRANCH_CODE"));
			dscDetails.setBranchName(rs.getString("BRANCH_NAME"));
			dscDetails.setSerialNo(rs.getString("SERIAL_NO"));
			dscDetails.setRequestType(rs.getString("REQUEST_TYPE"));
			return dscDetails;
		}
	}
    
  /*  class DigitalSigCerRePrintRowMapper implements RowMapper {
		*//**
		 * This method is used to map rows for CorporateProfile 
		 *//*
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			DSCDetails dscDetails = new  DSCDetails();
			dscDetails.setReferenceNo(rs.getString("REFERENCE_NO"));
			dscDetails.setUserName(rs.getString("USER_NAME"));
			
			dscDetails.setAuth1Name(rs.getString("AUTH1_NAME"));
			dscDetails.setAuth2Name(rs.getString("AUTH2_NAME"));
			dscDetails.setBranchCode(rs.getString("BRANCH_CODE"));
			dscDetails.setBranchName(rs.getString("BRANCH_NAME"));
			dscDetails.setCorporateId(rs.getString("CORPORATE_ID"));
			dscDetails.setCorporateName(rs.getString("CORPORATE_NAME"));
			
		
			
			return dscDetails;
		}
	}*/
    
    
    class DeactivateDigiSigCerRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CorporateProfile 
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			DSCDetails dscDetails = new  DSCDetails();
			
			dscDetails.setUserName(rs.getString("USER_NAME"));
			dscDetails.setReferenceNo(rs.getString("REFERENCE_NO"));
			dscDetails.setCorporateId(rs.getString("CORPORATE_ID"));
			dscDetails.setBranchCode(rs.getString("BRANCH_CODE"));
			dscDetails.setCorporateName(rs.getString("CORPORATE_NAME"));
			dscDetails.setCommonName(rs.getString("COMMONNAME"));
			dscDetails.setIssuerName(rs.getString("issuer_name"));
			dscDetails.setRole(rs.getString("role_in_inb"));
			dscDetails.setExpDate(rs.getTimestamp("expiry_date"));
			dscDetails.setSerialNo(rs.getString("SERIAL_NO"));
			
			return dscDetails;
		}
	}
    
    class DigitalSigCerReprintRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for CorporateProfile 
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			DSCDetails dscDetails = new  DSCDetails();
			
			dscDetails.setCorporateId(rs.getString("CORPORATE_ID"));
			dscDetails.setCorporateName(rs.getString("CORPORATE_NAME"));
			dscDetails.setUserName(rs.getString("USER_NAME"));
			dscDetails.setReferenceNo(rs.getString("REFERENCE_NO"));
			dscDetails.setBranchCode(rs.getString("BRANCH_CODE"));
			dscDetails.setBranchName(rs.getString("BRANCH_NAME"));
			dscDetails.setIssuerName(rs.getString("issuer_name"));
			dscDetails.setExpDate(rs.getTimestamp("expiry_date"));
			dscDetails.setRequestType(rs.getString("REQUEST_TYPE"));
			dscDetails.setBranchStatus(rs.getString("branch_status"));
			dscDetails.setSerialNo(rs.getString("serial_no"));
			
			return dscDetails;
		}
	}

class DigitalCertificateDetailsRowMapper implements RowMapper {
	/**
	 * This method is used to map rows for CorporateProfile 
	 */
	public Object mapRow(ResultSet rs, int index) throws SQLException {

		CertificateDetails cerftDetails = new CertificateDetails();
		
		cerftDetails.setCommonName(rs.getString("commonname"));
		cerftDetails.setIssuerName(rs.getString("issuer_name"));
		cerftDetails.setRole(rs.getString("role_in_inb"));
		cerftDetails.setExpDate(rs.getString("expiry_date"));
		
		return cerftDetails;
	}
}
	class DigitalCertificateDtlsRowMapper implements RowMapper {
	/**
	 * This method is used to map rows for CorporateProfile 
	 */
	public Object mapRow(ResultSet rs, int index) throws SQLException {

		CertificateDetails cerftDetails = new CertificateDetails();
		
		cerftDetails.setCommonName(rs.getString("commonname"));
		cerftDetails.setIssuerName(rs.getString("issuername"));
		cerftDetails.setExpDate(rs.getString("expirydate"));
		
		return cerftDetails;
	}
}    
class SFADetailsRowMapper implements RowMapper {
	/**
	 * This method is used to map rows for CorporateProfile 
	 */
	public Object mapRow(ResultSet rs, int index) throws SQLException {

		DSCDetails dscDetails = new  DSCDetails();
	
		dscDetails.setSfaProviderMode(rs.getString("SF_AUTH_PROVIDER"));
		dscDetails.setMobileNo(rs.getString("MOBILE_NO"));
	
		
		return dscDetails;
	}
}
}
 

