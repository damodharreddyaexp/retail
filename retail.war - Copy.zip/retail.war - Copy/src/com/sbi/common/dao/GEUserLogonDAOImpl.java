
/*
 * GEUserLogonDAOImpl.java
 * Created on Feb 13, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Feb 13, 2006 KRISHNA KUMAR - Initial Creation

package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
 
import com.sbi.common.dao.AccountDAOImpl.CreditableExtractor;
import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.LoggingConstants;

public class GEUserLogonDAOImpl extends JdbcDaoSupport  implements GEUserLogonDAO
{
    protected final Logger logger = Logger.getLogger(getClass());
    
    public String findStatus(String userName, String password) throws DAOException
    {
        logger.info("findStatus(String userName, String password)" + LoggingConstants.METHODBEGIN);
        logger.info("userName :"+userName);
        logger.info("password :"+password);
        String result=null;
        Object[] params={userName,password};
        if (userName != null&& !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) 
                && password!= null&& !password.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try{
                logger.info("inside try");
                result = (String)getJdbcTemplate().query(SQLConstants.FIND_GE_USER_STATUS,params,new StatusExtractor()); 
                logger.info("Result (status):" + result);
                }catch(DataAccessException ex){
                    logger.fatal(LoggingConstants.EXCEPTION, ex);
                    DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                    logger.fatal(LoggingConstants.EXCEPTION, exception);
                    throw exception;
                }   
         }else {
            DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            logger.fatal(LoggingConstants.EXCEPTION, exception);
            throw exception;
       } 
       logger.info("findStatus(String userName, String password)" + LoggingConstants.METHODEND);
       return result;
    }
    
    public boolean updateStatus(String userName, String password) throws DAOException
    {
        logger.info("updateStatus(String userName, String password) "+LoggingConstants.METHODBEGIN);
        boolean rowsUpdated = false;
        Object[] params={userName,password};
        if (userName != null&& !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) 
                && password!= null&& !password.trim().equalsIgnoreCase(DAOConstants.EMPTY))
        {
            try{
                int rows = getJdbcTemplate().update(SQLConstants.UPDATE_GE_USER_STATUS,params);
                if(rows > 0)
                    rowsUpdated = true;
                logger.info("No of rows updated = "+rows);
                logger.info("updateStatus(String userName, String password) "+LoggingConstants.METHODEND);
                return rowsUpdated;
            }catch (DataAccessException ex)
             { 
                logger.fatal(LoggingConstants.EXCEPTION, ex);
                DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                logger.fatal(LoggingConstants.EXCEPTION, exception);
                throw exception;
              }
        
        }else {
             DAOException exception = new DAOException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
             logger.fatal(LoggingConstants.EXCEPTION, exception);
             throw exception;
        } 
  }
    
    class StatusExtractor implements ResultSetExtractor{

        public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
            
            String status = "";
            while(rs.next())            
            {
                status = rs.getString("status");
            }
            return status;
        }
        
    }

   
   
}
