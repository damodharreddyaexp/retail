package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.utils.StringUtils;


public class DownloadBenificiariesListDAOImpl  extends JdbcDaoSupport implements DownloadBenificiariesListDAO{
	protected final Logger logger = Logger.getLogger(getClass());
	static int field=0;
	
	public int checkEligibilityForRegulator(String corporateID) throws DAOException{
		logger.info("corporateID :"+corporateID);
    	int resultcheck = 1;
    	List regulatorsList = new ArrayList();
    	try{
			
			Object params[] = new Object[] {corporateID};
			String sql ="select small_flag from sbicorp_corporate_profile where corporate_id=?";
			
			resultcheck =  getJdbcTemplate()
                    .queryForInt(sql,params);
			logger.info("result of eligibility check for regulator-->"+resultcheck);
			
			
			
		}catch (DataAccessException ex){
				 DAOException.throwException(
							ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		        	logger.error("DataAccessException :", ex);
		}
    	return resultcheck;
	}

	public int checkApproverEligible(String corporateID) throws DAOException{
		logger.info("corporateID :"+corporateID);
    	int resultcheck = 1;
    	List regulatorsList = new ArrayList();
    	try{
			
			Object params[] = new Object[] {corporateID};
			String sql ="select approver_level_3p from sbicorp_corporate_profile where corporate_id=?";
			
			resultcheck =  getJdbcTemplate()
                    .queryForInt(sql,params);
			logger.info("result of eligibility check -->"+resultcheck);
			
			
			
		}catch (DataAccessException ex){
				 DAOException.throwException(
							ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		        	logger.error("DataAccessException :", ex);
		}
    	return resultcheck;
	}
	
	public List getApprovers(String corporateID,String userName) throws DAOException{
    	logger.info("corporateID :"+corporateID);
    	List tempDetail = null;
    	List approversList = new ArrayList();
    	try{
			
			Object params[] = new Object[] {corporateID,userName};
			String sql =" select a.user_id user_id,a.user_alias user_alias from bv_user a , bv_user_profile b, bv_user_role c "+
						" where c.user_id=b.user_id and c.user_role=42 and  a.user_id=b.user_id and b.corporate_id=? " +
						" and a.user_state=0 and b.created_by=?";
			
			tempDetail =  getJdbcTemplate().query(sql,params,new ApproverDetailRowMapper());
			//logger.info("SIZE OF approvers list got from mapper -->"+tempDetail.size());
			
			/*approversList.add(0,"--Select Approver--");
			for(int i=1,j=0;j<tempDetail.size();i++,j++){
				approversList.add(i,tempDetail.get(j));
			}
			for(int j=0;j<tempDetail.size();j++){
				approversList.add(j,tempDetail.get(j));
			}*/
			
			
			//approversList.add(0,tempDetail.get(0));
			logger.info("SIZE OF final approvers list-->"+approversList.size());
			
		}catch (DataAccessException ex){
				 DAOException.throwException(
							ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		        	logger.error("DataAccessException :", ex);
		}
			
    	
		
		return tempDetail;
    	
    }
	
	
	public List getRegulators(String corporateID) throws DAOException{
    	logger.info("corporateID :"+corporateID);
    	List tempDetail = null;
    	List regulatorsList = new ArrayList();
    	try{
			
			Object params[] = new Object[] {corporateID};
			String sql =" select a.user_id,a.user_alias from bv_user a , bv_user_profile b, " +
					                    " bv_user_role c where c.user_id=b.user_id and c.user_role=10 and  " +
					                    " a.user_id=b.user_id and b.corporate_id=? and a.user_state=0 ";
			
			tempDetail =  getJdbcTemplate()
                    .query(
                    		sql,params,new RegulatorDetailRowMapper());
			logger.info("SIZE OF regulators list got from mapper -->"+tempDetail.size());
			
			/*regulatorsList.add(0,"--Select Regulator--");
			for(int i=1,j=0;j<tempDetail.size();i++,j++){
				regulatorsList.add(i,tempDetail.get(j));
			}
			logger.info("SIZE OF final regulators list-->"+regulatorsList.size());*/
			
				regulatorsList.add(0,tempDetail.get(0));
			
			
		}catch (DataAccessException ex){
				 DAOException.throwException(
							ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		        	logger.error("DataAccessException :", ex);
		}
			
    	
		
		return tempDetail;
    	
    }
	
	public List getAdmins(String corporateID) throws DAOException{
    	logger.info("corporateID :"+corporateID);
    	List tempadminDetail = null;
    	List adminList = new ArrayList();
    	try{
			
			Object params[] = new Object[] {corporateID};
			String sql =" select a.user_id,a.user_alias from bv_user a , bv_user_profile b, " +
					                    " bv_user_role c where c.user_id=b.user_id and c.user_role=7 and  " +
					                    " a.user_id=b.user_id and b.corporate_id=? and a.user_state=0 ";
			
			tempadminDetail =  getJdbcTemplate()
                    .query(
                    		sql,params,new AdminDetailRowMapper());
			logger.info("SIZE OF admin list got from mapper -->"+tempadminDetail.size());
			logger.info("element at 0 position is -->"+tempadminDetail.get(0));
			adminList.add(0,"TestAdmin");
			for(int i=1,j=0;j<tempadminDetail.size();i++,j++){
				adminList.add(i,tempadminDetail.get(j));
			}
			/*for(int k=1,l=0;k<tempadminDetail.size();k++,l++){
				adminList.add(k,tempadminDetail.get(l));
			}*/
			logger.info("SIZE OF final admins list-->"+adminList.size());
			
		}catch (DataAccessException ex){
				 DAOException.throwException(
							ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		        	logger.error("DataAccessException :", ex);
		}
			
    	
		
		return tempadminDetail;
    	
    }
    	
    	
    public class RegulatorDetailRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for TPBenThrirdParty
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			
			/*String temp = rs
					.getString("user_id") +","+rs
					.getString("user_alias");*/
			
			String temp = rs
					.getString("user_alias");
			
			return temp;
			
	
			/*UserDetail userDetail = new UserDetail();
			userDetail.setUserID(rs
					.getString("user_id"));
			userDetail.setUserName(rs
					.getString("user_alias"));
			return userDetail;*/
		}
	}
    
    public class AdminDetailRowMapper implements RowMapper {
		/**
		 * This method is used to map rows for TPBenThrirdParty
		 */
		public Object mapRow(ResultSet rs, int index) throws SQLException {
			
			/*String temp = rs
					.getString("user_id") +","+rs
					.getString("user_alias");*/
			
			String temp = rs
					.getString("user_alias");
			
			return temp;
			
	
			/*UserDetail userDetail = new UserDetail();
			userDetail.setUserID(rs
					.getString("user_id"));
			userDetail.setUserName(rs
					.getString("user_alias"));
			return userDetail;*/
		}
	}
    
    public class ApproverDetailRowMapper implements RowMapper {
  		/**
  		 * This method is used to map rows for TPBenThrirdParty
  		 */
  		public Object mapRow(ResultSet rs, int index) throws SQLException {
  			
  			/*String temp = rs
  					.getString("user_id") +","+rs
  					.getString("user_alias");*/
  			
  			String temp = rs
  					.getString("user_alias");
  			
  			return temp;
  			
  	
  			/*UserDetail userDetail = new UserDetail();
  			userDetail.setUserID(rs
  					.getString("user_id"));
  			userDetail.setUserName(rs
  					.getString("user_alias"));
  			return userDetail;*/
  		}
  	}
    
    public String generateRequestIdForDownload3PFile(
			String userName,String banktype,String corpId,String requestedBy,String formatType) throws DAOException {
	 logger.info("generateRequestIdForDownload3PFile(String userName,String banktype,String corpId,String formatType) method begins");
	  String requestId=null;
	  if( banktype==null || userName == null)            
      {
          DAOException.throwException("F001");
      }
	
      try{  
    	      String reqtype = "";
        	  Date d = new Date();
        	  String dateString=String.valueOf(d.getTime());
        	  if(field>9999)
        		  field=1;
        	  else field+=1;
        	  String padChar=StringUtils.padString(String.valueOf(field), 4, "0", "l");
        	  logger.info("requestId .."+dateString+padChar);
        	  requestId=dateString+padChar;
        	  requestId=requestId.substring(3, 17);
        	  logger.info("requestId.substring(3, 17);;;;"+requestId);
         	  logger.info("final requestId .."+requestId);
        	  logger.info("final userName .."+userName);
        	  logger.info("final corpId .."+corpId);
        	  logger.info("banktype"+banktype);
        	  logger.info("formatType"+formatType);
        	  logger.info("requestedBy by archanana :" +requestedBy);
        	  
        	  if (banktype.equalsIgnoreCase("3P")){
        		  reqtype = "corpintra_down_file";
        	  }else if(banktype.equalsIgnoreCase("IBTP"))
        	  {
        	  reqtype = "corpinter_down_file";
        	  }else if(banktype.equalsIgnoreCase("ABTP"))
        	  {
        	  reqtype = "corpaadhar_down_file";
        	  
        	  }
        	  logger.info("checking for correction");
        	  String sql=" insert into sbi_lpr_input(REQUEST_ID,USER_NAME,STATUS, " +
        	  		" REQUEST_TYPE,PARAM7,PARAM2,PARAM3,PARAM4,PARAM5,CREATION_TIME,PROCESS_TIME,PARAM8) " +
        	  		" values('"+requestId+"','"+userName+"','Pending','"+reqtype+"','"+formatType+"','','','"+corpId+"','',sysdate,sysdate,'"+requestedBy+"')";
        	  
        	  
        	  logger.info("query with parameters :" +sql);
        	  
        	 // Object[] insertParams={requestId,userName,reqtype,corpId,requestedBy};
        	 int result= getJdbcTemplate().update(sql);	
        	  logger.info("result--->"+result);
          logger.info("Insert into sbi_lpr_input ");
          
      }catch (Exception exception) {
    	  exception.printStackTrace();
          DAOException.throwException("CUS006",new Object[] {userName});
      }
	 return requestId;
     }
	
	public List viewBenDownload3PFileRequestStatus(String userName) throws DAOException{
		   logger.info("viewBenDownload3PFileRequestStatus(String username) method begins");
		   logger.info("username::::"+userName);
		   List echequeList=null;
		   if( userName != null ){
			   Object[] params;
			   try{
				   params = new Object[] {userName};
				   String sql="select REQUEST_ID,CREATION_TIME,STATUS, to_char(to_date(PARAM1,'dd-MM-yy'),'dd-mon-YY')PARAM1,to_char(to_date(PARAM2,'dd-MM-yy'),'dd-mon-YY')PARAM2,PARAM6,request_type,PARAM7  from bvsbi.sbi_lpr_input where user_name=? and request_type in ('corpinter_down_file','corpintra_down_file','corpaadhar_down_file') and  trunc(creation_time)>=trunc(sysdate-30) order by CREATION_TIME desc";
				   echequeList = (List)getJdbcTemplate().query(sql,params, new ViewStatusListExtractor());
			   }catch (DataAccessException exception) {
	                DAOException.throwException("CUS006",new Object[] {userName});
	            }
	        }else {
	            DAOException.throwException("CUS006",new Object [] {userName});//input params are null
	            logger.info("Null Input");// Exception to be added
	        }
	        logger.info("viewBenDownload3PFileRequestStatus method ends");
	        return echequeList;
	}
	
	private class ViewStatusListExtractor implements ResultSetExtractor{
    	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
    		List dataList = new ArrayList();

    		while(rs.next()){
	    		Map result=new HashMap();
    			result.put("REQUEST_ID",rs.getString("REQUEST_ID"));
    			SimpleDateFormat sdf=new SimpleDateFormat();
    			sdf.applyPattern("dd-MMM-yyyy hh:mm a");
    			result.put("CREATION_TIME",sdf.format(rs.getTimestamp("CREATION_TIME")));
    		
    			result.put("STATUS",rs.getString("STATUS"));
    			result.put("REQUEST_TYPE",rs.getString("REQUEST_TYPE"));
    			result.put("PARAM1",rs.getString("PARAM1"));
    			result.put("PARAM2",rs.getString("PARAM2"));
				result.put("PARAM7",rs.getString("PARAM7"));
				result.put("filename",rs.getString("PARAM6"));
    			dataList.add(result);
    		}
    		return dataList;
    	}
    }
    
}
