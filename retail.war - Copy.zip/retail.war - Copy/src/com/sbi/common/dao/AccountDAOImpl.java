/*
 * AccountDAOImpl.java
 * Created on Oct 18, 2005
 * 
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 BOOPATHI - Initial Creation
//NOV 23, 2005 BOOPATHI - CONSTANTS ADDED
//Nov 24, 2005 BOOPATHI - Constants added
//NOV 24, 2005 NAVEEN - ONE METHOD ADDED
//NOV 24, 2005 NAVEEN - CONSTANTS ADDED
//DEC 31, 2005 MANIKANDAN - ONE METHOD ADDED
//JAN 24, 2006 MANIKANDAN - ONE METHOD ADDED
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.tree.RowMapper;

import org.apache.log4j.Logger;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.cache.UserSessionCache;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;
import com.sbi.common.model.TransactionAccountDetails;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.BranchUtils;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;

import oracle.jdbc.driver.OracleTypes;

public class AccountDAOImpl extends JdbcDaoSupport implements AccountDAO {
     
    protected final Logger logger = Logger.getLogger(getClass());

    private BankSystemDAO coreDAOImpl;

    private UserSessionCache userSessionCache;

    private BranchUtils branchUtils;

    private UserDAO userDAOImpl;
    
    private static final String UPDATE_TP_NAME_ONLY = "update SBI_CUSTOMER_ACCOUNT_MAP set NAME_THIRD_PARTY = ?  where USER_NAME = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ?";
    
    private static final String UPDATE_TP_NAME = "update sbicorp_third_party set NAME_THIRD_PARTY = ?, outref7 = ?, mobile_no = ?, email_id = ?  where added_by = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ?";

    public static final String FIND_OLD_THIRDPARTY_NAME= "select NAME_THIRD_PARTY from SBI_CUSTOMER_ACCOUNT_MAP where USER_NAME = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ? and account_nature = 1";
    
    public static final String FIND_OLD_TP_NAME= "select NAME_THIRD_PARTY,outref7,mobile_no,email_id from sbicorp_third_party where added_by = ? AND BRANCH_CODE = ? AND ACCOUNT_NO = ? and approval_status in ('Pending','Approved')";
    
    public static final String FIND_RTGS_CREDIT_ACCOUNT= " select sum(noofrows) from(select count(1)noofrows from  sbi_rtgs_beneficiary where USER_NAME= ? and corporate_id=? and status='active' and FILE_SNO is NULL and (Payment_mode ='BOTH' or Payment_mode = 'RTGS')  and account_number=? and ifsc_code_receiver =? AND THIRD_PARTY_NAME=? " +
            " union select count(1)noofrows  from sbi_rtgs_beneficiary where corporate_id=? and user_role='10' and status='active' and FILE_SNO is NULL and (Payment_mode ='BOTH' or Payment_mode = 'RTGS') and account_number=?  and ifsc_code_receiver =? AND THIRD_PARTY_NAME=? union" +
            " select count(1)noofrows  from sbi_rtgs_beneficiary a, sbicorp_Ca_user_map b where b.user_name =? and a.user_name = b.ca_user and a.corporate_id =? and a.status='active'" +
            " and FILE_SNO is NULL and (Payment_mode ='BOTH' or Payment_mode = 'RTGS') and a.account_number=?  and a.ifsc_code_receiver =? AND a.THIRD_PARTY_NAME=? )";//RTGS credit account validation
    
    //5292
    public static final String GET_PRODUCT_DESCRIPTION= "  select product_code,product_type,product_desc,creditable FROM SBI_PRODUCT_DESC A WHERE PRODUCT_CODE in (?,?) ";
//Added for CR-5390
    public static final String DELETE_FROM_SBICORP_THIRD_PARTY = "delete from sbicorp_third_party where added_by =? and account_no =? and branch_code=? ";
    
    // Auth Chnages 
    private static final String VIEWINBOX_APPROVER_ACC ="select a.OID,a.account_no,product_desc,a.product_code, a.limit,a.product_type accounttype, a.product_type, b.branch_name,a.account_nickname,a.branch_code,A.CREATION_TIME  from sbicorp_ca_account_map a, sbi_branch_master b  where a.verify_flag=0 and  a.status=1 and product_type is not null and b.status=1 and a.branch_code=b.branch_code and b.core_banking=0 and exists (select ca_user from sbicorp_ca_user_map d where a.ca_user=d.ca_user and d.user_name= ?)";

  //added for CR 5679

    /*public static final String FIND_MT940_ACCOUNT_DETAILS = "SELECT a.OID, a.account_no, a.product_type, a.account_nickname, a.branch_code, a.core_message_status, b.branch_name, b.clear_balance, "+
   		 "b.currency,access_level, a.core_message_status core_message_status,c.core_banking coreflag, a.product_type accounttype, a.product_desc, "+
		 "a.product_code, a.user_name, lock_flag, decode(d.LIMIT,0, -1,null,-1,d.limit) limit, "+
		 "c.NEFT_IFSC_CODE, c.RTGS_IFSC_CODE "+
        " FROM sbi_customer_account_map a, sbi_all_master b, sbi_branch_master c, sbicorp_ca_account_map d,SBI_MT940_ACCOUNT_STATEMENT e "+
		 "WHERE e.user_name = ? AND a.verify_flag = 0 AND a.account_nature = 0 AND a.status = 1 AND a.account_no = b.account_no AND a.branch_code = b.branch_code and a.account_no=e.account_number and a.corporate_id=e.corporate_id and a.user_name=e.user_name and e.registration_status='Processed'"+
		 "AND b.branch_code = c.branch_code AND c.status = 1 AND c.core_banking = 1 AND access_level != 0 AND d.ACCOUNT_NO(+) = a.ACCOUNT_NO "+
		" AND D.BRANCH_CODE(+) = A.BRANCH_CODE AND a.product_type IS NOT NULL "+
           " UNION SELECT a.OID, a.account_no, a.product_type, a.account_nickname, a.branch_code, "+
		"a.core_message_status, b.branch_name, 0 AS clear_balance,'INR' AS currency, access_level, a.core_message_status core_message_status, core_banking coreflag, "+
		"a.product_type accounttype, a.product_desc, a.product_code, a.user_name, lock_flag, decode(C.LIMIT,0, -1,null,-1,C.limit) limit , b.NEFT_IFSC_CODE, b.RTGS_IFSC_CODE "+
           " FROM sbi_customer_account_map a, sbi_branch_master b, sbicorp_ca_account_map C,SBI_MT940_ACCOUNT_STATEMENT e "+
		"WHERE a.user_name = ? AND a.verify_flag = 0 AND a.account_nature = 0 AND a.status = 1 AND b.status = 1 AND a.branch_code = b.branch_code  and a.account_no=e.account_number and a.corporate_id=e.corporate_id and a.user_name=e.user_name and e.registration_status='Processed'"+
		"AND b.core_banking = 0 AND access_level != 0 AND C.ACCOUNT_NO(+) = a.ACCOUNT_NO AND C.BRANCH_CODE(+) = A.BRANCH_CODE AND a.product_type IS NOT NULL ORDER BY product_type ";*/

    public static final String FIND_MT940_ACCOUNT_DETAILS =  "select c.account_no,c.branch_code,c.product_type accounttype,c.account_nickname, b.branch_name from  SBI_MT940_ACCOUNT_STATEMENT a," +
    		"sbi_customer_account_map c,sbi_branch_master b where b.branch_code=c.branch_code and a.account_number=c.account_no and a.registration_status='Processed' and exists " +
    		"( select q.user_name from sbicorp_ca_user_map p,sbicorp_ca_user_map q where p.user_name =c.user_name and p.ca_user = q.ca_user and a.user_name =  q.user_name and p.status =1 and q.status =1) and c.user_name=?";
    public static final String FIND_MT940_MODIFY_DELETE="select a.registration_status,c.account_no,c.branch_code,c.product_type accounttype,c.account_nickname, b.branch_name from  SBI_MT940_ACCOUNT_STATEMENT a," +
    		"sbi_customer_account_map c,sbi_branch_master b ,sbicorp_ca_user_map p where b.branch_code=c.branch_code and a.account_number=c.account_no and p.status=1"+
    		"AND a.user_name =c.user_name AND p.user_name =c.user_name and a.registration_status='Processed' and a.user_name=?";
    
    //end CR 5679
    
    // CR-CPSMS Benificiary details display
    public static final String VIEWINBOX_ADMIN_ACC ="select a.OID,a.ca_user,a.account_no,product_desc,a.product_code, a.limit,a.product_type accounttype, a.product_type,b.branch_name,a.account_nickname,a.branch_code,A.CREATION_TIME from sbicorp_ca_account_map a, sbi_branch_master b  where a.verify_flag=0 and  a.status=1 and product_type is not null and b.status=1 and a.branch_code=b.branch_code and b.core_banking=0 and a.ca_user= ? and a.corporateid= ?";
    
    //Account statement changes with timestamp
    public static final String TIMESTAMP_FLAG= "select TIMESTAMP_REQUIRED from sbicorp_corporate_profile where corporate_id = ?";
    
  //added by Damodar for Account based MIS downloads with starts   
    public static final String USERPROFILE_DETAILS= "select CREATED_BY from bv_user_profile where   CORPORATE_ID= ? and user_id in (select user_id from bv_user where user_alias= ? )";
    public static final String USERID_DETAILS= "select user_id from bv_user where user_alias= ?";
    public static final String USER_ROLES= "SELECT user_role FROM BV_USER_ROLE WHERE USER_ID= ?";
    public static final String ACCOUNT_DETAILS_FETCHING= "select scam.ACCOUNT_NO,scam.PRODUCT_TYPE,scam.PRODUCT_DESC,scam.BRANCH_CODE, scam.PRODUCT_CODE,sbm.branch_name from sbicorp_ca_account_map scam,sbi_branch_master sbm where  scam.ca_user= ? and scam.status='1' and scam.deleted='0' and scam.corporateid =? and scam.BRANCH_CODE = sbm.BRANCH_CODE "; 
    public static final String ACCOUNT_FETCHING= "select scam.account_no,scam.product_type,scam.Product_desc,scam.branch_code,scam.PRODUCT_CODE,sbm.branch_name from sbicorp_ca_account_map scam,sbi_branch_master sbm where scam.corporateid =? and scam.status='1' and scam.deleted='0' and scam.BRANCH_CODE = sbm.BRANCH_CODE ";
    //added by Damodar for Account based MIS downloads with ends  
    
    /**
     * Iterate the accounts and check the corresponding BankSystem If the
     * BankSystem is core call getCoreBalance and update the balance and return
     * the account list else Call getSwitchBalance and update the balance and
     * return the account List
     * 
     * @param accounts
     *            [List]
     * @return accounts [List]
     * @throws DAOException
     */
    public List findLatestBalance(List accounts) throws DAOException {
        logger.info("findLatestBalance(List accounts)" + LoggingConstants.METHODBEGIN);
        if (accounts.size() > 0) {

            for (int i = 0; i < accounts.size(); i++) {
                Account account = (Account) accounts.get(i);
                if (logger.isDebugEnabled()) {
                    logger.debug("account :" + account);
                }

                if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE)) {
                    HashMap coreData = getCoreBalance(account);
                    if (logger.isDebugEnabled()) {
                        logger.debug("coreData :" + coreData);
                    }

                    account.setBalance(new Double((String) coreData.get(DAOConstants.AVAIL_BAL)));

                }
                else {
                    HashMap switchData = getSwitchBalance(account);
                    if (logger.isDebugEnabled()) {
                        logger.debug("switchData :" + switchData);
                    }
                    account.setBalance(new Double((String) switchData.get(DAOConstants.CORE_BALANCE)));
                }
            }
            logger.info("findLatestBalance(List accounts)" + LoggingConstants.METHODEND);
            return accounts;

        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    /**
     * Call fetchAccounts(username) and return List of accounts
     * 
     * @param userName
     * @return accountList [List]
     * @throws DAOException
     */

    public List findAccounts(String username) throws DAOException {

        logger.info("findAccounts(String username)" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + username);

        if (username != null && !(username.trim()).equals(DAOConstants.EMPTY)) {
            List accountList = fetchAccounts(username);
            if (accountList.size() > 0) {
                if (logger.isDebugEnabled()) {
                    logger.debug("accountList :" + accountList);
                }
                logger.info("findAccounts(String username)" + LoggingConstants.METHODEND);
                for(int counter=0;counter<accountList.size();counter++)
                {
                	Account currentelement = (Account)accountList.get(counter);
                	String accountnature = currentelement.getAccountNature();
                	if(accountnature != null && accountnature.equalsIgnoreCase(DAOConstants.CORE_BM_ACCOUNT_NATURE))
                	{
                		accountList.remove(counter);
                	}
                }
                return accountList;
            }
            else {
                logger.info("findAccounts(String username)" + LoggingConstants.METHODEND);
                return null;
            }
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }

        return null;
    }

    /**
     * Call fetchAccounts(username) and return List of accounts filtered by
     * productType
     * 
     * @param userName
     * @param productType
     * @return returnAccountList [List]
     * @throws DAOException
     */
    public List findAccounts(String username, String productType) throws DAOException {

        logger.info("findAccounts(String username, String productType)" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + username + " productType :" + productType);
 
        if (username == null || productType == null || (username.trim()).equals(DAOConstants.EMPTY)
                || (productType.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            List returnAccountList = new ArrayList();

            List accountList = fetchAccounts(username);
            if (accountList.size() == 0)
                return null;

            for (int i = 0; i < accountList.size(); i++) {
                Account acc = (Account) accountList.get(i);
                if (acc.getProductType().equalsIgnoreCase(productType)) {
                    returnAccountList.add(acc);
                }
            }
            if (returnAccountList.size() > 0) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnAccountList :" + returnAccountList);
                }
                logger.info("findAccounts(String username, String productType)" + LoggingConstants.METHODBEGIN);
                return returnAccountList;
            }
            else {
                logger.info("findAccounts(String username, String productType)" + LoggingConstants.METHODBEGIN);
                return null;
            }

        }
        return null;

    }

    /**
     * Call fetchAccounts(username) return List of accounts if (core account) {
     * Call -getCoreBalance(accounts) return Map } Update the account object
     * balance attribute. return List [accounts]
     * 
     * @param userName
     * @return accountList [List]
     * @throws DAOException
     */

    public List findAccountsWithBalance(String username, Boolean accountLimit) throws DAOException {

        logger.info("findAccountsWithBalance(String username))" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + username);

        if (username != null && !(username.trim()).equals(DAOConstants.EMPTY) && accountLimit != null) {
            List accountList;
            if (!accountLimit.booleanValue()) {
              accountList = fetchAccounts(username);
            }
            else

            {
                List allAccountList = fetchAccounts(username);
                accountList = filterAccounts(allAccountList);

            }
            logger.info("After filtering accounts :::::" + accountList.size() );
            if (accountList.size() == 0)
                return null;

            for (int i = 0; i < accountList.size(); i++) {
                Account acc = (Account) accountList.get(i);
                if (acc.getBankSystem().equals(DAOConstants.CORE)) {
                    HashMap coreData = getCoreBalance(acc);
                    if (logger.isDebugEnabled()) {
                        logger.debug("coreData :" + coreData);
                    }

                    String status = null;
                    String errorCode = null;

                    if (coreData.get("status") != null)
                        status = (String) coreData.get("status");
                    if (coreData.get("error_code") != null) {
                        errorCode = (String) coreData.get("error_code");
                        status = errorCode;
                    }

                    if (status == null && errorCode == null) {

                        if (acc.getProductType().equalsIgnoreCase("A5")
                                && !(acc.getProductDescription().substring(0, 2).equalsIgnoreCase("RD")))
                            acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                    .get(DAOConstants.TERM_VALUE)));
                        else
                            acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                    .get(DAOConstants.AVAIL_BAL)));

                        acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE));
                    }
                    else {
                        acc.setBalance(new Double(0));
                        acc.setCurrency("NA");
                    }
                }

            }
            if (logger.isDebugEnabled()) {
                logger.debug("accountList :" + accountList);
            }
            logger.info("findAccountsWithBalance(String username))" + LoggingConstants.METHODEND);
            return accountList;
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    /**
     * Call fetchAccounts(username) return List of accounts filter the accounts
     * by productType if(core account){ Call -getCoreBalance(accounts) return
     * Hashmap Update the account object balance attribute. } return List
     * [accounts] filtered by productType Update the account object balance
     * attribute. return List [accounts]
     * 
     * @param userName
     * @return accountList [List]
     * @throws DAOException
     */

    public List findAccountsWithBalance(String username, String productType[]) throws DAOException {

        logger.info("findAccountsWithBalance(String username, String productType)" + LoggingConstants.METHODBEGIN);

        //logger.info("username :" + username + " productType :" + productType);

        if (username == null || productType == null || (username.trim()).equals(DAOConstants.EMPTY)
                ) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            List returnList = new ArrayList();

            List accList = (List) fetchAccounts(username);

            if (accList.size() == 0)
                return null;

            for (int i = 0; i < accList.size(); i++) {
                Account acc = (Account) accList.get(i);
                int typelength = productType.length;
                boolean filterType = false;
                logger.info("*********** Typelength " + typelength);
                    for(int j=0;j < typelength;j++ ){
                        if(acc.getProductType().equals(productType[ j ])){
                            filterType = true;
                            break;
                        }
                      }
                if (filterType == true) {
                    logger.info("Product type " + acc.getProductType());
                    if (acc.getBankSystem().equals(DAOConstants.CORE)) {
                        HashMap coreData = getCoreBalance(acc);
                        if (logger.isDebugEnabled()) {
                            logger.debug("coreData :" + coreData);
                        }

                        String status = null;
                        String errorCode = null;

                        if (coreData.get("status") != null)
                            status = (String) coreData.get("status");
                        if (coreData.get("error_code") != null) {
                            errorCode = (String) coreData.get("error_code");
                            status = errorCode;
                        }

                        if (status == null && errorCode == null) {

                            if (acc.getProductType().equalsIgnoreCase("A5")
                                    && !(acc.getProductDescription().substring(0, 2).equalsIgnoreCase("RD")))
                                acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                        .get(DAOConstants.TERM_VALUE)));
                            else
                                acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                        .get(DAOConstants.AVAIL_BAL)));

                            acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE));
                        }
                        else {
                            acc.setBalance(new Double(0));
                            acc.setCurrency("NA");
                        }
                    }
                    returnList.add(acc);
                }
            }
            if (returnList.size() > 0) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnList :" + returnList);
                }
                logger
                        .info("findAccountsWithBalance(String username, String productType)"
                                + LoggingConstants.METHODEND);
                return returnList;
            }
            else {
                logger
                        .info("findAccountsWithBalance(String username, String productType)"
                                + LoggingConstants.METHODEND);
                return null;
            }
        }
        return null;
    }

    /**
     * Execute query on SBI_CUSTOMER_ACCOUNT_MAP table to fetch accounts
     * matching the accountNature Convert query output to accounts object List
     * and return List
     * 
     * @param userName
     * @param accountnature
     * @return accList [List]
     */

    public List findAccountsByNature(String userName, Integer accountnature) {
        logger.info("findAccountsByNature(String userName, Integer accountnature)" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + userName + " accountnature :" + accountnature);

        if (userName == null || accountnature == null || (userName.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            try {

                Object[] parameters = new Object[]
                { accountnature, userName };
                List accList = getJdbcTemplate().query(SQLConstants.ACCOUNTS_BY_NATURE_QUERY, parameters,
                        new AccountRowMapper());

                if (accList.size() > 0) {
                    for (int i = 0; i < accList.size(); i++) {
                        Account acc = (Account) accList.get(i);
                        acc.setAccountNature(accountnature.toString());
                    }
                    if (logger.isDebugEnabled()) {
                        logger.debug("accList :" + accList);
                    }
                    logger.info("findAccountsByNature(String userName, Integer accountnature)"
                            + LoggingConstants.METHODEND);
                    return accList;
                }
                else {
                    logger.info("findAccountsByNature(String userName, Integer accountnature)"
                            + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

            }

        }
        return null;

    }

    /**
     * Call fetchAccounts(username) and return List of accounts Return account
     * object filtered by branchcode and accountno
     * 
     * @param userName
     * @param accountnature
     * @return accList [List]
     */
    public Account findAccount(String accountno, String branchcode, String username) throws DAOException {
        logger.info("findAccount(String accountno, String branchcode, String username)" + LoggingConstants.METHODBEGIN);

        logger.info("accountno :" + accountno + " branchcode :" + branchcode + " username :" + username);

        if (accountno == null || branchcode == null || username == null || (username.trim()).equals(DAOConstants.EMPTY)
                || (branchcode.trim()).equals(DAOConstants.EMPTY) || (accountno.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            Account returnAccount = null;
            List accList = fetchAccounts(username);

            if (logger.isDebugEnabled()) {
                logger.debug("Account List size : " + accList.size());
            }

            if (accList.size() == 0)
                return null;

            int size = accList.size();
            for (int i = 0; i < size; i++) {
                Account acc = (Account) accList.get(i);
                if (acc.getAccountNo().equalsIgnoreCase(accountno) && acc.getBranchCode().equalsIgnoreCase(branchcode)) {
                    returnAccount = (Account) accList.get(i);
                }
            }

            if (returnAccount != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnAccount: " + returnAccount);
                }
                logger.info("findAccount(String accountno, String branchcode, String username) "
                        + LoggingConstants.METHODEND);
                return returnAccount;
            }
            else {
                logger.info("findAccount(String accountno, String branchcode, String username) "
                        + LoggingConstants.METHODEND);
                return null;
            }
        }
        return null;

    }

    /**
     * 1. Invokes AccountDAO.findAccounts to get account list object 2. Loop
     * through the list and filter accounts with accesslevel 5 or 9. If account
     * is non core, the check the first 3 characters of account no to match the
     * list (010,011,015,016,017,01294). Create a accounts list object with
     * filtered objects. 3. Return the list
     * 
     * public List getCreditAccounts( List accounts ) { return null; }
     * 
     * @param userName
     * @param productType
     * @return filterAccountList [List]
     * @throws DAOException
     */

    public List findTransactionAccount(String userName, String productType) throws DAOException {
        logger.info("findTransactionAccount(String userName, String productType)" + LoggingConstants.METHODBEGIN);

        logger.info("userName :" + userName + " productType :" + productType);

        Account account = null;
        List accountList = fetchAccounts(userName);
        if (accountList.size() == 0)
            return null;
        if (logger.isDebugEnabled()) {
            logger.debug("Account list from Fetch Account" + accountList);
        }
        if (productType.equals(ServiceConstant.DEBIT_ACCOUNT)) {
            List filterAccountList = new ArrayList();
            if (logger.isDebugEnabled()) {
                logger.debug("getting Debit Accounts ");
            }

            for (int i = 0; i < accountList.size(); i++) // while(iterator.hasNext())
            {
                account = (Account) accountList.get(i); // (Account)iterator.next();
                if (logger.isDebugEnabled()) {
                    logger.debug("Bank System " + account.getBankSystem());
                    logger.debug("account no " + account.getAccountNo().substring(0, 3));
                }
                if (account.getAccessLevel().equals(new Integer(DAOConstants.DEBIT_NO))) {
                    if (account.getBankSystem().equals(DAOConstants.CORE)) {
                    	if(account.getProductType().equals(DAOConstants.A1) || account.getProductType().equals(DAOConstants.A2) || account.getProductType().equals(DAOConstants.A3) || account.getProductType().equals(DAOConstants.A4)){
                    		filterAccountList.add(account);
                    	}
                    }
                    else if (DAOConstants.NC_DEBIT_ACCOUNT_DATA.indexOf(account.getAccountNo().substring(0, 3)) >= 0) {
                        filterAccountList.add(account);
                    } 
                } 
            }
            logger.info(filterAccountList);
            return filterAccountList;
        }

        /* filter for credit accont */

        if (productType.equals(ServiceConstant.CREDIT_ACCOUNT)) {
            List filterAccountList = new ArrayList();
            if (logger.isDebugEnabled()) {
                logger.debug("getting Debit Accounts ");
            }
            for (int i = 0; i < accountList.size(); i++) // while(iterator.hasNext())
            {
                account = (Account) accountList.get(i); // account =
                // (Account)iterator.next();
                if (account.getAccessLevel().equals(new Integer(DAOConstants.DEBIT_NO))
                        || account.getAccessLevel().equals(new Integer(DAOConstants.CREDIT_NO))) {
                    if (account.getBankSystem().equals(DAOConstants.CORE)) {
                        if (account.isCreditable().booleanValue())
                            filterAccountList.add(account);
                    }
                    else if (DAOConstants.NC_CREDIT_ACCOUNT_DATA.indexOf(account.getAccountNo().substring(0, 3)) >= 0
                            || account.getAccountNo().substring(0, 5).equals(DAOConstants.NC_CREDIT_ACCOUNT_DATA1)) {
                        filterAccountList.add(account);
                    }
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("filteraccountList debit " + filterAccountList);
            }
            logger.info("findTransactionAccount(String userName, String productType)" + LoggingConstants.METHODEND);
            return filterAccountList;
        }
        return null;

    }

    /**
     * 1. Invokes AccountDAO.fetchAccount to get account list object 2. Loop
     * through the list and filter accounts with accesslevel 5 or 9 and also
     * filter the accounts with productType.Create a accounts list object with
     * filtered objects. 3. Return the list
     */
    
    public Map findAccounts(String username, String corporateID, Integer accessLevel) throws DAOException {
        logger.info("findAccounts(String username, String[] productType, Integer accessLevel)"
                + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("username :" + username + " accessLevel :" + accessLevel);
        }
        
        if (username == null || accessLevel == null
                    || (username.trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
        
        List savingsAccountList = new ArrayList();
        List currentAccountList = new ArrayList();
        List cashcreditAccountList = new ArrayList();
        List timedepositAccountList = new ArrayList();
        List otherloansAccountList = new ArrayList();
        List tradeAccountList = new ArrayList();
        Map returnAccountMap = new HashMap();
        Object[] params={corporateID};
        
        String timestampFlag = (String) getJdbcTemplate().queryForObject(TIMESTAMP_FLAG, params, String.class);

        
        List accountList = fetchAccounts(username);
        if (accountList.size() == 0)
            return null;

        /* Filtering Accounts on the Basis of accessLevel and productType */

        for (int i = 0; i < accountList.size(); i++) {
            Account acc = (Account) accountList.get(i);
            logger.info("acc :::::"+acc);
            logger.info("acc.getProductType():::::"+acc.getProductType());
            if (acc.getProductType().equalsIgnoreCase("A1")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    savingsAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A2")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    currentAccountList.add(acc);
            }
            if ((acc.getProductType().equalsIgnoreCase("A3") || acc.getProductType().equalsIgnoreCase("A4"))&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    cashcreditAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A5")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    timedepositAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A6")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    otherloansAccountList.add(acc);
            }
            if ((acc.getProductType().equalsIgnoreCase("A8") || acc.getProductType().equalsIgnoreCase("A9"))
            		&& acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    tradeAccountList.add(acc);
            }
            
            }
        
        	returnAccountMap.put("Savings", savingsAccountList);
        	returnAccountMap.put("Current", currentAccountList);
        	returnAccountMap.put("CashCredit", cashcreditAccountList);
        	returnAccountMap.put("TimeDeposit", timedepositAccountList);
        	returnAccountMap.put("OtherLoans", otherloansAccountList);
        	returnAccountMap.put("Trade", tradeAccountList);
        	returnAccountMap.put("TimeStampFlag", timestampFlag);
        
        if (returnAccountMap.size() > 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("returnAccountMap :" + returnAccountMap);
            }
            return returnAccountMap;
        }
        else
            return null;
    }
    
    
 //added by Damodar for Account based MIS reports   
  public Map findUserAccountsForMIS(String username, String corporateID, Integer accessLevel) throws DAOException {
        logger.info("findUserAccountsForMIS(String username, String[] productType, Integer accessLevel)"
                + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("username :" + username + " accessLevel :" + accessLevel);
        }
        
        if (username == null || accessLevel == null
                    || (username.trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
        
        List savingsAccountList = new ArrayList();
        List currentAccountList = new ArrayList();
        List cashcreditAccountList = new ArrayList();
        List timedepositAccountList = new ArrayList();
        List otherloansAccountList = new ArrayList();
        List tradeAccountList = new ArrayList();
        Map returnAccountMap = new HashMap();
        Object[] params={corporateID};
        
        //String timestampFlag = (String) getJdbcTemplate().queryForObject(TIMESTAMP_FLAG, params, String.class);

        
        List accountList = fetchAccounts(username);
        if (accountList.size() == 0)
            return null;

        /* Filtering Accounts on the Basis of accessLevel and productType */

        for (int i = 0; i < accountList.size(); i++) {
            Account acc = (Account) accountList.get(i);
            logger.info("acc :::::"+acc);
            logger.info("acc.getProductType():::::"+acc.getProductType());
            if (acc.getProductType().equalsIgnoreCase("A1")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    savingsAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A2")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    currentAccountList.add(acc);
            }
            if ((acc.getProductType().equalsIgnoreCase("A3") || acc.getProductType().equalsIgnoreCase("A4"))&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    cashcreditAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A5")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    timedepositAccountList.add(acc);
            }
            if (acc.getProductType().equalsIgnoreCase("A6")&& 
            		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    otherloansAccountList.add(acc);
            }
            if ((acc.getProductType().equalsIgnoreCase("A8") || acc.getProductType().equalsIgnoreCase("A9"))
            		&& acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
            {
                    tradeAccountList.add(acc);
            }
            
            }
        
        	returnAccountMap.put("Savings", savingsAccountList);
        	returnAccountMap.put("Current", currentAccountList);
        	returnAccountMap.put("CashCredit", cashcreditAccountList);
        	returnAccountMap.put("TimeDeposit", timedepositAccountList);
        	returnAccountMap.put("OtherLoans", otherloansAccountList);
        	returnAccountMap.put("Trade", tradeAccountList);
        	//returnAccountMap.put("TimeStampFlag", timestampFlag);
        
        if (returnAccountMap.size() > 0) {
            
                logger.info("returnAccountMap :" + returnAccountMap);
           
            return returnAccountMap;
        }
        else
            return null;
    }
  
  
 
  // added by Damodar reddy for uploader,admin and regulator account fetching
  public Map findAccountsForMIS(String username, String corporateID, Integer accessLevel,Integer loginUserRole) throws DAOException {
      logger.info("findAccountsForMIS(String username, String[] corporateID, Integer accessLevel,Integer loginUserRole )"
              + LoggingConstants.METHODBEGIN);
      if (logger.isDebugEnabled()) {
          logger.debug("username :" + username + " accessLevel :" + accessLevel);
      }
      
      if (username == null || accessLevel == null
                  || (username.trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
              DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

          }
      
      List savingsAccountList = new ArrayList();
      List currentAccountList = new ArrayList();
      List cashcreditAccountList = new ArrayList();
      List timedepositAccountList = new ArrayList();
      List otherloansAccountList = new ArrayList();
      List tradeAccountList = new ArrayList();
      Map returnAccountMap = new HashMap();
      List accountList = null;        
     // Object[] params={corporateID};
      Object[] params =
          {  corporateID,username};
     // String timestampFlag = (String) getJdbcTemplate().queryForObject(TIMESTAMP_FLAG, params, String.class);
    
      Object[] accparams2 = new Object[] {corporateID};
      Object[] accparams3 = new Object[] {username,corporateID};
      try{ 
      	
     if(loginUserRole ==21){	
         logger.info("Uploader loginUserRole :"+loginUserRole);
         String createdByUser = (String) getJdbcTemplate().queryForObject(USERPROFILE_DETAILS, params, String.class);
	        logger.info("createdByUser :"+createdByUser);
	        Object[] parameter = new Object[] {createdByUser};
	        String userId = (String) getJdbcTemplate().queryForObject(USERID_DETAILS, parameter, String.class);
	        logger.info("userId :"+userId);
	        Object[] outparams = new Object[] {userId}; 
	        String userRole = (String) getJdbcTemplate().queryForObject(USER_ROLES, outparams, String.class);
	        logger.info("userRole :"+userRole);
	        Object[] accparams1 =
	            { createdByUser, corporateID}; 
      if(userRole.equals("7"))
      {
        //accountList = (List)getJdbcTemplate().query(ACCOUNT_DETAILS_FETCHING,params, new AccountForMISExtractor());
          accountList = getJdbcTemplate().query(ACCOUNT_DETAILS_FETCHING,accparams1, new AccountRowMapperForMIS());
      logger.info("accountList Size :"+accountList.size()); 

      }
      else if(userRole.equals("10"))
      {
          accountList = getJdbcTemplate().query(ACCOUNT_FETCHING,accparams2, new AccountRowMapperForMIS());
          logger.info("accountList Size :"+accountList.size());
      }
     }
      if(loginUserRole ==7){	 
	        logger.info("Admin loginUserRole :"+loginUserRole);
	        accountList = getJdbcTemplate().query(ACCOUNT_DETAILS_FETCHING,accparams3, new AccountRowMapperForMIS());
	        logger.info("accountList Size :"+accountList.size()); 
             
	        }
      
     if(loginUserRole ==10){	
         logger.info("Regulator loginUserRole :"+loginUserRole);
          accountList = getJdbcTemplate().query(ACCOUNT_FETCHING,accparams2, new AccountRowMapperForMIS());
          logger.info("accountList Size :"+accountList.size());
     // }
      }
     
     if(loginUserRole ==13){	
         logger.info("SuperEnquirer  loginUserRole :"+loginUserRole);
          accountList = getJdbcTemplate().query(ACCOUNT_FETCHING,accparams2, new AccountRowMapperForMIS());
          logger.info("accountList Size :"+accountList.size());
     // }
      }
     
   
      }
      catch (DataAccessException e) {
				logger.error("Error Occured : " + e.getMessage());
	            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			} 
      catch(NoSuchMessageException e){
			logger.error("No Such Account for the Report");
			accountList=null;
		}
		catch (Exception e) {
			logger.error("getAccount Details catch");
			accountList=null;
		} 

    //   Filtering Accounts on the Basis of accessLevel and productType 

      for (int i = 0; i < accountList.size(); i++) {
          Account acc = (Account) accountList.get(i);
          logger.info("acc :::::"+acc);
          logger.info("acc.getProductType():::::"+acc.getProductType());
          if (acc.getProductType().equalsIgnoreCase("A1")/*&& 
          		acc.getAccessLevel().intValue() >= accessLevel.intValue()*/) 
          {
                  savingsAccountList.add(acc);
          }
          if (acc.getProductType().equalsIgnoreCase("A2")/*&& 
          		acc.getAccessLevel().intValue() >= accessLevel.intValue()*/) 
          {
                  currentAccountList.add(acc);
          }
          if ((acc.getProductType().equalsIgnoreCase("A3") || acc.getProductType().equalsIgnoreCase("A4"))/*&& 
          		acc.getAccessLevel().intValue() >= accessLevel.intValue()*/) 
          {
                  cashcreditAccountList.add(acc);
          }
          /*if (acc.getProductType().equalsIgnoreCase("A5")&& 
          		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
          {
                  timedepositAccountList.add(acc);
          }
          if (acc.getProductType().equalsIgnoreCase("A6")&& 
          		acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
          {
                  otherloansAccountList.add(acc);
          }
          if ((acc.getProductType().equalsIgnoreCase("A8") || acc.getProductType().equalsIgnoreCase("A9"))
          		&& acc.getAccessLevel().intValue() >= accessLevel.intValue()) 
          {
                  tradeAccountList.add(acc);
          }*/
          
          }
      
      	returnAccountMap.put("Savings", savingsAccountList);
      	returnAccountMap.put("Current", currentAccountList);
      	returnAccountMap.put("CashCredit", cashcreditAccountList);
      	//returnAccountMap.put("TimeDeposit", timedepositAccountList);
      	//returnAccountMap.put("OtherLoans", otherloansAccountList);
      	//returnAccountMap.put("Trade", tradeAccountList);
      //	returnAccountMap.put("TimeStampFlag", timestampFlag);
      
      if (returnAccountMap.size() > 0) {
          
              logger.info("returnAccountMap :" + returnAccountMap);
         
          return returnAccountMap;
      }
      else
          return null;
  }

    public List findAccounts(String username, String[] productType, Integer accessLevel) throws DAOException {
        logger.info("findAccounts(String username, String[] productType, Integer accessLevel)"
                + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("username :" + username + " productType :" + productType + " accessLevel :" + accessLevel);
        }
        for (int i = 0; i < productType.length; i++) {

            if (logger.isDebugEnabled()) {
                logger.debug("username is :" + username + "and AccessLevel is :" + productType[i]
                        + "and productType is :" + accessLevel);
            }
            if (username == null || productType[i] == null || accessLevel == null
                    || (username.trim()).equals(DAOConstants.EMPTY)
                    || (productType[i].trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
        }
        List returnAccountList = new ArrayList();
        List accountList = fetchAccounts(username);
        if (accountList.size() == 0)
            return null;

        /* Filtering Accounts on the Basis of accessLevel and productType */

        for (int i = 0; i < accountList.size(); i++) {
            Account acc = (Account) accountList.get(i);
            logger.info("acc :::::"+acc);
            for (int j = 0; j < productType.length; j++) {
            	logger.info("productType[j]:::::"+productType[j]);
            	logger.info("acc.getProductType():::::"+acc.getProductType());
                if (acc.getProductType().equalsIgnoreCase(productType[j])
                        && acc.getAccessLevel().intValue() >= accessLevel.intValue()) {
                    returnAccountList.add(acc);
                }
            }
        }
        if (returnAccountList.size() > 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("returnAccountList :" + returnAccountList);
            }
            return returnAccountList;
        }
        else
            return null;
    }
    ////Access level check for corpuser for ipo
    public List findAccounts(String username, String[] productType, Integer[] accessLevel) throws DAOException {
        logger.info("findAccounts(String username, String[] productType, Integer accessLevel)"
                + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("username :" + username + " productType :" + productType + " accessLevel :" + accessLevel);
        }
        for (int i = 0; i < productType.length; i++) {

            if (logger.isDebugEnabled()) {
                logger.debug("username is :" + username + "and AccessLevel is :" + productType[i]
                        + "and productType is :" + accessLevel);
            }
            if (username == null || productType[i] == null || accessLevel == null
                    || (username.trim()).equals(DAOConstants.EMPTY)
                    || (productType[i].trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
        }
        List returnAccountList = new ArrayList();
        List accountList = fetchAccounts(username);
        if (accountList.size() == 0)
            return null;

        /* Filtering Accounts on the Basis of accessLevel and productType */

        for (int i = 0; i < accountList.size(); i++) {
            Account acc = (Account) accountList.get(i);
            logger.info("acc :::::"+acc);
            for (int j = 0; j < productType.length; j++) {
            	logger.info("productType[j]:::::"+productType[j]);
            	logger.info("acc.getProductType():::::"+acc.getProductType());
                if (acc.getProductType().equalsIgnoreCase(productType[j])
                        && acc.getAccessLevel().intValue() >= accessLevel[j].intValue()) {
                    returnAccountList.add(acc);
                }
            }
        }
        if (returnAccountList.size() > 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("returnAccountList :" + returnAccountList);
            }
            return returnAccountList;
        }
        else
            return null;
    }
    
   // Auth Changes BEgins
    
    public List findAccountsApprover(String username, String[] productType, Integer accessLevel) throws DAOException {
        logger.info("findAccountsApprover(String username, String[] productType, Integer accessLevel)"
                + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("username :" + username + " productType :" + productType + " accessLevel :" + accessLevel);
        }
        for (int i = 0; i < productType.length; i++) {

            if (logger.isDebugEnabled()) {
                logger.info("username is :" + username + "and AccessLevel is :" + productType[i]
                        + "and productType is :" + accessLevel);
            }
            logger.info("username1 is :" + username + "and AccessLevel is :" + productType[i]
                                                                                          + "and productType is :" + accessLevel);
            if (username == null || productType[i] == null || accessLevel == null
                    || (username.trim()).equals(DAOConstants.EMPTY)
                    || (productType[i].trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
        }
        List returnAccountList = new ArrayList();
        List accountList = fetchAccountsApprover(username);
       
        if (accountList.size() == 0)
            return null;

        /* Filtering Accounts on the Basis of accessLevel and productType */

        for (int i = 0; i < accountList.size(); i++) {
            Account acc = (Account) accountList.get(i);
         
            for (int j = 0; j < productType.length; j++) {
               if (acc.getProductType().equalsIgnoreCase(productType[j])) {
                    returnAccountList.add(acc);
                }
            }
        }
        if (returnAccountList.size() > 0) {
            if (logger.isDebugEnabled()) {
                logger.debug("returnAccountList :" + returnAccountList);
            }
            return returnAccountList;
        }
        else
            return null;
    }



private List fetchAccountsApprover(String username) throws DAOException {

        logger.info("fetchAccounts(String username)" + LoggingConstants.METHODBEGIN);
        logger.info("username :" + username);
        Object obj = userSessionCache.getData(username + DAOConstants.USER_ACCOUNTS);
        if (logger.isDebugEnabled()) {
            logger.debug("Acounts for " + username + " : " +obj);
        }
        List accList = new ArrayList();        
        if (obj != null) {
            accList = (List) obj;
            if (logger.isDebugEnabled()) {
                logger.debug("List of Acounts for " + username + " : " + accList.size());
            }
            logger.info("accList"+accList.size());
            logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
            return accList;
        }
        else {
            try {
                if (logger.isDebugEnabled()) {
                    logger.debug("Fetch account from DB");
                }

               Object[] params={username};
			//   accList = getJdbcTemplate().query();
			   accList = getJdbcTemplate().query(VIEWINBOX_APPROVER_ACC,params,new ApproverAccountRowMapper());
			   

                logger.info("accList ...."+accList);
                userSessionCache.setData(username + DAOConstants.USER_ACCOUNTS, accList);

                if (logger.isDebugEnabled()) {
                    logger.debug("Fetch from DB");
                }

                if (accList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("accList :" + accList);
                    }
                    logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
                    return accList;
                }
                else
                    return accList;
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

            }
        }
        return null;

    }

    /**
     * ->Get the Account Object from UserSessionCache according to the key
     * ->if(Account not avilable) { Call GETCUSTOMERALLBALANCES_NEW procedure
     * and convert the result into List Store it into the UserSessionCache with
     * reference of username key } return the List [Account accounts]
     * 
     * @param username
     * @return List [Account accounts]
     * @throws DAOException
     */
    private List fetchAccounts(String username) throws DAOException {

        logger.info("fetchAccounts(String username)" + LoggingConstants.METHODBEGIN);
        logger.info("username :" + username);
        Object obj = userSessionCache.getData(username + DAOConstants.USER_ACCOUNTS);
        if (logger.isDebugEnabled()) {
            logger.debug("Acounts for " + username + " : " +obj);
        }
        List accList = new ArrayList();        
        if (obj != null) {
            accList = (List) obj;
            if (logger.isDebugEnabled()) {
                logger.debug("List of Acounts for " + username + " : " + accList.size());
            }
            logger.info("accList"+accList.size());
            logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
            return accList;
        }
        else {
            try {
                if (logger.isDebugEnabled()) {
                    logger.debug("Fetch account from DB");
                }

                Map inParams = new HashMap();
                inParams.put(DAOConstants.USERNAME, new String(username));

                List parameterList = new ArrayList();
                parameterList
                        .add(new SqlOutParameter(DAOConstants.OUTDATA, OracleTypes.CURSOR, new AccountRowMapper()));
                parameterList.add(new SqlParameter(DAOConstants.USERNAME, Types.VARCHAR));

                CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(
                        SQLConstants.GET_CUSTOMER_BALANCES_PROC, parameterList);
                CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);
                Map result = getJdbcTemplate().call(callableStatement, parameterList);

                accList = (List) result.get(DAOConstants.OUTDATA);
                logger.info("accList ... from procedure"+accList);
                userSessionCache.setData(username + DAOConstants.USER_ACCOUNTS, accList);

                if (logger.isDebugEnabled()) {
                    logger.debug("Fetch from DB");
                }

                if (accList.size() > 0) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("accList :" + accList);
                    }
                    logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
                    return accList;
                }
                else
                    return accList;
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

            }
        }
        return null;

    }

    /**
     * Get Account object and check the productType According to the productType
     * set the transaction ID Form a Map that contains input parameter for
     * coreClient Call coreDAOImpl.getDataFromBankSystem(Map) return the Map
     * that contains result from coreClient
     * 
     * Changed from private to public for Dmat..
     * 
     * @param accounts
     *            [Account]
     * @return coreDataHash [HashMap]
     * @throws DAOException
     */
    
    public HashMap getCoreBalance(Account accounts) throws DAOException {

        logger.info("getCoreBalance(Account accounts)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("accounts :" + accounts);
        }
        String txnno = DAOConstants.EMPTY;
        if (accounts.getProductType().equalsIgnoreCase(DAOConstants.LOANACCOUNT))
            txnno = DAOConstants.SHORT_ENQ_LOANS_TXNNO;
        else
            txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;

        Map requestParam = new HashMap();
        requestParam.put(DAOConstants.TXNNO, txnno);
        requestParam.put(DAOConstants.ACCNO, (String) accounts.getAccountNo());
        requestParam.put("bankCode",accounts.getBranchCode().substring(0,1));
        List responseList = coreDAOImpl.getDataFromBankSystem(requestParam);
        HashMap coreDataHash = (HashMap) responseList.get(DAOConstants.ZERO_INT);
        if (logger.isDebugEnabled()) {
            logger.debug("coreDataHash :" + coreDataHash);
        }
        return coreDataHash;

    }

    /**
     * Get switchResponse and return the response data
     * 
     * @param account
     * @return switchData [HashMap]
     * @throws DAOException
     */
    private HashMap getSwitchBalance(Account account) throws DAOException {
        logger.info("getSwitchBalance(Account account)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled()) {
            logger.debug("account :" + account);
        }
        HashMap switchData = new HashMap();
        switchData.put(DAOConstants.BALANCE, "4500.25");// hard coded for
        // checking
        logger.info("getSwitchBalance(Account account)" + LoggingConstants.METHODEND);
        return switchData;
    }

    public Account deleteAccount(Account userAccount) throws DAOException {
        logger.info("deleteAccount(Account userAccount)Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            try {
                String accountNo = userAccount.getAccountNo();
                String accountNature = userAccount.getAccountNature();
                String userName = userAccount.getUserName();
                String branchCode = userAccount.getBranchCode();
                String branchName = branchUtils.getBranchName(branchCode);
                userAccount.setBranchName(branchName);
                // in table accountNature is of type NUMBER
                Integer newAccountNature = new Integer(Integer.parseInt(accountNature));
                Object[] params =
                { userName, accountNo, newAccountNature, branchCode };

                int noOfRowDeleted = getJdbcTemplate()
                        .update(SQLConstants.DELETE_FROM_SBI_CUSTOMER_ACCOUNT_MAP, params);

                if (noOfRowDeleted == 0) {
                    DAOException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);

                }
                else {
                    insertProfileAccountLog(userAccount, "Delete", "");
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("Query Executed Successfully for Deletion");
                    logger.debug("Value Returned by the Query " + noOfRowDeleted);
                }

            }
            catch (DataAccessException daoException) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, daoException);

            }

        }

        logger.info("deleteAccount(Account userAccount)Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    }

    /**
     * This methods updates the accountNickname of the account provided in the
     * input in SBI_CUSTOMER_ACCOUNT_MAP table.
     * 
     * @param userAccount
     * @return Account
     */
    public List updateNickName(List userAccountList) throws DAOException

    {

        logger.info("updateNickName( List userAccountList )Method Begin ");
        if (logger.isDebugEnabled())
            logger.debug("userAccountList :" + userAccountList);

        List accountsList = new ArrayList();
        if (userAccountList == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            for (int i = 0; i < userAccountList.size(); i++) {
                Account userAccount = (Account) userAccountList.get(i);
                String nickName = userAccount.getAccountNickName();
                String userName = userAccount.getUserName();
                String accountNo = userAccount.getAccountNo();
                String branchCode = userAccount.getBranchCode();
                Object[] param =
                { nickName, userName, branchCode, accountNo };

                for (int j = 0; j < param.length; j++) {
                    logger.info("Parameters for Query is :" + param[j]);
                }

                int sqlType[] =
                { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

                int noOfRowsUpdated = getJdbcTemplate().update(SQLConstants.UPDATE_NICKNAME, param, sqlType);

                if (noOfRowsUpdated <= 0) {
                    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                }
                else {
                    userSessionCache.removeData(userName + DAOConstants.USER_ACCOUNTS);
                    accountsList = fetchAccounts(userName);
                }
            }
        }
        if (logger.isDebugEnabled())
            logger.debug("Values in List Object is " + userAccountList);
        logger.info("updateNickName( List userAccountList )Method End ");

        return userAccountList;
    }

    /**
     * This methods updates the thirdpartyName and Transaction Limit of the
     * account provided in the input in SBI_CUSTOMER_ACCOUNT_MAP table.
     * 
     * @param userAccount
     * @return Account
     */
    public Account updateThirdParty(Account userAccount) throws DAOException

    {

        logger.info("updateThirdParty( Account userAccount )Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            String oldValues = "";
            String thirdPartyName = userAccount.getAccountNickName();
            Double balance = (Double) userAccount.getBalance();
            String userName = userAccount.getUserName();
            String accountNo = userAccount.getAccountNo();
            String branchCode = userAccount.getBranchCode();
            userAccount.setBranchName(branchUtils.getBranchName(branchCode));
            Object[] params = new Object[]
            { userName, branchCode, accountNo };
            Map result = getJdbcTemplate().queryForMap(SQLConstants.FIND_EDIT_THIRDPARTY_OLD_DETAILS, params);
            if (result != null) {
                if (logger.isDebugEnabled())
                    logger.debug("Values in Map " + result);
                String oldThirdPartyName = (String) result.get("NAME_THIRD_PARTY");
                String transactionLimit = (String) result.get("TRANSACTION_LIMIT").toString();
                oldValues = oldValues.concat(oldThirdPartyName);
                oldValues = oldValues.concat("|");
                oldValues = oldValues.concat(transactionLimit);
                if (logger.isDebugEnabled())
                    logger.debug("Old values = " + oldValues);
            }

            Object[] param =
            { thirdPartyName, balance, userName, branchCode, accountNo };

            for (int i = 0; i < param.length; i++) {
                if (logger.isDebugEnabled())
                    logger.debug("Parameters for Query is :" + param[i]);
            }

            int sqlType[] =
            { Types.VARCHAR, Types.DOUBLE, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

            int noOfRowsUpdated = getJdbcTemplate().update(SQLConstants.UPDATE_THIRDPARTYNAME, param, sqlType);

            logger.info("noOfRowsUpdated :" + noOfRowsUpdated);
            if (noOfRowsUpdated <= 0) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
            else {
                logger.info("calling insertProfileAccountLog");
                insertProfileAccountLog(userAccount, "Edit", oldValues);
            }
        }

        logger.info("updateThirdParty( Account userAccount ) Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    }

    /**
     * This method adds the account list provided as input in
     * SBI_CUSTOMER_ACCOUNT_MAP. Values for the accounts to be added will be
     * specified in the Account object.
     * 
     * @param Account
     *            userAccount
     * @return Account
     */

    public Account insertAccount(Account userAccount) throws DAOException

    {

        logger.info("insertAccount(Account userAccount)Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {

            // Calling private method to generate parameters for query
            Object[] inParameter = generateParams(userAccount);
            int sqlTypes[] =
            { Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                    Types.DOUBLE, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.VARCHAR,Types.VARCHAR,Types.VARCHAR };

            for (int i = 0; i < inParameter.length; i++) {
                if (logger.isDebugEnabled())
                    logger.debug("Parameters for Query is  " + inParameter[i]);
                logger.info("Parameters for Query is  " + inParameter[i]);
            }

            getJdbcTemplate().update(SQLConstants.INSERT_INTO_SBI_CUSTOMER_ACCOUNT_MAP, inParameter, sqlTypes);

            logger.info("Query Executed Successfully for Insertion");
        }
        logger.info("insertAccount(Account userAccount)Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    }

    private Object[] generateParams(Account userAccount)

    {

        logger.info("generateParams(Account userAccount) method Begin ");
        if (logger.isDebugEnabled())
            logger.debug("Account Object is  :" + userAccount);

        String userName = userAccount.getUserName();
        String accountNo = userAccount.getAccountNo();
        String branchCode = userAccount.getBranchCode();

        String branchName = branchUtils.getBranchName(branchCode); // userAccount.getBranchName();
        userAccount.setBranchName(branchName);
        Double balance = userAccount.getBalance();
        String accountNature = userAccount.getAccountNature();
        if (logger.isDebugEnabled())
            logger.debug("branchName :" + branchName);
        Integer newAccountNature = new Integer(Integer.parseInt(accountNature));
        Integer accessLevel = userAccount.getAccessLevel();
        String nameThirdParty = userAccount.getAccountNickName();
        String productCode=userAccount.getProductCode();
        String productDescription=userAccount.getProductDescription();

        if (logger.isDebugEnabled())
            logger.debug("name ThirdParty :" + nameThirdParty);
        Object[] params =
        { userName, new Integer(101), new Integer(1), new Integer(0), accountNo, branchCode, userName, balance,
                nameThirdParty, newAccountNature, accessLevel, new Integer(0), branchName,productCode,productDescription };

        if (logger.isDebugEnabled())
            logger.debug("Parameters for Query" + params);
        logger.info("generateParams(Account userAccount) method End ");

        return params;
    }

    /**
     * AccountRowMapper for processing the row
     */
    class AccountRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            Account acc = new Account();
            acc.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
            acc.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            acc.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));
            // Double value =
            // StringUtils.emptyCheck(rs.getDouble(DAOConstants.CLEAR_BALANCE));
            acc.setBalance(new Double(rs.getDouble(DAOConstants.CLEAR_BALANCE)));
            acc.setCurrency(rs.getString(DAOConstants.CURRENCY));
            if (rs.getString(DAOConstants.ACCOUNT_NICKNAME) != null
                    && !((rs.getString(DAOConstants.ACCOUNT_NICKNAME)).trim()).equals(""))
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NICKNAME));
            else
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NO));
            if (logger.isDebugEnabled())
                logger.debug("ACCOUNT_NICKNAME " + rs.getString(DAOConstants.ACCOUNT_NICKNAME));
            acc.setAccessLevel(new Integer(rs.getString(DAOConstants.ACCESS_LEVEL)));

            acc.setProductType(rs.getString(DAOConstants.ACCOUNT_TYPE));

            if (rs.getInt(DAOConstants.CORE_FLAG) == 0) {
                acc.setBankSystem(DAOConstants.CORE);
                String creditable = getCreditable(rs.getString("PRODUCT_CODE"));
                if (creditable != null && creditable.equalsIgnoreCase("Y"))
                    acc.setCreditable(new Boolean(true));
                else
                    acc.setCreditable(new Boolean(false));
            }
            else
                acc.setBankSystem(DAOConstants.BANK_MASTER);

            acc.setAccountNature(DAOConstants.ZERO);// 0 -> own accounts
            acc.setProductDescription(rs.getString(DAOConstants.PRODUCT_DESC));
            /*Product Code Added for CR-2734*/
            acc.setProductCode(rs.getString(DAOConstants.PRODUCT_CODE));
            acc.setCoreMigrationDisplay(rs.getString("CORE_MESSAGE_STATUS"));
            acc.setAccountLockFlag(new Integer (rs.getInt("LOCK_FLAG")));
            acc.setLimit( new Double (rs.getDouble("limit")));
            acc.setRtgsIFSCCode(rs.getString("RTGS_IFSC_CODE"));
            acc.setNeftIFSCCode(rs.getString("NEFT_IFSC_CODE"));
            acc.setBrokerStmtFlag(rs.getString("BROKER_STMT_FLAG")); //IR71227
           // acc.setCoreMigrationDisplay("Display");
            if (logger.isDebugEnabled())
                logger.debug("AccountRowMapper.mapRow method end and it return account:" + acc.toString());
            return acc;
        } 
    }
    
    // Auth Changes
    
    class ApproverAccountRowMapper implements RowMapper {
  //a.OID, a.account_no,product_desc, a.product_type, b.branch_name,a.account_nickname,a.branch_code,A.CREATION_TIME
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            Account acc = new Account();
            acc.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
            acc.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            acc.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));
           
            if (rs.getString(DAOConstants.ACCOUNT_NICKNAME) != null
                    && !((rs.getString(DAOConstants.ACCOUNT_NICKNAME)).trim()).equals(""))
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NICKNAME));
            else
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NO));
            if (logger.isDebugEnabled())
                logger.debug("ACCOUNT_NICKNAME " + rs.getString(DAOConstants.ACCOUNT_NICKNAME));
             acc.setProductType(rs.getString(DAOConstants.ACCOUNT_TYPE));

            acc.setBankSystem(DAOConstants.BANK_MASTER);

            acc.setAccountNature(DAOConstants.ZERO);
            acc.setProductDescription(rs.getString(DAOConstants.PRODUCT_DESC));
            acc.setProductCode(rs.getString(DAOConstants.PRODUCT_CODE));
            acc.setLimit( new Double (rs.getDouble("limit")));

            if (logger.isDebugEnabled())
                logger.debug("AccountRowMapper.mapRow method end and it return account:" + acc.toString());
            return acc;
        } 
    }

    /**
     * This methods returns the value of creditable in SBI_PRODUCT_DESC table
     * for the product code provided
     * 
     * @param productcode
     */
    public String getCreditable(String productcode) throws DAOException {
        String creditable = "";
        logger.info("getCreditable " + LoggingConstants.METHODBEGIN);
        logger.info("productcode :" + productcode);
        if (productcode != null) {
            if (logger.isDebugEnabled())
                logger.debug("getCreditable : retreiving the creditable value from SBI_PRODUCT_DESC");
            Object[] params = new Object[]
            { productcode };

            try {
                creditable = (String) getJdbcTemplate().query(SQLConstants.CREDITABLE_RETRIEVE, params,
                        new CreditableExtractor());
            }
            catch (DataAccessException excep) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, excep);
            }
            logger.info("getCreditable : result :" + creditable);

            // creditable = (String) result.get("CREDITABLE");

            if (creditable == null)
                creditable = "";
            return creditable;

        }
        /*
         * else { logger.error("getCreditable : Product code is null");
         * DAOException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE); }
         */
        return null;
    }

    public boolean insertProfileAccountLog(Account account, String actionFlag, String oldValues) {

        logger.info("insertProfileAccountLog(Account account, String actionFlag, String oldValues) "
                + LoggingConstants.METHODBEGIN);

        logger.info("account :" + account);
        logger.info("actionFlag :" + actionFlag);
        logger.info("oldValues :" + oldValues);

        try {
            String action = "";
            String newValues = "";

            UserProfile userProfile = userDAOImpl.findUserProfile(account.getUserName());

            int sqlTypes[] =
            { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
            if (account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString())) {
                if (actionFlag.equalsIgnoreCase("Edit")) {
                    action = "Edit Third Party";
                    newValues = account.getAccountNo() + "|" + account.getBranchCode() + "|"
                            + account.getAccountNickName() + "|" + account.getBalance();
                }
                else if  (actionFlag.equalsIgnoreCase("Add")) {
                    action = "Add Third Party";
                    newValues = account.getAccountNo() + "|" + account.getBranchCode() + "|"
                            + account.getAccountNickName() + "|" + account.getBalance();
                }

                else {
                    action = "Delete Third Party";
                    newValues = account.getAccountNo() + "|" + account.getBranchCode() + "|"
                            + account.getAccountNickName();
                }
            }
            else {
                action = "Delete PPF";
                newValues = account.getAccountNo() + "|" + account.getBranchCode();
            }

            logger.info("**************UserName:" + account.getUserName());
            logger.info("getUserIPaddress:" + userProfile.getUserIPaddress());
            logger.info("action Name:" + action);
            logger.info("oldValues:" + oldValues);
            logger.info("New values: ************** " + newValues);

            Object[] inParameter = new Object[]
            { account.getUserName(), userProfile.getUserIPaddress(), action, oldValues, newValues };

            int status = getJdbcTemplate().update(SQLConstants.PROFILE_LOG_QUERY_ACCOUNT, inParameter, sqlTypes);

            logger.info("Profile Log status for Account manipulation " + status);
        }
        catch (DataAccessException ex) {

            logger.error(LoggingConstants.EXCEPTION, ex);
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, ex);

        }
        catch (Exception ex) {

            logger.error(LoggingConstants.EXCEPTION, ex);
            ex.printStackTrace();
            
        }
        return true;
    }

    /** ** Customer Care *** */

    public List findNonVerfiedAccounts(String userName) throws DAOException {
        logger.info("findNonVerfiedAccounts(String userName)" + LoggingConstants.METHODBEGIN);
        logger.info("userName :" + userName);
        List nonVerifiedAccoutList = null;
        Object[] object =
        { userName };

        if (userName != null && (userName.trim()).length() > 0) {
            try {

                nonVerifiedAccoutList = getJdbcTemplate().query(SQLConstants.NON_VERIFIED_ACCOUNT_BY_USER_NAME, object,
                        new NonVerifiedAccountsRowMapper());
                if (logger.isDebugEnabled())
                    logger.debug("findNonVerfiedAccounts(String userName) outParam :" + nonVerifiedAccoutList);
            }
            catch (DataAccessException dataAccessException) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, dataAccessException);
            }

        }
        logger.info("findNonVerfiedAccounts(String userName)" + LoggingConstants.METHODEND);
        return nonVerifiedAccoutList;
    }

    class NonVerifiedAccountsRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int count) throws SQLException {
            Account account = new Account();
            account.setAccountNo(rs.getString("ACCOUNT_NO"));
            account.setBranchName(rs.getString("BRANCH_NAME"));
            account.setProductType(rs.getString("PRODUCT_TYPE"));
            account.setBranchCode(rs.getString("branch_code"));
            return account;
        }
    }

    public int findAllAccountsCount(String userName) throws DAOException {
        logger.info("findAllAccountsCount(String userName)" + LoggingConstants.METHODBEGIN);
        logger.info("userName :" + userName);
        int result = 0;
        Object[] params =
        { userName };
        try {
            result = getJdbcTemplate().queryForInt(SQLConstants.FIND_ALL_ACCOUNTS_COUNT, params);
            //logger.info("Result :" + result);
        }
        catch (DataAccessException dataAccessException) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        logger.info("findAllAccountsCount(String userName)" + LoggingConstants.METHODEND);
        return result;
    }

    public Double findMaximumTPAccountLimit(String userName) throws DAOException {

        logger.info("findMaximumTPAccountLimit(String userName)" + LoggingConstants.METHODBEGIN);
        logger.info("userName :" + userName);
        Double result = null;
        Object[] params =
        { userName };
        try {
            result = (Double) getJdbcTemplate().queryForObject(SQLConstants.FIND_MAX_TP_LIMIT, params,
                    java.lang.Double.class);

            logger.info("Result :" + result);
        }
        catch (DataAccessException dataAccessException) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        logger.info("findMaximumTPAccountLimit(String userName)" + LoggingConstants.METHODEND);
        return result;

    }

    class CreditableExtractor implements ResultSetExtractor {

        public Object extractData(ResultSet rs) throws SQLException, DataAccessException {

            String creditable = "";
            while (rs.next()) {
                creditable = rs.getString("creditable");
            }
            return creditable;
        }

    }

    /**
     * TODO Enter the description of the method here
     * 
     * @param accountsList
     * @return List
     */
    private List filterAccounts(List accountsList)

    {

        List filterAccountList = new ArrayList();
        if (accountsList != null && accountsList.size() > 0) {
            int txnAccountCount = 0;
            int loanAccountCount = 0;
            int ppfCount = 0;
            int tradeCount = 0;
            int odDepositCount = 0;
            int savingsAccountCount = 0;
            Account account = null;
 
            logger.info(" Fetching Account " + accountsList.size());
            logger.info(" Account :::: " + ((Account)accountsList.get(0)).toString());
            for (int i = 0; i < accountsList.size(); i++) {
                account = (Account) accountsList.get(i);
                logger.info("Product Type: " + account.getProductType());
                logger.info("Account number  " + account.getAccountNo());
                if (DAOConstants.TRANSACTION_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0
                        && txnAccountCount < 4) {
                    txnAccountCount++;
                    logger.info("Accout added as Transaction account ::" + account.getAccountNo());
                    filterAccountList.add(account);
                }
 
                else if (DAOConstants.DEPOSIT_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0
                        && odDepositCount < 4) {
                    filterAccountList.add(account);
                    odDepositCount++;
                }
                else if (DAOConstants.PPF_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0 && ppfCount < 4) {
                    filterAccountList.add(account);
                    ppfCount++;
                }

                else if (DAOConstants.TRADE_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0 && tradeCount < 4) {
                    filterAccountList.add(account);
                    tradeCount++;
                }
                else if (DAOConstants.SAVINGS_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0
                        && savingsAccountCount< 4) {
                    filterAccountList.add(account);
                    savingsAccountCount++;
                }
                else if (DAOConstants.LOAN_PRODUCT_TYPES.indexOf(account.getProductType().trim()) >= 0 && loanAccountCount < 4) {
                    filterAccountList.add(account);
                    loanAccountCount++;
                }
               logger.info("Account List during filtering the Accounts:  " + filterAccountList.size());
            }

        }

        return filterAccountList;

    }

    
    /**
     * Execute query on SBI_CUSTOMER_ACCOUNT_MAP table to fetch accounts
     * matching the accountNature Convert query output to accounts object List
     * and return List
     * 
     * @param userName
     * @param accountnature
     * @return accList [List]
     */

    public Account findAccountByNature(String userName, String accountNo, String branchCode, Integer accountnature) {
        logger.info("findAccountByNature(String userName, String accountNo, String branchCode, Integer accountnature)" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + userName + " accountnature :" + accountnature);
        logger.info("accountNo :" + accountNo + " branchCode :" + branchCode);

        if (userName == null || accountnature == null || (userName.trim()).equals(DAOConstants.EMPTY) || accountNo == null) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            try {

                Object[] parameters = new Object[]
                { accountnature, accountNo, branchCode, userName };
                int[]  types = {Types.NUMERIC,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                List accList = getJdbcTemplate().query(SQLConstants.ACCOUNT_BY_NATURE_QUERY, parameters,types,
                        new AccountRowMapper());

                if (accList.size() > 0) {                    
                        Account acc = (Account) accList.get(0);                    
                    if (logger.isDebugEnabled()) {
                        logger.debug("acc :" + acc);
                    }
                    logger.info("findAccountsByNature(String userName, Integer accountnature)"
                            + LoggingConstants.METHODEND);
                    return acc;
                }
                else {
                    logger.info("findAccountsByNature(String userName, Integer accountnature)"
                            + LoggingConstants.METHODEND);
                    return null;
                }
            }
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

            }

        }
        return null;

    }
    
//  Added for CR 295 - Start
    class AccountRowMapperForBM implements RowMapper {
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            Account acc = new Account();
            logger.info("in RowMapper");
            acc.setUserName(rs.getString("user_name"));
            acc.setAccountNo(rs.getString("bm_account_no"));
            acc.setBranchCode(rs.getString("bm_branch_code"));
            acc.setBankSystem(DAOConstants.BANK_MASTER);
            acc.setProductType(rs.getString("product_type"));
            acc.setBalance(new Double(rs.getDouble(DAOConstants.CLEAR_BALANCE)));
            acc.setBranchName(rs.getString("branch_name"));
            acc.setProductDescription(rs.getString("account_description"));
            acc.setAccountNature(DAOConstants.CORE_BM_ACCOUNT_NATURE);
            logger.info("username is " + acc.getUserName());
                       
               if (logger.isDebugEnabled())
                logger.debug("AccountRowMapperForBM.mapRow method end and it return account:" + acc.toString());
            return acc;
        }
    }
    
    public List getBMAccounts(String accountNo, String branchCode, Timestamp fromDate, String username) throws DAOException
    {
    	
    	logger.info("getBMAccounts(String accountNo, String branchCode, Timestamp fromDate)" + LoggingConstants.METHODBEGIN);

        logger.info("accountNo :" + accountNo + " branchCode :" + branchCode);
        logger.info("from date=="+fromDate);
        
        if (accountNo == null || branchCode == null || (accountNo.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {

             try {

                Object[] parameters = new Object[]
                {accountNo, branchCode, username, fromDate};
                
                List accList = (List) getJdbcTemplate().query(SQLConstants.GET_BM_ACCOUNTS, parameters,
                        new AccountRowMapperForBM());
                
                    if (logger.isDebugEnabled()) 
                        logger.debug("accList :" + accList);
                    if(accList != null)
                    {
                    	if(accList.size() > 0)
                    	{
                    		List useraccounts = (List) userSessionCache.getData(username + DAOConstants.USER_ACCOUNTS);
                    		Account bmaccount = (Account) accList.get(0);
                    		String bmaccountnumber = bmaccount.getAccountNo();
                    		String bmbranchcode = bmaccount.getBranchCode();
                    		boolean addaccount = true; 
                    		for(int acccounter=0;acccounter<useraccounts.size();acccounter++)
                    		{
                    			Account accfromlist = (Account) useraccounts.get(acccounter);
                    			if(bmaccountnumber.equalsIgnoreCase(accfromlist.getAccountNo()) && bmbranchcode.equalsIgnoreCase(accfromlist.getBranchCode()))
                    			{
                    				addaccount = false;
                    			}
                    		}
                    		if(addaccount)
                    		{
                    			useraccounts.add(bmaccount);
                    			userSessionCache.setData(username + DAOConstants.USER_ACCOUNTS,useraccounts);
                    		}
                    	}
                    }
                   logger.info("accList size is " + accList.size());
                    logger.info("getBMAccounts(String accountNo, String branchCode, Timestamp fromDate)"
                            + LoggingConstants.METHODEND);
                   return accList;
                
               }//end of try
                       
            catch (DataAccessException ex) {

                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

            }
        } 
       
        return null;

    }
    
    //Added for CR 295 - End
    

    public boolean upateCoreMessageStatus(String userName, String[] branchCodes) throws DAOException
    {
       logger.info("upateCoreMessageStatus(String userName, String branchCode)" + LoggingConstants.METHODBEGIN) ;
       logger.info("UserName " + userName + " | " + "BranchCode:" + branchCodes );
       String queryString = DAOConstants.EMPTY;
       boolean status = false;
       boolean flag = true;
       Object[] parameters = new Object[]{userName};
       for (int i = 0; i < branchCodes.length; i++) {
           logger.info(" Branch Code "+ branchCodes[i]);
            if (flag) {
                queryString = queryString + DAOConstants.EMPTY + branchCodes[i];
                flag = false;
            } else {
                queryString = queryString + DAOConstants.COMA + branchCodes[i];
            }
        }
       String finalQuery = SQLConstants.UPDATE_CORE_MESSAGE.replaceAll(
                DAOConstants.TO_BE_REPLACED, queryString);
       logger.info(" Final Query : " + finalQuery);
       
       int noOfRowsUpdated = getJdbcTemplate().update(finalQuery, parameters);

        if (noOfRowsUpdated <= 0) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else
        {  status = true;
        
        }
        logger.info("upateCoreMessageStatus(String userName, String branchCode)" + LoggingConstants.METHODEND);
        return status;
   
    } 
    
    /**
     * TODO Update the ThirdParty Name only in SBI_CUSTOMER_ACCOUNT_MAP TABLE
     * @param userAccount
     * @return
     * @throws DAOException Account
     */
    public Account updateThirdPartyName(Account userAccount) throws DAOException

    {

        logger.info("updateThirdParty( Account userAccount )Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            String oldValues = "";
            String thirdPartyName = userAccount.getAccountNickName();
            Double balance = (Double) userAccount.getBalance();
            String userName = userAccount.getUserName();
            String accountNo = userAccount.getAccountNo();
            String branchCode = userAccount.getBranchCode();
            userAccount.setBranchName(branchUtils.getBranchName(branchCode));
            Object[] params = new Object[]
            { userName, branchCode, accountNo };
            Map result = getJdbcTemplate().queryForMap(FIND_OLD_THIRDPARTY_NAME, params);
            if (result != null) {
                if (logger.isDebugEnabled())
                    logger.debug("Values in Map " + result);
                String oldThirdPartyName = (String) result.get("NAME_THIRD_PARTY");
                oldValues = oldValues.concat(oldThirdPartyName);
                     if (logger.isDebugEnabled())
                    logger.debug("Old values = " + oldValues);
            }

            Object[] param =
            { thirdPartyName, userName, branchCode, accountNo };

            for (int i = 0; i < param.length; i++) {
                if (logger.isDebugEnabled())
                    logger.debug("Parameters for Query is :" + param[i]);
            }

            int sqlType[] =
            { Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
            
            int noOfRowsUpdated = getJdbcTemplate().update(UPDATE_TP_NAME_ONLY, param, sqlType);

            logger.info("noOfRowsUpdated :" + noOfRowsUpdated);
            if (noOfRowsUpdated <= 0) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
            else {
                logger.info("calling insertProfileAccountLog");
                insertProfileAccountLog(userAccount, "Edit", oldValues);
            }
        }

        logger.info("updateThirdParty( Account userAccount ) Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    }

    
 //Added for CR 295 - End
    
    
    //Ponnusamy G   -START
    
    public class StringProductDetailsMapper implements ResultSetExtractor {

        public Object extractData(ResultSet rs) throws SQLException {
            String productCode=null;
            while(rs.next()){
             productCode = rs.getString("PRODUCT_DESC");
            }
            return productCode;
        }

    }

    
    public String getProductDetails(String productcode)throws DAOException
    {
        logger.info("getProductDetails(String productcode) - start");
        logger.info("productcode......"+productcode);
        Object[] params = new Object[] { productcode };
        String productDetails = null;
        try {
            if(productcode!=null ){
                productDetails = (String)getJdbcTemplate().query(SQLConstants.SELECT_PRODUCT_DETAILS,
                        params, new StringProductDetailsMapper());
                logger.info("Result :" + productDetails);
                
    }
        }catch (DataAccessException e) {
        DAOException.throwException(
                ErrorConstants.FATAL_EXCEPTION_ERRORCODE,e);
     }
        if(productDetails==null){
        
            productDetails="";
            return productDetails;
        }
    logger.info("getProductDetails(String productcode) - end");
        return productDetails;  
        
    }
    
    //Ponnusamy G   -END
//  RTGS credit account validation
    public boolean isValidRTGSCreditActNumber(String username, String corpId, String accountnumber, String ifscCode,String actNickName){
        logger.info("isValidRTGSCreditAccountNumber(Transaction corpTransaction) "
                + LoggingConstants.METHODBEGIN);
        Object[] params={username,corpId,accountnumber,ifscCode,actNickName,corpId,accountnumber,ifscCode,actNickName,username,corpId,accountnumber,ifscCode,actNickName};
        boolean isValid=false;
        if(username != null && accountnumber != null){
            int count=getJdbcTemplate().queryForInt(FIND_RTGS_CREDIT_ACCOUNT,params);
            if(count > 0){
                isValid=true;
            }
        }
        logger.info("isValidRTGSCreditAccountNumber(Transaction corpTransaction) "
                + LoggingConstants.METHODEND);
        return isValid;
        
    }
    /**
     * coreDAOImpl injection
     * 
     * @param userSessionCache
     *            void
     */

    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl) {
        this.coreDAOImpl = coreDAOImpl;
    }

    /**
     * userSessionCache injection
     * 
     * @param userSessionCache
     *            void
     */

    public void setUserSessionCache(UserSessionCache userSessionCache) {
        this.userSessionCache = userSessionCache;
    }

    public void setBranchUtils(BranchUtils branchUtils) {
        this.branchUtils = branchUtils;
    }

    public void setUserDAOImpl(UserDAO userDAOImpl) {
        this.userDAOImpl = userDAOImpl;
    }
    //5202  not displaying the balance in landing page
    public List findAccountsWithoutBalance(String username, Boolean accountLimit) throws DAOException {

        logger.info("findAccountsWithOutBalance(String username, Boolean accountLimit))" + LoggingConstants.METHODBEGIN);

        logger.info("username :" + username);

        if (username != null && !(username.trim()).equals(DAOConstants.EMPTY) && accountLimit != null) {
            List accountList;
            if (!accountLimit.booleanValue()) {
              accountList = fetchAccounts(username);
            }
            else

            {
                List allAccountList = fetchAccounts(username);
                accountList = filterAccounts(allAccountList);

            }
            logger.info("After filtering accounts :::::" + accountList.size() );
            if (accountList.size() == 0)
                return null;
            logger.info("findAccountsWithOutBalance(String username, Boolean accountLimit))" + LoggingConstants.METHODEND);
            return accountList;
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }
    //5292 starts
    public Map getProductDesc(String productCode,String productCode2) throws DAOException{
		Map productDesc=null;
		logger.info("inside dao -- productCode : "+productCode+" productCode2 : "+productCode2);
		
		try
		{
			Object[] params = {productCode,productCode2};
			productDesc=getJdbcTemplate().queryForMap(GET_PRODUCT_DESCRIPTION,params);
			
		}catch (DataAccessException ex)
        {
     	   DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
     	logger.error("DataAccessException :", ex);
	     }
	     catch (Exception e)
	     {
	     	   DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, e);
	     	logger.error("Exception :", e);
	     }
		return productDesc;
	}
    //5292 ends

    // four methods added for CR-5390 Starts here
    public List findTPAccounts(String userName) throws DAOException
    {
    	List thirdPartyList=null;
    	String FETCH_TP_ACCOUNTS="select a.oid,A.ACCOUNT_NO,A.BRANCH_CODE,B.BRANCH_NAME,nvl(A.NAME_THIRD_PARTY,'') ACCOUNT_NICKNAME,B.CORE_BANKING COREFLAG,'INR' CURRENCY,'' CLEAR_BALANCE, product_type ACCOUNTTYPE ,product_desc,product_code,outref7,mobile_no,email_id, -1 limit,"+ 
    "a.approval_status,a.added_by from  sbicorp_third_party a,sbi_branch_master b WHERE a.branch_code=b.branch_code and a.account_no not like 'NONE%' AND a.status = 1 and a.added_by=?"+
    		" ORDER BY UPPER(ACCOUNT_NICKNAME) ASC";
    	if(userName!=null)
    	{
    		Object tpParams[]={userName};
    		
    		thirdPartyList=getJdbcTemplate().query(FETCH_TP_ACCOUNTS, tpParams,new TPRowmapper());
    		
    		
    	}
    	 else {
             DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
    	
    	return thirdPartyList;
    }
    
    
  
    public Account updateTPName(Account userAccount) throws DAOException
    {


        logger.info("updateTPName( Account userAccount )Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            String oldValues = "";
            String thirdPartyName = userAccount.getAccountNickName();
            Double balance = (Double) userAccount.getBalance();
            String userName = userAccount.getUserName();
            String accountNo = userAccount.getAccountNo();
            String branchCode = userAccount.getBranchCode();
            
            //--5603
            String employeeCode = userAccount.getEmployeeCode();
            String mobileNo = userAccount.getMobileNo();
            String emailId = userAccount.getEmailId();

            if(mobileNo != null && mobileNo.length() > 0){
            	mobileNo = "91" + mobileNo;
            }
            //--end of 5603
            
            
            userAccount.setBranchName(branchUtils.getBranchName(branchCode));
            Object[] params = new Object[]
            { userName, branchCode, accountNo };
            Map result = getJdbcTemplate().queryForMap(FIND_OLD_TP_NAME, params);
            if (result != null) {
                if (logger.isDebugEnabled())
                    logger.debug("Values in Map " + result);
                String oldThirdPartyName = (String) result.get("NAME_THIRD_PARTY");                
                
                oldValues = oldValues.concat(oldThirdPartyName);
                     if (logger.isDebugEnabled())
                    logger.debug("Old values = " + oldValues);
            }

            Object[] param =
            { thirdPartyName, employeeCode, mobileNo, emailId, userName, branchCode, accountNo};
            //Added by Immanuel #CR5550 - Duplicate nick name check
            Object[] inparams = {userName, thirdPartyName.toLowerCase()};
            Integer duplicateNick = getJdbcTemplate().queryForInt("select count(*) from sbicorp_third_party where user_name=? and lower(name_third_party)=?  and (approval_status not in('Rejected') or  approval_status is null)",inparams);
            int noOfRowsUpdated = 0;
            //End #CR5550
            for (int i = 0; i < param.length; i++) {
                if (logger.isDebugEnabled())
                    logger.debug("Parameters for Query is :" + param[i]);
            }

            int sqlType[] =
            { Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };//--modified for 5603
            //Added by Immanuel #CR5550 - Duplicate nick name check
        	if(duplicateNick == 0) {
            noOfRowsUpdated = getJdbcTemplate().update(UPDATE_TP_NAME, param, sqlType);
        	} else {
       		 DAOException.throwException(ErrorConstants.NICK_NAME);
        	}
        	 //End #CR5550
            logger.info("noOfRowsUpdated :" + noOfRowsUpdated);
            if (noOfRowsUpdated <= 0) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

            }
            else {
                logger.info("calling insertProfileAccountLog");
                insertProfileAccountLog(userAccount, "Edit", oldValues);
            }
        }

        logger.info("updateTPName( Account userAccount ) Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    
    }
    
    public Account deleteTPAccount(Account userAccount) throws DAOException
    {

        logger.info("deleteAccount(Account userAccount)Method Begin ");

        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {

            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            try {
                String accountNo = userAccount.getAccountNo();
                String accountNature = userAccount.getAccountNature();
                String userName = userAccount.getUserName();
                String branchCode = userAccount.getBranchCode();
                String branchName = branchUtils.getBranchName(branchCode);
                userAccount.setBranchName(branchName);
                Object[] params =
                { userName, accountNo, branchCode };

                int noOfRowDeleted = getJdbcTemplate()
                        .update(DELETE_FROM_SBICORP_THIRD_PARTY, params);

                if (noOfRowDeleted == 0) {
                    DAOException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);

                }
                else {
                    insertProfileAccountLog(userAccount, "Delete", "");
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("Query Executed Successfully for Deletion");
                    logger.debug("Value Returned by the Query " + noOfRowDeleted);
                }

            }
            catch (DataAccessException daoException) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, daoException);

            }

        }

        logger.info("deleteAccount(Account userAccount)Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    
    }
    
    
    
    class TPRowmapper implements RowMapper
    {
    	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
            Account acc = new Account();
            acc.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
            acc.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
            acc.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));
            if (rs.getString(DAOConstants.ACCOUNT_NICKNAME) != null
                    && !((rs.getString(DAOConstants.ACCOUNT_NICKNAME)).trim()).equals(""))
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NICKNAME));
            else
                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NO));
            if (logger.isDebugEnabled())
                logger.debug("ACCOUNT_NICKNAME " + rs.getString(DAOConstants.ACCOUNT_NICKNAME));
            acc.setProductType(rs.getString(DAOConstants.ACCOUNT_TYPE));

            if (rs.getInt(DAOConstants.CORE_FLAG) == 0) {
                acc.setBankSystem(DAOConstants.CORE);
                String creditable = getCreditable(rs.getString("PRODUCT_CODE"));
                if (creditable != null && creditable.equalsIgnoreCase("Y"))
                    acc.setCreditable(new Boolean(true));
                else
                    acc.setCreditable(new Boolean(false));
            }
            else
                acc.setBankSystem(DAOConstants.BANK_MASTER);

            acc.setAccountNature(DAOConstants.ONE);// 1 -> TP accounts
            acc.setProductDescription(rs.getString(DAOConstants.PRODUCT_DESC));
            acc.setProductCode(rs.getString(DAOConstants.PRODUCT_CODE));
            acc.setCoreMigrationDisplay(rs.getString("approval_status")); //Setting the approval status in this unused object for CR-5390
            acc.setEmployeeCode(rs.getString(DAOConstants.EMPLOYEE_CODE));
            acc.setMobileNo(rs.getString(DAOConstants.MOBILE_NO));
            acc.setEmailId(rs.getString(DAOConstants.EMAIL_ID));
            acc.setUserAlias(rs.getString("added_by"));
            acc.setRefNo(rs.getString("oid"));
            if (logger.isDebugEnabled())
                logger.debug("TPRowmapper.mapRow method end and it return account:" + acc.toString());
            return acc;
        }
    	
    }
    
    //CR-5390 Ends here
    //Added by Indu for CR 5507
    
    
	public List findAccountsWithBalance(String userName) throws DAOException{
    	if (userName == null || (userName.trim()).equals(DAOConstants.EMPTY)){               
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else {
            List returnList = new ArrayList();
            List accList = (List) fetchAccounts(userName);
            if (accList.size() == 0)
                return null;
            for (int i = 0; i < accList.size(); i++) {
                Account acc = (Account) accList.get(i);
                if (acc.getBankSystem().equals(DAOConstants.CORE)) {
                        HashMap coreData = getCoreBalanceInterestRate(acc);
                        if (logger.isDebugEnabled()) {
                            logger.debug("coreData :" + coreData);
                        }                        
                        String status = null;
                        String errorCode = null;

                        if (coreData.get("status") != null)
                            status = (String) coreData.get("status");
                        if (coreData.get("error_code") != null) {
                            errorCode = (String) coreData.get("error_code");
                            status = errorCode;
                        }
                        if (status == null && errorCode == null) {
                            if (acc.getProductType().equalsIgnoreCase("A5")){
                            	// MOD Balance For A5 Product Type in Account Summary Page.
                                  if(acc.getProductDescription() != null && acc.getProductDescription().length() > 1 && (!acc.getProductDescription().substring(0, 2).equalsIgnoreCase("RD"))){
                                	  acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                        .get(DAOConstants.TERM_VALUE)));
                                  }else{
                                  acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                          .get(DAOConstants.BOOK_BALANCE)));
                                  }
                                acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.INTEREST_RATE)));                                
                            	acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE)); 
                            	                         	
                            }
                            else if(acc.getProductType().equalsIgnoreCase("A6")){
                                acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                        .get(DAOConstants.AMOUNTOUTSTANDING)));
                                acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.INTERESTRATE)));
                            	acc.setCurrency((String) coreData.get(DAOConstants.CURRENCYCODE));
                            }
                            else{
                            	acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                        .get(DAOConstants.BOOK_BALANCE)));
                            	acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.INTEREST_RATE)));
                            	acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE)); 
                            }                                                       
                        }
                        else {
                            acc.setBalance(new Double(0));
                            acc.setCurrency("NA");
                        }
                    }
                    returnList.add(acc);                    
                }
            if (returnList.size() > 0) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnList :" + returnList);
                }
                
                return returnList;
            }
            else {
               return null;
            }
        }
     return null;
	}
	
	
	public List findDepositAccountsWithBalance(String username, String productType[]) throws DAOException {
    	if (username == null || productType == null || (username.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else {
            List returnList = new ArrayList();
            List accList = (List) fetchAccounts(username);
             
            if (accList.size() == 0)
                return null;
            for (int i = 0; i < accList.size(); i++) {
                Account acc = (Account) accList.get(i);
                int typelength = productType.length;
                boolean filterType = false;
                   for(int j=0;j < typelength;j++ ){
                        if(acc.getProductType().equals(productType[ j ])){
                            filterType = true;
                            break;
                        }
                      }
                if (filterType == true) {
                    logger.info("Product type:" + acc.getProductType());
                    if (acc.getBankSystem().equals(DAOConstants.CORE)) {
                        HashMap coreData = getCoreBalanceInterestRate(acc);
                        if (logger.isDebugEnabled()) {
                            logger.debug("coreData :" + coreData);
                        }
                        String status = null;
                        String errorCode = null;
                        if (coreData.get("status") != null)
                            status = (String) coreData.get("status");
                        if (coreData.get("error_code") != null) {
                            errorCode = (String) coreData.get("error_code");
                            status = errorCode;
                        }
                        if (status == null && errorCode == null) {
                        	
                        	if (acc.getProductType().equalsIgnoreCase("A5")){
                        	 if((!acc.getProductDescription().substring(0, 2).equalsIgnoreCase("RD"))){
                           	  acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                   .get(DAOConstants.TERM_VALUE)));
                             }else{
                             acc.setBalance(StringUtils.emptyStringCheckForDouble((String) coreData
                                     .get(DAOConstants.BOOK_BALANCE)));
                             }
                        	//Added for CR 5507
                        	acc.setInterestRate(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.INTEREST_RATE)));                                
                         	acc.setCurrency((String) coreData.get(DAOConstants.CURRENCY_CODE));                            	
                         	acc.setProfileUserName((String) coreData.get(DAOConstants.PROFILE_USER_NAME));                       	
                         	acc.setMaturityAmount(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.MATURITY_AMT)));
                         	acc.setMaturityDate(StringUtils.coreDateToTimestamp((String) coreData.get(DAOConstants.MATURITY_DATE)));
                         	acc.setPrincipal(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.TERM_VALUE)));
                         	acc.setAccumulatedInterest(StringUtils.emptyStringCheckForDouble((String) coreData.get(DAOConstants.ACCUMULATED_INTEREST)));
                         	acc.setOpeningDate(StringUtils.coreDateToTimestamp((String) coreData.get(DAOConstants.OPENING_DATE)));
                         	acc.setTenorDays(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_DAYS)));
                         	acc.setTenorMonth(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_MONTH)));
                         	acc.setTenorYear(emptyStringCheckForInteger((String) coreData.get(DAOConstants.TENOR_YEAR)));
                         	//Added to display the TenureDays                         	
                         	acc.setTenorINDays(emptyStringCheckForInteger((String) coreData.get("tenureInDays")));
	                                                	
                        	//End
                          	}
                        }
                        else {
                            acc.setBalance(new Double(0));
                            acc.setCurrency("NA");
                        }
                        
                    }
                    returnList.add(acc);
                }
            }
            if (returnList.size() > 0) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnList :" + returnList);
                }
                
                return returnList;
            }
            else {
               return null;
            }
        }        
        return null;
    }
	
	
	
	private Integer emptyStringCheckForInteger(String responseString)
    {
    	if (logger.isDebugEnabled())
    		logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODBEGIN);
        Integer intValue = new Integer(DAOConstants.ZERO);
        if(responseString != null && responseString.trim().length()>0){	        
	        if (responseString != null)
	        {
	            try
	            {
	                intValue = new Integer(responseString);
	            }
	            catch (NumberFormatException nfx)
	            {
	                logger.fatal(LoggingConstants.EXCEPTION, nfx);
	                //DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
	            }
	        }
        }
        if (logger.isDebugEnabled())
        {
            logger.debug("intValue :" + intValue);
            logger.debug("emptyStringCheckForDouble(String responseString) " + LoggingConstants.METHODEND);
        }
        
        return intValue;
    }
	
	
	 public HashMap getCoreBalanceInterestRate(Account accounts) throws DAOException {        
	        if (logger.isDebugEnabled()) {
	            logger.debug("accounts :" + accounts);
	        }
	        String txnno = DAOConstants.EMPTY;
	        if (accounts.getProductType().equalsIgnoreCase(DAOConstants.LOANACCOUNT))
	            txnno = DAOConstants.LONG_ENQ_LOANS;
	        else
	            txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;

	        Map requestParam = new HashMap();
	        requestParam.put(DAOConstants.TXNNO, txnno);
	        requestParam.put(DAOConstants.ACCNO, (String) accounts.getAccountNo());
	        logger.info("txnno:: "+txnno);
	        requestParam.put("bankCode",String.valueOf(accounts.getBranchCode().charAt(0)));

	        List responseList = coreDAOImpl.getDataFromBankSystem(requestParam);
	        HashMap coreDataHash = (HashMap) responseList.get(DAOConstants.ZERO_INT);
	        if (logger.isDebugEnabled()) {
	            logger.debug("coreDataHash :" + coreDataHash);
	        }
	        return coreDataHash;
	    }
	//end CR 5507
	//added for CR 5679
		 
	// <!-- IR 71227-->			
	 
	public List findBrokerAccounts(String username) throws DAOException {
		logger.info("findBrokerAccounts(String username)" + LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled()) {
			logger.debug("username :" + username);
		}
		if (username == null || (username.trim()).equals(DAOConstants.EMPTY)) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		List returnAccountList = new ArrayList();
		List accountList = fetchAccounts(username);
		if (accountList.size() == 0)
			return null;

		/* Filtering Accounts on the Basis of accessLevel and productType */
		for (int i = 0; i < accountList.size(); i++) {
			Account acc = (Account) accountList.get(i);
			if (acc != null && acc.getBrokerStmtFlag() != null && acc.getBrokerStmtFlag().equals("TRUE")) {
				returnAccountList.add(acc);
			}
		}
		if (returnAccountList.size() > 0) {
			if (logger.isDebugEnabled()) {
				logger.debug("returnAccountList :" + returnAccountList);
			}
			return returnAccountList;
		} else
			return null;
	}

	 public AccountDetails findAccountDetails(Account account) throws DAOException {
		logger.info("findAccountDetails(Account account) " + LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled()) {
			logger.debug("Account :" + account);
		}
		if (account != null && account.getBankSystem() != null && account.getAccountNo() != null 
				&& !account.getAccountNo().trim().equalsIgnoreCase(DAOConstants.EMPTY)
				&& account.getBranchCode() != null 
				&& !account.getBranchCode().trim().equalsIgnoreCase(DAOConstants.EMPTY)) {
			if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE)) {
				logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
				return getTransactionAccountDetailsFromCore(account);
			} else {
				logger.info("findAccountDetails(Account account)" + LoggingConstants.METHODEND);
				return getTransactionAccountDetailsFromDB(account);
			}
		} else {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		return null;
	 }

	private AccountDetails getTransactionAccountDetailsFromDB(Account account) {
		logger.info("getTransactionAccountDetailsFromDB(Account account) " + LoggingConstants.METHODBEGIN);
		if (logger.isDebugEnabled()) {
			logger.debug("Account :" + account);
		}
		try {

			Object[] parameters = new Object[] { account.getAccountNo(), account.getBranchCode() };
			List resultList = getJdbcTemplate().query(SQLConstants.SBI_ACC_MASTER_DATA, parameters,
					new AccountClassRowMapper());
			if (resultList != null && resultList.size() > 0) {
				if (resultList.size() == 1) {
					return (AccountDetails) resultList.get(0);
				} else if (resultList.size() > 1) {
					DAOException.throwException(ErrorConstants.FATAL_ERROR3_CODE);
				}
			}
		} catch (DataAccessException ex) {
			DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
		}
		return null;
	}
	
	private AccountDetails getTransactionAccountDetailsFromCore(Account account) throws DAOException
    {
        logger.info("getTransactionAccountDetailsFromCore(Account account)" + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("Account :" + account);
        }
        String txnno = DAOConstants.SHORT_ENQ_DEPOSITS_TXNNO;
        logger.info("txnno : " + txnno);	
        Map requestParams = new HashMap();
        requestParams.put(DAOConstants.ACCOUNT_NO, (String) account.getAccountNo());
        requestParams.put(DAOConstants.TXNNO, txnno);
        requestParams.put("bankCode",account.getBranchCode().substring(0,1));
        List responseList = coreDAOImpl.getDataFromBankSystem(requestParams);
        
        if(responseList == null || responseList.size() == 0){
        	SBIApplicationException.throwException("BAS001");
        }
        HashMap coreDataHash = (HashMap) responseList.get(0);
        
        String status = null;
        String errorCode = null; 
        
        if(coreDataHash.get("status") != null){
        	status = (String)coreDataHash.get("status");
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        if(coreDataHash.get("error_code") != null){
        	errorCode = (String)coreDataHash.get("error_code");
        	status = errorCode; 
        	if(status.trim().length() == 0)
        		status = "ERR.";
        }
        
        if(status == null && errorCode == null){
        	TransactionAccountDetails acc = new TransactionAccountDetails();
        	acc.setAccountDescription(account.getProductDescription());
        	acc.setCurrencyCode((String) coreDataHash.get(DAOConstants.CURRENCY_CODE));
        	acc.setAccountShortName((String) coreDataHash.get(DAOConstants.PROFILE_USER_NAME));
        	if (((String) coreDataHash.get(DAOConstants.NOMINATION)).trim().equalsIgnoreCase(DAOConstants.NO))
        		acc.setNomination(DAOConstants.ZERO);
        	else 
        		acc.setNomination(DAOConstants.ONE);
        	acc.setAvailableBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.AVAIL_BAL)));
        	acc.setBookBalance(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.BOOK_BALANCE)));
        	acc.setDrawingPower(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.DRAWING_POWER)));
        	acc.setSanctionedLimit(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.LIMIT)));
        	acc.setCreditInterestRate(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.INTEREST_RATE)));
        	acc.setMaturityAmount(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.MATURITY_AMT)));
        	acc.setMaturityDate(coreDateToTimestamp((String) coreDataHash.get(DAOConstants.MATURITY_DATE)));
        	acc.setPrincipal(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.TERM_VALUE)));
        	acc.setAccumulatedInterest(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get(DAOConstants.ACCUMULATED_INTEREST)));
        	acc.setOpeningDate(coreDateToTimestamp((String) coreDataHash.get(DAOConstants.OPENING_DATE)));
        	acc.setTenorDays(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_DAYS)));
        	acc.setTenorMonth(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_MONTH)));
        	acc.setTenorYear(emptyStringCheckForInteger((String) coreDataHash.get(DAOConstants.TENOR_YEAR)));
        	//Added for CR-5171
        	acc.setHoldValue(StringUtils.emptyStringCheckForDouble((String) coreDataHash.get("hold_value")));
        	logger.info("getTransactionAccountDetailsFromCore(Account account)" +LoggingConstants.METHODEND);
        	return acc;
        }else{        	
        	DAOException.throwException(status);
        }
        return null;
    }
	
	private Timestamp coreDateToTimestamp(String coreDateString)
    {
        logger.info("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODBEGIN);
        Timestamp timestamp = null;
        try
        {

            if (coreDateString != null && coreDateString.trim().length()>0)
            {
                SimpleDateFormat ts = new SimpleDateFormat(DAOConstants.DATA_FORMAT);
                Date sqlToday = new java.sql.Date(ts.parse(coreDateString).getTime());
                timestamp = new Timestamp(sqlToday.getTime());
                logger.info("coreDateToTimestamp(String coreDateString) " + LoggingConstants.METHODEND);
                return timestamp;
            }

        }
        catch (ParseException e)
        {
            logger.fatal(LoggingConstants.EXCEPTION, e);
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return timestamp;

    }
	
	class AccountClassRowMapper implements RowMapper
    {
        public Object mapRow(ResultSet rs, int index) throws SQLException
        {
            TransactionAccountDetails acc = new TransactionAccountDetails();

            acc.setAccountShortName(rs.getString(SQLConstants.SHORT_NAME));
            acc.setNomination(rs.getString(SQLConstants.NOMINATION));
            acc.setAccountDescription(rs.getString(SQLConstants.ACCOUNT_DESC));
            acc.setClearBalance(new Double(rs.getDouble(SQLConstants.CLEAR_BALANCE)));
            acc.setBookBalance(new Double(rs.getDouble(SQLConstants.BOOK_BALANCE)));
            acc.setDrawingPower(new Double(rs.getFloat(SQLConstants.DRAWING_POWER)));
            acc.setAmountOutStanding(new Double(rs.getFloat(SQLConstants.AMOUNT_OUTSTANDING)));
            acc.setSanctionedLimit(new Double(rs.getFloat(SQLConstants.SANCTIONED_LIMIT)));
            acc.setSanctionedDate(rs.getTimestamp(SQLConstants.SANCTIONED_DATE));
            acc.setCreditInterestRate(new Double(rs.getFloat(SQLConstants.CR_INT_RATE)));
            acc.setMaturityAmount(new Double(rs.getFloat(SQLConstants.MATURITY_AMOUNT)));
            acc.setMaturityDate(rs.getTimestamp(SQLConstants.MATURITY_DATE));
            acc.setPrincipal(new Double(rs.getFloat(SQLConstants.PRINCIPAL)));
            acc.setAccumulatedInterest(new Double(rs.getFloat(SQLConstants.ACCUMULATED_INTEREST)));
            acc.setOpeningDate(rs.getTimestamp(SQLConstants.OPENING_DATE));
            acc.setTenorDays(new Integer(rs.getInt(SQLConstants.TENOR_DAYS)));
            acc.setTenorMonth(new Integer(rs.getInt(SQLConstants.TENOR_MONTH)));
            acc.setTenorYear(new Integer(rs.getInt(SQLConstants.TENOR_YEAR)));
            acc.setPasswordFlag(rs.getBoolean(SQLConstants.PASSWORD_FLAG));
            acc.setDormantFlag(rs.getBoolean(SQLConstants.DORMANT_FLAG));
            acc.setLastUpdatedDate(rs.getTimestamp("last_updated_date"));
            return acc;
        }
    }
		 
	 public List findAccountsMT940(String username, Boolean accountLimit) throws DAOException {

	        logger.info("findAccountsMT940(String username, Boolean accountLimit))" + LoggingConstants.METHODBEGIN);

	        logger.info("username :" + username);

	        if (username != null && !(username.trim()).equals(DAOConstants.EMPTY) && accountLimit != null) {
	            List accountList;
	            Object[] param = {username};
	            List accList = new ArrayList();
	            try{
	           	 	
	                   accList=getJdbcTemplate().query(FIND_MT940_ACCOUNT_DETAILS,param, new MT940AccountDetailMapper());
	                    logger.info(" fetchAccountsMT940 accList :" + accList);
	                    if (accList.size() > 0) {                	
	                        logger.info("No of MT940 accounts fetched :" + accList.size());
	                      
	                        return accList;
	                    }
	                    
	                }
	                catch (DataAccessException ex) {

	                    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

	                }
	                return null;
	        }
	        return null;
	       
	    }
	 public List modifyDeleteMT940(String username, Boolean accountLimit) throws DAOException {

	        logger.info("modifyDeleteMT940(String username, Boolean accountLimit))" + LoggingConstants.METHODBEGIN);

	        logger.info("username :" + username);

	        if (username != null && !(username.trim()).equals(DAOConstants.EMPTY) && accountLimit != null) {
	            List accountList;
	            Object[] param = {username};
	            List accList = new ArrayList();
	            try{
	           	 	
	                   accList=getJdbcTemplate().query(FIND_MT940_MODIFY_DELETE,param, new MT940AccountDetailMapper());
	                    logger.info("ModifyDeleteMT940 accList :" + accList);
	                    if (accList.size() > 0) {                	
	                        logger.info("No of MT940 accounts fetched :" + accList.size());
	                      
	                        return accList;
	                    }
	                    
	                }
	                catch (DataAccessException ex) {

	                    DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

	                }
	                return null;
	        }
	        return null;
	       
	    }
	 class MT940AccountDetailMapper implements RowMapper
	    {
	    	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
	            Account acc = new Account();
	            acc.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
	            acc.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
	            acc.setProductType(rs.getString(DAOConstants.ACCOUNT_TYPE));
	            if (rs.getString(DAOConstants.ACCOUNT_NICKNAME) != null
	                    && !((rs.getString(DAOConstants.ACCOUNT_NICKNAME)).trim()).equals(""))
	                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NICKNAME));
	            else
	                acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NO));
	            
	            acc.setBranchName(rs.getString(DAOConstants.BRANCH_NAME));	            
	            return acc;
	        }
	    	
	    }
	 
	 
	 //end CR 5679
	 
	 // CR-CPSMS Beneficiary details display
	 public List findAccountsApprover(String username,String corporateId) throws DAOException {
	        logger.info("findAccountsApprover(String username)"
	                + LoggingConstants.METHODBEGIN);
	        if (logger.isDebugEnabled()) {
	            logger.debug("username :" + username);
	        }
//	        for (int i = 0; i < productType.length; i++) {

	            if (logger.isDebugEnabled()) {
	                logger.info("username is :" + username);
	            }
	            logger.info("username1 is :" + username);
	            if (username == null || (username.trim()).equals(DAOConstants.EMPTY)) {
	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

	            }
//	        }
	        List returnAccountList = new ArrayList();
	        List accountList = fetchAccountsApprover(username,corporateId);
	       
	        if (accountList.size() == 0)
	            return null;

	        /* Filtering Accounts on the Basis of accessLevel and productType */

	        for (int i = 0; i < accountList.size(); i++) {
	            Account acc = (Account) accountList.get(i);
	            returnAccountList.add(acc);
	            /*for (int j = 0; j < productType.length; j++) {
	               if (acc.getProductType().equalsIgnoreCase(productType[j])) {
	                    returnAccountList.add(acc);
	                }
	            }*/
	        }
	        if (returnAccountList.size() > 0) {
	            if (logger.isDebugEnabled()) {
	                logger.debug("returnAccountList :" + returnAccountList);
	            }
	            return returnAccountList;
	        }
	        else
	            return null;
	    }
	 private List fetchAccountsApprover(String username,String corporateId) throws DAOException {

	        logger.info("fetchAccounts(String username)" + LoggingConstants.METHODBEGIN);
	        logger.info("username :" + username);
	        Object obj = userSessionCache.getData(username + DAOConstants.USER_ACCOUNTS);
	        if (logger.isDebugEnabled()) {
	            logger.debug("Acounts for " + username + " : " +obj);
	        }
	        List accList = new ArrayList();        
	        if (obj != null) {
	            accList = (List) obj;
	            if (logger.isDebugEnabled()) {
	                logger.debug("List of Acounts for " + username + " : " + accList.size());
	            }
	            logger.info("accList"+accList.size());
	            logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
	            return accList;
	        }
	        else {
	            try {
	                if (logger.isDebugEnabled()) {
	                    logger.debug("Fetch account from DB");
	                }

	               Object[] params={username,corporateId};
				//   accList = getJdbcTemplate().query();
				   accList = getJdbcTemplate().query(VIEWINBOX_ADMIN_ACC,params,new ApproverAccountRowMapper());
				   

	                logger.info("accList ...."+accList);
	                userSessionCache.setData(username + DAOConstants.USER_ACCOUNTS, accList);

	                if (logger.isDebugEnabled()) {
	                    logger.debug("Fetch from DB");
	                }

	                if (accList.size() > 0) {
	                    if (logger.isDebugEnabled()) {
	                        logger.debug("accList :" + accList);
	                    }
	                    logger.info("fetchAccounts(String username)" + LoggingConstants.METHODEND);
	                    return accList;
	                }
	                else
	                    return accList;
	            }
	            catch (DataAccessException ex) {

	                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

	            }
	        }
	        return null;

	    }
		
	 //Added for eTDR/eSTDR -Start
	 public boolean checkAccountForMasked(String accountno, String branchcode, String username)throws DAOException{
        boolean returnFlag = false;
        int result = 0;
        Object[] params =
        { accountno,branchcode,username };
        try {
            result = getJdbcTemplate().queryForInt(SQLConstants.FIND_MASKED_ACCOUNTS_COUNT, params);
            //logger.info("Result :" + result);
            if (result>0){
                returnFlag = true;  
            }
        }
        catch (DataAccessException dataAccessException) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return returnFlag;
    }
	public List findAccountsByAccessLevel(String userName, String productType,int...accessLevel) throws DAOException {
        Account account = null;
        List accountList = fetchAccounts(userName);
        if (accountList.size() == 0)
            return null;
        if (logger.isDebugEnabled()) {
            logger.debug("Account list from Fetch Account" + accountList);
        }
        /** Filter for DEBI Account */
        if (productType.equals(ServiceConstant.DEBIT_ACCOUNT)) {
            List filterAccountList = new ArrayList();
            if (logger.isDebugEnabled()) {
                logger.debug("getting Debit Accounts ");
            }

            for (int i = 0; i < accountList.size(); i++) 
            {
                account = (Account) accountList.get(i); 
                if (logger.isDebugEnabled()) {
                    logger.debug("Bank System " + account.getBankSystem());
                    logger.debug("account no " + account.getAccountNo().substring(0, 3));
                }
                for(int accessNo:accessLevel){
                if (account.getAccessLevel().equals(new Integer(accessNo))) {
                    if (account.getBankSystem().equals(DAOConstants.CORE)) { 
                    	if(account.getProductType().equals(DAOConstants.A1) || account.getProductType().equals(DAOConstants.A2) || account.getProductType().equals(DAOConstants.A3) || account.getProductType().equals(DAOConstants.A4)){
                    		logger.info("::::::: account.getBranchCode().substring(0,1)::::::==== " + account.getBranchCode().substring(0,1));
							logger.info(":::::  account.getProductCode():::::  " + account.getProductCode());  
                    	//	if(!(("60245102").equalsIgnoreCase(account.getProductCode()) && !("7").equalsIgnoreCase(account.getBranchCode().substring(0,1)))) // Added by Reddy Damodhar for SBT Money Account
							if(!("60245102").equalsIgnoreCase(account.getProductCode())) // Added by Reddy Damodhar for SBT Money Account   
							filterAccountList.add(account);
                    	}
                    }
                    else if (DAOConstants.NC_DEBIT_ACCOUNT_DATA.indexOf(account.getAccountNo().substring(0, 3)) >= 0) {
                        filterAccountList.add(account);
                    } 
                } 
                }
            }
            if(logger.isDebugEnabled())
            logger.debug("filterAccountList :"+filterAccountList);
            return filterAccountList;
        }

        /** Filter for CREDIT Account */

        if (productType.equals(ServiceConstant.CREDIT_ACCOUNT)) {
            List filterAccountList = new ArrayList();
            if (logger.isDebugEnabled()) {
                logger.debug("getting Debit Accounts ");
            }
            for (int i = 0; i < accountList.size(); i++) 
            {
                account = (Account) accountList.get(i); 
                
                for(int accessNo:accessLevel){
                if (account.getAccessLevel().equals(new Integer(accessNo))) {
                    if (account.getBankSystem().equals(DAOConstants.CORE)) {
                        if (account.isCreditable().booleanValue())
                            filterAccountList.add(account);
                    }
                    else if (DAOConstants.NC_CREDIT_ACCOUNT_DATA.indexOf(account.getAccountNo().substring(0, 3)) >= 0
                            || account.getAccountNo().substring(0, 5).equals(DAOConstants.NC_CREDIT_ACCOUNT_DATA1)) {
                        filterAccountList.add(account);
                    }
                }
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("filteraccountList debit " + filterAccountList);
            }
            
            return filterAccountList;
        }
        return null;

    }   
	//Added for eTDR/eSTDR -End
	//added by Damodar for Account based MIS downloads with starts   
	  public Map findAccountsApproverForMIS(String username, String corporateID, Integer accessLevel,Integer loginUserRole) throws DAOException {
	      logger.info("findAccountsApproverForMIS(String username, String[] corporateID, Integer accessLevel,Integer loginUserRole )"
	              + LoggingConstants.METHODBEGIN);
	      if (logger.isDebugEnabled()) {
	          logger.debug("username :" + username + " accessLevel :" + accessLevel);
	      }
	      
	      if (username == null || accessLevel == null
	                  || (username.trim()).equals(DAOConstants.EMPTY) || accessLevel.equals(DAOConstants.EMPTY)) {
	              DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

	          }
	      
	      List savingsAccountList = new ArrayList();
	      List currentAccountList = new ArrayList();
	      List cashcreditAccountList = new ArrayList();
	      List timedepositAccountList = new ArrayList();
	      List otherloansAccountList = new ArrayList();
	      List tradeAccountList = new ArrayList();
	      Map returnAccountMap = new HashMap();
	      List accountList = null;        
	      Object[] params =
	          {  corporateID,username};	    
	      Object[] accparams2 = new Object[] {corporateID};
	      
	      try{ 
	     	 if(loginUserRole ==42){ 	
	         logger.info("Approver loginUserRole :"+loginUserRole);
	         String createdByUser = (String) getJdbcTemplate().queryForObject(USERPROFILE_DETAILS, params, String.class);
		     logger.info("createdByUser :"+createdByUser);
		     Object[] parameter = new Object[] {createdByUser};
		     String userId = (String) getJdbcTemplate().queryForObject(USERID_DETAILS, parameter, String.class);
		     logger.info("userId :"+userId);
		     Object[] outparams = new Object[] {userId}; 
		     String userRole = (String) getJdbcTemplate().queryForObject(USER_ROLES, outparams, String.class);
		     logger.info("userRole :"+userRole);
		     Object[] accparams1 =
		            { createdByUser, corporateID}; 
	      if(userRole.equals("7"))
	      {
	        //accountList = (List)getJdbcTemplate().query(ACCOUNT_DETAILS_FETCHING,params, new AccountForMISExtractor());
	          accountList = getJdbcTemplate().query(ACCOUNT_DETAILS_FETCHING,accparams1, new AccountRowMapperForMIS());
	      logger.info("accountList Size :"+accountList.size()); 

	      }
	      else if(userRole.equals("10"))
	      {
	          accountList = getJdbcTemplate().query(ACCOUNT_FETCHING,accparams2, new AccountRowMapperForMIS());
	          logger.info("accountList Size :"+accountList.size());
	      }
	     }
	  	     	    	   
	   }
	      catch (DataAccessException e) {
					logger.error("Error Occured : " + e.getMessage());
		            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
				} 
	      catch(NoSuchMessageException e){
				logger.error("No Such Account for the Report");
				accountList=null;
			}
			catch (Exception e) {
				logger.error("getAccount Details catch");
				accountList=null;
			} 

	    //   Filtering Accounts on the Basis of accessLevel and productType 

	      for (int i = 0; i < accountList.size(); i++) {
	          Account acc = (Account) accountList.get(i);
	          logger.info("acc :::::"+acc);
	          logger.info("acc.getProductType():::::"+acc.getProductType());
	          if (acc.getProductType().equalsIgnoreCase("A1")) 
	          {
	                  savingsAccountList.add(acc);
	          }
	          if (acc.getProductType().equalsIgnoreCase("A2")) 
	          {
	                  currentAccountList.add(acc);
	          }
	          if ((acc.getProductType().equalsIgnoreCase("A3") || acc.getProductType().equalsIgnoreCase("A4")) ) 
	          {
	                  cashcreditAccountList.add(acc);
	          }
	          
	          }
	      
	      	returnAccountMap.put("Savings", savingsAccountList);
	      	returnAccountMap.put("Current", currentAccountList);
	      	returnAccountMap.put("CashCredit", cashcreditAccountList);
	      if (returnAccountMap.size() > 0) {
	          
	              logger.info("returnAccountMap :" + returnAccountMap);
	         
	          return returnAccountMap;
	      }
	      else
	          return null;
	  }
	  /**
     * AccountRowMapperForMIS for processing the row
     */
		class AccountRowMapperForMIS implements RowMapper {
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            Account acc = new Account();
            acc.setAccountNo(rs.getString(("ACCOUNT_NO"))); 
            acc.setProductType(rs.getString(("PRODUCT_TYPE")));
            acc.setProductDescription(rs.getString("PRODUCT_DESC")); 
            acc.setBranchCode(rs.getString("BRANCH_CODE"));  
            acc.setProductCode(rs.getString("PRODUCT_CODE")); 
            acc.setBranchName(rs.getString("BRANCH_NAME"));  
            if (logger.isDebugEnabled())
                logger.debug("AccountRowMapperForMIS.mapRow method end and it return account:" + acc.toString());
            return acc;
        } 
    }
	  //added by Damodar for Account based MIS downloads with ends      


	//Added for Beneficiary revamp
	public Account findAccountDtls(String accountno, String benCode, String username) throws DAOException {
        logger.info("findAccountDtls(String accountno, String benCode, String username)" + LoggingConstants.METHODBEGIN);

        logger.info("accountno :" + accountno + " benCode :" + benCode + " username :" + username);

        if (accountno == null || username == null || (username.trim()).equals(DAOConstants.EMPTY)
                 || (accountno.trim()).equals(DAOConstants.EMPTY)) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);

        }
        else {
            Account returnAccount = null;
            List accList = fetchAccounts(username);

            if (logger.isDebugEnabled()) {
                logger.debug("Account List size : " + accList.size());
            }

            if (accList.size() == 0)
                return null;

            int size = accList.size();
            
            if(benCode==null || "".equalsIgnoreCase(benCode.trim())) {
            	benCode="";
            }
            String currBenCode;
            for (int i = 0; i < size; i++) {
                Account acc = (Account) accList.get(i);
                currBenCode = acc.getEmployeeCode();
                if(currBenCode==null || "".equalsIgnoreCase(currBenCode.trim())) {
                	currBenCode="";
                }
                
                if (acc.getAccountNo().equalsIgnoreCase(accountno) && currBenCode.equalsIgnoreCase(benCode)) {
                    returnAccount = (Account) accList.get(i);
                }
            }

            if (returnAccount != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("returnAccount: " + returnAccount);
                }
                logger.info("findAccountDtls(String accountno, String benCode, String username) "
                        + LoggingConstants.METHODEND);
                return returnAccount;
            }
            else {
                logger.info("findAccountDtls(String accountno, String benCode, String username) "
                        + LoggingConstants.METHODEND);
                return null;
            }
        }
        return null;

    }
	public Account deleteTPAccountDtls(Account userAccount,String corporateId) throws DAOException
    {

        logger.info("deleteTPAccountDtls(Account userAccount,String corporateId) Method Begin ");
        logger.info("Values in Account Object is " + userAccount);

        if (userAccount == null) {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        else {
            try {
                
            	Object[] params = new Object[] {userAccount.getUserName(), userAccount.getRefNo(), userAccount.getAccountNickName(), corporateId};
            	String query = "update sbicorp_third_party set status='3',deletion_approved_by=? , approval_status='Deleted', "+ 
						" last_mod_time=sysdate where oid =? and name_third_party = ? and corporate_id=?";		
				logger.info("query :" + query);
				logger.info("parameters :" + userAccount.getUserName()+","+userAccount.getRefNo()+","+userAccount.getAccountNickName()+","+corporateId);
				int updateCount = getJdbcTemplate().update(query, params);
				
            	if (updateCount == 0) {
                    DAOException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);

                }
                else {
                    insertProfileAccountLogDtls(userAccount, "Delete", "");
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("Query Executed Successfully for Deletion");
                    logger.debug("Value Returned by the Query " + updateCount);
                }

            }
            catch (DataAccessException daoException) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, daoException);

            }

        }

        logger.info("deleteAccount(Account userAccount,String corporateId) Method End ");
        if (logger.isDebugEnabled())
            logger.debug("userAccount :" + userAccount);

        return userAccount;
    
    }
	public boolean insertProfileAccountLogDtls(Account account, String actionFlag, String oldValues) {

        logger.info("insertProfileAccountLogDtls(Account account, String actionFlag, String oldValues) "
                + LoggingConstants.METHODBEGIN);

        logger.info("account :" + account);
        logger.info("actionFlag :" + actionFlag);
        logger.info("oldValues :" + oldValues);

        try {
            String action = "";
            String newValues = "";

            UserProfile userProfile = userDAOImpl.findUserProfile(account.getUserName());

            int sqlTypes[] =
            { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
            if (account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString())) {
                if (actionFlag.equalsIgnoreCase("Edit")) {
                    action = "Edit Third Party";
                    newValues = account.getAccountNo() + "|" + account.getEmployeeCode() + "|"
                            + account.getAccountNickName() + "|" + account.getBalance();
                }
                else if  (actionFlag.equalsIgnoreCase("Add")) {
                    action = "Add Third Party";
                    newValues = account.getAccountNo() + "|" + account.getEmployeeCode() + "|"
                            + account.getAccountNickName() + "|" + account.getBalance();
                }

                else {
                    action = "Delete Third Party";
                    newValues = account.getAccountNo() + "|" + account.getEmployeeCode() + "|"
                            + account.getAccountNickName();
                }
            }
            else {
                action = "Delete PPF";
                newValues = account.getAccountNo() + "|" + account.getEmployeeCode();
            }

            logger.info("**************UserName:" + account.getUserName());
            logger.info("getUserIPaddress:" + userProfile.getUserIPaddress());
            logger.info("action Name:" + action);
            logger.info("oldValues:" + oldValues);
            logger.info("New values: ************** " + newValues);

            Object[] inParameter = new Object[]
            { account.getUserName(), userProfile.getUserIPaddress(), action, oldValues, newValues };

            int status = getJdbcTemplate().update(SQLConstants.PROFILE_LOG_QUERY_ACCOUNT, inParameter, sqlTypes);

            logger.info("Profile Log status for Account manipulation " + status);
        }
        catch (DataAccessException ex) {

            logger.error(LoggingConstants.EXCEPTION, ex);
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, ex);

        }
        catch (Exception ex) {

            logger.error(LoggingConstants.EXCEPTION, ex);
            ex.printStackTrace();
            
        }
        logger.info("insertProfileAccountLogDtls(Account account, String actionFlag, String oldValues) "
                + LoggingConstants.METHODEND);
        return true;
    }
}
