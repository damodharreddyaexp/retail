/*    
 * TransactionHistoryDAO.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $ 
 */
//History
//Oct 18, 2005 MURUGAN - Initial Creation
//History
//Oct 18, 2005 MURUGAN - method's implemetation
// DEC 28, 2005 - BOOPATHI - EXCEPTION MODIFIED
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oracle.jdbc.driver.OracleTypes;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.Account;
import com.sbi.common.model.BrokerAccountDetails;
import com.sbi.common.model.ChequeStatus;
import com.sbi.common.model.TransactionHistory;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.dao.DAOConstants;


//import com.sbi.model.*;
/**
 * TODO TransactionHistoryDAOImpl class
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */

public class TransactionHistoryDAOImpl extends JdbcDaoSupport implements TransactionHistoryDAO {

    public final static boolean coreFlag = true;

    protected final Logger logger = Logger.getLogger(getClass());

    private BankSystemDAO coreDAOImpl;

    private BankSystemDAO switchDAOImpl;

    /**
     * TODO Query to get data from TransactionHistory table filtering by date
     * if(Account.getBankSystem == NonCore ) then Call
     * [getTransactionfromDB(inParameters, "getTransactionsByDate")] return List
     * of TransactionHisotry else build the requestString, Call
     * [getTransactionsFromCore(requestString , account)] return List of
     * TransactionHistory
     * 
     * @param accountNo
     * @param branchCode
     * @param fromDate
     * @param toDate
     * @param order
     * @return List of TransactionHistory
     */

    public List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId)
            throws DAOException {
        
    	logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
            logger.debug("From Date:" + fromDate);
            logger.debug("To Date  :" + toDate);
            logger.debug("Order    :" + order);
        }
        logger.info("account.getBankSystem().equals(DAOConstants.BANK_MASTER)**"+account.getBankSystem().equals(DAOConstants.BANK_MASTER));
        logger.info("corporateId**3"+corporateId);
        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        String identification = "TransactionWithDate";

        if (account != null && fromDate != null && toDate != null) {
            try {
                if (account.getBankSystem().equals(DAOConstants.BANK_MASTER)) {
                    logger.debug("Find the  TransactionHistory in Banks Master");
                    String toDatestr = new SimpleDateFormat("MM/dd/yy").format(toDate);
                    String fromDatestr = new SimpleDateFormat("MM/dd/yy").format(fromDate);
                    inParameters.put(DAOConstants.ACCOUNT_NO, account.getAccountNo());
                    inParameters.put(DAOConstants.BRANCH_CODE, account.getBranchCode());
                    inParameters.put(DAOConstants.FROM_DATE, fromDatestr);
                    inParameters.put(DAOConstants.TO_DATE, toDatestr);
                    inParameters.put(DAOConstants.BALANCE, account.getBalance());
                    inParameters.put(DAOConstants.CORPORATE_ID,corporateId);
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1));                    
                    String procedureName = "{call GETTRANSACTIONSBYDATE(?,?,?,?,?,?,?)}";
                    transactionHistoryList = getTransactionfromDB(inParameters, procedureName, identification);
                }
                else if (account.getBankSystem().equals(DAOConstants.CORE)) {
                    if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_LOAN);
                    }
                    else {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_DEPOSIT); // key
                        // =
                        // "txnno"
                        inParameters.put(DAOConstants.CORE_FIN_TXN_TYPE, ""); // key
                        // =
                        // "fin_txn_type"
                    }

                    String coreTodate = new SimpleDateFormat("ddMMyyyy").format(toDate);
                    String coreFromDate = new SimpleDateFormat("ddMMyyyy").format(fromDate);
                    
                    String startDate = null;
                    String endDate = null;
                    if (fromDate != null)
                        startDate = new SimpleDateFormat("dd/MM/yyyy").format(fromDate);
                    if (toDate != null)
                        endDate = new SimpleDateFormat("dd/MM/yyyy").format(toDate);

                    inParameters.put("START_DATE", startDate);
                    inParameters.put("END_DATE", endDate);
                    
                    inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo()); // "account_no"
                    inParameters.put(DAOConstants.TXN_IDENTIFIER, "2"); // "txn_identifier"
                    inParameters.put(DAOConstants.CORE_START_DATE, coreFromDate); // "start_date"
                    inParameters.put(DAOConstants.CORE_END_DATE, coreTodate); // "end_date"
                    inParameters.put(DAOConstants.CORE_FROM_AMOUNT, ""); // "from_amt"
                    inParameters.put(DAOConstants.CORE_TO_AMOUNT, ""); // "to_amt"
                    inParameters.put("bankCode", ""); 
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1)); 
                    transactionHistoryList = getTransactionsFromCore(inParameters, account);
                } 
                logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId) method begin");

                return transactionHistoryList;
            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("Input Parameter Account" + account);
                logger.debug("Input parameter Account:" + account + " FromDate" + fromDate + " ToDate" + toDate);
            }
            DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
        }
        return null;
    }   
    
    
    public List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId, String timestamp, String type)
            throws DAOException {
        
    	logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
            logger.debug("From Date:" + fromDate);
            logger.debug("To Date  :" + toDate);
            logger.debug("Order    :" + order);
        }
        logger.info("account.getBankSystem().equals(DAOConstants.BANK_MASTER)**"+account.getBankSystem().equals(DAOConstants.BANK_MASTER));
        logger.info("corporateId**3"+corporateId);
        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        String identification = "TransactionWithDate";

        if (account != null && fromDate != null && toDate != null) {
            try {
                if (account.getBankSystem().equals(DAOConstants.BANK_MASTER)) {
                    logger.debug("Find the  TransactionHistory in Banks Master");
                    String toDatestr = new SimpleDateFormat("MM/dd/yy").format(toDate);
                    String fromDatestr = new SimpleDateFormat("MM/dd/yy").format(fromDate);
                    inParameters.put(DAOConstants.ACCOUNT_NO, account.getAccountNo());
                    inParameters.put(DAOConstants.BRANCH_CODE, account.getBranchCode());
                    inParameters.put(DAOConstants.FROM_DATE, fromDatestr);
                    inParameters.put(DAOConstants.TO_DATE, toDatestr);
                    inParameters.put(DAOConstants.BALANCE, account.getBalance());
                    inParameters.put(DAOConstants.CORPORATE_ID,corporateId);
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1));                    
                    String procedureName = "{call GETTRANSACTIONSBYDATE(?,?,?,?,?,?,?)}";
                    transactionHistoryList = getTransactionfromDB(inParameters, procedureName, identification);
                }
                else if (account.getBankSystem().equals(DAOConstants.CORE)) {
                    if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_LOAN);
                    }
                    else {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_DEPOSIT); // key
                        // =
                        // "txnno"
                        inParameters.put(DAOConstants.CORE_FIN_TXN_TYPE, ""); // key
                        // =
                        // "fin_txn_type"
                    }

                    String coreTodate = new SimpleDateFormat("ddMMyyyy").format(toDate);
                    String coreFromDate = new SimpleDateFormat("ddMMyyyy").format(fromDate);
                    
                    String startDate = null;
                    String endDate = null;
                    if (fromDate != null)
                        startDate = new SimpleDateFormat("dd/MM/yyyy").format(fromDate);
                    if (toDate != null)
                        endDate = new SimpleDateFormat("dd/MM/yyyy").format(toDate);

                    inParameters.put("START_DATE", startDate);
                    inParameters.put("END_DATE", endDate);
                    
                    inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo()); // "account_no"
                    inParameters.put(DAOConstants.TXN_IDENTIFIER, "2"); // "txn_identifier"
                    inParameters.put(DAOConstants.CORE_START_DATE, coreFromDate); // "start_date"
                    inParameters.put(DAOConstants.CORE_END_DATE, coreTodate); // "end_date"
                    inParameters.put(DAOConstants.CORE_FROM_AMOUNT, ""); // "from_amt"
                    inParameters.put(DAOConstants.CORE_TO_AMOUNT, ""); // "to_amt"
                    inParameters.put("timestamp", timestamp );
                    inParameters.put("type", type);
                    inParameters.put("bankCode", ""); 
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1)); 
                    transactionHistoryList = getTransactionsFromCore(inParameters, account);
                } 
                logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order, String corporateId) method begin");

                return transactionHistoryList;
            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("Input Parameter Account" + account);
                logger.debug("Input parameter Account:" + account + " FromDate" + fromDate + " ToDate" + toDate);
            }
            DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
        }
        return null;
    } 
    
    /**
     * TODO Query to get data from TransactionHistory table filtering by date
     * if(Account.getBankSystem == NonCore ) then Call
     * [getTransactionfromDB(inParameters, "getTransactionsByDate")] return List
     * of TransactionHisotry else build the requestString, Call
     * [getTransactionsFromCore(requestString , account)] return List of
     * TransactionHistory
     * 
     * @param accountNo
     * @param branchCode
     * @param fromDate
     * @param toDate
     * @param order
     * @return List of TransactionHistory
     */

    public List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order)
            throws DAOException {
        logger
                .info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, int order) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
            logger.debug("From Date:" + fromDate);
            logger.debug("To Date  :" + toDate);
            logger.debug("Order    :" + order);
        }
        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        String identification = "TransactionWithDate";

        if (account != null && fromDate != null && toDate != null) {
            try {
                if (account.getBankSystem().equals(DAOConstants.BANK_MASTER)) {
                    logger.debug("Find the  TransactionHistory in Banks Master");
                    String toDatestr = new SimpleDateFormat("MM/dd/yy").format(toDate);
                    String fromDatestr = new SimpleDateFormat("MM/dd/yy").format(fromDate);
                    inParameters.put(DAOConstants.ACCOUNT_NO, account.getAccountNo());
                    inParameters.put(DAOConstants.BRANCH_CODE, account.getBranchCode());
                    inParameters.put(DAOConstants.FROM_DATE, fromDatestr);
                    inParameters.put(DAOConstants.TO_DATE, toDatestr);
                    inParameters.put(DAOConstants.BALANCE, account.getBalance());
                    String procedureName = "{call getTransactionsByDate(?,?,?,?,?,?)}";
                    transactionHistoryList = getTransactionfromDB(inParameters, procedureName, identification);
                }
                else if (account.getBankSystem().equals(DAOConstants.CORE)) {
                    if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_LOAN);
                    }
                    else {
                        inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_DEPOSIT); // key
                        // =
                        // "txnno"
                        inParameters.put(DAOConstants.CORE_FIN_TXN_TYPE, ""); // key
                        // =
                        // "fin_txn_type"
                    }

                    String coreTodate = new SimpleDateFormat("ddMMyyyy").format(toDate);
                    String coreFromDate = new SimpleDateFormat("ddMMyyyy").format(fromDate);

                    String startDate = null;
                    String endDate = null;
                    if (fromDate != null)
                        startDate = new SimpleDateFormat("dd/MM/yyyy").format(fromDate);
                    if (toDate != null)
                        endDate = new SimpleDateFormat("dd/MM/yyyy").format(toDate);

                    inParameters.put("START_DATE", startDate);
                    inParameters.put("END_DATE", endDate);
                    
                    inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo()); // "account_no"
                    inParameters.put(DAOConstants.TXN_IDENTIFIER, "2"); // "txn_identifier"
                    inParameters.put(DAOConstants.CORE_START_DATE, coreFromDate); // "start_date"
                    inParameters.put(DAOConstants.CORE_END_DATE, coreTodate); // "end_date"
                    inParameters.put(DAOConstants.CORE_FROM_AMOUNT, ""); // "from_amt"
                    inParameters.put(DAOConstants.CORE_TO_AMOUNT, ""); // "to_amt"
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1));
                    transactionHistoryList = getTransactionsFromCore(inParameters, account);
                }
                logger.info("findTransactionHistory( account, fromDate, toDate,order) End");
                return transactionHistoryList;
            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("Input Parameter Account" + account);
                logger.debug("Input parameter Account:" + account + " FromDate" + fromDate + " ToDate" + toDate);
            }
            DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
        }
        return null;
    }

    /**
     * TODO Query to get data from TransactionHistory table filtering by date
     * if(Account.getBankSystem == NonCore ) then Call
     * [getTransactionfromDB(inParameters, "getTransactionsByDate")] return List
     * of TransactionHisotry else build the requestString, Call
     * [getTransactionsFromCore(requestString, account)] return List of
     * TransactionHistory
     * 
     * @param accountNo
     * @param branchCode
     * @param limit
     * @return List of TransactionHistory
     */

    public List findTransactionHistory(Account account, int limit) throws DAOException {
        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        String identification = "TransactionWithLimit";
        if (account != null) {

            logger.info("findTransactionHistory(Account account, int limit) method begin");
            if (account.getBankSystem().equalsIgnoreCase(DAOConstants.BANK_MASTER)) {                
                inParameters.put(DAOConstants.ACCOUNT_NO, account.getAccountNo());
                inParameters.put(DAOConstants.BRANCH_CODE, account.getBranchCode());
                inParameters.put(DAOConstants.FROM_DATE, "");
                inParameters.put(DAOConstants.TO_DATE, "");
                inParameters.put(DAOConstants.BALANCE, account.getBalance());
                logger.info("Balance : " + account.getBalance());
                

                String procedureName = "{call getTransactionsByLimit(?,?,?,?,?,?)}";
                transactionHistoryList = getTransactionfromDB(inParameters, procedureName, identification);
                logger.info("TransactionHistoryList : " + transactionHistoryList);
                logger.info("Get the TransactionHistory from BankMaster DB begin");
            }
            else if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE)) {
                if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
                    inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_LOAN);
                }
                else {
                    inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_DEPOSIT);
                    inParameters.put("fin_txn_type", "");
                }
                logger.info("Get the TransactionHistory from  Bank System : " + account.getBankSystem());
                

                inParameters.put("START_DATE", "");
                inParameters.put("END_DATE", "");

                
                inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo());
                inParameters.put(DAOConstants.TXN_IDENTIFIER, "0");
                inParameters.put(DAOConstants.CORE_START_DATE, "");
                inParameters.put(DAOConstants.CORE_END_DATE, "");
                inParameters.put(DAOConstants.CORE_FROM_AMOUNT, "");
                inParameters.put(DAOConstants.CORE_TO_AMOUNT, "");
                inParameters.put("bankCode",account.getBranchCode().substring(0,1));
                transactionHistoryList = getTransactionsFromCore(inParameters, account);
                logger.debug("Get the TransactionHistory from Core " + transactionHistoryList);
            }
            logger.info("findTransactionHistory(Account account, int limit) method  end");
            return transactionHistoryList;
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    public List findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, Double fromAmount,
            Double toAmount, String transactionType) throws DAOException {

        logger
                .info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, Double fromAmount,Double toAmount,String transactionType) method begin");
        if (logger.isDebugEnabled()) {
            logger.debug("Account  : " + account);
            logger.debug("From Date:" + fromDate);
            logger.debug("To Date  :" + toDate);
            logger.debug("From Amount   :" + fromAmount);
            logger.debug("To Amount   :" + toAmount);
            logger.debug("Transaction Type : " + transactionType);

        }

        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();

        if (account != null && transactionType != null) {
            try {
                if (account.getBankSystem().equals(DAOConstants.BANK_MASTER)) {
                    if (logger.isDebugEnabled()) 
                    logger.debug("Find the  TransactionHistory in Banks Master");
                    String toDatestr = null;
                    String fromDatestr = null;
                    String startDate = null;
                    String endDate = null;
                    if (toDate != null)
                        toDatestr = new SimpleDateFormat("MM/dd/yy").format(toDate);
                    if (fromDate != null)
                        fromDatestr = new SimpleDateFormat("MM/dd/yy").format(fromDate);
                    
                    if (fromDate != null)
                        startDate = new SimpleDateFormat("dd/MM/yyyy").format(fromDate);
                    if (toDate != null)
                        endDate = new SimpleDateFormat("dd/MM/yyyy").format(toDate);

                    inParameters.put("START_DATE", startDate);
                    inParameters.put("END_DATE", endDate);
                    
                    inParameters.put(DAOConstants.ACCOUNT_NO, account.getAccountNo());
                    inParameters.put(DAOConstants.BRANCH_CODE, account.getBranchCode());
                    inParameters.put(DAOConstants.FROM_DATE, fromDatestr);
                    inParameters.put(DAOConstants.TO_DATE, toDatestr);
                    inParameters.put(DAOConstants.FROMAMOUNT, fromAmount);
                    inParameters.put(DAOConstants.TOAMOUNT, toAmount);
                    inParameters.put(DAOConstants.TTYPE, transactionType);
                    String identification = "TransactionWithAmount";
                    String procedureName = "{call GETTRANSACTIONDETAILS(?,?,?,?,?,?,?,?)}";
                    transactionHistoryList = getTransactionfromDB(inParameters, procedureName, identification);
                }
                else if (account.getBankSystem().equals(DAOConstants.CORE)) {
                    inParameters.put(DAOConstants.CORE_TXN_NO, DAOConstants.TXN_ENQUIRY_DEPOSIT); // key
                    inParameters.put(DAOConstants.CORE_FIN_TXN_TYPE, ""); // key
                    String coreFromDate = null;
                    String coreTodate = null;
                    if (toDate != null) {

                        coreTodate = new SimpleDateFormat("ddMMyyyy").format(toDate);
                    }
                    if (toDate != null) {
                        coreFromDate = new SimpleDateFormat("ddMMyyyy").format(fromDate);
                    }

                    inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo()); // "account_no"
                    inParameters.put(DAOConstants.TXN_IDENTIFIER, "1"); // "txn_identifier"
                    inParameters.put(DAOConstants.CORE_START_DATE, coreFromDate); // "start_date"
                    inParameters.put(DAOConstants.CORE_END_DATE, coreTodate); // "end_date"
                    inParameters.put(DAOConstants.CORE_FROM_AMOUNT, StringUtils.getCoreAmount(fromAmount)); // "from_amt"
                    inParameters.put(DAOConstants.CORE_TO_AMOUNT, StringUtils.getCoreAmount(toAmount)); // "to_amt"
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1));
                    transactionHistoryList = getTransactionsFromCore(inParameters, account);
                }
                logger.info("findTransactionHistory( account, fromDate, toDate,order) End");
                return transactionHistoryList;

            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("Input Parameter Account" + account);
                logger.debug("Input parameter Account:" + account + " FromDate" + fromDate + " ToDate" + toDate);
            }

            DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
        }
        return null;

    }

    public List findChequeStatus(String accountNo, String branchCode, Integer[] chequeNumber) throws DAOException {
        System.out.println("findChequeStatus ");
        logger.info("findChequeStatus(String accountNo, String branchCode, String[] chequeNumber) method begin");
        String chequeNumbers = "";
        List resultList = null;
        int chequeTo = chequeNumber[1].intValue();
        int chequeFrom = chequeNumber[0].intValue();
        try {
            if (accountNo != null && branchCode != null && chequeNumber[0] != null && chequeNumber[1] != null) {
                for (int i = chequeFrom; i <= chequeTo; i++) {                	
                    chequeNumbers += "'" + StringUtils.padString(String.valueOf(i), 8, "0", "l") + "'";
                    if(i<chequeTo)
                    	chequeNumbers += ",";
                }
                logger.info("cheque " + chequeNumbers);
                Object[] parameters = new Object[]
                { accountNo, branchCode };

                logger.info("findChequeStatus(String accountNo, String branchCode, Integer[] chequeNumber) method end");
                // resultList = getJdbcTemplate()
                resultList = getJdbcTemplate().query(
                        "Select * from sbi_txn_history where account_no=? and branch_code=? and reference_no in ("
                                + chequeNumbers
                                + ") and ttype_code in ('42','45','55','49','52') order by reference_no", parameters,
                        new ChequeStatusRowMapper());

            }

        }
        catch (DataAccessException daoExp) {
            logger.error("Exception occured : " + daoExp);
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, daoExp);
        }

        logger.info("findChequeStatus(String accountNo, String branchCode, Integer[] chequeNumber) method end");
        return resultList;
    }

    /**
     * TODO Call the [coreDAOImpl.getDataFromBankSystem(request)] return List,
     * build the TransactionHistory object
     * 
     * @param request
     * @param account
     * @return List
     */
    public List getTransactionsFromCore(Map request, Account account) throws DAOException {
        logger.info("getTransactionsFromCore(Map request, Account account) begin");
        // BankSystemDAO bankSystemDAO = new CoreDAOImpl();
        
        logger.info("insert user name::"+request.get("USER_NAME"));
        String timeStamp = (String)request.get("timestamp");
        String postTime;
        List responseList = coreDAOImpl.getDataFromBankSystem(request);
        Map transactionMap = null;
        List transactionHistoryList = null;
        if (responseList != null && responseList.size() > 0) {
            transactionHistoryList = new ArrayList();
            for (int i = 0; i < responseList.size(); i++) {
                
                transactionMap = (Map) responseList.get(i);
                
                String status = null;
                String errorCode = null;
                String branchCode =account.getBranchCode();
                String bankCode =branchCode.substring(0, 1);
                String userAlias= account.getUserAlias();
                logger.info("insert user alias::"+userAlias);
                String anaklynFlag= account.getAnaklynFlag(); //pending account statement
                
                if(transactionMap.get("status") != null){
                	status = (String)transactionMap.get("status");
                	transactionHistoryList = new ArrayList();
                	transactionHistoryList.add(status);
                	return transactionHistoryList;
                }
                if(transactionMap.get("error_code") != null){
                	errorCode = (String)transactionMap.get("error_code");
                	status = errorCode; 
                }
                
                if(status == null && errorCode == null){
                    String fileName = (String)transactionMap.get("filename");
                    
                if(fileName.charAt(0) != ':'){ 
                TransactionHistory transactionHistory = new TransactionHistory();

                /*
                 * setting values from Core response to TransactionHistory
                 * object 
                 */
                if(logger.isDebugEnabled())
                logger.debug("core Date :" + transactionMap.get(DAOConstants.CORE_DATE));
                transactionHistory.setAmount(StringUtils.emptyStringCheckForDouble(((String) transactionMap
                        .get(DAOConstants.CORE_AMOUNT)))); // "amount"
                transactionHistory.setNarrative1((String) transactionMap.get(DAOConstants.CORE_NARRATIVE)); // "narrative"
                //Added by CR 2765
                transactionHistory.setBranchCodeFromCore((String)transactionMap.get(DAOConstants.BRANCH_CODE));
                logger.info("TRANSACTION MAP ::"+transactionHistory.getBranchCodeFromCore());
                transactionHistory.setNarrative2((String) transactionMap.get(DAOConstants.USER_NARRATIVE)); // "user_narrative"               
                transactionHistory.setTransactionDate((StringUtils.coreDateToTimestamp((String) transactionMap
                        .get(DAOConstants.CORE_DATE)))); // "date"
                transactionHistory.setValueDate(StringUtils.coreDateToTimestamp((String) transactionMap
                        .get(DAOConstants.CORE_VALUE_DATE))); // "valuedate"
                transactionHistory.setBalance(StringUtils.emptyStringCheckForDouble((String) transactionMap
                        .get(DAOConstants.CORE_BALANCE))); // "balance"
                if(transactionMap.get(DAOConstants.IB_REF_NO) != null)
                	transactionHistory.setReferenceNo(((String) transactionMap.get(DAOConstants.IB_REF_NO)).trim());
                if(timeStamp != null  && timeStamp.equals("yes") && account.getProductType() != null && !account.getProductType().equals(DAOConstants.LOANACCOUNT))
                {
                	if(transactionMap.get("post_time") != null)
                	{
                		
                		postTime = (((String) transactionMap.get("post_time")).trim()).substring(0,6);
                		postTime = postTime.substring(0,2)  +":"+  postTime.substring(2,4)  +":"+  postTime.substring(4,6);
                		transactionHistory.setPosttime(postTime);
                		logger.info("post time:::" + transactionHistory.getPosttime());
                		/*transactionHistory.setPosttime((((String) transactionMap.get("post_time")).trim()).substring(0,5));*/
                
                	}	
                }	
                
                if(transactionMap.get(DAOConstants.REFERENCE_NO) != null)
                    transactionHistory.setNarrative3(((String) transactionMap.get(DAOConstants.REFERENCE_NO)).trim());
            	// modified  CR 5322
               /*if(!(bankCode.equalsIgnoreCase("0")||bankCode.equalsIgnoreCase("6")||bankCode.equalsIgnoreCase("A"))){
                	   	if(transactionMap.get("ref_no_1") != null)                		
                    	transactionHistory.setReferenceNo(((String) transactionMap.get("ref_no_1")).trim());   
                	   	logger.info("ref_no_1"+transactionMap.get("ref_no_1"));
                    if(transactionMap.get("branch_code_1") != null)
                       transactionHistory.setBranchCodeFromCore((String)transactionMap.get("branch_code_1"));
                       logger.info("branch_code_1"+transactionMap.get("branch_code_1"));
                }
                */
                /* setting the value from Account object */
                transactionHistory.setAccountNo(account.getAccountNo());
                transactionHistory.setBranchCode(account.getBranchCode());
                transactionHistoryList.add(i, transactionHistory);
                }else{
                	String insertFileName = "";
                	if(fileName != null && fileName.trim().length() >0){
                		insertFileName = fileName.substring(5,fileName.length());
                		logger.info("insertFileName :"+insertFileName);
              	        
                		String startDate = (String) request.get("START_DATE");
                		String endDate = (String) request.get("END_DATE");
                        logger.info("startDate="+startDate);
                        logger.info("endDate="+endDate);
                        logger.info("BranchCode="+account.getBranchCode());
                        logger.info("account Discription="+account.getProductDescription());
                        logger.info("insert sbi_lpr_input begin");
                        request.get("USER_NAME");
                        request.get("USER_ALIAS");
                        int types [] = { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                     	
                        
                        if(anaklynFlag!=null && anaklynFlag.equalsIgnoreCase("1"))
                        {
                        	Object[] params1 = {account.getUserAlias(),insertFileName,startDate,endDate,account.getBranchCode(),account.getAccountNo(),"account_statement","Pending",account.getProductType(),account.getProductDescription()};
                        	getJdbcTemplate().update("insert into sbi_lpr_input fields(USER_NAME,REQUEST_ID,PARAM1,PARAM2,PARAM3,PARAM4,REQUEST_TYPE,STATUS,PARAM6,PARAM5,CREATION_TIME) values (?,?,?,?,?,?,?,?,?,?,sysdate)",params1,types);
                        	logger.info("insert sbi_lpr_input anaklyn flow end");
                        }	
                        else
                        {
                        	 if(timeStamp != null  && timeStamp.equals("yes") && account.getProductType() != null && !account.getProductType().equals(DAOConstants.LOANACCOUNT))
                        	 {
	                        	Object[] params2 = {account.getUserName(),insertFileName,startDate,endDate,account.getBranchCode(),account.getAccountNo(),"account_statement","Pending",account.getProductType(),account.getProductDescription(),timeStamp};
	                        	int timeStampTypes [] = { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
	                		    getJdbcTemplate().update("insert into sbi_lpr_input fields(USER_NAME,REQUEST_ID,PARAM1,PARAM2,PARAM3,PARAM4,REQUEST_TYPE,STATUS,PARAM6,PARAM5,PARAM7,CREATION_TIME) values (?,?,?,?,?,?,?,?,?,?,?,sysdate)",params2,timeStampTypes);
	                		    logger.info("insert sbi_lpr_input end");
                        	 }
                        	 else
                        	{
                        		 Object[] params2 = {account.getUserName(),insertFileName,startDate,endDate,account.getBranchCode(),account.getAccountNo(),"account_statement","Pending",account.getProductType(),account.getProductDescription()};
                        		 getJdbcTemplate().update("insert into sbi_lpr_input fields(USER_NAME,REQUEST_ID,PARAM1,PARAM2,PARAM3,PARAM4,REQUEST_TYPE,STATUS,PARAM6,PARAM5,CREATION_TIME) values (?,?,?,?,?,?,?,?,?,?,sysdate)",params2,types);
                        		 logger.info("insert sbi_lpr_input end");
                        	}
                        }
                    }
                }
                }
            }
        }
            
        if(logger.isDebugEnabled())
        logger.debug("Result List : " + transactionHistoryList);
        logger.info("getTransactionsFromCore(Map request, Account account) method end");
        return transactionHistoryList;
    }

    /**
     * TODO retrive the inputparameter and create a
     * CallableStatementCreatorFactory object
     * 
     * @param inParameters
     * @param procedureName
     * @return List 
     */
    private List getTransactionfromDB(Map inParameters, String procedureName, String identification)
            throws DAOException {
        logger.info("getTransactionfromDB(Map inParameters, String procedureName) method  begin");
        List parameterList = new ArrayList();
        List resultList = null;
        //logger.info(" Procedurer  Name : " + procedureName);
        try {
            parameterList.add(new SqlOutParameter("REF_CURSOR", OracleTypes.CURSOR, new TransactionHistoryRowMapper()));
            parameterList.add(new SqlParameter(DAOConstants.ACCOUNT_NO, Types.VARCHAR));
            parameterList.add(new SqlParameter(DAOConstants.BRANCH_CODE, Types.VARCHAR));
            parameterList.add(new SqlParameter(DAOConstants.FROM_DATE, Types.VARCHAR));
            parameterList.add(new SqlParameter(DAOConstants.TO_DATE, Types.VARCHAR));

            if (identification.equalsIgnoreCase("TransactionWithAmount")) {

                logger.info("Data fetching for Transaction Detail");
                parameterList.add(new SqlParameter(DAOConstants.FROMAMOUNT, Types.DOUBLE));
                parameterList.add(new SqlParameter(DAOConstants.TOAMOUNT, Types.DOUBLE));
                parameterList.add(new SqlParameter(DAOConstants.TTYPE, Types.VARCHAR));
            }
            else {
                parameterList.add(new SqlParameter(DAOConstants.BALANCE, Types.NUMERIC));
            }
            if(inParameters.get(DAOConstants.CORPORATE_ID) != null)
            	parameterList.add(new SqlParameter(DAOConstants.CORPORATE_ID, Types.VARCHAR));

            CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(procedureName,
                    parameterList);
            CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParameters);
            Map resultset = getJdbcTemplate().call(callableStatement, parameterList);
            resultList = (List) resultset.get("REF_CURSOR");
            /*
             * CallableStatementCreatorFactory statementFactory = new
             * CallableStatementCreatorFactory("{call " + procedureName +
             * "(?,?,?,?,?,?)}", parameterList);
             * 
             * CallableStatementCreator callableStatement =
             * statementFactory.newCallableStatementCreator(inParameters); Map
             * resultset = getJdbcTemplate().call(callableStatement,
             * parameterList); resultList = (List) resultset.get("REF_CURSOR");
             */

        }
        catch (DataAccessException exp) {
            
            DAOException.throwException(ErrorConstants.FATAL_ERROR1_CODE, exp);
            

        }
        if (logger.isDebugEnabled()) {
            logger.debug("Result List: " + resultList);
        }
        logger.info("getTransactionfromDB(Map inParameters, String procedureName) method end");
        return resultList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.sbi.dao.TransactionHistoryDAO#findTransctionTypeCode()
     */
    public Map findTransctionTypeCode() {
        logger.info("findTransctionTypeCode() " + LoggingConstants.METHODBEGIN);
        try {
            Map data = new HashMap();
            List transactionType = getJdbcTemplate()
            .query("select ttype_code,ttype_definition  from SBI_TTYPE_DEFINITION",
                            new TransactionTypeCodeRowMapper());

            if (transactionType != null && transactionType.size() > 0) {
                data = (Map) transactionType.get(0);
            }
            logger.info("findTransctionTypeCode() " + LoggingConstants.METHODEND);
            return data;
        }
        catch (DataAccessException ex) {
            
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            
        }
        return null;
    }

    /**
     * TODO This class is used to build TransactionHistory object using
     * Rowmapper
     * 
     * @version 1.0
     * @author Satyam Computer Services Ltd.,
     */
    class TransactionHistoryRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {
            TransactionHistory transactionHistory = new TransactionHistory();
            transactionHistory.setAccountNo(rs.getString(SQLConstants.ACCOUNT_NO)); // "ACCOUNT_NO"
            transactionHistory.setBranchCode(rs.getString(SQLConstants.BRANCH_CODE)); // "BRANCH_CODE"
            transactionHistory.setAmount(new Double(rs.getDouble(SQLConstants.AMOUNT))); // "AMOUNT"
            transactionHistory.setCreationTime(rs.getTimestamp(SQLConstants.CREATION_TIME)); // "CREATION_TIME"
            transactionHistory.setNarrative1(rs.getString(SQLConstants.NARRATIVE1)); // "NARRATIVE1"
            transactionHistory.setNarrative2(rs.getString(SQLConstants.NARRATIVE2));
            transactionHistory.setNarrative3(rs.getString(SQLConstants.NARRATIVE3)); // "REFERENCE_NO"
            transactionHistory.setReferenceNo(rs.getString(SQLConstants.REFERENCE_NO));
            transactionHistory.setTransactionCount(new Integer(rs.getInt(SQLConstants.TRANSACTION_COUNT)));
            transactionHistory.setTransactionDate(rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
            transactionHistory.setTTypeCode(rs.getString(SQLConstants.TXN_TYPE_CODE)); // TTYPE_CODE
            transactionHistory.setValueDate(rs.getTimestamp(SQLConstants.DATE_VALUE)); // DATE_VALUE
            transactionHistory.setBalance(new Double(rs.getDouble(SQLConstants.BALANCE)));
            return transactionHistory;
        }

    }

    class ChequeStatusRowMapper implements RowMapper {

        public Object mapRow(ResultSet rs, int index) throws SQLException {

            ChequeStatus chequeStatus = new ChequeStatus();

            chequeStatus.setAccountno(rs.getString(SQLConstants.ACCOUNT_NO));
            chequeStatus.setAmount(new Float(rs.getString(SQLConstants.AMOUNT)));
            chequeStatus.setBranchcode(rs.getString(SQLConstants.BRANCH_CODE));
            // chequeStatus.setReasonStoppage(rs.getString(SQLConstants.REASON_STOPPAGE));
            chequeStatus.setChequeno(rs.getString(SQLConstants.REFERENCE_NO));
            chequeStatus.setStopdate(rs.getTimestamp(SQLConstants.TRANSACTION_DATE));
            chequeStatus.setStatus("Cheque(s) are paid");

            return chequeStatus;
        }
    }

    class TransactionTypeCodeRowMapper implements RowMapper {
        Map typeCodeData = new HashMap();

        public Object mapRow(ResultSet rs, int index) throws SQLException {
            typeCodeData.put(rs.getString(1), rs.getString(2));
            return typeCodeData;
        }
    }

    public List findLatestBalance(Account account) throws DAOException {

        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        String sequenceNumber = null;

        if (account != null) {

            logger.info("findLatestBalance(Account account) method begin");
            if (account.getBankSystem().equalsIgnoreCase(DAOConstants.BANK_MASTER)) {

                inParameters.put("ACC_NO", account.getAccountNo());
                inParameters.put("BR_CODE", account.getBranchCode());
                inParameters.put("LAST_BUT", "0");
                inParameters.put("NO_TXN", "5");
                inParameters.put("txnno", "333333");
                int sequenceNo = getJdbcTemplate().queryForInt("select CURRBALREF.NEXTVAL from dual");
                sequenceNumber = "" + sequenceNo;
                inParameters.put("BREF", sequenceNumber.trim());
                ///logger.info("Sequence Number : " + sequenceNumber);
               // logger.info("Get the TransactionHistory from SwitchDAOImpl");
                transactionHistoryList = getTransactionsFromSwitch(inParameters, account);

            }
            else if (account.getBankSystem().equalsIgnoreCase(DAOConstants.CORE)) {
                if (account.getProductType().equals(DAOConstants.LOANACCOUNT)) {
                    inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_LOAN);
                }
                else {
                    inParameters.put("txnno", DAOConstants.TXN_ENQUIRY_DEPOSIT);
                    inParameters.put("fin_txn_type", "");
                }
                //logger.info("Get the TransactionHistory from  Bank System : " + account.getBankSystem());
                inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo());
                inParameters.put(DAOConstants.TXN_IDENTIFIER, "0");
                inParameters.put(DAOConstants.CORE_START_DATE, "");
                inParameters.put(DAOConstants.CORE_END_DATE, "");
                inParameters.put(DAOConstants.CORE_FROM_AMOUNT, "");
                inParameters.put(DAOConstants.CORE_TO_AMOUNT, "");
                inParameters.put("bankCode",account.getBranchCode().substring(0,1));
                transactionHistoryList = getTransactionsFromCore(inParameters, account);
                if(logger.isDebugEnabled())
                logger.debug("Get the TransactionHistory from Core " + transactionHistoryList);
            }
            logger.info("findLatestBalance(Account account) method  end");
            return transactionHistoryList;
        }
        else {
            DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

    private List getTransactionsFromSwitch(Map request, Account account) throws DAOException

    {
        logger.info("getTransactionsFromSwitch(Map request, Account account) begin");
        List responseList = switchDAOImpl.getDataFromBankSystem(request);
        Map transactionMap = null;
        List transactionHistoryList = null;
        if (responseList != null && responseList.size() > 0) {
            transactionHistoryList = new ArrayList();
            for (int i = 0; i < responseList.size(); i++) {
                TransactionHistory transactionHistory = new TransactionHistory();
                transactionMap = (Map) responseList.get(i);

                /*
                 * setting values from swit response to TransactionHistory
                 * object
                 */
                
                String status =  (String)transactionMap.get("status");
                
                if(status.equalsIgnoreCase("00")){
                 
                transactionHistory.setAmount(StringUtils.emptyStringCheckForDouble(((String) transactionMap
                        .get("TXN_AMT"))));
                transactionHistory.setNarrative1((String) transactionMap.get("TXN_NAR1"));
                transactionHistory.setNarrative2((String) transactionMap.get("TXN_NAR2"));
                transactionHistory.setTransactionDate((StringUtils.responseStringToTimestamp((String) transactionMap
                        .get("TXN_DATE"))));
                transactionHistory
                        .setBalance(StringUtils.emptyStringCheckForDouble((String) transactionMap.get("BAL")));
                transactionHistory.setReferenceNo(((String) transactionMap.get("TXN_REF")).trim());
                /* setting the value from Account object */
                transactionHistory.setAccountNo(account.getAccountNo());
                transactionHistory.setBranchCode(account.getBranchCode());
                transactionHistoryList.add(i, transactionHistory);
                }else
                	DAOException.throwException(status);
             

                
            }
        }
        if(logger.isDebugEnabled())
        logger.debug("Result List : " + transactionHistoryList);
        logger.info("getTransactionsFromCore(Map request, Account account) method end");
        return transactionHistoryList;
    }

    public Timestamp findUpdatedDateForNonCore(String branchCode) {
        String query = "select LAST_UPDATED_DATE from sbi_branch_master where branch_code = ?";
        Timestamp updatedDate = null; 
        Object[] params = {branchCode};
        try{
            updatedDate = (Timestamp)getJdbcTemplate().queryForObject(query,params,Timestamp.class);
        }catch(DataAccessException dataAccessException){
            logger.info("Unable to retrive the Date from sbi_branch_master");
        }
        return updatedDate;
    }
    
    // IR 71227
    
    public List findTransactionHistory(Account account, Timestamp fromDate,
			Timestamp toDate, String fromAmount, String toAmount) throws DAOException {
        logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, " +
        		"Double fromAmount,Double toAmount) method begin");
        logger.info("Account  : " + account + ", From Date:" + fromDate	+ ", To Date  :" + toDate 
        		+ ", From Amount   :" + fromAmount + "To Amount   :" + toAmount);

        List transactionHistoryList = new ArrayList();
        Map inParameters = new HashMap();
        if (account != null) {
            try {
                    String coreFromDate = null;
                    String coreTodate = null;
                    if (toDate != null) {
                        coreTodate = new SimpleDateFormat("ddMMyyyy").format(toDate);
                    }
                    if (toDate != null) {
                        coreFromDate = new SimpleDateFormat("ddMMyyyy").format(fromDate);
                    }

                    inParameters.put(DAOConstants.TXNNO, DAOConstants.BROKER_ACCOUNT_STATEMENT_TXNNO); // key
                    inParameters.put(DAOConstants.CORE_ACCOUNT_NO, account.getAccountNo()); // "account_no"
                    inParameters.put(DAOConstants.TXN_IDENTIFIER, "2"); // "txn_identifier"
                    inParameters.put(DAOConstants.CORE_START_DATE, coreFromDate); // "start_date"
                    inParameters.put(DAOConstants.CORE_END_DATE, coreTodate); // "end_date"
                    inParameters.put(DAOConstants.CORE_FROM_AMOUNT, fromAmount+"+"); // "from_amt"
                    inParameters.put(DAOConstants.CORE_TO_AMOUNT, toAmount+"+"); // "to_amt"
                    inParameters.put("bankCode",account.getBranchCode().substring(0,1));
                    transactionHistoryList = getBrokerAccountTransactionsFromCore(inParameters, account);
                    logger.info("findTransactionHistory(Account account, Timestamp fromDate, Timestamp toDate, " +
                    		"Double fromAmount,Double toAmount) method ends");
                return transactionHistoryList;

            }
            catch (DataAccessException ex) {
                DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            logger.error("Input Parameter Account" + account);
            DAOException.throwException(ErrorConstants.INPUT_ERROR2_CODE);
        }
        return null;

    }
    
    public List getBrokerAccountTransactionsFromCore(Map request, Account account) throws DAOException {
        logger.info("getBrokerAccountTransactionsFromCore(Map request, Account account) begin");

        List responseList = coreDAOImpl.getDataFromBankSystem(request);
        Map transactionMap = null;
        List transactionHistoryList = null;
        if (responseList != null && responseList.size() > 0) {
            transactionHistoryList = new ArrayList();
            for (int i = 0; i < responseList.size(); i++) {
                transactionMap = (Map) responseList.get(i);
                
                String status = null;
                String errorCode = null;
                String branchCode =account.getBranchCode();
                String bankCode =branchCode.substring(0, 1);
                
                if(transactionMap.get("status") != null)
                	status = (String)transactionMap.get("status");
                if(transactionMap.get("error_code") != null){
                	errorCode = (String)transactionMap.get("error_code");
                	status = errorCode; 
                }
                
                if(status == null && errorCode == null){
                    String fileName = (String)transactionMap.get("filename");
                if(fileName.charAt(0) != ':'){ 
                	BrokerAccountDetails transactionHistory = new BrokerAccountDetails();
	                /*
	                 * setting values from Core response to TransactionHistory object 
	                 */
                	transactionHistory.setAccountDescription(account.getProductDescription());
                	transactionHistory.setTransactionDate(StringUtils.coreDateToTimestamp((String) transactionMap.get(DAOConstants.TRANSACTION_DATE)));
                	transactionHistory.setClearingDate(StringUtils.coreDateToTimestamp((String) transactionMap.get(DAOConstants.CLEARING_DATE)));
                	transactionHistory.setTransactingBranch(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.TRANSACTING_BRANCH)));
                	transactionHistory.setTransactionAmount(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.TRANSACTION_AMOUNT)));
                	transactionHistory.setChequeNo(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.CHEQUE_NO)));
                	transactionHistory.setNarration(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.NARRATION)));
                	transactionHistory.setClientCode(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.CLIENT_CODE)));
                	transactionHistory.setClientName(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.CLIENT_NAME)));
                	transactionHistory.setDraweeBank(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.DRAWEE_BANK)));
                	transactionHistory.setDepositSlipNo(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.DEPOSIT_SLIP_NO)));
                	transactionHistory.setDraweeAccount(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.DRAWEE_ACCOUNT)));
                	transactionHistory.setTransactionDesc(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.TRANSACTION_DESC)));
                	transactionHistory.setFilename(StringUtils.emptyCheck((String) transactionMap.get(DAOConstants.FILENAME)));
                	transactionHistoryList.add(i, transactionHistory);
                }else{
                	String insertFileName = "";
                	if(fileName != null && fileName.trim().length() >0){
                		insertFileName = fileName.substring(1,fileName.length());
                		logger.info("Core Response FileName :"+insertFileName);
                		String startDate = (String) request.get("start_date");
                		String endDate = (String) request.get("end_date");
                        logger.info("Insert sbi_lpr_input Begin ");
                        logger.info("startDate : "+ startDate + ", endDate : " + endDate + ", BranchCode : " + account.getBranchCode() + ", account Discription="+account.getProductDescription());
                		Object[] params = {account.getUserName(),insertFileName,startDate,endDate,account.getBranchCode(),account.getAccountNo(),"broker_account_stmt","Pending",account.getProductType(),account.getProductDescription()};
                		int types [] = { Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                 		getJdbcTemplate().update("insert into sbi_lpr_input fields(USER_NAME,REQUEST_ID,PARAM1,PARAM2,PARAM3,PARAM4,REQUEST_TYPE,STATUS,PARAM6,PARAM5,CREATION_TIME) values (?,?,?,?,?,?,?,?,?,?,sysdate)",params,types);
                        logger.info("Insert sbi_lpr_input End ");
                	}
                }
                }
            }
        }
            
        if(logger.isDebugEnabled())
        logger.debug("Result List : " + transactionHistoryList);
        logger.info("getBrokerAccountTransactionsFromCore(Map request, Account account) method end");
        return transactionHistoryList;
    }
    
    /**
     * TODO
     * 
     * @param BankSystemDAO
     *            type object injection done here
     */
    public void setCoreDAOImpl(BankSystemDAO coreDAOImpl) {
        this.coreDAOImpl = coreDAOImpl;
    }

    public void setSwitchDAOImpl(BankSystemDAO switchDAOImpl) {
        this.switchDAOImpl = switchDAOImpl;
    }

}
 