package com.sbi.common.dao;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.RegMobileNoDetails;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.dao.ErrorConstants;
   
public class RegisterMobileNoDAOImpl extends JdbcDaoSupport implements RegisterMobileNoDAO{
	
	  protected final Logger logger = Logger.getLogger(getClass());
	  
	   public RegMobileNoDetails insertRegisterMobileNoDetails(Integer userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,int userRole,String cororateId,String userAlias,String friendlyName) throws DAOException
	    {
	        logger.info("int insertRegisterMobileNoDetails( String corpID )METHODBEGIN");
	        logger.info("UserId :" + userId+"ContryCode :"+contryCode+"MobileNo :"+mobileNo+"OldMobileNo :"+oldMobileNo+"ModifyUser :"+modifyUser+"BranchCode :"+branchCode+"UserRole :"+userRole+"friendlyName :"+friendlyName);
	        String newMobileNo = contryCode+"|"+mobileNo;
	        String exMobileNo= oldMobileNo;
	        if(exMobileNo == null || exMobileNo == "" ){
	        	exMobileNo ="";
	        }
	        int status =0;
	        RegMobileNoDetails regMobileNoDetails = new RegMobileNoDetails();
            String query="select 'CMR' || lpad(EHS_SEQUENCE.NEXTVAL,9,'0')reference_no from dual";
            String refferenceNo =(String)getJdbcTemplate().queryForObject(query,String.class);
            int count=0;
            String queryforCount;
	        if (userId != null && mobileNo !=null && !mobileNo.trim().equalsIgnoreCase(""))
	        {
	            Object[] Parameter = new Object[] {userId,exMobileNo,newMobileNo,refferenceNo,branchCode,userRole,cororateId,userAlias,friendlyName};
	            Object[]  countparams = new Object[] {userId};
	            queryforCount = "select count(1) from sbicorp_user_mobile_no where user_id=? AND status='Pending'";
	            count = getJdbcTemplate().queryForInt(queryforCount,countparams);
	            logger.info("count :"+count);
	            if(count == 0){
	            String queryforreg_mobile_no="INSERT INTO sbicorp_user_mobile_no (USER_ID,OLD_MOBILE_NO,NEW_MOBILE_NO,STATUS,CREATION_TIME,LAST_MOD_TIME,REFERENCE_NO,BRANCH_CODE,USER_ROLE,CORPORATE_ID,CREATED_BY,FRIENDLY_NAME)values(?,?,?,'Pending',sysdate,sysdate,?,?,?,?,?,?)";
	            status = getJdbcTemplate().update(queryforreg_mobile_no,Parameter);
	            logger.info("status " + status);
	            }else{
	            	DAOException
					.throwException(com.sbi.common.dao.ErrorConstants.PENDINT_REQ_ERROR_CODE);
	            }	                
               if(status == 1){
            	   logger.info("refferenceNo :::"+refferenceNo);
            	   regMobileNoDetails.setReferenceNo(refferenceNo);
            	   regMobileNoDetails.setMobileNo(mobileNo);
            	   regMobileNoDetails.setUserRole(String.valueOf(userRole));
               }
                if (logger.isDebugEnabled())
                {
                    logger.debug("status :" + status);
                }

	          
			}else{
				DAOException
				.throwException(ErrorConstants.INPUT_NULL_ERROR_CODE);
			}
	        logger.info("insertRegisterMobileNoDetails(int userId,String contryCode,String mobileNo,String oldMobileNo,String modifyUser,String branchCode,int userRole,String cororateId,String userAlias)"+ LoggingConstants.METHODEND);
	        return regMobileNoDetails;

	    }


}
