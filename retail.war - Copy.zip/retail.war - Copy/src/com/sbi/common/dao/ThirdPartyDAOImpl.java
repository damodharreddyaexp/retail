/*
 * ThirdPartyDAOImpl.java
 * Created on Dec 9, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 9, 2005 SG33414 - Initial Creation
package com.sbi.common.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.CallableStatementCreatorFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
     
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.DAOException;
import com.sbi.common.dao.SQLConstants;
import com.sbi.common.model.Account;
import com.sbi.common.model.ApproveDelTPModelStatus;
import com.sbi.common.model.CorporateFile;
import com.sbi.common.model.ApproveDelTPModel;
import com.sbi.common.rtgs.model.CorporateTP;
import com.sbi.common.utils.LoggingConstants;

public class ThirdPartyDAOImpl extends JdbcDaoSupport implements ThirdPartyDAO {

    protected final Logger logger = Logger.getLogger(getClass());
    
    private static final String CORP_ID="corpId";
    
    private static final String CREDIT_TYPE = "creditType";
    
    private static final String ACCOUNT_DETAILS = "Select A.ACCOUNT_NICKNAME ,A.ACCOUNT_NO,A.BRANCH_CODE,a.product_type,a.product_code,a.product_Desc  from SBICORP_CA_ACCOUNT_MAP A, SBICORP_CA_CORPORATE_MAP B where A.status=1 and B.status=1 and A.Ca_user=B.ca_user  and B.corporate_id=?";
   
    public final static String PR_GET_CREDIT_ACCOUNT_DTLS = "{call PR_GET_CREDIT_ACCOUNT_DTLS(?,?,?,?)}";
	

    /**
     * This method is used to add the DDBeneficiary details to SBICORP_THIRD_PARTY table
     * and returns ThirdParty Object
     * 
     */

   
    public String verify3PforDeletion(String corpID) throws DAOException
    {
        logger.info("int verify3PforAdmin( String corpID )METHODBEGIN");
        logger.info("corpID" + corpID);
        int status = 0;
        if (corpID != null && !corpID.trim().equalsIgnoreCase(""))
        {

            try
            {
                Object[] Parameter = new Object[] { corpID };
                logger.info("bEFORE qUERY");
                //status =  getJdbcTemplate().queryForObject("select nvl(admin_add_3p,'1') status1 from sbicorp_corporate_profile where corporate_id= ? and status=1",Parameter,new StatusRowMapper());
                status = getJdbcTemplate()
                        .queryForInt(
                                "select nvl(admin_add_3p,'1') status1 from sbicorp_corporate_profile where corporate_id= ? and status=1",
                                Parameter);
                logger.info("astatus____________ " + status);

                logger.info("status " + status);
                if (logger.isDebugEnabled())
                {
                    logger.debug("status :" + status);
                }

            }
            catch (DAOException exception)
            {

                DAOException.throwException("F001", exception);
            }
        }

        else
        {

            DAOException.throwException("F001");
        }

        return String.valueOf(status);

    }

   
    public CorporateFile[] findTPDelFiles(String userName,String startDate,String endDate,Integer userRole) {
        
        logger.info("findTPDelFiles( String userName )" + LoggingConstants.METHODBEGIN);
        logger.info("userName >>>>>>>>." + userName);
        if (logger.isDebugEnabled())
            logger.debug("userName :" + userName);
            logger.info("startDate :"+ startDate);
            logger.info("endDate :"+ endDate);
            logger.info("user role:"+ userRole);
        List result = new ArrayList();

        if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && !userRole.toString().equalsIgnoreCase("42")) {

            try {
                
                Object[] parameters = new Object[] {userName,startDate,endDate};
                result = getJdbcTemplate().query(SQLConstants.CORPORATE_DEL_FILE,parameters, new CorporateFileRowMapper());
               
                
                logger.info("Result size in DAO00001--->"+result);
                
                
                if (result.size() > 0 &&  result != null) {
                    logger.info("Result size in side if-->"+result.size());

                    CorporateFile[] corporateFileArray = new CorporateFile[result.size()];
                                    
                    for (int i = 0; i < result.size(); i++) {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }
                    logger.info("findTPDelFiles( String userName )"+ LoggingConstants.METHODEND);
                    return corporateFileArray;
                }
                
                
            } catch (DataAccessException ex) {
                DAOException.throwException(
                        ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        } 
        
        else if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && userRole.toString().equalsIgnoreCase("42")) {

            try {
          
                Object[] parameters = new Object[] {userName,userName,startDate,endDate};
                result = getJdbcTemplate().query(SQLConstants.CORPORATE_DEL_FILE_APPR,parameters, new CorporateFileRowMapper());
               
                
                logger.info("Result size in DAO000002--->"+result);
                
                
                if (result.size() > 0 &&  result != null) {
                    logger.info("Result size in side if-->"+result.size());

                    CorporateFile[] corporateFileArray = new CorporateFile[result.size()];
                                    
                    for (int i = 0; i < result.size(); i++) {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }
                    logger.info("findTPDelFiles( String userName )"+ LoggingConstants.METHODEND);
                    return corporateFileArray;
                }
                
                
            } catch (DataAccessException ex) {
                DAOException.throwException(
                        ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException
                    .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

public CorporateFile[] findTPDelFilesView(String userName,String startDate,String endDate,Integer userRole) {
        
        logger.info("findTPDelFilesView( String userName )" + LoggingConstants.METHODBEGIN);
        logger.info("userName >>>>>>>>." + userName+","+"start date "+startDate+","+"end date "+endDate);
                    if (logger.isDebugEnabled())
            logger.debug("userName :" + userName);

        List result = new ArrayList();

        if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && startDate != null && endDate != null && !userRole.toString().equalsIgnoreCase("42")) {

            try {
                Object[] parameters = new Object[] {userName,startDate,endDate};
                result = getJdbcTemplate().query(SQLConstants.CORPORATE_DEL_FILE_VIEW,parameters, new CorporateFileRowMapper());
               
                
                logger.info("Result size in DAO--->"+result);
                
                
                if (result != null && result.size() > 0 ) {
                    logger.info("Result size in side if-->"+result.size());

                    CorporateFile[] corporateFileArray = new CorporateFile[result.size()];
                                    
                    for (int i = 0; i < result.size(); i++) {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }
                    logger.info("findTPDelFilesView( String userName )"+ LoggingConstants.METHODEND);
                    return corporateFileArray;
                }
                
                
            } catch (DataAccessException ex) {
                DAOException.throwException(
                        ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else    if (userName != null && !userName.trim().equalsIgnoreCase(DAOConstants.EMPTY) && startDate != null && endDate != null && userRole.toString().equalsIgnoreCase("42")) {

            try {
                Object[] parameters = new Object[] {userName,userName,startDate,endDate};
                result = getJdbcTemplate().query(SQLConstants.CORPORATE_DEL_FILE_VIEW_APPR,parameters, new CorporateFileRowMapper());
               
                
                logger.info("Result size in DAO--->"+result);
                
                
                if (result != null && result.size() > 0 ) {
                    logger.info("Result size in side if-->"+result.size());

                    CorporateFile[] corporateFileArray = new CorporateFile[result.size()];
                                    
                    for (int i = 0; i < result.size(); i++) {
                        corporateFileArray[i] = (CorporateFile) result.get(i);
                    }
                    logger.info("findTPDelFilesView( String userName )"+ LoggingConstants.METHODEND);
                    return corporateFileArray;
                }
                
                
            } catch (DataAccessException ex) {
                DAOException.throwException(
                        ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        }
        else {
            DAOException
                    .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;

    }

  

  

 
    /**
     * Update sbicorp_third_party set status=1 ,user_name='"+Session.username+"'
     * where oid in (approvedoid list) and branch_code in (select branch_code
     * from sbi_branch_master)
     * 
     * 
     * Update sbicorp_third_party set status=0 ,user_name='"+Session.username+"'
     * where oid in ("unapprovedOID's list")
     * 
     * 
     * 
     */  
  
    /**
     * this method is used to find Branchcodes
     * and returns list of branchcodes
     */
   
    public ApproveDelTPModel[] findDelTPsByFile(String userName, String fileName) {
        logger.info("findDelTPsByFile( String fileName, String userName )"
                + LoggingConstants.METHODBEGIN);
        logger.info("fileName :" + fileName);
        logger.info("userName :" + userName);

        if (logger.isDebugEnabled()) {
            logger.debug("fileName :" + fileName);
            logger.debug("userName:" + userName);
        }
        if (fileName != null && userName != null) {

            try {
                Object[] params = new Object[] {fileName};
                
                for(int i =0;i<params.length;i++)
                    logger.info("data :"+params[i]);
                
                List result = getJdbcTemplate().query(SQLConstants.FIND_DEL_TP_BY_FILE, params,new CorporateDelTPRowMapper());
                logger.info("result Approve Del TP -------:" + result.size());
                if (logger.isDebugEnabled()) {
                    //logger.debug("result  :" + result);
                }

                ApproveDelTPModel[] corporateDelTPArray = new ApproveDelTPModel[result.size()];
                for (int i = 0; i < result.size(); i++) {
                    corporateDelTPArray[i] = (ApproveDelTPModel) result.get(i);
                }
                logger.info("corporateDelTPArray :" + corporateDelTPArray );
                logger.info("findDelTPsByFile( String fileName, String userName)"
                        + LoggingConstants.METHODEND);
                return corporateDelTPArray;

            } catch (DataAccessException ex) {
                DAOException.throwException(
                        ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
            }
        } else {
            DAOException
                    .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return null;
    }

     public ApproveDelTPModelStatus[] findDelTPsByStatus(String userName, String fileName,String[] approvedOIDs) {
            logger.info("ffindDelTPsByStatus( String fileName, String userName )"+ LoggingConstants.METHODBEGIN);
            logger.info("fileName :" + fileName);
            logger.info("userName :" + userName);
             String appIds="(";
      

            if (logger.isDebugEnabled()) {
                logger.debug("fileName :" + fileName);
                logger.debug("userName:" + userName);
            }
           
            
            
            if (fileName != null && userName != null) {
                if (approvedOIDs != null) {
                    for (int i = 0; i < approvedOIDs.length; i++) {
                        appIds=appIds+"'"+approvedOIDs[i]+"',";
                    }
                    appIds=appIds+")";
                    appIds=appIds.replace(",)",")");
                    try {
                        //int approvedCount = 0;
                        
                                           
                           
                            
                            Object[] approvedParams = new Object[] {fileName };
                        
                            
                            
                            String replacedString=SQLConstants.FIND_DEL_TP_BY_FILE_STATUS.replaceAll("#tobereplaced#",appIds);
                            
                            logger.info("replacedString"+replacedString);
                            
                            
                            List result = getJdbcTemplate().query(replacedString, approvedParams,new CorporateDelTPStatusRowMapper());   
                            logger.info("result Approve Del TP -------:" + result.size());
                            if (logger.isDebugEnabled()) {
                               
                               
                            }
                            ApproveDelTPModelStatus[] corporateDelTPArray = new ApproveDelTPModelStatus[result.size()];
                            for (int i = 0; i < result.size(); i++) {
                                corporateDelTPArray[i] = (ApproveDelTPModelStatus) result.get(i);
                            }
                            logger.info("corporateDelTPArray :" + corporateDelTPArray );
                            logger.info("findDelTPsByStatus( String fileName, String userName)"
                                  + LoggingConstants.METHODEND);         
                          
                        
                            
                        
                        return corporateDelTPArray;
                        
                    } catch (DataAccessException ex) {
                        DAOException.throwException(
                                ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
                    }

                }
             
            } else {
                DAOException
                        .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
            return null;
        }
     public ApproveDelTPModelStatus[] findDelTPsForView(String userName, String fileName) {
         logger.info("findDelTPsForView Status( String fileName, String userName )"+ LoggingConstants.METHODBEGIN);
         logger.info("fileName :" + fileName);
         logger.info("userName :" + userName);

         if (logger.isDebugEnabled()) {
             logger.debug("fileName :" + fileName);
             logger.debug("userName:" + userName);
         }
         if (fileName != null && userName != null) {

             try {
                 Object[] params = new Object[] {fileName};
                 
                 for(int i =0;i<params.length;i++)
                     logger.info("data :"+params[i]);
                 
                 List result = getJdbcTemplate().query(SQLConstants.FIND_DEL_TP_BY_FILE_VIEW, params,new CorporateDelTPStatusRowMapper());
                 logger.info("result Approve Del TP -------:" + result.size());
                 if (logger.isDebugEnabled()) {
                     
                 }
            logger.info("inside the");
                 ApproveDelTPModelStatus[] corporateDelTPArrayStatus = new ApproveDelTPModelStatus[result.size()];
                 for (int i = 0; i < result.size(); i++) {
                     corporateDelTPArrayStatus[i] = (ApproveDelTPModelStatus) result.get(i);
                 
                 }
                 logger.info("corporateDelTPArrayStatus :" + corporateDelTPArrayStatus );
                 logger.info("findDelTPsForView( String fileName, String userName)"
                         + LoggingConstants.METHODEND);
                 return corporateDelTPArrayStatus;

             } catch (DataAccessException ex) {
                 DAOException.throwException(
                         ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
             }
         } else {
             DAOException
                     .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
         return null;
     }








    /*
     * public class ThrirdPartyRowMapper implements RowMapper{ public Object
     * mapRow(ResultSet rs, int index) throws SQLException { ThirdParty
     * thirdParty=new ThirdParty();
     * 
     * //thirdParty.setCorporateID(rs.getString(DAOConstants.CORPORATE_ID));
     * thirdParty.setThirdPartyName(rs.getString(DAOConstants.NAME_THIRD_PARTY));
     * thirdParty.setAcctNo(rs.getString(DAOConstants.ACCOUNT_NO));
     * thirdParty.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
     * //thirdParty.setUploadUserName(rs.getString(DAOConstants.UPLOADER_USERNAME));
     * //thirdParty.setUserName(rs.getString(DAOConstants.USER_NAME));
     * logger.info("ThirdPartyName :"+thirdParty.getThirdPartyName());
     * logger.info("AcctNo :"+thirdParty.getAcctNo()); logger.info("BranchCode
     * :"+thirdParty.getBranchCode()); return thirdParty; } }
     */
    

    
      
    
    
    
    
    ////

        /** 
         * this method is used to update the state of the deleted files
         * and returns boolean value
         */
     public boolean updateDelTPState(String[] approvedOIDs,String userName) {
         logger
                 .info("updateDelTPState( Integer[] approvedOIDs)"
                         + LoggingConstants.METHODBEGIN);
         logger.info("approvedOIDs  :" + approvedOIDs.length);
              
                 if (!approvedOIDs[0].equals("-1")) {

             if (approvedOIDs != null) {
                 try {
                     int approvedCount = 0;
                     for (int i = 0; i < approvedOIDs.length; i++) {
                         
                    	 Long approverdIds = new Long(approvedOIDs[i]);
                         
                         Object[] approvedParams = new Object[] { userName,
                                 approverdIds };
                         logger.info("aprroved ids :"+approverdIds);
                         approvedCount = getJdbcTemplate().update(
                                 SQLConstants.UPDATE_DEL_TP_STATE_APPROVED,
                                 approvedParams);
                         
                     }

                 } catch (DataAccessException ex) {
                     DAOException.throwException(
                             ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
                 }

             }
         }

         return true;
     }
 
     //Added For CR 5390 Starts
     public List findApproveBeneficiary(String corpId,String userName,String type){
    	 logger.info(" findApproveBeneficiary(String corpId,String userName,String type) " + LoggingConstants.METHODBEGIN);         
         List resultList = new ArrayList();      
         
             Object[] param = new Object[] {corpId,userName };
             try {
                 if(type.equals("thirdparty"))
                	 resultList = getJdbcTemplate().query(SQLConstants.GET_APPROVE_TP, param, new CorporateTPRowMapper());
                 else if (type.equals("interbank"))
                	 resultList = getJdbcTemplate().query(SQLConstants.GET_APPROVE_RTGS, param, new CorporateRtgsRowMapper());
                 logger.info("Result List Size::"+resultList.size());
                 return resultList;
          
             } catch (DataAccessException exception) {
                 DAOException.throwException(
                         ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
             }         
         logger.info("findApproveBeneficiary(String corpId,String userName,String type) "+ LoggingConstants.METHODEND);
         return null;
     }
     public List getAlreadyAddedOids(String oids,String userName,String type){
    	 logger.info(" getAlreadyAddedOids(String oids,String userName,String type) " + LoggingConstants.METHODBEGIN);  
             Object[] param ;
             List oidsList=null;
             try {
                	 param= new Object[] {userName};
                	 if(type.equals("thirdparty"))
                		 oidsList=getJdbcTemplate().queryForList(SQLConstants.GET_TP_ALREADYADDED_OIDS.replaceAll("#tobereplace#", oids),param,String.class);                	 
                	 else if(type.equals("interbank"))
                	 	oidsList=getJdbcTemplate().queryForList(SQLConstants.GET_RTGS_ALREADYADDED_OIDS.replaceAll("#tobereplace#", oids),param,String.class);
                 return oidsList;
          
             } catch (DataAccessException exception) {
                 DAOException.throwException(
                         ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
             }         
         logger.info("getAlreadyAddedOids(String oids,String userName,String type) "+ LoggingConstants.METHODEND);
         return null;
     }
     public boolean approveBeneficiary(String userName,String approvedStatus,String remarks,String oids,String type, String corpID){
    	 logger.info(" approveBeneficiary(String userName,String approvedStatus,String remarks,String oids,String type)" + LoggingConstants.METHODBEGIN);
             Object[] param ;
             int status=0;
             try {
//                     param= new Object[] {approvedStatus,userName,remarks};
                     param= new Object[] {approvedStatus,userName,remarks,corpID};	/* Ramanan M - Corp Admin Paladion Security Changes */
                     if(type.equals("thirdparty")&& approvedStatus.equals("Approved")){
                	     status=getJdbcTemplate().update(SQLConstants.APPROVE_TP_BENEFICIARY.replaceAll("#tobereplace#", oids),param);
                     }if(type.equals("thirdparty")&& approvedStatus.equals("Rejected")){
                    	 status=getJdbcTemplate().update(SQLConstants.REJECT_TP_BENEFICIARY.replaceAll("#tobereplace#", oids),param);
                     }
                     else if(type.equals("interbank"))
                    	 status=getJdbcTemplate().update(SQLConstants.APPROVE_RTGS_BENEFICIARY.replaceAll("#tobereplace#", oids),param);
                	 logger.info("Number Of Rows Updated :"+status); 
                	 if(status > 0){
                		 return true;
                	 }else
                		 return false;                	
          
             } catch (DataAccessException exception) {
                 DAOException.throwException(
                         ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
             }         
         logger.info("approveBeneficiary(String userName,String approvedStatus,String remarks,String oids,String type) "+ LoggingConstants.METHODEND);
         return false;
     }
     
     /* Ramanan M - Corp Admin Paladion Security Changes */
     public List getBeneficiaryByOid(String oids,String type, String corporateID){
    	 logger.info(" getBeneficiaryByOid(String oids,String type) " + LoggingConstants.METHODBEGIN);         
         List resultList = new ArrayList(); 
             Object[] param = new Object[] { corporateID };	/* Ramanan M - Corp Admin Paladion Security Changes */
             try {
                if(type.equals("thirdparty"))
                	resultList = getJdbcTemplate().query(SQLConstants.GET_TP_BENEFICIARY_BY_OID.replaceAll("#tobereplace#", oids), param, new CorporateTPRowMapper());
                else if (type.equals("interbank"))
                	resultList = getJdbcTemplate().query(SQLConstants.GET_RTGS_BENEFICIARY_BY_OID.replaceAll("#tobereplace#", oids), param, new CorporateRtgsRowMapper());
                 logger.info("Result List Size::"+resultList.size());
                 return resultList;
          
             } catch (DataAccessException exception) {
                 DAOException.throwException(
                         ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
             }         
         logger.info("getBeneficiaryByOid(String oids,String type)) "+ LoggingConstants.METHODEND);
         return null;
     }
     public class CorporateTPRowMapper implements RowMapper {
        public Object mapRow(ResultSet rs, int index) throws SQLException {
             CorporateTP corporateTP = new CorporateTP();                       
             corporateTP.setOid(rs.getLong("OID")); 
             corporateTP.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));            
             corporateTP.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));             
             corporateTP.setName(rs.getString(DAOConstants.NAME_THIRD_PARTY));             
             corporateTP.setAddedBy(rs.getString("ADDED_BY"));             
             corporateTP.setProductCode(rs.getString("PRODUCT_CODE"));            
             corporateTP.setProductDesc(rs.getString("PRODUCT_DESC"));
             corporateTP.setAddedDate(rs.getTimestamp("CREATION_TIME"));
             corporateTP.setRemarks(rs.getString("REMARKS"));
             corporateTP.setApprovedStatus(rs.getString("APPROVAL_STATUS"));
            /* commented for  beneficary revamp with starts
             corporateTP.setMobileNo(rs.getString("MOBILE_NO"));//Added for CR-5603             
             corporateTP.setEmailId(rs.getString("EMAIL_ID"));//Added for CR-5603             
             commented for  beneficary revamp with ends*/             
             corporateTP.setEmployeeCode(rs.getString("OUTREF7"));//Added for CR-5603
             corporateTP.setBranchName(rs.getString("BRANCH_NAME")); // Added by  beneficary revamp
             
             
             return corporateTP;

         }          
     }
     public class CorporateRtgsRowMapper implements RowMapper {
         public Object mapRow(ResultSet rs, int index) throws SQLException {
             CorporateTP corporateTP = new CorporateTP();
        //     corporateTP.setOid(new Integer(rs.getInt("ID")));
             corporateTP.setOid(rs.getLong("ID"));
             corporateTP.setAccountNo(rs.getString("ACCOUNT_NUMBER"));
             corporateTP.setOutRef1(rs.getString("IFSC_CODE_RECEIVER"));
             corporateTP.setOutRef3(rs.getString("BRANCH_RECEIVER"));
             corporateTP.setOutRef2(rs.getString("BANK_RECEIVER"));
             corporateTP.setAddedBy(rs.getString("USER_NAME"));
             corporateTP.setRemarks(rs.getString("REJECTED_REASON"));
             corporateTP.setAddedDate(rs.getTimestamp("REGISTRATION_TIME"));
             corporateTP.setName(rs.getString("THIRD_PARTY_NAME"));
             corporateTP.setApprovedStatus(rs.getString("STATUS"));
             corporateTP.setMobileNo(rs.getString("PHONE_NO"));//Added for CR-5603
             corporateTP.setEmailId(rs.getString("EMAIL_ID"));//Added for CR-5603
             corporateTP.setEmployeeCode(rs.getString("EMP_CODE"));//Added for CR-5603
             corporateTP.setBranchName(rs.getString("BRANCH_NAME")); 
             return corporateTP;

         }          
     }
     //Added For CR 5390 Ends


  
    public class CorporateFileRowMapper implements RowMapper {
        /**
         * This method is used to map rows for CorporateFile
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            int i=0;
            String[] pages = new String[2];
            String fileName = rs.getString(DAOConstants.FILE_NAME);
            StringTokenizer st = new StringTokenizer(fileName,"/");
            
            /*while (st.hasMoreTokens()) {
                pages[i] = st.nextToken();
                i++;
            }*/
            st.nextToken();
            //String appFileName = pages[1];
            //logger.info("appFileName****#########");
    
            
            CorporateFile corporateFile = new CorporateFile();            
            corporateFile.setSno((rs.getString(DAOConstants.SNO)));
            corporateFile.setFileName(st.nextToken());
            corporateFile.setUploaderName(rs.getString(DAOConstants.USERNAME));
            corporateFile.setUploadedDate(rs.getTimestamp(DAOConstants.CREATION_TIME));
          
            return corporateFile;
        }   
    }  


    public class CorporateDelTPRowMapper implements RowMapper {
        /**
         * This method is used to map rows for CorporateDelTP
         */
        public Object mapRow(ResultSet rs, int index) throws SQLException {
            ApproveDelTPModel approveDelTPModel = new ApproveDelTPModel();
            approveDelTPModel.setAccountNo(rs.getString("BENIFICIARY_ACCOUNT"));
            approveDelTPModel.setBeneficiaryCode(rs.getString("BENIFICIARY_CODE"));
            approveDelTPModel.setBeneficiaryName(rs.getString("BENIFICIARY_NAME"));
            approveDelTPModel.setBranchCode(rs.getString("BENIFICIARY_BRANCH"));
            //approveDelTPModel.setRowID(new Integer(rs.getInt("ROW_ID")));
            approveDelTPModel.setRowID(rs.getLong("ROW_ID"));
            approveDelTPModel.setStatus(rs.getString("STATUS").toLowerCase());
            
            
            return approveDelTPModel;
        }
    }
    
    //Added by Sunjay S Galen
     public class CorporateDelTPStatusRowMapper implements RowMapper {
            
            public Object mapRow(ResultSet rs, int index) throws SQLException {
                ApproveDelTPModelStatus approveDelTPModelStatus = new ApproveDelTPModelStatus();
                approveDelTPModelStatus.setAccountNo(rs.getString("BENIFICIARY_ACCOUNT"));
                approveDelTPModelStatus.setBeneficiaryCode(rs.getString("BENIFICIARY_CODE"));
                approveDelTPModelStatus.setBeneficiaryName(rs.getString("BENIFICIARY_NAME"));
                approveDelTPModelStatus.setBranchCode(rs.getString("BENIFICIARY_BRANCH"));
                //approveDelTPModelStatus.setRowID(new Integer(rs.getInt("ROW_ID")));
                approveDelTPModelStatus.setRowID(rs.getLong("ROW_ID"));
                approveDelTPModelStatus.setStatus(rs.getString("STATUS").toLowerCase());
                return approveDelTPModelStatus;
            }
        }
     
	public List getHolidaysList(String bankCode) throws DAOException{
         logger.info("getHolidaysList method begins");
          String sql="select bank_code,initcap(to_char(trunc(holiday_date), 'DD-MON-YYYY')) h_date," +
                 "initcap(to_char(trunc(holiday_date), 'DAY')) day,initcap(holiday_description) holiday_description" +
                 " from SBI_RTGS_HOLIDAY_MASTER where to_char(trunc(holiday_date),'YYYY') >= to_char(trunc(sysdate),'YYYY') and bank_code=? order by holiday_date";
         List holidaysList=null;
         Object param[]={bankCode};
         if (logger.isDebugEnabled())
             logger.debug("getHolidays : retreiving the Holidays list from SBI_RTGS_HOLIDAY_MASTER");
         try{
             holidaysList=getJdbcTemplate().queryForList(sql,param);
             
         }catch (DataAccessException excep) {
             DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, excep);
         }
         logger.info("getHolidaysList method ends");
         return holidaysList;
         
     }
     public List findCreditAccount(String username,String corpId,String creditType) throws DAOException{
     	
     	logger.info("findCreditAccount(String username,String corpId,String creditType)" + LoggingConstants.METHODBEGIN);

         logger.info("username :" + username + "" + "corpId :" + corpId);
         List accList= null;  
         try {
               
                 Map inParams = new HashMap();
                 inParams.put(DAOConstants.USERNAME,username);
                 inParams.put(CORP_ID,corpId);
                 inParams.put(CREDIT_TYPE,creditType);
                

                 List parameterList = new ArrayList();
                 parameterList
                         .add(new SqlOutParameter(DAOConstants.OUTDATA, OracleTypes.CURSOR, new AccountRowMapper()));
                 parameterList.add(new SqlParameter(DAOConstants.USERNAME, Types.VARCHAR));
                 parameterList.add(new SqlParameter(CORP_ID,Types.VARCHAR));
                 parameterList.add(new SqlParameter(CREDIT_TYPE,Types.VARCHAR)); //DEMAND_DRAFT or THIRD_PARTY
                 
                 CallableStatementCreatorFactory statementFactory = new CallableStatementCreatorFactory(
                 		PR_GET_CREDIT_ACCOUNT_DTLS, parameterList);
                 CallableStatementCreator callableStatement = statementFactory.newCallableStatementCreator(inParams);
                 Map result = getJdbcTemplate().call(callableStatement, parameterList);
                 logger.info("result *****"+result);																	
                 accList = (List) result.get(DAOConstants.OUTDATA);
             }
             catch (DataAccessException ex) {
             	ex.printStackTrace();
                 DAOException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);

             }
             logger.info("findCreditAccount(String username,String corpId,String creditType)" + LoggingConstants.METHODBEGIN);
             
             logger.info("credit accList ::"+accList);
             
             return accList;
         }

     class AccountRowMapper implements RowMapper {
    	    public Object mapRow(ResultSet rs, int index) throws SQLException {
    	        Account acc = new Account();
    	        acc.setAccountNo(rs.getString(DAOConstants.ACCOUNT_NO));
    	        acc.setBranchCode(rs.getString(DAOConstants.BRANCH_CODE));
    	        
    	        if (rs.getString(DAOConstants.ACCOUNT_NICKNAME) != null
    	                && !((rs.getString(DAOConstants.ACCOUNT_NICKNAME)).trim()).equals(""))
    	            acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NICKNAME));
    	        else
    	            acc.setAccountNickName(rs.getString(DAOConstants.ACCOUNT_NO));
    	       
    	        acc.setProductCode(rs.getString(DAOConstants.PRODUCT_CODE));//If RTGS/NEFT it contains the Bank Name
    	        acc.setProductType(rs.getString("product_type"));//If RTGS/NEFT it contains the Branch Name
    	        acc.setProductDescription(rs.getString(DAOConstants.PRODUCT_DESC)); 
    	        
    	    	
    	        if (rs.getInt("coreFlag") == 0) {
    	            acc.setBankSystem(DAOConstants.CORE);
    	        }
    	        else
    	            acc.setBankSystem(DAOConstants.BANK_MASTER);
    	        
    	       
    	        
    	        try{
    	        	 
    	         	acc.setGrptFlag(rs.getString("GRPT"));//Added to set the GRPT flag.
    	         	logger.info("GRPT:"+rs.getString("GRPT"));
    	        	acc.setTxnType(rs.getString("TXN_TYPE"));
    	        	acc.setBusinessLineId(rs.getString("BUSINESS_LINE_ID"));
    	        	acc.setRtgsIFSCCode(rs.getString("RTGS_IFSC_CODE"));
    	        	acc.setNeftIFSCCode(rs.getString("NEFT_IFSC_CODE"));
    	        }catch (Exception e) {
    			
    	        	logger.info("AccountRowMapper Exception :"+e.getMessage());
    			}
    	        
    	        //System.out.println("AccountRowMapper.mapRow method end and it return account:" + acc.toString());
    	        return acc;
    	    }

    		
    	}
		
}
