/*
 * MerchantDAO.java
 * Created on May 22, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//May 22, 2006 srujana - Initial Creation
package com.sbi.common.dao;

import java.util.List;
import java.util.Map;

import com.sbi.common.exception.DAOException;
import com.sbi.common.model.DSCDetails;


public interface DigitalCertificateDAO
{
    public String updateRegistrationDetails(String userName, String branchCode,String serialNo,String corpID,String corpName,String moduleName) throws DAOException;
    
    public List getc11FormDetails(String referenceNo,String dscFunction) throws DAOException;
    
    public DSCDetails getDeactivationDetails(String userName,String serialNo,String secoption) throws DAOException;

    public boolean getDeactivationDSCertificate(String userName,String serialNo) throws DAOException;

	// public void updateRegistrationDetails(String userName, String serialNo) throws DAOException;
    
    public DSCDetails getDSCFormDetails(String referenceNo,String requestType) throws DAOException;
    
    public boolean updateSFAModeChangeDetails(Map inparam) throws DAOException;
    
    
    public DSCDetails getSFAModeChangeDetails(String userName) throws DAOException;

    public String updateReRegistrationDetails(String userName, String branchCode,String serialNo,String corpID,String corpName,String corpAddress) throws DAOException;
    
    public List getC11FormRegListDetails(String userName, String corporateID) throws DAOException;
    
    public List getC11FormReRegListDetails(String userName, String corporateID) throws DAOException;
    
    public int getRegisterPendingDetails(Map inparams) throws DAOException;
    
    boolean isDSCRegistered(String userName) throws DAOException;
    
    
}
