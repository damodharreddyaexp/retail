package com.sbi.common.bp;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.CorporateReportDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;

public class MISTransactionReportBP {
	protected final Logger logger = Logger.getLogger(getClass());
	
	private CorporateReportDAO corporateReportDAOImpl;
	
	private String reportToExcelCount;
   
    //5057 starts
	//modified for  corpuser paladion 
    public List getEchequesToDownload(String accountNo,String brCode,String fromDate,String toDate,String corporateId) {
        logger.info("getEchequesToDownload(String brCode, String accountNo,String fromDate,String toDate) corporateId- method begin");
        List echequeslst = null;
        try {
        	//modified for  corpuser paladion 
                echequeslst = corporateReportDAOImpl.retrieveEcheques(accountNo,brCode,fromDate,toDate,corporateId);
            } catch (DAOException exception) {
                SBIApplicationException.throwException(exception.getErrorCode(),
                        exception);
            }
        logger
                .info("getEchequesToDownload(String brCode, String accountNo,String fromDate,String toDate) corporateId method end");
        return echequeslst;
    }
    //5057 ends
	
	 public Map getEchequesFile(String fromDate,String toDate,String userName,String accountNo,String corpRole) {
	        logger.info("getEchequesFile(String fromDate,String toDate)- method begin");
	        HashMap outParams=new HashMap();
	        String requestId=null;
	        try {
	        	logger.info("corprole:" +corpRole);
	        	logger.info("this.reportToExcelCount..." +this.reportToExcelCount);
	        	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	        	df.parse(fromDate);
	        	/*if(((Calendar.getInstance().getTimeInMillis()-df.getCalendar().getTimeInMillis())/(1000*60*60*24))<=5){
	        		List echequeslist = corporateReportDAOImpl.fileBasedEcheques(fromDate,toDate,userName,accountNo,corpRole);
                    outParams.put("echequeslist",echequeslist);
	        	}
	        	else{*/
	        	    requestId=corporateReportDAOImpl.generateRequestId(fromDate,toDate,userName,accountNo,corpRole);
	        	    logger.info("requestId :" +requestId);
	        	    outParams.put("requestId",requestId);
	       // }   
	        	    
	            } catch (DAOException exception) {
	                SBIApplicationException.throwException(exception.getErrorCode(),
	                        exception);
	            }
	            catch(Exception ex){
	            	logger.error(ex);}  
	        logger.info("getEchequesFile(String username, String accountNo,String fromDate,String toDate) method end");
	        return outParams;
	    }
	 
	
	 
	 public Map getEchequesExcelFile(String txnDate,String txnType,String userName,String accountNo,String corpRole,String formatType,String corporateId) {
	        logger.info("getEchequesExcelFile(String fromDate,String toDate)- method begin");
	        HashMap outParams=new HashMap();
	        String requestId=null;
	        try {
	        	logger.info("corprole:" +corpRole);
	        	logger.info("account No:" +accountNo);
	        	if ( txnType!=null  && (txnType.equals("success_txn") ||
	        			txnType.equals("failure_txn")||txnType.equals("val_failure_txn") ||
	        			txnType.equals("unknow_txn") ||txnType.equals("adjusted_credits") ))
	        			{
	        				logger.info("inside the date condition");		
	        				DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	        				df.parse(txnDate);
	        			}
	        	
	        	
	        	    requestId=corporateReportDAOImpl.generateExcelRequestIdforMIS(txnDate,txnType,accountNo,userName,formatType,corporateId);
	        	    logger.info("requestId :" +requestId);
	        	    outParams.put("requestId",requestId);
	         
	        	    
	            } catch (DAOException exception) {
	                SBIApplicationException.throwException(exception.getErrorCode(),
	                        exception);
	            }
	            catch(Exception ex){
	            	logger.error(ex);}  
	        logger.info("getEchequesExcelFile(String username, String accountNo,String fromDate,String toDate) method end");
	        return outParams;
	    }
	
	 public void setCorporateReportDAOImpl(CorporateReportDAO corporateReportDAOImpl) {
			this.corporateReportDAOImpl = corporateReportDAOImpl;
		}

	public void setReportToExcelCount(String reportToExcelCount) {
		this.reportToExcelCount = reportToExcelCount;
	}

}
