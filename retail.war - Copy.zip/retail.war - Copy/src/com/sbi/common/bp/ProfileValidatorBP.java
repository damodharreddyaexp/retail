/**
 * @(#) ProfileValidatorBP.java
 */

package com.sbi.common.bp;

public abstract class ProfileValidatorBP
{
	public abstract void validate( Object input );
	
	
}
