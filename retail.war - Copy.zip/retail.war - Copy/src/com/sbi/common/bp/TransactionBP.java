/* 
 * TransactionBP.java 
 * Created on Oct 28, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 28, 2005 BOOPATHI - Initial Creation
//Nov 09,2005  MURUGAN K - modification in setter methods and change behaviour  the instance variable default to private 
//Nov 23, 2005 BOOPATHI - Constants Added
//Nov 26, 2005 BOOPATHI - i have changed the implementation of postTransactionToBankSystem method
package com.sbi.common.bp;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.BankSystemDAO;
import com.sbi.common.dao.BankSystemDAOFactory;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.IBTransactionDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Transaction;
import com.sbi.common.model.TransactionResponse;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.TxnFormatter;
import com.sbi.common.utils.TxnFormatterFactory;

public class TransactionBP
{

    protected final Logger logger = Logger.getLogger(getClass());

    private TxnFormatterFactory txnFormatterFactory;

    private IBTransactionDAO ibTransactionDAOImpl;
    
      private BankSystemDAOFactory bankSystemDAOFactory;

    /**
     * Call postTransactionToDB with Transaction Object as a input and get
     * ReferenceNo and update that Reference No in Transaction Object. Call
     * postTransactionToBankSystem with Transaction Object as a input and get
     * TransactionResponse Object and update the Transation object. Call
     * updateTransactionStatus with ReferenceNo,TransactionResponse and get
     * boolean result. return the Transaction Object
     * 
     * @param transaction
     *            Transaction
     * @return Transaction
     */
    public Transaction postTransaction(Transaction transaction) throws SBIApplicationException
    {

        if (transaction != null)
        {
            logger.info("postTransaction(Transaction transaction) " + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled())
            {
                logger.debug("transaction : " + transaction.toString());
            }
            String referenceNo = postTransactionToDB(transaction);
            if (logger.isDebugEnabled())
            {
                logger.debug("referenceNo : " + referenceNo);
            }
            transaction.getDebit().setReferenceNo(referenceNo);

            if (!transaction.isScheduled())//Added for CR-2655
            { 
            TransactionResponse transactionResponse = postTransactionToBankSystem(transaction);
            if (logger.isDebugEnabled())
            {
                logger.debug("transactionResponse : " + transactionResponse);
            }
            transaction.getDebit().setStatusCode(transactionResponse.getStatusCode());
            transaction.getDebit().setStatusDescription(transactionResponse.getStatusDescription());
            transaction.getDebit().setTransactionTime(transactionResponse.getResponseDate());
            transaction.getDebit().setErrorCode(transactionResponse.getErrorCode());
 
            logger.info("transactionResponse :"+transactionResponse);
            updateTransactionStatus(referenceNo, transactionResponse);
            logger.info("postTransaction(Transaction transaction) " + LoggingConstants.METHODEND);
            if (logger.isDebugEnabled())
            {
                logger.debug("transaction : " + transaction);
            }
           
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }
        return transaction;

    }

    /**
     * Call IBTransactionDAO.createTransaction method with Transaction Object as
     * a input and get ReferenceNo back.
     * 
     * @param transaction
     *            Transaction
     * @return String
     */
    private String postTransactionToDB(Transaction transaction)
    {
        String refNo=null;
    	try
        {
            logger.info("postTransactionToDB(Transaction transaction) " + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled())
            {
                logger.debug("transaction : " + transaction);
            }
            logger.info("transaction.getName()----------->"+transaction.getName());
            if(transaction.getName().startsWith("C"))//added for saral
            {
            	refNo=transaction.getDebit().getReferenceNo();
            }
            else 
            {
            refNo = ibTransactionDAOImpl.createTransaction(transaction);
 			}
            logger.info("refNo :"+refNo);
            if (logger.isDebugEnabled())
            {
                logger.debug("refNo : " + refNo);
            } 
            logger.info("postTransactionToDB(Transaction transaction) " + LoggingConstants.METHODEND);
        }
        catch (DAOException daoException)
        {
        	SBIApplicationException.throwException(daoException.getMessage(),daoException);
        }
        return refNo;
    }

    /**
     * Check the path . If it is core{ - call CoreFormatter.getTransactionFormat
     * with Transaction Object as a input and get Map back. - Call
     * CoreDaoImpl.getDataFromBankSystem with Map as a input and get List back. -
     * Get the data from List at first position. - Update the
     * TransactionResponse Object and return it }else{ - call
     * SwitchFormatter.getTransactionFormat with Transaction Object as a input
     * and get Map back. - Call SwitchDaoImpl.getDataFromBankSystem with Map as
     * a input and get List back. - Get the data from List at first position. -
     * Update the TransactionResponse Object and return it }
     * 
     * @param transaction
     *            Transaction
     * @return TransactionResponse
     */
    private TransactionResponse postTransactionToBankSystem(Transaction transaction)
    {
    	TransactionResponse transactionResponse=null;
        if (transaction != null)
        {
            logger.info("postTransactionToBankSystem(Transaction transaction) " + LoggingConstants.METHODBEGIN);
            if (logger.isDebugEnabled())
            {
                logger.debug("transaction : " + transaction);
            }

            try
            {
                String txnPath = transaction.getPath();
                if (logger.isDebugEnabled())
                {
                    logger.debug("txnPath : " + txnPath);
                }
                TxnFormatter txnFormatter = txnFormatterFactory.getTransactionFormatter(txnPath);
                if (logger.isDebugEnabled())
                {
                    logger.debug("txnFormatter is :" + txnFormatter);
                }
                Map requestData = txnFormatter.getTransactionRequestFormat(transaction);
                
                BankSystemDAO bankSystemDAO = bankSystemDAOFactory.getBankSystemDAO(txnPath);
                List responseList = bankSystemDAO.getDataFromBankSystem(requestData);
                logger.info("responseList :"+responseList);
                if (logger.isDebugEnabled())
                {
                    logger.debug("List from bank system is :" + responseList);
                }
                HashMap bankSystemDataHash = (HashMap) responseList.get(BPConstants.ZERO_INT);
                logger.info("bankSystemDataHash :"+bankSystemDataHash);
                if (logger.isDebugEnabled())
                {
                    logger.debug("bankSystemDataHash is :" + bankSystemDataHash);
                }
                Map transactionResponseData = txnFormatter.getTransactionResponseFormat(bankSystemDataHash);
                logger.info("*****transactionResponseData :"+transactionResponseData);

                logger.info("transactionResponseData :"+transactionResponseData);
                transactionResponse = new TransactionResponse();
                transactionResponse.setResponseDate((Timestamp) transactionResponseData.get(BPConstants.RESPONSE_DATE));
                transactionResponse.setResponseReference((String) transactionResponseData
                        .get(BPConstants.RESPONSE_REFERENCE));
                transactionResponse.setStatusCode((String) transactionResponseData.get(BPConstants.STATUS));
                transactionResponse.setStatusDescription((String) transactionResponseData
                        .get(BPConstants.RESPONSE_DESCRIPTION));
                transactionResponse.setErrorCode((String)transactionResponseData.get("errorCode"));
                
                logger.info("transactionResponseData.get()"+transactionResponse.getErrorCode());
                if (logger.isDebugEnabled())
                {
                    logger.debug("transactionResponse is :" + transactionResponse);
                }
                //logger.info("transactionResponse :"+transactionResponse);
                logger.info("postTransactionToBankSystem(Transaction transaction)" + LoggingConstants.METHODEND);
            }
            catch (DAOException daoException)
            {
            	SBIApplicationException.throwException(daoException.getMessage(),daoException);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
        }
        return transactionResponse;

    }

    /**
     * Call IBTransactionDAO.updateStatus with referenceNo and
     * TransactionResponse Object as a input and return boolean result.
     * 
     * @param referenceNo
     *            String
     * @param transactionResponse
     *            TransactionResponse
     * @return boolean
     */
    private boolean updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse)
    {
        logger.info("updateTransactionStatus(String referenceNo, TransactionResponse transactionResponse)"
                + LoggingConstants.METHODBEGIN);

        if (transactionResponse != null && referenceNo != null && referenceNo.trim() != BPConstants.EMPTY)
        {
            try
            {
                return ibTransactionDAOImpl.updateStatus(transactionResponse, referenceNo);
            }
            catch (DAOException daoException)
            {
            	SBIApplicationException.throwException(daoException.getMessage(),daoException);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
         }
        return true;

    }

    /**
     * CoreDAOImpl injection
     * 
     * @param coreDAOImpl
     *            BankSystemDAO
     */
    public void setBankSystemDAOFactory(BankSystemDAOFactory bankSystemDAOFactory)
    {
        this.bankSystemDAOFactory = bankSystemDAOFactory;
    }

    /**
     * IBTransactionDAOImpl injection
     * 
     * @param ibTransactionDAOImpl
     *            IBTransactionDAO
     */
    public void setIbTransactionDAOImpl(IBTransactionDAO ibTransactionDAOImpl)
    {
        this.ibTransactionDAOImpl = ibTransactionDAOImpl;
    }

    /**
     * TxnFormatterFactory injection
     * 
     * @param txnFormatterFactory
     *            void
     */
    public void setTxnFormatterFactory(TxnFormatterFactory txnFormatterFactory)
    {
        this.txnFormatterFactory = txnFormatterFactory;
    }

  
}
