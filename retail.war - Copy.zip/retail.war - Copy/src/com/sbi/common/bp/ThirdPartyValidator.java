/**
 * @(#) TPValidator.java
 */
 
package com.sbi.common.bp;


import java.util.HashMap;
import java.util.Map;

import com.sbi.common.model.Account;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.ProfileValidator;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.utils.Validator;
import org.apache.log4j.Logger;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.BranchMasterDAO;
 
public class ThirdPartyValidator extends ProfileValidatorBP
{
    private ProfileValidator profileValidator;
    
    private BranchMasterDAO branchMasterDAOImpl;
    
    private Validator validator;
    
    private Logger logger = Logger.getLogger(getClass());
    
    private final static String TP_VALIDATION_KEY = "validationType";
    
    private final static String TP_VALIDATION_ADD_TYPE = "Add";
    
    private final static String TP_VALIDATION_EDIT_TYPE = "Edit";
    
    private final static String ACCOUNT_KEY = "account";
	/**
	 * Will call the following methods 
	 * 1.findBankSystem of BranchmasterDAO
	 * 2.verifyaccountidentifier of the Profilevalidator
	 * 3.validateaccount of the Profilevalidator
	 * 4.verifylimit of validator class
	 */ 
	public void validate( Object input )
	{
        if(input != null)
        {        	
            logger.info("TPValidator : validate method "+LoggingConstants.METHODBEGIN);
            Map validateMap = (HashMap) input;
            
            String type = (String)  validateMap.get(TP_VALIDATION_KEY);
            Account acc = (Account) validateMap.get(ACCOUNT_KEY);

            logger.info("TPValidator : calling findBankSystem");
            String banksystem = branchMasterDAOImpl.findBankSystem(acc.getBranchCode());
            
            logger.info("TPValidator : banksystem "+banksystem);
            if(banksystem == null)
            	banksystem = Constants.NONCORE_SYSTEM;
            acc.setBankSystem(banksystem);
 
            logger.info("TPValidator : calling verifyaccountidentifier");
            profileValidator.verifyAccountIdentifier(acc);
            
            logger.info("TPValidator : calling validateAccount");
            if(type.equalsIgnoreCase(TP_VALIDATION_ADD_TYPE))
            	profileValidator.validateAddAccount(acc);
            else if(type.equalsIgnoreCase(TP_VALIDATION_EDIT_TYPE))
            	profileValidator.validateEditAccount(acc);
            else
            	SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
            logger.info("TPValidator : calling verifylimit");
            validator.validateLimit(acc.getBalance(),UtilsConstant.THIRD_PARTY);
        }
        else
        {
            logger.error("TPValidator : Error in data received");
            SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
        }
		 
	}
    public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
        this.branchMasterDAOImpl = branchMasterDAOImpl;
    }
    public void setProfileValidator(ProfileValidator profileValidator) {
        this.profileValidator = profileValidator;
    }
    public void setValidator(Validator validator) {
        this.validator = validator;
    }


}
