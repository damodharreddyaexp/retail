/*
 * ProfileValidtorFactory.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 MURUGAN K - Initial Creation
package com.sbi.common.bp;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;

public class ProfileValidatorFactory {

    private Logger logger = Logger.getLogger(getClass());

    private ProfileValidatorBP thirdPartyValidator;

    private ProfileValidatorBP ppFValidator;
    
    private ProfileValidatorBP corpThirdPartyValidator;
    
    private ProfileValidatorBP corpDDBenificiaryValidator;
    

    /**
     * Accepts type as input. Values for type and appropriate return objects for the same are
     * 1. TP - TPValidator
     * 2. PPF - PPFValidator
     */

    public ProfileValidatorBP getvalidator(String type) {
        logger.info("getvalidator : " + LoggingConstants.METHODBEGIN);
        if (type != null) {
            logger.info("getvalidator : type" + type);
            if (type.equalsIgnoreCase(BPConstants.PPF)) {
                logger.info("getvalidator : Creating a PPFvalidator instance");
                return ppFValidator;
            }
            else if (type.equalsIgnoreCase(BPConstants.THIRD_PARTY)) {
                logger.info("getvalidator : Creating a THIRD_PARTY  instance");
                return thirdPartyValidator;
            }
            else if (type.equalsIgnoreCase(BPConstants.THIRD_PARTY + "CORP_USER") ||type.equalsIgnoreCase(BPConstants.THIRD_PARTY + "CORP_REG") || type.equalsIgnoreCase(BPConstants.THIRD_PARTY + "CORP_ADMIN") ) {
                logger.info("getvalidator : Creating a  CORP_USER THIRD_PARTY  instance");
                return corpThirdPartyValidator;
            }
            else if (type.equalsIgnoreCase(BPConstants.DEMAND_DRAFT + "CORP_USER") ||type.equalsIgnoreCase(BPConstants.DEMAND_DRAFT + "CORP_REG") || type.equalsIgnoreCase(BPConstants.DEMAND_DRAFT + "CORP_ADMIN") ) {
                logger.info("getvalidator : Creating a DEMAND_DRAFT  instance " + corpDDBenificiaryValidator);
                return corpDDBenificiaryValidator;
            }
            
        }
        else {
            logger.error("getvalidator : invalid type passed");
            SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);
        }
        return null;
    }

   

    public void setThirdPartyValidator(ProfileValidatorBP thirdPartyValidator) {
        this.thirdPartyValidator = thirdPartyValidator;
    }



    public void setPpFValidator(ProfileValidatorBP ppFValidator) {
        this.ppFValidator = ppFValidator;
    }

 

    public void setCorpThirdPartyValidator(ProfileValidatorBP corpThirdPartyValidator) {
        this.corpThirdPartyValidator = corpThirdPartyValidator;
    }



    public void setCorpDDBenificiaryValidator(ProfileValidatorBP corpDDBenificiaryValidator) {
        this.corpDDBenificiaryValidator = corpDDBenificiaryValidator;
    }

 


   
}
