package com.sbi.common.bp;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import com.sbi.common.bp.UserDispatchBP;
import com.sbi.common.dao.BVUserDAO;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Address;
import com.sbi.common.model.SPOutput;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.utils.BranchUtils;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.Generator;

public class AddCorpRolesBP
{
    protected final Logger logger = Logger.getLogger(getClass());

    UserProfile userProfile = null;
    
    private UserDAO userDAOImpl;

    private Generator generator;

    private BVUserDAO broadVisionDAOImpl;

    SPOutput spoutput = new SPOutput();

    String userName = null;

    String passWord = null;

    boolean nameTest = true;

    User user = new User();
    
    private UserDispatchBP userDispatchBP;    
   
	private TransactionTemplate transactionTemplate;
    
    private String dispatchRef1;
    
    private String dispatchRef2;
    
    private BranchUtils branchUtils;
    	
	Map<String, String> dispatchDetails=new HashMap<String, String>();
	
	String address1=null;
	
	String address2=null;
	
	  public String setUserProfileDetails(Map inputparams)
	    {
	        logger.info("String setUserProfileDetails(Map inputParams)" + LoggingConstants.METHODBEGIN);
	        logger.info("inputparams"+inputparams);
	        UserProfile userPofile = new UserProfile();
	        String status = "";
	        logger.info("UserId  "+inputparams.get("userId"));
	 
	        if (inputparams != null)
	        { 
	            logger.info("inputparam" + inputparams);
	            userPofile.setName((String) inputparams.get("name"));
	            Integer userid = new Integer((String)inputparams.get("userId"));
	             userPofile.setUserId(userid);
	             
	            String add1 = (String) inputparams.get("address");
	            String add2 ="";
	            if(inputparams.get("address2") != null){
	            	add2 = (String) inputparams.get("address2");
	            } 
	            
	            String add = add1+" , "+add2;            	
	            Address address=new Address();
	            userPofile.setFriendlyName((String) inputparams.get("name"));
	            userPofile.setEmpNo((String) inputparams.get("emp"));
	            userPofile.setBranchCode((String) inputparams.get("branchCode"));
	            userPofile.setBankCode((String) inputparams.get("bankCode"));
	            userPofile.setCorporateId((String) inputparams.get("corpId"));
	            address.setAddress1(add);
	            address.setCity((String) inputparams.get("city"));
	            address.setState((String) inputparams.get("state"));
	            address.setPin((String) inputparams.get("pincode"));
	            userPofile.setDistrict((String) inputparams.get("district"));
	            address.setCountry((String) inputparams.get("country"));
	            userPofile.setAddress(address);
	            userPofile.setEmail((String) inputparams.get("emailId"));
	            userPofile.setHomePhone((String) inputparams.get("phone"));
	            userPofile.setDesignation((String) inputparams.get("designation"));
	            userPofile.setDepartment((String) inputparams.get("department"));
	            userPofile.setCreatedBy((String) inputparams.get("createdBy"));
	            userPofile.setUserAlias((String) inputparams.get("userName"));
	            status = userDAOImpl.updateProfileDetails(userPofile);

	        } 
	        else
	        {
	            SBIApplicationException.throwException("F001");
	        }

	        logger.info("String returned is " + status);
	        logger.info("String setUserProfileDetails(Map inputParams)" + LoggingConstants.METHODBEGIN);
	        return status;
	    }
    public UserProfile addUser(final UserProfile userProfile, final String role)
    {
        logger.info("addUser(UserProfile userProfile,String role)" + LoggingConstants.METHODBEGIN);
        logger.info("userProfile :" + userProfile);
        logger.info("role :" + role);

        //for search by employee number starts
        boolean status=false;        
        if (role == "800")
        {             
            userName=userProfile.getUserAlias();
            logger.info("userName of existing user:"+userName);
            passWord="-";
            status=true;
        }
        //for search by employee number ends
        else
        {  
            userName = generator.generateRandomWord(8);
            while (nameTest)
                {
                     user = userDAOImpl.findUser(userName);
                     if (user == null)
                          nameTest = false;
                     else
                        {
                             nameTest = true;
                             userName = generator.generateRandomWord(8);
                         }
                 }
             passWord = generator.generateRandomWord(8);
             logger.info("userName :" + userName);
             logger.info("passWord :" + passWord);

             status = broadVisionDAOImpl.addUser(userName, passWord);
             logger.info("status" + status); 
        }      
        if (status)
        {
            userProfile.setUserName(userName);
            
            transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(
						TransactionStatus transactionStatus) {
					try {  
            Map outParams = userDAOImpl.addUser(userProfile, role, new ArrayList(),passWord);
			UserProfile  userProf= (UserProfile) outParams.get("userProfile");
            logger.info("userProfile" + userProfile);
            try{
                   
                if (userName!= null && !"".equals(userName) && role != "800")
                {
                    List userRefs=new ArrayList();
                    userRefs=userDAOImpl.getUserRefs(userName);
                    logger.info("userDetails ::"+userRefs.toString());
                    dispatchRef1=(((Map)userRefs.get(0)).get("DISPATCH1_REF").toString());
                    dispatchRef2=(((Map)userRefs.get(0)).get("DISPATCH2_REF").toString());
                    logger.info("distachRef1::"+dispatchRef1);
                    logger.info("distachRef2::"+dispatchRef2);
                   
                    String branchName=branchUtils.getBranchName(userProf.getBranchCode());
                    logger.info("branchName::"+branchName);      
                    
                    String i[]=userProf.getAddress().getAddress1().split("\\,");
                    address1=i[0];
                    address2=i[1];
                    
                    dispatchDetails.put("name",userProf.getName());
                    dispatchDetails.put("address1",address1);
                    dispatchDetails.put("address2",address2.trim());
                    dispatchDetails.put("city",userProf.getAddress().getCity());
                    dispatchDetails.put("pincode",userProf.getAddress().getPin());
                    dispatchDetails.put("state",userProf.getAddress().getState());
                    dispatchDetails.put("country",userProf.getAddress().getCountry());
                    dispatchDetails.put("airwayBillNumber",dispatchRef1);
                    dispatchDetails.put("userPwd",userProf.getUserName());
                    dispatchDetails.put("module","CORPREG");
                    dispatchDetails.put("bankCode",userProf.getBankCode());
                    dispatchDetails.put("type","USERNAME");                
                    dispatchDetails.put("branchName",branchName);    
                    dispatchDetails.put("appendChar","U");
                                                         
                  	try {    				
    							userDispatchBP.insertDispatchDetails(dispatchDetails);//For USERNAME line
			                    dispatchDetails.put("airwayBillNumber",dispatchRef2);
			                    dispatchDetails.put("userPwd",passWord);
			                    dispatchDetails.put("type","PASSWORD");
			                    dispatchDetails.put("appendChar","P");
			                    userDispatchBP.insertDispatchDetails(dispatchDetails);//For PASSWORD line
    						}
    	                    catch (Exception exp) {
    							transactionStatus.setRollbackOnly();
    							DAOException.throwException("SE002");
    						}
    				
    			}
                
            }catch(Exception exc){
                logger.info("I/O exception occured");
				transactionStatus.setRollbackOnly();
                SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                
            }
					}
					catch (Exception exp) {
						transactionStatus.setRollbackOnly();
						DAOException.throwException("SE002");
					}
					
					return null;
			}
		});
        }
        else 
        {
            logger.info("return false");
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    
    public boolean userExists(String empNo,String corpId){
		logger.info("userExists(String empNo,String corpId))"+LoggingConstants.METHODBEGIN);
		boolean flag=userDAOImpl.findUserByEmpNo(empNo,corpId);		
		logger.info("userExists(String empNo,String corpId))"+LoggingConstants.METHODEND); 
		return flag;
	}
    public boolean userExists(String empNo,String role,String caUser,String corpId){
		logger.info("userExists(String empNo,String role,String caUser,String corpId)"+LoggingConstants.METHODBEGIN);
		boolean flag=userDAOImpl.findUserByEmpNo(empNo, role, caUser, corpId);		
		logger.info("userExists(String empNo,String role,String caUser,String corpId)"+LoggingConstants.METHODEND); 
		return flag;
	}
    public void updateUserType(String userName, int userType){
		logger.info("updateUserType(String userName, int userType)"+LoggingConstants.METHODBEGIN);
		logger.info("usernamr and usertype "+userName+" "+userType);
		int count= 0 ;
		try{
			count = userDAOImpl.updateUserState(userName, userType);
		}		
		catch(Exception exc){
            logger.info("Exception occured");
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
	}
 public UserProfile addUser(final UserProfile userProfile, final String role,final List auditAccMapList)
    { 
        logger.info("addUser(UserProfile userProfile,String role)" + LoggingConstants.METHODBEGIN);
        logger.info("userProfile :" + userProfile);
        logger.info("role :" + role);
        logger.info("auditAccMapList :" + auditAccMapList);
        

        userName = generator.generateRandomWord(8);
        while (nameTest)
        {
            user = userDAOImpl.findUser(userName);
            if (user == null)
                nameTest = false;
            else
            {
                nameTest = true;
                userName = generator.generateRandomWord(8);
            }
        }
        passWord = generator.generateRandomWord(8);
        logger.info("userName :" + userName);
        logger.info("passWord :" + passWord);

        boolean status = broadVisionDAOImpl.addUser(userName, passWord);
        logger.info("status" + status);        
        if (status)
		{
			userProfile.setUserName(userName);            
            transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(
						TransactionStatus transactionStatus) {
					try {  
            Map outParams = userDAOImpl.addUser(userProfile, role, auditAccMapList,passWord);
			UserProfile  userProf=(UserProfile)outParams.get("userProfile");
            logger.info("spoutput" + spoutput);
            try{
            	     
                if (userName!= null && !"".equals(userName))
                {
                    List userRefs=new ArrayList();
                    userRefs=userDAOImpl.getUserRefs(userName);
                    logger.info("userDetails ::"+userRefs.toString());
                    dispatchRef1=(((Map)userRefs.get(0)).get("DISPATCH1_REF").toString());
                    dispatchRef1=(((Map)userRefs.get(0)).get("DISPATCH2_REF").toString());
                    logger.info("distachRef1::"+dispatchRef1);
                    logger.info("distachRef2::"+dispatchRef1);
                        
                    String branchName=branchUtils.getBranchName(userProf.getBranchCode());
                    logger.info("branchName::"+branchName);      
                    
                    String i[]=userProf.getAddress().getAddress1().split("\\,");
                    address1=i[0];
                    address2=i[1];
                    
                    dispatchDetails.put("name",userProf.getName());
                    dispatchDetails.put("address1",address1);
                    dispatchDetails.put("address2",address2.trim());
                    dispatchDetails.put("city",userProf.getAddress().getCity());
                    dispatchDetails.put("pincode",userProf.getAddress().getPin());
                    dispatchDetails.put("state",userProf.getAddress().getState());
                    dispatchDetails.put("country",userProf.getAddress().getCountry());
                    dispatchDetails.put("airwayBillNumber",dispatchRef1);
                    dispatchDetails.put("userPwd",userProf.getUserName());
                    dispatchDetails.put("module","CORPREG");
                    dispatchDetails.put("bankCode",userProf.getBankCode());
                    dispatchDetails.put("type","USERNAME");                
                    dispatchDetails.put("branchName",branchName);    
                    dispatchDetails.put("appendChar","U");
                    
                    	try {
    							userDispatchBP.insertDispatchDetails(dispatchDetails);//For USERNAME line
			                    dispatchDetails.put("airwayBillNumber",dispatchRef2);
			                    dispatchDetails.put("userPwd",passWord);
			                    dispatchDetails.put("type","PASSWORD");
			                    dispatchDetails.put("appendChar","P");
			                    userDispatchBP.insertDispatchDetails(dispatchDetails);//For PASSWORD line
    						}
    	                    catch (Exception exp) {
    							transactionStatus.setRollbackOnly();
    							DAOException.throwException("SE002");
    						}
    					
    	                }
                
            }catch(Exception exc){
                logger.info("I/O exception occured");
				transactionStatus.setRollbackOnly();
                SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                
            }
                }
				catch (Exception exp) {
					transactionStatus.setRollbackOnly();
					DAOException.throwException("SE002");
				}
				
				return null;
		}
	});
    }
        else
        {
            logger.info("return false");
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    
    public Map  addUserPrePrintKit (UserProfile userProfile,String role)
    { 
        logger.info("addUserPrePrintKit(UserProfile userProfile)" + LoggingConstants.METHODBEGIN);
        logger.info("userProfile :" + userProfile);
        Map outParam=new HashMap();
        try{    
            String pp_id = userDAOImpl.addUserPrePrintKit(userProfile,role);
             outParam.put("userProfile",userProfile);
             outParam.put("pp_id",pp_id);
            }catch(Exception exc){
                logger.info("Exception occured so user profile is set to null "+exc);
                userProfile= null;
                SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
                
            }
            logger.info("addUserPrePrintKit(UserProfile userProfile)" + LoggingConstants.METHODEND);
            return outParam;
        }
  
    /*
     * 
     */
    public void insertMobileDetails(UserProfile userProfile, String role, String ppktId){
    	 logger.info("insertMobileDetails(UserProfile userProfile,String role, String userId)" + LoggingConstants.METHODBEGIN);
         logger.info("userProfile :" + userProfile);
         logger.info("ppktId :"+ppktId);
        try{
        	userDAOImpl.insertMobileDetails(userProfile,role,ppktId);
        }catch(Exception exc){
            logger.info("Exception occured  in insertMobileDetails in AddCorpRolesBP "+exc);
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            
        }
        logger.info("insertMobileDetails(UserProfile userProfile,String role, String userId)" + LoggingConstants.METHODEND);
     } 
    public void insertMobileDetailsPPKit(UserProfile userProfile, String role, String ppktId){
   	 logger.info("insertMobileDetails(UserProfile userProfile,String role, String userId)" + LoggingConstants.METHODBEGIN);
        logger.info("userProfile :" + userProfile);
        logger.info("ppktId :"+ppktId);
       try{
       	userDAOImpl.insertMobileDetailsPPKit(userProfile,role,ppktId);
       }catch(Exception exc){
           logger.info("Exception occured  in insertMobileDetails in AddCorpRolesBP "+exc);
           SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
           
       }
       logger.info("insertMobileDetails(UserProfile userProfile,String role, String userId)" + LoggingConstants.METHODEND);
    } 
    
    
   
    
    public void setUserDAOImpl(UserDAO userDAOImpl)
    {
        this.userDAOImpl = userDAOImpl;
    }

    public void setGenerator(Generator generator)
    {
        this.generator = generator;
    }   

    public void setBroadVisionDAOImpl(BVUserDAO broadVisionDAOImpl)
    {
        this.broadVisionDAOImpl = broadVisionDAOImpl;
    }

     public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
 		this.transactionTemplate = transactionTemplate;
 	}
     public void setBranchUtils(BranchUtils branchUtils) {
 		this.branchUtils = branchUtils;
 	}    
     
     
 	public void setUserDispatchBP(UserDispatchBP userDispatchBP) {
 		this.userDispatchBP = userDispatchBP;
 	}

}
