/**
 * @(#) SMSGatewayBP.java
 * Created on Jul 05, 2011
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 * History
 * Jul 05, 2011 Ponnusamy G - Initial Creation
 * To process the SMS request to send SMS thru Gateway
 */

package com.sbi.common.bp;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import Encryption.Encrypt;

import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.SMSRequestParams;
import com.sbi.common.utils.ConstructSMSRequest;
import com.sbi.common.utils.SMSGatewayClient;
import com.sbi.common.utils.StringUtils;

public class SMSGatewayBP {

	private SMSGatewayClient smsGatewayClient;	
	
	protected final Logger logger = Logger.getLogger(getClass());


	public String processSMSRequest(Map<String, String> requestMap,List<String> paramList) throws Exception {
		logger.info("processSMSRequest(Map<String, String> requestMap,List<String> paramList) -- Start");
		String message = "";
		String smsModuleType=requestMap.get("smsModuleType");
		String messageId=StringUtils.uniqueNumberUsingDateAndRandom(smsModuleType);
		String serverHost=StringUtils.getServerHost();
		 String sgateResponse="";
		logger.info("smsModuleType::::"+smsModuleType);
		logger.info("messageId::::::::"+messageId);
		logger.info("serverHost:::::::"+serverHost);
		 SMSRequestParams request=new SMSRequestParams();
			request.setBankCode(requestMap.get("bankCode"));
			request.setCountryCode(requestMap.get("countryCode"));
			request.setMessageId(messageId);// message id specific to module
			request.setMessageTypeId(requestMap.get("messageTypeId"));//specific to module configured in sms_config_master table
			request.setMobileNo(requestMap.get("mobileNo"));
			request.setModuleName(requestMap.get("moduleName"));
			request.setParam(paramList);// list contains actual message sequence
			request.setSendOrder(requestMap.get("sendOrder")); //order of the SMS to be sent. Default is 0.
			request.setUserName(requestMap.get("userName"));		
			request.setEmailId(requestMap.get("emailId"));
			//Added for Voice OTP
			request.setDeliveryFlag((String)requestMap.get("otpOption"));			
			
			logger.info("OTP option selected by the user in SMSGatewayBP: "+ (String)requestMap.get("otpOption"));

			//Added for Voice OTP
			
		 message=ConstructSMSRequest.constructSMSRequest(request);
		 
		 logger.info("message for email : "+ message);		 
		 if("YES".equals(requestMap.get("readResponse"))){
			 sgateResponse=smsGatewayClient.sendMessageToSgate(message, serverHost, messageId);
			 }
			 else {
				 smsGatewayClient.sendMessageToSgate(message, serverHost);
			 }
		 
		 
		//String sgateResponse=smsGatewayClient.sendMessageToSgate(message, serverHost, messageId);
		logger.info("sgateResponse : " + sgateResponse);
		logger.info("processSMSRequest(Map<String, String> requestMap,List<String> paramList) -- end");
		return sgateResponse;
	}


	public void setSmsGatewayClient(SMSGatewayClient smsGatewayClient) {
		this.smsGatewayClient = smsGatewayClient;
	}
	
	
}
