/*
 * ProfileBP.java
 * Created on Dec 16, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Dec 16, 2005 MURUGAN K - Initial Creation
//Dec 18,2005 NAVEEN KUMAR - Methods implementation.
package com.sbi.common.bp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

//Added for SHA encryption algorithm
import com.sbi.authentication.algorithm.Sha512Hashing;
import com.sbi.authentication.user.RequestResponseService;
import com.sbi.common.dao.AccountDAO;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Account;
import com.sbi.common.model.Field;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.CommonUtils;
import com.sbi.common.utils.Constants;
import com.sbi.common.utils.EncryptMD5;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.LogonValidator;//Added For CR 5274
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.utils.Validator;
import com.sbi.common.utils.TransactionPWDUtil;

public class ProfileBP {
    protected final Logger logger = Logger.getLogger(getClass());

    private UserDAO userDAOImpl;

    UserProfile userProfile;

    private CommonUtils commonUtils;

    private AccountDAO accountDAOImpl;

    private Account updatedAccountObj;

    private Validator validator;

    private ProfileValidatorFactory profileValidatorFactory;
    
    private ProfileValidatorBP profileValidatorBP; 
    
    private final static String TP_VALIDATION_KEY = "validationType";
    
    private final static String TP_VALIDATION_ADD_TYPE = "Add";
    
    private final static String TP_VALIDATION_EDIT_TYPE = "Edit";
    
    private final static String ACCOUNT_KEY = "account";
    
    private final static String INVALID_PROFILE_PASSWORD="CUV160";
    
    private LogonValidator passwordValidator;//Added For CR 5274
    
    private RequestResponseService requestResponseService; //Added for SHA encryption algorithm
    
    private Sha512Hashing sha512Hashing; 

     
    public UserProfile changeProfilePassword(String enteredpassword, String oldpassword, User user) {

        logger.info("changeprofilepwd(String enteredpassword, String oldpassword, String userName) method begin");
        try {
            passwordValidator.loginPassword(enteredpassword);//Added For Cr 5274
            userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
            String currentPwd = userProfile.getProfilepassword();                    
            String userName = user.getUserAlias();
            String txnPassword=userProfile.getTxnPassword();
            
            //Added for SHA encryption algorithm
            String loginPwdType=userProfile.getLoginHashing();
            String profilePwdType=userProfile.getProfileHashing();
        	String txnPwdType=userProfile.getTransactionHashing();
        	
        	boolean validationStatus=false;
        	if("SHA-512".equals(profilePwdType))
        	{
        		validationStatus=requestResponseService.validateHashSHA2(currentPwd,userName+ "|" + oldpassword);
        	}
        	else
        	{
        		validationStatus=commonUtils.verifyEncryption(userName + "|" + oldpassword, currentPwd);
        	}
            if (validationStatus) {
                if(oldpassword.equalsIgnoreCase(enteredpassword)){
                    SBIApplicationException.throwException(ErrorConstants.OLDPASSWORD_NEWPASSWORD_MATCH);
                }
                else if (txnPassword!=null){
            		 if("SHA-512".equals(txnPwdType) && requestResponseService.validateHashSHA2(txnPassword,userName+ "~" + enteredpassword))
	   				 {
	               	 	SBIApplicationException.throwException("V0763");
	   				 }
	   				 else if((TransactionPWDUtil.encryptPassword(enteredpassword)).equals(txnPassword))
	   				 {
	   					 SBIApplicationException.throwException("V0763");
	   				 }
                	//TransactionPWDUtil.encryptPassword(enteredpassword).equals(txnPassword)){
                	//SBIApplicationException.throwException("V0763");
//                	}
                }
            	//}else if(userDAOImpl.validateLogin(userName, enteredpassword)){
                
                if(userDAOImpl.validateLogin(userName, enteredpassword,null,null,loginPwdType)){//by nag
                	 SBIApplicationException.throwException("V0764");
                }
                
            	String arrayString[] = { userName + "|" + enteredpassword  };
            	
            	//Added for SHA encryption algorithm
                //String returnStringArray[] = null;
                //returnStringArray = commonUtils.encryptParam(arrayString);
            	String encPassword=sha512Hashing.hashingSHA2(userName + "|" + enteredpassword );//Added for SHA encryption algorithm
            	
                List arrayList = new ArrayList();
                Field field1 = new Field();
                field1.setFieldName(BPConstants.PROFILE_PASSWORD);
                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                //field1.setValue(returnStringArray[0]);
                field1.setValue(encPassword);
                
                //Added for SHA encryption algorithm
				Field field2 = new Field();
                field2.setFieldName(BPConstants.PROFILE_HASHING);
                field2.setType(BPConstants.SQL_VARCHAR_VALUE);
                field2.setValue("SHA-512");
                
                arrayList.add(field1); 
                arrayList.add(field2);
                logger.info("Calling updateprofile ");
                userProfile = userDAOImpl.updateProfile(arrayList, user);
            }
            else
            {
                SBIApplicationException.throwException(ErrorConstants.INVALID_PROFILE_PASSWORD_ERROR_CODE);
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.info("changeprofilepwd(String enteredpassword, String oldpassword, String userName) method end");
        return userProfile;

    }

    /**
     * TODO Call [Common
     * 
     * @param profilePassword
     * @param enteredPassword
     * @return boolean
     */
    public boolean verifyProfilePassword(String enteredPassword, String profilePassword, String userName) {

        logger.info("verifyProfilePassword(String enteredPassword,String profilePassword) "
                + LoggingConstants.METHODBEGIN);
        boolean status = commonUtils.verifyEncryption(userName + "|" + enteredPassword, profilePassword);

        if (status) {
            logger.info("verifyProfilePassword(String enteredPassword,String profilePassword) "
                    + LoggingConstants.METHODEND);
            return status;
        }else{
        	SBIApplicationException.throwException(INVALID_PROFILE_PASSWORD);
        }

        logger.info("verifyProfilePassword(String enteredPassword,String profilePassword) "
                + LoggingConstants.METHODEND);
        return false;

    }

    public UserProfile updatePersonalProfile(Map inputParam) {
        logger.info("updatepersonalprofile(Map inputParam)" + LoggingConstants.METHODBEGIN);

        User user = (User) inputParam.get(Constants.USER);
        UserProfile userProfile = (UserProfile) userDAOImpl.findUserProfile(user.getUserAlias());;
        //update bv_user_profile set #tobereplaced# where user_id in (select user_id from bv_user where user_alias=?)";
        try {
            logger.info("********** input from  Service : " + inputParam);
            logger.info("********** input from userName : " + user);
            logger.info("********** input from userName : " + userProfile);

            if (inputParam != null && user != null) {

                String friendlyName = (String) inputParam.get(BPConstants.DISPLAY_NAME);
                String emailID = (String) inputParam.get(BPConstants.EMAIL);
                String phoneNo = (String) inputParam.get(BPConstants.HOME_PHONE);

                List inparamList = new ArrayList();

                if(!friendlyName.equals(userProfile.getFriendlyName()))
                {
                    Field field1 = new Field();
                    field1.setFieldName(BPConstants.FRIENDLY_NAME);
                    field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field1.setValue(friendlyName);
                	
                    inparamList.add(field1);
                }

                if(!emailID.equals(userProfile.getEmail()))
                {
                    Field field2 = new Field();
                    field2.setFieldName(BPConstants.EMAIL);
                    field2.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field2.setValue(emailID);
                	
                    inparamList.add(field2);
                }

                if(!phoneNo.equals(userProfile.getHomePhone()))
                {
                    Field field3 = new Field();
                    field3.setFieldName(BPConstants.HOME_PHONE);
                    field3.setType(BPConstants.SQL_VARCHAR_VALUE);
                    field3.setValue(phoneNo);
                	
                    inparamList.add(field3);
                }

                logger.info("inparamList "+inparamList.size());
                logger.info("Profile "+userProfile);
                
                if(inparamList.size() > 0)
                	userProfile = userDAOImpl.updateProfile(inparamList, user);

                logger.info("After Profile "+userProfile);

            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);       
        }

        logger.info("updatepersonalprofile User Profile " + userProfile);
        logger.info("updatepersonalprofile(Map inputParam)" + LoggingConstants.METHODEND);
        return userProfile;
    }

    public UserProfile setPassword(String password, String hintQuesition, String hintAnswer, User user) {
        logger.info("setpassword(String userName,String hindQuesition,String hindAnswer) method begin");

        try {
        	passwordValidator.loginPassword(password);//Added For CR 5274
        	userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
        	String userName = user.getUserAlias();
        	String txnPassword=userProfile.getTxnPassword();
        	//Added for SHA encryption algorithm
        	String loginPwdType=userProfile.getLoginHashing();
        	String txnPwdType=userProfile.getTransactionHashing();
        	
            String arrayString[] =
            { userName + "|" + password, userName + "|" + hintQuesition, userName + "|" + hintAnswer };
            String returnStringArray[] = commonUtils.encryptParam(arrayString);
            
        	//Added for SHA encryption algorithm
        	String encPassword=sha512Hashing.hashingSHA2(userName + "|" + password);
        	//String encHintQuesition=sha512Hashing.hashingSHA2(userName + "|" + hintQuesition);
        	//String encHintAnswer=sha512Hashing.hashingSHA2(userName + "|" + hintAnswer);
        	
            //if (txnPassword!=null && TransactionPWDUtil.encryptPassword(password).equals(txnPassword)){
            if (txnPassword!=null)
    		{
            	 if("SHA-512".equals(txnPwdType) && requestResponseService.validateHashSHA2(txnPassword,userName+ "~" + password))
   				 {
               	 	SBIApplicationException.throwException("V0763");
   				 }
   				 else if((TransactionPWDUtil.encryptPassword(password)).equals(txnPassword))
  				 {
  					 SBIApplicationException.throwException("V0763");
  				 }
            	//SBIApplicationException.throwException("V0763");
            }
            //else if(userDAOImpl.validateLogin(userName, password,null,null)){//by nag
            if(userDAOImpl.validateLogin(userName, password,null,null,loginPwdType)){ //Added for SHA encryption algorithm
            	 SBIApplicationException.throwException("V0764");
            }
            

            List inparamList = new ArrayList();

            Field field1 = new Field();
            field1.setFieldName(BPConstants.PROFILE_PASSWORD);
            field1.setType(BPConstants.SQL_VARCHAR_VALUE);
            //field1.setValue(returnStringArray[0]);
            field1.setValue(encPassword);
            inparamList.add(field1);

            if(hintQuesition  != null && ! hintQuesition.equalsIgnoreCase(""))
            { 
                Field field2 = new Field();
                field2.setFieldName(BPConstants.HINT_QUESTION);
                field2.setType(BPConstants.SQL_VARCHAR_VALUE);
                field2.setValue(returnStringArray[1]);
                //field2.setValue(encHintQuesition);
                inparamList.add(field2);
            }

            if(hintAnswer != null && ! hintAnswer.equalsIgnoreCase(""))
            {
                Field field3 = new Field();
                field3.setFieldName(BPConstants.HINT_ANSWER);
                field3.setType(BPConstants.SQL_VARCHAR_VALUE);
                field3.setValue(returnStringArray[2]);
                //field3.setValue(encHintAnswer);
                inparamList.add(field3);
            }
            //Added for SHA encryption algorithm
            Field field4 = new Field();
            field4.setFieldName(BPConstants.PROFILE_HASHING);
            field4.setType(BPConstants.SQL_VARCHAR_VALUE);
            field4.setValue("SHA-512");
            inparamList.add(field4);
            
            userProfile = userDAOImpl.updateProfile(inparamList, user);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);        
        }

        logger.info("setpassword(String userName,String hindQuesition,String hindAnswer) method end");
        return userProfile;
    }

    /**
     * This Method Will form the following objects
     * field=internet_bank_trans_limit;value=<from input User object>;type=number;key=n
     * field=thirdparty_limit;value=<from input User object>;type=number;key=n
     * call the updateProfile method of the UserDAO
     * @param userobj
     * @return User
     */
    public UserProfile updateLimits(Map inputParam) {
        logger.info("updatelimits(Map inputParam)" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Map are" + inputParam);


        try {
        	User user = (User) inputParam.get(Constants.USER);
            String userName = user.getUserAlias();
            Double currentTPLimit = user.getThirdPartyLimit();
            Double currentDDLimit = user.getPPFlimit();
            List inparamList = new ArrayList();

            logger.info("input fron  Service : " + inputParam);

            if (inputParam != null && userName != null && !userName.trim().equalsIgnoreCase(BPConstants.EMPTY)) {

                Double internetBankTransactionLimit = new Double((String) inputParam
                        .get(BPConstants.INTERNET_BANK_TRANSACTION_LIMIT));
                Double thirdPartyLimit = new Double((String) inputParam.get(BPConstants.THIRDPARTY_LIMIT));
                //Double maxTpLimit  = new Double ((String)inputParam.get( BPConstants.TP_MAX_LIMIT ));
                logger.info("Value of DD limit current"+currentDDLimit);
                logger.info("Value of DD limit entered"+internetBankTransactionLimit);
                
                logger.info("Value of TP limit current"+currentTPLimit);
                logger.info("Value of TP limit entered"+thirdPartyLimit);
                
                if(thirdPartyLimit.compareTo(currentTPLimit) != 0 )
                {
                    try 
                    {
                        validator.validateLimit(thirdPartyLimit, Constants.THIRD_PARTY);
                        validator.validateMaxThirdParyLimit(thirdPartyLimit,userName);
                     }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(exception.getErrorCode());
                                                
                    }
                	
                    Field field1 = new Field();
                    field1.setFieldName(BPConstants.THIRDPARTY_LIMIT);
                    field1.setType(BPConstants.SQL_DOUBLE_VALUE);
                    field1.setValue(thirdPartyLimit);

                    inparamList.add(field1);
                }
                
                if(currentDDLimit.compareTo(internetBankTransactionLimit) != 0)
                {
                    try 
                    {
                        validator.validateLimit(internetBankTransactionLimit, Constants.DEMAND_DRAFT);
                    }
                    catch (SBIApplicationException exception)
                    {
                        SBIApplicationException.throwException(ErrorConstants.INVALID_DD_LIMIT);                        
                    }

                    Field field2 = new Field();
                    field2.setFieldName(BPConstants.INTERNET_BANK_TRANSACTION_LIMIT);
                    field2.setType(BPConstants.SQL_DOUBLE_VALUE);
                    field2.setValue(internetBankTransactionLimit);

                    inparamList.add(field2);
                	
                }

                if(inparamList.size() > 0 )
                	userProfile = userDAOImpl.updateProfile(inparamList, user);
                else
                	userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.info("UserProfile object contains value" + userProfile);
        logger.info("updatelimits(Map inputParam)" + LoggingConstants.METHODEND);
        

        return userProfile;
    }

    /**
     * This method form the following objects
     * field=mobile_no;value=<from input User object>;type=number;key=n
     * field=sms_security;value=<from input User object>;type=number;key=n
     * will call the updateProfile method of the UserDAO
     * @param inputParam
     * @return UserProfile
     */
    public UserProfile updateHighSecurityOption(Map inputParam) {
        logger.info("updatehighsecurityoption(Map inputParam)" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Map are" + inputParam);

        try {
        	User user = (User) inputParam.get(Constants.USER);
            String userName = user.getUserAlias();
            logger.info("input fron  Service : " + inputParam);

            if (inputParam != null && userName != null && !userName.trim().equalsIgnoreCase(BPConstants.EMPTY)) {

                String mobileNumber = (String) inputParam.get(BPConstants.MOBILE_NO);
                Integer smsSecurity = (Integer) inputParam.get(BPConstants.SMS_SECURITY);

                List inparamList = new ArrayList();
                
                /*if(smsSecurity.equals(new Integer(0))){
	                Field field1 = new Field();
	                field1.setFieldName(BPConstants.MOBILE_NO);
	                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
	                field1.setValue(mobileNumber);
	                inparamList.add(field1);
                }*/
                Field field2 = new Field();
                field2.setFieldName(BPConstants.SMS_SECURITY);
                field2.setType(BPConstants.SQL_INTEGER_VALUE);
                field2.setValue(smsSecurity);

                
                inparamList.add(field2);

                userProfile = userDAOImpl.updateProfile(inparamList, user);

            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.info("updatelimits(Map inputParam)" + LoggingConstants.METHODEND);
        logger.info("UserProfile object contains value" + userProfile);

        return userProfile;
    }

    /**
     * This method will call the getValidator method of ProfileValidatorFactory with type as
     * TP if the account nature of in accounts object passed is 1
     * PPF if the account nature of in accounts object passed is 2
     * 2. With the object obtained in Step1 calls  the validate method of ProfileValidatorBP.
     * 3. If the validate method returns true calls the insertaccount method of AccountDAO
     * @param account
     * @return Account
     */
    public Account addUserAccounts(Account account) {
        logger.info("addUseraccounts( Account account )" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Account Object is" + account);

        try {
            
            if (account != null) {
                
                String validatortype = "";
                logger.debug("Setting the account nature for Validator factory ");
            
                if(account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString()))
                {
                    validatortype = BPConstants.THIRD_PARTY;
                }
                
                else
                {
                    validatortype = BPConstants.PPF;
                    account.setAccessLevel(new Integer(1));
                }
                
                logger.debug("Calling the getValidator of profileValidatorFactory");
                profileValidatorBP = profileValidatorFactory.getvalidator(validatortype);
                
                Map validateMap = new HashMap();
                validateMap.put(TP_VALIDATION_KEY,TP_VALIDATION_ADD_TYPE);
                validateMap.put(ACCOUNT_KEY,account);
                logger.debug("Calling the validate of profileValidatorBP");
                profileValidatorBP.validate(validateMap);
                
                updatedAccountObj = accountDAOImpl.insertAccount(account);
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.info("addUseraccounts( Account account )" + LoggingConstants.METHODEND);
        logger.info("Account object contains value" + updatedAccountObj);

        return updatedAccountObj;
    }

    /**
     * 1.This method will call the getValidator method of ProfileValidatorFactory with type as TP
     * 2. With the object obtained in Step1 calls  the validate method of ProfileValidatorBP.
     * 3. If the validate method returns true calls the updateaccount method of AccountDAO
     * @param account
     * @return Account
     */
    public Account editUserAccount(Account account) {
        logger.info("edituseraccount( Account account )" + LoggingConstants.METHODBEGIN);
        logger.info("Values in Account Object is" + account);
        Account updatedAccountObj = new Account();

        try {

            if (account != null) {

                String validatortype = "";
                logger.debug("Setting the account nature for Validator factory ");
                if(account.getAccountNature().equalsIgnoreCase(ServiceConstant.THIRD_PARTY.toString()))
                {
                    validatortype = BPConstants.THIRD_PARTY;
                }
                else
                {
                    validatortype = BPConstants.PPF;
                }
                
                logger.debug("Calling the getValidator of profileValidatorFactory");
                profileValidatorBP = profileValidatorFactory.getvalidator(validatortype);
                
                logger.debug("Calling the validate of profileValidatorBP");
                Map validateMap = new HashMap();
                validateMap.put(TP_VALIDATION_KEY,TP_VALIDATION_EDIT_TYPE);
                validateMap.put(ACCOUNT_KEY,account);
                profileValidatorBP.validate(validateMap);
                
                updatedAccountObj = accountDAOImpl.updateThirdParty(account);
            }

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.info("editUseraccounts( Account account )" + LoggingConstants.METHODEND);
        logger.info("Account object contains value" + updatedAccountObj);

        return updatedAccountObj;
    }

    /**
     * 1.Calls the encrpytParameter method of CommonUtils by passing  the hint question and hintanswer in a string array.
     * 2. The encrypted hint details obtained in the step 1 is validated against the hint details in the UserProfile object obtained as input. If it does not match throw an SBIApplicationException
     */
    public boolean verifyHintDetails(String hintquestion, String hintanswer, String username) {
        logger.info("verifyhintdetails" + LoggingConstants.METHODBEGIN);

        if (hintquestion != null && hintanswer != null && username != null) {
            logger.info("verifyhintdetails : Hintquestion " + hintquestion);
            logger.info("verifyhintdetails : Hintanswer " + hintanswer);
            logger.info("verifyhintdetails : Username " + username);

            boolean boolhintvalid = false;

            logger.debug("verifyhintdetails : obtaining userprofile object for user");
            UserProfile userprofile = userDAOImpl.findUserProfile(username);

            logger.debug("verifyhintdetails : obtaining hint details for the user");
            String actualhintq = userprofile.getHintQuestion();
            logger.info("actual hintquestion: "+actualhintq);
             String actualhintans = userprofile.getHintAnswer();
             logger.info("actual hintanswer: "+actualhintans);
            if (actualhintq != null && actualhintans != null) {
                logger.debug("verifyhintdetails : validating hint question against user profile object " + actualhintq);
                boolhintvalid = commonUtils.verifyEncryption(username + "|" + hintquestion, actualhintq);
                if (boolhintvalid) {
                    logger.debug("verifyhintdetails : validating hint answer against user profile object "
                            + actualhintans);
                    boolhintvalid = commonUtils.verifyEncryption(username + "|" + hintanswer, actualhintans);
                    if (!boolhintvalid) {
                        SBIApplicationException.throwException(ErrorConstants.INVALID_HINT_ANSWER_ERROR_CODE);                        
                    }
                    logger.info("verifyhintdetails : " + LoggingConstants.METHODEND);

                }
                else {
                    SBIApplicationException.throwException(ErrorConstants.INVALID_HINT_QUESTION_ERROR_CODE);                    
                }

            }
            else {
                SBIApplicationException.throwException(ErrorConstants.DATA_NOT_FOUND_CODE);                
            }

            return boolhintvalid;
        }
        else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);            
        }
        return false;
    }
    
    public UserProfile updateMobileNo(Map inputParams)
    {
        logger.info("updateMobileNo(Map inputParams)"+LoggingConstants.METHODBEGIN);
        UserProfile userProfile = null;
        String mobileNumber = (String) inputParams.get(BPConstants.MOBILE_NO);
        String countryCode =(String) inputParams.get(BPConstants.COUNTRY_CODE);
        if(mobileNumber!=null && countryCode!=null )
        {
            String busPhone = countryCode+"|"+mobileNumber;
            User user = (User) inputParams.get(BPConstants.USER);
            List inparamList = new ArrayList();
            Field field1 = new Field();
            try{
                field1.setFieldName(BPConstants.BUS_PHONE);
                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                field1.setValue(busPhone);
                inparamList.add(field1);
                logger.info("inparamList"+inparamList);
                userProfile = userDAOImpl.updateProfile(inparamList,user);
                logger.info("updateMobileNo(Map inputParams)"+LoggingConstants.METHODEND);
                
            }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    public UserProfile updateLoginCountAndNumber(Map inputParams)
    {
        logger.info("updateLoginCountAndNumber(Map inputParams)"+LoggingConstants.METHODBEGIN);
        UserProfile userProfile = null;
        Integer loginCount = (Integer) inputParams.get(BPConstants.LOGIN_COUNT);
        Date date = new Date();  
        java.sql.Date   sqlDate =  new java.sql.Date(date.getTime());
        Timestamp loginDate = new Timestamp(sqlDate.getTime());
        logger.info("loginDate ="+loginDate );
        if(loginCount!=null )
        {
            User user = (User) inputParams.get(BPConstants.USER);
            List inparamList = new ArrayList();
            Field field1 = new Field();
            Field field2 = new Field();
            try{
                field1.setFieldName(BPConstants.SQL_LOGIN_COUNT);
                field1.setType(BPConstants.SQL_INTEGER_VALUE);
                field1.setValue(loginCount);
                inparamList.add(field1);
                
                field2.setFieldName(BPConstants.SQL_LOGIN_DATE);
                field2.setType(BPConstants.SQL_TIMESTAMP_VALUE);
                field2.setValue(loginDate);
                inparamList.add(field2);
                
                logger.info("inparamList"+inparamList);
                userProfile = userDAOImpl.updateProfile(inparamList,user);
                logger.info("updateLoginCountAndNumber(Map inputParams)"+LoggingConstants.METHODEND);
                
            }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }else {
            SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        return userProfile;
    }
    public void changeLoginPassword(User user, String oldPassword, String newPassword){
    	
		logger.info("changeLoginPassword(User user, String oldPAssword, String newPassword) "+LoggingConstants.METHODBEGIN);
    	
    	userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
    	String profilePassword=userProfile.getProfilepassword();
    	String txnPassword=userProfile.getTxnPassword();    	

    	//Added for SHA encryption algorithm
    	String loginPwdType=userProfile.getLoginHashing();
    	String profilePwdType=userProfile.getProfileHashing();
    	String txnPwdType=userProfile.getTransactionHashing();
    	
    	if(user != null )
        {
        try{
    		String userName=user.getUserAlias();
    		logger.info("userName:"+userName);
//            boolean loginStatus = userDAOImpl.validateLogin(userName, oldPassword);
    		boolean loginStatus = userDAOImpl.validateLogin(userName, oldPassword,null,null,loginPwdType);//by nag //Added for SHA encryption algorithm
    		if(loginStatus){
    			passwordValidator.loginPassword(newPassword);//Added For CR 5274
    			 if(oldPassword.equals(newPassword))//Added For CR 5274
                 {

                     SBIApplicationException.throwException(ErrorConstants.OLDPASSWORD_NEWPASSWORD_MATCH);
                 }
    			 //else if(profilePassword!=null && commonUtils.verifyEncryption(userName + "|" + newPassword, profilePassword))
    			 else if(profilePassword!=null)
    			 {
    				 if("SHA-512".equals(profilePwdType) && requestResponseService.validateHashSHA2(profilePassword,userName+ "|" + newPassword))
    				 {
                	 	SBIApplicationException.throwException("V0766");
    				 }
    				 else if(commonUtils.verifyEncryption(userName + "|" + newPassword, profilePassword))
    				 {
    					 SBIApplicationException.throwException("V0766");
    				 }
                }
    			 //else if (txnPassword !=null && TransactionPWDUtil.encryptPassword(newPassword).equals(txnPassword))
    			if (txnPassword !=null)
    			 {
    				if("SHA-512".equals(txnPwdType) && requestResponseService.validateHashSHA2(txnPassword,userName+ "~" + newPassword))
             		{
                 		SBIApplicationException.throwException("V0765");
             		}
    				else if((TransactionPWDUtil.encryptPassword(newPassword).equals(txnPassword)))
                	{
                 		SBIApplicationException.throwException("V0765");
                	}
                 }
    			//Added for CR 5450 - begin
	    			int passHistCount = userDAOImpl.getPrevPassHistory(user.getUserAlias(), EncryptMD5.hashMessage(user.getUserAlias() + "#" + newPassword));
	    			//Added for SHA encryption algorithm -Start
	    			int passHistSHACount = userDAOImpl.getPrevPassHistory(user.getUserAlias(), sha512Hashing.hashingSHA2(user.getUserAlias() + "#" + newPassword));
	    			passHistCount=passHistCount+passHistSHACount;
	    			//Added for SHA encryption algorithm -End
	    			if (passHistCount>0){
	    				SBIApplicationException.throwException("SE151");
	    			}
	    		//added for CR 5450 - end
    			
    			userDAOImpl.changeLoginPassword(user, oldPassword, newPassword);

    		}else{
    			SBIApplicationException.throwException(ErrorConstants.INVALID_LOGIN_PASSWORD_ERROR_CODE);
    		}
    	}catch(DAOException daoExp){
    		SBIApplicationException.throwException(daoExp.getErrorCode());
    	}
    	
    	logger.info("changeLoginPassword(User user, String oldPAssword, String newPassword) "+LoggingConstants.METHODEND);
        }
    
        }
    public UserProfile setTransactionPWD(User user, String newPassword) {
        logger.info("setTransactionPWD(User user, String newPassword) method begin"+ LoggingConstants.METHODBEGIN);
        try {
            
            //String arrayString[] = {newPassword };
            //String returnStringArray[] = commonUtils.encryptParam(arrayString);
        	passwordValidator.loginPassword(newPassword);//Added For CR 5274
        	userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
        	String userName = user.getUserAlias();
        	String profilePassword=userProfile.getProfilepassword();
        	String encryptedTxnPwd=null;
        	
        	//Added for SHA encryption algorithm
        	String loginPwdType=userProfile.getLoginHashing();
        	String profilePwdType=userProfile.getProfileHashing();
        	
        	//encryptedTxnPwd=TransactionPWDUtil.encryptPassword(newPassword);
        	encryptedTxnPwd=sha512Hashing.hashingSHA2(userName + "~" + newPassword);//Added for SHA encryption algorithm
        	//if(profilePassword!=null && commonUtils.verifyEncryption(userName + "|" + newPassword, profilePassword))
        	if(profilePassword!=null)
        	{
        		
  				 if("SHA-512".equals(profilePwdType) && requestResponseService.validateHashSHA2(profilePassword,userName+ "|" + newPassword))
  				 {
              	 	SBIApplicationException.throwException("V0761");
  				 }
  				 else if(commonUtils.verifyEncryption(userName + "|" + newPassword, profilePassword))
 				 {
 					 SBIApplicationException.throwException("V0761");
 				 }
        		
        		//SBIApplicationException.throwException("V0761");
            }
//            else if(userDAOImpl.validateLogin(userName, newPassword))
        	//else if(userDAOImpl.validateLogin(userName, newPassword,null,null))//by nag
        	if(userDAOImpl.validateLogin(userName, newPassword,null,null,loginPwdType))// Added for SHA encryption algorithm
            {
            	 SBIApplicationException.throwException("V0762");
            }
        	 
        	
            List inparamList = new ArrayList();
            Field field1 = new Field();
            field1.setFieldName("transaction_password");
            field1.setType(BPConstants.SQL_VARCHAR_VALUE);
            field1.setValue(encryptedTxnPwd);
            
            Field field2 = new Field();
            field2.setFieldName(BPConstants.TXN_HASHING);
            field2.setType(BPConstants.SQL_VARCHAR_VALUE);
            field2.setValue("SHA-512");
            
            inparamList.add(field1);
            inparamList.add(field2);
             userProfile = userDAOImpl.updateProfile(inparamList, user);
        } catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(),
                    daoException);
        }

        logger.info("setTransactionPWD(User user, String newPassword) method end"+ LoggingConstants.METHODEND);
        return userProfile;
    }


    
    
  /**
 * TODO Enter the description of the method here
 * @param enteredpassword
 * @param oldpassword
 * @param user
 * @return UserProfile
 */
public UserProfile changeTxnPassword(String enteredpassword, String oldpassword, User user) {

        logger.info("changeTxnPassword(String enteredpassword, String oldpassword, User user) method begin");
        try {
        	passwordValidator.loginPassword(enteredpassword);//Added For CR 5274
            userProfile = userDAOImpl.findUserProfile(user.getUserAlias());
            String currentPwd = userProfile.getTxnPassword();
            String userName = user.getUserAlias();
            logger.info("User name in change txn pwd method : "+userName);
            String profilePassword=userProfile.getProfilepassword();  
            
            //Added for SHA encryption algorithm
            String loginPwdType=userProfile.getLoginHashing();
            String profilePwdType=userProfile.getProfileHashing();
        	String txnPwdType=userProfile.getTransactionHashing();
        	
        	boolean validationStatus=false;
        	if("SHA-512".equals(txnPwdType))
        	{
        		validationStatus=requestResponseService.validateHashSHA2(currentPwd,userName+ "~" + oldpassword);
        	}
        	else
        	{
        		validationStatus=(TransactionPWDUtil.encryptPassword(oldpassword)).equals(currentPwd);
        	}
            if (validationStatus) {
            //if(TransactionPWDUtil.encryptPassword(oldpassword).equals(currentPwd)){
                if(oldpassword.equals(enteredpassword))
                {
                    SBIApplicationException.throwException(ErrorConstants.OLDPASSWORD_NEWPASSWORD_MATCH);
                }
                //else if(profilePassword!=null && commonUtils.verifyEncryption(userName + "|" + enteredpassword, profilePassword))
                else if(profilePassword!=null)
                {
                	 if("SHA-512".equals(profilePwdType) && requestResponseService.validateHashSHA2(profilePassword,userName+ "|" + enteredpassword))
	   				 {
	               	 	SBIApplicationException.throwException("V0761");
	   				 }
	   				 else if(commonUtils.verifyEncryption(userName + "|" + enteredpassword, profilePassword))
	   				 {
	   					 SBIApplicationException.throwException("V0761");
	   				 }
                	 //SBIApplicationException.throwException("V0761");
                }
//                else if(userDAOImpl.validateLogin(userName, enteredpassword))
                	//else if(userDAOImpl.validateLogin(userName, enteredpassword,null,null))//by nag
                if(userDAOImpl.validateLogin(userName, enteredpassword,null,null,loginPwdType)) //Added for SHA encryption algorithm
                {
                	 SBIApplicationException.throwException("V0762");
                }
                
                String encryptedTxnPwd=null;
                //encryptedTxnPwd=TransactionPWDUtil.encryptPassword(enteredpassword);
                encryptedTxnPwd=sha512Hashing.hashingSHA2(userName + "~" + enteredpassword);//Added for SHA encryption algorithm
                List arrayList = new ArrayList();
                Field field1 = new Field();
                field1.setFieldName("transaction_password");
                field1.setType(BPConstants.SQL_VARCHAR_VALUE);
                field1.setValue(encryptedTxnPwd);
                
                Field field2 = new Field();
                field2.setFieldName(BPConstants.TXN_HASHING);
                field2.setType(BPConstants.SQL_VARCHAR_VALUE);
                field2.setValue("SHA-512");
                
                arrayList.add(field1);
                arrayList.add(field2);  
                userProfile = userDAOImpl.updateProfile(arrayList, user);
            }  
            else
            {
                SBIApplicationException.throwException("CUV002"); // Invalid Transaction Password;
                 
            }

        }

        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.info("changeTxnPassword(String enteredpassword, String oldpassword, User user) method end");
        return userProfile;

    }
//Added for CR 5392
public String checkPhisingIP(String ipAddress) {
	logger.info("checkPhisingIP method begins");
	String validateIP= null;
	int count = 0;
	try{
		ipAddress=ipAddress.substring(0, ipAddress.lastIndexOf("."));
		 count = userDAOImpl.getPhisingIPAddress(ipAddress);
		if(count > 0){
			validateIP="PhisingIP";	
		}
	}
	catch(DAOException daoException){
		SBIApplicationException.throwException(daoException.getErrorCode());			
	}	
		
	logger.info("checkPhisingIP method ends");
	return validateIP;		
}
//End of CR 5392


  // Added for Forgot Password..
 //TODO - ashok
 
	/**
	 * This Method is used to update Hint Question and Hint Answer for Corresponding  in User.
	 * 
	 * @param userProfile
	 *            contain userProfile information like login userName, friendly
	 *            userName ,hint Question,hint Answer and address etc....
	 * @return updated UserProfile After update of Hint Question and Hint
	 *         Answer..
	 */
	public UserProfile changeHintDetails(final UserProfile userProfile){
		logger.info("changeHintDetails(final UserProfile userProfile)"+ LoggingConstants.METHODBEGIN);
		
		UserProfile updatedUserProfile = null;
		try {
			String hintQuesition = userProfile.getHintQuestion();
			String hintAnswer = userProfile.getHintAnswer();
			String userName = userProfile.getUserAlias();
			String arrayString[] = { userName + UtilsConstant.PIPE_SEPARATOR + hintQuesition,
									 userName + UtilsConstant.PIPE_SEPARATOR + hintAnswer 
								   }; // Preparing Normal Array String for Encription.
        
			String returnStringArray[] = commonUtils.encryptParam(arrayString); // Getting Encription arrayString for normal Array String.
			List inparamList = new ArrayList();
			
             // Construction Hint Question DB parameters
			if (hintQuesition != null
					&& !UtilsConstant.EMPTY.equals(hintQuesition)) {
				Field hintQuestionField = new Field();
				hintQuestionField.setFieldName(BPConstants.HINT_QUESTION);
				hintQuestionField.setType(BPConstants.SQL_VARCHAR_VALUE);
				hintQuestionField.setValue(returnStringArray[0]);
				inparamList.add(hintQuestionField);
			}
              // Construction Hint Answer DB parameters
			if (hintAnswer != null && !UtilsConstant.EMPTY.equals(hintAnswer)) {
				Field hintAnswerField = new Field();
				hintAnswerField.setFieldName(BPConstants.HINT_ANSWER);
				hintAnswerField.setType(BPConstants.SQL_VARCHAR_VALUE);
				hintAnswerField.setValue(returnStringArray[1]);
				inparamList.add(hintAnswerField);
			}
			
//			  if(userProfile instanceof User ){
					updatedUserProfile = userDAOImpl.updateProfile(inparamList,(User) userProfile); // for Getting Updated userProfile After update of Hint Question and Answer.
//			  }

		} catch (DAOException daoException) {
			SBIApplicationException.throwException(daoException.getErrorCode(),daoException);
		}

		logger.info("changeHintDetails(final UserProfile userProfile)" + LoggingConstants.METHODEND);
		return updatedUserProfile;
	}
  
 

    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

    public void setCommonUtils(CommonUtils commonUtils) {
        this.commonUtils = commonUtils;
    }

    public void setProfileValidatorBP(ProfileValidatorBP profileValidatorBP) {
        this.profileValidatorBP = profileValidatorBP;
    }

    public void setProfileValidatorFactory(ProfileValidatorFactory profileValidatorFactory) {
        this.profileValidatorFactory = profileValidatorFactory;
    }

    public void setValidator(Validator validator) {
        this.validator = validator;
    }

    public void setUserDAOImpl(UserDAO userDAOImpl) {
        this.userDAOImpl = userDAOImpl;
    }
    
    public void setPasswordValidator(LogonValidator passwordValidator) {
    	this.passwordValidator = passwordValidator;
}
	//Added for SHA encryption algorithm -Start
	public void setRequestResponseService(
			RequestResponseService requestResponseService) {
		this.requestResponseService = requestResponseService;
	}
	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}
	//Added for SHA encryption algorithm -End
      
}

