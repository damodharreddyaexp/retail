/*     
 *AccountInformationBP.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 18, 2005 MURUGAN K - Initial Creation
// Nov 24, boopathi - changed accountType to productType
package com.sbi.common.bp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.AccountDAO;
import com.sbi.common.dao.AccountMasterDAO;
import com.sbi.common.dao.AccountMasterDAOFactory;
import com.sbi.common.dao.DAOConstants;
import com.sbi.common.dao.LoanAccountMasterDAO;
import com.sbi.common.dao.TransactionHistoryDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.Account;
import com.sbi.common.model.AccountDetails;
import com.sbi.common.model.LoanAccountDetails;
import com.sbi.common.model.TransactionAccountDetails;
import com.sbi.common.utils.LoggingConstants;

/*
 * TODO we get the Account related informations from this class
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public class AccountInformationBP {

    private AccountDAO accountDAOImpl;

    private AccountMasterDAOFactory accountMasterDAOFactory;

    private TransactionHistoryDAO transactionHistoryDAOImpl;
    
    /* CR -147 START */
	private LoanAccountMasterDAO loanaccountDetails;
	/* CR -147 END */
    protected final Logger logger = Logger.getLogger(getClass());

    SBIApplicationException applicationException = new SBIApplicationException("Exception in BP");

    /**
     * TODO 1. Invokes AccountDAO.findAccounts to get account list object 2.
     * Return the list
     * 
     * @param userName
     * @return List
     */

    public List getUserAccounts(String userName) {

        logger.info("getUserAccounts(String userName) method begin");
        List accountList = new ArrayList();
        try {
            if (userName != null && !(userName.trim().equals(""))) {

                accountList = accountDAOImpl.findAccounts(userName);
                if (accountList != null) {
                    logger.info("getUserAccounts(String userName) method End");
                    return accountList;
                }
 
            } 
        }
        catch (DAOException daoException) {            
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }

        logger.debug("Account List :" + accountList);
        logger.info("getUserAccounts(String userName) method end");
        return accountList;
    }
 
    /**
     * TODO get the Account List based on Account Type, call
     * AccountDAOImpl.findAccounts(username,productType)
     * 
     * @param username
     * @param productType
     * @return List
     */
    public List getUserAccounts(String username, String productType) {
        List accountList = null;
        logger.info("getUserAccounts(String username, String productType) method begin");
        logger.debug("User name: " + username + " Account Type: " + productType);
        try {
            if (username != null && productType != null) {
                accountList = accountDAOImpl.findAccounts(username, productType);
            }
            else {
                logger.debug("User name and Account Type are NULL");
            }
        }
        catch (DAOException daoException) {            
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List " + accountList);
        logger.info("getUserAccounts(String username, String productType) method end");
        return accountList;

    }

    public List getUserAccounts(String userName, String productType, String accessLevel) {
        return null;
    }

    /**
     * 1. Invokes AccountDAO.findAccounts(username,productType) to get account
     * list object 2. Return the list
     */
    public List getLoanAccounts(String userName, String[] productType, Integer accessLevel ) {
        
        
        
        return null;
    }

    /**
     * 1. Set accountNature to 2. 2. Invokes
     * AccountDAO.findAccountsByNature(username,accountNature) to get account
     * list object. 3. Return the list
     */ 
    public List getPPFAccounts(String userName, String[] productType, Integer accessLevel) {
        logger.info("getPPFAccounts(String userName, String[] productType, Integer accessLevel)"+LoggingConstants.METHODBEGIN);
        List ppfAccountList = null;
        if(userName != null && productType != null && accessLevel != null  ) 
        {
        try{
           
            ppfAccountList = accountDAOImpl.findAccounts(userName, productType,accessLevel );
        }  
        catch(DAOException doaExp)
        {
            SBIApplicationException.throwException(doaExp.getErrorCode(), doaExp); 
        }
        logger.info("getPPFAccounts(String userName, String[] productType, Integer accessLevel)"+LoggingConstants.METHODEND);
        }
        return ppfAccountList;
    }

    /**
     * TODO 1. Call accountDAOImpl.findAccountsWithBalance(username) 2. Return
     * Accounts List object
     * 
     * @param username
     * @return List
     */

    public List getUserAccountsWithBalance(String userName,Boolean accountLimit) {
        logger.info("getUserAccountsWithBalance(String username) method begin");
        logger.debug("User name: " + userName);
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {
 
            try {            	
                accountList = accountDAOImpl.findAccountsWithBalance(userName,accountLimit);
 
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name:" + userName);
        }
        logger.debug("Account List: " + accountList);
        logger.info("getUserAccountsWithBalance(String username) method end");
        return accountList;
    }

    /**
     * 1. Set accountNature to 1. 2. Invokes
     * AccountDAO.findAccountsByNature(username,accountNature) to get account
     * list object. 3. Return the list
     */
    public List getThirdPartyAccounts(String username) {
        return null;
    }

    public List getUserAccountsWithBalance(String userName, String accessLevel, String productType) {

        return null;

    }

    // Change to getTransactionAccounts
    /**
     * TODO Invoce the
     * AccountDAOImpl.findTransactionAccount(userName,productType) to get the
     * filtered account list
     * 
     * @param userName
     * @param productType
     * @return List
     */
    public List getTransactionAccounts(String userName, String productType) {
        List transactionAccountList = null;
        logger.info(" findTransactionAccounts(String userName,String productType) method begin");
        try {
            transactionAccountList = accountDAOImpl.findTransactionAccount(userName, productType);

        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Transaction acccount list : " + transactionAccountList);
        logger.info(" findTransactionAccounts(String userName,String productType) method end");

        return transactionAccountList;
    }

    public List getAccounts(String username) {
        return null;
    }

    /**
     * TODO Get user account [AccountDAO.findAccount(username, accountno,
     * branchcode)] AccountMasterDAOFactory.getAccoutType(account.productType)
     * return AccountMasterDAO AccountMasterDAO.findAccountDetails(accountno,
     * branchcode) return AccountDetails return AccountDetails *
     * 
     * @param accountNo
     * @param branchCode
     * @param userName
     * @return AccountDetails
     */

    public AccountDetails getUserAccountDetails(String accountNo, String branchCode, String userName) {
        // List accountDetailsList = null;
        AccountDetails accountDetails = null;
        logger.info("getUserAccountDetails(String accountNo, String branchCode,String userName) method begin");
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (account != null) {
                    logger.debug("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                    logger.debug("AccountMasterDAO type: " + accountMasterDAO);

                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    if (accountDetails != null) {
                        accountDetails.setAccount(account);
                        logger.debug("AccountDetails  return by" + accountMasterDAO + " is+" + accountDetails);
                        logger.debug("AccountDetails.AccountDescription " + accountDetails.getAccountDescription());
                        logger.debug("AccountDetails.productType " + accountDetails.getAccount().getProductType());
                        logger
                                .info("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");
                    }
                    // return accountDetails;
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
        }
        logger.debug("Account Details: " + accountDetails);
        logger.info("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");

        return accountDetails;
    }
    
    public AccountDetails getUserAccountDetails(String accountNo, String branchCode, String userName,String bankCode) {
        
        AccountDetails accountDetails = null;
        logger.info("getUserAccountDetails(String accountNo, String branchCode, String userName, String bankCode) method begin");
        if (accountNo != null && branchCode != null && userName != null && bankCode != null ) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (account != null) {
                    logger.info("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                    logger.info("AccountMasterDAO type: " + accountMasterDAO);
                    account.setBankCode(bankCode);
                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    if (accountDetails != null) {
                        accountDetails.setAccount(account);
                        logger.info("AccountDetails  return by" + accountMasterDAO + " is+" + accountDetails);
                        logger.info("AccountDetails.AccountDescription " + accountDetails.getAccountDescription());
                        logger.info("AccountDetails.productType " + accountDetails.getAccount().getProductType());
                        logger.info("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");
                    }
                    // return accountDetails;
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
        }
        logger.debug("Account Details: " + accountDetails);
        logger.info("getUserAccountDetails(String accountNo, String branchCode,String userName, String bankCode) method end");

        return accountDetails;
    }
    
    
    public AccountDetails getUpdatedUserAccountDetails(String accountNo, String branchCode, String userName) {
        AccountDetails accountDetails = null;
        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method begin");
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (account != null) {
                    logger.debug("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    logger.info("Product Type: "+account.getProductType());
                    
                    String currencyCode=accountDetails.getCurrencycode();
                    if(currencyCode != null && !"".equals(currencyCode) && currencyCode.length() > 0){
                    	account.setCurrency(currencyCode);//Setting the currency code coming from COre
                    }
                    if("A1".equals(account.getProductType()) || "B1".equals(account.getProductType()))
                    {
                    	TransactionAccountDetails transactionAccountDetails = (TransactionAccountDetails)accountDetails;
                    	account.setBalance(transactionAccountDetails.getAvailableBalance());
                    	 }

                    if (accountDetails != null) {
                    	// CR-147 start
						account.setUserName(userName);
						// CR-147 end
                        accountDetails.setAccount(account);
                        logger.info("account from account details:  --> getBalance(): "+account.getBalance());
                        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");
                    }
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
        }
        logger.debug("Account Details: " + accountDetails);
        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");

        return accountDetails;
    }
    
    public AccountDetails getUpdatedUserAccountDetails(String accountNo, String branchCode, String userName, String bankCode) {
        AccountDetails accountDetails = null;
        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName, String bankCode) method begin");
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (account != null) {
                    logger.debug("Account from AccountDAOImp is" + account);
                    AccountMasterDAO accountMasterDAO = accountMasterDAOFactory.getInstance(account.getProductType());
                    account.setBankCode(bankCode);
                    accountDetails = accountMasterDAO.findAccountDetails(account);
                    logger.info("Product Type: "+account.getProductType());
                    
                    
                    String currencyCode=accountDetails.getCurrencycode();
                    if(currencyCode != null && !"".equals(currencyCode) && currencyCode.length() > 0){
                    	account.setCurrency(currencyCode);//Setting the currency code coming from COre
                    }
                    if("A1".equals(account.getProductType()) || "B1".equals(account.getProductType()))
                    {
                    	TransactionAccountDetails transactionAccountDetails = (TransactionAccountDetails)accountDetails;
                    	account.setBalance(transactionAccountDetails.getAvailableBalance());
                    	 }

                    if (accountDetails != null) {
                    	// CR-147 start
						account.setUserName(userName);
						// CR-147 end
                        accountDetails.setAccount(account);
                        logger.info("account from account details:  --> getBalance(): "+account.getBalance());
                        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName, String bankCode) method end");
                    }
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else { 
            logger.debug("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No "
                    + accountNo);
        }
        logger.debug("Account Details: " + accountDetails);
        logger.debug("getUserAccountDetails(String accountNo, String branchCode,String userName) method end");

        return accountDetails;
    }
    /**
     * TODO Get the Account [AccountDAOImpl.findAccount(String accountNo, String
     * branchCode, String userName)] and get the List of TransactionHistory from
     * [TransactionHistoryDAOImpl.findTransactionHistory(Account
     * account,Timestamp fromDate, Timestamp toDate, int order, String corporateId) using Account
     * 
     * @param userName
     * @param accountNo
     * @param branchCode
     * @param fromDate
     * @param toDate
     * @param order
     * @return List
     * @return corporateId
     */

    public List getAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate,
            Timestamp toDate, int order, String corporateId) {
        logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) begin");
        logger.info("corporateId=***2"+corporateId);
        List transactionHistorylist = null;

        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, fromDate, toDate,
                        order,corporateId);
                logger.debug("TransactionList is " + transactionHistorylist);
                logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) end");

            }
            catch (DAOException daoException) {
            	SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.info("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        return transactionHistorylist;
    }
    
    public List getAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate,
            Timestamp toDate, int order, String corporateId, String timestamp, String type) {
        logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) begin");
        logger.info("corporateId=***2"+corporateId);
        List transactionHistorylist = null;

        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, fromDate, toDate,
                        order,corporateId, timestamp, type);
                logger.debug("TransactionList is " + transactionHistorylist);
                logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) end");

            }
            catch (DAOException daoException) {
            	SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.info("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        return transactionHistorylist;
    }
    /**
     * TODO Get the Account [AccountDAOImpl.findAccount(String accountNo, String
     * branchCode, String userName)] and get the List TransactionHistory from
     * [TransactionHistoryDAOImpl.findTransactionHistory(Account account, int
     * limit)] return List of TransactionHistory
     * 
     * @param userName
     * @param accountNo
     * @param branchCode
     * @param limit
     * @return List
     */

    public List getAccountStatement(String userName, String accountNo, String branchCode, int limit) {
        List transactionHistorylist = null;
        logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) begin");
        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, limit);

            }
            catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
            return transactionHistorylist;

        }
        else {
            logger.debug("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        logger.debug("TransactionHistorylist" + transactionHistorylist);
        logger.info("getAccountStatement() method end ");
        return transactionHistorylist;

    }

    /**
     * TODO Get Accounts By Nature
     * [accountDAOImpl.findAccountsByNature(userName, accountNature)] return
     * List of Accounts
     * 
     * @param userName
     * @param accountNature
     * @return List of Accounts
     */
    public List getAccountsByNature(String userName, Integer accountNature) {
        logger.info("getAccountsByNature(String username,String accountNature) method begin");
        List accountList = new ArrayList();
        if (userName != null && accountNature != null) {
            if ((accountNature.equals(new Integer("0"))) || (accountNature.equals(new Integer("1")))
                    || (accountNature.equals(new Integer("2")))) {
                logger.debug("inside if condition getAccountsByNature : accountNature " + accountNature + "UserName : "
                        + userName);
                try {
                    accountList = accountDAOImpl.findAccountsByNature(userName, accountNature);
                    if (accountList != null) {
                        logger.info("getAccountsByNature(String username,String accountNature) method end");
                        return accountList;
                    }
                }
                catch (DAOException daoException) {
                    SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                }
            }
        }
        else {
            logger.debug("User Name is " + userName);
            logger.debug("Account Nature is " + userName);
        }
        return null;
    }
//Added for CR-5390
    public List getTPAccounts(String userName) {
        logger.info("getTPAccounts(String username) method begin");
        List accountList = new ArrayList();
        if (userName != null ) {
           
                try {
                    accountList = accountDAOImpl.findTPAccounts(userName);
                    if (accountList != null) {
                        logger.info("getTPAccounts(String username) method end");
                        return accountList;
                    }
                }
                catch (DAOException daoException) {
                    SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                }
            }
        
        else {
            logger.debug("User Name is " + userName);
            logger.debug("Account Nature is " + 1);
        }
        return null;
    }
    
    
    
    /**
     * TODO Get the Account [AccountDAOImpl.findAccount(String accountNo, String
     * branchCode, String userName)] and get the List of TransactionHistory from
     * [TransactionHistoryDAOImpl.findTransactionHistory(Account
     * account,Timestamp fromDate, Timestamp toDate, int order) using Account
     * 
     * @param userName
     * @param accountNo
     * @param branchCode
     * @param fromDate
     * @param toDate
     * @param order
     * @return List
     */

    public List getAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate,
            Timestamp toDate, int order) {
        logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) begin");
        List transactionHistorylist = null;

        if (userName != null && accountNo != null && branchCode != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                logger.debug("Account return by AccountDAOImpl is" + account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, fromDate, toDate,
                        order);
                logger.debug("TransactionList is " + transactionHistorylist);
                logger.info("getAccountStatement(String userName, String accountNo, String branchCode, int limit) end");

            }
            catch (DAOException daoException) {
            	SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.info("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        return transactionHistorylist;
    }

    /**
     * TODO Get the Transaction Accounts [accountDAOImpl.findAccounts(userName)]
     * return list of Accounts
     * 
     * @param userName
     * @return List
     */

    public List getTransactionAccounts(String userName) {
        logger.info("getTransactionAccounts(String userName) begin");
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {
            try {
                accountList = accountDAOImpl.findAccounts(userName);
                System.out.println("aaccount List " + accountList);
                if (accountList != null) {
                    logger.info("getUserAccounts(String userName) method End");
                    return accountList;
                }
                else {
                    logger.info("List of Account is" + accountList);
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.debug("input parameter userName " + userName);
        }

        return null;

    }

    /**
     * TODO Get the Accounts with Balance
     * [AccountDAOImpl.findAccountsWithBalance(userName,productType)] retunrn
     * List of Accounts
     * 
     * @param userName
     * @param productType
     * @return List
     */
    public List getUserAccountsWithBalance(String userName, String productType[]) {
        logger.info("getUserAccountsWithBalance(String username, String productType) method begin");
        logger.debug("User name: " + userName + "Account Type: " + productType);
        List accountList = null;
        try {
            if (userName != null && userName.trim() != "" && productType != null) {
                accountList = accountDAOImpl.findAccountsWithBalance(userName, productType);

            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List With Balace " + accountList);
        logger.info("getUserAccountsWithBalance(String username, String productType) end");
        return accountList;
    } 
    
    
    
    //Added for CR 295 - Start
    public Map getBMAccountDetails(String accountNo, String branchCode, Timestamp fromDate, String userName)
    {
    	Map accountDetails = new HashMap();
    	Account accountObj = (Account) accountDAOImpl.findAccount(accountNo,branchCode,userName);
    	   	logger.info("bank system is " + accountObj.getBankSystem());
    	if (accountObj.getBankSystem().equalsIgnoreCase(DAOConstants.CORE))
    	{
    		List bmacclist = accountDAOImpl.getBMAccounts(accountNo,branchCode,fromDate,userName);
    		logger.info("the size of getBMaccList is " + bmacclist.size());
    		accountDetails.put("getBMaccList",bmacclist);
    		
    		
    	}
    	return accountDetails;
    	
    }
//  Added for CR 295 - End

    /**
     * TODO Enter the description of the method here
     * @param userName
     * @return boolean
     */
    public boolean upateCoreMessageStatus(String userName, String [] branchCodes)
    {
        logger.info( "upateCoreMessageStatus(String userName, String [] branchCodes) method begin");
        boolean status = false;
        try{
        status =  accountDAOImpl.upateCoreMessageStatus(userName,branchCodes);  
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.info( "upateCoreMessageStatus(String userName, String [] branchCodes) method end");
        return status;
     }
    
    
    /**
     * TODO AccountDAO object injection done here
     * 
     * @param accountDAOImpl
     *            void
     */

    public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
        this.accountDAOImpl = accountDAOImpl;
    }

    /**
     * TODO AccountMasterFactory object injection done here
     * 
     * @param accountMasterDAOFactory
     *            void
     */

    public void setAccountMasterDAOFactory(AccountMasterDAOFactory accountMasterDAOFactory) {
        this.accountMasterDAOFactory = accountMasterDAOFactory;
    }

   
    
    /**
     * TODO TransactionHistoryDAOImpl object injection done here
     * 
     * @param transactionHistoryDAOImpl
     *            void
     */
     

    public void setTransactionHistoryDAOImpl(TransactionHistoryDAO transactionHistoryDAOImpl) {
        this.transactionHistoryDAOImpl = transactionHistoryDAOImpl;

    } 

    //5202
    public List getUserAccountsWithoutBalance(String userName,Boolean accountLimit) {
        logger.info(" getUserAccountsWithoutBalance(String userName,Boolean accountLimit) method begin");
        logger.debug("User name: " + userName);
        List accountList = new ArrayList();
        if (userName != null && !(userName.trim().equals(""))) {
 
            try {            	
            	accountList=accountDAOImpl.findAccountsWithoutBalance(userName,accountLimit);
 
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
                
            }
        }
        else {
            logger.debug("User name:" + userName);
        }
        logger.debug("Account List: " + accountList);
        logger.info(" getUserAccountsWithoutBalance(String userName,Boolean accountLimit) method end");
        return accountList;
    }
  //Added for CR 5507
    public List getUserAccountsWithBalance(String userName){
    	logger.debug("getUserAccountsWithBalance(String username) method begin");
        List consolidatedAccountList = new ArrayList();
        try {
            if (userName != null && userName.trim() != "") {    	
                consolidatedAccountList = accountDAOImpl.findAccountsWithBalance(userName);	            
            }
        }catch (DAOException daoException) {
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }            
        if(consolidatedAccountList != null && consolidatedAccountList.size()>0){
        logger.info("Size of consolidatedAccountList: " + consolidatedAccountList.size());
        }
        logger.debug("getUserAccountsWithoutBalance(String username) method end");
        return consolidatedAccountList;
    }

    public List getUserDepositAccountDetails(String userName, String productType[]) {
        
        logger.debug("User name: " + userName + "Account Type: " + productType);
        List accountList = null;
        try {
            if (userName != null && userName.trim() != "" && productType != null) {
                accountList = accountDAOImpl.findDepositAccountsWithBalance(userName, productType);
            }
        }
        catch (DAOException daoException) {
            SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
        }
        logger.debug("Account List With Balace " + accountList);
        
        return accountList;
    }
    
    
    //IR 71227
    public AccountDetails getBrokerUserAccountDetails(String accountNo, String branchCode, String userName) {
        AccountDetails accountDetails = null;
        logger.info("getBrokerUserAccountDetails(String accountNo, String branchCode,String userName) method begin");
        logger.info("Input parameters User Name:" + userName + ", Branchcode:" + branchCode + ", Account No: " + accountNo);
        if (accountNo != null && branchCode != null && userName != null) {
            try {
                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                if (account != null) {
                	accountDetails = new AccountDetails();
                    if (accountDetails != null) {
                        accountDetails.setAccount(account);
                    }
                }
            }
            catch (DAOException daoException) {                
                SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        } else { 
            logger.error("Input parameters User Name:" + userName + " Branchcode:" + branchCode + " Account No " + accountNo);
            SBIApplicationException.throwException("SE002");
        }
        logger.info("getBrokerUserAccountDetails(String accountNo, String branchCode,String userName) method end");
        return accountDetails;
    }
    
    
  //IR 71227
    
    public List getBrokerAccountStatement(Account account, String userName, String accountNo, String branchCode, Timestamp fromDate,
            Timestamp toDate, String fromAmount, String toAmount) {
        logger.info("getBrokerAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate, Timestamp toDate, String fromAmount, String toAmount) begin");
        List transactionHistorylist = null;

        if (userName != null && accountNo != null && branchCode != null) {
            try {
//                Account account = accountDAOImpl.findAccount(accountNo, branchCode, userName);
                logger.info("Account return by AccountDAOImpl is" +account);
                transactionHistorylist = transactionHistoryDAOImpl.findTransactionHistory(account, fromDate, toDate,
                        fromAmount,toAmount);
                logger.info("getBrokerAccountStatement(String userName, String accountNo, String branchCode, Timestamp fromDate, Timestamp toDate, String fromAmount, String toAmount) End");

            }
            catch (DAOException daoException) {
            	SBIApplicationException.throwException(daoException.getErrorCode(), daoException);
            }
        }
        else {
            logger.info("Input Parameter user name:" + userName + " account no:" + accountNo + " branchCode:"
                    + branchCode);

        }
        return transactionHistorylist;
    } 
    
 // CR 147 start

	public AccountDetails getLoanCurrAndPrevYearInterest(
			AccountDetails accountDetails)

	{

		String accountNo = accountDetails.getAccount().getAccountNo();
		String branchCode = accountDetails.getAccount().getBranchCode();

		String userName = accountDetails.getAccount().getUserName();

		/*
		 * String accountNo = "00000030001215832"; String branchCode = "00036";
		 * 
		 * String userName = "rajucuser";
		 */

		logger.debug("getLoanCurrAndPrevInterest(AccountDetails accountDetails) method begin");
		if (accountNo != null && branchCode != null && userName != null) {
			try {
				Account account = accountDAOImpl.findAccount(accountNo,
						branchCode, userName);

				if (account != null) {
					logger.debug("Account from AccountDAOImp is" + account);
					/*
					 * AccountMasterDAO accountMasterDAO =
					 * accountMasterDAOFactory
					 * .getInstance(account.getProductType());
					 */

					/*
					 * if ((accountMasterDAO) instanceof LoanAccountMasterDAO) {
					 * loanaccountDetails = (LoanAccountMasterDAO)
					 * accountMasterDAO;
					 * loanaccountDetails.findLoanAccountDetails(account); }
					 */
					// AccountDetails
					// loanaccountDetails=loanaccountDetails.findLoanAccountDetails(account);
					AccountDetails loanaccountDetail = loanaccountDetails
							.findLoanAccountDetails(account);
					logger.info("Product Type: " + account.getProductType());

					if (loanaccountDetail != null) {
						LoanAccountDetails intRateLoanAccDetailNew = (LoanAccountDetails) loanaccountDetail;
						LoanAccountDetails intRateLoanAccDetail = (LoanAccountDetails) accountDetails;
						intRateLoanAccDetail
								.setBranchCode(intRateLoanAccDetailNew
										.getBranchCode());
						intRateLoanAccDetail
								.setBranchName(intRateLoanAccDetailNew
										.getBranchName());
						intRateLoanAccDetail
								.setCurrentYearInterest(intRateLoanAccDetailNew
										.getCurrentYearInterest());
						intRateLoanAccDetail
								.setPreviousYearInterest(intRateLoanAccDetailNew
										.getPreviousYearInterest());
						logger.debug("getLoanCurrAndPrevInterest(AccountDetails accountDetails) method end");
						return intRateLoanAccDetail;
					}

				}
			} catch (DAOException daoException) {
				SBIApplicationException.throwException(
						daoException.getErrorCode(), daoException);
			}
		}
		logger.debug("Account Details: " + accountDetails);
		logger.debug("getLoanCurrAndPrevInterest(String accountNo, String branchCode,String userName) method end");

		return accountDetails;
	}
	
	
	public void setLoanaccountDetails(LoanAccountMasterDAO loanaccountDetails) {
		this.loanaccountDetails = loanaccountDetails;
	}
	

	// CR 147 end
    }

    //End of CR 5507

