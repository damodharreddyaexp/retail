/* 
 * TransactionValidatorBP.java
 * Created on Oct 26, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Oct 26, 2005 BOOPATHI - Initial Creation
//Nov 09,2005  Changed set methods and declare instance are private  which is realated to setter methods.
package com.sbi.common.bp;

import org.apache.log4j.Logger;
import com.sbi.common.model.Transaction;

public abstract class TransactionValidatorBP 
{

    protected Transaction transaction;

    protected final Logger logger = Logger.getLogger(getClass());

    /**
     * Call validate method that return boolean
     * 
     * @param transaction
     * @return boolean
     */
    public abstract boolean validate(Transaction transaction);
    
    public Object validate(Object  inparams){
	   
   return null;
   }

}
