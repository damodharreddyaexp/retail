/*
 * AddAlertValidatorBP.java
 * Created on Jan 3, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jan 3, 2006 KRISHNA KUMAR - Initial Creation
package com.sbi.common.bp;

import org.apache.log4j.Logger;

import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.model.SMSAlertSpec;
import com.sbi.common.utils.AlertValidator;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;
import com.sbi.common.utils.Validator;


/**
 * Call the 4 functions Validator.validateTxnRights
 * AlertValidator.validateAlertTypes(String alertType) Validator.validateAmount
 * AlertValidator.validateNickName(userName,nickName)
 */

public class AddAlertValidatorBP
{
    private Validator validator;
    
    private AlertValidator alertValidator;

    protected final Logger logger = Logger.getLogger(getClass());

    public boolean validate(SMSAlertSpec smsAlertSpec) throws SBIApplicationException
    {
        if (smsAlertSpec != null)
        {
            logger.info("validate(SMSAlertSpec smsAlertSpec)" + LoggingConstants.METHODBEGIN);
            
            if (logger.isDebugEnabled())
            {
                logger.debug("smsAlertSpec :" + smsAlertSpec.toString());
            }
            
            if (logger.isDebugEnabled())
            {
                logger.debug("validateAlertName(smsAlertSpec.getAlertName()");
            }
            alertValidator.validateAlertName(smsAlertSpec.getAlertName());
            
            String alertName = smsAlertSpec.getAlertName();
            
            if(alertName == UtilsConstant.DLBAL ||alertName == UtilsConstant.DUBAL||alertName == UtilsConstant.CLBAL
                    || alertName == UtilsConstant.CUBAL || alertName == UtilsConstant.CIAL || alertName == UtilsConstant.DIAL
                    || alertName == UtilsConstant.CRAL|| alertName == UtilsConstant.DRAL){
	            validator.validateTxnRights(smsAlertSpec.getStringCol2(), smsAlertSpec.getStringCol3(), smsAlertSpec
	                    .getStringCol1(), new Integer(BPConstants.CREDIT_NO));
	            if (logger.isDebugEnabled())
	            {
	                logger
	                        .debug("validateTxnRights(String accountNo, String branchCode, String userName, Integer accessLevel) method for credit - true");
	            }
            }
            /*validator.validateAmount(smsAlertSpec.getFloatCol1());
            if (logger.isDebugEnabled())
            {
                logger.debug("validateAmount(smsAlertSpec.getFloatCol1())");
            }*/
            if( alertName == UtilsConstant.BP )
            {
                alertValidator.validateAlertExists(smsAlertSpec.getStringCol1(),UtilsConstant.BP);
                
            } 
                
            
            
            
            alertValidator.validateNickName(smsAlertSpec.getStringCol1(),smsAlertSpec.getStringCol4());
            
            if (logger.isDebugEnabled())
            {
                logger.debug("validateNickName(smsAlertSpec.getStringCol1(),smsAlertSpec.getStringCol4())");
            }
            
        }
        else
        { 
        	SBIApplicationException .throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }

        logger.info("validate(SMSAlertSpec smsAlertSpec)" + LoggingConstants.METHODEND);
        return true;
    }

    /**
     * Validator injection
     * 
     * @param validator
     */
    public void setValidator(Validator validator)
    {
        this.validator = validator;
    }
    

    /**
     * @param alertValidator The alertValidator to set.
     */
    public void setAlertValidator(AlertValidator alertValidator)
    {
        this.alertValidator = alertValidator;
    }

}
