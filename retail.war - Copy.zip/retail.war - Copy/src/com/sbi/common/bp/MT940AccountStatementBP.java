
package com.sbi.common.bp;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.BankSystemDAO;
import com.sbi.common.dao.LateProcessRequestDAO;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.dao.CommonDAO;


public class MT940AccountStatementBP{
    
	protected final Logger logger = Logger.getLogger(getClass());
	
	private static int mt940RandNo;
	
	private BankSystemDAO coreDAOImpl;
	
	private LateProcessRequestDAO lateProcessRequestDAOImpl;
	
	private int mt940Cachedays;
	
	private CommonDAO commonDAOImpl;	
	//Updated by Sulthan for IR 71772
	public Map requestMT940AccountStatement(Map inputParams)throws Exception{
		logger.info("String requestMT940AccountStatement(Map inputParams)"+LoggingConstants.METHODBEGIN);
		HashMap request=new HashMap();
		Map coreResponse=new HashMap();
		String account=(String)inputParams.get("accountNo");
		//String fromDate=(String)inputParams.get("fromDate");
		//String toDate=(String)inputParams.get("toDate");
		String bankCode=(String)inputParams.get("bankCode");
		//String userName=(String)inputParams.get("userName");
		String action=(String)inputParams.get("action");//IR71772
		String fromBicId=(String)inputParams.get("fromBicId");
		String toBicId=(String)inputParams.get("toBicId");
		//String referenceNo=StringUtils.padString(Long.toString(mt940RandNo++), 5, "0", "l")+Long.toString(new Date().getTime()).substring(3);
		//mt940RandNo=(mt940RandNo==99999) ? mt940RandNo=0:mt940RandNo;	
		
		//request.put("from_date",dateFormatter.format(dateFormatter.parse(fromDate)).replaceAll("/", ""));
		//request.put("to_date", dateFormatter.format(dateFormatter.parse(toDate)).replaceAll("/", ""));
		//changed by Sulthan
		request.put("bankCode", bankCode);	
		request.put("account_number", account);
		request.put("txnno", "007021");
		request.put("action", action);		
		logger.info("ACTION::"+action);
		request.put("branch_swift_id", fromBicId);
		request.put("customer_swift_id", toBicId);
		//request.put("reference_no",referenceNo);	
		List responseList=coreDAOImpl.getDataFromBankSystem(request);
		logger.info(" Total List :"+responseList);
		if(responseList!=null && responseList.size()>0){
			coreResponse=(Map) responseList.get(0);
			/*if(coreResponse!=null){
				logger.info("Statement::"+coreResponse.get("branch_swift_id"));
				logger.info("Statement::"+coreResponse.get("customer_swift_id"));			
				logger.info("Status::"+coreResponse.get("status"));
				logger.info("Statement::"+coreResponse.get("statement"));		
			}*/
		}
				
		/*if(responseList!=null && responseList.size()>0 && ((Map)responseList.get(0)).get("status").equals("LOG.") ){
		
			String fileName=(String)((Map)responseList.get(0)).get("file_name");
			coreResponse.put("userName", userName);
			coreResponse.put("requestId", referenceNo);
			hm.put("param1", fileName.substring(6));
			hm.put("param2", fromDate);
			hm.put("param3", toDate);
			coreResponse.put("param4", account);
			coreResponse.put("status", "Pending");
			coreResponse.put("requestType", "MT940");
			lateProcessRequestDAOImpl.insertToLPR(coreResponse);
		}*/
		else
			SBIApplicationException.throwException("F003");
		
		logger.info("String requestMT940AccountStatement(Map inputParams)"+LoggingConstants.METHODEND);
		return coreResponse;
	}
	public Map viewMT940AccountStatement(Map inputParams){
		HashMap request=new HashMap();
		Map coreResponse=new HashMap();
		String account=(String)inputParams.get("accountNo");
		String bankCode=(String)inputParams.get("bankCode");
		String action=(String)inputParams.get("action");
		//String referenceNo=StringUtils.padString(Long.toString(mt940RandNo++), 5, "0", "l")+Long.toString(new Date().getTime()).substring(3);
		//mt940RandNo=(mt940RandNo==99999) ? mt940RandNo=0:mt940RandNo;
		request.put("account_number", account);
		request.put("action", action);
		request.put("bankCode", bankCode);	
		request.put("txnno", "007021");
		//request.put("reference_no",referenceNo);
		List responseList=coreDAOImpl.getDataFromBankSystem(request);
		if(responseList!=null){
			coreResponse=(Map) responseList.get(0);
			if(coreResponse!=null){
				logger.info("branch_swift_id::"+coreResponse.get("branch_swift_id"));
				logger.info("customer_swift_id::"+coreResponse.get("customer_swift_id"));
				coreResponse.put("account", account);
				coreResponse.put("bankCode", bankCode);
				
			}
			}
		/*logger.info("List viewMT940AccountStatement(String UserName)"+LoggingConstants.METHODBEGIN);
		List mt940details=lateProcessRequestDAOImpl.findMT940AccountStatement(UserName,mt940Cachedays);
		if(mt940details==null || mt940details.size()==0)
			SBIApplicationException.throwException("SE076");
		logger.info("List viewMT940AccountStatement(String UserName)"+LoggingConstants.METHODEND);*/
		return coreResponse;
		
	}
	//Added by IR71772  by Sulthan
	public String getRegisteredUser(Map inputParams) {
		String regUserName=null;
		String accountNo=(String)inputParams.get("accountNo");
		String userName=(String)inputParams.get("userName");
		logger.info("accountNo"+accountNo);
		logger.info("userName"+userName);
		regUserName=commonDAOImpl.getRegisteredCreatedUser(accountNo,userName);
		return regUserName;
	}
	public void setCommonDAOImpl(CommonDAO commonDAOImpl) {
		this.commonDAOImpl = commonDAOImpl;
	}
	public void setCoreDAOImpl(BankSystemDAO coreDAOImpl) {
		this.coreDAOImpl = coreDAOImpl;
	}
	public void setLateProcessRequestDAOImpl(
			LateProcessRequestDAO lateProcessRequestDAOImpl) {
		this.lateProcessRequestDAOImpl = lateProcessRequestDAOImpl;
	}	
	public void setMt940Cachedays(int mt940Cachedays) {
		this.mt940Cachedays = mt940Cachedays;
	}
	
}
