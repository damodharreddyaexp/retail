/* 
 * TransactionValidatorFactory.java
 * Created on Nov 8, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History 
//Nov 8, 2005 BOOPATHI - Initial Creation
//Nov 23, 2005 BOOPATHI - Constants Added
package com.sbi.common.bp;

import org.apache.log4j.Logger;

import com.sbi.common.bp.TransactionValidatorBP;
import com.sbi.common.dao.ErrorConstants;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.utils.LoggingConstants;
import com.sbi.common.utils.UtilsConstant;


public class TransactionValidatorFactory
{

    protected final Logger logger = Logger.getLogger(getClass());

    TransactionValidatorBP fundsTransferValidatorBP;

    TransactionValidatorBP creditToPPFValidatorBP;

    TransactionValidatorBP demandDraftValidatorBP;

    TransactionValidatorBP thirdPartyValidatorBP;

    TransactionValidatorBP loanPartPaymentValidatorBP;
    
    TransactionValidatorBP authorizationValidatorBP;

    TransactionValidatorBP corpTpValidatorBP;
    
    TransactionValidatorBP corpFundsTransferValidatorBP;
    
    TransactionValidatorBP corpDDValidatorBP;
    
    TransactionValidatorBP corpIndirectTaxesValidatorBP;
    			           
    TransactionValidatorBP corpSupplierValidatorBP;
   
    TransactionValidatorBP ddebitAuthValidatorBP;
    
    TransactionValidatorBP corpBillPaymentValidatorBP;
    
    TransactionValidatorBP txnRequestValidatorBP;// added to perform CH txn for GLS Rupee instant
    
    TransactionValidatorBP lienAuthorizationValidatorBP; //added for NOW
    
    TransactionValidatorBP  epfoPaymentValidatorBP;//Added for EPFO
    
    TransactionValidatorBP fixedDepositValidatorBP;  //added for e-TDR
 
	public TransactionValidatorBP getEpfoPaymentValidatorBP() {
		return epfoPaymentValidatorBP;
	}

	public void setEpfoPaymentValidatorBP(
			TransactionValidatorBP epfoPaymentValidatorBP) {
		this.epfoPaymentValidatorBP = epfoPaymentValidatorBP;
	}

	/**
     * Accept the txnName as input and according to that it will return
     * corresponding ValidatorBP instance
     * 
     * @param txnName
     * @return ValidatorBP
     */
    public TransactionValidatorBP getValidator(String txnName)
    {
        logger.info("getValidator(String txnName) " + LoggingConstants.METHODBEGIN);
        if (logger.isDebugEnabled())
        {
            logger.debug("txnName :" + txnName);
        }
        if (txnName != null && !txnName.trim().equalsIgnoreCase(BPConstants.EMPTY))
        {

            if (txnName.equalsIgnoreCase(BPConstants.FUND_TRANSFER))
                return fundsTransferValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.PPF))
                return creditToPPFValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.DEMAND_DRAFT))
                return demandDraftValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.THIRD_PARTY))
                return thirdPartyValidatorBP;
            else if (txnName.equalsIgnoreCase(BPConstants.LOAN_PART_PAYMENT)
                    || txnName.equalsIgnoreCase(BPConstants.LOAN_CLOSURE))
                return loanPartPaymentValidatorBP;
            else if (txnName.equalsIgnoreCase("corp_auth"))
            	return authorizationValidatorBP;
            
            else if (txnName.equalsIgnoreCase("lien_auth"))
            	return lienAuthorizationValidatorBP; //added by shanthi for NOW
            
            else if(txnName.equalsIgnoreCase("ddebit_auth"))
            	return ddebitAuthValidatorBP;
            else if(txnName.equalsIgnoreCase("CT"))
            	return corpTpValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CD"))
            	return corpDDValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CI") || txnName.equalsIgnoreCase(UtilsConstant.RTGS_ECHEQUE_TXN_REF_NAME)||txnName.equalsIgnoreCase(UtilsConstant.NEFT_ECHEQUE_TXN_REF_NAME) || txnName.equalsIgnoreCase("CG")
            		|| txnName.equalsIgnoreCase(UtilsConstant.GRPT_ECHEQUE_TXN_REF_NAME) )//added for GRPT
            	return corpFundsTransferValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CK"))
            	return corpIndirectTaxesValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CB"))
                return corpBillPaymentValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CS"))
            	return corpSupplierValidatorBP;
            
            else if(txnName.equalsIgnoreCase("CH"))
            	return txnRequestValidatorBP;
            else if(txnName.equalsIgnoreCase("CF"))//Added for EPFO
            	return epfoPaymentValidatorBP;
            else if (txnName.equalsIgnoreCase("CW")){
                return fixedDepositValidatorBP;} //Added for ETDR
            else
            {
            	SBIApplicationException.throwException(ErrorConstants.TRANSACTION_NAME_NOT_VALID_ERROR_CODE);
            }
        }
        else
        {
        	SBIApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
          }
        return null;
    }

    /**
     * FundsTransferValidatorBP injection
     * 
     * @param fundsTransferValidatorBP
     */
    public void setFundsTransferValidatorBP(TransactionValidatorBP fundsTransferValidatorBP)
    {
        this.fundsTransferValidatorBP = fundsTransferValidatorBP;
    }

    /**
     * CreditToPPFValidatorBP injection
     * 
     * @param creditToPPFValidatorBP
     */
    public void setCreditToPPFValidatorBP(TransactionValidatorBP creditToPPFValidatorBP)
    {
        this.creditToPPFValidatorBP = creditToPPFValidatorBP;
    }

    /**
     * DemandDraftValidatorBP injection
     * 
     * @param demandDraftValidatorBP
     */
    public void setDemandDraftValidatorBP(TransactionValidatorBP demandDraftValidatorBP)
    {
        this.demandDraftValidatorBP = demandDraftValidatorBP;
    }

    /**
     * ThirdPartyValidatorBP
     * 
     * @param thirdPartyValidatorBP
     */
    public void setThirdPartyValidatorBP(TransactionValidatorBP thirdPartyValidatorBP)
    {
        this.thirdPartyValidatorBP = thirdPartyValidatorBP;
    }

    /**
     * LoanPartPaymentValidatorBP injection
     * 
     * @param thirdPartyValidatorBP
     */
    public void setLoanPartPaymentValidatorBP(TransactionValidatorBP loanPartPaymentValidatorBP)
    {
        this.loanPartPaymentValidatorBP = loanPartPaymentValidatorBP;
    }

	public void setAuthorizationValidatorBP(
			TransactionValidatorBP authorizationValidatorBP) {
		this.authorizationValidatorBP = authorizationValidatorBP;
	}
    
	 public void setCorpDDValidatorBP(TransactionValidatorBP corpDDValidatorBP) {
			this.corpDDValidatorBP = corpDDValidatorBP;
		}

	public void setCorpFundsTransferValidatorBP(
				TransactionValidatorBP corpFundsTransferValidatorBP) {
			this.corpFundsTransferValidatorBP = corpFundsTransferValidatorBP;
	}

	public void setCorpTpValidatorBP(TransactionValidatorBP corpTpValidatorBP) {
			this.corpTpValidatorBP = corpTpValidatorBP;
	}

	public void setCorpIndirectTaxesValidatorBP(
			TransactionValidatorBP corpIndirectTaxesValidatorBP) {
		this.corpIndirectTaxesValidatorBP = corpIndirectTaxesValidatorBP;
	}

	public void setCorpSupplierValidatorBP(
			TransactionValidatorBP corpSupplierValidatorBP) {
		this.corpSupplierValidatorBP = corpSupplierValidatorBP;
	}

	public void setDdebitAuthValidatorBP(
			TransactionValidatorBP ddebitAuthValidatorBP) {
		this.ddebitAuthValidatorBP = ddebitAuthValidatorBP;
	}

	public void setCorpBillPaymentValidatorBP(
			TransactionValidatorBP corpBillPaymentValidatorBP) {
		this.corpBillPaymentValidatorBP = corpBillPaymentValidatorBP;
	}

	public void setTxnRequestValidatorBP(
			TransactionValidatorBP txnRequestValidatorBP) {
		this.txnRequestValidatorBP = txnRequestValidatorBP;
	}

	public void setLienAuthorizationValidatorBP(
			TransactionValidatorBP lienAuthorizationValidatorBP) {
		this.lienAuthorizationValidatorBP = lienAuthorizationValidatorBP;
	}
	//added for e-TDR

	public void setFixedDepositValidatorBP(
			TransactionValidatorBP fixedDepositValidatorBP) {
		this.fixedDepositValidatorBP = fixedDepositValidatorBP;
	}
	

}
