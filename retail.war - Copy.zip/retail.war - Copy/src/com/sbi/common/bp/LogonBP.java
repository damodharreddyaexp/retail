/*
 * LogonBP.java
 * Created on Jun 12, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Jun 12, 2006 MV32627 - Initial Creation
package com.sbi.common.bp;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sbi.common.dao.BVUserDAO;
import com.sbi.common.dao.UserDAO;
import com.sbi.common.model.User;
import com.sbi.common.model.UserProfile;
import com.sbi.common.service.ServiceConstant;
import com.sbi.common.utils.StringUtils;
import com.sbi.common.utils.DateUtils;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;
import com.sbi.common.exception.SBIApplicationResponse;

public class LogonBP {
	private Logger logger=Logger.getLogger(getClass());
	//private static final long MILLIS_PER_DAY = 1000 * 60 * 60 * 24;
	private UserDAO userDAOImpl;
	private BVUserDAO broadVisionDAOImpl;
	private String multipleLoginFlag;
//	public boolean validateLogin(String userName,String password,String ipAddress)throws SBIApplicationException{ //by nag
	public boolean validateLogin(String userName,String password,String ipAddress,String keyString,String sha2Password,String hashingType)throws SBIApplicationException{//by nag  //Added for SHA encryption algorithm
		boolean lockStatus=false;//userDAOImpl.getLockStatus(userName);
		String errorCode="";
        // Added for CR 5110
        Map lock = userDAOImpl.getUserLockPWDType(userName);
        Integer lockCount = null;        
        if (lock.get("LAYOUT_PREF") == null )
            lock.put("LAYOUT_PREF","0");            
        lockCount = new Integer (lock.get("LAYOUT_PREF").toString());
        if (lockCount.intValue() > 2)
            lockStatus=true;
		if(!lockStatus){
//			boolean loginStatus=userDAOImpl.validateLogin(userName,password); //by nag
			boolean loginStatus=userDAOImpl.validateLogin(userName,password,keyString,sha2Password,hashingType);//by nag  //Added for SHA encryption algorithm
			if(!loginStatus){
				String passwordType=userDAOImpl.getPasswordType(userName);
				if(passwordType != null && passwordType.equalsIgnoreCase("J")){
			    	Object[] errorParams={userName};
					SBIApplicationException.throwException("LOG001",errorParams); // Invalid username / password
				}
				else{
					//CR 1808 - Reset login password using PPKIT - starts(if-else loop brought in for this CR) 
					if(passwordType != null && passwordType.equalsIgnoreCase("K"))
					{
						boolean kModeLoginStatus = false;
						String kModeUsername = userDAOImpl.getKModeUserName(userName);
						//kModeLoginStatus=broadVisionDAOImpl.validateLogin(userName,password);
						if(!kModeLoginStatus && kModeUsername!=null && kModeUsername!="")//if password is java encrypted
						{
							//kModeLoginStatus=userDAOImpl.kModeValidateLogin(userName,password,kModeUsername);//by nag
							kModeLoginStatus=userDAOImpl.kModeValidateLogin(userName,password,kModeUsername,keyString);//by nag
						}
						if (!kModeLoginStatus)
						{
							Object[] errorParams={userName};
							if(kModeUsername==null || kModeUsername.trim().equalsIgnoreCase("")){//for kmode password reset users. CR 5034
								errorCode="LOG001";
							}else{//for password redespatch kit users.							
								errorCode="K001"; //by nag
							}
							SBIApplicationException.throwException(errorCode,errorParams); // Invalid username / password. CR 5034  
						}
						else 
						{
							try
							{
								User user=new User();
								user.setUserAlias(userName);
								user.setUserIPaddress(ipAddress);
								userDAOImpl.changeLoginPassword(user,password,password);
							}
							catch(DAOException daoEx)
							{
								logger.error("Exception occured : " , daoEx);
							}
							return true;
						}
					}
					else
					{
					//CR 1808 - Reset login password using PPKIT - ends	
						boolean bvLoginStatus=broadVisionDAOImpl.validateLogin(userName,password);
						logger.info("bvstatus :" + bvLoginStatus);
						if(bvLoginStatus){
							try{
								User user=new User();
								user.setUserAlias(userName);
								user.setUserIPaddress(ipAddress);
								userDAOImpl.changeLoginPassword(user,password,password);
							}catch(DAOException daoEx){
								logger.error("EXception occured : " , daoEx);
							}
							return true;
						}
						else{
							Object[] errorParams={userName};
							logger.info("~~ errorparams ~~"+errorParams);
							SBIApplicationException.throwException("LOG011",errorParams);// Invalid username / password failed in BV 
						}
					}//added for CR 1808 - Reset login password using PPKIT
				}
			}
			else
				return true;
		}
		else{
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG002",errorParams);// Account locked.
		}
		return false;
	}
	
	public Map getUserDetails(Map inputParams)throws SBIApplicationException{
		Map outParams = new HashMap();
		String userName = (String) inputParams.get(ServiceConstant.USER_NAME);
		String password = (String) inputParams.get(ServiceConstant.PASSWORD);
		String sha2password = (String) inputParams.get(ServiceConstant.SHA2_PASSWORD);  //Added for SHA encryption algorithm
        String bankCode = (String) inputParams.get(ServiceConstant.BANK_CODE);
        int dateDifference=0;
        Integer userRole = null;
        UserProfile profile = null;
		User user = userDAOImpl.findUser(userName, password);
		if ( user != null ) {		
			if ( user.getRoles() != null && user.getRoles().size() > 0 ) {
				userRole = (Integer) user.getRoles().get(0);
				if (logger.isDebugEnabled())
					logger.debug("role " + userRole);
				if ( userRole != null ) {
					profile = userDAOImpl.findUserProfile(user.getUserAlias());
					if ( profile != null ) {
						logger.info("profile.getBankCode :  " + profile.getBankCode());
						if( profile.getBankCode().equalsIgnoreCase( bankCode.trim() ) ){
	                        profile.setUserIPaddress((String) inputParams.get(ServiceConstant.IP_ADDRESS));
	                        profile.setRoles(user.getRoles());
	                        profile.setUserAlias(user.getUserAlias());
	                        profile.setUserId(user.getUserId());
	                        profile.setUserState(user.getUserState());
                            if(profile.getPasswordChangeDate()!=null){
							 dateDifference=DateUtils.getDays(new Timestamp(new Date().getTime()),profile.getPasswordChangeDate());
                            profile.setLoginPwdChangedDayCount(dateDifference);
                            }
                            logger.info("Login Password changed:---- " + dateDifference+ " --- days back");
							outParams.put("profile",profile);
							if(multipleLoginFlag!=null&&multipleLoginFlag.equals("NO"))
							 userDAOImpl.insertActiveUserLogin(inputParams);  //Added For CR 5405
                            return outParams;
                       }else{
                    	   	Object[] errorParams={userName,bankCode};
                            SBIApplicationException.throwException("LOG003",errorParams); // bankCode not matching
                       }
					}else {
						Object[] errorParams={userName};
						SBIApplicationException.throwException("LOG004",errorParams);// profile null
					}
				}else {
					Object[] errorParams={userName};
					SBIApplicationException.throwException("LOG005",errorParams);// role null
				}
			} else {
				Object[] errorParams={userName};
				SBIApplicationException.throwException("LOG006",errorParams);// role list null
			}
		} else {
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG007",errorParams);// user null
		}
		return null;
	} 
	//Added for Dmat NOW corporate
	public Map findValidCorpUser(String ebrokingId,String corporateId,String corpAdmin,String userName,Map outParams)throws SBIApplicationException{
		//Map outParams = new HashMap();
		
        logger.info("userName"+userName);
        int count=0;       
        String currencytrade="";
		if ( userName != null ) {
			try{
			currencytrade = userDAOImpl.currencyTradeUser(userName);
			if(currencytrade!=null && currencytrade.equalsIgnoreCase("Yes")){
			count = userDAOImpl.findValidCorpUser(ebrokingId,corporateId,corpAdmin,userName);
			if(count>0){
				//dmat.setUserName(userName);
				outParams.put("count",count);
			}
			else{				
				logger.info("====>>>>>"+"loginFailure");
				outParams.put("profile",null);
				Object[] errorParams={userName};
				SBIApplicationException.throwException("DMATC002",errorParams);// invalid user 
		        }
			
			}else if(currencytrade==null){
				outParams.put("profile",null);
				Object[] errorParams={userName};
				SBIApplicationException.throwException("DMATC003",errorParams);
			}else{
				outParams.put("profile",null);
				Object[] errorParams={userName};
				SBIApplicationException.throwException("DMATC004",errorParams);
			}
			}
			catch(DAOException daoEx){
				logger.info("===================="+userName);
				Object[] errorParams={userName};
				outParams.put("profile",null);
				DAOException.throwException(daoEx.getErrorCode(),errorParams);// Unable to get the password
			   	
			}
		} else {
			Object[] errorParams={userName};
			SBIApplicationException.throwException("LOG007",errorParams);// user null
		}
		return outParams;
	} //ends Dmat NOW corporate
	
	public String getPAssword(String keyId, String password){
		String decPassword=password;
		//StringBuffer key = StringUtils.responseLPadd(keyId,"0");
		//keyId = key.toString();
		//String decryptKey = userDAOImpl.secretKeyGenerator(keyId);
		decPassword = StringUtils.decryptString(password,keyId);
		return decPassword;
	}
 	//Added for SHA encryption algorithm
	public String getSha2Password(String keyId, String sha2password){
		String decSha2Password=sha2password;
		decSha2Password = StringUtils.decryptString(sha2password,keyId);
		return decSha2Password;
	}
 	//Added for SHA encryption algorithm
	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	public void setBroadVisionDAOImpl(BVUserDAO broadVisionDAOImpl) {
		this.broadVisionDAOImpl = broadVisionDAOImpl;
	}

	public void setMultipleLoginFlag(String multipleLoginFlag) {
		this.multipleLoginFlag = multipleLoginFlag;
	}
	
}
