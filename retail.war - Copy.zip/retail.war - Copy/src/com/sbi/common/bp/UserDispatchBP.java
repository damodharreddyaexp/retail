/**
 * @(#) UserDispatchBP.java
 * Created on May 27, 2009
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 * History
 * May 27, 2009 Ponnusamy - Initial Creation
 * this common class used to encrypt the user dispatch details and to 
 * insert into sbi_dispatch_printing_details table.
 */

package com.sbi.common.bp;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import Encryption.Encrypt;

import com.sbi.common.dao.UserDAO;
import com.sbi.common.exception.DAOException;
import com.sbi.common.exception.SBIApplicationException;

public class UserDispatchBP {

	protected final Logger logger = Logger.getLogger(getClass());

	private Encrypt encrypt;

	private UserDAO userDAOImpl;

	private static Map<String, String> bankNames = new HashMap<String, String>();
	
	static {
		bankNames.put("0", "www.onlinesbi.com");
		bankNames.put("A", "www.onlinesbi.com");
		bankNames.put("a", "www.onlinesbi.com");
		bankNames.put("6", "www.onlinesbi.com");
		bankNames.put("1", "www.sbbjonline.com");
		bankNames.put("2", "www.onlinesbh.com");
		bankNames.put("3", "www.onlinesbi.com");
		bankNames.put("4", "www.onlinesbm.com");
		bankNames.put("5", "www.onlinesbp.com");
		bankNames.put("7", "www.sbtonline.in");
	}

	public void insertDispatchDetails(Map<String, String> dispatchDetails) {
		logger.info("insertDispatchDetails (Map<String, String> dispathDetails) Method Starts");
		String encMessage = "";
		String serialNo = null;
		
		if (dispatchDetails != null && dispatchDetails.size() > 0) {
			String encData = null;
			try {
				serialNo = userDAOImpl.getDispatchSerialNo(dispatchDetails.get("appendChar"), dispatchDetails.get("type"));
				dispatchDetails.put("serialNo", serialNo);
				String message = constructMessage(dispatchDetails);
				encData = encrypt.encryptFile(message);
				if(encData==null) 
					logger.info("Encrypt data is null");
					else
				logger.info("Encrypt data length ::: "+encData.length());
				} catch (Exception ex) {
				ex.printStackTrace();
				logger.info("Exception occured :" + ex);
			}
			encMessage = encMessage.replaceAll("\n", "");
			logger.info("serialNo ::: "+serialNo);
			logger.info("airwayBillNumber ::: "+dispatchDetails.get("airwayBillNumber"));
			logger.info("module ::: "+ dispatchDetails.get("module"));
			logger.info("type ::: "+ dispatchDetails.get("type"));
			userDAOImpl.insertUserDispatchDetails(serialNo, encData,dispatchDetails.get("airwayBillNumber"),dispatchDetails.get("module"),dispatchDetails.get("type"));
			} 
		else {
			logger.info("dispatchDetails is null");
			SBIApplicationException.throwException("F001");
		}
		logger.info("insertDispatchDetails (Map<String, String> dispathDetails) Method Ends");
	}

	private String constructMessage(Map<String, String> dispatchDetails) {
		StringBuilder message = new StringBuilder();
		
		message.append(dispatchDetails.get("name")).append("|");
		logger.info("dispatch name ::: "+ dispatchDetails.get("name"));
		message.append(dispatchDetails.get("address1")).append("|");
		logger.info("dispatch address1 ::: "+ dispatchDetails.get("address1"));
		message.append(dispatchDetails.get("address2")).append("|");
		logger.info("dispatch address2 ::: "+ dispatchDetails.get("address2"));
		message.append(dispatchDetails.get("city")).append("|");
		logger.info("dispatch city ::: "+ dispatchDetails.get("city"));
		message.append(dispatchDetails.get("pincode")).append("|");
		logger.info("dispatch pincode ::: "+ dispatchDetails.get("pincode"));
		message.append(dispatchDetails.get("state")).append("|");
		logger.info("dispatch state ::: "+ dispatchDetails.get("state"));
		message.append(dispatchDetails.get("country")).append("|");
		logger.info("dispatch country ::: "+ dispatchDetails.get("country"));
		message.append("Airway Bill Number : ");
		message.append(dispatchDetails.get("airwayBillNumber")).append("|");
		logger.info("dispatch airwayBillNumber ::: "+ dispatchDetails.get("airwayBillNumber"));
		message.append(dispatchDetails.get("userPwd")).append("|");
		if(dispatchDetails.get("userPwd")==null){
			logger.info("dispatch userPwd ::: USER PASSWORD IS NULL ");
		}else{
		    logger.info("dispatch userPwd length:::"+dispatchDetails.get("userPwd").length());
		}
		message.append("Branch : ");
		message.append(dispatchDetails.get("branchName")).append("|");
		logger.info("dispatch branchName ::: "+ dispatchDetails.get("branchName"));
		message.append("Logon to ");
		message.append(bankNames.get(dispatchDetails.get("bankCode"))).append("|");
		logger.info("dispatch bankCode ::: "+ dispatchDetails.get("bankCode"));
		message.append("Serial No : ");
		message.append(dispatchDetails.get("serialNo"));	
		logger.info("dispatch serialNo ::: "+ dispatchDetails.get("serialNo"));
		
		return message.toString();
	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	public void setEncrypt(Encrypt encrypt) {
		this.encrypt = encrypt;
	}

}
