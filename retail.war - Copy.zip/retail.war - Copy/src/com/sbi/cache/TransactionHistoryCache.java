/*
 * TransactionHistoryCache.java
 * Created on Mar 24, 2006
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History
//Mar 24, 2006 MURUGAN K - Initial Creation

package com.sbi.cache;


public class TransactionHistoryCache extends UserSessionCache {
    
    
}
