package com.sbi.cache;

public class CorePropertiesDataCache extends UserSessionCache{

}
