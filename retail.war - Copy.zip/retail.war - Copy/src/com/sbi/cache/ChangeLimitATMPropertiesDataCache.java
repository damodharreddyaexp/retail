package com.sbi.cache;

public class ChangeLimitATMPropertiesDataCache extends UserSessionCache{

}
