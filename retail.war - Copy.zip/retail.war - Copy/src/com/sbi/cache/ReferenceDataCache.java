/*  
 * ReferenceDataCache.java
 * Created on Oct 18, 2005
 *
 * Copyright (c) 2005 by SBI All Rights Reserved.
 * $Header: $
 */
//History 
//Oct 18, 2005 BOOPATHI - Initial Creation
//Nov 07,2005 MURUGAN K - logs added
//NOV 23 , 2005 CONSTANTS ADDED
//NOV 23, 2005 ACCOUNTNAME MAP ADDED
package com.sbi.cache;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.log4j.Logger;

import com.sbi.dao.AccountDAO;
import com.sbi.dao.BranchMasterDAO;
import com.sbi.dao.DAOConstants;
import com.sbi.dao.ProfileDAO;
import com.sbi.dao.SBINameValueMasterDAO;
import com.sbi.utils.UtilsConstant;

public class ReferenceDataCache
{
    private Hashtable cacheReferenceData = new Hashtable();

    private SBINameValueMasterDAO sbiNameValueMasterDAOImpl;
    
    private BranchMasterDAO branchMasterDAOImpl; 
    
    private ProfileDAO profileDAOImpl;
 private AccountDAO accountDAOImpl;

    protected final Logger logger = Logger.getLogger(getClass());

    private void init()
    {

        logger.debug(" init() begin ");
        HashMap coreErrorData = (HashMap) sbiNameValueMasterDAOImpl.getSBICoreErrorData();
        String coreErrorKey = DAOConstants.CORE_ERRORS;
        if (coreErrorData != null)
            setReferenceData(coreErrorKey, coreErrorData);

        HashMap switchErrorData = (HashMap) sbiNameValueMasterDAOImpl.getSBISwitchErrorData();
        String switchErrorKey = DAOConstants.SWITCH_ERRORS;
        if (switchErrorData != null)
            setReferenceData(switchErrorKey, switchErrorData);

        HashMap data = (HashMap) sbiNameValueMasterDAOImpl.getNameValueMasterData();
        String key = DAOConstants.TRANSACTION_LIMIT;
        if (data != null)
            setReferenceData(key, data);
        
        //CR 1523 start
        HashMap serviceCharge = (HashMap) sbiNameValueMasterDAOImpl.getServiceChargeValueData();
        String serviceKey = UtilsConstant.SERVICE_CHARGE_DETAILS;
        if (serviceCharge != null)
            setReferenceData(serviceKey, serviceCharge);
        
        //CR 1523 end
        
        //cutoff time start
        HashMap cutOffTime = (HashMap) sbiNameValueMasterDAOImpl.getCutOffTimeData();
        String cutOffTimeKey = "CUTOFF_TIME";
        if (cutOffTime != null)
            setReferenceData(cutOffTimeKey, cutOffTime);
        
        //cutoff time end
        HashMap branchData = (HashMap) sbiNameValueMasterDAOImpl.findAllBranchName();
        String branchDataKey = DAOConstants.BRANCH_DATA_KEY;
        if (data != null)
            setReferenceData(branchDataKey, branchData);
        
        HashMap allBranchData = (HashMap) branchMasterDAOImpl.findAllBranchesWithCode();
        String allBranchDataKey = "allBranchDataKey";
        if (data != null)
            setReferenceData(allBranchDataKey, allBranchData);
       
        /* set the Country Name and Codes  from ProfileDAOImpl.findCountryNameCodes() */
       
    
        HashMap countryNameCodes = (HashMap) profileDAOImpl.findCountryNameCodes();
        String countryNameCodesKey = DAOConstants.COUNTRY_NAME_CODE;
        if (countryNameCodes != null)
        {
            setReferenceData(countryNameCodesKey, countryNameCodes);
        } 
        
        //CR 5114 start
        HashMap pensionCatMap = (LinkedHashMap) sbiNameValueMasterDAOImpl.getPensionCategoryMap();
        String category = "PENSION_CATEGORY";
        if (pensionCatMap != null)
            setReferenceData(category, pensionCatMap);
        
        //CR 5114 end
        
        /*	CR-5655 Ramanan M - BEGIN - NRE check through Product Code	*/
        HashMap nreProductCodes = (HashMap) sbiNameValueMasterDAOImpl.findAllNREProductCodes();
        String nreProductCodesKey = DAOConstants.NRE_PRODUCT_CODES;
        if (nreProductCodes != null)
        {
            setReferenceData(nreProductCodesKey, nreProductCodes);
        } 
        /*	CR-5655 Ramanan M - END - NRE check through Product Code	*/
        
        /* Added for Voice OTP */
        
        HashMap voiceOTPSeries = (HashMap) profileDAOImpl.findVoiceOTPMobileSeries();
        if (voiceOTPSeries != null)
        {
            setReferenceData(DAOConstants.VOICE_OTP_SERIES, voiceOTPSeries);
        } 
        /* End of Voice OTP */
        
        /* Added for minor Varient  product Code  */
        HashMap minorVarientProdCodes = (HashMap) branchMasterDAOImpl.findAllVarientMinorProducts();
        if (minorVarientProdCodes != null)
        {
            setReferenceData(DAOConstants.MINOR_VARIENT_PRODUCT_CODES,minorVarientProdCodes);
        } 
        /*Added for Post IT pad display*/
        HashMap loanProdCodes = (HashMap) branchMasterDAOImpl.findAllLoanProductCodes();
        if(loanProdCodes !=null){
        	setReferenceData(DAOConstants.LOAN_PRODUCT_CODES,loanProdCodes);
        }
       
        
        Map accountName = new HashMap();
        accountName.put(DAOConstants.A1, DAOConstants.SAVINGS_ACCOUNT);
        accountName.put(DAOConstants.A2, DAOConstants.CURRENT_ACCOUNT);
        accountName.put(DAOConstants.A3, DAOConstants.CASH_CREDIT);
        accountName.put(DAOConstants.A4, DAOConstants.OD_ACCOUNT);
        accountName.put(DAOConstants.A5, DAOConstants.DEPOSIT_ACCOUNT);
        accountName.put(DAOConstants.A6, DAOConstants.LOAN_ACCOUNT);
		// CR - 1566 start
        accountName.put(DAOConstants.A7, DAOConstants.TRADE_ACCOUNT);
        accountName.put(DAOConstants.A8, DAOConstants.TRADE_ACCOUNT);
        accountName.put(DAOConstants.A9, DAOConstants.TRADE_ACCOUNT);
        // CR - 1566 END
        accountName.put(DAOConstants.B1, DAOConstants.PPF_ACCOUNT);
        accountName.put(DAOConstants.NRE_PISA1, DAOConstants.NRE_PIS_ACCOUNT);
        accountName.put(DAOConstants.NRO_PISA1, DAOConstants.NRO_PIS_ACCOUNT);
        accountName.put(DAOConstants.NREA1, DAOConstants.NRE_PARENT_ACCOUNT);
        accountName.put(DAOConstants.NROA1, DAOConstants.NRO_PARENT_ACCOUNT);
        accountName.put(DAOConstants.NRE_PISA2, DAOConstants.NRE_PIS_ACCOUNT);
        accountName.put(DAOConstants.NRO_PISA2, DAOConstants.NRO_PIS_ACCOUNT);
        accountName.put(DAOConstants.NREA2, DAOConstants.NRE_PARENT_ACCOUNT);
        accountName.put(DAOConstants.NROA2, DAOConstants.NRO_PARENT_ACCOUNT);
        
        setReferenceData(DAOConstants.ACCOUNTNAME_KEY, accountName);

        logger.debug(" init() end ");

    }

    /**
     * TODO Get the HashMap value from Hashtable with reference of the key
     * @param key String 
     * @return HashMap 
     */
    public HashMap getReferenceData(String key)
    {
        logger.debug("getReferenceData( String key ) begin");
        if (key.equalsIgnoreCase(DAOConstants.SWITCH_ERRORS)
				|| key.equalsIgnoreCase(DAOConstants.TRANSACTION_LIMIT)
				|| key.equalsIgnoreCase(DAOConstants.CORE_ERRORS)
				|| key.equalsIgnoreCase(DAOConstants.ACCOUNTNAME_KEY)
				|| key.equalsIgnoreCase(DAOConstants.BRANCH_DATA_KEY)
				|| key.equalsIgnoreCase(DAOConstants.COUNTRY_NAME_CODE)
				|| key.equalsIgnoreCase(DAOConstants.NRE_PRODUCT_CODES)
				|| key.equalsIgnoreCase(DAOConstants.VOICE_OTP_SERIES)
				|| key.equalsIgnoreCase(DAOConstants.MINOR_VARIENT_PRODUCT_CODES)
				|| key.equalsIgnoreCase(DAOConstants.LOAN_PRODUCT_CODES))
        {
            HashMap h = (HashMap) cacheReferenceData.get(key);
            if (h != null)
            {
                logger.debug("getReferenceData( String key ) end");
                return h;
            }
            else
            {
                init();
                HashMap data = (HashMap) cacheReferenceData.get(key);
                logger.debug("getReferenceData( String key ) end");
                return data;
            }
        }
        else
        {

            HashMap h = (HashMap) cacheReferenceData.get(key);
            logger.debug("getReferenceData( String key ) end");
            return h;

        }
    }

    /**
     * TODO Set the Map value into the Hashtable with reference of the key
     * @param key String
     * @param value Map
     */
    public void setReferenceData(String key, Map value)
    {
        logger.debug("setReferenceData( String key, Map value )begin");
        cacheReferenceData.put(key, value);
        logger.debug("setReferenceData( String key, Map value )end");
    }

    /** 
     * TODO Remove the Map value from Hashtable with reference of the key
     * @param key String
     */
    public void removeReferenceData(String key)
    {
        logger.debug("removeReferenceData( String key )begin");
        cacheReferenceData.remove(key);
        logger.debug("removeReferenceData( String key )end");
    }

    /**
     * TODO SBINameValueMasterDAOImpl injection 
     * @param sbiNameValueMasterDAOImpl SBINameValueMasterDAO
     */
    public void setSbiNameValueMasterDAOImpl(SBINameValueMasterDAO sbiNameValueMasterDAOImpl)
    {
        this.sbiNameValueMasterDAOImpl = sbiNameValueMasterDAOImpl;

    }

    public void setProfileDAOImpl(ProfileDAO profileDAOImpl) {
        this.profileDAOImpl = profileDAOImpl;
    }

	public void setBranchMasterDAOImpl(BranchMasterDAO branchMasterDAOImpl) {
		this.branchMasterDAOImpl = branchMasterDAOImpl;
	}
/**
	 * @param accountDAOImpl the accountDAOImpl to set
	 */
	public void setAccountDAOImpl(AccountDAO accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}
  
    

 
}

